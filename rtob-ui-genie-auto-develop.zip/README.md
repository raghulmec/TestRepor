#Welcome to Genie 3

To find out more about Genie, visit the [Genie 3 Confluence Page.](https://confluence.global.standardchartered.com/display/GENIE)
