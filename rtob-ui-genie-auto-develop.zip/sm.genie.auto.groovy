@Library('ExtStandardLibrary@STABLE') _

ocRunStdGenie {
    cucumber_opt = "--tags @SecurityMatrixPack"
    email_address = "Praveen.Gunasekara@sc.com;anthony.yeong@sc.com;Elamathy.Prabhakaran@sc.com;Tanushree.Balhara@sc.com;Dhannyasree.Lekshmidas@sc.com;Swapnil.Gour@sc.com"
    mvn_lifecycle_cmd = "clean test"
}