package com.scb.rtob.module.test.framework.glue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class SignatureVerification {
	
	public static Logger logger = Logger.getLogger(SignatureVerification.class);
	
	static CommonUtils utils= new CommonUtils(); 
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static List<String> uploadDoc = new ArrayList<String>();
	public static List<String> primaryUploadDoc = new ArrayList<String>();
	public static List<String> coAppUploadDoc = new ArrayList<String>();
	
	public static void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();
		// Thread.sleep(10000);
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1; 
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last);
	}
	
	   @Given("^Go to Signature Verification WB home page$")
	    public void gotoSVWBHomePage() throws Throwable {

	        wrap.switch_to_default_Content(BaseProject.driver);

	        try {
	            wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "work_basket_option"));
	            wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "seeall_option"));
	            wrap.getWorkbasketoption(BaseProject.driver, " Signature Verification ");
	            wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "modal_submit_button"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	    }
	   
	   @Then("^Signature Verification: select an application number$")
	    public static void selectAnApplicationNumber()
	            throws IOException, InterruptedException, ClassNotFoundException, SQLException {

		       /*DBUtils.convertDBtoMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	           String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);*/
	        wrap.wait(5000);
		  
           
	        String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);

	        BaseProject.appId = appId.trim();

	        logger.info("The Value going to select or Filter is [" + appId + "]");
	        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
	        //wrap.wait(2000);
	        String filter = com.getElementProperties("Signature_Verification","filter_link");
	        String search = com.getElementProperties("Signature_Verification","search_text");
	        String apply_button = com.getElementProperties("Signature_Verification","apply_button");
	        //wrap.wait(2000);
	        wrap.click(BaseProject.driver, filter);
	        //wrap.wait(1000);
	        wrap.typeToTextBox(BaseProject.driver, appId, search);
	       // wrap.wait(1000);
	        wrap.click(BaseProject.driver, apply_button);
	 
            switchFrame();

	       // wrap.wait(3000);

	        try {
	            BaseProject.driver.findElement(By.xpath("//div[@id='HARNESS_CONTENT']//table/tbody/tr[1]/td/div/table/tbody/tr[2]/td/div/span[text()='" + appId + "']")).click();
	        } catch (Exception e) {
	            BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
	        }
	   }
	   
	   @Then("^Selecting all checkbox in Signature Verification WB$")
	    public void selectingAllCheckboxInRM_Referral() throws Throwable {
		   switchFrame();
		   System.out.println("Inside checkbox");
		   
//		   JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
//	       js.executeScript("window.scrollBy(0,250)");
	       
	       JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
	       jse.executeScript("arguments[0].scrollIntoView(true);",wrap.getElement(BaseProject.driver,"//input[contains(@id,'SignatureMatchFlag1')]"));
	       
		    List<WebElement> allcheckbox = BaseProject.driver.findElements(By.xpath("//input[contains(@id,'SignatureMatchFlag')]"));
	        for (WebElement eachchecbox : allcheckbox) {
	            if(eachchecbox.isDisplayed())
	            	//System.out.println("Inside checkbox true"+eachchecbox.isSelected());
	                eachchecbox.click();
	           	}	    
	    }
	
	   @Then("^Signature Verification WB Action Drop down values$")
	   
		public void switchToSignatureVerificationPageAndInspectActionDropDown() throws Throwable {
			switchFrame();
			//wrap.wait(5000);
			//System.out.println("Inside action drop down ");
			WebElement dropdown1 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","Heama_Action"));
			Select dropdown = new Select(dropdown1);

			List<WebElement> Eles = dropdown.getOptions();
			logger.info("The Action dropdown values are given below");
			
			for(WebElement ele : Eles)
			{
				int i=1;
				logger.info("Option  " + i + "is :"+ ele.getText());
				i++;
			}
			
			
		}
	   
	   @Then("^Select the value from Action DropDown and Enter Remarkss$")
		public void selectTheVerifiedValueFromActionDropdownAndEnterRemarks1() throws Throwable {
		   switchFrame();
		   Select sel1 = new Select(BaseProject.driver.findElement(By.xpath("//*[@id='SigCapVerificationAction']")));
		   sel1.selectByIndex(1);
		   //wrap.wait(2000);
		   //wrap.type(BaseProject.driver, "Test", com.getElementProperties("Fulldatacapturemaker","Remarks")); 	   
		   List<WebElement> allremarks1 = BaseProject.driver.findElements(By.xpath(" //*[@id='Comments']"));
		   for (WebElement eachremarks : allremarks1) {
		       if(eachremarks.isDisplayed()){
		              
		              eachremarks.sendKeys("Completed");          		   
		   }
		   }
		   wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
		   }
		    
	   @Then("^Signature Verification : Validate Field '(.+)'$")
	    public static void validateFieldSignatureVerification(String FieldName) throws IOException, InterruptedException {

	        //wrap.wait(1000);

	        logger.info("Going to switch into frame");

	        switchFrame();
			logger.info("Frame switched successfully");

			CommonUtilsData.FieldNameData = FieldName;

	        //CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "Signature_Verification");

	        try {

	            if (!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)) {

	                CommonUtils.validateField_frontline(
	                        CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
	                        //CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData));
//	                      CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
//	                      CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

	            }
	        } catch (Exception E) {

	            System.out.println("Field : " + FieldName + " is not present in Datamodel");
	        }

	    }

	   @Then("^Signature Verication : Validate Field values '(.+)'$")
       public static void validateFieldStepSV(String FieldName) throws Throwable{

              //checkerHeadersvalue=wrap.getHeadersFromCsv(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\" +"Datamodel - Checker1.csv", ",");
              //CsvCompare.convertCsvMapOfMap(System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData\\"+"Datamodel - Checker1.csv",CheckerData,"\n");

              logger.info("Going to switch into frame");

              switchFrame();

              logger.info("Frame switched successfully");
              
              System.out.println("FieldName-------"+FieldName);

              CommonUtilsData.FieldNameData = FieldName; 
              String filename = "C:\\Workspace\\latest\\Frontline\\src\\test\\resources\\ExcelData\\Signature_verication.csv ";
              String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,filename);              
              try{

                    CommonUtils.validateFieldSV(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7]);
                           

                  }
              catch(Exception E){

                     System.out.println("Field : "+FieldName+" is not present ");
              }            

       }

	   
	   
//	   
//	   @Then("^Select the value from Action DropDown and Enter Remarks$")
//		public void selectTheVerifiedValueFromActionDropdownAndEnterRemarks() throws Throwable {
//		   switchFrame();
//		   JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
//		   jse.executeScript("arguments[0].scrollIntoView(true);",wrap.getElement(BaseProject.driver,"//*[@id='SigCapVerificationAction']"));
//		   System.out.println("Inside action drop down and remarks");
//		    wrap.wait(7000);
//		    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","Heama_Action"), "1", "BYINDEX");
//		   // wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Signature_Verification","Action"), "A", "BYVALUE");
//			System.out.println("Inside action drop down values like complete");
//			wrap.wait(5000);
//			wrap.type(BaseProject.driver, "Test", com.getElementProperties("SigVerify","Remarks"));
//			System.out.println("Inside action drop down values like remark");
//			
//			//wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
//		}
	
}

