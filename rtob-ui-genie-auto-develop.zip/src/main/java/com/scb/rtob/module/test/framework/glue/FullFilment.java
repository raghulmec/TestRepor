package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.framework.SQLConnector;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FullFilment {
	
	private static Logger logger = Logger.getLogger(FullFilment.class);
	File file;
	Properties CONFIG ;
	static BusinessCommonUtils businesscommonutils= new BusinessCommonUtils();
	SQLConnector sc = new SQLConnector();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public FullFilment()
	{
		file = new File(System.getProperty("user.dir")+"\\src\\main\\java\\com\\standardchartered\\techm\\rtob\\config\\config.properties");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		 CONFIG = new Properties();
		try {
			CONFIG.load(fis);
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	static CommonUtils utils= new CommonUtils();
	public static WebDriver driver=BaseProject.driver;
	public static Wrapper wrap = new Wrapper();
	public static Commons com = new Commons();
	
	
	/*static Wrapper wrap = new Wrapper();
	// Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	public static WebDriver driver;

	@Given("^openURL$")
	public void openURL() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Automation-March\\Genie3.3\\drivers\\chrome\\2.26\\chromedriver.exe");
		driver = new ChromeDriver();
		String URL = "https://10.20.234.172:8080/prweb/";
		System.out.println(URL);
		driver.get(URL);
		//Thread.sleep(3000);
		//	driver.manage().window().maximize();
		// driver.quit();
	}

	@Given("^enter_valid_credentails$")
	public void enter_valid_credentails() throws Throwable {
		wrap.type(driver, "1555976",
				com.getElementProperties("ExceptionChecker", "home_login_username"));
		wrap.type(driver, "rules",
				com.getElementProperties("ExceptionChecker", "home_login_password"));
		//Thread.sleep(3000);
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "home_login_submit"));
		//Thread.sleep(2000);
	}
*/


	@When("^verify the applicant status in Application Search Fulfillment$")
	public void verify_the_applicant_status_in_Application_Search_Fulfillment() throws Throwable
	{


		wrap.click(driver, com.getElementProperties("Fullfilment","search") );


		// wrap.switchFrame1();
		Thread.sleep(5000);

		driver.switchTo().frame("PegaGadget0Ifr");
		Thread.sleep(5000);
		//	driver.switchTo().defaultContent();
		driver.findElement(By.id("ApplicationRefNo")).clear();
		//driver.findElement(By.id("ApplicationRefNo")).sendKeys(BaseProject.appId);
		driver.findElement(By.id("ApplicationRefNo")).sendKeys("IN20170405000036");
		//wrap.type(driver, "IN20170227000043", com.getElementProperties("Fullfilment", "applicationid" ));



		wrap.click(driver, com.getElementProperties("Fullfilment", "searchbutton"));

		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget0Ifr");
		Thread.sleep(5000);
		
		//driver.findElement(By.xpath("//div[@class='oflowDivM ']/span/a[text()='"+BaseProject.appId+"']")).click();
		
		driver.findElement(By.xpath("//div[@class='oflowDivM ']/span/a[text()='IN20170405000036']")).click();
	//	wrap.click(driver, com.getElementProperties("Fullfilment", "Applink"));
		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");
		Thread.sleep(5000);
		wrap.click(driver, com.getElementProperties("Fullfilment", "Status"));




		/*String search_link=com.getElementProperties("Fullfilment", "Search_link_XPATH");
		String ApplicationNo=com.getElementProperties("Fullfilment", "Application_ID");
		String serach_button=com.getElementProperties("Fullfilment", "Search_Button_XPATH");
		String moreInfo=com.getElementProperties("Fullfilment", "More_Info_XPATH");
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		wrap.click(driver, search_link);
		//Thread.sleep(3000);

		Thread.sleep(3000);
		wrap.type(driver, "IN20170227000043", ApplicationNo);
		wrap.click(driver, serach_button);
		Thread.sleep(5000);
		 */			
	}





	@Then ("^VerifyCustomer$")
	public void verifyCustomer() throws Throwable {
        int count =0;
		//WebElement eletable =driver.findElement(By.xpath("//h2[text()='Customer/Account Setup']//following::div[@id='PEGA_GRID_SKIN']//following::table"));
		List<WebElement> headers=wrap.getElements(driver,"//span[contains(text(),'Service Name')]/parent::div/parent::td/parent::tr//td/div/span");
		List<WebElement> cells=wrap.getElements(driver,"//span[contains(text(),'Create Customer')]/parent::div/parent::td/parent::tr//td/div/span");

		for(WebElement header:headers){
			System.out.print(header.getText());
			System.out.print(",");
		}	
		System.out.println();
		for(WebElement cell:cells){
			
			  if(cell.getText().startsWith("CRN"))
			  {
						
				  count++;
				  
						System.out.print("The Customer Number is :"+cell.getText());
						
						
						
						

							System.out.println();
							String val[]=cell.getText().split(":");
							
							if(cell.getText().length() == 16)
							{
								System.out.println("The Length of Customer no is  16");
							}
							/*sc.Result(val[1]);
							if (val[1].length()==16)
							{
								System.out.println("The Length of Customer no is  16");
							}
*/
							
							

			  }	

			  
		}


		if (count==0)
		{
			System.out.println("Customer No not created");
			
			Assert.fail();
		}






	}


	/*@When("^verify the applicant status in Application Search Basic Data '(.*)'$")
	public void verify_the_applicant_status_in_Application_Search_Basic_Data(String appnum) throws Throwable
	{


		wrap.click(driver, com.getElementProperties("Fullfilment","search") );


		// wrap.switchFrame1();
		Thread.sleep(5000);

		driver.switchTo().frame("PegaGadget0Ifr");
		Thread.sleep(5000);
		//	driver.switchTo().defaultContent();
		driver.findElement(By.id("ApplicationRefNo")).clear();
		driver.findElement(By.id("ApplicationRefNo")).sendKeys(appnum);
		//wrap.type(driver, "IN20170227000043", com.getElementProperties("Fullfilment", "applicationid" ));



		wrap.click(driver, com.getElementProperties("Fullfilment", "searchbutton"));

		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget0Ifr");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//div[@class='oflowDivM ']/span/a[text()='"+appnum+"']")).click();
	//	wrap.click(driver, com.getElementProperties("Fullfilment", "Applink"));
		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");
		Thread.sleep(5000);
		wrap.click(driver, com.getElementProperties("Fullfilment", "Status"));




				
	}*/

	@When("^verify the applicant status in Application Search Basic Data '(.*)'$")
    public void verify_the_applicant_status_in_Application_Search_Basic_Data(String appnum) throws Throwable
    {


           wrap.click(BaseProject.driver, com.getElementProperties("Fullfilment","search") );


           // wrap.switchFrame1();
           Thread.sleep(5000);
wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
    //     driver.switchTo().frame("PegaGadget0Ifr");
           Thread.sleep(5000);
           //     driver.switchTo().defaultContent();
           BaseProject.driver.findElement(By.id("ApplicationRefNo")).clear();
           BaseProject.driver.findElement(By.id("ApplicationRefNo")).sendKeys(appnum);
           //wrap.type(driver, "IN20170227000043", com.getElementProperties("Fullfilment", "applicationid" ));



    //     wrap.click(BaseProject.driver, com.getElementProperties("Fullfilment", "searchbutton"));
    WebElement ele=      BaseProject.driver.findElement(By.xpath("//button[text()='earch ']"));
    
    
    JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
    executor.executeScript("arguments[0].click();", ele);  


           BaseProject.driver.switchTo().defaultContent();
           BaseProject.driver.switchTo().frame("PegaGadget0Ifr");
           Thread.sleep(5000);
           
           BaseProject.driver.findElement(By.xpath("//div[@class='oflowDivM ']/span/a[text()='"+appnum+"']")).click();
    //     wrap.click(driver, com.getElementProperties("Fullfilment", "Applink"));
           BaseProject.driver.switchTo().defaultContent();
           BaseProject.driver.switchTo().frame("PegaGadget1Ifr");
           Thread.sleep(5000);
           wrap.click(BaseProject.driver, com.getElementProperties("Fullfilment", "Status"));




           /*String search_link=com.getElementProperties("Fullfilment", "Search_link_XPATH");
           String ApplicationNo=com.getElementProperties("Fullfilment", "Application_ID");
           String serach_button=com.getElementProperties("Fullfilment", "Search_Button_XPATH");
           String moreInfo=com.getElementProperties("Fullfilment", "More_Info_XPATH");
           driver.switchTo().defaultContent();
           Thread.sleep(3000);
           wrap.click(driver, search_link);
           //Thread.sleep(3000);

           Thread.sleep(3000);
           wrap.type(driver, "IN20170227000043", ApplicationNo);
           wrap.click(driver, serach_button);
           Thread.sleep(5000);
           */                  
    }

	@Then("^Verify Fullfilemnt Banking Service Details$")
	public void verify_Fullfilemnt_Banking_Service_Details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement eletable =driver.findElement(By.xpath("//h2[text()='Banking Services']//following::table[@id='gridLayoutTable']"));
		//String data= null;
		List <WebElement>  trows= eletable.findElements(By.tagName("tr"));
		System.out.println(trows.size());

		for (WebElement tr : trows) {

			// System.out.println(tr.getText());

			List<WebElement> tdatas= tr.findElements(By.tagName("td"));
			for (WebElement td : tdatas) {


				System.out.println(td.getText());

			}






		}


	}


	@Then("^Verify Cheque book Status$")
	public void verify_Cheque_book_Status() throws Throwable {



		// Write code here that turns the phrase above into concrete actions

		WebElement eletable =driver.findElement(By.xpath("//h2[text()='Cheque Book Status']//following::table[@id='gridLayoutTable']"));


		//String data= null;
		
		List <WebElement>  trows= eletable.findElements(By.tagName("tr"));
		System.out.println(trows.size());

		for (WebElement tr : trows) {

			// System.out.println(tr.getText());

			List<WebElement> tdatas= tr.findElements(By.tagName("td"));
			for (WebElement td : tdatas) {


				System.out.println(td.getText());

			}






		}




	}





	@Given("^Go to Exceptions '(.+)'$")
	public void Go_to_Exceptions(String workbasketModule) throws Throwable {

		Thread.sleep(5000);
		wrap.click(driver, com.getElementProperties("Fullfilment", "work_basket_option"));
		Thread.sleep(2000);

		wrap.click(driver, com.getElementProperties("Fullfilment", workbasketModule));
	}




	/*@When ("^select application number '(.*)'$")
	public static void select_application_number(String appNumber) throws IOException, InterruptedException{


		Thread.sleep(1000);

		String filter = com.getElementProperties("Fullfilment", "filter_link");
		String search = com.getElementProperties("Fullfilment","search_text");
		String apply_button = com.getElementProperties("Fullfilment","apply_button");
		try{
			wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
		}
		catch(Exception e){
			//wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			wrap.click(driver, filter);
			Thread.sleep(1000);

			wrap.typeToTextBox(driver, appNumber, search);
			wrap.click(driver, apply_button);


			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();

		}
		Thread.sleep(1000);
		wrap.switch_to_default_Content(driver);
	}
*/

	@Then("^Verify the Fullfilment Exceptions$")
	public void verify_the_Fullfilment_Exceptions() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		wrap.switch_to_default_Content(driver);
		wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");


		WebElement eletable =driver.findElement(By.xpath("//h2[text()='Customer/Account Setup']//following::table[@class='gridTable ']"));
		//	String data= null;
		List <WebElement>  trows= eletable.findElements(By.tagName("tr"));
		System.out.println(trows.size());

		for (WebElement tr : trows) {

			// System.out.println(tr.getText());

			List<WebElement> tdatas= tr.findElements(By.tagName("td"));
			for (WebElement td : tdatas) {


				System.out.println(td.getText());






			}


		}




	}




	@Given("^Fullfilment Banking Services$")
	public void fullfilment_Banking_Services() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement eletable =driver.findElement(By.xpath(" //h2[text()='Banking Services']//following::table[@class='gridTable ']"));
		//	String data= null;
		List <WebElement>  trows= eletable.findElements(By.tagName("tr"));
		System.out.println(trows.size());

		for (WebElement tr : trows) {

			// System.out.println(tr.getText());

			List<WebElement> tdatas= tr.findElements(By.tagName("td"));
			for (WebElement td : tdatas) {


				System.out.println(td.getText());






			}   

		}

	}
	
	
	@Then("^verifyMaster$")
	public void verifymaster() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		int count=0;
	//	WebElement eletable =driver.findElement(By.xpath("//h2[text()='Customer/Account Setup']//following::div[@id='PEGA_GRID_SKIN']//following::table"));
		List<WebElement> headers=wrap.getElements(driver,"//span[contains(text(),'Service Name')]/parent::div/parent::td/parent::tr//td/div/span");
		List<WebElement> cells=wrap.getElements(driver,"//span[contains(text(),'Create Master')]/parent::div/parent::td/parent::tr//td/div/span");

		for(WebElement header:headers){
			System.out.print(header.getText());
			System.out.print(",");
		}	
		System.out.println();
		for(WebElement cell:cells){
			
			
  if(cell.getText().startsWith("MRN"))
  {
	  
	  
	  count++;	
			System.out.print("The Master Number is :"+cell.getText());
		//	System.out.print("-");

			System.out.println();
			String val[]=cell.getText().split(":");
			if (val[1].length()==7)
			{
				System.out.println("The Length of Master no is 7");
			}
  }	

		}
		
		
		
		if (count==0)
		{
			System.out.println("Master No not created");
			
			Assert.fail();
		}

	}
	
	
	@Then("^verifyUpdateCustomer$")
	public void verifyupdatecustomer() throws Throwable {

		int count =0;
		List<WebElement> headers=wrap.getElements(driver,"//span[contains(text(),'Service Name')]/parent::div/parent::td/parent::tr//td/div/span");
		List<WebElement> cells=wrap.getElements(driver,"//span[contains(text(),'Update Customer')]/parent::div/parent::td/parent::tr//td/div/span");

		for(WebElement header:headers){
			System.out.print(header.getText());
			System.out.print(",");
		}	
		System.out.println();
		for(WebElement cell:cells){
			
			if(cell.getText().startsWith("CRN"))
			  {
						
				count++;
						System.out.print("The Customer Number is :"+cell.getText());
						
							System.out.println();
							String val[]=cell.getText().split(":");
							sc.Result(val[1]);
							if (val[1].length()==13)
							{
								System.out.println("The Length of Customer no is  13");
							}


							
							if (count==0)
							{
								System.out.println("Update Customer No not created");
								
								Assert.fail();
							}
			  }	



			//System.out.print(cell.getText());
			
		//	System.out.print("-");
// Write code here that turns the phrase above into concrete actions
	    
	}
}
	
	
	
	@Given("^verifyUpdateMaster$")
	public void verifyupdatemaster() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		int count =0;
		List<WebElement> headers=wrap.getElements(driver,"//span[contains(text(),'Service Name')]/parent::div/parent::td/parent::tr//td/div/span");
		List<WebElement> cells=wrap.getElements(driver,"//span[contains(text(),'Modify Master')]/parent::div/parent::td/parent::tr//td/div/span");

		for(WebElement header:headers){
			System.out.print(header.getText());
			System.out.print(",");
		}	
		System.out.println();
		for(WebElement cell:cells){
			
			
  if(cell.getText().startsWith("MRN"))
  {
	  
	  count++;
			
			System.out.print("The Master Number is :"+cell.getText());
		//	System.out.print("-");

			System.out.println();
			String val[]=cell.getText().split(":");
			if (val[1].length()==7)
			{
				System.out.println("The Length of Master no is 7");
			}
  }	

		}
		
		
		
		if (count==0)
		{
			System.out.println("Update Master No not created");
			
			Assert.fail();
		}

	}
	
	
	@Given("^SMSVerify$")
	public void smsverify() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	@When("^Validate Application Status in search page for Fulfillment$")
    public static void search_appstatus_fulfillment()
                  throws IOException, InterruptedException, SQLException, ClassNotFoundException {
           
           String search=com.getElementProperties("Fullfilment", "FF_Supp_Search");
           String applicationid=com.getElementProperties("Fullfilment", "FF_Supp_AppNo_Text");
           String searchbutton=com.getElementProperties("Fullfilment", "FF_Supp_SearchButton");
           
           //DBUtils.convertDBtoMap("bdquery");
           utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","ApplicationNo");
           String appNumber = CommonUtils.readColumnWithRowID("ApplicationId", BaseProject.scenarioID);
                        
           wrap.switch_to_default_Content(BaseProject.driver);
           wrap.wait(5000);
           wrap.click(BaseProject.driver, search);
           wrap.wait(500);
           wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
           wrap.typeToTextBox(BaseProject.driver, appNumber, applicationid);
           wrap.click(BaseProject.driver, searchbutton);
           wrap.wait(500);
           
           String appidlink = com.getElementProperties("Fullfilment", "FF_Supp_AppID");
           //wrap.click(BaseProject.driver, appidlink);
           wrap.wait(1000);
           BaseProject.driver.findElement(By.xpath("//a[contains(text(),'"+appNumber+"')]")).click();
           wrap.wait(1000);
           wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
           
           //BaseProject.driver.findElement(By.xpath("//h3[contains(text(),'Service Execution Status')]")).click();
           
           String servexecstatus= com.getElementProperties("Fullfilment", "FF_Supp_ServExecStatus");
           wrap.click(BaseProject.driver, servexecstatus);
           
           
           List<WebElement> relno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Create Customer')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Reference No']//span"));
           for(WebElement relno1: relno){
                 logger.info(relno1.getText());
                    System.out.println("Relationhip nos are" +relno1.getText());
                    String relnoss= relno1.getText().substring(5).trim();
                  logger.info("Primary and Coapplicant relnos are"+relnoss);
                    
                    }
           
           List<WebElement> custno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Create Master')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Reference No']//span"));
           for(WebElement custno1: custno){
                 logger.info(custno1.getText());
                    System.out.println("Master nos are" +custno1.getText());
                  String custnoss= custno1.getText().substring(9).trim();
                  logger.info("Primary and Coapplicant Masternos are"+custnoss);
                    }
           
           List<WebElement> cardno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Create Account')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Account Number']//span"));
           for(WebElement cardno1: cardno){
                 logger.info(cardno1.getText());
                    System.out.println("Account nos are" +cardno1.getText());
                  //String cardnoss= cardno1.getText().substring(9).trim();
              //  logger.info("Primary and Coapplicant Account nos are"+cardnoss);
                    }
           
           
           
           
           List<WebElement> irows =   BaseProject.driver.findElements(By.xpath("//h2[contains(text(),'Customer/Account Setup')]//ancestor::div[@tabindex='0' and @id='RULE_KEY']//following-sibling::div[@section_index='1']//table[@class='gridTable ']//tbody//tr"));     
           int iRowsCount = irows.size();     
           List<WebElement> icols =   BaseProject.driver.findElements(By.xpath("//h2[contains(text(),'Customer/Account Setup')]//ancestor::div[@tabindex='0' and @id='RULE_KEY']//following-sibling::div[@section_index='1']//table[@class='gridTable ']//tbody//tr//th"));     
           int iColsCount = icols.size();     
           System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
           System.out.println();      

           FileOutputStream fos = new FileOutputStream("C:\\selenium\\test.xlsx");                                 

           XSSFWorkbook wkb = new XSSFWorkbook();       
           XSSFSheet sheet1 = wkb.createSheet("DataStorage"); 
           int rowid=0;
           for (int i=1;i<=iRowsCount;i++)      
           {  
            XSSFRow excelRow = sheet1.createRow(i);            
           for (int j=1; j<=iColsCount;j++)                    
           {           
           if (i==1)       
           {           
           WebElement val= BaseProject.driver.findElement(By.xpath("//h2[contains(text(),'Customer/Account Setup')]//ancestor::div[@tabindex='0' and @id='RULE_KEY']//following-sibling::div[@section_index='1']//table[@class='gridTable ']//tbody//tr["+i+"]/th["+j+"]"));             
           String  a = val.getText();            
           System.out.print(a); 
           logger.info("Header titles are" +a);

           int cellid=0;             
           XSSFCell excelCell = excelRow.createCell(j);                  
           excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
           excelCell.setCellValue(a);  

           //wkb.write(fos);       
           }       
           else        
           {           
           WebElement val= BaseProject.driver.findElement(By.xpath("//h2[contains(text(),'Customer/Account Setup')]//ancestor::div[@tabindex='0' and @id='RULE_KEY']//following-sibling::div[@section_index='1']//table[@class='gridTable ']//tbody//tr["+i+"]/td["+j+"]"));             
           String a = val.getText();                    
           System.out.print(a);                            
           logger.info("table values are" +a);
           
           XSSFCell excelCell = excelRow.createCell(j);                      
           excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
           excelCell.setCellValue(a);   

           //wkb.write(fos);       
           }       
           }               
           System.out.println();     
           }     
           fos.flush();     
           wkb.write(fos);     
           fos.close();     
           }

}
