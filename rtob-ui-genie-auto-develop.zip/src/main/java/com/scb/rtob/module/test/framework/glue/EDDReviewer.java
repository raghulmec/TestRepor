package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EDDReviewer {

    public static Logger logger = Logger.getLogger(EDDReviewer.class);
	File file;
	Properties CONFIG ;

//	static BusinessCommonUtils businessutils= new BusinessCommonUtils();
	public static WebDriver driver=BaseProject.driver;
	static CommonUtils utils= new CommonUtils();
	
	public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
	//public static String BaseProject.scenarioID = BaseProject.scenarioID;
	
	public static String excelValue = BaseProject.scenarioID;

	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";

	public static List<HashMap<String, String>> exceldata = new ArrayList<HashMap<String, String>>();
	public static LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();

	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	
	   public static String propertiesFilename = "EDDReviewer";

	
	@Given("^Go to EDD Reviewer home page$")
	 public void goto_EDD()
	{
		 wrap.switch_to_default_Content(BaseProject.driver);
		
	        try {
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
	            wrap.getWorkbasketoption(BaseProject.driver, "EDD Reviewer");
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }		
	}
	
	
	 
	@Then("^EDD Reviewer: select an application number$")
	public static void select_application_number()
			throws IOException, InterruptedException, ClassNotFoundException, SQLException {
		wrap.wait(5000);
	    String appId = DBUtils.readColumnWithRowID("Application_ID_CDD", BaseProject.scenarioID);
		logger.info("The Value going to select or Filter is ["+appId+"]");

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		wrap.wait(2000);		
		String filter = com.getElementProperties("Fulldatacapturemaker",
				"filter_link");
		String search = com.getElementProperties("Fulldatacapturemaker",
				"search_text");
		String apply_button = com.getElementProperties("Fulldatacapturemaker",
				"apply_button");
		wrap.click(BaseProject.driver, filter);
		wrap.wait(1000);
		wrap.typeToTextBox(BaseProject.driver, appId, search);
		wrap.wait(1000);
		wrap.click(BaseProject.driver, apply_button);

		wrap.wait(10000);

		WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
		((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
		BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();

	}
	
//	@Given("^Basic: Switch to frame$")
	public  void switchFrame() throws InterruptedException {
		int Last = 0;
		Thread.sleep(500);
		driver.switchTo().defaultContent();
		Thread.sleep(500);
		List<WebElement> frames = driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		logger.info(Last);
		driver.switchTo().frame(Last);
		Thread.sleep(500);
	}

	@When("^EDD Reviewer : Logout the application$")
	public void logout() throws IOException, InterruptedException
	{
		boolean visi_logout=false;
		wrap.switch_to_default_Content(driver);
		visi_logout = wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).isDisplayed();
		if (visi_logout==true)
		{
			wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).click();
			logger.info("User logged out successfully");
			Thread.sleep(500);

		}

	}
	
	
	@Given("^EDDReviewer: Submit$")
	public void submit() throws IOException, InterruptedException{
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","Submit")));
		wrap.click(BaseProject.driver, com.getElementProperties("EDDReviewer","Submit"));
		Thread.sleep(2000);
		
	}
	

	 @And("^connect to DB and fetch EDD dataset$")
	    public static void load_EDD_dataSet() throws IOException,ClassNotFoundException, SQLException {
	        DBUtils.convertDBtoMap("eddquery");
	    }

	 
	 @Then("^EDD Reviewer : Validate Field '(.+)'$")
	 
		public  void validate_field_usingCSV(String FieldName) throws Throwable{

			logger.info("Going to switch into frame");

			switchFrame();

			logger.info("Frame switched successfully");

			BaseProject.propertiesFilename = "EDDReviewer";
			CommonUtilsData.FieldNameData = FieldName; 
			String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"EDDReviewer.csv");
			try{

				if(!(Fieldval[0]).equalsIgnoreCase(null)){
					logger.info("Field validation starts"); 
					CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
				}
			}
			catch(Exception E){

				logger.info("Field : "+FieldName+" is not present in Datamodel");
			}   
		}
		/*public  void validateFieldStep(String FieldName) throws IOException, InterruptedException{
			
			//wrap.wait(1000);
			
			//logger.info("Going to scroll");
			
			//innerScroll();

			//switchFrame();
		 	BaseProject.propertiesFilename="EDDReviewer";
			CommonUtilsData.FieldNameData = FieldName;
			
			CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","EDDReviewer");
			
			try{
				
				if(!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)){
				
					CommonUtils.validateField(
	                        CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
	                        CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
	          			  CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));
	    
	    }
	}

	catch(Exception E){
	    
	    logger.info("Field : "+FieldName+" is not present in Datamodel");
	}             

	}*/
	 
	 @Then("^EDD Reviewer :Click on '(.+)' tab$")
     public void click_on_tab(String tabName)
     {
            wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
            try {
                if(tabName.equalsIgnoreCase("Customer Details"))
                {
                      JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                      jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer", "CustomerDetails_Tab"))); 
                      wrap.click(driver, com.getElementProperties("EDDReviewer", "CustomerDetails_Tab"));
                }
                else if(tabName.equalsIgnoreCase("Product Details"))
                {	
                	JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                    jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer", "ProductDetails_Tab")));
                    wrap.click(driver, com.getElementProperties("EDDReviewer", "ProductDetails_Tab"));
                }
                else if (tabName.equalsIgnoreCase("Application Details"))
                {	
                	  JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                      jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer", "ApplicationDetails_Tab")));
                      wrap.click(driver, com.getElementProperties("EDDReviewer", "ApplicationDetails_Tab"));
                } else
                {
                	  JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                      jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer", "Documents_Tab")));
                      wrap.click(driver, com.getElementProperties("EDDReviewer", "Documents_Tab"));
                }
                     
                         
            } catch (InterruptedException |IOException e) {
                   logger.error("unable to click on "+tabName +"tab"+ e);
                   Assert.fail();
            } 
            
     }


	 //Updated on 1 Feb 2018
	 @When("^EDD Reviewer :validate prefilled values in customer details tab")
	    public void validate_prefilled_customer_details_tab()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Full_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("Date_of_Birth", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MaritalStatus"), DBUtils.readColumnWithRowID("Marital_Status", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_EducationalQualification"), DBUtils.readColumnWithRowID("Educational_Qualification", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PlaceofBirth"), DBUtils.readColumnWithRowID("Place_of_Birth", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryOfBirth"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ResidenceCountry"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AreyoufromJ&KMeghalayaorAssam"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ConstitutionCode"), DBUtils.readColumnWithRowID("Constitution_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ResidentialStatus"), DBUtils.readColumnWithRowID("Residential_Status", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_BureauConsentFlag"), DBUtils.readColumnWithRowID("Bureau_Consent_Flag", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NoofDependants"), DBUtils.readColumnWithRowID("No_of_Dependants", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ConnectedLendingRelationship"), DBUtils.readColumnWithRowID("connected_Lending_Relationship", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ClientType"), DBUtils.readColumnWithRowID("Client_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CustomerDemiseDate"), DBUtils.readColumnWithRowID("CustomerDemiseDate", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AuthenticationMode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AliasType"), DBUtils.readColumnWithRowID("Alias_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AliasFirstName"), DBUtils.readColumnWithRowID("Alias_First_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AliasMiddleName"), DBUtils.readColumnWithRowID("Alias_Middle_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AliasLastName"), DBUtils.readColumnWithRowID("Alias_Last_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AliasFullName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ContactClassification"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("Contact_type_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Contact_Details", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ISDCode"), DBUtils.readColumnWithRowID("ISD_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PreferredContact"), DBUtils.readColumnWithRowID("Preferred_Contact1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Address1_Address_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ResidenceType"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Address1_Address_Line_1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address1_Address_Line_2", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address1_Address_Line_3", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AddressLine4"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Address1_City", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Address1_Country", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Address1_Zip_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Address1_State", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Area"), DBUtils.readColumnWithRowID("Address1_Area", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Lengthatcurrentaddress"), DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_YY", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CustomerMailingAddressIndicator"), DBUtils.readColumnWithRowID("Address1_Mailing_Address_Indicator", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PermanentAddresssameasResidentialAddress"), DBUtils.readColumnWithRowID("Address1_Permanent_Address_same_as_Residential_Address", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PreferredLanguage"), DBUtils.readColumnWithRowID("Preferred_Language", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AdviceDetailsAddressType"), DBUtils.readColumnWithRowID("Advice_Detail_Address_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MarketingPreferences"), DBUtils.readColumnWithRowID("Marketing_Preferences", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Occupation"), DBUtils.readColumnWithRowID("Occupation_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ISIC"), DBUtils.readColumnWithRowID("ISIC_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PayrollIndicator"), DBUtils.readColumnWithRowID("Payroll_Indicator", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_WorkType"), DBUtils.readColumnWithRowID("Work_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_DomicileCountry"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CorporateID"), DBUtils.readColumnWithRowID("Corporate_ID", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NatureOfBusiness"), DBUtils.readColumnWithRowID("Nature_Of_Business", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_EmployerName"), DBUtils.readColumnWithRowID("Employer_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Department"), DBUtils.readColumnWithRowID("Department", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_SalaryMode"), DBUtils.readColumnWithRowID("Salary_Mode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Previousemployername"), DBUtils.readColumnWithRowID("Previous_employer_name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Designation"), DBUtils.readColumnWithRowID("Designation", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_DeclaredIncome"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NoofMonthsinCurrentbusinessOrganization"), DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NoofMonthsinPreviousbusinessOrganization"), DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_TotalWorkExperience"), DBUtils.readColumnWithRowID("Total_work_experience", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CustomerType"), DBUtils.readColumnWithRowID("Customer_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_SpecificStatus"), DBUtils.readColumnWithRowID("Specific_status", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NorkomName "), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PANNumber"), DBUtils.readColumnWithRowID("PAN", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_PanStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Nationalities/Citizenships"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CRSIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryCDDperformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_IsCDDdeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_IsCountryCDDdeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryCDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryCDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDNextReviewDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AssignedReasonCodes"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDApproverName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_ComplianceApproverName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_SegmentHeadApproverName "), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_OATRiskRating"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AvailabilityofCustomerSignature"), DBUtils.readColumnWithRowID("Availability_of_Customer_Signature", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_NoOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_AmountOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Verificationrequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_FATCAIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_CDDIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       
	                        
	}
	 //Updated on 1 Feb 2018
	 @When("^EDD Reviewer :validate prefilled values in product details tab")
	    public void validate_prefilled_product_details_tab()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_Promotion/CampaignCode"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ProductCategory"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_DepositType"), DBUtils.readColumnWithRowID("Deposit_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ProductCode"), DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_BundleIndicator"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AcquisitionorUsageindicator"), DBUtils.readColumnWithRowID("AcquisitionUsage", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RequestedAmount"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RequestedTenure"), DBUtils.readColumnWithRowID("Requested_Tenure", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_PurposeOfLoan"), DBUtils.readColumnWithRowID("Purpose_of_Loan", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_Term"), DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_TenureType"), DBUtils.readColumnWithRowID("Tenure_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_FundAccountChoice"), DBUtils.readColumnWithRowID("Fund_Account_Choice", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ChequeNumber"), DBUtils.readColumnWithRowID("Cheque_Number", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ChequeDate"), DBUtils.readColumnWithRowID("Cheque_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ChequeDrawnon"), DBUtils.readColumnWithRowID("Cheque_Drawn_On", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_Amount"), DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AssessmentType"), DBUtils.readColumnWithRowID("Assessment_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_PreferredLimit"), DBUtils.readColumnWithRowID("Preferred_Limit", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AccountCurrency"), DBUtils.readColumnWithRowID("Account_Currency_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_TermdepositonsecuredCCvalue"), DBUtils.readColumnWithRowID("Term_deposit_on_secured_CC_value", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ProductAddressType"), DBUtils.readColumnWithRowID("Product_address_type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AccountRequestType"), DBUtils.readColumnWithRowID("Account_Request_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_OperatingInstruction"), DBUtils.readColumnWithRowID("Operating_Instruction", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AccountShortName"), DBUtils.readColumnWithRowID("Account_Short_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_DepositAmount"), DBUtils.readColumnWithRowID("Deposit_Amount", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_FundAccountNo"), DBUtils.readColumnWithRowID("Fund_Account_No", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_FundAccountName"), DBUtils.readColumnWithRowID("Fund_Account_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_FundAccountCurrency"), DBUtils.readColumnWithRowID("Fund_Account_Currency", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RollOverChoice"), DBUtils.readColumnWithRowID("Roll_Over_Choice", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RollOverInstruction"), DBUtils.readColumnWithRowID("Roll_Over_Instruction", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RepaymentMode"), DBUtils.readColumnWithRowID("Payment_Mode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_InterestFrequency"), DBUtils.readColumnWithRowID("Interest_Frequency", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_Lien"), DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_MaturityDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AccountCurrency"), DBUtils.readColumnWithRowID("Account_Currency_Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RepaymentMode"), DBUtils.readColumnWithRowID("Repayment_mode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_RepaymentAccountType"), DBUtils.readColumnWithRowID("Repayment_Account_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AccountNumber"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_DebitType"), DBUtils.readColumnWithRowID("Debit_Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AutoDebitAmount"), DBUtils.readColumnWithRowID("Auto_Debit_Amount", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_Frequency"), DBUtils.readColumnWithRowID("Frequency", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_EffectiveDate"), DBUtils.readColumnWithRowID("Effective_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_BillingCycle"), DBUtils.readColumnWithRowID("Billing_Cycle", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_CCEmbossName"), DBUtils.readColumnWithRowID("CC_Emboss_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_ConsolidatedFlag"), DBUtils.readColumnWithRowID("Consolidated_Flag", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_StatementFlag"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_UserCode2"), DBUtils.readColumnWithRowID("User_Code2", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_LezCode"), DBUtils.readColumnWithRowID("LezCode", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_FDFundingYN"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code_Prd", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value_Prd", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_DisbursementMode"), DBUtils.readColumnWithRowID("Disbursement_mode", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_BeneficiaryName"), DBUtils.readColumnWithRowID("Beneficiary_Name", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_BeneficiarysBank"), DBUtils.readColumnWithRowID("Beneficiarys_Bank", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_BeneficiaryACNumber"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_AdvanceEMI"), DBUtils.readColumnWithRowID("Advance_EMI", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_PurposeofAccountOpening"), DBUtils.readColumnWithRowID("Purpose_of_account_opening", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ProductDetailsTab_OperatingInstruction"), DBUtils.readColumnWithRowID("Operating_Instruction", BaseProject.scenarioID));
	       	 
	}
	 
	 
	
	 
	//Updated on 1 Feb 2018
	 @When("^EDD Reviewer :validate prefilled values in application details tab")
	    public void validate_prefilled_application_details_tab()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_ApplicationCreatedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_AOFDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_SourcingID"), DBUtils.readColumnWithRowID("Sourcing_ID", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_ReferralID"), DBUtils.readColumnWithRowID("Referral_ID", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_AcquisitionChannel"), DBUtils.readColumnWithRowID("Acquisition_Channel", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_ApplicationBranch"), DBUtils.readColumnWithRowID("Application_Branch", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_HomeBranch"), DBUtils.readColumnWithRowID("Home_Branch", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_ClosingID"), DBUtils.readColumnWithRowID("Closing_ID", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_RefereeRelationship"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_SegmentCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_Fund"), DBUtils.readColumnWithRowID("Fund", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_SourcingChannel"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_CountryOfAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_PhotoMatchWithIDAndAof"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_SignAcrossPhoto"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_SourceChannel"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_InstitutionClassificationCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "ApplicationDetailsTab_ServiceIndicatorCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       
	}


	//Updated on 1 Feb 2018
	 @When("^EDD Reviewer :validate prefilled values in document details tab")
	    public void validate_prefilled_document_details_tab()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Document_Category", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Name_of_the_Document", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Document_Number", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Document_Signatory_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Document_Expiry_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_IsDocumentAvailable"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countryies_of_Tax_Residence", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_IsExistingDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "DocumentsTab_DocumentReceiveDate"), DBUtils.readColumnWithRowID("Document_Receive_Date", BaseProject.scenarioID));
	       
	}
	 

	 @When("^EDD Reviewer :Click OK alert message")
	    public void click_ok_alert_message(){
	       
	       Wrapper.switch_to_alert_dismiss("accept");
	}
	 
	 @When("^EDD Reviewer :Validate error message for the field(.*)")
	    public void validate_error_message_for_the_field(String fieldName) throws IOException, InterruptedException{
		 String expectedError = "Value cannot be blank";
		 String actualError = null;
		 
		 if(fieldName.contains("CDD Performed")){
			 JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_CDD_Performed_Error_Message")));
		      actualError=Wrapper.getTextValue(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_CDD_Performed_Error_Message"));	 
		}
		 
		 if(fieldName.contains("Country CDD Performed")){
			 JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Country_CDD_Performed_Error_Message")));
		      actualError=Wrapper.getTextValue(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Country_CDD_Performed_Error_Message"));	 
		}
		
			if(fieldName.contains("Verification Required")){
				 JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Verification_Required_Error_Message")));
			      actualError=Wrapper.getTextValue(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Verification_Required_Error_Message"));	 
			}
		
	     
	     System.out.println("Expected error message is = "+expectedError);
	     System.out.println("Actual error message is = "+actualError);
	     Assert.assertEquals(expectedError, actualError);
	    
	}
	 

	 @Then("^EDD Reviewer :Click on Co-Applicant tab$")
     public void click_on_coApplicant_tab( ) throws InterruptedException, IOException
     {
		 wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
         JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Co-Applicant1Tab")));       
         wrap.click(driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Co-Applicant1Tab"));
                   
                         
      }
	 
	 //Updated on 1 Feb 2018
	 
	 @When("^EDD Reviewer :validate prefilled values in customer details tab Co-Applicant1")
	    public void validate_prefilled_customer_details_tab_coApplicant1()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Coapplicant1_Title", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("Coapplicant1_First_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Coapplicant1_Middle_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Coapplicant1_Last_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Full_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("Coapplicant1_DOB", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Coapp1_Gender", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MaritalStatus"), DBUtils.readColumnWithRowID("Coapp1_Marital_Status", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_EducationalQualification"), DBUtils.readColumnWithRowID("Coapp1_Educational_Qualification", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PlaceofBirth"), DBUtils.readColumnWithRowID("Place_of_Birth", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryOfBirth"), DBUtils.readColumnWithRowID("Coapplicant1_Country_Of_Birth_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ResidenceCountry"), DBUtils.readColumnWithRowID("Coapplicant1_Residence_Country_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Coapplicant1_Nationality_Code1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AreyoufromJ&KMeghalayaorAssam"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ConstitutionCode"), DBUtils.readColumnWithRowID("Constitution_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ResidentialStatus"), DBUtils.readColumnWithRowID("Residential_Status", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_BureauConsentFlag"), DBUtils.readColumnWithRowID("Bureau_Consent_Flag", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_NoofDependants"), DBUtils.readColumnWithRowID("No_of_Dependants", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ConnectedLendingRelationship"), DBUtils.readColumnWithRowID("connected_Lending_Relationship", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ClientType"), DBUtils.readColumnWithRowID("Coapplicant1_Client_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CustomerDemiseDate"), DBUtils.readColumnWithRowID("CustomerDemiseDate", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AuthenticationMode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AliasType"), DBUtils.readColumnWithRowID("Coapplicant1_Alias_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AliasFirstName"), DBUtils.readColumnWithRowID("Coapplicant1_Alias_First_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AliasMiddleName"), DBUtils.readColumnWithRowID("Coapplicant1_Alias_Middle_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AliasLastName"), DBUtils.readColumnWithRowID("Coapplicant1_Alias_Last_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AliasFullName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ContactClassification"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("Coapplicant1_Contact_type_Code1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Coapplicant1_Contact_Details1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ISDCode"), DBUtils.readColumnWithRowID("Coapplicant1_ISD_Code1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PreferredContact"), DBUtils.readColumnWithRowID("Preferred_Contact1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Coapp1_Address_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ResidenceType"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Coapp1_Address_Line", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address1_Address_Line_2", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address1_Address_Line_3", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine4"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Coapp1_City", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Coapp1_Country", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Coapp1_Zip_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Coapp1_State", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Area"), DBUtils.readColumnWithRowID("Address1_Area", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Lengthatcurrentaddress"), DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_YY", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MailingAddressIndicator"), DBUtils.readColumnWithRowID("Address1_Mailing_Address_Indicator", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PermanentAddresssameasResidentialAddress"), DBUtils.readColumnWithRowID("Address1_Permanent_Address_same_as_Residential_Address", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PreferredLanguage"), DBUtils.readColumnWithRowID("Preferred_Language", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AdviceDetailsAddressType"), DBUtils.readColumnWithRowID("Advice_Detail_Address_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MarketingPreferences"), DBUtils.readColumnWithRowID("Coapp1_Marketing_Preferences", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Occupation"), DBUtils.readColumnWithRowID("Coapplicant1_Occupation_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ISIC"), DBUtils.readColumnWithRowID("Coapplicant1_ISIC", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PayrollIndicator"), DBUtils.readColumnWithRowID("Payroll_Indicator", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_WorkType"), DBUtils.readColumnWithRowID("Work_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_NatureOfBusiness"), DBUtils.readColumnWithRowID("Nature_Of_Business", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CustomerType"), DBUtils.readColumnWithRowID("Coapp1_Customer_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_SpecificStatus"), DBUtils.readColumnWithRowID("Coapp1_Specific_status", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_NorkomName "), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PANNumber"), DBUtils.readColumnWithRowID("PAN", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_PanStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Nationalities/Citizenships"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CRSIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDperformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsCDDdeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsCountryCDDdeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDNextReviewDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AssignedReasonCodes"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDApproverName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_ComplianceApproverName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_SegmentHeadApproverName "), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_OATRiskRating"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AvailabilityofCustomerSignature"), DBUtils.readColumnWithRowID("Availability_of_Customer_Signature", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("Coapp1_MIS_Code1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("Coapp1_MIS_Value1", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_NoOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_AmountOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_Verificationrequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_FATCAIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDIDDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		              
	       
	}
	 
	 //Updated on 1 Feb 2018
	 @When("^EDD Reviewer :validate prefilled values in document details tab Co-Applicant1")
	    public void validate_prefilled_document_details_tab_coApplicant1()
	            throws Throwable {
	       
	       switchFrame();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Coapplicant1_Document_Category1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Coapplicant1_Name_of_the_Document1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Coapplicant1_Document_Number1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Coapplicant1_Document_Signature_Date1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Coapplicant1_Document_Expiry_Date1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_IsDocumentAvailable"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countryies_of_Tax_Residence", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_IsExistingDocument"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));
	     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant1_DocumentsTab_DocumentReceiveDate"), DBUtils.readColumnWithRowID("Document_Receive_Date", BaseProject.scenarioID));
	       
	}
	 
	//Updated on 1 Feb 2018
	 @Then("^EDD Reviewer :Click on Co-Applicant2 tab$")
     public void click_on_coApplicant2_tab( ) throws InterruptedException, IOException
     {
            wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
            JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","CustomerDetailsTab_Co-Applicant2Tab")));       
            wrap.click(driver, com.getElementProperties("EDDReviewer", "CustomerDetailsTab_Co-Applicant2Tab"));
                   
                         
      }

	 
		//Added on 01 Feb 2018
	 @And("^EDD Reviewer :connect to DB and fetch v_RTOB_TestData dataset$")
	    public static void connect_RTOB_testData() throws IOException,ClassNotFoundException, SQLException {
	        DBUtils.convertDBtoMap("testdataquery");
	 }   
	 
	 
	//Added on 1 Feb 2018
	 
		 @When("^EDD Reviewer :validate prefilled values in customer details tab Co-Applicant2")
		    public void validate_prefilled_customer_details_tab_coApplicant2()
		            throws Throwable {
		       
		       switchFrame();
		       
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Customer_Name", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Address2_Address_Type", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Address2_Address_Line1", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address2_Address_Line2", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address2_Address_Line3", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Address2_State", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Address2_City", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Address2_Zip_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Address2_Country", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MailingAddressIndicator"), DBUtils.readColumnWithRowID("Address2_Mailing_Address_Indicator", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("COntact_type_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Contact_Details", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code2", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsIndicateOfSanctionedCountry"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_NTBNonResidentIndividuals"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsBusinessPurpose"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ClientWishesAnonymity"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsAUMCriteria"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_DeticaResponse"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_OtherRiskFactors"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsAlreadyEDDMEDD"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ListOfProductsOpened"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsCDDDeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryCDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_VerificationRequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_NorkomName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		     //wrap.validatevalue(BaseProject.driver, com.getElementProperties("EDDReviewer", "Co-Applicant2_CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));       
		       
		}
		 
		 //Added on 1 Feb 2018
		 @When("^EDD Reviewer :validate prefilled values in document details tab Co-Applicant2")
		    public void validate_prefilled_document_details_tab_coApplicant2()
		            throws Throwable {
		       
		       switchFrame();
		       
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Coapplicant2_Document_Category", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Coapplicant2_Name_of_the_Document", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Coapplicant2_Document_Number", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Coapplicant2_Document_Expiry_Date", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Coapplicant2_Document_Signatory_Date", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countries_of_Tax_Residence", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_CRSReasonCode"), DBUtils.readColumnWithRowID("CRS_Reason_Code", BaseProject.scenarioID));
		       wrap.validatevalue(BaseProject.driver, com.getElementProperties("CDDReviewer", "Co-Applicant2_DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));
		       
		}
		 
		 //Added on 9 th Feb
		 
		 @Then("^EDD Reviewer : Click on Release button$")
		 public void click_on_release() throws InterruptedException, IOException
		 {
			 JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			 jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("EDDReviewer","Release")));
			 wrap.click(driver, com.getElementProperties("EDDReviewer","Release"));
			 wrap.wait(5000);
		 }
}
