package com.scb.rtob.module.test.utils;

import java.io.File;
import java.io.FileInputStream;

import com.scb.rtob.module.test.framework.*;
import com.scb.rtob.module.test.utils.CommonUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.scb.rtob.module.test.framework.glue.DocumentIndexing;
import com.scb.rtob.module.test.framework.glue.BaseProject;

public class DCOReader {
	
	private static Logger logger = Logger.getLogger(DCOReader.class);
	
	static Commons com = new Commons();
	static Wrapper wrap = new Wrapper();
	
	public static void main(String[] args) throws IOException, InterruptedException{
		
		logger.info("count :"+ CommonUtils.rowCount);
		
		readDCO("BasicdataTest");
		
	}
	
	public static void readDCO(String sheet) throws IOException, InterruptedException{
		
		System.out.println("inside readDCO");
		
		CommonUtils.convertExcelToMap("C:"+File.separator+"Users"+File.separator+"1559556"+File.separator+"Desktop"+File.separator+"New folder", "DCO.xls", sheet);
		
		logger.info("count :"+ CommonUtils.rowCount);
		
		for(int i=0;i<CommonUtils.rowCount-1;i++){
		//for(int i=0;i<2;i++){
			
			System.out.println("Length : "+CommonUtils.readColumn("Length", i));
			
			DCOValidations(CommonUtils.mydata.get(i));
			
		}
		
	}
	
	public static void DCOValidations(Map <String,String> map) throws IOException, InterruptedException{
		
		System.out.println(map.get("Data Type"));
		
		switch(map.get("Data Type"))
		{
			case "Dropdown":
				validateDropdown(map);
				break;
			
			case "Free Text":
				validateFreeText(map);
				break;
				
			case "Calendar":
				validateCalendar(map);
				break;
		}
		
	}
	
	public static void validateDropdown(Map <String,String> Dmap){
		
		System.out.println(Dmap.get("Field Name"));
		
		String xpathGen = "//label[contains(.,'"+Dmap.get("Field Name")+"')]/following-sibling::div/select";
		
		System.out.println("xpath : "+xpathGen);
		
		}
	
	public static void validateFreeText(Map <String,String> Fmap) throws IOException, InterruptedException{
		
		String xpathGen = "//label[contains(.,'"+Fmap.get("Field Name")+"')]/following-sibling::div/span/input";
		
		System.out.println("xpath : "+xpathGen);
		
		/*com.validateAlphaNumeric(ProductCatalogue.driver, xpathGen, "123abcdef456");
		com.validateDataLength(ProductCatalogue.driver, xpathGen, "123abcdef456123abcdef456123abcdef456123abcdef456", Fmap.get("Length").replaceAll(""+File.separator+".0*$", ""));
		com.validateErrorMessage(ProductCatalogue.driver, xpathGen, Fmap.get("M/O/C"));*/
		
		System.out.println("Done validations");
			
		}

	public static void validateCalendar(Map <String,String> Cmap){
		
		String xpathGen = "//label[contains(.,'"+Cmap.get("Field Name")+"')]/following-sibling::div/span/input";
		
		System.out.println("xpath : "+xpathGen);
		
	}

}
