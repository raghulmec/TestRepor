package com.scb.rtob.module.test.framework.glue;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;






//import junit.framework.Assert;
import org.junit.Assert;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;
//import com.scb.rtob.module.test.utils.ExcelUtil;
import com.scb.rtob.module.test.framework.XMLParser;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.formatter.model.Feature;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


public class DocumentIndexing {

    public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60, 1000);
    static Wrapper wrap = new Wrapper();
    static Commons com = new Commons();
    static BlindData bdata = new BlindData();
    static CsvReaderutil csvread = new CsvReaderutil();
    private static String[] scenarioParts;
    XMLParser xmlParser = new XMLParser();
    CommonUtils commonUtils = new CommonUtils();
    private static Logger logger = Logger.getLogger(DocumentIndexing.class);
    
    Map<String, List<String>> tableMap = new HashMap<String, List<String>>();
    ArrayList<String> DocCategory = new ArrayList<String>();
	public ArrayList<String> TargetDoc = new ArrayList<String>();

    public static void waitUntilVisibilityOfWebElement(WebElement elem) {
        wait.until(ExpectedConditions.visibilityOf(elem));
    }

    @Before(order = 2, value = {"@DI"})
    public void beforeDI(Scenario scenario) {
        logger.info("inside DI before");
        String scen[] = scenario.getName().split("_");
        BaseProject.scenarioID = scen[1];
        logger.info("@Before - BaseProject.scenarioID : " + BaseProject.scenarioID);
    }

    @After(order = 2, value = {"@DI"})
    public void afterDI(Scenario scenario) {
        System.out.println("DI After");
    }

    
    @Given("^DI: Go to Document Indexing home page$")
    public void go_to_Document_Indexing_home_page() throws Throwable {


        DBUtils.convertDBtoMap("diquery");

        wrap.switch_to_default_Content(BaseProject.driver);


        try {
            wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
            wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));
            wrap.wait(1000);
            wrap.getWorkbasketoption(BaseProject.driver, "Document Indexing");
            wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));

        } catch (Exception e) {

            e.printStackTrace();
            Assert.fail();

        }

    }
    

   
    @Then("^DI: select an application number$")
    public static void select_an_application_number()
            throws IOException, InterruptedException, ClassNotFoundException, SQLException {

	       /*DBUtils.convertDBtoMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
           String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);*/
        wrap.wait(5000);

        String appId = DBUtils.readColumnWithRowID("ApplicationID_DI", BaseProject.scenarioID);

        BaseProject.appId = appId.trim();

        logger.info("The Value going to select or Filter is [" + appId + "]");
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
        wrap.wait(2000);
        String filter = com.getElementProperties("Fulldatacapturemaker",
                "filter_link");
        String search = com.getElementProperties("Fulldatacapturemaker",
                "search_text");
        String applyButton = com.getElementProperties("Fulldatacapturemaker",
                "apply_button");
        wrap.wait(2000);
        wrap.click(BaseProject.driver, filter);
        wrap.wait(1000);
        wrap.typeToTextBox(BaseProject.driver, appId, search);
        wrap.wait(1000);
        wrap.click(BaseProject.driver, applyButton);

        wrap.wait(3000);

	      /* WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
           ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);*/
        BlindData.switchFrame();

        wrap.wait(3000);

        try {
            BaseProject.driver.findElement(By.xpath("//div[@id='HARNESS_CONTENT']//table/tbody/tr[1]/td/div/table/tbody/tr[2]/td/div/span[text()='" + appId + "']")).click();
        } catch (Exception e) {
            BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
        }


    }


    @Then("^Classification link is clickable$")
    public void verifyEClassify() throws IOException {
        try {
            logger.info(wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_Eclassification_link1")));
            if (wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_Eclassification_link1"))) {
                logger.info("E-Classification link is clickable");
            }
        } catch (Exception E) {
            logger.info("E-Classification link is not clickable");
        }
    }

   

    @Then("^Save,submit,Other Actions buttons are enabled && clickable$")
    public void save_submit_other_actions_buttons_are_enabled_clickable() throws IOException {
        try {
            Assert.assertEquals(true, wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_Save_button")));
            Assert.assertEquals(true, wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_submit_button")));
            Assert.assertEquals(true, wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_Otheractions_button")));
            logger.info("Save, submit and Action buttons are available");
        } catch (Exception E) {
            logger.info("Verifying Save,Submit & Other action failed");
        }
		

    }


    @Then("^close,Cancel buttons are disabled && clickable$")
    public void close_cancel_buttons_are_disabled_clickable() throws IOException {
        try {
            if (!wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_Close_button")) &&
                    !wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_cancel_button"))) {
                logger.info("close, cancel buttons are disabled");
            }
			/*Assert.assertEquals(true, wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_Close_button")));
			Assert.assertEquals(true, wrap.isElementEnabled(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_cancel_button")));*/
            else {
                logger.info("close, cancel buttons are not disabled");
            }
        } catch (Exception E) {
            logger.info("Failing to verify close and cancel buttons");
        }

    }

   

    @Given("^The user clicks on Classification link$")
    public void click_on_classification_link() throws IOException, InterruptedException {

        JavascriptExecutor jsExecutor = (JavascriptExecutor) BaseProject.driver;
        logger.info(jsExecutor.executeScript("return self.name"));
        String currentFrame = (String) jsExecutor.executeScript("return self.name");

        
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        try {
            wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_Eclassification_link1"));
            logger.info("clicked E-Classification link");
        } catch (Exception E) {
            logger.info("not able to click E-Classification link");
        }
        try {
        	if(BaseProject.envmap.get("browser").equalsIgnoreCase("ie")){
        		BaseProject.driver.navigate().to("javascript:document.getElementById('overridelink').click()");
        	}

        } catch (Exception E) {
            logger.info("No Certificate error");
        }
        try {
            wrap.wait(5000);
            wrap.switchToWindow(BaseProject.driver, "eClassifier");
            logger.info("switched to eClassifier");
        } catch (Exception E) {
            logger.info("window not switched");
        }
    }

    @Then("^verify Add row button is displayed$")
    public void verifyAddRowButton() throws IOException, InterruptedException {
        try {
			/*Assert.assertEquals(true,wrap.isElementPresent(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow")));*/
            logger.info(wrap.isElementPresent(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow")));
        } catch (Exception E) {
            logger.info("Add Row button is not available");
        }
    }

    /* Updated with DB details */
    
    
    @Then("^verify LOV values under DocCategory and TargetDocType$")
    public void verify_lov_values_under_doccategory_and_targetdoctype() throws IOException, InterruptedException
    {
    	wrap.wait(2000);
    	String DI_eClassify_DocumentCategory = com.getElementProperties("DI", "DI_eClassify_DocumentCategory");
    	String DI_eClassify_DocumentCategory_Dropdown = com.getElementProperties("DI", "DI_eClassify_DocumentCategory_Dropdown");
    	String DI_eClassify_TargetDocumentType = com.getElementProperties("DI", "DI_eClassify_TargetDocumentType");
    	String DI_eClassify_TargetDocumentType_Dropdown = com.getElementProperties("DI", "DI_eClassify_TargetDocumentType_Dropdown");
    	
    	wrap.click(BaseProject.driver, DI_eClassify_DocumentCategory_Dropdown);
    	List<WebElement> DocCat = BaseProject.driver.findElements(By.xpath(DI_eClassify_DocumentCategory));
    	int DocSizeValue = DocCat.size();
    	
    	
    	try {
    			//Document category list verification 
                 csvread.Read_DIvalues_from_CSV("Document Category",DI_eClassify_DocumentCategory,"DocumentIndexing.csv");
                 
                // Target Document Type list verification                 
                 for(int i=2; i <= DocCat.size()-1; i++){
                	 logger.info("For loop starting ");
                	 //wrap.click(BaseProject.driver, DI_eClassify_DocumentCategory_Dropdown);
                	 String DocCategory = "//*[@id='targetDocumentCatgy0_popup']/div["+i+"]";
                 	wrap.click(BaseProject.driver, DocCategory);
                 	wrap.wait(2000);
                 	wrap.click(BaseProject.driver, DI_eClassify_TargetDocumentType_Dropdown);
                 	wrap.wait(2000);
                	csvread.Read_DIvalues_from_CSV("Document Name",DI_eClassify_TargetDocumentType,"DocumentIndexing.csv");
                	wrap.click(BaseProject.driver, DI_eClassify_DocumentCategory_Dropdown);
                	wrap.wait(1000);
                	logger.info("For loop ending ");
                 }
                 
                 logger.info("Document Size: "+DocSizeValue);


           } catch (Throwable e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
           }
    }
    
        

    public void userSplitsDocsAccordingBarcode(String id1, String id2, int j) throws IOException, InterruptedException {
    	
    	// Primary

    	String primaryDocCategory1 = DBUtils.readColumnWithRowID("PrimaryDocCategory1", BaseProject.scenarioID);    	
    	String primaryTargetDocType1 = DBUtils.readColumnWithRowID("PrimaryTargetDocType1", BaseProject.scenarioID);
    	String primaryDocCategory2 = DBUtils.readColumnWithRowID("PrimaryDocCategory2", BaseProject.scenarioID);
    	String primaryTargetDocType2 = DBUtils.readColumnWithRowID("PrimaryTargetDocType2", BaseProject.scenarioID);
    	String primaryDocCategory3 = DBUtils.readColumnWithRowID("PrimaryDocCategory3", BaseProject.scenarioID);
    	String primaryTargetDocType3 = DBUtils.readColumnWithRowID("PrimaryTargetDocType3", BaseProject.scenarioID);
    	String primaryDocCategory4 = DBUtils.readColumnWithRowID("PrimaryDocCategory4", BaseProject.scenarioID);
    	String primaryTargetDocType4 = DBUtils.readColumnWithRowID("PrimaryTargetDocType4", BaseProject.scenarioID);
    	String primaryDocCategory5 = DBUtils.readColumnWithRowID("PrimaryDocCategory5", BaseProject.scenarioID);
    	String primaryTargetDocType5 = DBUtils.readColumnWithRowID("PrimaryTargetDocType5", BaseProject.scenarioID);
    	String primaryDocCategory6 = DBUtils.readColumnWithRowID("PrimaryDocCategory6", BaseProject.scenarioID);
    	String primaryTargetDocType6 = DBUtils.readColumnWithRowID("PrimaryTargetDocType6", BaseProject.scenarioID);
    	String primaryDocCategory7 = DBUtils.readColumnWithRowID("PrimaryDocCategory7", BaseProject.scenarioID);
    	String primaryTargetDocType7 = DBUtils.readColumnWithRowID("PrimaryTargetDocType7", BaseProject.scenarioID);
    	String primaryDocCategory8 = DBUtils.readColumnWithRowID("PrimaryDocCategory8", BaseProject.scenarioID);
    	String primaryTargetDocType8 = DBUtils.readColumnWithRowID("PrimaryTargetDocType8", BaseProject.scenarioID);
    	String primaryDocCategory9_1 = DBUtils.readColumnWithRowID("PrimaryDocCategory9_1", BaseProject.scenarioID);
    	String primaryTargetDocType9_1 = DBUtils.readColumnWithRowID("PrimaryTargetDocType9_1", BaseProject.scenarioID);
    	String primaryDocCategory9_2 = DBUtils.readColumnWithRowID("PrimaryDocCategory9_2", BaseProject.scenarioID);
    	String primaryTargetDocType9_2 = DBUtils.readColumnWithRowID("PrimaryTargetDocType9_2", BaseProject.scenarioID);
    	String primaryDocCategory9_3 = DBUtils.readColumnWithRowID("PrimaryDocCategory9_3", BaseProject.scenarioID);
    	String primaryTargetDocType9_3 = DBUtils.readColumnWithRowID("PrimaryTargetDocType9_3", BaseProject.scenarioID);
    	String primaryDocCategory9_4 = DBUtils.readColumnWithRowID("PrimaryDocCategory9_4", BaseProject.scenarioID);
    	String primaryTargetDocType9_4 = DBUtils.readColumnWithRowID("PrimaryTargetDocType9_4", BaseProject.scenarioID);
   	
    	// Co-Applicant 1     	
    	String coApplicant1DocCategory1 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory1", BaseProject.scenarioID);    	
    	String coApplicant1TargetDocType1 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType1", BaseProject.scenarioID);
    	String coApplicant1DocCategory2 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory2", BaseProject.scenarioID);
    	String coApplicant1TargetDocType2 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType2", BaseProject.scenarioID);
    	String coApplicant1DocCategory3 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory3", BaseProject.scenarioID);
    	String coApplicant1TargetDocType3 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType3", BaseProject.scenarioID);
    	String coApplicant1DocCategory4 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory4", BaseProject.scenarioID);
    	String coApplicant1TargetDocType4 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType4", BaseProject.scenarioID);
    	String coApplicant1DocCategory5 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory5", BaseProject.scenarioID);
    	String coApplicant1TargetDocType5 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType5", BaseProject.scenarioID);
    	String coApplicant1DocCategory6 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory6", BaseProject.scenarioID);
    	String coApplicant1TargetDocType6 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType6", BaseProject.scenarioID);
    	String coApplicant1DocCategory7 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory7", BaseProject.scenarioID);
    	String coApplicant1TargetDocType7 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType7", BaseProject.scenarioID);
    	String coApplicant1DocCategory8 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory8", BaseProject.scenarioID);
    	String coApplicant1TargetDocType8 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType8", BaseProject.scenarioID);
    	String coApplicant1DocCategory9_1 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory9_1", BaseProject.scenarioID);
    	String coApplicant1TargetDocType9_1 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType9_1", BaseProject.scenarioID);
    	String coApplicant1DocCategory9_2 = DBUtils.readColumnWithRowID("CoApplicant1DocCategory9_2", BaseProject.scenarioID);
    	String coApplicant1TargetDocType9_2 = DBUtils.readColumnWithRowID("CoApplicant1TargetDocType9_2", BaseProject.scenarioID);
    	
    	// Co-Applicant 2
    	String coApplicant2DocCategory1 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory1", BaseProject.scenarioID);
    	String coApplicant2TargetDocType1 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType1", BaseProject.scenarioID);
    	String coApplicant2DocCategory2 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory2", BaseProject.scenarioID);
    	String coApplicant2TargetDocType2 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType2", BaseProject.scenarioID);
    	String coApplicant2DocCategory3 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory3", BaseProject.scenarioID);
    	String coApplicant2TargetDocType3 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType3", BaseProject.scenarioID);
    	String coApplicant2DocCategory4 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory4", BaseProject.scenarioID);
    	String coApplicant2TargetDocType4 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType4", BaseProject.scenarioID);
    	String coApplicant2DocCategory5 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory5", BaseProject.scenarioID);
    	String coApplicant2TargetDocType5 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType5", BaseProject.scenarioID);
    	String coApplicant2DocCategory6 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory6", BaseProject.scenarioID);
    	String coApplicant2TargetDocType6 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType6", BaseProject.scenarioID);
    	String coApplicant2DocCategory7 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory7", BaseProject.scenarioID);
    	String coApplicant2TargetDocType7 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType7", BaseProject.scenarioID);
    	String coApplicant2DocCategory8 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory8", BaseProject.scenarioID);
    	String coApplicant2TargetDocType8 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType8", BaseProject.scenarioID);
    	String coApplicant2DocCategory9_1 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory9_1", BaseProject.scenarioID);
    	String coApplicant2TargetDocType9_1 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType9_1", BaseProject.scenarioID);
    	String coApplicant2DocCategory9_2 = DBUtils.readColumnWithRowID("CoApplicant2DocCategory9_2", BaseProject.scenarioID);
    	String coApplicant2TargetDocType9_2 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType9_2", BaseProject.scenarioID);
    	
    			
    	if((!primaryDocCategory1.equals("null"))&&(!primaryDocCategory1.isEmpty()))
    	{
    		DocCategory.add(primaryDocCategory1);
    		TargetDoc.add(primaryTargetDocType1);
    	}
    	
    	if((!primaryDocCategory2.equals("null"))&&(!primaryDocCategory2.isEmpty())&&(!primaryDocCategory2.equals(null)))
    	{
    		DocCategory.add(primaryDocCategory2);
    		TargetDoc.add(primaryTargetDocType2);
    	}
    	
    	if(primaryDocCategory3 != null){    	
    		if(!primaryDocCategory3.equals("null") && !primaryDocCategory3.isEmpty()) {
    			logger.info("PrimaryDocCategory3 :"+primaryDocCategory3);
    			DocCategory.add(primaryDocCategory3);
    			TargetDoc.add(primaryTargetDocType3);
    		}
    	}
    	
    	if(primaryDocCategory4 != null){    	
    		if(!primaryDocCategory4.equals("null") && primaryDocCategory4.isEmpty()) {
    			logger.info("PrimaryDocCategory4 :"+primaryDocCategory4);
    			DocCategory.add(primaryDocCategory4);
    			TargetDoc.add(primaryTargetDocType4);
    		}
    	}
    	
    	if(primaryDocCategory5 != null){    	
    		if(!primaryDocCategory5.equals("null") && !primaryDocCategory5.isEmpty()) {
    			logger.info("PrimaryDocCategory5 :"+primaryDocCategory5);
    			DocCategory.add(primaryDocCategory5);
    			TargetDoc.add(primaryTargetDocType5);
    		}
    	}
    	
    	if(primaryDocCategory6 != null){    	
    		if(!primaryDocCategory6.equals("null") && !primaryDocCategory6.isEmpty()) {
    			logger.info("PrimaryDocCategory6 :"+primaryDocCategory6);
    			DocCategory.add(primaryDocCategory6);
    			TargetDoc.add(primaryTargetDocType6);
    		}
    	}
    	
    	if(primaryDocCategory7 != null){    	
    		if(!primaryDocCategory7.equals("null") && !primaryDocCategory7.isEmpty()) {
    			logger.info("PrimaryDocCategory7 :"+primaryDocCategory7);
    			DocCategory.add(primaryDocCategory7);
    			TargetDoc.add(primaryTargetDocType7);
    		}
    	}
    	
    	if(primaryDocCategory8 != null){    	
    		if(!primaryDocCategory8.equals("null") && !primaryDocCategory8.isEmpty()) {
    			DocCategory.add(primaryDocCategory8);
    			TargetDoc.add(primaryTargetDocType8);
    		}
    	}
    	
    	if(primaryDocCategory9_1 != null){    	
    		if(!primaryDocCategory9_1.equals("null") && !primaryDocCategory9_1.isEmpty()) {
    			DocCategory.add(primaryDocCategory9_1);
    			TargetDoc.add(primaryTargetDocType9_1);
    		}
    	}
    	
    	if(primaryDocCategory9_2 != null){    	
    		if(!primaryDocCategory9_2.equals("null") && !primaryDocCategory9_3.isEmpty()) {
    			DocCategory.add(primaryDocCategory9_2);
    			TargetDoc.add(primaryTargetDocType9_2);
    		}
    	}
    	
    	if(primaryDocCategory9_3 != null){    	
    		if(!primaryDocCategory9_3.equals("null") && !primaryDocCategory9_3.isEmpty()) {
    			DocCategory.add(primaryDocCategory9_3);
    			TargetDoc.add(primaryTargetDocType9_3);
    		}
    	}
    	
    	if(primaryDocCategory9_4 != null){    	
    		if(!primaryDocCategory9_4.equals("null") && !primaryDocCategory9_4.isEmpty()) {
    			DocCategory.add(primaryDocCategory9_4);
    			TargetDoc.add(primaryTargetDocType9_4);
    		}
    	}
    	
    	//Co Applicant 
    	
    	if(coApplicant1DocCategory1 != null){    	
    		if(!coApplicant1DocCategory1.equals("null") && !coApplicant1DocCategory1.isEmpty()) {
    			DocCategory.add(coApplicant1DocCategory1);
    			TargetDoc.add(coApplicant1TargetDocType1);
    		}
    	}
    	
    	if(coApplicant1DocCategory2 != null){    	
    		if(!coApplicant1DocCategory2.equals("null") && !coApplicant1DocCategory2.isEmpty()) {
    	   		DocCategory.add(coApplicant1DocCategory2);
    	   		TargetDoc.add(coApplicant1TargetDocType2);
    		}
    	}
    	
    	if(coApplicant1DocCategory3 != null){    	
    		if(!coApplicant1DocCategory3.equals("null") && !coApplicant1DocCategory3.isEmpty()) {
    			DocCategory.add(coApplicant1DocCategory3);
    			TargetDoc.add(coApplicant1TargetDocType3);
    		}
    	}
    	
    	if(coApplicant1DocCategory4 != null){    	
    		if(!coApplicant1DocCategory4.equals("null") && !coApplicant1DocCategory4.isEmpty()) {
    			DocCategory.add(coApplicant1DocCategory4);
    			TargetDoc.add(coApplicant1TargetDocType4);
    		}
    	}
    	
    	if(coApplicant1DocCategory5 != null){    	
    		if(!coApplicant1DocCategory5.equals("null") && !coApplicant1DocCategory5.isEmpty()) {
    			DocCategory.add(coApplicant1DocCategory5);
    			TargetDoc.add(coApplicant1TargetDocType5);
    		}
    	}
    	
    	if(coApplicant1DocCategory6 != null){    	
    		if(!coApplicant1DocCategory6.equals("null") && !coApplicant1DocCategory6.isEmpty()) {
    	    	DocCategory.add(coApplicant1DocCategory6);
    	    	TargetDoc.add(coApplicant1TargetDocType6);
    		}
    	}
    	
    	if(coApplicant1DocCategory7 != null){    	
    		if(!coApplicant1DocCategory7.equals("null") && !coApplicant1DocCategory7.isEmpty()) {
    			DocCategory.add(coApplicant1DocCategory7);
    			TargetDoc.add(coApplicant1TargetDocType7);
    		}
    	}
    	
    	if(coApplicant1DocCategory8 != null){    	
    		if(!coApplicant1DocCategory8.equals("null") && !coApplicant1DocCategory8.isEmpty()) {
    	   		DocCategory.add(coApplicant1DocCategory8);
    	   		TargetDoc.add(coApplicant1TargetDocType8);
    		}
    	}
    	
    	if(coApplicant1DocCategory9_1 != null){    	
    		if(!coApplicant1DocCategory9_1.equals("null") && !coApplicant1DocCategory9_1.isEmpty()) {    	
    			DocCategory.add(coApplicant1DocCategory9_1);
    			TargetDoc.add(coApplicant1TargetDocType9_1);
    		}
    	}
    	
    	if(coApplicant1DocCategory9_2 != null){    	
    		if(!coApplicant1DocCategory9_2.equals("null") && !coApplicant1DocCategory9_2.isEmpty()) {
    	   		DocCategory.add(coApplicant1DocCategory9_2);
    	   		TargetDoc.add(coApplicant1TargetDocType9_2);
    		}
    	}
    	
    	// Co Applicant 2
    	if(coApplicant2DocCategory1 != null){    	
    		if(!coApplicant2DocCategory1.equals("null") && !coApplicant2DocCategory1.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory1);
    	   		TargetDoc.add(coApplicant2TargetDocType1);
    		}
    	}
    	
    	if(coApplicant2DocCategory2 != null){    	
    		if(!coApplicant2DocCategory2.equals("null") && !coApplicant2DocCategory2.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory2);
    	   		TargetDoc.add(coApplicant2TargetDocType2);
    		}
    	}
    	
    	if(coApplicant2DocCategory3 != null){    	
    		if(!coApplicant2DocCategory3.equals("null") && !coApplicant2DocCategory3.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory3);
    	   		TargetDoc.add(coApplicant2TargetDocType3);
    		}
    	}
    	
    	if(coApplicant2DocCategory4 != null){    	
    		if(!coApplicant2DocCategory4.equals("null") && !coApplicant2DocCategory4.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory4);
    	   		TargetDoc.add(coApplicant2TargetDocType4);
    		}
    	}
    	
    	if(coApplicant2DocCategory5 != null){    	
    		if(!coApplicant2DocCategory5.equals("null") && !coApplicant2DocCategory5.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory5);
    	   		TargetDoc.add(coApplicant2TargetDocType5);
    		}
    	}
    	
    	if(coApplicant2DocCategory6 != null){    	
    		if(!coApplicant2DocCategory6.equals("null") && !coApplicant2DocCategory6.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory6);
    	   		TargetDoc.add(coApplicant2TargetDocType6);
    		}
    	}
    	
    	if(coApplicant2DocCategory7 != null){    	
    		if(!coApplicant2DocCategory7.equals("null") && !coApplicant2DocCategory7.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory7);
    	   		TargetDoc.add(coApplicant2TargetDocType7);
    		}
    	}
    	
    	if(coApplicant2DocCategory8 != null){    	
    		if(!coApplicant2DocCategory8.equals("null") && !coApplicant2DocCategory8.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory8);
    	   		TargetDoc.add(coApplicant2TargetDocType8);
    		}
    	}
    	
    	if(coApplicant2DocCategory9_1 != null){    	
    		if(!coApplicant2DocCategory9_1.equals("null") && !coApplicant2DocCategory9_1.isEmpty()) {
    	   		DocCategory.add(coApplicant2DocCategory9_1);
    	   		TargetDoc.add(coApplicant2TargetDocType9_1);
    		}
    	}
    	
    	if(coApplicant2DocCategory9_2 != null){    	
    		if(!coApplicant2DocCategory9_2.equals("null") && !coApplicant2DocCategory9_2.isEmpty()) {
    			DocCategory.add(coApplicant2DocCategory9_2);
    			TargetDoc.add(coApplicant2TargetDocType9_2);
    		}
    	}
    	    	
    	
    	for (int i = j; i < DocCategory.size(); i++) {
			System.out.println(DocCategory.get(i));
			System.out.println(TargetDoc.get(i));
			String doccategory_value = DocCategory.get(i);
			logger.info("Document Category value from database=================> :"+doccategory_value);
								
			if(doccategory_value.equals("PRODUCT & SUPPORTING DOCUMENTS")){	
				List<WebElement> DocuType = BaseProject.driver.findElements(By.xpath(com.getElementProperties("DI", "DI_DocumentType_Table")));
		        int k=DocuType.size();
		        if(k==2){				
		        	wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_DeleteRow"));
		        	wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_Dropdown")); 
		        	wrap.wait(1000);
		        	wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_SupportingDocs"));
		        	wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
		        	WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_SourceDocType_LastRow"));
		        	waitUntilVisibilityOfWebElement(element);
		        	String Applform = element.getAttribute("value");
		        	String[] TrimmedApplForm = Applform.split("-");
		        	String App_Value = "1-"+TrimmedApplForm[1];
		        	logger.info("The Application form " + TrimmedApplForm[0]);
                					
					wrap.typeToTextBox(BaseProject.driver, App_Value, com.getElementProperties("DI", "DI_eClassify_PageRange"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.typeToTextBox(BaseProject.driver, DocCategory.get(i), com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_TargetDocType"));
					wrap.typeToTextBox(BaseProject.driver, TargetDoc.get(i), com.getElementProperties("DI", "DI_eClassify_TargetDocType"));    
					
					if(i<(DocCategory.size()-1)){
						wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
					}					
		        }
		        else
		        {
		        	wrap.typeToTextBox(BaseProject.driver, id2, com.getElementProperties("DI", "DI_eClassify_PageRange"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.typeToTextBox(BaseProject.driver, DocCategory.get(i), com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_TargetDocType"));
					wrap.typeToTextBox(BaseProject.driver, TargetDoc.get(i), com.getElementProperties("DI", "DI_eClassify_TargetDocType"));    
					
					if(i<(DocCategory.size()-1)){
						wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
					}		
		        }
			}	
			else{
				if((i==0) || (i==1))
				{	
					wrap.typeToTextBox(BaseProject.driver, id1, com.getElementProperties("DI", "DI_eClassify_PageRange"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.typeToTextBox(BaseProject.driver, DocCategory.get(i), com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_TargetDocType"));
					wrap.typeToTextBox(BaseProject.driver, TargetDoc.get(i), com.getElementProperties("DI", "DI_eClassify_TargetDocType"));    
					
					if(i<(DocCategory.size()-1)){
						wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
					}
				
				}
				else
				{
					wrap.typeToTextBox(BaseProject.driver, id2, com.getElementProperties("DI", "DI_eClassify_PageRange"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.typeToTextBox(BaseProject.driver, DocCategory.get(i), com.getElementProperties("DI", "DI_eClassify_DocCategory"));
					wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_TargetDocType"));
					wrap.typeToTextBox(BaseProject.driver, TargetDoc.get(i), com.getElementProperties("DI", "DI_eClassify_TargetDocType"));    
					
					if(i<(DocCategory.size()-1)){
						wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
					}
				}
			}
    	 }
    	
    }

    @Given("^Splits the application by entering page range & selecting any option under DocCategory,TargetDocType$")
    public void splits_the_application_by_entering_page_range_selecting_any_option_under_doccategory_targetdoctype() throws IOException, InterruptedException {          
        
    	WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentType"));
    	wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_Dropdown"));
    	wrap.wait(1000);
    	WebElement element1 = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_ApplicationForm"));
    	WebElement element2 = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_SupportingDocs"));
       
    	String docType = element.getText();
        
        List<WebElement> documentType = BaseProject.driver.findElements(By.xpath(com.getElementProperties("DI", "DI_DocumentType_Table")));
        int i=documentType.size();
        int j;
        logger.info("DocType count ---------------------------------------> :"+i);
        logger.info("DocType value ---------------------------------------> :"+docType);
        if(i>1){        	
        		if(docType == "ApplicationForm"){
        			//wrap.click(BaseProject.driver, "ApplicationForm");
        			logger.info("If Document Type Value is Application Form:"+documentType);
        			splitDocs(0);
        			wrap.wait(1000);
        		}
        		else{
        			logger.info("Else Document Type Value is suppporting document");
        			wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_DeleteRow"));
        			wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_Dropdown")); 
        			wrap.wait(1000);
        			wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_ApplicationForm"));
        			wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_AddRow"));
        			wrap.wait(1000);
        			logger.info("Clicked Application Form");
        			splitDocs(1);                
        		}
        		i--;
        	}        	
       
        else{
        	splitDocs(0);
        	i--;
        }
    }
        		
      		
      
   public void splitDocs(int i) throws IOException, InterruptedException {
	    //WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_Sourcedoc_type_Applform_text"));
	   WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("DI", "DI_SourceDocType_LastRow"));
        waitUntilVisibilityOfWebElement(element);
    	String applForm = element.getAttribute("value");
        String[] trimmedApplForm = applForm.split("-");

        logger.info("The Application form " + trimmedApplForm[0]);
        logger.info("The Application form is of : " + trimmedApplForm[1]);


        switch (trimmedApplForm[1]) {
            case "2":

                logger.info("The Application contains 2 pages");
                userSplitsDocsAccordingBarcode("1-2", "2", i);
                break;

            case "5":

                logger.info("The Application contains 5 pages");
                userSplitsDocsAccordingBarcode("1-5", "5", i);
                break;

            case "6":

                logger.info("The Application contains 6 pages");
                userSplitsDocsAccordingBarcode("1-6", "6", i);
                break;
                
            case "9":

                logger.info("The Application contains 6 pages");
                userSplitsDocsAccordingBarcode("1-9", "9", i);
                break;

            case "14":

                logger.info("The Application contains 14 pages");
                userSplitsDocsAccordingBarcode("1-14", "14", i);
                break;

            case "15":

                logger.info("The Application contains 15 pages");
                userSplitsDocsAccordingBarcode("1-15", "15", i);
                break;
                
            case "18":

                logger.info("The Application contains 15 pages");
                userSplitsDocsAccordingBarcode("1-18", "18", i);
                break;
                
            case "24":

                logger.info("The Application contains 24 pages");
                userSplitsDocsAccordingBarcode("1-24", "24", i);
                break;

            case "26":

                logger.info("The Application contains 26 pages");
                userSplitsDocsAccordingBarcode("1-26", "26", i);
                break;
            
        	}
        }

    @Given("^user clicks on Split button$")
    public void click_on_split_button() throws IOException, InterruptedException {
        wrap.wait(3000);
        wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_split_button"));
    }


    @Given("^user clicks on Proceed for Indexing button$")
    public void click_on_proceed_for_indexing_button() throws IOException, InterruptedException {
    	
    	String coApplicant2TargetDocType1 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType1", BaseProject.scenarioID);
    	String coApplicant2TargetDocType2 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType2", BaseProject.scenarioID);
    	String coApplicant2TargetDocType3 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType3", BaseProject.scenarioID);
    	String coApplicant2TargetDocType4 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType4", BaseProject.scenarioID);
    	String coApplicant2TargetDocType5 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType5", BaseProject.scenarioID);
    	String coApplicant2TargetDocType6 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType6", BaseProject.scenarioID);
    	String coApplicant2TargetDocType7 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType7", BaseProject.scenarioID);
    	String coApplicant2TargetDocType8 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType8", BaseProject.scenarioID);
    	String coApplicant2TargetDocType9_1 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType9_1", BaseProject.scenarioID);
    	String coApplicant2TargetDocType9_2 = DBUtils.readColumnWithRowID("CoApplicant2TargetDocType9_2", BaseProject.scenarioID);

    	wrap.wait(6000);

        Wait<WebDriver> wait = new FluentWait<WebDriver>(BaseProject.driver)
                .withTimeout(30, TimeUnit.SECONDS)
                .pollingEvery(1, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);

        //wait.until(ExpectedConditions.elementToBeClickable(BY.com.getElementProperties("DI", "DI_eclassify_proccedforindexing_button"));
        wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_proceedforindexing_button"));
        
        ArrayList<String> targetTypes = new ArrayList<String>();
        ArrayList<String> targetTypes1 = new ArrayList<String>();
        
        targetTypes.add(coApplicant2TargetDocType1);
        targetTypes.add(coApplicant2TargetDocType2);
        targetTypes.add(coApplicant2TargetDocType3);
        targetTypes.add(coApplicant2TargetDocType4);
        targetTypes.add(coApplicant2TargetDocType5);
        targetTypes.add(coApplicant2TargetDocType6);
        targetTypes.add(coApplicant2TargetDocType7);
        targetTypes.add(coApplicant2TargetDocType8);
        targetTypes.add(coApplicant2TargetDocType9_1);
        targetTypes.add(coApplicant2TargetDocType9_2);
        
        //targetTypes.removeAll(Collections.singletonList(null));        
        
        
        for (int i = 0 ; i<targetTypes.size();i++){
        	if(targetTypes.get(i) != null){    	
        		if(!targetTypes.get(i).equals("null") && !targetTypes.get(i).isEmpty()) {
        			targetTypes1.add(targetTypes.get(i));
        		}
        	}
        }
        
        logger.info("Target types list size after removing null ---------------------> :"+targetTypes1.size());        
               
        int m=1;
        int n=1;
    	for(int k=0; k<targetTypes1.size(); k++){
    		String targetTypeValue = targetTypes1.get(k);
        	//if(!target_value.equals("null")){        		        		
        		if(targetTypeValue.contains("$$2")){        			
        				logger.info("$$2 value .................:"+m);
        	        		String value = com.getElementProperties("DI", "DI_eclassify_CoApp2_ApplicationSequenceNo")+"["+m+"]";
        	        		logger.info("Co App $$2 xpath value ---------------------------------------------------> :"+value);
        	        		wrap.typeToTextBox(BaseProject.driver, "2", value);
        	        		wrap.wait(1000);
        	        		m=m+1;           	        		
        	    }
        		else if(targetTypeValue.contains("$$1")){
        			logger.info("$$2 value .................:"+m);
	        		String value = com.getElementProperties("DI", "DI_eclassify_CoApp2_ApplicationSequenceNo1")+"["+n+"]";
	        		logger.info("Co App $$1 xpath value ---------------------------------------------------> :"+value);
	        		wrap.typeToTextBox(BaseProject.driver, "2", value);
	        		wrap.wait(1000);
	        		n=n+1; 
        			
        		}
        		else{  
        			WebElement AppNo = BaseProject.driver.findElement(By.xpath("(//input[contains(@id, '"+targetTypeValue+"') and @name='ApplicSeqNo'])[2]"));
        			/*String AppNumber = AppNo.getText();
        			logger.info("Executed unique value ++++++++ :"+AppNo);*/
        			BaseProject.driver.findElement(By.xpath("(//input[contains(@id, '"+targetTypeValue+"') and @name='ApplicSeqNo'])[2]")).clear();
        			BaseProject.driver.findElement(By.xpath("(//input[contains(@id, '"+targetTypeValue+"') and @name='ApplicSeqNo'])[2]")).sendKeys("2");
            		logger.info("Executed else for unique value");
        		}          			
    		}
    }




   

    @Then("^user clicks on Commit button$")
    public void click_on_commit_button() throws IOException, InterruptedException {

        WebElement elem = BaseProject.driver.findElement(By.xpath(com.getElementProperties("DI", "DI_eclassify_Commit_button")));
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(elem));
        
        elem.click();        

    }


    @Then("^user clicks on OK button$")
    public void click_on_ok_button() throws IOException, InterruptedException {

        wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eclassify_Conform_popup_OK_button"));
        //wrap.getTextValue(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_Done_popup_message"));
        //logger.info(wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_Done_popup_message")).getText());

        wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_eClassify_Done_popup_OK_button"));

    }
    
    @Then("^user clicks on Submit button$")
    public void click_on_submit_button() throws IOException, InterruptedException {
    	try{
    		wrap.wait(1000);    	
    		wrap.switchToWindow(BaseProject.driver, "AppWorkFlow User Portal");
    		//wrap.switch_to_default_Content(BaseProject.driver);
    		wrap.wait(2000);
    		logger.info("Window Switched successfully");
    		wrap.click(BaseProject.driver, com.getElementProperties("DI", "DI_DocumentIndexingWorkBasket_submit_button"));
    		wrap.wait(2000);
    	}
    	catch(Exception e){
    		logger.info("Window not switched"+e);
    	}
    }
    
    @Then("^Verify the application falls in Basic Data Capture post Document Indexing$")
    public void verify_the_application_falls_in_blind_basic_data_capture_post_document_indexing() throws IOException, InterruptedException {

        wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));
        wrap.wait(2000);
        wrap.getWorkbasketoption(BaseProject.driver, "Basic data capture ");
        wrap.wait(2000);
        String applicationID = null;
        applicationID = commonUtils.readColumnWithRowID("ApplicationID_DI", BaseProject.scenarioID);
        try {
            wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
            logger.info("switched");
        } catch (Exception E) {
            logger.info("frame not switched");
        }
        BusinessCommonUtils.select_application_number(BaseProject.driver, applicationID);
        logger.info("App Id filtered");
    }

    
}
