package com.scb.rtob.module.test.framework.glue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class InvestigationsWB {

	public static Logger logger = Logger.getLogger(InvestigationsWB.class);

	static CommonUtils utils= new CommonUtils(); 
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";



	public static void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();

		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1; 
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last);
	}

	@Given("^Go to Investigation WB home page$")
	public void go_to_Investigations_WB_home_page() throws Throwable {

		wrap.switch_to_default_Content(BaseProject.driver);

		try {
			wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "work_basket_option"));
			wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "seeall_option"));
			wrap.getWorkbasketoption(BaseProject.driver, "Investigation");
			wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "modal_submit_button"));
		} 

		catch (Exception e) {
			e.printStackTrace();
		}

	}


	@Then("^Capture the table details under InvestigationWB$")
	public void capture_Table_details() throws Throwable {

		switchFrame();

		WebElement eleTable = BaseProject.driver.findElement(By.xpath("//table[@pl_prop='.CriticalDataAuditView']"));

		List<WebElement> trws= eleTable.findElements(By.tagName("tr"));

		for (WebElement tr : trws) {

			List<WebElement> ths=tr.findElements(By.tagName("th"));


			for (WebElement th : ths) {

				logger.info("Table headers are: "+th.getText());


			}

			List<WebElement> tds=tr.findElements(By.tagName("td"));


			for (WebElement td : tds) {


				logger.info("Table values are: "+td.getText());


			}		

		}
	}
	
	
	@Then("^Investigations: Select value from Action DropDown and Enter Remarks$")
     public void select_value_from_action_dropdown_and_enter_remarks() throws Throwable {
        //switchFrame();
        Select sel1 = new Select(BaseProject.driver.findElement(By.xpath("//*[@id='InvestigationAction']")));
        sel1.selectByIndex(1);
              
        List<WebElement> allremarks1 = BaseProject.driver.findElements(By.xpath("//*[@id='Comments']"));
        for (WebElement eachremarks : allremarks1) {
            if(eachremarks.isDisplayed()){
                   
                   eachremarks.sendKeys("Completed");                       
        }
        }
        wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
        }


}

