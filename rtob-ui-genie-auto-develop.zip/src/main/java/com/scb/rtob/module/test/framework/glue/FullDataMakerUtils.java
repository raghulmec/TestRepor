package com.scb.rtob.module.test.framework.glue;

import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FullDataMakerUtils {

    public static Logger logger = Logger.getLogger(FullDataMakerUtils.class);

    static Wrapper wrap = new Wrapper();
    static Commons com = new Commons();
    public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
    static String co_xpath = null;
    static String multipleProducts_xpath = null;
    CommonUtils utils = new CommonUtils();
    public static String excelPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ExcelData";
    //Neethu code below two line declaration for co-applicant
    public static int fDC_Co_Applicant = 0, fDC_Co_Applicant1 = 0;
    public static String coapp = "Coapp";
//	public static int increment_Applicant = 1;


    @Then("^FDM : Switch to Customer details tab$")
    public static void switchToCustomerDetailsTab() throws InterruptedException, IOException {
    	wrap.wait(5000);
        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        
        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_PD_CustomerDetails_Link")));
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_CustomerDetails_Link"), 20);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_CustomerDetails_Link"));
    }

    @Then("^FDM : Switch to Product details tab$")
    public static void switchToProductDetailsTab() throws InterruptedException, IOException {

    	 wrap.wait(3000);
        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
       
        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link")));
        //jse.executeScript(“window.scrollTo(0,document.body.scrollHeight);”);
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"), 20);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"));
     

    }

    @Then("^FDM : Switch to Application details tab$")
    public static void switchToApplicationDetailsTab() throws InterruptedException, IOException {

        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link")));
        //jse.executeScript(“window.scrollTo(0,document.body.scrollHeight);”);
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"), 20);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_tab"));

    }

    @Then("^FDM : Switch to Documents tab$")
    public static void switchToIncomeDocsTab() throws InterruptedException, IOException {

        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_tab"));

    }

    public static int noOfApplicants() throws InterruptedException, IOException {

        List<WebElement> Total_Link = wrap.getExactAttributes(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_All_Applicants_link"));

        return Total_Link.size();
    }


    public static int noOfProducts() throws InterruptedException, IOException {

        List<WebElement> Total_Link = wrap.getExactAttributes(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_MultipleProduct_link"));

        return Total_Link.size();
    }

    public static void switchToNextProduct() throws InterruptedException, IOException {

        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.wait(1000);

        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        wrap.wait(2000);

        multipleProducts_xpath = com.getElementProperties("Fulldatacapturemaker", "MultipleProduct_link") + "[" + FullDataMaker.fDC_Multiple_Product + "]";

        wrap.click(BaseProject.driver, multipleProducts_xpath);

        FullDataMaker.fDC_Multiple_Product++;

    }


    public static void addDocumentInCustomerTab(String action, String docCategory, String docName, String docNumber, String docSignDate, String docExpDate) throws InterruptedException, IOException {

        if (action.equalsIgnoreCase("Delete")) {

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentDelete"));

        } else {

            if (action.equalsIgnoreCase("Add")) {

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentAdd"));
            }

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentCategory1"),
                    docCategory, "BYVISIBLETEXT");
            wrap.wait(3000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                    docName, "BYVISIBLETEXT");

            wrap.typeToTextBox(BaseProject.driver, docNumber, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));

            wrap.typeToTextBox(BaseProject.driver, docSignDate, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentSignatorydate"));

            wrap.typeToTextBox(BaseProject.driver, docExpDate, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentExpiryDate"));

        }
    }

    public static void switchToDocumentsTab() throws InterruptedException, IOException {

        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_tab"));

    }


    public static void fillCommonAddressfields() throws InterruptedException, IOException {

        //wrap.wait(4500);

        try {
        	
        	JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
            jse.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox")));
        	
        	//com.suggestionTextBox2(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID), "A1 Res");
            
            String add_type="A1 Residence";
            StringBuffer sb=new StringBuffer();
            
            
            BaseProject.driver.findElement(By.xpath("//span[text()='Address Type']//parent::label/following-sibling::div//input[not(@type='hidden')]")).sendKeys(sb.append(add_type));
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'"+add_type+"')]")).click();
            
           // wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID));
           // wrap.wait(1000);
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"))));
        } catch (Exception e) {
            e.printStackTrace();

        }


        /*****************************Residence Type field is available for RES Address Type only***********************************/

        if (FullDataMaker.product.equalsIgnoreCase("CC") || FullDataMaker.product.equalsIgnoreCase("PL")) {

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType"),
                    DBUtils.readColumnWithRowID("Address1_Residence type", BaseProject.scenarioID), "BYVISIBLETEXT");

        }

	/*	
		String addrtypevalue = BaseProject.driver.findElement(By.xpath("//input[@id='Type'][@value='RES']")).getText();
		if(addrtypevalue.equalsIgnoreCase("RES"))
		{
			logger.info("RES is successfully selected");
		}*/


        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt")));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt"));

        //wrap.wait(1000);
        //new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"))));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 2", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"));

        //wrap.wait(1000);
        //new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"))));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 3", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"));

        //wrap.wait(1000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("City", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City"));
		

        //wrap.wait(1000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Zip Code", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"));
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"))));
        //wrap.wait(1000);
//        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("State", BaseProject.scenarioID),
//                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));
		/*wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID) , 
				com.getElementProperties("Fulldatacapturemaker","FDC_CustomerDetails_AreaCode"));*/

     //   wrap.captureScreenShot(BaseProject.driver, "Address Section");



    }

    public static void fillWorkExperienceFields() throws InterruptedException, IOException {

        /**********************Filling work experience fields**************************/
        //wrap.wait(3000);
        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY"));
        //wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY")).sendKeys(Keys.TAB);
        wrap.wait(2500);

       // wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM"));
        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No of Months in Current business/Organization", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM"));
        //wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM")).sendKeys(Keys.TAB);
        wrap.wait(2500);

        //wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY"));
        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY"));
       // wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY")).sendKeys(Keys.TAB);
        wrap.wait(2500);

        //wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM"));
        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM"));
        wrap.wait(2500);
        


    }

    /*public static void selectWorkType() throws IOException, InterruptedException {

        String workType = DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID);
        String occData = BaseProject.driver.findElement(By.xpath("//*[text()='Occupation']/../following::div/span")).getText();
        logger.info("The given occupation type is : "+ occData);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), workType, "BYVISIBLETEXT");
        wrap.wait(2000);

        
        switch (workType) {

            case "S - Salaried/Controller/Owner/Director":
            			
            	if(occData.contains("STAFF"))
            	{
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                        DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

            	 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Corporate ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Corporateid"));
            	 
            	 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            	}
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName"),
                        "code", DBUtils.readColumnWithRowID("Employer Name", BaseProject.scenarioID));
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Department", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Department"));
           	 
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary"));
                wrap.wait(2000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary"),
                        DBUtils.readColumnWithRowID("Salary Mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Previous employer name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Previousemployername"));
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Designation"),
                        DBUtils.readColumnWithRowID("Designation", BaseProject.scenarioID), "BYVISIBLETEXT");
                                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Declared Income", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_DeclaredIncome"));
                
                fillWorkExperienceFields();

                break;
                
            case "E - Self-Employed/Business Owner":
            	
            	if(occData.contains("STAFF"))
            	{
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                        DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

            	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            	}
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_DescribeApplicantOrOwnershipType"),
                        DBUtils.readColumnWithRowID("Describe Applicant/Ownership Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyType"),
                        DBUtils.readColumnWithRowID("Company Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IndustryGroupSector"),
                        DBUtils.readColumnWithRowID("Industry Group Sector", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("% of Share holding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_percentofShareholding"));
           	 
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Business Establishment Date", BaseProject.scenarioID), 
                		com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate"));
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Company Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyName"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Incorporation Date", BaseProject.scenarioID), 
                		com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationDate"));
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationCountry"),
                        DBUtils.readColumnWithRowID("Incorporation Country", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Designation"),
                        DBUtils.readColumnWithRowID("Designation", BaseProject.scenarioID), "BYVISIBLETEXT");
                                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Declared Income", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_DeclaredIncome"));
                
                fillWorkExperienceFields();
                
                break;

            default:
// common scripts for D-student, G-Salaried,H-Homemaker,R-Retired & U-Unemployed - options in Worktype.
            	if(occData.contains("STAFF"))
            	{
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                        DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

            	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            	}
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
            	System.out.println("Not redirected to exact work type in switch case");
                break;
        }


    }*/

    
    //Neethu-09/02/18
    
    public static void selectWorkType() throws IOException, InterruptedException {
    	try {
			DBUtils.convertDBtoMap("fdquery");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
        String workType = DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID);
        String occData = BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//*[text()='Occupation']/../following::div/span")).getText();
        logger.info("The given occupation type is : "+ occData);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"), workType, "BYVISIBLETEXT");
        wrap.wait(2000);

        
        switch (workType) {
             
            case "S - Salaried/Controller/Owner/Director":
                           
             if(occData.equalsIgnoreCase("STAFF"))
            {
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                        DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            
             wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            
              wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

             wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Corporate ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Corporateid"));
             
              wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            }
             
             wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Corporate ID", BaseProject.scenarioID),
                     com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Corporateid"));
             
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName_joint"),
                        "code", DBUtils.readColumnWithRowID("Employer Name", BaseProject.scenarioID));
                
                /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Department", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Department"));*/
              
               /* wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary"));
                wrap.wait(2000);*/
                
                wrap.wait(2000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary_joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary_joint"),
                        DBUtils.readColumnWithRowID("Salary Mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Previous employer name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Previousemployername_joint"));
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Designation_joint"),
                        DBUtils.readColumnWithRowID("Designation", BaseProject.scenarioID), "BYVISIBLETEXT");
                                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Declared Income", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_DeclaredIncome"));
                
                fillWorkExperienceFields();

                break;
                
            case "E - Self-Employed/Business Owner":
            
             if(occData.equalsIgnoreCase("STAFF"))
            {
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                       DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            
             wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            
             wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

            wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            }
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_DescribeApplicantOrOwnershipType"),
                        DBUtils.readColumnWithRowID("Describe Applicant/Ownership Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyType"),
                        DBUtils.readColumnWithRowID("Company Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IndustryGroupSector"),
                        DBUtils.readColumnWithRowID("Industry Group Sector", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("% of Share holding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_percentofShareholding"));
              
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Business Establishment Date", BaseProject.scenarioID), 
                           com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate"));
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Company Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyName"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Incorporation Date", BaseProject.scenarioID), 
                           com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationDate"));
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationCountry"),
                        DBUtils.readColumnWithRowID("Incorporation Country", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Designation"),
                        DBUtils.readColumnWithRowID("Designation", BaseProject.scenarioID), "BYVISIBLETEXT");
                                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Declared Income", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_DeclaredIncome"));
                
                fillWorkExperienceFields();
                
                break;

            default:
// common scripts for D-student, G-Salaried,H-Homemaker,R-Retired & U-Unemployed - options in Worktype.
            if(occData.contains("STAFF"))
            {
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffCategory"),
                        DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
            
             wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_StaffGrade"),
                        DBUtils.readColumnWithRowID("Staff Grade", BaseProject.scenarioID), "BYVISIBLETEXT");
            
             wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employee ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployeeId_TextBox"));

            wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
            }
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
            System.out.println("Not redirected to exact work type in switch case");
                break;
        }


    }


    public static void fillFATCA() throws InterruptedException, IOException {

        /**********************Filling FATCA section**************************/
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"));
    	
    	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"))));
    	
    	wrap.radioButtonSelection(BaseProject.driver, "FATCA - Is Customer a US Resident?", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No");
	
        
		wrap.radioButtonSelection(BaseProject.driver, "Is Customer a US Citizen?", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No");
       
		wrap.radioButtonSelection(BaseProject.driver, "FATCA - Is Customer a Green card holder?", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No");
        
        /*WebElement ele_PSD_CRS1 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"));

        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
        myExecutor.executeScript("arguments[0].click();", ele_PSD_CRS1);

        wrap.wait(3000);
        WebElement ele_PSD_us = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No"));
        myExecutor.executeScript("arguments[0].click();", ele_PSD_us);
        wrap.wait(3000);
        WebElement ele_PSD_gr = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No"));
        myExecutor.executeScript("arguments[0].click();", ele_PSD_gr);*/

      //  wrap.wait(500);
       // wrap.SelectAutosuggestionTextBox(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty"),DBUtils.readColumnWithRowID("FATCA Country of Treaty", BaseProject.scenarioID));
		
		com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty"), "IN", DBUtils.readColumnWithRowID("FATCA Country of Treaty", BaseProject.scenarioID));

    }


    public static void fillGST() throws InterruptedException, IOException {

        /**********************Filling GST section*****************************/

		wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes"));

		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes")));    
            wrap.radioButtonSelection(BaseProject.driver, "Customer Type", "Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes", "FDC_GSTDetails_CustomerType_No");
        

        String specStatusYNopt = DBUtils.readColumnWithRowID("Specific status", BaseProject.scenarioID);
        logger.info("Specific Status :" + specStatusYNopt);

        if (specStatusYNopt.equalsIgnoreCase("No"))
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_No"));
        else if (specStatusYNopt.equalsIgnoreCase("Yes"))
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes"));
        else
            logger.info("Incorrect selection has been made, other than Yes or No data");

    }


    @SuppressWarnings("deprecation")
    @When("^FD: Verify FDMaker workbasker$")
    public void FDmakerworkbasket() throws IOException, InterruptedException {

        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");

        wrap.wait(2000);
        if (!wrap.getElement(BaseProject.driver, "//h2[text()='Full Data Capture Maker']").getText().contains("Full Data Capture Maker")) {
            logger.info("FDMaker workbasket not verified");
            Assert.assertEquals("FDMaker workbasket not verified", "true", "false");

        } else
            logger.info("FDMaker workbasket  verified in this credential");

    }

    @When("^FD: Logout all$")
    public void FDlogoutall() throws IOException, InterruptedException {
        boolean visi_logout = false, peggalogout = false;
        wrap.switch_to_default_Content(BaseProject.driver);
        visi_logout = wrap.getElement(BaseProject.driver, com.getElementProperties("ProductCatalogue", "logOut_xpath")).isDisplayed();
        if (visi_logout == true) {
            wrap.getElement(BaseProject.driver, "//a[text()= ' Logout']").click();
            System.out.println("User logged out successfully");
            wrap.wait(3000);
        }
        wrap.switchToWindow(BaseProject.driver, "Pega Designer Studio");
        logger.info(BaseProject.driver.getTitle() + "hj");
        wrap.wait(5000);

        {
            wrap.switch_to_default_Content(BaseProject.driver);
            wrap.getElement(BaseProject.driver, "//i[@data-test-id='px-opr-image-ctrl']").click();
            wrap.wait(3000);
            wrap.click(BaseProject.driver, "//span[text()='Log off']");

            wrap.wait(3000);
        }

    }

    @Then("^map testcases with scenarioids for reporting$")
    public void map_testcases_with_scenarioids_for_reporting() throws Throwable {
        utils.convertExcelToMap(excelPath, "Checkerorder.xls", "Sheet1");

    }

    ////////////////Neethu code starts here for Co-Applicant ////////////////////////////////////

    public static void selectWorkTypejoint(int FDC_Co_Applicant) throws IOException, InterruptedException {

        String workType = DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Work Type", BaseProject.scenarioID);


        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
        wrap.wait(1000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                workType, "BYVISIBLETEXT");
        wrap.wait(2000);

        switch (workType) {

            case "S - Salaried/ Controller/Owner/Director":


                wrap.wait(2000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmployerName_joint"),
                        "code", DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Employer Name", BaseProject.scenarioID));

                //wrap.wait(3000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary_joint"));
                wrap.wait(1500);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary_joint"),
                        DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Salary Mode", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(2000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Designation_joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Designation_joint"),
                        DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Designation", BaseProject.scenarioID), "BYVISIBLETEXT");

                fillWorkExperienceFieldsjoint(FDC_Co_Applicant);

                break;

            case "E - Self-Employed/Business Owner":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"), "S - Salaried", "BYVISIBLETEXT");

                break;

            default:

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmployeeBankingPricingCategory_joint"), "Non Mangement", "BYVISIBLETEXT");

                break;
        }


    }

    public static void fillWorkExperienceFieldsjoint(int FDC_Co_Applicant) throws InterruptedException, IOException {

        /**********************Filling work experience fields**************************/
        CommonUtils.convertExcelToMap(BaseProject.excelPath, "FullDataCapture.xls", "Co-applicant");

        wrap.wait(3000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " NoOfYears Current", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY_joint"));
        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY_joint")).sendKeys(Keys.TAB);
        wrap.wait(4500);

        wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM_joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " NoOfMonths Current", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM_joint"));
        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM_joint")).sendKeys(Keys.TAB);
        wrap.wait(4500);

        wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY_joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " NoOfYears Previous", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY_joint"));
        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY_joint")).sendKeys(Keys.TAB);
        wrap.wait(4500);

        wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM_joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " NoOfMonths Previous", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM_joint"));
        wrap.wait(3500);

    }

    public static void switchToNextCoapplicant() throws InterruptedException, IOException {

//		wrap.switch_to_default_Content(BaseProject.driver);
//		wrap.wait(1000);
//
//		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
//		wrap.wait(2000);
//		int m=FullDataMaker.FDC_Co_Applicant+1;
//		Co_xpath = com.getElementProperties("Fulldatacapturemaker", "Co-Applicant")+"["+m+"]";
		/*Co_xpath = com.getElementProperties("Fulldatacapturemaker", "Co-Applicant");
		logger.info("The xpath of co-applicant is : "+Co_xpath);
		wrap.click(BaseProject.driver,Co_xpath);
		logger.info("The co-applicant tab header name is : "+wrap.getElement(BaseProject.driver, Co_xpath).getText());
		logger.info("The count of co-applicant tab is/are : "+FullDataMaker.FDC_Co_Applicant);
		wrap.wait(4000);
		//wrap.captureScreenShot(BaseProject.driver, "Joint ");*/


        List<WebElement> TotNoOfApplicants = wrap.getExactAttributes(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_All_Applicants_link"));
        int TotSizeofApplicants = TotNoOfApplicants.size();
        logger.info("The size of the applicants is/are : " + TotSizeofApplicants);

        logger.info("List of applicant names given below: ");
        for (WebElement i : TotNoOfApplicants)
            logger.info(i.getText());

        //Clicking on next coapplicant
        while (FullDataMaker.fDC_Co_Applicant < TotSizeofApplicants) {
            logger.info("User is going to click on the Joint/Co-applicant/Guardian/POA Applicant");
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_All_Applicants_link"))));
           // wrap.wait(3000);
            TotNoOfApplicants.get(FullDataMaker.fDC_Co_Applicant).click();
            break;

        }


    }

    public static void fillCommonAddressfieldsjoint(int FDC_Co_Applicant) throws InterruptedException, IOException {

    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"));
    	
        wrap.wait(1000);
        try {

            logger.info("User is in Address type field in Address section");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"));
            com.suggestionTextBox2(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"),
                    "PER", DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Address Type", BaseProject.scenarioID));
			
			/*wrap.typenewSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FD_Address_AddressType_Joint"), "code", 
                    DBUtils.readColumnWithRowID(Coapp+FDC_Co_Applicant+" Address Type", BaseProject.scenarioID),DBUtils.readColumnWithRowID("Address code", BaseProject.scenarioID));*/
        } catch (Exception E) {

            wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"), "Description",
                    DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Address Type", BaseProject.scenarioID));

        }

        wrap.wait(2500);

        /*****************************Residence Type field is available for RES Address Type only***********************************/
		
		/*if(DBUtils.readColumnWithRowID(Coapp+FDC_Co_Applicant+" Address Type", BaseProject.scenarioID).equalsIgnoreCase("A1 RES")){
			
			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FD_Address_ResidenceType_Joint"), 
					DBUtils.readColumnWithRowID(Coapp+FDC_Co_Applicant+" Residence Type", BaseProject.scenarioID), "BYVISIBLETEXT");	
		}*/

        if (FullDataMaker.product.equalsIgnoreCase("CC") || FullDataMaker.product.equalsIgnoreCase("PL")) {
            logger.info("Am going to select residence type for CC account");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_ResidenceType_Joint"));
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_ResidenceType_Joint"),
                    DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Residence Type", BaseProject.scenarioID), "BYVISIBLETEXT");
        }

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine1_Joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Address Line 1", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine1_Joint"));

        wrap.wait(2500);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine2_Joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Address Line 2", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine2_Joint"));

        wrap.wait(2500);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine3_Joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Address Line 3", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine3_Joint"));

        wrap.wait(2500);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_City_Joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " City", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_City_Joint"));

        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Country_Joint"), "code",
                DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Country", BaseProject.scenarioID));

        wrap.wait(2500);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_joint"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + FDC_Co_Applicant + " Zip Code", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_joint"));
        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_joint")).sendKeys(Keys.TAB);
        wrap.wait(4000);

        //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");

        wrap.wait(2000);

    }


    /*******************
     * KYC details for Primary customers
     ***************************/
    public static void adddetailsinKYCTab(String action, String dateofdeclaration, String placeOfDeclaration, String verificationDate, String employeeName, String employeeDesignation, String verificationBranch, String employeeCode, String ckycId) throws InterruptedException, IOException {

        if (action.equalsIgnoreCase("Primary")) {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));
            wrap.typeToTextBox(BaseProject.driver, dateofdeclaration, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, placeOfDeclaration, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCPlaceOfDeclaration"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, verificationDate, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationDate"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, employeeName, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeName"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, employeeDesignation, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeDesignation"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, verificationBranch, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationBranch"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, employeeCode, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeCode"));
            wrap.wait(1500);
            wrap.typeToTextBox(BaseProject.driver, ckycId, com.getElementProperties("Fulldatacapturemaker", "FDC_CKYCID"));
            wrap.wait(1500);

        } else {

            if (action.equalsIgnoreCase("Coapplicant")) {

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentAdd"));
            }


        }
    }


    public static int noOfApplicantsindocument() throws InterruptedException, IOException {

        List<WebElement> Total_Link = wrap.getExactAttributes(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "documentCo-Applicant"));

        return Total_Link.size();
    }

    public static void switchToNextdocumentCoapplicant() throws InterruptedException, IOException {

        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.wait(1000);

        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        wrap.wait(2000);
        int m = FullDataMaker.fDC_Co_Applicant1 + 1;
        co_xpath = com.getElementProperties("Fulldatacapturemaker", "documentCo-Applicant") + "[" + m + "]";
        logger.info(co_xpath);
        wrap.click(BaseProject.driver, co_xpath);
        logger.info(wrap.getElement(BaseProject.driver, co_xpath).getText());
        logger.info(FullDataMaker.fDC_Co_Applicant1);
        wrap.wait(4000);
        //wrap.captureScreenShot(BaseProject.driver, "Joint ");


    }

    ////////////////Neethu code ends here for Co-Applicant //////////////////////////////////
    //Changes are done.


    public static void fillFATCAjoint() throws InterruptedException, IOException, ClassNotFoundException, SQLException {

        int no = FullDataMaker.fDC_Co_Applicant + 1;
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No_joint"));

        /**********************Filling FATCA section**************************/
     //   wrap.wait(3000);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No_joint"));

        WebElement ele_PSD_CRS1 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No_joint"));


        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);

        myExecutor.executeScript("arguments[0].click();", ele_PSD_CRS1);
		
		
		wrap.radioButtonSelection(BaseProject.driver, "Is_the_Customer_a_US_Resident1", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes_joint", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No_joint");
        
		wrap.radioButtonSelection(BaseProject.driver, "Is_the_customer_a_US_citizen1", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes_joint", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No_joint");
       
		wrap.radioButtonSelection(BaseProject.driver, "Is_Customer_a_Green_card_holder1", "Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes_joint", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No_joint");
        
        /*WebElement ele_PSD_us = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No_joint"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No_joint"));
        myExecutor.executeScript("arguments[0].click();", ele_PSD_us);
      //  wrap.wait(3000);
        WebElement ele_PSD_gr = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No_joint"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No_joint"));
        myExecutor.executeScript("arguments[0].click();", ele_PSD_gr);
        
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"))));*/
        com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"), "IN", DBUtils.readColumnWithRowID("FATCA_Country_of_Treaty" + no, BaseProject.scenarioID));

      /* // wrap.wait(1000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("FATCA Country of Treaty" + no, BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"));
       // wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + DBUtils.readColumnWithRowID("FATCA Country of Treaty" + no, BaseProject.scenarioID) + "')]")).click();
*/

    }

// Thiyanes-Added-22/11

    public static void fillGSTjoint() throws InterruptedException, IOException {

        /**********************Filling GST section*****************************/
     
        int no = FullDataMaker.fDC_Co_Applicant + 1;
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
		
		wrap.radioButtonSelection(BaseProject.driver, "Customer_Type1", "Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint", "FDC_GSTDetails_CustomerType_No_joint");
        
		wrap.radioButtonSelection(BaseProject.driver, "Specific_status1", "Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint", " FDC_GSTDetails_SpecificStatus_No_joint");
    }

    public static void fillCommonAddressfields_joint() throws InterruptedException, IOException {

       // wrap.wait(4500);
    	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_All_Applicants_link"))));
        int no = FullDataMaker.fDC_Co_Applicant + 1;

        try {
            /*wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j")).clear();
            com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j"),
            		DBUtils.readColumnWithRowID("Address Type" + no, BaseProject.scenarioID), "A1 RESIDENCE");*/
        	String code=DBUtils.readColumnWithRowID("Address Type" + no, BaseProject.scenarioID);
        	
        	wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j"));
        	wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j")).sendKeys("A1 RESIDENCE ADDRESS");
        	wrap.wait(1000);
        	BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'A1 Residence Address') and contains(@data-gargs,'RES')]")).click();

          
        } catch (Exception E) {

            logger.info("2nd attempt for address type");
            /*com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j"),
            		DBUtils.readColumnWithRowID("Address Type" + no, BaseProject.scenarioID), "A1 RESIDENCE");*/
            wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j"));
            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox_j")).sendKeys("A1 RESIDENCE ADDRESS");
        	wrap.wait(1000);
        	BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'A1 Residence Address') and contains(@data-gargs,'RES')]")).click();

        }

        //wrap.wait(7000);
        
       // new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType_j"))));

        /*****************************Residence Type field is available for RES Address Type only***********************************/

        if (FullDataMaker.product.equalsIgnoreCase("CC") || FullDataMaker.product.equalsIgnoreCase("PL")) {

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType_j"),
                    DBUtils.readColumnWithRowID("Residence Type" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

        }

        //wrap.wait(2000);
       // wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt_j"));
       // wrap.wait(5000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address_Line_"+no, BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt_j"));
        
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address_Line_"+no+"_2", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt_j"));
        
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address_Line_"+no+"_3", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt_j"));

        //wrap.wait(2500);
       // wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City_j"));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("City" + no, BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City_j"));

  
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Zip Code" + no, BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt_j"));
        
        
        if (FullDataMaker.product.equalsIgnoreCase("CC") || FullDataMaker.product.equalsIgnoreCase("PL")) {

        	wrap.type(BaseProject.driver, "Chennai",com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint"));
        }
		//wrap.radioButtonSelection(BaseProject.driver, "Mail_Address_Indicator1", "Fulldatacapturemaker","FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox_j", "FD_Address_IsMailingNo_Joint");
		
        /*if(DBUtils.readColumnWithRowID("Mail_Address_Indicator" + no, BaseProject.scenarioID).equalsIgnoreCase("YES"))
        {wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox_j"));}
        else{wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingNo_Joint"));}
        */
       // wrap.wait(1500);
      //  wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt_j")).sendKeys(Keys.TAB);
      //  wrap.wait(4000);

        //wrap.captureScreenShot(BaseProject.driver, "Address Section");

       // wrap.wait(2000);

    }
//Dinesh & Tanu updated as on 16 Jan
}

