package com.scb.rtob.module.test.framework.glue;

import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.text.SimpleDateFormat;  
 

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Map.Entry;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.velocity.runtime.directive.Foreach;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;






























import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.DBUtils;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;








import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;


public class FulfillmentSecureCards {
	
	
	List<String> report= new ArrayList<String>();
	List <String> reportHeaders= new ArrayList<String>();
	String expectedResult;
	String startDate;
	Date Stime;
	Date startTime;
	Date endTime;
	long executionDuration;
	Date time;
	int entry;

	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static SeleniumService seleniumService;
	public static GenieScenario genieScenario;
	//public static WebDriver driver=BaseProject.driver;
	public static String testResultsFIle;
	public static Robot r;
	public static String appId = null;
	public static WebDriverWait wait = new WebDriverWait(BaseProject.driver,30);
	public static List<HashMap<String, String>> mydata = new ArrayList<HashMap<String, String>>();
	static CommonUtils utils= new CommonUtils(); 
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static String screenShotPath = "C:/R2/Basic Screen shot";
	File file;
	Properties CONFIG ;
	private static Logger logger = Logger.getLogger(FulfillmentSecureCards.class);
	//public static WebDriverWait wait=new WebDriverWait(BaseProject.driver, 30);

	//{
		/*file = new File(System.getProperty("user.dir")+"\\src\\main\\java\\com\\standardchartered\\techm\\rtob\\config\\config.properties");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		CONFIG = new Properties();
		try {
			CONFIG.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}*/


	public static void waitunlitVisiblityOfWebElement(String attribute){
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, attribute)));

	}


	public static int convert_String_To_Number(String numStr){
		char ch[] = numStr.toCharArray();
		int sum = 0;
		//get ascii value for zero
		int zeroAscii = (int)'0';
		for(char c:ch){
		int tmpAscii = (int)c;
		sum = (sum*10)+(tmpAscii-zeroAscii);
			}
			return sum;
			}
	
	public boolean verifyTextBoxThnClick(WebDriver driver,String attribute) throws InterruptedException{
		try{
			wrap.fluentWait(driver, attribute);
			wrap.click(driver, attribute);

			while(!wrap.getElement(driver, attribute).isEnabled()){
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, attribute)));  
				if(!wrap.getElement(driver, attribute).isEnabled()){
					wrap.getElement(driver, attribute).click();
				}
			}
			return true;
		}
		catch(InvalidElementStateException e){
			logger.info(e);
			logger.info(attribute);
			verifyTextBoxThnClick(driver,attribute);
			return true;
		}
	}
	
	public static void switchFrame() throws InterruptedException {
        int Last = 0;

        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(300);
        List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
        for (WebElement frame : frames) {
            logger.info(frame.getAttribute("Name"));

        }
        //logger.info("current frame name is "+ frmName.getAttribute("id"));
        Last = frames.size() - 1;
        //string currentFrame =
        logger.info("User should switch to this frame name PegaGadget" + Last + "Ifr");

        //wdwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(Last));
        BaseProject.driver.switchTo().frame(Last);
        logger.info("User switched to this frame name PegaGadget" + Last + "Ifr");
        wrap.wait(300);
    }
	
	@When("^Validate Application Status in search page$")
	public static void search_appstatus()
			throws IOException, InterruptedException, SQLException, ClassNotFoundException {
		
		DBUtils.convertDBtoMap("fdquery");
        String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);
		
		String search=com.getElementProperties("Fullfilment", "FF_Supp_Search");
		String applicationid=com.getElementProperties("Fullfilment", "FF_Supp_AppNo_Text");
		String searchbutton=com.getElementProperties("Fullfilment", "FF_Supp_SearchButton");
		//String appNumber="IN20170808000115";
		wrap.click(BaseProject.driver, search);
		switchFrame();
		wrap.type(BaseProject.driver, appId, applicationid);
		wrap.click(BaseProject.driver, searchbutton);
		new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'"+appId+"')]")));
		BaseProject.driver.findElement(By.xpath("//a[contains(text(),'"+appId+"')]")).click();
		
		/*String appidlink = com.getElementProperties("Fullfilment", "FF_Supp_AppID");
		wrap.click(BaseProject.driver, appidlink);*/
		switchFrame();
		
		//BaseProject.driver.findElement(By.xpath("//h3[contains(text(),'Service Execution Status')]")).click();
		
		String servexecstatus= com.getElementProperties("Fullfilment", "FF_Supp_ServExecStatus");
		wrap.click(BaseProject.driver, servexecstatus);
		
		String relno=com.getElementProperties("Fullfilment", "FF_Supp_REL");
		String custno=com.getElementProperties("Fullfilment", "FF_Supp_CustNo");
		String cardno=com.getElementProperties("Fullfilment", "FF_Supp_CardNo");
		
		String relno2=wrap.getTextValue(BaseProject.driver, relno);
		String custno2=wrap.getTextValue(BaseProject.driver, custno);
		String cardno2=wrap.getTextValue(BaseProject.driver, cardno);
				
		String relno1=relno2.substring(5).trim();
		System.out.println(relno1);
		int relno3=convert_String_To_Number(relno1);
		System.out.println(relno3);
		logger.info(relno1);
		String custno1=custno2.substring(9);
		logger.info(custno1);
		String cardno1=cardno2.substring(9);
		logger.info(cardno1);
		
		/*//DB Connectivity						
	    String dbUrl ="jdbc:db2://10.112.185.56:50070/INEBBS";					
		String username ="indb2rpt";	    					
			String password ="xs3ri3s";				
			String query = "select *  from DB2INST1.REL where RELATIONSHIPNO IN ('0199385224458740')";	            
	  	    Class.forName("com.ibm.db2.jcc.DB2Driver");			
	  
	  		//Create Connection to DB		
	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
	   	
	   	System.out.println("DB Connected");
	 		//Create Statement Object		
		   Statement stmt = con.createStatement();					

				// Execute the SQL Query. Store results in ResultSet		
			ResultSet rs= stmt.executeQuery(query);							
			
			// While Loop to iterate through all data and print results		
			while (rs.next()){
				
				
				//RELNO
				String relnodb=rs.getString("RELATIONSHIPNO").trim();
        		System.out.println(relnodb);
        		//int relno4=convert_String_To_Number(relnodb);
        		//System.out.println(relno4);
        		if(relnodb==null)
        		{
        		System.out.println("RELNO is not entered");
        		logger.info("RELNO is not entered");
        			}
        		else{
       			if(relnodb.equals(relno1))
      			{
      			System.out.println("RELNO is in sync");
      			logger.info("RELNO is in sync");
      			} else{System.out.println("RELNO is not in sync");
      			logger.info("RELNO is not in sync");
      			}}
        		*/
        		/*//CUSTOMERNO
				String custnodb=rs.getString("CUSTOMERNO");
        		System.out.println(custnodb);
        		if(custnodb==null)
        		{
        		System.out.println("CUSTNO is not entered");
        		logger.info("CUSTNO is not entered");
        			}
        		else{
       			if(custnodb.equalsIgnoreCase(custno1))
      			{
      			System.out.println("CUSTNO is in sync");
      			logger.info("CUSTNO is in sync");
      			} else{System.out.println("CUSTNO is not in sync");
      			logger.info("CUSTNO is not in sync");
      			}}
        		
        		//CARDNO
				String cardnodb=rs.getString("CARDNO");
        		System.out.println(cardnodb);
        		if(cardnodb==null)
        		{
        		System.out.println("CARDNO is not entered");
        		logger.info("CARDNO is not entered");
        			}
        		else{
       			if(cardnodb.equalsIgnoreCase(cardno1))
      			{
      			System.out.println("CARDNO is in sync");
      			logger.info("CARDNO is in sync");
      			} else{System.out.println("CARDNO is not in sync");
      			logger.info("CARDNO is not in sync");
      			}}
				*/
				
		
		
		//	con.close();
			
		/*List<WebElement> irows =   BaseProject.driver.findElements(By.xpath("(//table[@class='gridTable '])[9]/tbody/tr"));     
		int iRowsCount = irows.size();     
		List<WebElement> icols =   BaseProject.driver.findElements(By.xpath("(//table[@class='gridTable '])[9]/tbody/tr/th"));     
		int iColsCount = icols.size();     
		System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
		System.out.println();      

		FileOutputStream fos = new FileOutputStream("C:\\New folder\\test.xlsx");                                 

		XSSFWorkbook wkb = new XSSFWorkbook();       
		XSSFSheet sheet1 = wkb.createSheet("DataStorage"); 
		int rowid=0;
		for (int i=1;i<=iRowsCount;i++)      
		{  
		 XSSFRow excelRow = sheet1.createRow(i);            
		for (int j=1; j<=iColsCount;j++)                    
		{           
		if (i==1)       
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("(//table[@class='gridTable '])[9]/tbody/tr["+i+"]/th["+j+"]"));             
		String  a = val.getText();            
		System.out.print(a);                        

		int cellid=0;             
		XSSFCell excelCell = excelRow.createCell(j);                  
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
		excelCell.setCellValue(a);  

		//wkb.write(fos);       
		}       
		else        
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("(//table[@class='gridTable '])[9]/tbody/tr["+i+"]/td["+j+"]"));             
		String a = val.getText();                    
		System.out.print(a);                            

		 
		XSSFCell excelCell = excelRow.createCell(j);                      
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
		excelCell.setCellValue(a);   

		//wkb.write(fos);       
		}       
		}               
		System.out.println();     
		}     
		fos.flush();     
		wkb.write(fos);     
		fos.close();  */   
		}
		
	
	@When("^Validate Application Status in search page of coapplicant$")
	public static void search_appstatus_coapplicant()
			throws IOException, InterruptedException, SQLException, ClassNotFoundException {
		
		String search=com.getElementProperties("Fullfilment", "FF_Supp_Search");
		String applicationid=com.getElementProperties("Fullfilment", "FF_Supp_AppNo_Text");
		String searchbutton=com.getElementProperties("Fullfilment", "FF_Supp_SearchButton");
		//String appNumber="IN20170725000004";
		wrap.click(BaseProject.driver, search);
		/*wrap.wait(500);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");*/
		switchFrame();
		//wrap.typeToTextBox(BaseProject.driver, appNumber, applicationid);
		wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID), applicationid);
		wrap.click(BaseProject.driver, searchbutton);
		//wrap.wait(500);
		
		String appidlink = com.getElementProperties("Fullfilment", "FF_Supp_AppID");
		wrap.click(BaseProject.driver, appidlink);
		//wrap.wait(1000);
		//wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		switchFrame();
		
		//BaseProject.driver.findElement(By.xpath("//h3[contains(text(),'Service Execution Status')]")).click();
		
		String servexecstatus= com.getElementProperties("Fullfilment", "FF_Supp_ServExecStatus");
		wrap.click(BaseProject.driver, servexecstatus);
		
		
		/*List<WebElement> relno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Create Customer')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Reference No']//span"));
		
		for(WebElement relno1: relno){
		      logger.info(relno1.getText());
		   	  System.out.println("Relationhip nos are" +relno1.getText());
		   	  String relnoss= relno1.getText().substring(5).trim();
		   	logger.info("Primary and Coapplicant relnos are"+relnoss);
		   	  
		   	  }
		
		List<WebElement> custno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Create')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Reference No']//span[contains(text(),'Cust')]"));
		for(WebElement custno1: custno){
		      logger.info(custno1.getText());
		   	  System.out.println("Relationhip nos are" +custno1.getText());
		   	String custnoss= custno1.getText().substring(9).trim();
		   	logger.info("Primary and Coapplicant custnoss are"+custnoss);
		   	  }
		
		List<WebElement> cardno=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'createAccount')]//ancestor::td[@data-attribute-name='Service Name']//following-sibling::td[@data-attribute-name='Reference No']//span"));
		for(WebElement cardno1: cardno){
		      logger.info(cardno1.getText());
		   	  System.out.println("Relationhip nos are" +cardno1.getText());
		   	String cardnoss= cardno1.getText().substring(9).trim();
		   	logger.info("Primary and Coapplicant cardnos are"+cardnoss);
		   	  }*/
		
		
		/*//DB Connectivity						
	    String dbUrl ="jdbc:db2://10.112.185.56:50070/INEBBS";					
		String username ="indb2rpt";	    					
			String password ="xs3ri3s";				
			String query = "select *  from DB2INST1.REL where RELATIONSHIPNO IN ('0199385224458740')";	            
	  	    Class.forName("com.ibm.db2.jcc.DB2Driver");			
	  
	  		//Create Connection to DB		
	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
	 
	 		//Create Statement Object		
		   Statement stmt = con.createStatement();					

				// Execute the SQL Query. Store results in ResultSet		
			ResultSet rs= stmt.executeQuery(query);							

			// While Loop to iterate through all data and print results		
			while (rs.next()){
				
				
				//RELNO
				String relnodb=rs.getString("RELATIONSHIPNO").trim();
        		System.out.println(relnodb);
        		//int relno4=convert_String_To_Number(relnodb);
        		//System.out.println(relno4);
        		if(relnodb==null)
        		{
        		System.out.println("RELNO is not entered");
        		logger.info("RELNO is not entered");
        			}
        		else{
       			if(relnodb.equals(relno1))
      			{
      			System.out.println("RELNO is in sync");
      			logger.info("RELNO is in sync");
      			} else{System.out.println("RELNO is not in sync");
      			logger.info("RELNO is not in sync");
      			}}
        		
        		//CUSTOMERNO
				String custnodb=rs.getString("CUSTOMERNO");
        		System.out.println(custnodb);
        		if(custnodb==null)
        		{
        		System.out.println("CUSTNO is not entered");
        		logger.info("CUSTNO is not entered");
        			}
        		else{
       			if(custnodb.equalsIgnoreCase(custno1))
      			{
      			System.out.println("CUSTNO is in sync");
      			logger.info("CUSTNO is in sync");
      			} else{System.out.println("CUSTNO is not in sync");
      			logger.info("CUSTNO is not in sync");
      			}}
        		
        		//CARDNO
				String cardnodb=rs.getString("CARDNO");
        		System.out.println(cardnodb);
        		if(cardnodb==null)
        		{
        		System.out.println("CARDNO is not entered");
        		logger.info("CARDNO is not entered");
        			}
        		else{
       			if(cardnodb.equalsIgnoreCase(cardno1))
      			{
      			System.out.println("CARDNO is in sync");
      			logger.info("CARDNO is in sync");
      			} else{System.out.println("CARDNO is not in sync");
      			logger.info("CARDNO is not in sync");
      			}}
				
				
		}
		
			con.close();*/
		
		List<WebElement> irows =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'ServiceExecutionStatus')]/tbody/tr"));     
		int iRowsCount = irows.size();     
		List<WebElement> icols =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'ServiceExecutionStatus')]/tbody/tr/th"));     
		int iColsCount = icols.size();     
		System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
		System.out.println();      

		FileOutputStream fos = new FileOutputStream("C:\\New folder\\test.xlsx");                                 

		XSSFWorkbook wkb = new XSSFWorkbook();       
		XSSFSheet sheet1 = wkb.createSheet("CustAcctSetup"); 
		int rowid=0;
		for (int i=1;i<=iRowsCount;i++)      
		{  
		 XSSFRow excelRow = sheet1.createRow(i);            
		for (int j=1; j<=iColsCount;j++)                    
		{           
		if (i==1)       
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'ServiceExecutionStatus')]/tbody/tr["+i+"]/th["+j+"]"));             
		String  a = val.getText();            
		System.out.print(a); 
		logger.info("Header titles are" +a);

		int cellid=0;             
		XSSFCell excelCell = excelRow.createCell(j);                  
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
		excelCell.setCellValue(a);  

		//wkb.write(fos);       
		}       
		else        
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'ServiceExecutionStatus')]/tbody/tr["+i+"]/td["+j+"]"));             
		String a = val.getText();                    
		System.out.print(a);                            
		logger.info("table values are" +a);
		 
		XSSFCell excelCell = excelRow.createCell(j);                      
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
		excelCell.setCellValue(a);   

		//wkb.write(fos);       
		}       
		}               
		System.out.println();     
		}     
		fos.flush();     
		wkb.write(fos);     
		fos.close();     
		}
	
	@When("^Read Banking service table$")
	public static void Bann_Service_table()
			throws IOException, InterruptedException, SQLException, ClassNotFoundException {
		
		List<WebElement> irows =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'TemporaryProductsList')]/tbody/tr"));     
		int iRowsCount = irows.size();     
		List<WebElement> icols =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'TemporaryProductsList')]/tbody/tr/th"));     
		int iColsCount = icols.size();     
		System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
		System.out.println();      

		FileOutputStream fos = new FileOutputStream("C:\\New folder\\test1.xlsx");                                 

		XSSFWorkbook wkb = new XSSFWorkbook();       
		XSSFSheet sheet1 = wkb.createSheet("BankingService"); 
		int rowid=0;
		for (int i=1;i<=iRowsCount;i++)      
		{  
		 XSSFRow excelRow = sheet1.createRow(i);            
		for (int j=1; j<=iColsCount;j++)                    
		{           
		if (i==1)       
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'TemporaryProductsList')]/tbody/tr["+i+"]/th["+j+"]"));             
		String  a = val.getText();            
		System.out.print(a); 
		logger.info("Header titles are" +a);

		int cellid=0;             
		XSSFCell excelCell = excelRow.createCell(j);                  
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
		excelCell.setCellValue(a);  

		//wkb.write(fos);       
		}       
		else        
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop,'TemporaryProductsList')]/tbody/tr["+i+"]/td["+j+"]"));             
		String a = val.getText();                    
		System.out.print(a);                            
		logger.info("table values are" +a);
		 
		XSSFCell excelCell = excelRow.createCell(j);                      
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
		excelCell.setCellValue(a);   

		//wkb.write(fos);       
		}       
		}               
		System.out.println();     
		}     
		fos.flush();     
		wkb.write(fos);     
		fos.close(); 
		
	}
	
	@When("^Read cheque book status table$")
	public static void cheque_book_status()
			throws IOException, InterruptedException, SQLException, ClassNotFoundException {
		
		List<WebElement> irows =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop_class,'Data-ChequeOrder')]/tbody/tr"));     
		int iRowsCount = irows.size();     
		List<WebElement> icols =   BaseProject.driver.findElements(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop_class,'Data-ChequeOrder')]/tbody/tr/th"));     
		int iColsCount = icols.size();     
		System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
		System.out.println();      

		FileOutputStream fos = new FileOutputStream("C:\\New folder\\test2.xlsx");                                 

		XSSFWorkbook wkb = new XSSFWorkbook();       
		XSSFSheet sheet1 = wkb.createSheet("chequeorder"); 
		int rowid=0;
		for (int i=1;i<=iRowsCount;i++)      
		{  
		 XSSFRow excelRow = sheet1.createRow(i);            
		for (int j=1; j<=iColsCount;j++)                    
		{           
		if (i==1)       
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop_class,'Data-ChequeOrder')]/tbody/tr["+i+"]/th["+j+"]"));             
		String  a = val.getText();            
		System.out.print(a); 
		logger.info("Header titles are" +a);

		int cellid=0;             
		XSSFCell excelCell = excelRow.createCell(j);                  
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
		excelCell.setCellValue(a);  

		//wkb.write(fos);       
		}       
		else        
		{           
		WebElement val= BaseProject.driver.findElement(By.xpath("//table[contains(@class,'gridTable') and contains(@pl_prop_class,'Data-ChequeOrder')]/tbody/tr["+i+"]/td["+j+"]"));             
		String a = val.getText();                    
		System.out.print(a);                            
		logger.info("table values are" +a);
		 
		XSSFCell excelCell = excelRow.createCell(j);                      
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
		excelCell.setCellValue(a);   

		//wkb.write(fos);       
		}       
		}               
		System.out.println();     
		}     
		fos.flush();     
		wkb.write(fos);     
		fos.close(); 
		
	}

	@When("^FF: Read Excel$")
	public static void readExcelFF() throws Throwable {
	utils.convertExcelToMap(excelPath,"FFSupp.xls","Sheet1");

		//String Titles = utils.readColumnWithRowID("Title",ProductCatalogue.scenarioID);
	}
	
}
	

