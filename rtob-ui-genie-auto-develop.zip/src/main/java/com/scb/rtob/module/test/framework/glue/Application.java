package com.scb.rtob.module.test.framework.glue;

/***************************************************************************************
Project Name: RTOB - Base Project
Author: 
Version: V 1.0
Date of Creation: 17th March 2017
Modified By:
Reviewed By:
***************************************************************************************/
import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.awt.*;
import java.io.File;

import org.openqa.selenium.Dimension;

import java.net.URL;

import com.scb.rtob.module.test.utils.DBUtils;

import org.apache.log4j.Logger;
import org.apache.xerces.impl.io.MalformedByteSequenceException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.SeleniumModule;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
//import com.standardchartered.techm.rtob.module.rtob.Read_xls;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.framework.XMLParser;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.scb.rtob.module.test.framework.XMLParser.envName;

public class Application {
	
	static List<String> reportOrder= new ArrayList<String>();
	List <String> reportHeadersOrder= new ArrayList<String>();
	public static String testResultsFIleOrder;
	
	public static List<String> reportFieldVals= new ArrayList<String>();
	public static String testResultsFieldVals;

	List<String> report= new ArrayList<String>();
	List <String> reportHeaders= new ArrayList<String>();
	String expectedResult;
	String startDate;
	Date Stime;
	Date startTime;
	Date endTime;
	long executionDuration;
	Date time;
	int entry;
	
	public static String propertiesFilename = "BasicData";
	
	static String scenarioID = null;
	static boolean resultSet = false;
	static boolean resultOrderSet = false;
	static boolean resultOrderHeaderSet = false;
	static boolean resultFieldValSet = false;
	static boolean resultFieldValHeaderSet = false;
	static String ModuleName = null;
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static SeleniumService seleniumService;
	public static GenieScenario genieScenario;
	public static WebDriver driver=BaseProject.driver;
	public static String testResultsFIle;
	public static Robot r;
	public static String appId = null;
	CommonUtils utils= new CommonUtils(); 
	public static String excelPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"ExcelData";



//	public static String excelPath="C:"+File.separator+"BitBucket"+File.separator;
	public static String autoItPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"autoit";
	//public static String scenarioID="01";
	File file;
	private String actualresult;
	static Properties CONFIG ;
	static BusinessCommonUtils businesscommonutils= new BusinessCommonUtils();
	
	public static String UATExpectedResult=null;
	public static String UATTestCaseDescription=null;
	public static String UATTestScenarioID=null;
	
	//public static RemoteWebDriver driver;
	String browserType="chrome";
    DesiredCapabilities dr=null;
	public static String filepath=null;
	static HashMap<String, String> envmap= new HashMap<String, String>();
	
	private static Logger logger = Logger.getLogger(Application.class);

	public Application()
	{	

		String envName = System.getProperty("env");
		logger.info("envName is " + envName);
		URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
		if (resource == null) {
			logger.info("resource is null");
			System.exit(1);
		}
			File file = null;
		FileInputStream fis = null;
		try {
		//	assert resource != null;
			if (resource != null) {
				file = new File(resource.toURI());
			}
			fis = new FileInputStream(file);
		} catch (FileNotFoundException | URISyntaxException e) {
			e.printStackTrace();
		}


		try {
		//	assert file != null;
			if (file != null) {
				fis = new FileInputStream(file);
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		Properties ENVCONFIG = new Properties();
		try {
			ENVCONFIG.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}

		for (String key : ENVCONFIG.stringPropertyNames()) {
			String value = ENVCONFIG.getProperty(key);;
			envmap.put(key, value);
		}

	}
	public static void switchFrame() throws InterruptedException 
	{
        int Last = 0;

        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(300);
        List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
        for (WebElement frame : frames) {
            logger.info(frame.getAttribute("Name"));

        }
        //logger.info("current frame name is "+ frmName.getAttribute("id"));
        Last = frames.size() - 1;
        //string currentFrame =
        logger.info("User should switch to this frame name PegaGadget" + Last + "Ifr");

        //wdwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(Last));
        BaseProject.driver.switchTo().frame(Last);
        logger.info("User switched to this frame name PegaGadget" + Last + "Ifr");
        wrap.wait(300);
    }

	
	@Given("^Search App ref and submit in respective WB$")
	public void searchApplicationIdinworkbasket() throws Throwable 
	{

		wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "Search_link_XPATH"));		
		
		wrap.wait(4000);
				
		switchFrame();
		
		String applicationId ="//input[@id='ApplicationRefNo']";
		
		String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);

        BaseProject.appId = appId.trim();
		
        logger.info("AppId ==== "+appId);
    
        wrap.type(BaseProject.driver, appId, applicationId);
        
        String searchbutton=com.getElementProperties("Fulldatacapturemaker", "SearchButton");
		
		wrap.click(BaseProject.driver, searchbutton);

		String moreInfobutton=com.getElementProperties("Fulldatacapturemaker", "MoreInfo");
		
		new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(moreInfobutton)));
		
		wrap.click(BaseProject.driver, moreInfobutton);
		
		
		
		String  workBasket="//table[@pl_prop_class='SCB-FW-AppWorkFlowFW-Data-Search-Result']//tr[2]//td[2]";
		
		for(int y=0;y<7;y++)
		
		new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(workBasket)));
		String workBasketName=Wrapper.getTextValue(BaseProject.driver, workBasket);
		logger.info("Workbasket name : "+workBasketName);
			
		String closeContainer="//button[@id='container_close' and @title='close modal']";
		
		new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(closeContainer)));
		
		wrap.click(BaseProject.driver, closeContainer);
		
		logoutall();
		
		if(workBasketName.equals("Basic Data Capture Maker")) 
			BaseProject.enter_valid_credentails("basic_username","basic_password");
			
		else if(workBasketName.equals("Blind Data Capture Maker")) 
			BaseProject.enter_valid_credentails("blind_username","blind_password");
		
		else if(workBasketName.equals("Full Data Capture Maker")) 
			BaseProject.enter_valid_credentails("fulldatamaker_username","fulldatamaker_password");
		
		
		 wrap.switch_to_default_Content(BaseProject.driver);

	        try {
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
	            wrap.getWorkbasketoption(BaseProject.driver, workBasketName);
	            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
			
	        FullDataMaker.select_an_application_number();
	        
	        FullDataMakerUtils.switchToCustomerDetailsTab();     
	        
	        String Submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
	        
	        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(Submit)));
	        
	        wrap.scroll_to(BaseProject.driver,Submit); 
	        wrap.click(BaseProject.driver, Submit);
	    
		
}
	@When("^Logout all$")
    public void logoutall() throws IOException, InterruptedException
    {
          boolean visi_logout=false,peggalogout=false;
          wrap.switch_to_default_Content(driver);
          visi_logout = wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).isDisplayed();
          if (visi_logout==true)
          {
                 wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).click();
                 System.out.println("User logged out successfully");
                 wrap.wait(3000);
          }
        
    }

	

}
