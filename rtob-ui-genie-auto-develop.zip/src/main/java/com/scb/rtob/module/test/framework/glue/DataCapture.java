package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class DataCapture {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Dinesh Space\\RTOB API FrameWork\\Hemant sent project link\\drivers\\chrome\\2.26\\chromedriver.exe");
		String URL = "https://confluence.global.standardchartered.com/display/RTO/Data+Capture";
		
		WebDriver driver = new ChromeDriver();
		driver.get(URL);
		
		String username = "1567264";
		String password = "Ram3sita#";
		int rowCount = 0;
		//Creating POI Workbook
		XSSFWorkbook wb1 = new XSSFWorkbook();
		
		
		
		//LOGIN
		driver.findElement(By.id("os_username")).sendKeys(username);		
		driver.findElement(By.id("os_password")).sendKeys(password);
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(5000);
		
		//**********USER-INPUT***************//
		//Provide the VISIBLE text in textString i.e. India>IN Releases>R1.1>On boarding>Data Capture><<BDM or BLM>>
		String textString = "Basic Data Maker (BDM)";
		//**********USER-INPUT***************//
		
		//String textString = "Basic Data Maker (BDM)";Full Data Maker
		String RootNodeLocator = "//a[text()=\'"+textString+"\']";
		WebElement SheetName = driver.findElement(By.xpath(RootNodeLocator));
		SheetName.findElement(By.xpath("preceding::div[1]/a")).click();
		String NameOfSheet = SheetName.getText();
		Thread.sleep(5000);
		
		XSSFSheet sh1 = wb1.createSheet(NameOfSheet);
		String TabNameCol = RootNodeLocator+"/ancestor::div[1]/following-sibling::div/ul/li";
		//ChildNode expand-icon click
		List <WebElement> TabNames = driver.findElements(By.xpath(TabNameCol));
		int TabNamesSize = TabNames.size();
		System.out.println(TabNamesSize);
		int main_loop_flag=1;
		
		while(main_loop_flag <=TabNamesSize){
			WebElement TabName = null;
			String TabNameLoc = TabNameCol+"["+main_loop_flag+"]/div[2]/span/a";
			//String TabNameLoc = TabNameCol+"/span/a";
			TabName = driver.findElement(By.xpath(TabNameLoc));
			String TabNameString = TabName.getText();
			System.out.println(TabNameString);
			TabName.click();
			Thread.sleep(5000);
		
		
			String sectionString = TabNameLoc+"[text()=\'"+TabNameString+"\']/ancestor::div[1]/following-sibling::div/ul/li/div[2]";
			List <WebElement> section = driver.findElements(By.xpath(sectionString));
			int loop = section.size();
			System.out.println(loop);
			WebElement sectionName = null;
			int loop_flag = 1;
			while (loop_flag <= loop){
				
				String subnode_we_loc = "//a[text()=\'"+TabNameString+"\']/ancestor::div[1]/following-sibling::div/ul/li["+loop_flag+"]/div[2]/span/a";
				sectionName = driver.findElement(By.xpath(subnode_we_loc));
				
					
				String SectionLinkName = sectionName.getText();
				System.out.println(SectionLinkName);
				
				sectionName.click();
				Thread.sleep(5000);
			

				rowCount = readHTMLTable(sh1, driver,0, rowCount, SectionLinkName, TabNameString);
	
			//rowCount = readConfluenceTable(sh1, driver, rowCount);
			rowCount++;
			Thread.sleep(5000);
			loop_flag++;
		}
			main_loop_flag++;
									
		}
		writeToExcel(wb1,NameOfSheet);
		wb1.close();
		
		//driver.findElement(By.xpath("//a[text()='Basic Data Maker (BDM)']/preceding::div[1]/a")).click();
		
		
		
		driver.close();
	}

	
	
	public static int readHTMLTable(XSSFSheet Buffersheet, WebDriver driver, int flag, int rowCountBuffer, String SectionName, String TabName){
		
		
		int columnCount = 0;
		
		//WebElement table = driver.findElement(By.xpath("//div[@class='table-wrap']"));
		if (flag == 0){
			XSSFRow rowHeader = Buffersheet.createRow(rowCountBuffer);
			rowHeader.createCell(columnCount).setCellValue("TabName");
			columnCount++;
			rowHeader.createCell(columnCount).setCellValue("SectioNName");
			columnCount++;
			List <WebElement> RTOBTableHeader = driver.findElements(By.xpath("//div[@class='table-wrap']/table/thead[1]/tr"));
			for (WebElement header:RTOBTableHeader){
			
				
				List<WebElement> columnHeader = header.findElements(By.xpath("th"));
				for (WebElement HeaderValue : columnHeader){
					
					String HtmlCellValue = HeaderValue.getText();
					XSSFCell headercell = rowHeader.createCell(columnCount);
					headercell.setCellValue(HtmlCellValue);
					columnCount++;
				}
				columnCount = 0;
			}
			
		}
		
	
		List <WebElement> RTOBTable = driver.findElements(By.xpath("//div[@class='table-wrap']/table/tbody/tr"));
		
		for (WebElement rows : RTOBTable){

			rowCountBuffer ++;
			XSSFRow row = Buffersheet.createRow(rowCountBuffer);
			//row.createCell(rowCountBuffer).setCellValue(SectionName);
			List <WebElement> columns = rows.findElements(By.xpath("td"));
			XSSFCell cell_TabName = row.createCell(columnCount);
			cell_TabName.setCellValue(TabName);
			columnCount++;
			XSSFCell cell_SectionName = row.createCell(columnCount);
			cell_SectionName.setCellValue(SectionName);
			columnCount++;
			for (WebElement bufferValue : columns){
				
				String cellValue = bufferValue.getText();
				XSSFCell cell = row.createCell(columnCount);
				cell.setCellValue(cellValue);
				columnCount++;
				
			}
			columnCount = 0;
						
		}
		return rowCountBuffer;
		
		
	}
	
	
	public static void writeToExcel (XSSFWorkbook wbBuffer, String fileName) throws IOException{
		    
		FileOutputStream OutputFile = new FileOutputStream(new File("C:/Dinesh Space/RTOB API FrameWork/" + fileName + ".xlsx"));
		wbBuffer.write(OutputFile);
		wbBuffer.close();
		OutputFile.close();
				
	}
}


