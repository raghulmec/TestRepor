/*************************************************************************************
 * Module   : Full Data Capture Maker
 * Author   : Balaji, Dinesh and Neethu
 * Date     : June 29th
 * Reviewer :
 *************************************************************************************/

package com.scb.rtob.module.test.framework.glue;

import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cucumber.api.java.en.And;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
//import com.standardchartered.techm.rtob.module.rtob.glue.FullDataMakerObjects;


import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FullDataMaker {

    public static Logger logger = Logger.getLogger(FullDataMaker.class);

    //Priya	UAT TEST CASES
    public static ArrayList<String> resListOfValues = new ArrayList<String>();
    public static List<WebElement> perListOfValues = new ArrayList<WebElement>();

    public static String addressType, addressLine1, addressLine2, addressLine3, cityName, country, zipCode, state, area;
    /**********************************/

    public static int fDC_Co_Applicant = 0, fDC_Co_Applicant1 = 0;

    public static String prdCat = "CREDIT CARD";

    public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
    static Wrapper wrap = new Wrapper();
    static Commons com = new Commons();

    static CommonUtils utils = new CommonUtils();
    public static String excelPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ExcelData";

    public static String product = "CC";
    public static String productName = "";
    public static String applicantType = "";
    public static String jointType = "Co-Applicant";
    //	public static int fDC_Co_Applicant = 1;
    public static int fDC_Multiple_Product = 1;
    public static String mar_status = "";
    public static String mar_Sta_joint = "";
    public static String productcode = "";
    //static FullDataMakerObjects FDMObjects = new FullDataMakerObjects();

    //Neethu code below two line declaration for co-applicant
//		public static int fDC_Co_Applicant = 1,fDC_Co_Applicant1=0;
    public static String coapp = "Coapp";

    //Balaji code 1 line below
    public static String propertiesFilename = "Fulldatacapturemaker";

    /*******************
     * Workbasket Selection code
     *****************************/

    @Given("^Go to Full data Capture Maker home page$")
    public void go_to_Full_data_Capture_home_page() throws Throwable {

        wrap.switch_to_default_Content(BaseProject.driver);

        try {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
            wrap.getWorkbasketoption(BaseProject.driver, "Full Data Capture Maker");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //**************************************** Application Selection code***************

    @Then("^Full Data: select an application number$")
    public static void select_an_application_number()
            throws IOException, InterruptedException, ClassNotFoundException, SQLException {

	       /*DBUtils.convertDBtoMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
           String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);*/
        wrap.wait(5000);

        String appId = DBUtils.readColumnWithRowID("ApplicationID", BaseProject.scenarioID);

        BaseProject.appId = appId.trim();

        logger.info("The Value going to select or Filter is [" + appId + "]");
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
        wrap.wait(2000);
        String filter = com.getElementProperties("Fulldatacapturemaker",
                "filter_link");
        String search = com.getElementProperties("Fulldatacapturemaker",
                "search_text");
        String apply_button = com.getElementProperties("Fulldatacapturemaker",
                "apply_button");
        //wrap.wait(2000);
        wrap.click(BaseProject.driver, filter);
        wrap.wait(1000);
        wrap.typeToTextBox(BaseProject.driver, appId, search);
        wrap.wait(1000);
        wrap.click(BaseProject.driver, apply_button);

        wrap.wait(3000);

	      /* WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
           ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);*/
        switchFrame();

        wrap.wait(3000);

        try {
            BaseProject.driver.findElement(By.xpath("//div[@id='HARNESS_CONTENT']//table/tbody/tr[1]/td/div/table/tbody/tr[2]/td/div/span[text()='" + appId + "']")).click();
        } catch (Exception e) {
            BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
        }


    }


    public static boolean verifyTextBoxThnClick(WebDriver driver, String attribute) throws InterruptedException {
        try {
            wrap.fluentWait(driver, attribute);
            wrap.click(driver, attribute);

            while (!wrap.getElement(driver, attribute).isEnabled()) {
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, attribute)));
                if (!wrap.getElement(driver, attribute).isEnabled()) {
                    wrap.getElement(driver, attribute).click();
                }
            }
            return true;
        } catch (InvalidElementStateException e) {
            logger.info(e);
            logger.info(attribute);
            verifyTextBoxThnClick(driver, attribute);
            return true;
        }
    }


    //*******************Start of step definitions for Customer Details tab**********************/

    @Then("^FDM : Fill Customer Personal Detail section in Customer Details Tab$")
    public static void fillCustomerPersonalDetailSections() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

        FullDataMakerUtils.switchToProductDetailsTab();

        //wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCategory_txt"), 20);
        String prdCat = com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCategory_txt"));

        if (prdCat.equalsIgnoreCase("PERSONAL LOAN")) {
            product = "PL";
            logger.info("The product code is assigned as PL");
        } else if (prdCat.equalsIgnoreCase("CREDIT CARD")) {
            product = "CC";
            logger.info("The product code is assigned as CC");
        } else if (prdCat.equalsIgnoreCase("SAVINGS ACCOUNT")) {
            product = "SA";
            logger.info("The product code is assigned as SA");
        } else if (prdCat.equalsIgnoreCase("CURRENT ACCOUNT")) {
            product = "CA";
            logger.info("The product code is assigned as CA");
        } else {
            product = "TD";
            logger.info("The product code is assigned as TD");
        }


        /*******Swtiching to Customer Details Tab*********/

        FullDataMakerUtils.switchToCustomerDetailsTab();
        
        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_PD_CustomerDetails_Link")));

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

        /*******Filling Personal Details section in Customer Details Tab*********/
        
        logger.info("The given scenario id is : " + BaseProject.scenarioID);
        //wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown"), 20);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown"),
                DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown"),
                DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID), "BYVISIBLETEXT");

       /* String val = DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID);
        logger.info("Martial status value of DB is : "+ val);
       String data_type = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown")).getAttribute("data-ctl");
       logger.info("Data type of dropdown is : "+data_type);
        if(val.contains("Please Select"))
        {
        	wrap.elementTabOut(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown"));
        	String varpath = com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown");
        	varpath = varpath+"/following-sibling::div/span";
        	logger.info("The negative xpath is : "+varpath);
        	String negval = wrap.getTextValue(BaseProject.driver, varpath);
        	if(negval.contains("Value cannot"))
        	{
        	    logger.info("inline error message is displayed as " + negval);
        		
        	}
        	
        }*/
//        wrap.wait(1000);
//        Select ms = new Select(wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown")));
//        mar_status = ms.getFirstSelectedOption().getText();

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Qualification_DropDown"),
                DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Place Of Birth", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Placeofbirth_TextBox"));
        
        JavascriptExecutor jse1 = (JavascriptExecutor)BaseProject.driver;
        jse1.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDCMaker_CustDemiseDate")));
        
       // wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCMaker_Authcode"));

        //wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CustomerDemiseDate", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDCMaker_CustDemiseDate"));
        
        wrap.wait(500);
        BaseProject.driver.findElement(By.xpath("//input[@id='CustomerDemiseDate']")).click();
        wrap.wait(500);
        BaseProject.driver.findElement(By.xpath("//input[@id='CustomerDemiseDate']")).sendKeys(DBUtils.readColumnWithRowID("CustomerDemiseDate", BaseProject.scenarioID));
        
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Authentication Mode", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDCMaker_Authcode"));

        //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail");

        switch (product) {

            case "CA":
            case "SA":
                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"));
                //wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");
                break;

            case "TD":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"),
                        DBUtils.readColumnWithRowID("Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),
                        DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                break;

            case "CC":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"),
                        DBUtils.readColumnWithRowID("Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

              //  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),
                        DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("No Of Dependants", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_NoOfDependants_textbox"));

                wrap.wait(2000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_dropdown"),
                        DBUtils.readColumnWithRowID("Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(2000);
                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail");
                break;

            case "PL":

            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"),
                        DBUtils.readColumnWithRowID("Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

              //  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),
                        DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("No Of Dependants", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_NoOfDependants_textbox"));

                wrap.wait(2000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_dropdown"),
                        DBUtils.readColumnWithRowID("Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(2000);
                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail");
                break;

        }

    }

    @Then("^FDM : Fill Alias and Related Party sections in Customer Details Tab$")
    public static void fillAliasRelatedPartySections() throws IOException, InterruptedException {

        switch (product) {

            case "CA":


//                String linkRelationshipNumber = DBUtils.readColumnWithRowID("Relationship Number", BaseProject.scenarioID);
//
//                JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
//
//                WebElement w = BaseProject.driver.findElement(By.xpath("//input[@id='RelatedPartyRelNumber']"));

            	JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                jse.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedParty_HouseholdID")));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("HouseholdID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedParty_HouseholdID"));

//                js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", w, "value", linkRelationshipNumber);

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedPartySection_LinkRelationshipNumber_txt"));

               // wrap.wait(2000);
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedPartySection_LinkRelationshipNumber_txt"))));

                //wrap.captureScreenShot(BaseProject.driver, "Alias and Related Party Section");

                break;

            case "SA":
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("HouseholdID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedParty_HouseholdID"));

                wrap.type(BaseProject.driver, "0199385224856121",
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedPartySection_LinkRelationshipNumber_txt"));

                //wrap.wait(2000);
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedPartySection_LinkRelationshipNumber_txt"))));

                //wrap.captureScreenShot(BaseProject.driver, "Alias and Related Party Section");
                break;


            case "TD":

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("HouseholdID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedParty_HouseholdID"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_RelatedPartySection_LinkRelationshipNumber_txt"));

                //wrap.captureScreenShot(BaseProject.driver, "Alias and Related Party Section");
                break;

            case "CC":


                break;

            case "PL":

                break;

        }

    }

    @Then("^FDM : Fill Contact and Address section in Customer Details Tab$")
    public static void fillcontactAddressSection() throws IOException, InterruptedException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
        /**********************************Filling Contact section********************************************/
        //wrap.wait(2000);
        /*if(!wrap.getElement(BaseProject.driver,
                com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_PrefferedContact_CheckBox")).isSelected())
		{

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_PrefferedContact_CheckBox"));
			wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_PrefferedContact_CheckBox")).sendKeys(Keys.TAB);
	        wrap.wait(3000);
	    }*/


        /**********************************Filling Address section********************************************/

        FullDataMakerUtils.fillCommonAddressfields();

        switch (product) {

            case "CA":
            	wrap.radioButtonSelection(BaseProject.driver, "Customer Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "SA":
                //Changes - SA - Need to have State field and copy remaining available fields from case CC part
				wrap.radioButtonSelection(BaseProject.driver, "Customer Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "TD":
				wrap.radioButtonSelection(BaseProject.driver, "Customer Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
                wrap.radioButtonSelection(BaseProject.driver, "Address1_Permanent Address same as Residential Address", "Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes", "FDC_CD_AddressSection_Residential_Address_No");
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "CC":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
               
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
               
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY1", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year"));
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM1", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month"));
                
				wrap.radioButtonSelection(BaseProject.driver,  "Address1_Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
                
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
               
				wrap.radioButtonSelection(BaseProject.driver,"Address1_Permanent Address same as Residential Address", "Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes", "FDC_CD_AddressSection_Residential_Address_No");
                                
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "PL":

            	 /*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
                 
                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));*/
                
                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year"));
                 
                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM", BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month"));
                 
 				wrap.radioButtonSelection(BaseProject.driver,  "Address1_Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
                 
                 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
                
 				wrap.radioButtonSelection(BaseProject.driver,"Address1_Permanent Address same as Residential Address", "Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes", "FDC_CD_AddressSection_Residential_Address_No");
                                 
                 //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                 break;

        }

    }

    @Then("^FDM : Fill Communication sections in Customer Details Tab$")
    public static void fillCommunicationSections() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

        /**********************************Filling Communication section********************************************/

    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));
    	
        com.suggestionTextBox3(BaseProject.driver,
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"),
                DBUtils.readColumnWithRowID("Advice Detail Address Type", BaseProject.scenarioID),"Mailing address63");
       // wrap.wait(2000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_MarketingPreferences_dropdown"),
                DBUtils.readColumnWithRowID("Marketing Preferences", BaseProject.scenarioID), "BYVISIBLETEXT");

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
      //  //wrap.captureScreenShot(BaseProject.driver, "Communication Section");
    }

    @Then("^FDM : Fill Employment section in Customer Details Tab$")
    public static void fillEmploymentSection() throws IOException, InterruptedException {

        FullDataMakerUtils.switchToCustomerDetailsTab();

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
    	
    	JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView();",wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType")));

        switch (product) {

            case "CA":
                //FDC_CD_Employment_Occupation

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"),
                        DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
           
                /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));*/

                /*if (DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID) != "Self-Employed/Business Owner") {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
                    wrap.wait(1000);
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"));
                    wrap.wait(1500);
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                            DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName"),
                            "code", DBUtils.readColumnWithRowID("Employer Name", BaseProject.scenarioID));
                }*/


            //    //wrap.captureScreenShot(BaseProject.driver, "Employment Section");

                break;

            case "SA":

                //FullDataMakerUtils.selectWorkType();
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
//                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"),
//                        DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
//                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType")).sendKeys(Keys.TAB);
                wrap.type(BaseProject.driver, "0199385224856121",
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));


			    /* wrap.wait(1000);
			     wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_StaffCategory_DropDown"),
							DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
			     wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_StaffCategory_DropDown")).sendKeys(Keys.TAB);*/

		    	/*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Employer Relationship ID", BaseProject.scenarioID),
			    		 com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));*/

//                wrap.wait(1000);
//                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"));
//                wrap.wait(1500);
//                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
//                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
//
//                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName"),
//                        "code", DBUtils.readColumnWithRowID("Employer Name", BaseProject.scenarioID));
        //        //wrap.captureScreenShot(BaseProject.driver, "Employment Section");

                break;

            case "TD":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
             //   wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"),
                        DBUtils.readColumnWithRowID("Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType")).sendKeys(Keys.TAB);

              //  wrap.wait(1000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"),
                        DBUtils.readColumnWithRowID("Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName"),
                        "code", DBUtils.readColumnWithRowID("Employer Name", BaseProject.scenarioID));

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");

                break;

            case "CC":
            	
				wrap.radioButtonSelection(BaseProject.driver, "Payroll Indicator", "Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes", "FDC_CPD_Payrollindicator_no");
            	FullDataMakerUtils.selectWorkType();

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

            case "PL":
            	
				wrap.radioButtonSelection(BaseProject.driver, "Payroll Indicator", "Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes", "FDC_CPD_Payrollindicator_no");
            	FullDataMakerUtils.selectWorkType();

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

        }


    }

    @Then("^FDM : Fill FATCA and GST sections in Customer Details Tab$")
    public static void fillFATCAandGSTSections() throws IOException, InterruptedException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
    	//FullDataMakerUtils.switchToCustomerDetailsTab();
        switch (product) {

            case "CA":

                FullDataMakerUtils.fillFATCA();
                FullDataMakerUtils.fillGST();

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber"));
                //wrap.captureScreenShot(BaseProject.driver, "FATCA & GST Section");

                break;

            case "SA":

                FullDataMakerUtils.fillFATCA();
                FullDataMakerUtils.fillGST();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber"));
                }
//                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State", BaseProject.scenarioID),
//                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State"));
                //wrap.captureScreenShot(BaseProject.driver, "FATCA & GST Section");
                break;

            case "TD":

                FullDataMakerUtils.fillFATCA();
                FullDataMakerUtils.fillGST();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber"));
                }
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State"));
                //wrap.captureScreenShot(BaseProject.driver, "FATCA & GST Section");

                break;

            case "CC":
                FullDataMakerUtils.fillGST();

                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber"));
                }
               /* wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State"));*/

                //wrap.captureScreenShot(BaseProject.driver, "GST Section");

                break;

            case "PL":
                FullDataMakerUtils.fillGST();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber"));
                }
                /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State"));*/

                //wrap.captureScreenShot(BaseProject.driver, "GST Section");
                break;

        }

    }

    @Then("^FDM : Fill Document details section in Customer Details Tab$")
    public static void fillDocumentSection() throws IOException, InterruptedException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

        FullDataMakerUtils.addDocumentInCustomerTab("Select",
                DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID),
                DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID),
                DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID)
        );

    }

    @Then("^FDM : Fill CDD and Internal sections in Customer Details Tab$")
    public static void fillCDDInternalSections() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

        /**********************Filling CDD section**********************************/


		/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_typeOfInitalFund"),
				DBUtils.readColumnWithRowID("Type(s) of initial funding", BaseProject.scenarioID), "BYVISIBLETEXT");

		wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Amount of Initial Funding", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_amountOfInitalFund"));

		wrap.enterDate(BaseProject.driver,DBUtils.readColumnWithRowID("Date initial funding is expected to be placed", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_dateInitilaFund"));*/


    	//wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"));
    	
        switch (product) {

            case "CA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"));

                wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"), DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_descriptionOfInitalFund"));

                /**********************Filling Internal section*****************************/
                
                wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"));
              
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"),
                        DBUtils.readColumnWithRowID("MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");
              //  wrap.wait(2000);
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues"));

                break;

            case "SA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"), "code",
                        DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_descriptionOfInitalFund"));

                /**********************Filling Internal section*****************************/
                
                wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"));
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"),
                        DBUtils.readColumnWithRowID("MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");
              //  wrap.wait(2000);
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues"));

                break;

            case "TD":

                /**********************Filling Internal section*****************************/
            	
            	 wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode"),
                        DBUtils.readColumnWithRowID("MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues"));

                break;

            case "CC":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund"));
            	
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund"),
                        DBUtils.readColumnWithRowID("Type of initial funding", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//*[@id='AmountOfInitialFunding']")).sendKeys(DBUtils.readColumnWithRowID("Amount of Initial Funding", BaseProject.scenarioID));

            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//*[@id='DateInitialFund']")).sendKeys(DBUtils.readColumnWithRowID("Date of Initial Funding", BaseProject.scenarioID));

                break;

            case "PL":

			/*wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_sourceOfInitalFund"), "code",
					DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_descriptionOfInitalFund"));	*/

wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund"));
            	
            	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund"),
                        DBUtils.readColumnWithRowID("Type of initial funding", BaseProject.scenarioID), "BYVISIBLETEXT");
            	
            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//*[@id='AmountOfInitialFunding']")).sendKeys(DBUtils.readColumnWithRowID("Amount of Initial Funding", BaseProject.scenarioID));

            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//*[@id='DateInitialFund']")).sendKeys(DBUtils.readColumnWithRowID("Date of Initial Funding", BaseProject.scenarioID));

                break;

        }
     //   //wrap.captureScreenShot(BaseProject.driver, "CDD Section");
    }


    @Then("^FDM : Fill Signature and Financial details section in Customer Details Tab$")
    public static void fillSignatureFinancialSections() throws IOException, InterruptedException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
    	
    	int no = FullDataMaker.fDC_Co_Applicant + 1;
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio"));

        /**********************Filling Signature section*****************************/
		// Don't Change below radio button which has 3 buttons yes/no/manual. hence common wrapper method won't fit.
    	String custSigYNopt = DBUtils.readColumnWithRowID("Availability_of_Customer_Signature1", BaseProject.scenarioID);
        logger.info("Customer Type :" + custSigYNopt);
        if (custSigYNopt.equalsIgnoreCase("Yes")) {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio"));
        }else if (custSigYNopt.equalsIgnoreCase("No")) {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureNo_Radio"));                
        }else if (custSigYNopt.equalsIgnoreCase("Manual")) {
        	wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureM_Radio"));
        }
        else
            logger.info("Incorrect selection has been made, other than Yes or No data");
        		
       
        //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"));


        switch (product) {

            case "CA":
                //wrap.wait(500);
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"))));
				/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));
				wrap.wait(1000);
				wrap.type(BaseProject.driver, "06/10/2017", com.getElementProperties("Fulldatacapturemaker","FDC_C=D_AOFSign_Date"));*/

                break;

            case "SA":
               // wrap.wait(500);
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"))));
				/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));
				wrap.wait(1000);
				wrap.type(BaseProject.driver, "06/10/2017", com.getElementProperties("Fulldatacapturemaker","FDC_C=D_AOFSign_Date"));*/

                break;

            case "TD":
              //  wrap.wait(500);
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"))));
				/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));
				wrap.wait(1000);
				wrap.type(BaseProject.driver, "06/10/2017", com.getElementProperties("Fulldatacapturemaker","FDC_C=D_AOFSign_Date"));*/

                break;

            case "CC":
              //  wrap.wait(500);
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"))));
				/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));
				wrap.wait(1000);
				wrap.type(BaseProject.driver, "06/10/2017", com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));*/

                break;

            case "PL":
             //   wrap.wait(500);
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"))));
				/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));
				wrap.wait(1000);
				wrap.type(BaseProject.driver, "06/10/2017", com.getElementProperties("Fulldatacapturemaker","FDC_CD_AOFSign_Date"));*/

                break;
        }

    //    //wrap.captureScreenShot(BaseProject.driver, "AOF Signature Section");
    }


    @Then("FDM : Fill Banking Service Details section in Customer Details Tab$")

    public static void fillbankingservicedetailssection() throws IOException, InterruptedException {
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_Yes"));

        switch (product) {

            case "CA":
            	
				wrap.radioButtonSelection(BaseProject.driver, "Online Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_No");
				
            	wrap.radioButtonSelection(BaseProject.driver, "Mobile Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture_CustomerDetail_MobileBanking_Radio_No");

                break;

            case "SA":
            	
				wrap.radioButtonSelection(BaseProject.driver, "Online Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_No");
				
            	wrap.radioButtonSelection(BaseProject.driver, "Mobile Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture_CustomerDetail_MobileBanking_Radio_No");
            	
            	break;

            case "TD":
            	
				wrap.radioButtonSelection(BaseProject.driver,"Online Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_No");
            	
				wrap.radioButtonSelection(BaseProject.driver, "Mobile Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture_CustomerDetail_MobileBanking_Radio_No");
            	
                break;

            case "CC":
            	
				wrap.radioButtonSelection(BaseProject.driver,"Online Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBanking_Radio_Yes", "String FullDataCapture_CustomerDetail_OnlineBanking_Radio_No");
            	
				wrap.radioButtonSelection(BaseProject.driver, "Mobile Banking", "Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture_CustomerDetail_MobileBanking_Radio_No");
            	
                break;

            case "PL":

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Banking Service Details Section");
    }


    @Then("FDM : Fill Family Details section in Customer Details Tab$")

    public static void fillfamilydetailssection() throws IOException, InterruptedException {
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

        switch (product) {

            case "CA":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));

			/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Father Middle Name", BaseProject.scenarioID) ,
                    com.getElementProperties("Fulldatacapturemaker","FDM_Family_FatherMiddleName"));*/

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));

                break;

            case "SA":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));

			/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Father Middle Name", BaseProject.scenarioID) ,
                    com.getElementProperties("Fulldatacapturemaker","FDM_Family_FatherMiddleName"));*/

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));

                break;

            case "TD":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Father Middle Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));

                break;

            case "CC":
                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));

//			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Father Middle Name", BaseProject.scenarioID) ,
//                    com.getElementProperties("Fulldatacapturemaker","FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "middlename", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "LastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"),
                        "CAP - Captain", "BYVISIBLETEXT");

                //wrap.captureScreenShot(BaseProject.driver, "Family Details Section");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));

                //FDM_Family_MotherMaidenName
                wrap.type(BaseProject.driver, "MothersMaidenName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMaidenName"));

               /* if (mar_status.equalsIgnoreCase("MARRIED")) {
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseOccupation"),
                            "HOUSEWIFE", "BYVISIBLETEXT");
                }
                wrap.type(BaseProject.driver, "1", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren")).sendKeys(Keys.TAB);


                wrap.type(BaseProject.driver, "Hirendra", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
                wrap.type(BaseProject.driver, "2", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildAge"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildGender"),
                        "MALE", "BYVISIBLETEXT");*/
                wrap.wait(3000);

                break;

            case "PL":
                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));

//			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Father Middle Name", BaseProject.scenarioID) ,
//                    com.getElementProperties("Fulldatacapturemaker","FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "middlename", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));

                wrap.type(BaseProject.driver, "LastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"),
                        "CAP - Captain", "BYVISIBLETEXT");

                //wrap.captureScreenShot(BaseProject.driver, "Family Details Section");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));

                //FDM_Family_MotherMaidenName
                wrap.type(BaseProject.driver, "MothersMaidenName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMaidenName"));

                if (mar_status.equalsIgnoreCase("MARRIED")) {
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseOccupation"),
                            "HOUSEWIFE", "BYVISIBLETEXT");
                }

                wrap.type(BaseProject.driver, "1", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren")).sendKeys(Keys.TAB);


                wrap.type(BaseProject.driver, "Hirendra", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
                wrap.type(BaseProject.driver, "2", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildAge"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildGender"),
                        "MALE", "BYVISIBLETEXT");
                wrap.wait(3000);
                break;

        }

     //   //wrap.captureScreenShot(BaseProject.driver, "Family Details Section");
    }


    @Then("^FDM : Fill CDDOAT and Marketing details sections in Customer Details Tab$")
    public static void fillCDDOATMarketingSections() throws IOException, InterruptedException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_numbered_account/passbook?Yes"));

        /**********************Filling CDD OAT section*****************************/
    	
		
		wrap.radioButtonSelection(BaseProject.driver, "Client wishes anonymity (numbered account/passbook) ?", "Fulldatacapturemaker", "FDC_CD_CDD(OAT)_numbered_account/passbook?Yes","FDC_CD_CDD(OAT)_numbered_account/passbook?No");
    	
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_Other_risk_factors"),
                DBUtils.readColumnWithRowID("Other risk factors", BaseProject.scenarioID), "BYVISIBLETEXT");

        /**********************Marketing Details*****************************/

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustTab_PreferredContact_Time"),
                "Evening", "BYVISIBLETEXT");

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "CDD(OAT) & Marketing details Section");
    }

    /*******************End of step definitions for Customer Details tab**********************/


    /*******************
     * Start of step definitions for Product Details tab
     **********************/


    @Then("^FDM : Fill Product Details and A/C Setup sections in Product Details Tab$")
    public static void fillProductACSetupSection() throws IOException, InterruptedException {
    	
    	FullDataMakerUtils.switchToProductDetailsTab();
    	/*wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");*/
		wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"));
		
		//BaseProject.driver.findElement(By.xpath("//div[contains(@sectionbodyid,'SubSectionProductDetails')]//li[1]//span")).click();
        //FullDataMakerUtils.switchToProductDetailsTab();
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCategory_txt"), 20);

        String prdCat = com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCategory_txt"));

        if (prdCat.equalsIgnoreCase("PERSONAL LOAN")) {
            product = "PL";
            logger.info("The product code is assigned as PL");
        } else if (prdCat.equalsIgnoreCase("CREDIT CARD")) {
            product = "CC";
            logger.info("The product code is assigned as CC");
        } else if (prdCat.equalsIgnoreCase("SAVINGS ACCOUNT")) {
            product = "SA";
            logger.info("The product code is assigned as SA");
        } else if (prdCat.equalsIgnoreCase("CURRENT ACCOUNT")) {
            product = "CA";
            logger.info("The product code is assigned as CA");
        } else {
            product = "TD";
            logger.info("The product code is assigned as TD");
        }


        //FDC_ProdDet_PromCampaigncode
        if (product.equalsIgnoreCase("CA") || product.equalsIgnoreCase("SA") || product.equalsIgnoreCase("CC")) {
            productcode = com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCode_txt"));
            logger.info("Product Code : " + productcode);
        }
        logger.info("Promotion/CampaignCode : " + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_PromCampaigncode")).getText());
        logger.info("Product Category : " + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCategory_txt")).getText());

        if (product.equalsIgnoreCase("TD")) {
            logger.info("Deposit Type : " + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_DepositType_txt")).getText());
        }
        //logger.info("Acquisition Or Usage indicator : " + com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Acquisition__txt")));
        //logger.info("Account Currency :"+wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_A/CSetupSec_AccountCurrency_txt")).getText());

        switch (product) {

            case "CA":
			
            	/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_FundAccountChoice_DD"),
                        DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID), "BYVISIBLETEXT");*/
            	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_FundAccountChoice_DD"))));
            	
            	if((DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID)).equalsIgnoreCase("CHEQUE")){
            	
            		wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqNum_Txt"));


            	wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqDate_Txt"));
            	
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Drawn On", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqDrawnOn_Txt"));

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Amount", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqAmu_Txt"));
            	
            	}
            	
            	
            	if((DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID)).equalsIgnoreCase("EXISTING CASA")){
                	
            		wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Fund Account No", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductTab_DepositInfo_FundAccountNo"));


            		wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Amount", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqAmu_Txt"));
            	
            	}
            	
				wrap.radioButtonSelection(BaseProject.driver, "Nomination Facility", " Fulldatacapturemaker", "FDC_PD_NKISec_NominationFacility_Yes", "FDC_PD_NKISec_NominationFacility_No");
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_MisCode"),
                        DBUtils.readColumnWithRowID("MIS Code (Prd)", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_Misvalue_Xpath"));

                break;

            case "SA":

				/*wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Maximum Deposit Size", BaseProject.scenarioID),
						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_MaxDepoSize_txt"));

				wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Make Multiples Amount", BaseProject.scenarioID),
						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_MakeMultiplesAmt_txt"));

				wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Minimum Deposit Size", BaseProject.scenarioID),
						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_MinimumDepositSize_txt"));

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_TermType_DD"),
						DBUtils.readColumnWithRowID("Term Type", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_AttachtoAutobrk_DD"),
						DBUtils.readColumnWithRowID("Attach to Auto Break", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_DepositType_DD"),
						DBUtils.readColumnWithRowID("Deposit Type", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_DepositBrkMulti_DD"),
						DBUtils.readColumnWithRowID("Deposit Break Multiples", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Max threshold", BaseProject.scenarioID),
`						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_MaxThreshold_txt"));

				wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID),
						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_Term_txt"));

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_Tenure_DD"),
						DBUtils.readColumnWithRowID("Tenure Type", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID),
						com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_MinClearBal_txt"));

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_FundAccountChoice_DD"),
						DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID), "BYVISIBLETEXT");*/

                if (com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCode_txt")).contains("300")
                        || com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCode_txt")).contains("310")
                        || com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCode_txt")).contains("100") || com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ProductCode_txt")).contains("316")) {
                    logger.info("User is in product code - 300 or 310 or 100 or 316");
				/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_FundAccountChoice_DD"),
						DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID), "BYVISIBLETEXT");*/
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqNum_Txt"));


                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Date", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqDate_Txt"));

                    wrap.wait(2000);
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Drawn On", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqDrawnOn_Txt"));

                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Amount", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_CheqAmu_Txt"));

                    
					wrap.radioButtonSelection(BaseProject.driver, "Nomination Facility", " Fulldatacapturemaker", "FDC_PD_NKISec_NominationFacility_Yes", "FDC_PD_NKISec_NominationFacility_No");
                    
//                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_OperatingInstruction_DD"),
//                            DBUtils.readColumnWithRowID("Operating Instruction", BaseProject.scenarioID), "BYVISIBLETEXT");
//                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Account Short Name", BaseProject.scenarioID),
//                            com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_A/CSetupSec_AccountShortName_txt"));

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_MisCode"),
                            DBUtils.readColumnWithRowID("MIS Code (Prd)", BaseProject.scenarioID), "BYVISIBLETEXT");
                    
                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value (Prd)", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_Misvalue"));

                } else {
                    logger.info("if condition is failed, not satisfied - so Product detail, Nominee and A/C setup not filled");
                }


                break;


            case "TD":
                
				wrap.radioButtonSelection(BaseProject.driver, "Nomination Facility", "Fulldatacapturemaker", "FDC_PD_NKISec_NominationFacility_Yes", "FDC_PD_NKISec_NominationFacility_No");
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_MisCode"),
                        DBUtils.readColumnWithRowID("MIS Code (Prd)", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value (Prd)", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_Misvalue"));


                break;


            case "PL":

                //logger.info("Account Request Type :"+wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD(OAT)_Other_risk_factors")).getText());

                //logger.info("Purpose of account opening :"+wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_A/CSetupSec_Purposeofaccountopening_txt")).getText());

                switch (com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Acquisition__txt"))) {
                    case "Acquisition":
                        //added newly
                        //logger.info("Am in Acquisition case currently for PL 6075 in PL Account");
                        
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Special Rate", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"));
                        
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"));
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                        //added newly
					/*if(wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_AssessmentType"))=="Surrogate")
							{
						wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("FDC_ProdTab_SurrogateOn", BaseProject.scenarioID) ,
								com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_Surrogate_On"));
							}*/
                        //ended
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Amount (with Currency)", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));
                        //added newly
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
                        //ended
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Tenure", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));

                       
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Purposeofloan"),
                                DBUtils.readColumnWithRowID("Purpose Of Loan", BaseProject.scenarioID), "BYVISIBLETEXT");

                        //FDC_ProductDetails_EffectiveRate%
                        
                        wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate"));
                        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate")).sendKeys(Keys.TAB);
                        wrap.wait(1500);
                        wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Prd_Reqeff"));
                        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Prd_Reqeff")).sendKeys(Keys.TAB);
                        wrap.wait(1500);
                        wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Prd_AppReqeff"));
                        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Prd_AppReqeff")).sendKeys(Keys.TAB);
                       // wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Prd_AppReqeff")).sendKeys(Keys.TAB);
                        wrap.wait(1500);
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"));
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"),
                                "RES", "BYVISIBLETEXT");
                        wrap.wait(2000);
                        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType")).sendKeys(Keys.TAB);

                        wrap.wait(3000);
                        //wrap.captureScreenShot(BaseProject.driver, "Product Request Section");
                        break;

                    case "Usage":
                        //added newly
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UsageType"),
                                DBUtils.readColumnWithRowID("Usage Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                        //added newly
                        if (wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType")) == "Surrogate") {
                            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Surrogate_On"),
                                    DBUtils.readColumnWithRowID("FDC_ProdTab_SurrogateOn", BaseProject.scenarioID), "BYVISIBLETEXT");
                        }
                        //ended
                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Amount (with Currency)", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));

                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
                        wrap.wait(500);
                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Tenure", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));

                        //Added newly
                        switch (DBUtils.readColumnWithRowID("Usage Type", BaseProject.scenarioID)) {
                            /********************************************Code for Top Up in usage******************************************************/
                            case "Top-Up":
                                wrap.wait(1000);
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Top-UpA/CNumber"));

                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupType"),
                                        DBUtils.readColumnWithRowID("FDC_ProductDetails_TopupType", BaseProject.scenarioID), "BYVISIBLETEXT");

                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Purposeofloan"),
                                        DBUtils.readColumnWithRowID("Purpose Of Loan", BaseProject.scenarioID), "BYVISIBLETEXT");

                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate%", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate%"));
                                wrap.wait(1000);
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_OriginalLoanOutStandingAmt", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_OriginalLoanOutStandingAmt"));
                                wrap.wait(500);
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_OriginalLoanOutstandingTenor", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_OriginalLoanOutstandingTenor"));

                                logger.info("TopupAmount(withCurrency) :" + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupAmount(withCurrency)")).getText());

                                //wrap.captureScreenShot(BaseProject.driver, "Product Details Section");
                                /*****************************End of Topup Usage********************************/
                                break;

                            case "OD":
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CA_A/C_Number"));
                                break;
                        }
                        break;
                }
                //Altered Excel column name
					/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_ProductAddressType"),
							DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");
					//wrap.captureScreenShot(BaseProject.driver, "Product Request Section");*/

                break;

            case "CC":

       
            	wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Special Rate", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"));

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");

				
                      
                        try {

                            if (productcode.contains("175"))

                            {
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Emirates Number", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC_EmiratesSkywardsMembershipNo"));
                                
                            }
                        } catch (Exception E) {

                        }
                        
                        if(DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID).equalsIgnoreCase("surrogate"))
                        {
                        	 wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Surrogate_On"),
                             		DBUtils.readColumnWithRowID("Surrogate On", BaseProject.scenarioID), "BYVISIBLETEXT");
                        	
                        }
                        
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Preferred Limit", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
                       
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("TermdepositSecureCC", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"),
                        		DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");
                       
                        wrap.wait(3000);
                        
                        wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType")).sendKeys(Keys.TAB);
   

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Product Details Section");
    }


    @Then("^FDM : Fill Banking Service Details section in Product Details Tab$")
    public static void fillBankingServiceDetailsSection() throws IOException, InterruptedException {

        switch (product) {

            case "CA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_MisCode"));
            	
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_MisCode"),
                        DBUtils.readColumnWithRowID("MIS Code (Prd)", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Internal_Misvalue_Xpath"));
                
                wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_ChequeBookNo"));
            	
				wrap.radioButtonSelection(BaseProject.driver, "Cheque Book Required", "Fulldatacapturemaker", "FDC_PD_A/CSetupSec_ChequeBookYes", "FDC_PD_A/CSetupSec_ChequeBookNo");
            	
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_StatementType_DD"),
                        DBUtils.readColumnWithRowID("Statement Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                
				wrap.radioButtonSelection(BaseProject.driver, "Consolidated Flag", "Fulldatacapturemaker","FDC_PD_A/CSetupSec_ConsolidatedFlagYes", "FDC_PD_A/CSetupSec_ConsolidatedFlagNo");
                
                break;

            case "SA":
				
				wrap.radioButtonSelection(BaseProject.driver, "Cheque Book Required", "Fulldatacapturemaker", "FDC_PD_A/CSetupSec_ChequeBookYes", "FDC_PD_A/CSetupSec_ChequeBookNo");
            	
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_StatementType_DD"),
                        DBUtils.readColumnWithRowID("Statement Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                
				wrap.radioButtonSelection(BaseProject.driver, "Consolidated Flag", "Fulldatacapturemaker", " FDC_PD_A/CSetupSec_ConsolidatedFlagYes", "FDC_PD_A/CSetupSec_ConsolidatedFlagNo");
               
                break;

            case "TD":

                break;

            case "CC":


                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Banking Service Details Section");
    }

    @Then("FDM : Deposit Info Details section in Product Details Tab$")

    public static void depositInfoDetailSection() throws IOException, InterruptedException {

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":
      
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Deposit Amount", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductTab_DepositInfo_DepositAmount"));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Value Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductTab_DepositInfo_ValueDate"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_FundAccountChoice_DD"),
                        DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ChequeNumber_txt"));

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ChequeDate_txt"));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Cheque Drawn on", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ChequeDrawnOn_txt"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_TerMDepositec_suspenceAccount"),
                        "1", "BYINDEX");
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ChequeAmount_txt"));

                //need to add 'Roll over choice' field in the FDC data sheet
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetails_DI_Roll_Over_Choice_Y_Term"));
               
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetails_DI_Roll_Over_Choice_Y_Term")).sendKeys(Keys.TAB);
              

                //need to add '2-in-1' field in the FDC data sheet
                
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_TwoInOne_N_Term"));
                
                //      wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_TwoInOne_N_Term")).sendKeys(Keys.TAB);
               
              /*wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("Base Rate", BaseProject.scenarioID),
                   com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_Base_Rate"));*/

                //need to add 'Maturity Date' field in the FDC data sheet
                logger.info("Maturity Date :" + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Maturity_Date")).getText());

                //need to add 'Lien' field in the FDC data sheet
                
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Lien_No"));
                
                //     wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD_ProductDetailsSec_Lien_No")).sendKeys(Keys.TAB);
                
                //need to add 'Linkage' field in the FDC data sheet
                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_PD1_ProductDetailsSec_Linkage_yes"));

                //wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("No of Deposit", BaseProject.scenarioID),
                //        com.getElementProperties("Fulldatacapturemaker","FDC_PD1_ProductDetailsSec_No_of_Deposit"));

                break;


            case "CC":


                break;

            case "PL":

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Deposit Info Details Section");

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "final_Save"));

    }

    @Then("^FDM : Fill Product Request section in Product Details Tab$")
    public static void fillProductRequestSection() throws IOException, InterruptedException {

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "PL":
                logger.info("Bundle Indicator :" + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BundleIndicator")).getText());

			/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_Acq_UsageIndicator"),
					DBUtils.readColumnWithRowID("AcquisitionUsage", BaseProject.scenarioID), "BYVISIBLETEXT");*/

                String pcode = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProdDet_PromCampaigncode")).getText();
                logger.info("Am in PL case and my product code is : " + pcode);


                switch (pcode) {

                    case "PL6025_BR_NTB":
                        logger.info("Am in to PL6025 case ");
                        String acqoOrUsg = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator")).getText();
                        logger.info("Acq or Usage indicatior value is : " + acqoOrUsg);

                        switch (acqoOrUsg) {
                            case "Acquisition":
                                //added newly
                                logger.info("Am in Acquisition case currently for PL6025 code in PLaccount");
                                wrap.wait(500);
                                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"));
                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                        DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                                //added newly
					/*if(wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_AssessmentType"))=="Surrogate")
							{
						wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("FDC_ProdTab_SurrogateOn", BaseProject.scenarioID) ,
								com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_Surrogate_On"));
							}*/
                                //ended
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Amount (with Currency)", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));
                                //added newly
                                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
                                //ended
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Tenure", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));

                                wrap.wait(3000);
                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Purposeofloan"),
                                        DBUtils.readColumnWithRowID("Purpose Of Loan", BaseProject.scenarioID), "BYVISIBLETEXT");

                                //FDC_ProductDetails_EffectiveRate%
                                wrap.wait(3000);
                                wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate"));
                                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate")).sendKeys(Keys.TAB);
                                wrap.wait(5000);
                                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"));
                                wrap.wait(500);
                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"),
                                        DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");
                                wrap.wait(2000);
                                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType")).sendKeys(Keys.TAB);

                                wrap.wait(5000);
                                //wrap.captureScreenShot(BaseProject.driver, "Product Request Section");
                                break;


                            case "Usage":
                                //added newly
                                wrap.wait(500);
                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UsageType"),
                                        DBUtils.readColumnWithRowID("Usage Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                                wrap.wait(500);
                                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                        DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                                //added newly
                                if (wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType")) == "Surrogate") {
                                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Surrogate_On"),
                                            DBUtils.readColumnWithRowID("FDC_ProdTab_SurrogateOn", BaseProject.scenarioID), "BYVISIBLETEXT");
                                }
                                //ended
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Amount (with Currency)", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));

                                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
                                wrap.wait(500);
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Requested Tenure", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));

                                //Added newly
                                switch (DBUtils.readColumnWithRowID("Usage Type", BaseProject.scenarioID)) {
                                    /********************************************Code for Top Up in usage******************************************************/
                                    case "Top-Up":
                                        wrap.wait(1000);
                                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID),
                                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Top-UpA/CNumber"));

                                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupType"),
                                                DBUtils.readColumnWithRowID("FDC_ProductDetails_TopupType", BaseProject.scenarioID), "BYVISIBLETEXT");

                                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Purposeofloan"),
                                                DBUtils.readColumnWithRowID("Purpose Of Loan", BaseProject.scenarioID), "BYVISIBLETEXT");

                                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate%", BaseProject.scenarioID),
                                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EffectiveRate%"));
                                        wrap.wait(1000);
                                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_OriginalLoanOutStandingAmt", BaseProject.scenarioID),
                                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_OriginalLoanOutStandingAmt"));
                                        wrap.wait(500);
                                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProductDetails_OriginalLoanOutstandingTenor", BaseProject.scenarioID),
                                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_OriginalLoanOutstandingTenor"));

                                        logger.info("TopupAmount(withCurrency) :" + wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupAmount(withCurrency)")).getText());

                                        //wrap.captureScreenShot(BaseProject.driver, "Product Request Section");
                                        /*****************************End of Topup Usage********************************/
                                        break;

                                    case "OD":
                                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("MIS Value", BaseProject.scenarioID),
                                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CA_A/C_Number"));
                                        break;
                                }
                                break;
                        }
                        //Altered Excel column name
					/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_ProductAddressType"),
							DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");
					//wrap.captureScreenShot(BaseProject.driver, "Product Request Section");*/

                        break;

                }
                break;


            case "CC":

			/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_Acq_UsageIndicator"),
					DBUtils.readColumnWithRowID("AcquisitionUsage", BaseProject.scenarioID), "BYVISIBLETEXT");*/

                switch (DBUtils.readColumnWithRowID("AcquisitionUsage", BaseProject.scenarioID)) {
                    case "Acquisition":

                        wrap.wait(1000);

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                        wrap.wait(1000);
                        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_PD_PRS_LezCode_suggestionBox"), "Description",
                                DBUtils.readColumnWithRowID("LezCode", BaseProject.scenarioID));
                        wrap.wait(3000);
                        try {
                            if (productName.equalsIgnoreCase("175")) {
                                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("EmiratesNumber", BaseProject.scenarioID),
                                        com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC_EmiratesSkywardsMembershipNo"));
                                wrap.wait(1000);
                            }
                        } catch (Exception E) {

                        }
                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Preferred Limit", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("TermdepositSecureCC", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"),
                                DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");
                        wrap.wait(2000);

                        //wrap.captureScreenShot(BaseProject.driver, "Product Request Section");
                        break;


                    case "Usage":

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UsageType"),
                                DBUtils.readColumnWithRowID("Usage Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                        wrap.wait(2000);


                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"),
                                DBUtils.readColumnWithRowID("Assessment Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"),
                                DBUtils.readColumnWithRowID("Product address type", BaseProject.scenarioID), "BYVISIBLETEXT");

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Preferred Limit", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("TermdepositSecureCC", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));
                        //wrap.captureScreenShot(BaseProject.driver, "Product Request Section");
                        break;

                }

                break;

        }

    }


    @Then("^FDM : Fill Repayment Details section in Product Details Tab$")
    public static void fillRepaymentSection() throws IOException, InterruptedException {

    	//FullDataMakerUtils.switchToProductDetailsTab();
        switch (product) {

            case "PL":
            	/*wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
            	
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"),
                        DBUtils.readColumnWithRowID("Repayment Mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode")).sendKeys(Keys.TAB);
                wrap.wait(3500);
                
                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"));
                wrap.wait(2000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"),
                        DBUtils.readColumnWithRowID("Repayment Account Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.wait(1000);
                switch (DBUtils.readColumnWithRowID("Repayment Mode", BaseProject.scenarioID)) {*/
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
            	WebElement eleRepaymentMode=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                
                new WebDriverWait(BaseProject.driver, 30).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(eleRepaymentMode));
	
            	wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"),
                        DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                WebElement selMode=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                
                Select repaymentMode=new Select(selMode);
                if(!repaymentMode.getFirstSelectedOption().getText().equals(DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID)))
                	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"),
                            DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                    
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode")).sendKeys(Keys.TAB);
                //wrap.wait(2000);
                WebElement eleRepaymentAccountType=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"));
                
                new WebDriverWait(BaseProject.driver, 30).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(eleRepaymentAccountType));
                //wrap.wait(2000);
                
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"));
                
                System.out.println("clicked on repayment account type");
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"),
                        DBUtils.readColumnWithRowID("Repayment Account Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                System.out.println("selected an option from repayment account type");
                
                String currentRepayMode = DBUtils.readColumnWithRowID("Repayment Mode", BaseProject.scenarioID);
                wrap.wait(200);
                switch (currentRepayMode) {

                    case "SI on SCB":
                    	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AccountNumber"));
                    	 wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Frequency"), DBUtils.readColumnWithRowID("Frequency", BaseProject.scenarioID), "BYVISIBLETEXT");
                    	 wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Effective Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EffectiveDate"));
                        break;

                    case "PDC-Post Dated Cheque":

                    	wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("PDC-Total cheque No", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-TotalchequeNo"));
                       

                        break;

                    case "EDA on other bank A/C":
                    	System.out.println("Switched successfully to respective case");

                       //wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRD_AccType"), DBUtils.readColumnWithRowID("Repayment Account Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                       wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AccountNumber"));
                       wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("EDA Account holder Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EDAName"));
                       
                       wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode"), DBUtils.readColumnWithRowID("IFSC code", BaseProject.scenarioID), "BYVISIBLETEXT");
                      // wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Bank/Utility Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_BankorUtilityName"));
                       
                       wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Bank Sort Code", BaseProject.scenarioID),
                               com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_BankSortCode"));
                       
                      wrap.type(BaseProject.driver, "CHENNAI",
                              com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BranchDescription"));
                   //    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Repaymentbranchcode"), DBUtils.readColumnWithRowID("Repayment branch code", BaseProject.scenarioID), "BYVISIBLETEXT");
                      wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Monthly_Repayment_Due_Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_MonthlyRepaymentDueDate"));
                      
                      /*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebitType"),
                              DBUtils.readColumnWithRowID("Debit Type", BaseProject.scenarioID), "BYVISIBLETEXT");*/
                       
                       wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Frequency"), DBUtils.readColumnWithRowID("Frequency", BaseProject.scenarioID), "BYVISIBLETEXT");
                       wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Effective Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EffectiveDate"));
                       wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Expiry Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_ExpiryDate"));
                       
                }
                ////wrap.captureScreenShot(BaseProject.driver, "Repayment Details Section");
                break;

            case "CC":
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
            	WebElement eleRepaymentMode1=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                
                new WebDriverWait(BaseProject.driver, 30).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(eleRepaymentMode1));
	
            	wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"),
                        DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                WebElement selMode1=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
                
                Select repaymentMode1=new Select(selMode1);
                if(!repaymentMode1.getFirstSelectedOption().getText().equals(DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID)))
                	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"),
                            DBUtils.readColumnWithRowID("Repayment mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                    
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode")).sendKeys(Keys.TAB);
                wrap.wait(2000);
                WebElement eleRepaymentAccountType1=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"));
                
                new WebDriverWait(BaseProject.driver, 30).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(eleRepaymentAccountType1));
                
                
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"));
                
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentAccountType"),
                        DBUtils.readColumnWithRowID("Repayment Account Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                
                switch (DBUtils.readColumnWithRowID("Repayment Mode", BaseProject.scenarioID)) {
                    case "EDA on other bank A/C":

                        
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AccNumber"));

                        //EDA Name (Mandatory)
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("EDA Account holder Name", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EDAName"));

                  
                        try {

                            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode"),
                                    DBUtils.readColumnWithRowID("IFSC Code", BaseProject.scenarioID), "BYVISIBLETEXT");
                            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode")).sendKeys(Keys.TAB);

						
                        } catch (Exception E) {

                            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode"),
                                    DBUtils.readColumnWithRowID("IFSC Code", BaseProject.scenarioID), "BYVISIBLETEXT");
                            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode")).sendKeys(Keys.TAB);


                        }



                       /* wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Repaymentbranchcode"),
                                DBUtils.readColumnWithRowID("Repayment branch code", BaseProject.scenarioID), "BYVISIBLETEXT");*/


                        //Bank/UtilityName (Mandatory) - It will prepopulate


                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Bank Sort Code", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_BankSortCode"));
                        
                        
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Repayment Branch Name", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BranchDescription"));
                        
                        wrap.type(BaseProject.driver, "TEST",
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BeneficiaryBankRegion"));
                        
                        //Monthly Repayment DueDate (Mandatory)
                        wrap.wait(2000);
                        BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//*[@id='MonthlyRepaymentDueDt']")).click();
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Monthly_Repayment_Due_Date", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_MonthlyRepaymentDueDate"));
                        
                       /* wrap.wait(1000);
                        BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//*[@id='MonthlyRepaymentDueDt']")).click();
                        BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//*[@id='MonthlyRepaymentDueDt']")).sendKeys("01/01/2020");
*/
                        //wrap.wait(2000);
                        //Debit Type
                                                                   
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebitType"),
                                DBUtils.readColumnWithRowID("Debit Type", BaseProject.scenarioID), "BYVISIBLETEXT");


                        //Auto debit amount
                        //wrap.wait(2000);
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Auto Debit Amount", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AutoDebitAmount"));


                        break;
                    case "SI on SCB":

                   
                    	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AccNumber"),
                                DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID), "BYVISIBLETEXT");

                    	 wrap.type(BaseProject.driver, "CHENNAI",
                                 com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BranchDescription"));
                         
                         wrap.type(BaseProject.driver, "TEST",
                                 com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BeneficiaryBankRegion"));
                    	
                        //Debit Type
                    	
                    	//WebElement eleDebitType1=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebitType"));
                                           
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebitType"),
                                DBUtils.readColumnWithRowID("Debit Type ", BaseProject.scenarioID), "BYVISIBLETEXT");

                        //Auto debit amount
                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Auto Debit Amount", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AutoDebitAmount"));
                        break;

                    case "PDC-Post Dated Cheque":
                    	
                    	wrap.type(BaseProject.driver, "TEST",
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BeneficiaryBankRegion"));

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Auto Debit Amount", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AutoDebitAmount"));
                        break;
                    // Dinesh code ends here

                }

                break;

            default:

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Repayment Details Section");
    }

    @Then("^FDM : Fill Disbursement Details section in Product Details Tab$")
    public static void fillDisbursementSection() throws IOException, InterruptedException {

        switch (product) {

            case "PL":
                /*******AmountForDisbursement is auto populated based on RequestedAmount under Product Request section***********/
              //  wrap.wait(1500);
						/*wrap.clear(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AmountForDisbursement"));
						wrap.type(BaseProject.driver,"8000", com.getElementProperties("Fulldatacapturemaker","AmountForDisbursement"));
						wrap.wait(3000);
		                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","DrawDownSeqNoid"));
		                wrap.wait(1000);
		                wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("FDC_ProdTab_DrawDownSeqNo", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker","DrawDownSeqNoid"));
		                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","DrawDownSeqNoid")).sendKeys(Keys.TAB);
		                //Altered 17th Aug
		                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AmountForDisbursement"));
		                wrap.wait(3000);
		                wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker","FDC_PD_Drawdownamt"));*/
                //Drawdown Date is pre populated with sys date

            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"));
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"));
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"),
                        DBUtils.readColumnWithRowID("Disbursement mode", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.wait(1500);
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode")).sendKeys(Keys.TAB);
                wrap.wait(3000);
                switch (DBUtils.readColumnWithRowID("Disbursement Mode", BaseProject.scenarioID)) {
                    case "Pay Order":

                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary A/C Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
                        //Pay Order number is pre-populated
                        
                        
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Pay order date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Payorderdate"));
                        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Pay order hand over date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Payorderhandoverdate"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Pay Order Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PayOrderNumber"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Pay Order Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PayOrderamount"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Debit Account", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DebitAccount"));

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PickUpMethod"),
                                DBUtils.readColumnWithRowID("Pick Up Method", BaseProject.scenarioID), "BYVISIBLETEXT");
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Pickupby"),
                                DBUtils.readColumnWithRowID("Pick up by", BaseProject.scenarioID), "BYVISIBLETEXT");
                        
                        
                        com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PrintLocation"), "MAA", DBUtils.readColumnWithRowID("Print Location", BaseProject.scenarioID));
                       /* wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PrintLocation"), "code",
                                DBUtils.readColumnWithRowID("Print Location", BaseProject.scenarioID));*/
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ClearingZonecode"),DBUtils.readColumnWithRowID("Clearing Zone code", BaseProject.scenarioID),"BYVISIBLETEXT");
                        break;

                    case "NEFT":
                    	
                    	wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode_Disbursement"), "code",
                                DBUtils.readColumnWithRowID("IFSC Code", BaseProject.scenarioID));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary A/C Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
                        break;
                        
                    case "RTGS":

                        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_IFSCCode_Disbursement"), "code",
                                DBUtils.readColumnWithRowID("IFSC Code", BaseProject.scenarioID));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary A/C Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
                        break;

                    case "Account Credit":
                       // wrap.wait(2000);
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary Name", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
                      //  wrap.wait(2000);
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Beneficiary A/C Number", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
                       // wrap.wait(2000);
                        wrap.type(BaseProject.driver, "5000", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_AdvanceEMI"));
                        break;

                }

            //    wrap.wait(2000);
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProdTab_BankUse_LoanNotes", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Loannotes"));

                break;


        }
        //wrap.captureScreenShot(BaseProject.driver, "Disbursement Details Section");
    }

    @Then("^FDM : Fill Bank Use section in Product Details Tab$")
    public static void fillBankUseSection() throws IOException, InterruptedException {

        switch (product) {

            case "CC":
            	
            	//wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_BillingCycle"));
      
               /* wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Billing Cycle", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BillingCycle"));*/

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("CC Emboss Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CCEmbossName"));
               
				wrap.radioButtonSelection(BaseProject.driver, "Consolidated Flag", "Fulldatacapturemaker", "FDC_ProductDetails_ConsolidatedFlagY", "FDC_ProductDetails_ConsolidatedFlagN");
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_StatementFlag"),
                        DBUtils.readColumnWithRowID("Statement Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("User_Code2", BaseProject.scenarioID),
            		 com.getElementProperties("Fulldatacapturemaker","FDC_ProductDetails_UserCode2"));

                
                wrap.typeToTextBox(BaseProject.driver,"PPLS",
               		 com.getElementProperties("Fulldatacapturemaker","FDCM_PD_PRS_LezCode_suggestionBox"));


                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_PD_PRS_LezCode_suggestionBox")).sendKeys(Keys.TAB);

                break;

            case "PL":
                //Added newly to enter the Loan Notes
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("FDC_ProdTab_BankUse_LoanNotes", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_LoanNotes"));

                break;

        }

       
    }

    /*******************End of step definitions for Product Details tab**********************/


    /*******************
     * Start of step definitions for Application Details tab
     **********************/

    @Then("^FDM : Fill Debit Card section in Application Details Tab$")
    public static void fillDebitCardSectionAppTab() throws IOException, InterruptedException {

       // FullDataMakerUtils.switchToApplicationDetailsTab();
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_DebitCardRequired_no"), 20);

        switch (product) {

            case "CA":
            	
            	JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
                jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_DebitCardRequired_yes")));
            	
				wrap.radioButtonSelection(BaseProject.driver, "Debit Card Required", "Fulldatacapturemaker","FDC_ApplicationDetails_DebitCardRequired_yes", "FDC_ApplicationDetails_DebitCardRequired_no");
            	
			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ApplicationDetails_Customer"),
					DBUtils.readColumnWithRowID("FDC AD Customer", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_PrimaryProduct_DropDown"),
					DBUtils.readColumnWithRowID("Primary Product", BaseProject.scenarioID), "BYVISIBLETEXT");


			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SecondaryProduct_dropDown"),
					DBUtils.readColumnWithRowID("Secondary Product", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_CardType_DropDown"),
					DBUtils.readColumnWithRowID("Card Type", BaseProject.scenarioID), "BYVISIBLETEXT");
			
			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_CardSubType"),
					DBUtils.readColumnWithRowID("Card Sub Type", BaseProject.scenarioID), "BYVISIBLETEXT");
			
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_Add"));

			/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Card Sub Type", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_CardSubType"));*/


			/*
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_SourcingCity"));

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_RefreeRelationship"),
					DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("AD_Fund", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_Fund"));*/

                break;

            case "SA":
            	
				wrap.radioButtonSelection(BaseProject.driver, "Debit Card Required", "Fulldatacapturemaker", "FDC_ApplicationDetails_DebitCardRequired_yes", "FDC_ApplicationDetails_DebitCardRequired_no");
            	
			/*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_ApplicationDetails_Customer"),
					DBUtils.readColumnWithRowID("FDC_AD_Customer", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_PrimaryProduct_DropDown"),
					DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SecondaryProduct_dropDown"),
					DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_CardType_DropDown"),
					DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("AD_Fund", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_CardSubType"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_Add"));*/

                break;

        }

    }

    @Then("^FDM : Fill Bank Use section in Application Details Tab$")
    public static void fillBankUseSectionAppTab() throws IOException, InterruptedException {
    	
    //	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"));

		/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Sourcing ID", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SourcingID_TextBox"));

		wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ReferralID_TextBox"));*/

        switch (product) {

            case "CA":

               /* wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"),
                        DBUtils.readColumnWithRowID("Home Branch", BaseProject.scenarioID), "BYVISIBLETEXT");*/

            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
            	
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Closing ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
                
				wrap.radioButtonSelection(BaseProject.driver, "Investment Account Request", "Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes", "FDC_AppDetailsTab_InvAccReq_no");
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("HR Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));


             /*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("SourcingCity", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_SourcingCity"));*/

                break;

            case "SA":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"),
                        DBUtils.readColumnWithRowID("Home Branch", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Closing ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
				
				wrap.radioButtonSelection(BaseProject.driver, "Investment Account Request", "Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes", "FDC_AppDetailsTab_InvAccReq_no");
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("HR Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));

			/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("SourcingCity", BaseProject.scenarioID) ,
								com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_SourcingCity"));*/

                break;

            case "TD":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"),
                        DBUtils.readColumnWithRowID("Home Branch", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Closing ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
				
				wrap.radioButtonSelection(BaseProject.driver, "Investment Account Request", "Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes", "FDC_AppDetailsTab_InvAccReq_no");
               
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("HR Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));

                break;

            case "CC":
            	
            	com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID"), "A57", "A57");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Closing ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
                
                wrap.radioButtonSelection(BaseProject.driver, "Investment Account Request", "Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes", "FDC_AppDetailsTab_InvAccReq_no");

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("HR Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));
                
                wrap.wait(500);
                BaseProject.driver.findElement(By.xpath("//*[@id='DSACode']")).click();
                wrap.wait(500);
                BaseProject.driver.findElement(By.xpath("//*[@id='DSACode']")).sendKeys("DSACode");
                
			/*wrap.wait(3500);
			wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("SourcingCity", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_SourcingCity"));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("DSACode", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_DSACode"));*/

                /*wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_RefreeRelationship"),
                        DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("AD_Fund", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_Fund"));*/

                break;

            case "PL":


            	wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Closing ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
                
                wrap.radioButtonSelection(BaseProject.driver, "Investment Account Request", "Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes", "FDC_AppDetailsTab_InvAccReq_no");

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("HR Date", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));
                
                wrap.wait(500);
                BaseProject.driver.findElement(By.xpath("//*[@id='DSACode']")).sendKeys(DBUtils.readColumnWithRowID("DSA Code", BaseProject.scenarioID));
                
			/*wrap.wait(3500);
			wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID("SourcingCity", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_SourcingCity"));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("DSACode", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_BankUse_DSACode"));*/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_RefreeRelationship"),
                        DBUtils.readColumnWithRowID("Referee Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("AD_Fund", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_Fund"));

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Application BankUse Section");
    }

    @And("^FDM: validate Remarks fields in Full Data Capture$")
    public static void validate_Remarks_fields_in_Full_Data_Capture() throws IOException, InterruptedException {

        switchFrame();

        String action = com.getElementProperties("Fulldatacapturemaker", "FDC_Maker_Action");

        String remarks = com.getElementProperties("Fulldatacapturemaker", "FDC_Maker_Remarks");

        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

        WebElement w = BaseProject.driver.findElement(By.xpath(action));
        logger.info(w.getTagName());
        js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", w.findElement(By.xpath("//option[@value='Complete']")), "selected", "selected");

        WebElement w2 = BaseProject.driver.findElement(By.xpath(remarks));
           }

    @Then("^FDM : Fill Internal and A/C section in Application Details Tab$")
    public static void fillInternalACSection() throws IOException, InterruptedException {
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"));

        switch (product) {

            case "CA":

					/*wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ARMcode"), "code",
							DBUtils.readColumnWithRowID("FDC_AD_ARMCode", BaseProject.scenarioID));

					wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_Segmentcode"), "code",
										DBUtils.readColumnWithRowID("FDC_AD_SegmentCode", BaseProject.scenarioID));

					wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SubSegmentcode"), "code",
										DBUtils.readColumnWithRowID("FDC_AD_SubSegmentCode", BaseProject.scenarioID));*/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"),
                        DBUtils.readColumnWithRowID("Service Indicator Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), DBUtils.readColumnWithRowID("Institution Classification Code", BaseProject.scenarioID));

                break;

            case "SA":

					/*wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ARMcode"), "code",
							DBUtils.readColumnWithRowID("FDC_AD_ARMCode", BaseProject.scenarioID));

					wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_Segmentcode"), "code",
										DBUtils.readColumnWithRowID("FDC_AD_SegmentCode", BaseProject.scenarioID));

					wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SubSegmentcode"), "code",
										DBUtils.readColumnWithRowID("FDC_AD_SubSegmentCode", BaseProject.scenarioID));*/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"),
                        DBUtils.readColumnWithRowID("Service Indicator Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), DBUtils.readColumnWithRowID("Institution Classification Code", BaseProject.scenarioID));

//                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), "code",
//                        DBUtils.readColumnWithRowID("Institution Classification Code", BaseProject.scenarioID));

                break;

            case "TD":

					/*wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ApplicationCreationDate")).getText();

                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ARMcode"), "code",
                                  DBUtils.readColumnWithRowID("FDC_AD_ARMCode", BaseProject.scenarioID));

                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_Segmentcode"), "code",
                                                       DBUtils.readColumnWithRowID("FDC_AD_SegmentCode", BaseProject.scenarioID));

                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_SubSegmentcode"), "code",
                                                       DBUtils.readColumnWithRowID("FDC_AD_SubSegmentCode", BaseProject.scenarioID));

                    wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_ApplicationDetails_ShortName")).getText();*/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"),
                        DBUtils.readColumnWithRowID("Service Indicator Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), "code",
                        DBUtils.readColumnWithRowID("Institution Classification Code", BaseProject.scenarioID));

                break;

            case "CC":

                break;

            case "PL":

                break;

        }

    }


    @Then("^FDM : Fill KYC section in Application Details Tab$")
    public static void fillKYCSection() throws IOException, InterruptedException {

        switch (product) {

            case "CA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));
            	
            	//new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"))));
            	//wrap.wait(2000);
                
            	/*wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"));*/
            	
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID));
            	//wrap.wait(1000);
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(Keys.TAB);
            	
            	//wrap.wait(1000);
            	BaseProject.driver.findElement(By.xpath("//*[@id='KYCPlaceOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID));
            	
            	
                
                /*wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCPlaceOfDeclaration"));*/
               
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationDate"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeName"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Designation", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeDesignation"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Branch", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationBranch"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeCode"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CKYC ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYC_CKYCid"));
                

                break;

            case "SA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Date Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Place Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCPlaceOfDeclaration"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Verification Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationDate"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeName"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Designation", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeDesignation"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Verification Branch", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationBranch"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeCode"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("CKYC ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CKYCID"));

                break;

            case "TD":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Date Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCDateOfDeclaration"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Place Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCPlaceOfDeclaration"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Verification Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationDate"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeName"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Designation", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeDesignation"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Verification Branch", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCVerificationBranch"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Employee Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_KYCEmployeeCode"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("CKYC ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CKYCID"));
               

                break;

            case "CC":

            	//wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));

              //  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));
            	
            	//new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"))));
            	//wrap.wait(2000);
                
            	/*wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"));*/
            	
            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).click();
            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID));
            	//wrap.wait(1000);
            	//BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(Keys.TAB);
            	
            	wrap.wait(500);
            	BaseProject.driver.findElement(By.xpath("//*[@id='KYCPlaceOfDeclaration']")).click();
            	wrap.wait(500);
            	//wrap.wait(1000);
            	BaseProject.driver.findElement(By.xpath("//*[@id='KYCPlaceOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID));
            	
            	
                
                /*wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCPlaceOfDeclaration"));*/
               
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationDate"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeName"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Designation", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeDesignation"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Branch", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationBranch"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeCode"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CKYC ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYC_CKYCid"));
                

                break;

            case "PL":

            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));
            	
            	//new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"))));
            	//wrap.wait(2000);
                
            	/*wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateOfDeclaration"));*/
            	
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Date Of Declaration", BaseProject.scenarioID));
            	//wrap.wait(1000);
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Date Of Declaration']/following-sibling::div//*[@id='KYCDateOfDeclaration']")).sendKeys(Keys.TAB);
            	
            	//wrap.wait(1000);
            	BaseProject.driver.findElement(By.xpath("//label[text()='KYC Place Of Declaration']/following-sibling::div//*[@id='KYCPlaceOfDeclaration']")).sendKeys(DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID));
            	
            	
                
                /*wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Place Of Declaration", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCPlaceOfDeclaration"));*/
               
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationDate"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Name", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeName"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Designation", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeDesignation"));
                
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Verification Branch", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationBranch"));
               
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("KYC Employee Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeCode"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CKYC ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYC_CKYCid"));
                

                break;

        }

    }

    @Then("^Verify if the validation of Field DateOfDeclaration is present under the category KYC$")
    public void verify_if_the_validation_of_Field_DateOfDeclaration_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isDateOfDeclarationDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCDateOfDeclaration"))).isDisplayed();
            logger.info("is DateOfDeclaration ==== " + isDateOfDeclarationDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }

    @Then("^Verify if the validation of Field PlaceOfDeclaration is present under the category KYC$")
    public void verify_if_the_validation_of_Field_PlaceOfDeclaration_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isPlaceOfDeclarationDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCPlaceOfDeclaration"))).isDisplayed();
            logger.info("is PlaceOfDeclaration ==== " + isPlaceOfDeclarationDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }

    @Then("^Verify if the validation of Field VerificationDate is present under the category KYC$")
    public void verify_if_the_validation_of_Field_VerificationDate_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
            //			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isVerificationDateDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCVerificationDate"))).isDisplayed();
            logger.info("is VerificationDate ==== " + isVerificationDateDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }
    }

    @Then("^Verify if the validation of Field EmployeeName is present under the category KYC$")
    public void verify_if_the_validation_of_Field_EmployeeName_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isEmployeeNameDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCEmployeeName"))).isDisplayed();
            logger.info("is VerificationDate ==== " + isEmployeeNameDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }

    @Then("^Verify if the validation of Field EmployeeDesignation is present under the category KYC$")
    public void verify_if_the_validation_of_Field_EmployeeDesignation_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isEmployeeDesignationDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCEmployeeDesignation"))).isDisplayed();
            logger.info("is EmployeeDesignation ==== " + isEmployeeDesignationDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }

    @Then("^Verify if the validation of Field VerificationBranch is present under the category KYC$")
    public void verify_if_the_validation_of_Field_VerificationBranch_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isVerificationBranchDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCVerificationBranch"))).isDisplayed();
            logger.info("is VerificationBranch ==== " + isVerificationBranchDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }

    @Then("^Verify if the validation of Field EmployeeCode is present under the category KYC$")
    public void verify_if_the_validation_of_Field_EmployeeCode_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isKYCEmployeeCodeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_KYCEmployeeCode"))).isDisplayed();
            logger.info("is VerificationBranch ==== " + isKYCEmployeeCodeDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }


    @Then("^Verify if the validation of Field CKYCID is present under the category KYC$")
    public void verify_if_the_validation_of_Field_CKYCID_is_present_under_the_category_KYC() throws IOException, InterruptedException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
        try {
//			com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
            boolean isKYCCKYCIDDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("FullDatacapturemarker.properties", "FDC_CKYCID"))).isDisplayed();
            logger.info("is VerificationBranch ==== " + isKYCCKYCIDDisplayed);
        } catch (Exception e) {

            System.out.println("Field is read only");
        }

    }


    @Then("^FDM : Fill Application Details section in Application Details Tab$")
    public static void fillApplicatioDetails() throws IOException, InterruptedException {

        switch (product) {

            case "CC":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_PCOCallType"),
                        DBUtils.readColumnWithRowID("PCOCallType", BaseProject.scenarioID), "BYVISIBLETEXT");

                break;

            case "PL":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_PCOCallType"),
                        DBUtils.readColumnWithRowID("PCOCallType", BaseProject.scenarioID), "BYVISIBLETEXT");
                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Application Details Section");

          wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "final_Save"));

    }

    /*******************End of step definitions for Application Details tab**********************/


    /*******************
     * Start of step definitions for Income Docs tab
     ****************************/


    @Then("^FDM : Fill Documents in Document Details Tab for CASA$")
    public static void fillIDDocumnetsCASA() throws IOException, InterruptedException {
        wrap.wait(5000);
        FullDataMakerUtils.switchToDocumentsTab();
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

//        //Fatca
//        WebElement ele_fatca = wrap.getElement(BaseProject.driver, "//a[contains(@name,'FATCADocumentList_pyWorkPage.Customers')]");

        //Actions act=new Actions(BaseProject.driver);
        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);

//        myExecutor.executeScript("arguments[0].click();", ele_fatca);
//        wrap.wait(2000);

//        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FatcaDocumentDropdown"),
//                "FORM W8-BEN", "BYVISIBLETEXT");

//        wrap.wait(1000);

        //wrap.typeToTextBox(BaseProject.driver,"11/11/2018" ,com.getElementProperties("Fulldatacapturemaker","FatcaDocumentSignatorydate"));

        String documentSignatoryDate = com.getElementProperties("Fulldatacapturemaker", "DocumentSignatoryRequiredDate");

        WebElement w = BaseProject.driver.findElement(By.xpath(documentSignatoryDate));

        myExecutor.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", w, "value", "01/01/2015");

        //wrap.enterDate(BaseProject.driver, "01/01/2015", com.getElementProperties("Fulldatacapturemaker", "DocumentSignatoryRequiredDate"));

//        WebElement ele_PSD_CRS = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList')]");

//        myExecutor.executeScript("arguments[0].click();", ele_PSD_CRS);


        wrap.wait(2000);
        // CRS FATCA ANNEXURE
//        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"),
//                "CRS/ FATCA AOF ANNEXURE", "BYVISIBLETEXT");

//        wrap.wait(1000);

//        WebElement ele_PSD_CRS1 = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList') and @title='Add a tab ']");
//        myExecutor.executeScript("arguments[0].click();", ele_PSD_CRS1);

//        wrap.wait(4000);

//        //MID
//        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"));
//        wrap.wait(3000);
//        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"),
//                "MID", "BYVISIBLETEXT");


        wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "TaxOfResidence"), "IN");

        wrap.wait(4000);

        wrap.SelectAutosuggestionTextBox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "CRSReasoncode"),"B00");

        wrap.wait(3000);

        String documentComments = com.getElementProperties("Fulldatacapturemaker", "CRSComm");

        //wrap.type(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "CRSComm"), "Test");

        WebElement w1 = BaseProject.driver.findElement(By.xpath(documentComments));

        myExecutor.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", w1, "value", "Test");

        //wrap.captureScreenShot(BaseProject.driver, "ID Document section");

    }

    @Then("^FDM : Upload docs$")
    public static void uploaCASA() throws Throwable {
        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docList"));

        wrap.wait(7000);

        switchFrame();

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadToApplicant"), "1", "BYINDEX");
        wrap.wait(2000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docCategoryToUpload"), "6", "BYINDEX");
        wrap.wait(4000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docTypeToUpload"), "FORM W8-BEN", "BYVISIBLETEXT");
        wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "chooseFile"));
        wrap.wait(9000);
        Runtime.getRuntime().exec("C:" + File.separator + "auto" + File.separator + "upload.exe");
        wrap.wait(7000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadDoc"));
        wrap.wait(10000);
        logger.info(wrap.getTextValue(BaseProject.driver, "//div[@id='CT' and contains(@swp,'IsDocUploaded') and contains(@show_when,'true') and not(contains(@style,'display:none'))]//div[text()]"));

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "resetDoc"));
        wrap.wait(3000);


        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadToApplicant"), "1", "BYINDEX");
        wrap.wait(2000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docCategoryToUpload"), "5", "BYINDEX");
        wrap.wait(4000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docTypeToUpload"), "CRS/ FATCA AOF ANNEXURE", "BYVISIBLETEXT");
        wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "chooseFile"));
        wrap.wait(9000);
        Runtime.getRuntime().exec("C:" + File.separator + "auto" + File.separator + "upload.exe");
        wrap.wait(7000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadDoc"));


        wrap.wait(3000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "resetDoc"));
        wrap.wait(3000);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadToApplicant"), "1", "BYINDEX");
        wrap.wait(2000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docCategoryToUpload"), "5", "BYINDEX");
        wrap.wait(4000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "docTypeToUpload"), "MID", "BYVISIBLETEXT");
        wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "chooseFile"));
        wrap.wait(9000);
        Runtime.getRuntime().exec("C:" + File.separator + "auto" + File.separator + "upload.exe");
        wrap.wait(7000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "uploadDoc"));


        wrap.wait(3000);


        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "submitUpload"));
        wrap.switch_to_default_Content(BaseProject.driver);


    }


    @Then("^FDM : Fill Documents in Document Details Tab for TD$")
    public static void fillDocumnetsTD() throws IOException, InterruptedException {
        wrap.wait(5000);
        FullDataMakerUtils.switchToDocumentsTab();
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");
        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);

        // client id

        // client tax


        List<WebElement> ele = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='.OptionalTaxDocs']//td");

        for (int mk = 0; mk < ele.size(); mk += 2) {


            if (ele.get(mk).getText().contains("Mandatory")) {
                String mandat = ele.get(mk + 1).getText();
                String[] mandatory = mandat.split(",");
                for (int c1 = 0; c1 < mandatory.length; c1++) {

                    WebElement ele_PSD_tax = wrap.getElement(BaseProject.driver, "//a[contains(@name,'TaxDocumentList_pyWorkPage') and @title='Add a tab ']");
                    myExecutor.executeScript("arguments[0].click();", ele_PSD_tax);

                    wrap.wait(4000);

                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "TaxDocumentDropdown"));
                    wrap.wait(3000);
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "TaxDocumentDropdown"),
                            mandatory[0], "BYVISIBLETEXT");


                }

            }
        }


        // fatca


        WebElement ele_fatca = wrap.getElement(BaseProject.driver, "//a[contains(@name,'FATCADocumentList_pyWorkPage.Customers')]");


        myExecutor.executeScript("arguments[0].click();", ele_fatca);
        wrap.wait(2000);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FatcaDocumentDropdown"),
                "FORM W8-BEN", "BYVISIBLETEXT");

        wrap.wait(1000);

        wrap.enterDate(BaseProject.driver, "11/11/2018", com.getElementProperties("Fulldatacapturemaker", "FatcaDocumentSignatorydate"));

        WebElement ele_PSD_CRS = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList')]");

        myExecutor.executeScript("arguments[0].click();", ele_PSD_CRS);


        wrap.wait(2000);

        // clent verification

        //credit assessment

        //product supporting

        List<WebElement> ele1 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='.OptionalProdDocs']//td");
        // String xp="//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='.OptionalProdDocs']//td";

        Boolean flag1 = false, flag2 = false;
        for (int mk = 0; mk < ele1.size(); mk += 2) {


            ele1 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='.OptionalProdDocs']//td");
            new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele1.get(mk)));


            if (ele1.get(mk).getText().contains("Mandatory")) {
                new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele1.get(mk + 1)));
                String mandat1 = ele1.get(mk + 1).getText();
                String[] mandatoryy = mandat1.split(",");
                for (int c1 = 0; c1 < mandatoryy.length; c1++) {

                    logger.info(mandatoryy[c1]);

                    if (mandatoryy[c1].contains("MID"))
                        flag1 = true;

                    if (mandatoryy[c1].contains("CRS/ FATCA AOF ANNEXURE"))
                        flag2 = true;

                    WebElement ele_PSD_pro = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList') and @title='Add a tab ']");

                    new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele_PSD_pro));

                    myExecutor.executeScript("arguments[0].click();", ele_PSD_pro);

                    wrap.wait(4000);

                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"));
                    wrap.wait(3000);

                    if (mandatoryy[c1].contains("ANNEXURE-2 FOR SPECIAL")) {


                        mandatoryy[c1] = "ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)";
                        logger.info(mandatoryy[c1]);
                    }


                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"),
                            mandatoryy[c1], "BYVISIBLETEXT");
                    wrap.wait(2000);


                }

            }
        }
        if (flag1 == false) {
            WebElement ele_PSD_pro = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList') and @title='Add a tab ']");

            new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele_PSD_pro));

            myExecutor.executeScript("arguments[0].click();", ele_PSD_pro);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"));

            wrap.wait(3000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"), "MID", "BYVISIBLETEXT");

        }


        if (flag2 == false) {

            wrap.wait(2000);
            WebElement ele_PSD_pro = wrap.getElement(BaseProject.driver, "//a[contains(@name,'ProdDocumentList') and @title='Add a tab ']");

            new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele_PSD_pro));

            myExecutor.executeScript("arguments[0].click();", ele_PSD_pro);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"));

            wrap.wait(3000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PDSDocumentDropdown"), "CRS/ FATCA AOF ANNEXURE", "BYVISIBLETEXT");


        }


        WebElement ele_other_pro = wrap.getElement(BaseProject.driver, "//a[contains(@name,'InternalDocumentList') and @title='Add a tab ']");

        new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele_other_pro));

        myExecutor.executeScript("arguments[0].click();", ele_other_pro);

        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "TaxOfResidence"), "code", "IN");

        wrap.wait(9000);

        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "CRSReasoncode"), "code", "B00");

        wrap.wait(2000);

        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "CRSReasoncode"), "code", "B00");


        WebElement ele_internal = wrap.getElement(BaseProject.driver, "//a[contains(@name,'InternalDocumentList_pyWorkPage') and @title='Delete this tab ']");

        new WebDriverWait(BaseProject.driver, 20).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(ele_internal));

        myExecutor.executeScript("arguments[0].click();", ele_internal);

    }


    @Then("^FDM : Fill ID Documents in Document Details Tab$")
    public static void fillIDDocumnetsAppTab() throws IOException, InterruptedException {

        FullDataMakerUtils.switchToDocumentsTab();
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","FullDataCapture");

        List<WebElement> ty = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.DocumentList' and @tabgroupid='SubSectionDocumentListBTR']//ul//li/a");

        boolean flag = false;

        for (WebElement ele : ty)

        {
            ele.click();

            List<WebElement> count = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentList')]//select[@id='DocumentName']");

            if (count.size() == 0) {
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));

                wrap.wait(3000);

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));

                wrap.wait(3000);
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));

            } else

            {

                flag = true;
                break;

            }

        }

        WebElement IDDocuments = wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//h2[text()='ID Documents']");
        String mandat, optional;
        if (IDDocuments.getText().contains("ID Documents")) {

            List<WebElement> ele = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='OptionalIDDocs.pxResults']//td");
            Boolean documentpresent = false;
            for (int mk = 0; mk < ele.size(); mk += 2) {


                if (ele.get(mk).getText().contains("Mandatory")) {
                    mandat = ele.get(mk + 1).getText();
                    String[] mandatory = mandat.split(",");
                    for (int c1 = 0; c1 < mandatory.length; c1++) {

                        if (flag == false) {
                            List<WebElement> ty3 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.DocumentList' and @tabgroupid='SubSectionDocumentListBTR']//ul//li/a");

                            Actions builder = new Actions(BaseProject.driver);
                            int hh = ty3.size();
                            while (ty3.size() == hh) {

                                builder.moveToElement(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//a[starts-with(@name,'DocumentList_pyWorkPage.Customers(')and @title='Add a tab ']"))).click().build().perform();
                                wrap.wait(3000);
                                ty3 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.DocumentList' and @tabgroupid='SubSectionDocumentListBTR']//ul//li/a");
                                flag = true;
                            }
                        }


                        wrap.wait(3000);
                        logger.info(mandatory[c1].toUpperCase());
                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                                mandatory[c1].toUpperCase(), "BYVISIBLETEXT");

                        wrap.wait(3000);

                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));

                        wrap.wait(1000);
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));
                        wrap.wait(2000);
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));

                        wrap.wait(3000);
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));
                        wrap.wait(1000);
                        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));

                        wrap.wait(3000);
                    }

                } else if (ele.get(mk).getText().contains("Any One")) {
                    optional = ele.get(mk + 1).getText();

                    String[] optionals = optional.split(",");
                    List<WebElement> ty2 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.DocumentList' and @tabgroupid='SubSectionDocumentListBTR']//ul//li/a");
                    Actions builder = new Actions(BaseProject.driver);
                    int hh = ty2.size();
                    while (ty2.size() == hh) {


                        builder.moveToElement(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//a[starts-with(@name,'DocumentList_pyWorkPage.Customers(')and @title='Add a tab ']"))).click().build().perform();

                        wrap.wait(3000);
                        ty2 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.DocumentList' and @tabgroupid='SubSectionDocumentListBTR']//ul//li/a");

                    }

                    wrap.wait(3000);
                    logger.info(optionals[0]);

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                            optionals[0].toUpperCase(), "BYVISIBLETEXT");

                    wrap.wait(3000);

                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));
                    wrap.wait(1000);
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));
                    wrap.wait(2500);
                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));
                    wrap.wait(3000);
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));
                    wrap.wait(1000);
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));

                    wrap.wait(3000);

                }

            }

        }

        //wrap.captureScreenShot(BaseProject.driver, "ID Document section");
    }


    @Then("^FDM : Fill Address Documents in Document Details Tab$")
    public static void fillAddressDocumnetsAppTab() throws IOException, InterruptedException {

        //FullDataMakerUtils.switchToDocumentsTab();

        List<WebElement> ty = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.AddressDocumentList' and @tabgroupid='SubSectionAddressDocumentListBTR']//ul//li/a");

        boolean flag = false;

        for (WebElement ele : ty)

        {
            ele.click();

            List<WebElement> count = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionAddressDocumentList')]//select[@id='DocumentName']");

            if (count.size() == 0) {
                wrap.wait(3000);

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentNumber"));
                wrap.wait(3000);
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentSignatorydate"));
                wrap.wait(3000);
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentExpiryDate"));


            } else

            {

                flag = true;
                break;

            }

        }

        WebElement AddressDocuments = wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//h2[text()='Address Documents']");
        String mandat, optional;
        logger.info(AddressDocuments.getText());
        if (AddressDocuments.getText().contains("Address Documents")) {

            List<WebElement> ele = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//table[@pl_prop='OptionalAddressDocs.pxResults']//td");
            //Boolean documentpresent=false;
            for (int mk = 0; mk < ele.size(); mk += 2) {
                if (ele.get(mk).getText().contains("Mandatory")) {
                    mandat = ele.get(mk + 1).getText();
                    String[] mandatory = mandat.split(",");
                    for (int c1 = 0; c1 < mandatory.length; c1++) {

                        if (flag == false) {
                            List<WebElement> ty4 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.AddressDocumentList' and @tabgroupid='SubSectionAddressDocumentListBTR']//ul//li/a");


                            Actions builder = new Actions(BaseProject.driver);
                            int hh = ty4.size();
                            while (ty4.size() == hh) {

                                builder.moveToElement(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//a[contains(@name,'AddressDocumentList_pyWorkPage.Customers(')and @title='Add a tab ']"))).click().build().perform();

                                wrap.wait(3000);
                                ty4 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.AddressDocumentList' and @tabgroupid='SubSectionAddressDocumentListBTR']//ul//li/a");

                            }
                            flag = true;
                        }


                        wrap.wait(3000);

                        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_NameoftheDocument1"),
                                mandatory[c1].toUpperCase(), "BYVISIBLETEXT");

                        wrap.wait(3000);

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentNumber"));
                        wrap.wait(3000);

                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentSignatorydate"));
                        wrap.wait(3000);
                        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentExpiryDate"));

                    }

                }
                if (ele.get(mk).getText().contains("Any One")) {
                    logger.info("Any one");
                    optional = ele.get(mk + 1).getText();

                    String[] optionals = optional.split(",");
                    if (flag == false) {
                        List<WebElement> ty6 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.AddressDocumentList' and @tabgroupid='SubSectionAddressDocumentListBTR']//ul//li/a");

                        Actions builder = new Actions(BaseProject.driver);
                        int hh = ty6.size();
                        while (ty6.size() == hh) {


                            builder.moveToElement(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//a[contains(@name,'AddressDocumentList_pyWorkPage.Customers(')and @title='Add a tab ']"))).click().build().perform();

                            wrap.wait(3000);
                            ty6 = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[@pl_prop='.AddressDocumentList' and @tabgroupid='SubSectionAddressDocumentListBTR']//ul//li/a");

                        }
                        flag = true;
                    }


                    wrap.wait(3000);
                    logger.info(optionals[0].toUpperCase());

                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_NameoftheDocument1"));
                    wrap.wait(2000);

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_NameoftheDocument1"),
                            "1", "BYINDEX");

                    wrap.wait(3000);

                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentNumber"));

                    wrap.wait(3000);
                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentSignatorydate"));

                    wrap.wait(3000);
                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_Address_Detail_DocumentExpiryDate"));

                }


            }


        }

        //wrap.captureScreenShot(BaseProject.driver, "Address Document Details");
    }


    @Then("^FDM : Fill Bank Statement info in Document Tab$")
    public static void fillBankstatement() throws IOException, InterruptedException {

//FullDataMakerUtils.switchToIncomeDocsTab();
        if (wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//span[text()='Mandatory Documents']//following-sibling::div//span").getText().contains("BankStatement") || wrap.getElement(BaseProject.driver, "//span[text()='Any One or More documents to be selected from :']//following-sibling::div//span").getText().contains("BankStatement")) {
            logger.info("im in bank statement");
            if (wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "BankStatement")).getText().contains("BankStatement")) {

                wrap.wait(1000);
                Actions builder = new Actions(BaseProject.driver);


                builder.moveToElement(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//span[text()='BankStatement']"))).click().build().perform();


                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "BankStatement"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "BankingDocumentStatus_Payslip"), "Received", "BYVISIBLETEXT");
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfCustomerInitiatedTransactions"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfInterestCredits"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfDebitCharges"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfChequeBounceCharges"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfDebitTransactions"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfInwardChequeReturns"));
                wrap.typeToTextBox(BaseProject.driver, "6", com.getElementProperties("Fulldatacapturemaker", "NoOfOutwardChequeReturns"));

                for (int y = 1; y <= 3; y++) {
                    if (y == 1)
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "month1"));

                    if (y == 2)
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "month2"));
                    if (y == 3)
                        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "month3"));

                    wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("DocumentIssueDate", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "DocumentIssueDate"));

                    wrap.type(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlySalesTurnover"));
                    wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1HLLoanLimit"));
                    wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1Shareholding_Percentage"));
                    wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1HLLoanCommitment"));
                    wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1ThreeMonthAvgBalance"));
                    wrap.typeToTextBox(BaseProject.driver, "7", com.getElementProperties("Fulldatacapturemaker", "Field1SalaryCredit"));

                }

            }
        }
        //wrap.captureScreenShot(BaseProject.driver, "Bank Statement Details");
    }

    @Then("^FDM : Fill Annual Bonus info in Document Tab$")
    public static void fillAnnualBonus() throws IOException, InterruptedException {

        if (wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//span[text()='Mandatory Documents']//following-sibling::div//span").getText().contains("AnnualBonusLetter")) {
            logger.info("im in anual bonus");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "AnnualBonusLetter"));

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");
        }

        //wrap.captureScreenShot(BaseProject.driver, "Annual Bonus Details");

    }

    @Then("^FDM : Fill Payslip info in Document Tab$")
    public static void fillPayslip() throws IOException, InterruptedException {
        logger.info(wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//span[text()='Mandatory Documents']//following-sibling::div//span").getText());

        wrap.wait(5000);
        if (wrap.getElement(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//span[text()='Mandatory Documents']//following-sibling::div//span").getText().contains("Payslip") || wrap.getElement(BaseProject.driver, "//span[text()='Any One or More documents to be selected from :']//following-sibling::div//span").getText().contains("Payslip")) {
            logger.info("im in payslip");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Payslips"));

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");


            for (int y = 1; y <= 3; y++) {
                if (y == 1)
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Month1"));

                if (y == 2)
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Month2"));

                if (y == 3)
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Month3"));

                wrap.wait(4500);
                wrap.type(BaseProject.driver, "11/05/2017", com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Month_issuedate"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1BasicMonthlySalary"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlyBonus"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlyAllowance"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlyRental"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlyCommission"));
                wrap.wait(4500);
                wrap.type(BaseProject.driver, "9", com.getElementProperties("Fulldatacapturemaker", "Field1MonthlyVariableBonus"));

            }

        }
        //wrap.captureScreenShot(BaseProject.driver, "Payslip Details");
    }


    @Then("^FDM : Fill Action and Remarks Tab$")
    public static void fillActionRemarks() throws IOException, InterruptedException {

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Action_DropDown"),
                DBUtils.readColumnWithRowID("Action_dropdown", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Remarks", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Remarks_TextArea"));

        //wrap.captureScreenShot(BaseProject.driver, "Remarks");

        wrap.wait(2000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "final_Save"));

        wrap.wait(10000);

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "Submit"));

        wrap.wait(5000);
    }

    /*******************
     * Start of Functions other than step definitions
     *******************/


	/*@Then("^FDM : Fill Joint Applicants data$")
	public static void fillJointApplicants() throws IOException, InterruptedException{

		while(fDC_Co_Applicant<FullDataMakerUtils.noOfApplicants()){

		FullDataMakerUtils.switchToNextCoapplicant();

		fillCustomerPersonalDetailSectionsJoint();
		fillAddressSectionJoint();
		fillContactCommunicationSectionsJoint();
		fillEmploymentSectionJoint() ;
		fillFATCAandGSTSectionsJoint();
		fillContactCommunicationSectionsJoint();
		fillCDDInternalSectionsJoint();
		fillSignatureFinancialSectionsJoint();
		fillCDDOATMarketingSectionsJoint();

		}

	}	*/
    @Then("^FDM : Fill All Product details$")
    public static void fillAllProductDetails() throws IOException, InterruptedException {

        while (fDC_Multiple_Product < FullDataMakerUtils.noOfProducts()) {

            FullDataMakerUtils.switchToNextProduct();

            fillProductACSetupSection();
            fillProductRequestSection();
            fillRepaymentSection();
            fillDisbursementSection();
            fillBankUseSection();

        }

    }


	/*public static void fillCustomerPersonalDetailSectionsJoint() throws InterruptedException, IOException{

switch(product){

		case "CA":

			break;

		case "SA":

			break;

		case "TD":

			break;

		case "CC":

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Gender_DropDown"),
					DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_MaritalStatus_DropDown"),
					DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Qualification_DropDown"),
					DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Place Of Birth", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Placeofbirth_TextBox"));

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Constitutioncode"),
					DBUtils.readColumnWithRowID("Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("No Of Dependants", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_CPD_NoOfDependants_textbox"));

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CPD_ConnectedLendingRelationship_dropdown"),
					DBUtils.readColumnWithRowID("Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CPD_ResidentialStatus_dropdown"),
					DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

			break;

		case "PL":

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Gender_DropDown"),
					DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_MaritalStatus_DropDown"),
					DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Qualification_DropDown"),
					DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Place Of Birth", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Placeofbirth_TextBox"));

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_Constitutioncode"),
					DBUtils.readColumnWithRowID("Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("No Of Dependants", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_CPD_NoOfDependants_textbox"));

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CPD_ConnectedLendingRelationship_dropdown"),
					DBUtils.readColumnWithRowID("Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CPD_ResidentialStatus_dropdown"),
					DBUtils.readColumnWithRowID("Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

			break;

		}

	}
	*/

    public static void fillAddressSectionJoint() throws InterruptedException, IOException {

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

			/*wrap.typenewSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AddressSection_AddressType_suggestionBox"), "code",
					DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID),DBUtils.readColumnWithRowID("Address code", BaseProject.scenarioID));
			*/
                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), "code",
                        DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID));


                /*****************************Residence Type field is available for RES Address Type only***********************************/

                if (DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID).equalsIgnoreCase("A1 Residence Address")) {

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType"),
                            DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                }

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 2", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 3", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("City", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Country_suggestionBox"), "code",
                        DBUtils.readColumnWithRowID("Country", BaseProject.scenarioID));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Zip Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year"));
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month"));

                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AddressSection_Residential_Address_Yes"));

                break;

            case "PL":

			/*wrap.typenewSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AddressSection_AddressType_suggestionBox"), "code",
					DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID),DBUtils.readColumnWithRowID("Address code", BaseProject.scenarioID));
			*/
                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), "code",
                        DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID));


                /*****************************Residence Type field is available for RES Address Type only***********************************/

                if (DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID).equalsIgnoreCase("A1 Residence Address")) {

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType"),
                            DBUtils.readColumnWithRowID("Residence Type", BaseProject.scenarioID), "BYVISIBLETEXT");

                }

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 2", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 3", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("City", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Country_suggestionBox"), "code",
                        DBUtils.readColumnWithRowID("Country", BaseProject.scenarioID));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Zip Code", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year"));
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month"));

                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_AddressSection_Residential_Address_Yes"));

                break;

        }

    }

	/*public static void fillContactCommunicationSectionsJoint() throws InterruptedException, IOException{

switch(product){

		case "CA":

			break;

		case "SA":

			break;

		case "TD":

			break;

		case "CC":

			*//**********************************Filling Contact section********************************************//*

			//wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID(	"Extension Details", BaseProject.scenarioID) ,
				//	com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_ExtensionDetails_TextBox"));

			wrap.click(BaseProject.driver,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_PrefferedContact_CheckBox"));

			*/

    /**********************************
     * Filling Communication section
     ********************************************//*

			wrap.typeInSuggestionTextbox(BaseProject.driver,
					com.getElementProperties("Fulldatacapturemaker","FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"), "code",
					DBUtils.readColumnWithRowID("Advice Detail Address Type",BaseProject.scenarioID));

			break;

		case "PL":


			break;

		}

	}
	*/
    public static void fillEmploymentSectionJoint() throws InterruptedException, IOException {

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes"));

                FullDataMakerUtils.selectWorkType();

                break;

            case "PL":


                break;

        }

    }

	/*public static void fillFATCAandGSTSectionsJoint() throws InterruptedException, IOException{

switch(product){

		case "CA":

			break;

		case "SA":

			break;

		case "TD":

			break;

		case "CC":

			*//**********************Filling FATCA section**************************//*

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes"));

			wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_FATCACountryofTreaty"), "code",
					DBUtils.readColumnWithRowID("FATCA Country of Treaty", BaseProject.scenarioID));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_DocumentSignatorydate"));

			*/

    /**********************
     * Filling GST section
     *****************************//*

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_CustomerType_Yes"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_SpecificStatus_Yes"));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("GST Registration Number", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_GSTRegistrationNumber"));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("GST State", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_State"));

			break;

		case "PL":

			break;

		}

	}
	*/
    public static void fillDocumentSectionJoint() throws InterruptedException, IOException {

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentCategory1_joint"),
                DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1_joint"),
                DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber_joint"));

        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentSignatorydate_joint"));

        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentExpiryDate_joint"));

    }

	/*public static void fillCDDInternalSectionsJoint() throws InterruptedException, IOException{

	switch(product){

			case "CA":

				break;

			case "SA":

				break;

			case "TD":

				break;

			case "CC":


				*//**********************Filling CDD section**********************************//*

				wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_sourceOfInitalFund_joint"), "code",
						DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

				wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID) ,
						com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_descriptionOfInitalFund_joint"));

				wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_typeOfInitalFund_joint"),
						DBUtils.readColumnWithRowID("Type(s) of initial funding", BaseProject.scenarioID), "BYVISIBLETEXT");

				wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Amount of Initial Funding", BaseProject.scenarioID) ,
						com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_amountOfInitalFund_joint"));

				wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Date initial funding is expected to be placed", BaseProject.scenarioID) ,
						com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_dateInitilaFund_joint"));

				break;


			case "PL":

				break;
		}

	}*/

	/*public static void fillSignatureFinancialSectionsJoint() throws InterruptedException, IOException{

		*//**********************Filling Signature section*****************************//*

		wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"));

	}*/

	/*public static void fillCDDOATMarketingSectionsJoint() throws InterruptedException, IOException{

		*/

    /**********************
     * Filling CDD OAT section
     *****************************//*

		wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD(OAT)_numbered_account/passbook?Yes_joint"));


		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD(OAT)_Other_risk_factors_joint"),
				DBUtils.readColumnWithRowID("Other risk factors/ Local Regulations/ Stringent rules applied in country?", BaseProject.scenarioID), "BYVISIBLETEXT");

	}
	*/
    public static void fillProductACSetupSectionCC() throws IOException {

        switch (productName) {

            case "108":

                break;

            default:

                break;

        }

    }

    public static void fillProductACSetupSectionPL() throws IOException {

        switch (productName) {

            case "PL002":

                break;

            default:

                break;

        }

    }

    /***********
     * End of Functions other than step definitions
     *
     * @throws IOException
     * @throws InterruptedException
     * @throws SQLException
     * @throws ClassNotFoundException
     ***********/

	/*@Then("^FDM : Validate Field '(.+)'$")
	public static void validateFieldStep(String FieldName) throws IOException, InterruptedException{

		CommonUtilsData.FieldNameData = FieldName;

		CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");

		try{

			if(!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)){

				CommonUtils.validateField(
						CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData));

			}
		}

		catch(Exception E){

			System.out.println("Field : "+FieldName+" is not present in Datamodel");
		}

	}
	*/


    //////////////// Neethu code starts here for Co-Applicant //////////////////////////////////
    @Then("^FDM : Fill Joint Applicants data$")
    public static void fillJointApplicants() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

//		wrap.wait(5000);
//		wrap.switch_to_default_Content(BaseProject.driver);
//		wrap.wait(1000);
//
//		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
//		wrap.wait(2000);

        /*******Swtiching to Customer Details Tab*********/

        FullDataMakerUtils.switchToCustomerDetailsTab();

        logger.info("Number of Applicants is/are : " + FullDataMakerUtils.noOfApplicants());

        while (fDC_Co_Applicant < FullDataMakerUtils.noOfApplicants()) {
            logger.info("filling next applicant");
            FullDataMakerUtils.switchToNextCoapplicant();
//            if (fDC_Co_Applicant == 0) {
//                fillCustomerPersonalDetailSections();
//                fillAliasRelatedPartySections();
//                fillcontactAddressSection();
//                fillCommunicationSections();
//                fillEmploymentSection();
//                fillFATCAandGSTSections();
//                fillCDDInternalSections();
//                fillSignatureFinancialSections();
//                fillbankingservicedetailssection();
//                fillfamilydetailssection();
//                fillCDDOATMarketingSections();
//            } else
//            
            {

                fillCustomerPersonalDetailSectionsJoint();
                fillAliasRelatedPartySectionsJoint();
                fillAddressSectionJoint(fDC_Co_Applicant);
                fillContactCommunicationSectionsJoint();
                fillEmploymentSectionJoint(fDC_Co_Applicant);
                fillFATCAandGSTSectionsJoint();
                fillCDDInternalSectionsJoint();
                fillSignatureFinancialSectionsJoint();
                fillbankingservicedetailssectionJoint();
                fillfamilydetailssectionJoint();
                fillCDDOATMarketingSectionsJoint();
            }
            FullDataMaker.fDC_Co_Applicant++;
            logger.info("The co-applicant count has been incremented to : " + fDC_Co_Applicant);
            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "final_Save"));

            wrap.wait(3000);

        }

    }

    public static void fillCustomerPersonalDetailSectionsJoint() throws InterruptedException, IOException, ClassNotFoundException, SQLException {

    	DBUtils.convertDBtoMap("fdquery_joint");
    	
    	logger.info("Am in co-applicant personal details section");

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        /*******Filling Personal Details section in Customer Details Tab - Joint Co-applicant*********/
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_Gender_Joint"));

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_Gender_Joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Gender", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_MaritalStatus_Joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Marital Status", BaseProject.scenarioID), "BYVISIBLETEXT");

        Select msj = new Select(wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_MaritalStatus_Joint")));
        mar_Sta_joint = msj.getFirstSelectedOption().getText();

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_Qualification_Joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Educational Qualification", BaseProject.scenarioID), "BYVISIBLETEXT");

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Place Of Birth", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_CD_Placeofbirth_joint"));

        //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");

        switch (product) {

            case "CA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature of Relationship with Primary Applicant", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");
                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");
                break;

            case "SA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature of Relationship with Primary Applicant", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");

                break;

            case "TD":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ConstitutionCode_Joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ConstitutionCode_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature of Relationship with Primary Applicant", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");
                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");

                break;

            case "CC":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ConstitutionCode_Joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ConstitutionCode_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature of Relationship with Primary Applicant", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " No Of Dependants", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_NoDependants_Joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");
                break;

            case "PL":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ConstitutionCode_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Constitution Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature of Relationship with Primary Applicant", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_ResidenceStatus_Joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residential Status", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " No Of Dependants", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_NoDependants_Joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Connected Lending Relationship", BaseProject.scenarioID), "BYVISIBLETEXT");

                //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail Joint");
                break;

        }

    }

    public static void fillAliasRelatedPartySectionsJoint() throws IOException, InterruptedException {
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");
        switch (product) {

            case "CA":

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " House Hold ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber")).sendKeys(Keys.TAB);

                //wrap.captureScreenShot(BaseProject.driver, "Joint Alias and Related Party Section");
                break;

            case "SA":

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " House Hold ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber")).sendKeys(Keys.TAB);
       
                //wrap.captureScreenShot(BaseProject.driver, "Joint Alias and Related Party Section");

                break;

            case "TD":

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " House Hold ID", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Relationship Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber")).sendKeys(Keys.TAB);
                //wrap.captureScreenShot(BaseProject.driver, "Joint Alias and Related Party Section");

                break;

            case "CC":


                break;

            case "PL":

                break;

        }

    }


    public static void fillAddressSectionJoint(int y) throws InterruptedException, IOException {


        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        logger.info("Am in Joint Address Section");
        /**********************************Filling Contact section********************************************/
        wrap.wait(2000);
        if (!wrap.getElement(BaseProject.driver,
                com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_PreferredContact_joint")).isSelected()) {
            logger.info("Am in contact section and am going to click on check box");
         
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_PreferredContact_joint"));
           

            //wrap.captureScreenShot(BaseProject.driver, "Joint Contact Section");
        }


        /**********************************Filling Address section********************************************/

        FullDataMakerUtils.fillCommonAddressfieldsjoint(y);

        switch (product) {

            case "CA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));
                wrap.wait(2000);
                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC1_CD_AddressSection_Residential_Address_Yes"));

                //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");
                break;

            case "SA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));
                wrap.wait(2000);
                //	wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC1_CD_AddressSection_Residential_Address_Yes"));

                //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");
                break;

            case "TD":
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));
                wrap.wait(2000);
                //	wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC1_CD_AddressSection_Residential_Address_Yes"));

                //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");
                break;

            case "CC":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint"));

                wrap.wait(4000);
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint"));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressYY", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthYY_Joint"));

                wrap.wait(5000);
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressMM", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthMM_Joint"));
                wrap.wait(2000);

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));

                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC1_CD_AddressSection_Residential_Address_Yes"));

                //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");
                break;

            case "PL":

                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FD_Address_Area_Joint"));
                logger.info("Am in pl block of address section");
                wrap.wait(4000);
			/*wrap.type(BaseProject.driver,DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Area", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FD_Address_Area_Joint"));*/

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressYY", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthYY_Joint"));

                wrap.wait(4000);
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressMM", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthMM_Joint"));
                wrap.wait(2000);

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));

                //wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC1_CD_AddressSection_Residential_Address_Yes"));

                //wrap.captureScreenShot(BaseProject.driver, "Joint Address Section");

                break;

        }

    }

    public static void fillContactCommunicationSectionsJoint() throws InterruptedException, IOException {

		/*wrap.typeInSuggestionTextbox(BaseProject.driver,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CS_AdviceDetailAddressType_suggessionBox_joint"), "code",
				DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Advice Detail Address Type",BaseProject.scenarioID));*/

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        /**********************************Filling Communication section********************************************/

        wrap.typeInSuggestionTextbox(BaseProject.driver,
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CS_AdviceDetailAddressType_suggessionBox_joint"), "code",
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Advice Detail Address Type", BaseProject.scenarioID));
        wrap.wait(2000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CS_MarkPref_DD_joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Marketing Preferences", BaseProject.scenarioID), "BYVISIBLETEXT");

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Joint Communication Section");
    }

    public static void fillEmploymentSectionJoint(int y) throws InterruptedException, IOException {
        logger.info("Am in Joint Employment section");
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        switch (product) {

            case "CA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
               
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

               
                Select sel = new Select(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")));
                String dd_text = sel.getFirstSelectedOption().getText();
                logger.info("Work Type - Drop down selected value is : " + dd_text);

		     /*wrap.wait(1000);
		     wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_StaffCategory_DropDown"),
						DBUtils.readColumnWithRowID("Staff Category", BaseProject.scenarioID), "BYVISIBLETEXT");
		     wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_StaffCategory_DropDown")).sendKeys(Keys.TAB);*/

                if (dd_text.contains("Salaried")) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Employer Relationship ID", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
                    wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox")).sendKeys(Keys.TAB);

                    
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                   
                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmployerName_joint"),
                            "code", DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Employer Name", BaseProject.scenarioID));
                } else if (dd_text.contains("Business")) {
                    
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
                }

                //wrap.captureScreenShot(BaseProject.driver, "Joint Employment Section");

                break;

            case "SA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
              
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

                Select sel_sa = new Select(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")));
                String sa_dd_text = sel_sa.getFirstSelectedOption().getText();
                logger.info("Work Type - Drop down selected value is : " + sa_dd_text);


                if (sa_dd_text.contains("Salaried")) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Employer Relationship ID", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
                    wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox")).sendKeys(Keys.TAB);

                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmployerName_joint"),
                            "code", DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Employer Name", BaseProject.scenarioID));
                } else if (sa_dd_text.contains("Business")) {
           
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
                }

                //wrap.captureScreenShot(BaseProject.driver, "Joint Employment Section");

                break;

            case "TD":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Work Type", BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

                wrap.wait(4000);
                Select sel_td = new Select(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")));
                String td_dd_text = sel_td.getFirstSelectedOption().getText();
                logger.info("Work Type - Drop down selected value is : " + td_dd_text);


                if (td_dd_text.contains("Salaried")) {
		     /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Employer Relationship ID", BaseProject.scenarioID),
		    		 com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox"));
		     wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FullDataCapture1_CustomerDetail_EmployerRelationshipID_TextBox")).sendKeys(Keys.TAB);*/

                    wrap.wait(2000);
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");

                    wrap.wait(1000);
                    wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmployerName_joint"),
                            "code", DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Employer Name", BaseProject.scenarioID));
                } else if (td_dd_text.contains("Business")) {
                    wrap.wait(2000);
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                            DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Nature Of Business", BaseProject.scenarioID), "BYVISIBLETEXT");
                }

                //wrap.captureScreenShot(BaseProject.driver, "Joint Employment Section");

                break;

            case "CC":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes_joint"));

                FullDataMakerUtils.selectWorkTypejoint(y);

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

            case "PL":

                logger.info("Am in PL account");
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes_joint"));

                FullDataMakerUtils.selectWorkTypejoint(y);

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

        }

    }

    public static void fillFATCAandGSTSectionsJoint() throws InterruptedException, IOException {
        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");
        switch (product) {

            case "CA":

                /**********************Filling FATCA section**************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes_joint"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"), "code",
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " FATCA Country of Treaty", BaseProject.scenarioID));

                /**********************Filling GST section*****************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).sendKeys(Keys.TAB);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint"));

                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));


                break;

            case "SA":

                /**********************Filling FATCA section**************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes_joint"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"), "code",
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " FATCA Country of Treaty", BaseProject.scenarioID));

                /**********************Filling GST section*****************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).sendKeys(Keys.TAB);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint"));

                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                break;

            case "TD":

                /**********************Filling FATCA section**************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes_joint"));

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes_joint"));

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_FATCACountryofTreaty_joint"), "code",
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " FATCA Country of Treaty", BaseProject.scenarioID));

                /**********************Filling GST section*****************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).sendKeys(Keys.TAB);
           
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint"));

                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                break;

            case "CC":

                /**********************Filling FATCA section**************************/

			/*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?Yes"));

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_IsCustomeraGreencardholder?Yes"));

			wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_FatcaSection_FATCACountryofTreaty"), "code",
					DBUtils.readColumnWithRowID("FATCA Country of Treaty", BaseProject.scenarioID));

			wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID("Document Signatory Date", BaseProject.scenarioID) ,
					com.getElementProperties("Fulldatacapturemaker","FullDataCapture_CustomerDetail_DocumentSignatorydate"));*/

                /**********************Filling GST section*****************************/

                String custTyYNopt = DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Customer Type", BaseProject.scenarioID);
                logger.info("Customer Type for Joint : " + custTyYNopt);
                if (custTyYNopt.equalsIgnoreCase("No"))
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_No_joint"));
                else if (custTyYNopt.equalsIgnoreCase("Yes"))
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
                else
                    logger.info("Incorrect selection has been made, other than Yes or No data");

                wrap.wait(2500);

                String specStatusYNopt = DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Specific status", BaseProject.scenarioID);
                logger.info("Specific Status for Joint : " + specStatusYNopt);

                if (specStatusYNopt.equalsIgnoreCase("No"))
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_No_joint"));
                else if (specStatusYNopt.equalsIgnoreCase("Yes"))
                    wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint"));
                else
                    logger.info("Incorrect selection has been made, other than Yes or No data");

			/*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_CustomerType_Yes_joint"));
			wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_CustomerType_Yes_joint")).sendKeys(Keys.TAB);
			wrap.wait(2000);

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_GSTDetails_SpecificStatus_Yes_joint"));*/

                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST Registration Number", BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                break;

            case "PL":

                /**********************Filling GST section*****************************/

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).sendKeys(Keys.TAB);

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes_joint"));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST Registration Number", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " GST State", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Joint FATCA & GST Section");

    }

    public static void fillCDDInternalSectionsJoint() throws InterruptedException, IOException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        /**********************Filling CDD section**********************************/

		/*wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Description of initial funding", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_descriptionOfInitalFund_joint"));

		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_typeOfInitalFund_joint"),
				DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Type(s) of initial funding", BaseProject.scenarioID), "BYVISIBLETEXT");

		wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Amount of Initial Funding", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_amountOfInitalFund_joint"));

		wrap.typeToTextBox(BaseProject.driver,DBUtils.readColumnWithRowID(Coapp+fDC_Co_Applicant+" Date initial funding is expected to be placed", BaseProject.scenarioID) ,
				com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_dateInitilaFund_joint"));*/


        switch (product) {

            case "CA":

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISCode_joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISValues_joint"));

                break;

            case "SA":

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISCode_joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISValues_joint"));

                break;

            case "TD":

			/*wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","FDC_CD_CDD_sourceOfInitalFund_joint"), "code",
					DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));*/

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISCode_joint"),
                        DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Code", BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " MIS Value", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_Internal_MISValues_joint"));

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "joint CDD & internal Section");
    }

    public static void fillSignatureFinancialSectionsJoint() throws InterruptedException, IOException {

        /**********************Filling Signature section*****************************/

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_AvailabilityofCustomerSignatureYes_Radio"));
        //wrap.captureScreenShot(BaseProject.driver, "joint AOF Signature Section");
    }


    public static void fillbankingservicedetailssectionJoint() throws IOException, InterruptedException {

        switch (product) {

            case "CA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint")).sendKeys(Keys.TAB);
                wrap.wait(3000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_MobileBankingY_Radio"));

                break;

            case "SA":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint")).sendKeys(Keys.TAB);
                wrap.wait(3000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_MobileBankingY_Radio"));

                break;

            case "TD":

//			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint"));
//			wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_OnlineBankingY_Radio_joint")).sendKeys(Keys.TAB);
//			wrap.wait(3000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_BSD_MobileBankingY_Radio"));

                break;

            case "CC":


                break;

            case "PL":

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Joint Banking Service Details Section");
    }

    public static void fillfamilydetailssectionJoint() throws IOException, InterruptedException {

        switch (product) {

            case "CA":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MaidenFirstName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherPrefix_joint"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherFirstName_joint"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherMiddleName_joint"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherPrefix_joint"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherFirstName_joint"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherMiddleName_joint"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpousePrefix_joint"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseFirstName_joint"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseMiddleName_joint"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseLastName_joint"));

                break;

            case "SA":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MaidenFirstName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherPrefix_joint"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherFirstName_joint"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherMiddleName_joint"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherPrefix_joint"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherFirstName_joint"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherMiddleName_joint"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpousePrefix_joint"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseFirstName_joint"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseMiddleName_joint"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseLastName_joint"));

                break;

            case "TD":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MaidenFirstName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherPrefix_joint"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherFirstName_joint"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherMiddleName_joint"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherPrefix_joint"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherFirstName_joint"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherMiddleName_joint"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpousePrefix_joint"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseFirstName_joint"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseMiddleName_joint"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseLastName_joint"));

                break;

            case "CC":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MaidenFirstName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherPrefix_joint"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherFirstName_joint"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherMiddleName_joint"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherPrefix_joint"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherFirstName_joint"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherMiddleName_joint"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpousePrefix_joint"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseFirstName_joint"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseMiddleName_joint"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseLastName_joint"));

                //FDM_Family_MotherMaidenName
                wrap.type(BaseProject.driver, "MothersMaidenName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MothersMaidenName_joint"));

                if (mar_Sta_joint.equalsIgnoreCase("MARRIED")) {
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseOccupation_joint"),
                            "HOUSEWIFE", "BYVISIBLETEXT");
                }

                wrap.type(BaseProject.driver, "1", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_Numberofchildren_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_Numberofchildren_joint")).sendKeys(Keys.TAB);


                wrap.type(BaseProject.driver, "Hirendra", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_NameoftheChild_joint"));
                wrap.type(BaseProject.driver, "2", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_AgeofChild_joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_GenderofChild_joint"),
                        "MALE", "BYVISIBLETEXT");
                wrap.wait(3000);

                break;

            case "PL":

                wrap.type(BaseProject.driver, "maidenfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MaidenFirstName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherPrefix_joint"),
                        "DR - Doctor", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "fatherfirstname", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherFirstName_joint"));

                wrap.type(BaseProject.driver, "fathermiddlename", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherMiddleName_joint"));

                wrap.type(BaseProject.driver, "fatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_FatherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherPrefix_joint"),
                        "PRF - Prof", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "MotherfirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherFirstName_joint"));

                wrap.type(BaseProject.driver, "MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherMiddleName_joint"));

                wrap.type(BaseProject.driver, "MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MotherLastName_joint"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpousePrefix_joint"),
                        "CAP - Captain", "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, "SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseFirstName_joint"));

                wrap.type(BaseProject.driver, "SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseMiddleName_joint"));

                wrap.type(BaseProject.driver, "SpouselastName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseLastName_joint"));

                //FDM_Family_MotherMaidenName
                wrap.type(BaseProject.driver, "MothersMaidenName", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MothersMaidenName_joint"));

                
                if (mar_Sta_joint.equalsIgnoreCase("MARRIED")) {
                    wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_SpouseOccupation_joint"),
                            "HOUSEWIFE", "BYVISIBLETEXT");
                }

                wrap.type(BaseProject.driver, "1", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_Numberofchildren_joint"));
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_Numberofchildren_joint")).sendKeys(Keys.TAB);
                wrap.wait(2000);

                wrap.type(BaseProject.driver, "Hirendra", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_NameoftheChild_joint"));
                wrap.type(BaseProject.driver, "2", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_AgeofChild_joint"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_GenderofChild_joint"),
                        "MALE", "BYVISIBLETEXT");
                

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Joint Family Details Section");
    }

    public static void fillCDDOATMarketingSectionsJoint() throws InterruptedException, IOException {

        //CommonUtils.convertExcelToMap(BaseProject.excelPath,"FullDataCapture.xls","Co-applicant");

        /**********************Filling CDD OAT section*****************************/

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDDOAT_numbered_AccOrPassbook_Yes_joint"));


        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDDOAT_OtherRiskFactors_joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Other risk factors", BaseProject.scenarioID), "BYVISIBLETEXT");

        /**********************Marketting Details*****************************/
     
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustTab_MarketingDetails_PrefContactTime_joint"));
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustTab_MarketingDetails_PrefContactTime_joint"),
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Preferred Contact Time", BaseProject.scenarioID), "BYVISIBLETEXT");

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "Joint CDD(OAT) & Marketing details Section");
    }

    ///////////// set-2 ///////////////////////

    @Then("^FDM : Fill Joint Applicant Documents$")
    public static void fillJointdocumentApplicants() throws IOException, InterruptedException {

        FullDataMakerUtils.switchToDocumentsTab();
        while (fDC_Co_Applicant1 < FullDataMakerUtils.noOfApplicantsindocument()) {
            logger.info("filling next applicant");
            FullDataMakerUtils.switchToNextdocumentCoapplicant();
            fillIDDocumnetsAppTab();
            fillAddressDocumnetsAppTab();
            fillBankstatement();
            fillAnnualBonus();
            fillPayslip();
            FullDataMaker.fDC_Co_Applicant1++;
        }
    }

    /////////////////////// Neethu code ends here for Co-Applicant //////////////////////////


    //////////////////////Balaji code for field level validation - started ///////////////////////////

    @Then("^FDM : Validate Field '(.+)'$")
    public static void validateFieldStep(String fieldName) throws IOException, InterruptedException {
    	
    	switchFrame();
    	
    	//BaseProject.propertiesFilename="Fulldatacapturemaker";

        CommonUtilsData.FieldNameData = fieldName;
        
        logger.info(CommonUtilsData.FieldNameData);

        //CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "Data_Updated");
		CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "DataModel_1011");

        try {

            if (!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)) {

            	logger.info(CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData));
                CommonUtils.validateField(
                		CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

            }
            
          //  BaseProject.scenario.write("The field " +fieldName+ " is validated successfully.UAT Reference is " +uatref);
            
        } catch (Exception E) {

            System.out.println("Field : " + fieldName + " is not present in Datamodel");
        }

    }
    
    
    @Then("^FDM : Validate Field with UATRef '(.+)' '(.+)'$")
    public static void validateFieldStepuatref(String fieldName,String uatref) throws IOException, InterruptedException {
    	
    	switchFrame();
    	
    	//BaseProject.propertiesFilename="Fulldatacapturemaker";

        CommonUtilsData.FieldNameData = fieldName;
        
        logger.info(CommonUtilsData.FieldNameData);

        //CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "Data_Updated");
		CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "DataModel_1011");

        try {

            if (!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)) {

            	logger.info(CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData));
                CommonUtils.validateField(
                		CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                		CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

            }
            
            BaseProject.scenario.write("The field " +fieldName+ " is validated successfully.UAT Reference is " +uatref);
            
        } catch (Exception E) {

            System.out.println("Field : " + fieldName + " is not present in Datamodel");
        }

    }


    @Then("^FDM : Validate Field values '(.+)'$")
	public static void validateFieldStepChecker(String FieldName) throws Throwable{

				logger.info("Going to switch into frame");
		
				switchFrame();
		
		      logger.info("Frame switched successfully");
		    //  JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		      
	//	String S = wrap.getElement(BaseProject.driver, com.getElementProperties("Checker", "Checker_PrimaryApplicant_Tab_XPATH")).getText();
		
	//	logger.info("The String is" + S);

		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"Datamodel.csv");
		try{

			if(!(Fieldval[0]).equalsIgnoreCase(null)){
				/*js.executeScript("arguments[0].scrollIntoView(true);",Fieldval[11]);
				wrap.click(BaseProject.driver, com.getElementProperties("Checker", Fieldval[11]));*/
				
				wrap.wait(2000);
				logger.info("Field validation starts"); 
						CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);

			}
		}

		catch(Exception E){

			System.out.println("Field : "+FieldName+" is not present in Datamodel");
		}            

	}
    
    ////////////////////// Balaji code for field level validation - ends here ///////////////////////////

    /******************************
     * Vijay's steps start
     *********************************/

    @Then("^FDM : Add Financial Details$")
    public static void validateAdditionalFieldsInCustomerDetailsTab() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToCustomerDetailsTab();

            WebElement element = wrap.getElement(BaseProject.driver, "//div[@sectionbodyid='SubSectionMoreFinancialDetailsB']//a[@title='Add a tab ']");
            ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);


            //More Financial Details - Add
            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionMoreFinancialDetailsB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);
            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Status"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Status"), "Existing", "BYVISIBLETEXT");
            wrap.wait(2000);


        } catch (Exception e) {

        }
    }

    @Then("^FDM : Select AccountType as Mortage$")

    public static void SelectMortage() throws IOException, InterruptedException {

        try {


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"), "Mortgage", "BYVISIBLETEXT");
            wrap.wait(2000);


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestType"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestType"), "Floating", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }


    @Then("^FDM : Account Type as CC$")
    public static void accountTypeAsCC() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToCustomerDetailsTab();

            WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));
            ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"), "Credit Card", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }

    @Then("^FDM : Account Type as Insurance$")
    public static void accountTypeAsInsurance() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToCustomerDetailsTab();

            WebElement element = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));
            ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AccountType"), "Insurance", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }

    }


    @Then("^FDM : Select WorkType as Salaried$")
    public static void SelectWorkTypeasSalaried() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToCustomerDetailsTab();


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), "S - Salaried", "BYVISIBLETEXT");
            wrap.wait(2000);

        } catch (Exception e) {

        }
    }

    @Then("^FDM : Select WorkType as Self Employed$")
    public static void SelectWorkTypeasSelfEmployed() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToCustomerDetailsTab();


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), "E - Self Employed", "BYVISIBLETEXT");
            wrap.wait(2000);

        } catch (Exception e) {

        }
    }


    @Then("^FDM : Select RepaymentMode as EDA$")
    public static void SelectRepaymentModeasEDA() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"), "EDA on other bank A/C", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }

    @Then("^FDM : Select RepaymentMode as PDC$")
    public static void SelectRepaymentModeasPDC() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RepaymentMode"), "PDC-Post Dated Cheque", "BYVISIBLETEXT");
            wrap.wait(2000);

            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionPDCDetailsBB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);

            wrap.wait(2000);
        } catch (Exception e) {

        }
    }

    @Then("^FDM : Add Disbursement Details$")
    public static void addDisbursementDetails() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();

            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "AmountForDisbursement"));


            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDisbursementDetailsBB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);

            wrap.wait(2000);


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"), "Pay Order", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }


    @Then("^FDM : Change DrawdownMode as NEFT$")
    public static void addDrawDownModeAsNEFT() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();

            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "AmountForDisbursement"));


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"));
            wrap.wait(2000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DrawdownMode"), "NEFT", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }

    @Then("^FDM : Select AcquisitionOrUsage as UsageType and UsageType as Topup$")
    public static void AcquistionorUsage() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();
            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"));

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"));
            wrap.wait(1000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"), "Usage", "BYVISIBLETEXT");
            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"));
            wrap.wait(1000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"), "Top-Up", "BYVISIBLETEXT");
            wrap.wait(2000);


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"));
            wrap.wait(1000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"), "Surrogate", "BYVISIBLETEXT");
            wrap.wait(2000);

        } catch (Exception e) {

        }
    }


    @Then("^FDM : Select UsageType as OD$")
    public static void UsageTypeasOD() throws IOException, InterruptedException {

        try {

            FullDataMakerUtils.switchToProductDetailsTab();
            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"));

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"));
            wrap.wait(1000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"), "OD", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }


    @Then("^FDM : Select AcquisitionOrUsage as UsageType and UsageType as Limit Increase$")
    public static void AcquistionorUsageLimit() throws IOException, InterruptedException {


        try {

            FullDataMakerUtils.switchToProductDetailsTab();
            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"));


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"));
            wrap.wait(1000);

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"), "Usage", "BYVISIBLETEXT");
            wrap.wait(2000);


            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"));
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_UsageType"), "Limit Increase", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (Exception e) {

        }
    }


    @Then("^FDM : Add Nominee$")
    public static void addNominee() throws IOException, InterruptedException {

        try {
           
        	//FullDataMakerUtils.switchToProductDetailsTab();


            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_NKISec_NominationFacility_Yes"));
            
			wrap.radioButtonSelection(BaseProject.driver, "Nomination Facility", "Fulldatacapturemaker", "FDC_PD_NKISec_NominationFacility_Yes", "FDC_PD_NKISec_NominationFacility_No");
            
        } catch (Exception e) {

        }
    }

    @Then("^FDM : Select Address Type as RES$")
    public static void selectAddrTypeAsRES() throws InterruptedException, IOException {

        try {
            wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PrefferedContact_CheckBox"));

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PrefferedContact_CheckBox"));


            wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), "Description", "A1 Residence Address");

            wrap.wait(2000);
        } catch (Exception e) {

        }

    }


    public static void switchFrame() throws InterruptedException {
        int Last = 0;

        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(300);
        List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
        for (WebElement frame : frames) {
            logger.info(frame.getAttribute("Name"));

        }       
        Last = frames.size() - 1;
        logger.info("User should switch to this frame name PegaGadget" + Last + "Ifr");
        BaseProject.driver.switchTo().frame(Last);
        logger.info("User switched to this frame name PegaGadget" + Last + "Ifr");
        wrap.wait(300);
    }

    @Then("^FDM : Switch to 1st Coapplicant in Customer Tab$")
    public static void switchToCoapplicantCust() throws InterruptedException, IOException {
        switchFrame();
        wrap.click(BaseProject.driver, "//span[text()='Co-Applicant']");
        wrap.wait(3000);

    }


    @Then("^FDM : Switch to 1st Coapplicant in Document Tab$")
    public static void switchToCoapplicantDoc() throws InterruptedException, IOException {
        switchFrame();
        wrap.click(BaseProject.driver, "(//span[text()='Co-Applicant'])[2]");
        wrap.wait(3000);

    }

    /******************************Vijay's steps end*********************************/


    /*****************************
     * Neethu's steps start here
     **************************/

    @Then("^FDM : validation UAT$")
    public void UAT() throws InterruptedException, IOException {
        validationUATindocument();
        validationUATinproduct();
        validationUATincustomerdetails();
    }

    @Then("^FDM : validation UAT in customer joint section$")
    public void UAT1() throws InterruptedException, IOException {

        valaidationUATincustomerjoint();
    }

    public void validationUATindocument() throws InterruptedException, IOException {

        FullDataMakerUtils.switchToDocumentsTab();

        //check whether the "Document Number" field is accepting Special Characters only if "Name of the Document" field is updated as "Driving Licence" or "Voter ID"

        while (fDC_Co_Applicant1 < FullDataMakerUtils.noOfApplicantsindocument()) {

            FullDataMakerUtils.switchToNextdocumentCoapplicant();


            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                    "DRIVING LIC NO", "BYVISIBLETEXT");

            wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                    com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));


            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));

            wrap.wait(3000);
            List<WebElement> ele = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber_error"));
            if (ele.size() == 0) {
                logger.info("PASS: Special characters allowed in Document no -Driving licence");
                Assert.assertEquals("Special characters allowed in Document no -Driving licence", true, true);
            } else {

                logger.info(ele.get(0).getText());
                logger.info("FAIL: Special characters  not allowed in Document no -Driving licence");
                //Assert.assertEquals("Special characters not allowed in Document no -Driving licence", false, true);

            }

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                    "IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT", "BYVISIBLETEXT");

            wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID),
                    com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));


            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));

            wrap.wait(3000);

            List<WebElement> ele1 = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber_error"));
            if (ele1.size() == 0) {

                logger.info("PASS: Special characters allowed in Document no -Voters id");
                Assert.assertEquals("Special characters allowed in Document no -Voters id", true, true);

            } else {

                logger.info(ele1.get(0).getText());

                logger.info("FAIL: Special characters not allowed in Document no -Voters id");
                //Assert.assertEquals("Special characters not allowed in Document no -Driving licence", false, true);

            }

            //check whether the "Document Expiry Date" field is not accepting "Past Date"

            wrap.wait(3000);
            wrap.typeToTextBox(BaseProject.driver, "12/07/2016",
                    com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentExpiryDate"));
            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_DocumentDetail_DocumentSignatorydate"));

            wrap.wait(3000);


            List<WebElement> ele3 = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentExpiryDate_error"));
            if (ele3.size() != 0) {
                logger.info(ele3.get(0).getText());
                logger.info("PASS: Document Expiry Date field is not accepting Past Date ");

            } else {

                logger.info("FAIL: Document Expiry Date field is  accepting Past Date ");

            }

            FullDataMaker.fDC_Co_Applicant1++;
        }
    }


    public void validationUATinproduct() throws InterruptedException, IOException {
        //check whether the field "Pay order hand over date" is enabled only when the mode of disbursement is selected as Payorder by the user.
        FullDataMakerUtils.switchToProductDetailsTab();

        wrap.wait(4000);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Acq_UsageIndicator"),
                "Usage", "BYVISIBLETEXT");

        wrap.wait(2000);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UsageType"),
                "Top-Up", "BYVISIBLETEXT");

        wrap.wait(2000);

        if (enable(com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Top-UpA/CNumber"))) {

            logger.info("PASS: Top-UpA/CNumber is enabled in PL Top-UP dropdown also");
        } else {
            logger.info("FAIL: Top-UpA/CNumber is not enabled in PL Top-UP dropdown also");
        }

        if (enable(com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupType"))) {

            logger.info("PASS: TopupType is enabled in PL Top-UP dropdown also");
        } else {
            logger.info("FAIL: TopupType is not enabled in PL Top-UP dropdown also");
        }


        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TopupType"),
                DBUtils.readColumnWithRowID("FDC_ProductDetails_TopupType", BaseProject.scenarioID), "BYVISIBLETEXT");


        WebElement finan_ele = wrap.getElement(BaseProject.driver, "//div[ contains(@sectionbodyid,'SubSectionDisbursementDetail')]//a[@title='Add a tab ']");

        wrap.click(BaseProject.driver, "//input[@id='DrawDownSeqNo']");
        wrap.wait(2000);

        wrap.click(BaseProject.driver, "//input[@id='LoanNotes']");
        wrap.wait(2000);

        Actions builder = new Actions(BaseProject.driver);

        builder.moveToElement(finan_ele).build().perform();

        wrap.wait(4000);

        builder.click(finan_ele).build().perform();

        wrap.wait(3000);

        boolean flag1 = false;
        for (int m = 0; m < 4; m++) {
            if (m == 0)
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "disbursementmode"), "NEFT", "BYVISIBLETEXT");
            if (m == 1)
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "disbursementmode"), "RTGS", "BYVISIBLETEXT");
            if (m == 2)
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "disbursementmode"), "Account Credit", "BYVISIBLETEXT");
            if (m == 3)
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "disbursementmode"), "Pay Order", "BYVISIBLETEXT");
            if (m == 1 || m == 0 || m == 2) {
                if (enable(com.getElementProperties("Fulldatacapturemaker", "PayOrderHandOverDt"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PayOrderHandOverDt is enabled in other dropdown also");
                }

                if (enable(com.getElementProperties("Fulldatacapturemaker", "PayOrderAmount"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PayOrderAmount is enabled in other dropdown also");
                }

                if (enable(com.getElementProperties("Fulldatacapturemaker", "PrintLocation"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PrintLocation is enabled in other dropdown also");
                }

                if (enable(com.getElementProperties("Fulldatacapturemaker", "PickUpBy"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PickUpBy is enabled in other dropdown also");
                }
                if (enable(com.getElementProperties("Fulldatacapturemaker", "PickUpMethod"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PickUpMethod is enabled in other dropdown also");
                }
                if (enable(com.getElementProperties("Fulldatacapturemaker", "PayOrderRefNumber"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL PayOrderRefNumber is enabled in other dropdown also");
                }
                if (enable(com.getElementProperties("Fulldatacapturemaker", "PayOrderHandOverDt"))) {
                    flag1 = true;
                    if (m == 0) logger.info("NEFT");
                    if (m == 1) logger.info("RTGS");
                    if (m == 2) logger.info("Acccount Credit");
                    logger.info("FAIL ClearingZoneCode is enabled in other dropdown also");
                }
            }
            if (m == 3) {
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PayOrderHandOverDt"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PayOrderAmount"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PrintLocation"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PickUpBy"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PickUpMethod"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "PayOrderRefNumber"));
                enable_webelement(com.getElementProperties("Fulldatacapturemaker", "ClearingZoneCode"));
            }

        }


    }

    public void valaidationUATincustomerjoint() throws InterruptedException, IOException {


        wrap.wait(5000);
        wrap.switch_to_default_Content(BaseProject.driver);
        wrap.wait(1000);

        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
        wrap.wait(2000);

        logger.info(FullDataMakerUtils.noOfApplicants());

        int count = 0, k;
        while (fDC_Co_Applicant < FullDataMakerUtils.noOfApplicants()) {
            logger.info("filling next applicant");
            FullDataMakerUtils.switchToNextCoapplicant();

            //check whether the field "Type(s) of initial funding" is enabled only for primary applicant

            if (wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund_joint")).isDisplayed()) {

                count++;
                k = fDC_Co_Applicant;

            }


            FullDataMaker.fDC_Co_Applicant++;

        }

        if (count == 1 && fDC_Co_Applicant == 0) {
            logger.info("PASS :Type(s) of initial funding is enabled only for primary applicant");
        } else if (count == 2)
            logger.info("FAIL :Type(s) of initial funding is  enabled  for primary applicant and coaplicant");


    }

    public void validationUATincustomerdetails() throws IOException, InterruptedException {


        FullDataMakerUtils.switchToCustomerDetailsTab();

        wrap.wait(3000);

        if (wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_numbered_account/passbook?Yes")).isDisplayed())
            logger.info("PASS :Client wishes anonymity (numbered account/passbook) ? is displayed only for NTB and ETB");

        else
            logger.info("PASS :Client wishes anonymity (numbered account/passbook) ? is  not displayed for NTB and ETB");


        if (wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_Other_risk_factors")).isDisplayed())
            logger.info("PASS :Other risk factors/ Local Regulations/ Stringent rules applied in country ? is displayed only for NTB and ETB");

        else
            logger.info("PASS :Other risk factors/ Local Regulations/ Stringent rules applied in country ? is  not displayed for NTB and ETB");


        //check whether the field "Type(s) of initial funding" in the drop down is reflecting as Demand Draft / Cashier's Order (or) Bank Transfer (or) Cash

        Select selectBox = new Select(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_typeOfInitalFund")));

        List<WebElement> optionslist = selectBox.getOptions();
        boolean option_initialfund = false;
        for (WebElement opt : optionslist) {
            String optiontext = opt.getText();
            logger.info(optiontext);
            if (optiontext.contains("Bank Transfer")) {
                logger.info(optiontext + " is present in dropdownlist");
                continue;
            } else if (optiontext.contains("Cash")) {
                logger.info(optiontext + " is present in dropdownlist");
                continue;
            } else if (optiontext.contains("Demand Draft / Cashiers Order")) {
                logger.info(optiontext + " is present in dropdownlist");
                continue;
            } else if (optiontext.contains("Cheque")) {

                continue;
            } else {

                option_initialfund = true;

            }

        }
        if (option_initialfund == false)
            logger.info("PASS: Type(s) of initial funding in the drop down is reflecting as Demand Draft / Cashiers Order (or) Bank Transfer (or) Cash");

        else
            logger.info("FAIL: Type(s) of initial funding in the drop down is not  reflecting as Demand Draft / Cashiers Order (or) Bank Transfer (or) Cash");

        //Currency Initial funding is expected to be in" is defaulted with INR

        if (wrap.getElement(BaseProject.driver, "//span[text()='Currency of Initial Funding']//parent::span/following-sibling::div//span").getText().contains("INR"))
            logger.info("PASS : Currency Initial funding  is defaulted with INR");

        else
            logger.info("FAIL : Currency Initial funding  is not  defaulted with INR");

        Actions act = new Actions(BaseProject.driver);
        wrap.click(BaseProject.driver, "//span[text()='Marketing Preferences']");
        for (int k = 0; k < 5; k++)

            act.sendKeys(Keys.DOWN).build().perform();


        wrap.wait(2000);
        act.moveToElement(BaseProject.driver.findElement(By.xpath("//a[contains(@name,'MoreFinancialDetails') and @title='Add a tab ']"))).click().build().perform();

        wrap.wait(5000);


        Select selectBox2 = new Select(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "Status")));

        List<WebElement> optionslist2 = selectBox2.getOptions();
        int y = 0, j = 0;
        for (WebElement opt : optionslist2)

        {

            selectBox2.selectByVisibleText(opt.getText());
            wrap.wait(3000);
            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "AccountType"), "RCC", "BYVISIBLETEXT");
            wrap.wait(2000);
            if (opt.getText().contains("Existing")) {
                if (enable(com.getElementProperties("Fulldatacapturemaker", "OutstandingAmount"))) {
                    y++;
                    j = 1;
                    logger.info(" Outstanding amount is displayed for existing option");
                }

            } else

            {
                if (enable(com.getElementProperties("Fulldatacapturemaker", "OutstandingAmount"))) {
                    y++;
                    logger.info(" Outstanding amount is displayed for " + opt.getText() + "  option");
                }

            }
        }
        if (y == 1 && j == 1)
            logger.info("PASS :Outstanding amount is displayed for Existing");
        else if (y > 1 && j == 1)
            logger.info("FAIL :Outstanding amount is displayed for Existing and other options also");
        else if (y == 0 && j == 0)
            logger.info("FAIL :Outstanding amount is  not displayed for Existing and other options also");

    }

    public void validationUATindocumentpan() throws InterruptedException, IOException {

        FullDataMakerUtils.switchToDocumentsTab();

        //check whether the "Document Number" field is accepting Special Characters only if "Name of the Document" field is updated as "Driving Licence" or "Voter ID"

        int p = 0;
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                "PAN NO", "BYVISIBLETEXT");
        //String input_pan="233";
        Pattern pattern = Pattern.compile("[a-zA-Z]{3}[pP][a-zA-Z][0-9]{4}[a-zA-Z]{1}");
        String[] input_pan = {"1234", "abcfd", "AOMPN4892B", "aomhh7896b", "AOMPN489B"};
        int size = input_pan.length, y = 0, k = 0;
        logger.info(size);

        for (int i = 0; i < size; i++) {
            boolean flag = false;
            Matcher matcher = pattern.matcher(input_pan[i]);
            // Check if pattern matches
            if (matcher.matches()) {
                flag = true;
                //logger.info(input_pan[i]);
                logger.info(input_pan[i] + " : to be enetered is  valid, so document no should not throw error");
            } else {

                logger.info(input_pan[i] + " : to be enetered is not valid, so document should throw error");
            }

            wrap.typeToTextBox(BaseProject.driver, input_pan[i],
                    com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));

            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys(Keys.TAB);

            wrap.wait(4000);
            List<WebElement> ele = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber_error"));
            if (ele.size() == 0 && flag == true) {
                y++;

                logger.info(input_pan[i] + " : Document no entered is valid as per the specification");

            } else if (ele.size() == 1 && flag == false) {
                logger.info(input_pan[i] + " : " + ele.get(0).getText() + ": ERROR IS VALID");
                y++;

            } else if (flag == false & ele.size() == 0) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed, error is expected ");

            } else if (flag == true & ele.size() == 1) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed , error is not expected");

                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys("   ");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys(Keys.TAB);

                wrap.wait(2000);
            }


        }

        if (y == size) {
            p = 1;
            logger.info(" PASS :Pan Card Number Validation of Total 10 Characters are allowed, out of which first five are Alpha on which fourth character should be 'P', next four are numeric and last character is Alpha is required");


        } else
            logger.info(" FAIL :Pan Card Number Validation Failed");


        for (int i = 0; i < size; i++) {
            boolean flag = false;
            Matcher matcher = pattern.matcher(input_pan[i]);
            // Check if pattern matches
            if (matcher.matches()) {
                flag = true;
                //logger.info(input_pan[i]);
                logger.info(input_pan[i] + " : to be enetered is  valid, so document no should not throw error");
            } else {

                logger.info(input_pan[i] + " : to be enetered is not valid, so document should throw error");
            }

            wrap.typeToTextBox(BaseProject.driver, input_pan[i],
                    com.getElementProperties("Fulldatacapturemaker", "crsdocumentno"));

            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "crsdocumentno")).sendKeys(Keys.TAB);

            wrap.wait(4000);
            List<WebElement> ele = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "crsdocumentnoerror"));
            if (ele.size() == 0 && flag == true) {
                y++;

                logger.info(input_pan[i] + " : Document no entered is valid as per the specification");

            } else if (ele.size() == 1 && flag == false) {
                logger.info(input_pan[i] + " : " + ele.get(0).getText() + ": ERROR IS VALID");
                y++;

            } else if (flag == false & ele.size() == 0) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed, error is expected ");

            } else if (flag == true & ele.size() == 1) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed , error is not expected");

                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "crsdocumentno")).sendKeys("   ");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "crsdocumentno")).sendKeys(Keys.TAB);

                wrap.wait(2000);
            }


        }

        if (y == size) {
            k = 1;
            logger.info(" PASS :Pan Card -CRS Number Validation of Total 10 Characters are allowed, out of which first five are Alpha on which fourth character should be 'P', next four are numeric and last character is Alpha is required");


        } else
            logger.info(" FAIL :Pan Card Number -CRS Validation Failed");

        if (p == 1 && k == 1)
            logger.info("SUCCESS: Pan card validated successfully in CRS and ID Document");
        else if (p == 1)
            logger.info("FAIL: Pan card validation failed in CRS ");
        else if (k == 1)
            logger.info("FAIL: Pan card validation failed in IDDocument ");
    }


    public void validationUATindocumentaadhar() throws InterruptedException, IOException {

        FullDataMakerUtils.switchToDocumentsTab();

        //check whether the "Document Number" field is accepting Special Characters only if "Name of the Document" field is updated as "Driving Licence" or "Voter ID"

        int p = 0;
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_NameoftheDocument1"),
                "AADHAR", "BYVISIBLETEXT");
        //String input_pan="233";
        Pattern pattern = Pattern.compile("[[0-9]{12}]");
        String[] input_pan = {"1234", "abcfd", "123456789012", "aomhh7896b", "AOMPN489B"};
        int size = input_pan.length, y = 0, k = 0;
        logger.info(size);

        for (int i = 0; i < size; i++) {
            boolean flag = false;
            Matcher matcher = pattern.matcher(input_pan[i]);
            // Check if pattern matches
            if (matcher.matches()) {
                flag = true;
                //logger.info(input_pan[i]);
                logger.info(input_pan[i] + " : to be enetered is  valid, so document no should not throw error");
            } else {

                logger.info(input_pan[i] + " : to be enetered is not valid, so document should throw error");
            }

            wrap.typeToTextBox(BaseProject.driver, input_pan[i],
                    com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber"));

            wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys(Keys.TAB);

            wrap.wait(4000);
            List<WebElement> ele = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber_error"));
            if (ele.size() == 0 && flag == true) {
                y++;

                logger.info(input_pan[i] + " : Document no entered is valid as per the specification");

            } else if (ele.size() == 1 && flag == false) {
                logger.info(input_pan[i] + " : " + ele.get(0).getText() + ": ERROR IS VALID");
                y++;

            } else if (flag == false & ele.size() == 0) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed, error is expected ");

            } else if (flag == true & ele.size() == 1) {
                y = 0;
                logger.info(input_pan[i] + ": validation failed , error is not expected");

                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys("   ");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_DocumentNumber")).sendKeys(Keys.TAB);

                wrap.wait(2000);
            }


        }

        if (y == size) {
            p = 1;
            logger.info(" PASS :Aadhar  Number field  accepted only Numeric Values and length of the field should be 12 ");


        } else
            logger.info(" FAIL :Aadhar  Number field validation  failed - only Numeric Values and length of the field should be 12 ");


    }


    public void enable_webelement(String ele) throws InterruptedException {

        wrap.wait(3000);
        if (wrap.getElement(BaseProject.driver, ele).isEnabled())
            logger.info("PASS: " + ele + " is enabled only when the mode of disbursement is selected as Payorder by the user");

        else
            logger.info("FAIL: " + ele + " is not enabled  when the mode of disbursement is selected as Payorder by the user");

    }

    public boolean enable(String ele) throws InterruptedException {

        wrap.wait(3000);
        if (wrap.getElement(BaseProject.driver, ele).isDisplayed() && wrap.getElement(BaseProject.driver, ele).isEnabled())
            return true;

        else
            return false;

    }

    /**********************************Neethu's steps end*****************************************/

    /**********************************
     * Priya's steps start
     *************************************************/

    public static void fullNameValidation(String fName, String mName, String lName, String fullName, String type) throws IOException, InterruptedException {
        String first_Name = wrap.getTextValue(BaseProject.driver, fName);
        logger.info(type + " FirstName " + first_Name);
        String middle_Name = wrap.getTextValue(BaseProject.driver, mName);
        logger.info(type + " MiddleName " + middle_Name);
        String last_Name = wrap.getTextValue(BaseProject.driver, lName);
        logger.info(type + " LastName " + last_Name);
        String full_Name = wrap.getTextValue(BaseProject.driver, fullName);
        logger.info(type + " FullName " + full_Name);

        if (!first_Name.isEmpty() && !middle_Name.isEmpty() && !last_Name.isEmpty()) {
            logger.info("!First_Name.isEmpty()&&!Middle_Name.isEmpty()&&!Last_Name.isEmpty() ");
            String Name = first_Name + " " + middle_Name + " " + last_Name;
            logger.info("Concat Name " + Name);
            if (full_Name.equals(Name))
                logger.info("Pass");
        } else if (!first_Name.isEmpty() && !middle_Name.isEmpty()) {
            logger.info("!First_Name.isEmpty()&&!Middle_Name.isEmpty()");
            String Name = first_Name + " " + middle_Name;
            logger.info("Concat Name " + Name);
            if (full_Name.equals(Name))
                logger.info("Pass");
        } else if (!first_Name.isEmpty() && !last_Name.isEmpty()) {
            logger.info("!First_Name.isEmpty()&&!Last_Name.isEmpty()");
            String Name = first_Name + " " + last_Name;
            logger.info("Concat Name " + Name);
            if (full_Name.equals(Name))
                logger.info("Pass");
        } else if (middle_Name.isEmpty() && last_Name.isEmpty()) {
            logger.info("Middle_Name.isEmpty()&&Last_Name.isEmpty()");
            String Name = first_Name;
            logger.info("Concat Name " + Name);
            if (full_Name.equals(Name))
                logger.info("Pass");
        } else {
            logger.info("Fail");
            logger.info("Full name do not match with the concatenation of FirstName,MiddleName and LastName");
        }
    }


    //Test case:9782 Permanent address same as Residence address
    //Test case:9679-Check state derived based on Zip code
    //Test case:9697-City Should not accept number values
    public static void isPermanentAdressSameAsResident() throws IOException, InterruptedException {
        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"), "Description",
                DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID));
        wrap.wait(3000);


        if (DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID).equalsIgnoreCase("A1 Residence Address")) {

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType"),
                    DBUtils.readColumnWithRowID("Residence Type", BaseProject.scenarioID), "BYVISIBLETEXT");

        }

        wrap.click(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID));
        wrap.wait(4000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 2", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Address Line 3", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"));
        wrap.wait(1500);
        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City"), "code",
                DBUtils.readColumnWithRowID("City", BaseProject.scenarioID));
        wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City")).sendKeys(Keys.TAB);
        wrap.wait(2000);
        if (wrap.isElementPresent(BaseProject.driver, "FDC_AddressSection_City_Error")) {
            logger.info("Numeric Validation Error shown for numeric values entered");
            logger.info("Pass");
        } else {

            logger.error("Numberic Error message is not shown");
        }

        wrap.wait(1000);
        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Country_suggestionBox"), "code",
                DBUtils.readColumnWithRowID("Country", BaseProject.scenarioID));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Zip Code", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
        wrap.wait(5000);
        String state = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt")).getAttribute("value");
        if (!state.isEmpty()) {
            logger.info("The derived value of State is " + state);
            logger.info("Pass");
        } else {
            logger.info("Fail");
        }
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year"));
        wrap.wait(5000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month"));

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes"));
        wrap.wait(5000);
        try {
            System.out.println("Getting address links");

            addressType = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox")).getAttribute("value");
            resListOfValues.add(addressType);
            addressLine1 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt")).getAttribute("value");
            resListOfValues.add(addressLine1);

            addressLine2 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt")).getAttribute("value");
            resListOfValues.add(addressLine2);

            addressLine3 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt")).getAttribute("value");
            resListOfValues.add(addressLine3);
            wrap.wait(500);
            country = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Country_suggestionBox")).getAttribute("value");
            resListOfValues.add(country);

            cityName = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City")).getAttribute("value");
            resListOfValues.add(cityName);

            zipCode = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt")).getAttribute("value");
            resListOfValues.add(zipCode);

            state = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt")).getAttribute("value");
            resListOfValues.add(state);

            area = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area")).getAttribute("value");
            resListOfValues.add(area);

            logger.info("Resident Address fields:" + resListOfValues);

            String add = BaseProject.driver.findElement(By.xpath("//div[@pl_prop='.Addresses']/ul/li[2]//tr/td/nobr/span")).getText();
            logger.info("Address links" + add);

            if (add.equalsIgnoreCase("PER")) {

                System.out.println("Going to click on Permanent address tab");
                wrap.wait(2000);
                wrap.click(BaseProject.driver, "//div[@pl_prop='.Addresses']/ul/li[2]//tr/td/nobr/span");

                perListOfValues = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Address_values_per_address"));
            }
            for (int i = 1; i <= perListOfValues.size(); i++) {
                logger.info(resListOfValues.get(i) + " == " + perListOfValues.get(i).getText());
                if (resListOfValues.get(i).equalsIgnoreCase(perListOfValues.get(i).getText())) {
                    logger.info(resListOfValues.get(i) + " == " + perListOfValues.get(i).getText());
                    logger.info("Pass");
                } else
                    logger.info("Fail");
            }

        } catch (Exception e) {
            logger.info("Unable to read the field values" + e);
        }

    }

    public static void isPermanentAdressSameAsResident_joint() throws IOException, InterruptedException {


        wrap.typenewSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"), "code",
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Address Type", BaseProject.scenarioID), DBUtils.readColumnWithRowID("Address code", BaseProject.scenarioID));

        wrap.wait(3000);


        if (DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Address Type", BaseProject.scenarioID).equalsIgnoreCase("A1 Residence Address")) {

            wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_ResidenceType_Joint"),
                    DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Residence Type", BaseProject.scenarioID), "BYVISIBLETEXT");

        }

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Address Line 1", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine1_Joint"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Address Line 2", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine2_Joint"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Address Line 3", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine3_Joint"));

        wrap.wait(1500);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " City", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_City_Joint"));

        wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_City_Joint")).sendKeys(Keys.TAB);
        wrap.wait(1000);
        if (wrap.isElementPresent(BaseProject.driver, "FDC_AddressSection_City_Error")) {
            logger.info("Numeric Validation Error shown for numeric values entered");
            logger.info("Pass");
        } else {

            logger.error("Numberic Error message is not shown");
        }

        wrap.wait(1000);
        wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Country_Joint"), "code",
                DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Country", BaseProject.scenarioID));

        wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Zip Code", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_joint"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
        wrap.wait(5000);
        String state = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_State_Joint")).getAttribute("value");
        if (!state.isEmpty()) {
            logger.info("The derived value of State is " + state);
            logger.info("Pass");
        } else {
            logger.info("Fail");
        }
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint"));
        wrap.wait(3000);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " Area", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint"));

        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_IsMailingYes_Joint"));

        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressYY", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthYY_Joint"));
        wrap.wait(1500);
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(coapp + fDC_Co_Applicant + " LengthAtCurrentAddressMM", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FD_Address_LengthMM_Joint"));
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes_joint"));
        wrap.wait(1000);
        try {
            System.out.println("Getting address links");

            addressType = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint")).getAttribute("value");
            resListOfValues.add(addressType);
            addressLine1 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine1_Joint")).getAttribute("value");
            resListOfValues.add(addressLine1);

            addressLine2 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine2_Joint")).getAttribute("value");
            resListOfValues.add(addressLine2);

            addressLine3 = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressLine3_Joint")).getAttribute("value");
            resListOfValues.add(addressLine3);
            wrap.wait(500);
            country = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Country_Joint")).getAttribute("value");
            resListOfValues.add(country);

            cityName = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_City_Joint")).getAttribute("value");
            resListOfValues.add(cityName);

            zipCode = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_joint")).getAttribute("value");
            resListOfValues.add(zipCode);

            state = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_State_Joint")).getAttribute("value");
            resListOfValues.add(state);

            area = wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_Area_Joint")).getAttribute("value");
            resListOfValues.add(area);

            logger.info("Resident Address fields:" + resListOfValues);

            String add = BaseProject.driver.findElement(By.xpath("//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@pl_prop='.Addresses']/ul/li[2]//tr/td/nobr/span")).getText();
            logger.info("Address links" + add);

            if (add.equalsIgnoreCase("PER")) {

                System.out.println("Going to click on Permanent address tab");
                wrap.wait(2000);
                wrap.click(BaseProject.driver, "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@pl_prop='.Addresses']/ul/li[2]//tr/td/nobr/span");

                perListOfValues = wrap.getElements(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Address_values_per_address_joint"));

                logger.info("Permanent Address fields:" + perListOfValues);
            }
            for (int i = 1; i <= perListOfValues.size(); i++) {
                logger.info(resListOfValues.get(i) + " == " + perListOfValues.get(i).getText());
                if (resListOfValues.get(i).equalsIgnoreCase(perListOfValues.get(i).getText())) {
                    logger.info(resListOfValues.get(i) + " == " + perListOfValues.get(i).getText());
                    logger.info("Pass");
                } else
                    logger.info("Fail");
            }

        } catch (Exception e) {
            logger.info("Unable to read the field values" + e);
        }

    }

    //Test Case 9507 & 9515 To Check Gender field derived or not

    public static void genderCheck(String title_locator, String gender_locator) throws IOException, InterruptedException {
        try {
            logger.info("title_locator" + title_locator);
            String title = wrap.getElement(BaseProject.driver, com.getElementProperties(propertiesFilename, title_locator)).getText();
            logger.info("Title: " + title);
            String gender = wrap.SelectedValueDropDown(BaseProject.driver, com.getElementProperties(propertiesFilename, gender_locator));
            logger.info("Gender: " + gender);
            if (!gender.isEmpty())
                logger.info("Pass");
            else
                logger.info("Fail");
        } catch (Exception e) {
            logger.info("Unable to read value from Gender Field" + e);
        }
    }

    public static void contactSectionValidation(String contactList, String contactTypeBox, String contactTypeList, String contactDetails, String areaCode, String ext, String isdCode, String ResCountry, String contactype) throws IOException, InterruptedException {

        List<String> contact_TypeList = new ArrayList<String>();
        Iterator<WebElement> itr;
        Actions a = new Actions(BaseProject.driver);

        String contact_list = com.getElementProperties(propertiesFilename, contactList);
        String contactType_typebox = com.getElementProperties(propertiesFilename, contactTypeBox);
        String fDC_ContactType_List = com.getElementProperties(propertiesFilename, contactTypeList);
        String contact_Details = com.getElementProperties(propertiesFilename, contactDetails);
        String area_Code = com.getElementProperties(propertiesFilename, areaCode);
        String extension = com.getElementProperties(propertiesFilename, ext);
        String iSDCode = com.getElementProperties(propertiesFilename, isdCode);
        String residenceCountry = wrap.getElement(BaseProject.driver, com.getElementProperties(propertiesFilename, ResCountry)).getText();

        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[contains(text(),'Contact')]"));
        ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        List<WebElement> Document_Total_Link = wrap.getExactAttributes(BaseProject.driver, contact_list);
        int add_tab = Document_Total_Link.size();
        logger.info("Contact Details List size: " + add_tab);
        wrap.click(BaseProject.driver, contact_list + "[" + add_tab + "]/span//tr/td/span/a");
        wrap.wait(2000);
        logger.info("Contact details Length Validation:");
        switch (contactype) {
            case "Telephone":
                wrap.click(BaseProject.driver, contactType_typebox);
                wrap.type(BaseProject.driver, "Tele", contactType_typebox);
                wrap.wait(1000);
                WebElement scroll = wrap.getElement(BaseProject.driver, contactType_typebox);
                //Actions a = new Actions(BaseProject.driver);
                for (int j = 0; j < 50; j++) {
                    a.sendKeys(scroll, Keys.ARROW_DOWN).sendKeys(Keys.DOWN).build().perform();
                }
                wrap.wait(3000);
                itr = wrap.getElements(BaseProject.driver, fDC_ContactType_List).iterator();

                while (itr.hasNext()) {
                    WebElement types = (WebElement) itr.next();
                    String values = types.getText();
                    System.out.println("Suggest values " + values);
                    contact_TypeList.add(values);
                }
                logger.info("List values " + contact_TypeList);
                for (int j = 0; j <= contact_TypeList.size() - 1; j++) {

                    wrap.typeInSuggestionTextbox(BaseProject.driver, contactType_typebox, "code", contact_TypeList.get(j));
                    wrap.wait(1000);
                    logger.info("Length matches: " + wrap.fieldLenghtVal(BaseProject.driver, contact_Details, "13", "test"));

                    if (wrap.isElementPresent(BaseProject.driver, area_Code)) {
                        logger.info("Area Code Field is enabled");
                        logger.info("Pass");
                    } else {
                        logger.info("Area Code Field is not enabled");
                        logger.info("Fail");

                    }
                    if (wrap.isElementPresent(BaseProject.driver, extension)) {
                        logger.info("Extension Field is enabled");
                        logger.info("Pass");
                    } else {
                        logger.info("Extension Field is not enabled");
                        logger.info("Fail");
                    }
                    if (wrap.isElementPresent(BaseProject.driver, iSDCode)) {
                        logger.info("ISD Code Field is enabled");
                        wrap.wait(1000);
                        String iSD_Code = wrap.SelectedValueDropDown(BaseProject.driver, iSDCode);
                        if ((!residenceCountry.isEmpty()) && (!iSD_Code.isEmpty())) {
                            logger.info("Residence County " + residenceCountry);
                            logger.info("ISD Code " + iSD_Code);
                            if (residenceCountry.equalsIgnoreCase("India") && iSD_Code.equals("91"))
                                logger.info("Pass");
                            else
                                logger.info("Fail");
                        }
                    } else {
                        logger.info("ISD Code Field is not enabled");
                        logger.info("Fail");
                    }

                }
                break;
            case "Email":
                wrap.click(BaseProject.driver, contactType_typebox);
                wrap.type(BaseProject.driver, "mail", contactType_typebox);
                wrap.wait(1000);
                WebElement scroll_mail = wrap.getElement(BaseProject.driver, contactType_typebox);
                for (int j = 0; j < 50; j++) {
                    a.sendKeys(scroll_mail, Keys.ARROW_DOWN).sendKeys(Keys.DOWN).build().perform();
                }
                wrap.wait(3000);
                itr = wrap.getElements(BaseProject.driver, fDC_ContactType_List).iterator();

                while (itr.hasNext()) {
                    WebElement types = (WebElement) itr.next();
                    String values = types.getText();
                    System.out.println("Suggest values " + values);
                    contact_TypeList.add(values);
                }
                System.out.println("List values " + contact_TypeList);
                for (int j = 0; j <= contact_TypeList.size() - 1; j++) {

                    wrap.typeInSuggestionTextbox(BaseProject.driver, contactType_typebox, "code", contact_TypeList.get(j));
                    logger.info("Data formate check" + wrap.fieldObjectTypeVal(BaseProject.driver, contact_Details, "Free Text"));
                    wrap.wait(1000);
                    logger.info("Length matches: " + wrap.fieldLenghtVal(BaseProject.driver, contact_Details, "150", "test"));
                }
                break;

            case "Mobile":
                wrap.click(BaseProject.driver, contactType_typebox);
                wrap.type(BaseProject.driver, "mobile", contactType_typebox);
                wrap.wait(1000);
                WebElement scroll_mobile = wrap.getElement(BaseProject.driver, contactType_typebox);
                //Actions a = new Actions(BaseProject.driver);
                for (int j = 0; j < 50; j++) {
                    a.sendKeys(scroll_mobile, Keys.ARROW_DOWN).sendKeys(Keys.DOWN).build().perform();
                }
                wrap.wait(2000);
                itr = wrap.getElements(BaseProject.driver, fDC_ContactType_List).iterator();

                while (itr.hasNext()) {
                    WebElement types = (WebElement) itr.next();
                    String values = types.getText();
                    System.out.println("Suggest values " + values);
                    contact_TypeList.add(values);
                }
                System.out.println("List values " + contact_TypeList);
                for (int j = 0; j <= contact_TypeList.size() - 1; j++) {

                    wrap.typeInSuggestionTextbox(BaseProject.driver, contactType_typebox, "code", contact_TypeList.get(j));
                    wrap.wait(1000);
                    logger.info("Length matches: " + wrap.fieldLenghtVal(BaseProject.driver, contact_Details, "15", "test"));
                    if (wrap.isElementPresent(BaseProject.driver, iSDCode)) {
                        logger.info("ISD Code Field is enabled");
                        wrap.wait(1000);
                        String iSD_Code = wrap.SelectedValueDropDown(BaseProject.driver, iSDCode);
                        if ((!residenceCountry.isEmpty()) && (!iSD_Code.isEmpty())) {
                            logger.info("Residence County " + residenceCountry);
                            logger.info("ISD Code " + iSD_Code);
                            if (residenceCountry.equalsIgnoreCase("India") && iSD_Code.equals("91"))
                                logger.info("Pass");
                            else
                                logger.info("Fail");
                        }
                    } else {
                        logger.info("ISD Code Field is not enabled");
                    }

                }
                break;
            default:
                logger.info("Enter a contact type as Telephone/Mobile/Email");
        }

    }

    @Then("^FDM:UATFieldCheck$")
    public static void UATfieldsCheck() throws IOException, InterruptedException {
        //Test Case 9507
        genderCheck("FullDataCapture_CustomerDetail_Title", "FullDataCapture_CustomerDetail_Gender_DropDown");
        //Test Case 9530
        wrap.validateNumericInputBox(BaseProject.driver, "FullDataCapture_CustomerDetail_Placeofbirth_TextBox", "Place of Birth");

        //Test case 11402 To Check Full Name
        fullNameValidation(com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_FirstName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_MiddleName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_LastName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_FullName"),
                "Customer");

        //Test Case 11505 To check Alias(es)
        wrap.wait(1000);
        String aliasType = wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_AliasType"));
        logger.info("Alias type" + aliasType);

        fullNameValidation(com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_FirstName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_MiddleName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_LastName"),
                com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_FullName"),
                "Alias");

        //Test Case 9581,11644,11661 ,11623,11624,11625

        contactSectionValidation("FDC_Contact_list", "FDC_ContactType_TypeBox", "FDC_ContactType_List", "FDC_ContactDetails", "FDC_contact_area_code", "FDC_contact_Extension",
                "FDC_ISDCODE", "FullDataCapture_CustomerDetail_ResidenceCountry", "Email");
        //Test Case 9782,9679,9697
        isPermanentAdressSameAsResident();

        /******************CO-Applicant********************/
        FullDataMakerUtils.switchToNextCoapplicant();
        //Test Case 9515
        genderCheck("FD_CD_Title_joint", "FD_CD_Gender_Joint");

        //Test case 11402 To Check Full Name
        fullNameValidation(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Firstname_joint"),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Middlename_joint"),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Lastname_joint"),
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Fullname_joint"),
                "Customer");

        //Test Case 11505 To check Alias(es)
        String aliasType_coapp = wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_AliasType_joint"));
        logger.info("Alias type" + aliasType_coapp);
        if (aliasType_coapp.equals("AKA"))
            fullNameValidation(com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_FirstName_joint"),
                    com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_MiddleName_joint"),
                    com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_LastName_joint"),
                    com.getElementProperties("Fulldatacapturemaker", "FDC_Alias_FullName_joint"),
                    "Alias");

        //Test Case 9538
        wrap.validateNumericInputBox(BaseProject.driver, "FD_CustomerDetail_Placeofbirth_TextBox_joint", "Place of Birth");

        //Test Case 9589,11651,11669,11634,11635,11636
        contactSectionValidation("FDC_Contact_list_joint", "FDC_ContactType_TypeBox_joint", "FDC_ContactType_List_joint", "FDC_ContactDetails_joint", "FDC_contact_area_code_joint", "FDC_contact_Extension_joint",
                "FDC_ISDCODE_joint", "FullDataCapture_CustomerDetail_ResidenceCountry_joint", "Telephone");

        //Test Case 9790,9706,9688
        isPermanentAdressSameAsResident_joint();

    }

    //Test Case 12455
    @Then("^FDM:Application moved to FDC Checker workbasket check$")
    public static void searchFDCCheck() throws IOException, InterruptedException {
        try {
            String searchLink = com.getElementProperties(propertiesFilename, "ApplicationSearch_Menu_Search_Link_XPATH");
            wrap.click(BaseProject.driver, searchLink);
            wrap.wait(1000);
            wrap.switch_to_default_Content(BaseProject.driver);
            wrap.wait(1000);
            wrap.switch_to_Iframe(BaseProject.driver, com.getElementProperties(propertiesFilename, "ApplicationSearch_PegaGadget0"));

            String applicationId = com.getElementProperties(propertiesFilename, "ApplicationSearch_SearchScreen_ApplicationRefNo_TextBox_ID");
            String moreInfoLink = com.getElementProperties(propertiesFilename, "ApplicationSearch_SearchScreen_MoreInfoLink_Link_XPATH");

            String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);
            logger.info("The Application ID  is [" + appId + "]");
            wrap.type(BaseProject.driver, appId, applicationId);
            wrap.click(BaseProject.driver, com.getElementProperties(propertiesFilename, "ApplicationSearch_SearchScreen_Search_Button_XPATH"));
            wrap.wait(2000);
            wrap.click(BaseProject.driver, moreInfoLink);
            wrap.wait(1000);
            boolean flag = false;
            WebElement table = BaseProject.driver.findElement(By.xpath("//table[@id='bodyTbl_right'][@pl_prop='D_SubCasesWorkFlowResults.pxResults']"));
            List<WebElement> rows = table.findElements(By.tagName("tr"));
            for (WebElement row : rows) {
                List<WebElement> cells = row.findElements(By.tagName("td"));
                for (WebElement cell : cells) {
                    logger.info(cell.getText());
                    if (cell.getText().contains("Full Data Capture Checker")) {
                        flag = true;
                        break;
                    }
                }
            }
            if (flag == true)
                logger.info("Application is moved to Full Data Capture Checker");
            else
                logger.info("Application is not  moved to Full Data Capture Checker");
        } catch (Exception e) {
            logger.info("Unable to click on Search" + e);
        }


    }

    //Added-Thiyanes-22/11

    @Then("^Fill Document Section of FDCM$")
    public static void documentsection() throws Throwable {

        switchFrame();
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//label[contains(text(),'Documents')]")).click();
        wrap.wait(1000);
        wrap.enterDate(BaseProject.driver, "20/09/2017", com.getElementProperties("Fulldatacapturemaker", "FDC_Document_CRS_DocSigdate"));
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("(//input[@id='CountryofTaxResidence'])")).sendKeys("INDIA");
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'IN')]")).click();


    }


    @Then("^FDM : Fill Joint data in fdm$")
    public static void fillJointApplicantsfdm() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

        /*******Swtiching to Customer Details Tab*********/
    	
    	DBUtils.convertDBtoMap("fdquery_joint");

        FullDataMakerUtils.switchToCustomerDetailsTab();

        logger.info("Number of Co-Applicants is/are : " + FullDataMakerUtils.noOfApplicants());

        while (fDC_Co_Applicant < FullDataMakerUtils.noOfApplicants()) {
            logger.info("filling next applicant");
            FullDataMakerUtils.switchToNextCoapplicant();
            {

                fillCustomerPersonalDetailSections_joint();
                fillcontactAddressSection_joint();
                fillCommunicationSections_joint();
                fillEmploymentSectionjoint();
                fillFATCAandGSTSectionsjoint();
                if(!product.equalsIgnoreCase("CC")||!product.equalsIgnoreCase("PL"))
                fillCDDInternalSectionsjoint();
                fillSignatureFinancialSections();
                fillbankingservicedetailssectionjoint();
				fillFamilydetailsjoint();	
                fillCDDOATMarketingSectionsjoint();

            }
            FullDataMaker.fDC_Co_Applicant++;
            logger.info("The co-applicant count has been incremented to : " + fDC_Co_Applicant);
            wrap.wait(2000);

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "final_Save"));

            wrap.wait(3000);

        }

    }

    @Then("^FDM : Fill Customer Personal Detail section in Customer Details Tab joint$")
    public static void fillCustomerPersonalDetailSections_joint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown_j"));

       // wrap.wait(2000);
    	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_All_Applicants_link"))));


        if (prdCat.equalsIgnoreCase("PERSONAL LOAN")) {
            product = "PL";
            logger.info("The product code is assigned as PL");
        } else if (prdCat.equalsIgnoreCase("CREDIT CARD")) {
            product = "CC";
            logger.info("The product code is assigned as CC");
        } else if (prdCat.equalsIgnoreCase("SAVINGS ACCOUNT")) {
            product = "SA";
            logger.info("The product code is assigned as SA");
        } else if (prdCat.equalsIgnoreCase("CURRENT ACCOUNT")) {
            product = "CA";
            logger.info("The product code is assigned as CA");
        } else {
            product = "TD";
            logger.info("The product code is assigned as TD");
        }
        int no = FullDataMaker.fDC_Co_Applicant + 1;


        /*******Filling Personal Details section in Customer Details Tab*********/
        logger.info("The given scenario id is : " + BaseProject.scenarioID);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown_j"),
                DBUtils.readColumnWithRowID("Gender" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
        
        
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown_j"),
                DBUtils.readColumnWithRowID("Marital_Status" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
     //   new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown_j"))));
        //wrap.wait(1000);
      //  Select ms = new Select(wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown_j")));
      //  mar_status = ms.getFirstSelectedOption().getText();

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Qualification_DropDown_j"),
                DBUtils.readColumnWithRowID("Educational_Qualification" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
        
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Place_of_Birth" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Placeofbirth_TextBox_j"));

        //wrap.captureScreenShot(BaseProject.driver, "Customer Personal Detail");

        switch (product) {

            case "CA":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_NatureofRelationshipwithPrimaryApplicant_joint"),
                        DBUtils.readColumnWithRowID("Nature_of_Relationship_with_Primary_Applicant" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CustomerDemiseDate" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Authentication_Mode" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_AuthMode_joint"));
                //Related Party
                
                wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("HouseHold_ID" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Link_Relationship_number" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber"));
                
                
                /*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"),
                        DBUtils.readColumnWithRowID("Residential Status" + no, BaseProject.scenarioID), "BYVISIBLETEXT");*/

                break;

            case "SA":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CustomerDemiseDate" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));

                //Related Party
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("HouseHold_ID" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_Householdid"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Link_Relationship_number" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FD_CD_RPS_LinkRelationshipNumber"));

                
                /*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"),
                        DBUtils.readColumnWithRowID("Residential Status" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
*/
                break;

            case "TD":

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant" + no, BaseProject.scenarioID), "BYVISIBLETEXT");


                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode_j"),
                        DBUtils.readColumnWithRowID("Constitution Code" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"));
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown_j"),
                        DBUtils.readColumnWithRowID("Residential Status" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                break;

            case "CC":
           
            	//wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"),
                        DBUtils.readColumnWithRowID("Constitution Code"+no, BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.wait(1000);
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(1000);
            	

               
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),
                        DBUtils.readColumnWithRowID("Residential Status"+no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No Of Dependants"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_NoOfDependants_textbox"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_joint"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant"+no, BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CustomerDemiseDate" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Authentication_Mode" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_AuthMode_joint"));
                
                wrap.wait(2000);
            	
            	
            	
            	break;

			case "PL":
           
            	//wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"),
                        DBUtils.readColumnWithRowID("Constitution Code"+no, BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.wait(1000);
                
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "PrimaryRelationType"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.wait(1000);
            	

               
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"),
                        DBUtils.readColumnWithRowID("Residential Status"+no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("No Of Dependants"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_NoOfDependants_textbox"));

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_joint"),
                        DBUtils.readColumnWithRowID("Nature of Relationship with Primary Applicant"+no, BaseProject.scenarioID), "BYVISIBLETEXT");
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CustomerDemiseDate" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Authentication_Mode" + no, BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_AuthMode_joint"));

                wrap.wait(2000);
            	
            	
            	
            	break;

        }

    }


    public static void fillcontactAddressSection_joint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {


        int no = FullDataMaker.fDC_Co_Applicant + 1;
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_Address_AddressType_Joint"));

        /**********************************Filling Contact section********************************************/
       // wrap.wait(2000);
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PrefferedContact_CheckBox_j"))));
        if (!wrap.getElement(BaseProject.driver,
                com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PrefferedContact_CheckBox_j")).isSelected()) {

            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PrefferedContact_CheckBox_j"));
        }


        /**********************************Filling Address section********************************************/

        FullDataMakerUtils.fillCommonAddressfields_joint();

        switch (product) {

            case "CA":


                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox_j"));
               // wrap.wait(2000);
               // wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_No_j"));
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "SA":
                //Changes - SA - Need to have State field and copy remaining available fields from case CC part
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox_j"));
              //  wrap.wait(2000);
               // wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_No_j"));
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "TD":
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_ChkBox_j"));
              //  wrap.wait(2000);
              //  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_No_j"));
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

            case "CC":

                /*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
               
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));*/
               
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year_Joint"));
                
                wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month_Joint"));
                
				//wrap.radioButtonSelection(BaseProject.driver,  "Address1_Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
                
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes_joint"))));
               
				wrap.radioButtonSelection(BaseProject.driver,"Address1_Permanent Address same as Residential Address", "Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes_joint", "FDC_CD_AddressSection_Residential_Address_No_j");
                                
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");
                break;

              
                
            case "PL":

            	/*wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
                
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));*/
               
            	 wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressYY"+no, BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_Year_Joint"));
                 
                 wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("LengthAtCurrentAddressMM"+no, BaseProject.scenarioID),
                         com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_LengthAtCurrentAddress_month_Joint"));
                
				wrap.radioButtonSelection(BaseProject.driver,  "Address1_Mailing Address Indicator", "Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_NChkBox");
                
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"))));
               
                wrap.radioButtonSelection(BaseProject.driver,"Address1_Permanent Address same as Residential Address", "Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes_joint", "FDC_CD_AddressSection_Residential_Address_No_j");
                                
                //wrap.captureScreenShot(BaseProject.driver, "Address Section");

                break;

        }
       // wrap.wait(2000);

    }


    public static void fillEmploymentSectionjoint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {


        int no = FullDataMaker.fDC_Co_Applicant + 1;
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
        
        switch (product) {

            case "CA":
                //FDC_CD_Employment_Occupation

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
               // wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID("Work_Type" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
              //  wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

              //  wrap.wait(1000);
               /* wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"));
              //  wrap.wait(1500);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID("Nature Of Business" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName_joint"),
                        "code", DBUtils.readColumnWithRowID("Employer Name" + no, BaseProject.scenarioID));*/

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");

                break;

            case "SA":

                //FullDataMakerUtils.selectWorkType();
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
              //  wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID("Work Type" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

              //  wrap.wait(1000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"));
               // wrap.wait(1500);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID("Nature Of Business" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName_joint"),
                        "code", DBUtils.readColumnWithRowID("Employer Name" + no, BaseProject.scenarioID));

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

            case "TD":
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"));
               // wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint"),
                        DBUtils.readColumnWithRowID("Work Type" + no, BaseProject.scenarioID), "BYVISIBLETEXT");
                wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentTypeJoint")).sendKeys(Keys.TAB);

               // wrap.wait(1000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"));
               // wrap.wait(1500);
                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness_joint"),
                        DBUtils.readColumnWithRowID("Nature Of Business" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_EmployerName_joint"),
                        "code", DBUtils.readColumnWithRowID("Employer Name" + no, BaseProject.scenarioID));

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");

                break;

            case "CC":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes_joint"));

                FullDataMakerUtils.selectWorkType();

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

            case "PL":

                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes_joint"));

                FullDataMakerUtils.selectWorkType();

                //wrap.captureScreenShot(BaseProject.driver, "Employment Section");
                break;

        }

       // wrap.wait(2000);

    }

    public static void fillCommunicationSections_joint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

        int no = FullDataMaker.fDC_Co_Applicant + 1;
        
        wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CS_AdviceDetailAddressType_suggessionBox_joint"));
        
        //com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CS_AdviceDetailAddressType_suggessionBox_joint"), DBUtils.readColumnWithRowID("Advice_Address" + no, BaseProject.scenarioID), "Mailing Address 63");

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_MarketingPreferences_dropdown_j"),
                DBUtils.readColumnWithRowID("Marketing_Preferences" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

        //wrap.captureScreenShot(BaseProject.driver, "Communication Section");
    }

    public static void fillFATCAandGSTSectionsjoint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

    	DBUtils.convertDBtoMap("fdquery_joint");
    	wrap.wait(2000);
    	
        int no = FullDataMaker.fDC_Co_Applicant + 1;
        switch (product) {

            case "CA":

                FullDataMakerUtils.fillFATCAjoint();
                FullDataMakerUtils.fillGSTjoint();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }
               /* wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));*/
                //wrap.captureScreenShot(BaseProject.driver, "FATCA & GST Section");

                break;

            case "SA":

                FullDataMakerUtils.fillFATCAjoint();
                FullDataMakerUtils.fillGSTjoint();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }
                /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));*/
                break;

            case "TD":

                FullDataMakerUtils.fillFATCAjoint();
                FullDataMakerUtils.fillGSTjoint();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }
                /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));*/
                break;

            case "CC":
                FullDataMakerUtils.fillGSTjoint();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                    wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint")).sendKeys(Keys.TAB);
                }
                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                //wrap.captureScreenShot(BaseProject.driver, "GST Section");

                break;

            case "PL":
                FullDataMakerUtils.fillGSTjoint();
                if (wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes_joint")).isSelected()) {
                    wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST_Registration_Number" + no, BaseProject.scenarioID),
                            com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                }
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST Registration Number" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("GST State" + no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State_joint"));

                //wrap.captureScreenShot(BaseProject.driver, "GST Section");
                break;

        }

    }


    public static void fillCDDInternalSectionsjoint() throws IOException, InterruptedException {
        
    	//CommonUtils.convertExcelToMap(BaseProject.excelPath, "FullDataCapture.xls", "FullDataCapture");

        /**********************Filling CDD section**********************************/
		int no = FullDataMaker.fDC_Co_Applicant + 1;
		
		wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode_j"));

        switch (product) {

            case "CA":

               /* wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund_joint"), "code",
                        DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_descriptionOfInitalFund_joint"));*/

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode_j"),
                        DBUtils.readColumnWithRowID("MIS_Code"+no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS_Value"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues_j"));

                break;

            case "SA":

               /* wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund_joint"), "code",
                        DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));

                wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Description of initial funding", BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_descriptionOfInitalFund_joint"));*/

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode_j"),
                        DBUtils.readColumnWithRowID("MIS_Code"+no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS_Value"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues_j"));

                break;

            case "TD":

                /**********************Filling Internal section*****************************/

                wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISCode_j"),
                        DBUtils.readColumnWithRowID("MIS_Code"+no, BaseProject.scenarioID), "BYVISIBLETEXT");

                wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("MIS_Value"+no, BaseProject.scenarioID),
                        com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Internal_MISValues_j"));

                break;

            case "CC":

                break;

            case "PL":

                break;

        }
        //wrap.captureScreenShot(BaseProject.driver, "CDD Section");
    }

    public static void fillbankingservicedetailssectionjoint() throws IOException, InterruptedException {

    	int no = FullDataMaker.fDC_Co_Applicant + 1;
    	
        switch (product) {

            case "CA":
            	
            	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio"));
            	
            	wrap.radioButtonSelection(BaseProject.driver, "Availability_of_Customer_Signature1", "Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio", "FDCM_CDSec_AvailabilityofCustomerSignatureNo_Radio");
				
				wrap.radioButtonSelection(BaseProject.driver, "Online_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_No");
                
				wrap.radioButtonSelection(BaseProject.driver, "Mobile_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_No");
				
               
                break;

            case "SA":
            	
				wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio"));
            	
            	wrap.radioButtonSelection(BaseProject.driver, "Availability_of_Customer_Signature1", "Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio", "FDCM_CDSec_AvailabilityofCustomerSignatureNo_Radio");
				
				wrap.radioButtonSelection(BaseProject.driver, "Online_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_No");
               
				wrap.radioButtonSelection(BaseProject.driver, "Mobile_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_No");
              
                break;

            case "TD":
				
				wrap.radioButtonSelection(BaseProject.driver, "Mobile_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_No");				
                break;

            case "CC":
				
				wrap.radioButtonSelection(BaseProject.driver, "Online_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_OnlineBanking_Radio_No");
                wrap.radioButtonSelection(BaseProject.driver, "Mobile_Banking1", "Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_Yes", "FullDataCapture1_CustomerDetail_MobileBanking_Radio_No");				
               break;

            case "PL":

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "Banking Service Details Section");
    }

    public static void fillCDDOATMarketingSectionsjoint() throws IOException, InterruptedException, ClassNotFoundException, SQLException {

		//switchFrame();
        int no = FullDataMaker.fDC_Co_Applicant + 1;
        /**********************Filling CDD OAT section*****************************/

      wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDDOAT_numbered_AccOrPassbook_Yes_joint"));
		wrap.radioButtonSelection(BaseProject.driver, "Client_wishes_anonymity1", "Fulldatacapturemaker", "FDC_CD_CDDOAT_numbered_AccOrPassbook_Yes_joint", "FDC_CD_CDDOAT_numbered_AccOrPassbook_No_joint");
		
        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_Other_risk_factors_joint"));
       
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_Other_risk_factors_joint"),
                DBUtils.readColumnWithRowID("Other_risk_factors" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

        /**********************Marketing Details*****************************/

      
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustTab_PreferredContact_Time_j"),
                DBUtils.readColumnWithRowID("Prefer_contact_timing" + no, BaseProject.scenarioID), "BYVISIBLETEXT");

        switch (product) {

            case "CA":

                break;

            case "SA":

                break;

            case "TD":

                break;

            case "CC":

                break;

            case "PL":

                break;

        }

        //wrap.captureScreenShot(BaseProject.driver, "CDD(OAT) & Marketing details Section");


        wrap.wait(3000);
    }

    
    //Thiyanes-05/01/2018
    
    @Then("^FDM : Add Nominee section details$")
    public void AddNominee() throws InterruptedException, IOException {
    	
    	//wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee1"));
    	
    	//new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee3"))));
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee3"));
    	
    	
    	wrap.wait(1000);
    	BaseProject.driver.findElement(By.xpath("//input[@id='NomineeFullName']")).click();
    	wrap.wait(1000);
    	BaseProject.driver.findElement(By.xpath("//input[@id='NomineeFullName']")).sendKeys(DBUtils.readColumnWithRowID("Nominee Full Name", BaseProject.scenarioID));
    	/*wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Full Name", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee3"));*/
    	wrap.wait(1000);
    	wrap.typeToTextBox(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Relnship", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee4"));
    	
    	wrap.wait(1000);
    	wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee DOB", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee5"));
        
    	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee6"),
                DBUtils.readColumnWithRowID("Print Nominee Name", BaseProject.scenarioID), "BYVISIBLETEXT");
    	
    	wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee8"));
    	
		wrap.radioButtonSelection(BaseProject.driver, "Get Residence Address from Primary Applicant", "Fulldatacapturemaker", "FDC_PRod_Nominee9", "FDC_PRod_Nominee8");
    	
    	
    	//com.suggestionTextBox2(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee10"), DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID), "A1 Residence Address");

    	 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Address Line 1", BaseProject.scenarioID),
    	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee11"));
    	                
    	                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Address Line 2", BaseProject.scenarioID),
    	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee12"));
    	                
    	                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Address Line 3", BaseProject.scenarioID),
    	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee13"));
    	                
    	                 wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee City", BaseProject.scenarioID),
    	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee14"));
    	                 
    	                 com.suggestionTextBox2(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee15"), "IN", "INDIA"); 
    	                
    	                  wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Zip Code", BaseProject.scenarioID),
    	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee16"));
    		
    	                  
						  wrap.radioButtonSelection(BaseProject.driver, "Nominee_Mailing Address Indicator", "Fulldatacapturemaker", "FDC_PRod_Nominee17", "FDC_PRod_Nominee18");
						 
						  wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee19"));
						  
    	                  com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee19"), "OT1", "Regst Office Telephone No.-1");
    	                  
    	                  /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Conno", BaseProject.scenarioID),
    	      	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee20"));*/
    	                  
    	                  wrap.wait(2000);
    	                  BaseProject.driver.findElement(By.xpath("//input[contains(@name,'NomineeInfo') and contains(@name,'ContactNumber')]")).click();
    	                  wrap.wait(2000);
    	                  BaseProject.driver.findElement(By.xpath("//input[contains(@name,'NomineeInfo') and contains(@name,'ContactNumber')]")).sendKeys("8900089000");
    
    	                  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee21"),
    	                          DBUtils.readColumnWithRowID("Nominee ISDcd", BaseProject.scenarioID), "BYVISIBLETEXT");
    	                  
    	                  wrap.wait(1000);
    	                  BaseProject.driver.findElement(By.xpath("//input[contains(@name,'NomineeInfo') and contains(@name,'ExtensionDetails')]")).sendKeys(new StringBuffer().append(DBUtils.readColumnWithRowID("Nominee Extn", BaseProject.scenarioID)));
    	                  
    	                  /*wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Nominee Extn", BaseProject.scenarioID),
      	      	                com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee22"));*/
    	                  
    	                  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PRod_Nominee23"));
    }
    
    @Then("^FDM : Enter Debit card details$")
    public void AddDebitcard() throws InterruptedException, IOException {
    	
    	  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit1"));
    	  
    	  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit2"),
                  DBUtils.readColumnWithRowID("Debit customer", BaseProject.scenarioID), "BYVISIBLETEXT");
    	  
    	  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit3"),
                  DBUtils.readColumnWithRowID("Debit primary", BaseProject.scenarioID), "BYVISIBLETEXT");
    	  
    	  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit4"),
                  DBUtils.readColumnWithRowID("Debit secondary", BaseProject.scenarioID), "BYVISIBLETEXT");
    	  
    	  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit5"),
                  DBUtils.readColumnWithRowID("Debit card type", BaseProject.scenarioID), "BYVISIBLETEXT");
    	  
    	  wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Debit6"),
                  DBUtils.readColumnWithRowID("Debit card subtype", BaseProject.scenarioID), "BYVISIBLETEXT");
    	  
    	  wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_App_Add"));
    	  
    	  
    }  
    
    @Then("^FDM : Add contact for Online Banking$")
    public void Addcontact() throws InterruptedException, IOException {
    	
    	
    	 String contactDetails = com.getElementProperties("Fulldatacapturemaker", "FDC_Contact_No");
         String contactType = com.getElementProperties("Fulldatacapturemaker", "FDC_Contact_Type");
         String preferredContact = com.getElementProperties("Fulldatacapturemaker", "FDC_PRConnno");
         String onliney=com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_OnlineBankingY_Radio");
        
         String contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
         String contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
         String contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
         String iSD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
         String extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);


         String contactsection = com.getElementProperties("BasicData", "Contactsection");   
         
         List <String> contacts=new ArrayList <String>();
         switchFrame();
         
         wrap.click(BaseProject.driver, onliney);
         
         wrap.wait(1000);
         
         if(wrap.getElement(BaseProject.driver, onliney).isSelected()){
        	 
        	 List <WebElement> contlist=BaseProject.driver.findElements(By.xpath("//h2[contains(text(),'Contact')]//ancestor::div[@id='EXPAND-PLUSMINUS']//following-sibling::div[@id='EXPAND-INNERDIV']//td//nobr//span"));
        	 
        	 for(WebElement conttxt:contlist)
        	 {
        		 contacts.add(conttxt.getText());
        		 System.out.println(contacts);
        	 }
        	 
        	 if(!contacts.contains("EMR")){
        	 
        	 wrap.wait(1000);
        	 WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']"));
             JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
             myExecutor.executeScript("arguments[0].click();", add);
         
             com.suggestionTextBox3(BaseProject.driver, contactType, "EMR", "Personal Email Address");
                           
             wrap.type(BaseProject.driver, "test@sc.com", contactDetails);
             
             wrap.click(BaseProject.driver, preferredContact);
         }
         }
}
    
    
    @When("^FullData: Add Product '(.*)'$")
    public void add_addtionalproduct(String j)
            throws Throwable {

        int i = Integer.parseInt(j);
        int k = i + 1;
        
        String tab = "xpath=(//li[@id='Tab" + k + "' and contains(@tabbedrepeatid,'Product')]//a)";
        wrap.click(BaseProject.driver, tab);
        
        
        String promotionCode = DBUtils.readColumnWithRowID("PromotionCode" + i + "", BaseProject.scenarioID);
        String accountShortNm = DBUtils.readColumnWithRowID("AccountShortNm" + i + "", BaseProject.scenarioID);
        String riskRemarks = DBUtils.readColumnWithRowID("RiskRemarks" + i + "", BaseProject.scenarioID);
        String mISCode = DBUtils.readColumnWithRowID("MISCode" + i + "", BaseProject.scenarioID);
        String mISValue = DBUtils.readColumnWithRowID("MISValue" + i + "", BaseProject.scenarioID);
        String statementTypeCASA = DBUtils.readColumnWithRowID("StatementTypeCASA" + i + "", BaseProject.scenarioID);
        String consolidatedFlag = DBUtils.readColumnWithRowID("ConsolidatedFlag" + i + "", BaseProject.scenarioID);
        String chequeBookRequired = DBUtils.readColumnWithRowID("ChequeBookRequired" + i + "", BaseProject.scenarioID);
                
        
        		
        		String promocode = "xpath=(//input[@id='PromotionCode' and contains(@data-focus,'Products(" + k + ")')])";
        		String accshrnm = "xpath=(//input[@id='AccountShortNm' and contains(@data-focus,'Products(" + k + ")')])";
        		String riskremark = "xpath=(//input[@id='RiskRemarks' and contains(@data-focus,'Products(" + k + ")')])";
        		String mIScd = "xpath=(//select[@id='MISCode1' and contains(@data-change,'Products(" + k + ")')])";
        		String misval = "xpath=(//input[@id='MISValue1'])[" + k + "]";
        		String cASAStmttyp = "xpath=(//select[@id='StatementTypeCASA' and contains(@data-focus,'Products(" + k + ")')])";

        		String consolflagy = "xpath=(//div[contains(@data-focus,'Products(" + k + ")')]//input[@id='ConsolidatedFlagY'])";
        		String consolflagN = "xpath=(//div[contains(@data-focus,'Products(" + k + ")')]//input[@id='ConsolidatedFlagN'])";

        		String chkbooky = "xpath=(//div[contains(@data-focus,'Products(" + k + ")')]//input[@id='ChequeBookRequiredY'])";
        		String chkbookn = "xpath=( //div[contains(@data-focus,'Products(" + k + ")')]//input[@id='ChequeBookRequiredN'])";

        		wrap.wait(1000);
        		String prdtext=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'Product Category')]/../following-sibling::div/span")).getText();
        		logger.info("Prd text is"+prdtext);
        		wrap.wait(1000);
        		if(prdtext.equalsIgnoreCase("SAVINGS ACCOUNT") || prdtext.equalsIgnoreCase("CURRENT ACCOUNT") ){
        		//switchFrame();
        		wrap.scroll_to(BaseProject.driver, promocode);
        		wrap.type(BaseProject.driver, promotionCode, promocode);
        		wrap.scroll_to(BaseProject.driver, accshrnm);
        		wrap.type(BaseProject.driver, accountShortNm, accshrnm);
        		wrap.scroll_to(BaseProject.driver, riskremark);
        		wrap.type(BaseProject.driver, riskRemarks, riskremark);
        		wrap.scroll_to(BaseProject.driver, mIScd);
        		wrap.selectFromDropDown(BaseProject.driver, mIScd, mISCode, "BYVISIBLETEXT");
        		wrap.type(BaseProject.driver, mISValue, misval);
        		
        		/*if(ChequeBookRequired.equalsIgnoreCase("YES")){wrap.click(BaseProject.driver, chkbooky);}
        		else {wrap.click(BaseProject.driver, chkbookn);}*/
        		
        		wrap.scroll_to(BaseProject.driver, cASAStmttyp);
        		wrap.selectFromDropDown(BaseProject.driver, cASAStmttyp, statementTypeCASA, "BYVISIBLETEXT");
        		
        		if(consolidatedFlag.equalsIgnoreCase("YES")){wrap.click(BaseProject.driver, consolflagy);}
        		else {wrap.click(BaseProject.driver, consolflagN);}
        		}
        		
        		if(prdtext.equalsIgnoreCase("TERM DEPOSITS"))
        		{
        			wrap.scroll_to(BaseProject.driver, accshrnm);
            		wrap.type(BaseProject.driver, "TEST", accshrnm);
            		wrap.scroll_to(BaseProject.driver, mIScd);
            		wrap.selectFromDropDown(BaseProject.driver, mIScd, "ASC", "BYVISIBLETEXT");
            		wrap.type(BaseProject.driver, "AS1", misval);
        		}
        		}
    
    @When("^FullData: validate prefilled values")
    public void prefillvaluevalidate()
            throws Throwable {
       
       switchFrame();
       DBUtils.convertDBtoMap("bdquery");	
       System.out.println(DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Client_Type"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_First_name"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Middle_name"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Last_name"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Full_name"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_DOB"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_COB"), DBUtils.readColumnWithRowID("Country_Of_Birth_Code", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Res_Country"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code1", BaseProject.scenarioID));
     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Communication"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
     
       FullDataMakerUtils.switchToProductDetailsTab();
       
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Camapigncode"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
       
     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ProductCategory"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
   //    wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Deposittype"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Producttype"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ACqusition"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Term"), DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Tenuretype"), DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Depositamnt"), DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ValueDate"), DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Rollover"), DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_interestfreq"), DBUtils.readColumnWithRowID("TD_Interest_Frequency", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_2in1"), DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_BaseRate"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_MArginal"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_MAturityDate"), DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Lien"), DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID));
       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_nodeposit"), DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID));
       
}
    
    
    public static void fillFamilydetailsjoint() throws IOException, InterruptedException {

    	int no = FullDataMaker.fDC_Co_Applicant + 1;
    	
    	//switchFrame();
    	
    	String maidenFirstName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_MaidenFirstName");
     	String fatherPrefix= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_FatherPrefix");
     	String fatherFirstName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_FatherFirstName");
     	String fatherMiddleName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_FatherMiddleName");
     	String fatherLastName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_FatherLastName");
     	String motherPrefix= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_MotherPrefix");       	
     	String motherFirstName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_MotherFirstName");
     	String motherMiddleName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_MotherMiddleName");
     	String motherLastName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_MotherLastName");
     	String spousePrefix= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_SpousePrefix");
     	String spouseFirstName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_SpouseFirstName");
     	String spouseMiddleName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_SpouseMiddleName");
     	String spouseLastName= com.getElementProperties("Fulldatacapturemaker", "FDC_Coapp_SpouseLastName");

     	String maiden_FirstName=DBUtils.readColumnWithRowID("Maiden_First_Name"+no,  BaseProject.scenarioID);
        String father_Prefix=DBUtils.readColumnWithRowID("Father_Prefix"+no,  BaseProject.scenarioID);
        String father_FirstName=DBUtils.readColumnWithRowID("Father_First_Name"+no,  BaseProject.scenarioID);
        String father_MiddleName=DBUtils.readColumnWithRowID("Father_Middle_Name"+no,  BaseProject.scenarioID);
        String father_LastName=DBUtils.readColumnWithRowID("Father_Last_Name"+no,  BaseProject.scenarioID);
        String mother_Prefix=DBUtils.readColumnWithRowID("Mother_Prefix"+no,  BaseProject.scenarioID);
        String mother_FirstName=DBUtils.readColumnWithRowID("Mother_First_Name"+no,  BaseProject.scenarioID);
        String mother_MiddleName=DBUtils.readColumnWithRowID("Mother_Middle_Name"+no,  BaseProject.scenarioID);
        String mother_LastName=DBUtils.readColumnWithRowID("Mother_Last_Name"+no,  BaseProject.scenarioID);
        String spouse_Prefix=DBUtils.readColumnWithRowID("SpousePrefix"+no,  BaseProject.scenarioID);
        String spouse_FirstName=DBUtils.readColumnWithRowID("Spouse_First_Name1"+no,  BaseProject.scenarioID);
        String spouse_MiddleName=DBUtils.readColumnWithRowID("Spouse_Middle_Name"+no,  BaseProject.scenarioID);
        String spouse_LastName=DBUtils.readColumnWithRowID("Spouse_Last_Name"+no,  BaseProject.scenarioID);

        wrap.scroll_to(BaseProject.driver, maidenFirstName);
        
        wrap.type(BaseProject.driver, maiden_FirstName, maidenFirstName);
     	wrap.selectFromDropDown(BaseProject.driver , fatherPrefix, father_Prefix, "BYVISIBLETEXT");
   //  	wrap.type(BaseProject.driver, father_FirstName, fatherFirstName);
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='FatherFirstName']")).click();
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='FatherFirstName']")).sendKeys(father_FirstName);
     	wrap.type(BaseProject.driver, father_MiddleName, fatherMiddleName);
     	wrap.type(BaseProject.driver, father_LastName, fatherLastName);
     	wrap.selectFromDropDown(BaseProject.driver, motherPrefix, mother_Prefix , "BYVISIBLETEXT");
     	//wrap.type(BaseProject.driver, mother_FirstName, motherFirstName);
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='MotherFirstName']")).click();
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='MotherFirstName']")).sendKeys(mother_FirstName);
     	wrap.type(BaseProject.driver, mother_MiddleName, motherMiddleName);
     	wrap.type(BaseProject.driver, mother_LastName, motherLastName);
     	wrap.selectFromDropDown(BaseProject.driver, spousePrefix, spouse_Prefix, "BYVISIBLETEXT");
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='SpouseFirstName']")).click();
     	wrap.wait(500);
     	BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='SpouseFirstName']")).sendKeys(spouse_FirstName);
     	//wrap.type(BaseProject.driver, spouse_FirstName, spouseFirstName);
     	wrap.type(BaseProject.driver, spouse_MiddleName, spouseMiddleName);
     	wrap.type(BaseProject.driver, spouse_LastName, spouseLastName);

}
    
    // Nethu's code
    
    @Then("^FDM : Add Contact section in Customer Details Tab$")
    public static void addcontactSection() throws IOException, InterruptedException {

        
        /**********************************Filling Contact section********************************************/
   
       FullDataMakerUtils.switchToCustomerDetailsTab();
       
        String contactDetails = com.getElementProperties("Fulldatacapturemaker", "ContactDetails");
        String iSDCode = com.getElementProperties("Fulldatacapturemaker", "ISDCode");
        String extension = com.getElementProperties("Fulldatacapturemaker", "Extension");
        
        String contact_type_Code = DBUtils.readColumnWithRowID("FDC_ContactCode", BaseProject.scenarioID);
        String contact_type_Description = DBUtils.readColumnWithRowID("FDC_ContactDescription", BaseProject.scenarioID);
        String contact_Details = DBUtils.readColumnWithRowID("FDC_ContactDetails", BaseProject.scenarioID);
        String iSD_Code = DBUtils.readColumnWithRowID("FDC_ISDCode", BaseProject.scenarioID);
        String extension_No = DBUtils.readColumnWithRowID("FDC_Extension", BaseProject.scenarioID);
       
       WebElement addContact=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AddContact"));          
       JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
       
       myExecutor.executeScript("arguments[0].click();", addContact);
       
       //com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AddContactType"),Contact_type_Code, Contact_type_Description);
       com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AddContactType"),contact_type_Code, "MT3");
       
       String CTD = contact_type_Code;
       
              
        if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4")| CTD.equals("MT7") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {

            wrap.type(BaseProject.driver, contact_Details, contactDetails);

            wrap.selectFromDropDown(BaseProject.driver, iSDCode, iSD_Code, "BYVISIBLETEXT");

        } else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {


            wrap.type(BaseProject.driver, contact_Details, contactDetails);

        } else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

            wrap.type(BaseProject.driver, contact_Details, contactDetails);
          
            wrap.selectFromDropDown(BaseProject.driver, iSDCode, iSD_Code, "BYVISIBLETEXT");
        
            wrap.type(BaseProject.driver, extension_No, extension);
            
        }

        else {

            wrap.type(BaseProject.driver, contact_Details, contactDetails);

        }
    }

@Then("^FDM : Add Address section in Customer Details Tab$")
        public static void addAddressSection() throws IOException, InterruptedException {
       
             FullDataMakerUtils.switchToCustomerDetailsTab();
             JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
       
       //*********************Address Section**************************
        wrap.scroll_to(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker","AddAddress"));
        
        WebElement addAddress=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AddAddress"));          
       
        myExecutor.executeScript("arguments[0].click();", addAddress);
        
        
        String fD_AddressType = com.getElementProperties("Fulldatacapturemaker", "FD_AddressType");
        String fD_AddressLine1 = com.getElementProperties("Fulldatacapturemaker", "FD_AddressLine1");
        String fD_AddressLine2 = com.getElementProperties("Fulldatacapturemaker", "FD_AddressLine2");
        String fD_AddressLine3 = com.getElementProperties("Fulldatacapturemaker", "FD_AddressLine3");      
        String fD_CityName = com.getElementProperties("Fulldatacapturemaker", "FD_CityName");
        String fD_PostalCode = com.getElementProperties("Fulldatacapturemaker", "FD_PostalCode");
        String fD_State = com.getElementProperties("Fulldatacapturemaker", "FD_State");
        String fD_Country = com.getElementProperties("Fulldatacapturemaker", "FD_Country");
        String fD_Area=com.getElementProperties("Fulldatacapturemaker", "FD_Area");
        String fD_LengthYY=com.getElementProperties("Fulldatacapturemaker", "FD_LengthYY");
        String fD_LengthMM=com.getElementProperties("Fulldatacapturemaker", "FD_LengthMM");
        
        
        String address2_Address_Type = DBUtils.readColumnWithRowID("Address2_Address Type", BaseProject.scenarioID);
        String address2_Address_Line_1 = DBUtils.readColumnWithRowID("Address2_Address Line 1", BaseProject.scenarioID);
        String address2_Address_Line_2 = DBUtils.readColumnWithRowID("Address2_Address Line 2", BaseProject.scenarioID);
        String address2_Address_Line_3 = DBUtils.readColumnWithRowID("Address2_Address Line 3", BaseProject.scenarioID);
        String address2_Country = DBUtils.readColumnWithRowID("Address2_Country", BaseProject.scenarioID);
        String address2_City = DBUtils.readColumnWithRowID("Address2_City", BaseProject.scenarioID);
        String address2_Zip_Code = DBUtils.readColumnWithRowID("Address2_Zip Code", BaseProject.scenarioID);
        String address2_Area= DBUtils.readColumnWithRowID("Address2_Area", BaseProject.scenarioID);
        String address2_LengthYY= DBUtils.readColumnWithRowID("Address2_Length at Current Address", BaseProject.scenarioID);
        String address2_LengthMM= DBUtils.readColumnWithRowID("Address2_Length_at_Current_Address_MM", BaseProject.scenarioID);       
        
        String address3_Address_Type = DBUtils.readColumnWithRowID("Address3_Address Type", BaseProject.scenarioID);
        String address3_Address_Line_1 = DBUtils.readColumnWithRowID("Address3_Address Line 1", BaseProject.scenarioID);
        String address3_Address_Line_2 = DBUtils.readColumnWithRowID("Address3_Address Line 2", BaseProject.scenarioID);
        String address3_Address_Line_3 = DBUtils.readColumnWithRowID("Address3_Address Line 3", BaseProject.scenarioID);
        String address3_Country = DBUtils.readColumnWithRowID("Address3_Country", BaseProject.scenarioID);
        String address3_City = DBUtils.readColumnWithRowID("Address3_City", BaseProject.scenarioID);
        String address3_Zip_Code = DBUtils.readColumnWithRowID("Address3_Zip Code", BaseProject.scenarioID);
        String address3_Area= DBUtils.readColumnWithRowID("Address3_Area", BaseProject.scenarioID);
        String address3_LengthYY= DBUtils.readColumnWithRowID("Address3_Length_at_Current_Address_YY", BaseProject.scenarioID);
        String address3_LengthMM= DBUtils.readColumnWithRowID("Address3_Length at Current Address", BaseProject.scenarioID);
        
        
        
        try {
             
             for(int y=0;y<8;y++)
                    new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(fD_AddressType)));
             com.suggestionTextBox3(BaseProject.driver, fD_AddressType, address2_Address_Type,"LO1");
       
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(fD_AddressType)));
        } 
        
        catch (Exception e) {
            e.printStackTrace();

        }
             wrap.type(BaseProject.driver, address2_Address_Line_1,fD_AddressLine1);
       
        wrap.type(BaseProject.driver, address2_Address_Line_2,fD_AddressLine2);

   
        wrap.type(BaseProject.driver, address2_Address_Line_3,fD_AddressLine3);

        wrap.type(BaseProject.driver, address2_City, fD_CityName);
        
        com.suggestionTextBox3(BaseProject.driver, fD_Country, "IN",address2_Country);
        wrap.type(BaseProject.driver, address2_Zip_Code,fD_PostalCode);
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_PostalCode"))));
  
        if(product.equals("CC"))
        {
             for(int g=0;g<7;g++)
             
                    new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_Area"))));
            wrap.type(BaseProject.driver, address2_Area,fD_Area);
            
            for(int g=0;g<7;g++)
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_LengthYY"))));
             wrap.type(BaseProject.driver, address2_LengthYY,fD_LengthYY);
             
             for(int g=0;g<7;g++)
                    new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_LengthMM"))));
             wrap.type(BaseProject.driver, address2_LengthMM,fD_LengthMM);
        }
        
        WebElement addAddress1=wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","AddAddress")); 
        
        myExecutor.executeScript("arguments[0].click();", addAddress1);
        for(int y=0;y<10;y++)
             new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(fD_AddressType)));
        com.suggestionTextBox3(BaseProject.driver, fD_AddressType,address3_Address_Type,"LO2");
        wrap.type(BaseProject.driver, address3_Address_Line_1,fD_AddressLine1);
        
        wrap.type(BaseProject.driver, address3_Address_Line_2,fD_AddressLine2);

   
        wrap.type(BaseProject.driver, address3_Address_Line_3,fD_AddressLine3);

        wrap.type(BaseProject.driver, address3_City, fD_CityName);
        
        com.suggestionTextBox3(BaseProject.driver, fD_Country, "IN",address3_Country);
        wrap.type(BaseProject.driver, address3_Zip_Code,fD_PostalCode);
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_PostalCode"))));
  
        if(product.equals("CC"))
        {
             for(int g=0;g<7;g++)
             
                    new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_Area"))));
            wrap.type(BaseProject.driver, address3_Area,fD_Area);
            
            for(int g=0;g<7;g++)
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_LengthYY"))));
             wrap.type(BaseProject.driver, address3_LengthYY,fD_LengthYY);
             
             for(int g=0;g<7;g++)
                    new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "FD_LengthMM"))));
             wrap.type(BaseProject.driver, address3_LengthMM,fD_LengthMM);
        }
        
        
        
    }

    @Then("^FDM : Fill Documents in Document Details Tab New$")
    public static void fillIDDocumnetTabNew() throws IOException, InterruptedException {

         wrap.switch_to_default_Content(BaseProject.driver);
          wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
         wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_tab"));
         wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_tab"));
         String passportExpiry = DBUtils.readColumnWithRowID("Expiry Date", BaseProject.scenarioID);
        String docName;
        
        //Client iD Documents
        
        logger.info("Client ID Documents");

        List<WebElement> doc = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'IDDocumentList')]//li");
        
        int idDocumentSize=doc.size()-1;
        
        logger.info("No of documents in  ID Doc : "+idDocumentSize);
          JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
        
        for(int mk=1;mk<=idDocumentSize;mk++)
        {
             
               BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'IDDocumentList')]//li["+mk+"]/a//td[1]")).click();
             
               if(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'IDDocumentList')]//div[contains(@id,'SubSectionIDDocumentListBTR')and contains(@style,'block')]//span[text()='Name of the Document']/..")).getTagName().contains("span"))
                    
                     docName=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'IDDocumentList')]//div[contains(@id,'SubSectionIDDocumentListBTR')and contains(@style,'block')]//span[text()='Name of the Document']//parent::span//following-sibling::div//span")).getText();
             
             else{
                    WebElement seldocName=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'IDDocumentList')]//div[contains(@id,'SubSectionIDDocumentListBTR')and contains(@style,'block')]//select[@id='DocumentName']"));
                    
                    Select sel=new Select(seldocName);
                    docName=sel.getFirstSelectedOption().getText();
             
             }
             
             if(docName.contains("PASSPORT")){
                 logger.info(docName);
                    
                    wrap.type(BaseProject.driver, passportExpiry, com.getElementProperties("Fulldatacapturemaker", "FD_Passport_expirydate"));                   
        
             
             }
        }
        

        //client verification documents
        
             List<WebElement> docs = wrap.getElements(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//li");
               
        int verfDocumentSize=docs.size()-1;
        
        logger.info("No of documents in  veriification Doc : "+verfDocumentSize);
        wrap.scroll_to(BaseProject.driver, "//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//li[1]/a//td[1]");
        for(int mk=1;mk<=verfDocumentSize;mk++)
        {
             
               BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//li["+mk+"]/a//td[1]")).click();
             
               if(BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//div[contains(@id,'SubSectionVerfDocumentListBTR')and contains(@style,'block')]//span[text()='Name of the Document']/..")).getTagName().contains("span"))
                    
                     docName=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//div[contains(@id,'SubSectionVerfDocumentListBTR')and contains(@style,'block')]//span[text()='Name of the Document']//parent::span//following-sibling::div//span")).getText();
             
             else{
                    WebElement seldocName=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionDocumentEntry')]//div[contains(@pl_prop,'VerfDocumentList')]//div[contains(@id,'SubSectionVerfDocumentListBTR')and contains(@style,'block')]//select[@id='DocumentName']"));
                    Select sel=new Select(seldocName);
                    docName=sel.getFirstSelectedOption().getText();
                    }
             
             if(docName.contains("PASSPORT")){
                 logger.info(docName);
                    
                    wrap.type(BaseProject.driver, passportExpiry, com.getElementProperties("Fulldatacapturemaker", "FD_Passport_expirydate_verf"));                   
        
             
             }
        }
        
        //PaySlip
        wrap.wait(500);
        WebElement payslip=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'Payslip')]"));
        wrap.wait(500);
        String paysliptxt=payslip.getText();
        
        wrap.wait(500);
        if(paysliptxt.contains("Payslip"))
        {
        	wrap.wait(500);
        	payslip.click();
        	
        	wrap.wait(500);
        	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");
        	
        	wrap.wait(500);
        	List <WebElement> month=BaseProject.driver.findElements(By.xpath("//li[contains(@hpref,'Payslip')]//span[contains(text(),'Month')]"));
        	for(WebElement months:month){
        		
        		wrap.wait(500);
        		months.click();
        	
        	
        	
        	wrap.wait(500);
        	wrap.enterDate(BaseProject.driver, "01/01/2015", com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentDate"));
        
        	wrap.wait(500);
        	wrap.enterDate(BaseProject.driver, "100", com.getElementProperties("Fulldatacapturemaker","FDC_Documents_ClientCreditAssessmentDocuments_GrossPay"));
        	
        	wrap.wait(500);
        	wrap.enterDate(BaseProject.driver, "100", com.getElementProperties("Fulldatacapturemaker","FDC_Documents_ClientCreditAssessmentDocuments_NetPay"));
        	
        	wrap.wait(500);
        	wrap.enterDate(BaseProject.driver, "10", com.getElementProperties("Fulldatacapturemaker","FDC_Documents_ClientCreditAssessmentDocuments_NoofWorkDays"));
        	
        	//wrap.wait(500);
        	//BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'Month2')]")).click();
        	
        	/*wrap.wait(500);
        	WebElement DocIssueDate2=BaseProject.driver.findElement(By.xpath("(//input[@id='DocumentDate2'])[2]"));
        	wrap.wait(500);
        	DocIssueDate2.click();
        	wrap.wait(500);
        	DocIssueDate2.sendKeys("01/01/1990");
        	
        	wrap.wait(500);
        	WebElement Grspay=BaseProject.driver.findElement(By.xpath("(//input[@id='GrossPay'])[2]"));
        	wrap.wait(500);
        	Grspay.click();
        	wrap.wait(500);
        	Grspay.sendKeys("100");
        	
        //	wrap.type(BaseProject.driver, "100", com.getElementProperties("Fulldatacapturemaker", "FDC_Payslip2"));
        	
        //	wrap.type(BaseProject.driver, "10", com.getElementProperties("Fulldatacapturemaker", "FDC_Payslip3"));
        	
        	wrap.wait(500);
        	WebElement Netpay=BaseProject.driver.findElement(By.xpath("(//input[@id='NetPay'])[2]"));
        	wrap.wait(500);
        	Netpay.click();
        	wrap.wait(500);
        	Netpay.sendKeys("10");*/
        	
        	
        	
        	}
        	
        }
        
      //Form16
        wrap.wait(500);
        WebElement form=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'FORM16')]"));
        wrap.wait(500);
        String formtxt=form.getText();
        
        wrap.wait(500);
        if(formtxt.contains("FORM16"))
        {
        	wrap.wait(500);
        	form.click();
        	
        	wrap.wait(500);
        	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");
        	
        	wrap.wait(500);
        	List <WebElement> year=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'Year')]"));
        	for(WebElement years:year){
        		
        		wrap.wait(500);
        		years.click();
        		
        		wrap.enterDate(BaseProject.driver, "01/01/2010", com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_Docdate"));
        		wrap.enterDate(BaseProject.driver, "10", com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_Income"));
        		
        	}
        }
        
        
        //CreditCard
        wrap.wait(500);
        WebElement cc=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'CreditCard')]"));
        wrap.wait(500);
        String cctxt=cc.getText();
        
        wrap.wait(500);
        if(cctxt.contains("CreditCard"))
        {
        	wrap.wait(500);
        	cc.click();
        	
        	wrap.wait(500);
        	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");
        	
        	wrap.wait(500);
        	List <WebElement> month=BaseProject.driver.findElements(By.xpath("//li[contains(@hpref,'CreditCard')]//span[contains(text(),'Month')]"));
        	for(WebElement months:month){
        		
        		wrap.wait(500);
        		months.click();
        		
        		wrap.enterDate(BaseProject.driver, "01/01/2010", com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_dateissue"));
        		wrap.enterDate(BaseProject.driver, "10", com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_cardlimit"));
        		wrap.enterDate(BaseProject.driver, "10", com.getElementProperties("Fulldatacapturemaker", "FDC_Doc_cardrepayratio"));
        		
        	}
        }
        
        
        //Bonus
        wrap.wait(500);
        WebElement bonus=BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[contains(text(),'BonusLetter')]"));
        wrap.wait(500);
        String bonustxt=bonus.getText();
        
        wrap.wait(500);
        if(bonustxt.contains("BonusLetter"))
        {
        	wrap.wait(500);
        	bonus.click();
        	
        	wrap.wait(500);
        	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_DocumentStatus"), "Received", "BYVISIBLETEXT");
             	
        }
        
        
        // CRS Fatca
        
        WebElement elementCRS=wrap.getElement(BaseProject.driver, "//span[text()='T0074']");
     
        Actions data =new Actions(BaseProject.driver);
        data.moveToElement(elementCRS);
        myExecutor.executeScript("arguments[0].click();", elementCRS);
     
        wrap.enterDate(BaseProject.driver, DBUtils.readColumnWithRowID("CRSExpiryDate", BaseProject.scenarioID),com.getElementProperties("Fulldatacapturemaker", "FD_CRSExpirydate"));
              
        // Other documents

        wrap.scroll_to(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "TaxOfResidence")); 
        
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("CRSComments", BaseProject.scenarioID),
                com.getElementProperties("Fulldatacapturemaker", "CRSCommentss"));
        for(int f=0;f<10;f++)
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "TaxOfResidence"))));
       
        com.suggestionTextBox4(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","TaxOfResidence"), "IN", "INDIA");
        
        
        for(int f=0;f<12;f++)
             new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "CRSReasoncode"))));
       
        com.suggestionTextBox3(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","CRSReasoncode"), "C00", "NO TIN REQUIRED");
         
        for(int f=0;f<12;f++)
             new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(com.getElementProperties("Fulldatacapturemaker", "CRSCommentss"))));
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("CRSComments", BaseProject.scenarioID), com.getElementProperties("Fulldatacapturemaker", "CRSCommentss"));
  
    }


    @Then("^FDM: Check for negative validation for customer details tab$")
    public static void negativeForCustomerDetailsTab() throws IOException, InterruptedException 
    {
        
        utils.convertExcelToMap(FullDataMaker.excelPath, "Datamodel.xls", "Negative");
        FullDataMakerUtils.switchToCustomerDetailsTab();          
        
        utils.negativeVals("Gender", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown"));
        utils.negativeVals("Marital_Status", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown"));
        utils.negativeVals("Educational_Qualification", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Qualification_DropDown"));
        utils.negativeVals("Place_of_Birth", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Placeofbirth_TextBox"));          
        utils.negativeVals("Constitution_Code", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Constitutioncode"));
        utils.negativeVals("Residential_Status", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown"));
        utils.negativeVals("No_of_Dependants", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_NoOfDependants_textbox"));       
        utils.negativeVals("connected_Lending_Relationship", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_dropdown"));
        
        //contact         
        utils.negativeVals("FDC_ContactCode", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_ContactType"));
        utils.negativeVals("FDC_ContactDetails", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_ContactDetails"));
        utils.negativeVals("FDC_ISDCode", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_ContactDetails"));
        //utils.negativeVals("Preferred_Contact1", com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_PreferredContact"));
        
        //Address
        utils.negativeVals("Address1_Address_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"));
        utils.negativeVals("Residence Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType"));
        utils.negativeVals("Address1_Address_Line_1", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address1_txt"));
        utils.negativeVals("Address1_Address_Line_2", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address2_txt"));
        utils.negativeVals("Address1_Address_Line_3", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address3_txt"));
        utils.negativeVals("Address1_Address_Line_3", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Address4_txt"));         
        utils.negativeVals("Address1_City", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_City"));
        utils.negativeVals("Address1_Country", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Country_suggestionBox"));
        utils.negativeVals("Address1_Zip_Code", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ZipCode_txt"));
        utils.negativeVals("Address1_State", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));
        utils.negativeVals("Address1_Area", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area"));
            utils.negativeVals("Address1_Mailing_Address_Indicator", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_CustomerMailingAddressIndicator_YChkBox"));
      utils.negativeVals("Address1_Permanent_Address_same_as_Residential_Address", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_Residential_Address_Yes"));
        
        //communication
        
        utils.negativeVals("Advice_Detail_Address_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));
        utils.negativeVals("Marketing_Preferences", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CS_MarkPref_DD_joint"));
        
        //Employment
        
        utils.negativeVals("Payroll_Indicator", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Payrollindicator_yes"));
        utils.negativeVals("Work_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"));
        utils.negativeVals("Nature_of_Business", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness"));
           utils.negativeVals("Describe_ApplicantOwnership_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_OwnershipType"));
        utils.negativeVals("Company_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CompanyType"));
        utils.negativeVals("Share_holding", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_shareholding"));
        utils.negativeVals("Business_Establishment_Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_BusinessEstablishmentDate"));
        utils.negativeVals("Company_Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CompanyName"));
        utils.negativeVals("Incorporation_Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_IncorporationDate"));
        utils.negativeVals("Incorporation_Country", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_IncorporationCountry"));
        utils.negativeVals("Designation", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Designation"));
        utils.negativeVals("Declared_Income", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AnnualDeclaredIncome"));          
       utils.negativeVals("No_of_Months_in_Current_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY"));
      utils.negativeVals("No_of_Months_in_Current_businessPreOrganization_MM", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM"));          
       utils.negativeVals("No_of_Months_in_Previous_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY"));
      utils.negativeVals("No_of_Months_in_Previous_businessPreOrganization_MM", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM"));          
        utils.negativeVals("Declared_Income", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AnnualDeclaredIncome"));          
        utils.negativeVals("Total_work_experience", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_WorkExperienceYY"));        
        utils.negativeVals("Total_work_experience", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_WorkExperienceMM"));
        
        //GST Details    
        
        utils.negativeVals("Customer_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_CustomerType_Yes"));
        utils.negativeVals("Specific_status", com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_SpecificStatus_Yes"));
        utils.negativeVals("State", com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_State"));
        
        //CDD
        
        utils.negativeVals("Type_of_initial_funding", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_sourceOfInitalFund"));
        utils.negativeVals("Amount_of_Initial_Funding", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_amountOfInitalFund"));
        utils.negativeVals("Date_of_Initial_Funding", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD_dateInitilaFund"));
        
        //AOF       
         utils.negativeVals("Availability_of_Customer_Signature", com.getElementProperties("Fulldatacapturemaker", "FDCM_CDSec_AvailabilityofCustomerSignatureYes_Radio"));
        
        //CDD       
        utils.negativeVals("Other_risk_factors", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CDD(OAT)_Other_risk_factors"));
        
        
        //product details       
        utils.negativeVals("Special_Rate", com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"));
        utils.negativeVals("Assessment_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType"));
        utils.negativeVals("Preferred_Limit", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
           utils.negativeVals("Term_deposit_on_secured_CC_value", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));
        utils.negativeVals("Product_address_type", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ProductAddressType"));
        
        //Bank Use        
        utils.negativeVals("Billing_Cycle", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_BillingCycle"));
        utils.negativeVals("CC_Emboss_Name", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CCEmbossName"));
        utils.negativeVals("Consolidated_Flag", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ConsolidatedFlagY"));
        utils.negativeVals("Statement_Type", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_StatementFlag"));
        utils.negativeVals("User_Code2", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UserCode2"));
        utils.negativeVals("LezCode", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Lezcode"));
        
        //Application Details
        utils.negativeVals("Closing_ID", com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
        utils.negativeVals("Investment_Account_Request", com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_yes"));
        utils.negativeVals("HR_Date", com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"));
        utils.negativeVals("DSA_Code", com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_DSACode"));
        utils.negativeVals("Referee_Relationship", com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_RefreeRelationship"));
        utils.negativeVals("Fund", com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_Fund"));         
        
        
        //utils.negativeVals("CustomerDemiseDate", com.getElementProperties("Fulldatacapturemaker", "FD_CD_CustDemiseDate"));
        //utils.negativeVals("Address Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_AddressType_suggestionBox"));
        //utils.negativeVals("Address Line 1", com.getElementProperties("Fulldatacapturemaker", "FD_AddressLine1"));
        //utils.negativeVals("FATCA - Is Customer a US Resident?", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?Yes"));
  }

    
    @Given("^FDM: Read FullData LOV Value on Customer Details Tab$")
    public void fdm_Read_FullData_LOV_Value_on_Customer_Details_Tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    	
    	

        String Gender = com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Gender_DropDown");
        String MaritalStatus = com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_MaritalStatus_DropDown");
        String Qualification = com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_CustomerDetail_Qualification_DropDown");
        String ResStatus = com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ResidentialStatus_dropdown");
        String ConLendingRel = com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_ConnectedLendingRelationship_dropdown");
        String Residencetype = com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_ResidenceType");
        String MarketingPref = com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_MarketingPreferences_dropdown"); 
        String Worktype = com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"); 
        String SalaryMode =com.getElementProperties("Fulldatacapturemaker", "FDC_CD_ModeofSalary");
       String NatureofBusiness = com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness");
       String Desig=com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Designation"); 
       String GrpSector =com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IndustryGroupSector"); 
       String NOB=com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NatureofBusiness");  
       String intialfund=com.getElementProperties("Fulldatacapturemaker", "FDC_CDD");  
       String FatherPrefix=com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherPrefix"); 
       String MotherPrefix=com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherPrefix"); 
       String SpousePrefix=com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpousePrefix"); 

        try {

        	CsvReaderutil.Read_values_from_CSV("Gender",Gender,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Marital Status",MaritalStatus,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Education Qualification",Qualification,"FDMLOVvalues.csv");
        	//CsvReaderutil.Read_values_from_CSV("",ResStatus,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("connected Lending Relationship",ConLendingRel,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Residence type",Residencetype,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Marketing Pref",MarketingPref,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Work Type",Worktype,"FDMLOVvalues.csv");

        	fillEmploymentSectionJoint() ;
        	CsvReaderutil.Read_values_from_CSV("Nature of Business",NatureofBusiness,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Salary Mode",SalaryMode,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Designation",Desig,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Industry Group Sector",GrpSector,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Nature of Business",NOB,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Designation",intialfund,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Father Prefix",FatherPrefix,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Mother Prefix",MotherPrefix,"FDMLOVvalues.csv");
        	CsvReaderutil.Read_values_from_CSV("Spouse Prefix",SpousePrefix,"FDMLOVvalues.csv");
        	
        } catch (Throwable e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }
 }
    
    
    
    
    @Given("^FDM: Read FullData LOV Value on Application Details Tab$")
    public void fdm_Read_FullData_LOV_Value_on_Application_Details_Tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
    	 String Refree = com.getElementProperties("Fulldatacapturemaker", "FDC_BankUse_RefreeRelationship");
    	 
    	 
    	
    	try {
			CsvReaderutil.Read_values_from_CSV("Refree Relationship",Refree,"FDMLOVvalues.csv");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
    }
    
   // @Then("Checker: Read LOV value under Checker section for Product tab")
    @Then("Checker: Read LOV value for FDC Product tab")
    public void validate_FDCfields_using_CSV_Products_tab() throws IOException
    {

           String AssessmentType = com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_AssessmentType");
           String Surrogate_On = com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Surrogate_On");
           String ProductAddressType = com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_ProductAddressType");
           String RepaymentMode = com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_RepaymentMode");
           String RepaymentAccountType = com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_RepaymentAccountType");
           String StatementFlag= com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_StatementFlag");
           String Purposeofloan= com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_Purposeofloan");
           String FeeCode= com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_FeeCode");
           String IFSCCode= com.getElementProperties("Fulldatacapturemaker", " FDC_ProductDetails_IFSCCode");






           try {

        	   CsvReaderutil.Read_values_from_CSV("Assessment Type", AssessmentType,"FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Surrogate On", Surrogate_On," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Product Address Type", ProductAddressType," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Repayment Mode", RepaymentMode," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Repayment Account Type", RepaymentAccountType," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Statement Flag", StatementFlag," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Purpose of Loan", Purposeofloan," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("Fee Code", FeeCode," FDC_LOV_Product.csv");
        	   CsvReaderutil.Read_values_from_CSV("IFSC Code", IFSCCode," FDC_LOV_Product.csv");




           } catch (Throwable e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
           }
    }
    
    @And("^FDC : connected to full dataset$")
	public static void loadFullDataset() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("fdquery");
	}

    
@Then("^FDM: Check for negative validation for Full data maker tabs$")
    public static void negativeForCustomerDetailsTab1() throws IOException, InterruptedException 
    {
        
        //utils.convertExcelToMap(FullDataMaker.excelPath, "Datamodel.xls", "Negative");
        FullDataMakerUtils.switchToCustomerDetailsTab();          
        
        
        utils.negativeVals("Advice Detail Address Type", com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));
        utils.negativeVals("Age of Child", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_AgeofChild"));
        utils.negativeVals("Area", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area_joint"));
        utils.negativeVals("Description of initial funding", com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_CDD_descriptionOfInitalFund"));
        utils.negativeVals("Company Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyName"));
        utils.negativeVals("CustomerDemiseDate", com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
        utils.negativeVals("Department", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Department_joint"));
        utils.negativeVals("Employee ID", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Corporateid"));
        utils.negativeVals("FatherFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));
        utils.negativeVals("FatherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));
        utils.negativeVals("FatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));
        utils.negativeVals("GST Registration Number", com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
        
        utils.negativeVals("Business Establishment Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate"));
        utils.negativeVals("Account Open Date", com.getElementProperties("Fulldatacapturemaker", "AccountOpenDate"));
        utils.negativeVals("Actual Monthly Commitment", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_ActualMonthlyCommitment"));
        utils.negativeVals("Applied Amount", com.getElementProperties("Fulldatacapturemaker", "Amount_Financial"));
        utils.negativeVals("Applied Tenor", com.getElementProperties("Fulldatacapturemaker", "AppliedTenor"));
        utils.negativeVals("Interest Rate1", com.getElementProperties("Fulldatacapturemaker", "InterestRate"));
        utils.negativeVals("Max advance ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Maxadvanceratio_joint"));
        utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV_joint"));
        utils.negativeVals("Original approved limit", com.getElementProperties("Fulldatacapturemaker", "OriginalApprovedLimit"));
        utils.negativeVals("other Card Repayment Ratio", com.getElementProperties("Fulldatacapturemaker", "OtherCardRepaymentRatio"));
        utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV_joint"));
        utils.negativeVals("Outstanding amount", com.getElementProperties("Fulldatacapturemaker", "OutstandingAmount"));
        utils.negativeVals("Remaining tenor in months", com.getElementProperties("Fulldatacapturemaker", "RemainingTenorInMonths"));
        utils.negativeVals("surrogate Insurance Premium", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_surrogateInsurancePremium"));
        
        utils.negativeVals("Incorporation Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationDate"));
        utils.negativeVals("MaidenFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));
       
        utils.negativeVals("State", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));
        
        utils.negativeVals("Mother Maiden Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MothersMaidenName"));
        utils.negativeVals("MotherFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));
        utils.negativeVals("MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));
        utils.negativeVals("MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));
        utils.negativeVals("Name of the Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
        utils.negativeVals("No_of_Months_in_Current_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker","FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY"));
        utils.negativeVals("No of Months in Current business/Organization", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM"));
        utils.negativeVals("No_of_Months_in_Previous_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY"));
        utils.negativeVals("No of Months in Previous business/Organization", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM"));
        utils.negativeVals("Number of children", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
        utils.negativeVals("Previous Employer Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Previousemployername"));
        utils.negativeVals("SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));
        utils.negativeVals("SpouseLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));
        utils.negativeVals("SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

        
        utils.negativeVals("% of Share holding", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_%ofShareholding_joint"));
        
        utils.negativeVals("Applied Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Amount"));
        utils.negativeVals("Applied Tenor", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AppliedTenor"));
        utils.negativeVals("Original approved limit", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Originalapprovedlimit"));
        utils.negativeVals("Outstanding amount", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Outstandingamount"));
        utils.negativeVals("Remaining tenor in months", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Remainingtenorinmonths"));
        utils.negativeVals("Interest Rate1", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestRate1"));
        utils.negativeVals("Interest Rate2", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestRate2"));
        utils.negativeVals("Actual Monthly Commitment", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_ActualMonthlyCommitment"));
        utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV"));
        utils.negativeVals("other Card Repayment Ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_otherCardRepaymentRatio"));
        utils.negativeVals("surrogate Insurance Premium", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_surrogateInsurancePremium"));
        utils.negativeVals("Max advance ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Maxadvanceratio"));
        utils.negativeVals("Late payment charges", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_Latepaymentcharges"));
        utils.negativeVals("Customer Demise Date", com.getElementProperties("Fulldatacapturemaker", "FD_CD_CustDemiseDate"));
        utils.negativeVals("Number of children", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
        utils.negativeVals("Name of the Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
        utils.negativeVals("Age of Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildAge"));
        utils.negativeVals("Advice Detail Address Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));

        
        
        //Product
        
        FullDataMakerUtils.switchToProductDetailsTab(); 
        utils.negativeVals("TermdepositSecureCC", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TDSecCC"));
        utils.negativeVals("Monthly_Repayment_Due_Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_MonthlyRepaymentDueDate"));
       
        utils.negativeVals("Account Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AccountNumber"));
        utils.negativeVals("Auto Debit Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AutoDebitAmount"));
        utils.negativeVals("Bank Sort Code", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_BankSortCode"));
        utils.negativeVals("CC Emboss Name", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CCEmbossName"));
        utils.negativeVals("User_Code2", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UserCode2"));
        utils.negativeVals("Beneficiary bank MICR code", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryBankMICRcode"));
        utils.negativeVals("Business Establishment Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate_joint"));
        utils.negativeVals("Cash Out Portion (with Currency)", com.getElementProperties("Fulldatacapturemaker", "OutstandingAmountcurrencyy"));
        
        utils.negativeVals("Beneficiary A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
        utils.negativeVals("Beneficiary Name", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
        utils.negativeVals("Pay Order amount", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PayOrderamount"));
        utils.negativeVals("Pay order hand over date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Payorderhandoverdate"));
        utils.negativeVals("Payment reference", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Paymentreference"));
        
        utils.negativeVals("EDA Account holder Name", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EDAName"));
        utils.negativeVals("Effective Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EffectiveDate"));
        utils.negativeVals("Expiry Date", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ExpiryDate"));
       
        
        //utils.negativeVals("Other Income for ITR Document", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("PAT for Profit and loss account", com.getElementProperties("Fulldatacapturemaker", ""));
          utils.negativeVals("PDC-Cheque No", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ChequeNo"));
          utils.negativeVals("PDC-Cheque Value", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ChequeValue"));
          utils.negativeVals("PDC-Effective Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-EffectiveDate"));
          utils.negativeVals("PDC-Expiry Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ExpiryDate"));
          utils.negativeVals("PDC-Total cheque No", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Total_Cheque_No"));
          utils.negativeVals("PDC-Total Cheque Value", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Total_Cheque_Value"));
        //utils.negativeVals("Premium Amount", com.getElementProperties("Fulldatacapturemaker", ""));
          utils.negativeVals("CA A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_CAA/CNumber"));
          utils.negativeVals("Emirates Skywards Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EmiratesMenbershipNum"));
          utils.negativeVals("Landmark Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_LandmarkMenbershipNum"));
          utils.negativeVals("Preferred Limit", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
          utils.negativeVals("Requested Amount (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));
          utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Tenure"));
          utils.negativeVals("Top-Up A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Top-UpA/CNumber"));
        //utils.negativeVals("Receivables for ITR Document", com.getElementProperties("Fulldatacapturemaker", ""));
          utils.negativeVals("Requested Fee %", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamountpercentage"));
          utils.negativeVals("Requested Fee Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamount"));
          utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
        //utils.negativeVals("Secured OD", com.getElementProperties("Fulldatacapturemaker", ""));
          
          utils.negativeVals("Term deposit on secured CC value", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));
        //utils.negativeVals("Term Loans outstanding", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Total Annual Income (before tax)/ Gross Income", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Total revenues/Sales", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Unsecured OverDraft", com.getElementProperties("Fulldatacapturemaker", ""));
         
        //utils.negativeVals("Supp C/H Address Line 1", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Supp C/H Address Line 2", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Supp C/H Address Line 3", com.getElementProperties("Fulldatacapturemaker", ""));
        //utils.negativeVals("Supp C/H Zipcode", com.getElementProperties("Fulldatacapturemaker", ""));

          utils.negativeVals("CA A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CAAccountNumber"));
          utils.negativeVals("Top-Up A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Top-UpA/CNumber"));
          utils.negativeVals("Emirates Skywards Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EmiratesMenbershipNum"));
          utils.negativeVals("Landmark Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_LandmarkMenbershipNum"));
          utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Tenure"));
          utils.negativeVals("Requested Fee %", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamountpercentage"));
          utils.negativeVals("Requested Fee Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamount"));
          utils.negativeVals("Preferred Limit", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
          utils.negativeVals("Beneficiary bank MICR code", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiarybankMICRcode"));
          utils.negativeVals("Debt Con Amount (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebtConAmt"));
          utils.negativeVals("Cash Out Portion (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CashOutPortion"));

          
        //Application
        
        FullDataMakerUtils.switchToApplicationDetailsTab(); 
        
        utils.negativeVals("Closing ID", com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ClosingID"));
        
        utils.negativeVals("CKYC ID", com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationTab_CKYCID"));
        utils.negativeVals("KYC Date Of Declaration", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));
        utils.negativeVals("KYC Employee Code", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeCode"));
        utils.negativeVals("KYC Employee Designation", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeDesignation"));
        utils.negativeVals("KYC Employee Name", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeName"));
        utils.negativeVals("KYC Place Of Declaration", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCPlaceofDeclaration"));
        utils.negativeVals("KYC Verification Branch", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationBranch"));
        utils.negativeVals("KYC Verification Date", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationDate"));
        
        utils.negativeVals("Closing ID", com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
        
        FullDataMakerUtils.switchToIncomeDocsTab();  
        utils.negativeVals("Director Remuneration", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_DirectorRemuneration"));
        utils.negativeVals("Receivables", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_Receivables"));
        utils.negativeVals("Income from profession", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_ProfessionalIncome"));
        utils.negativeVals("Income from Business", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_BusinessIncome"));
        utils.negativeVals("Other Income", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_OtherIncome"));
        utils.negativeVals("Term Loans outstanding", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_TermLoansoutstanding"));
        utils.negativeVals("Cash Credit", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_CashCredit"));
        utils.negativeVals("Unsecured OverDraft", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_UnsecuredOverDraft"));
        utils.negativeVals("Secured OD", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_SecuredOD"));

}


@Then("^FDM: Check for negative validation for Full data maker tabs withUATRef '(.+)'$")
public static void negativeForCustomerDetailsTabwithuatref(String uatref) throws IOException, InterruptedException 
{
    
    //utils.convertExcelToMap(FullDataMaker.excelPath, "Datamodel.xls", "Negative");
    FullDataMakerUtils.switchToCustomerDetailsTab();          
    
    
    utils.negativeVals("Advice Detail Address Type", com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));
    utils.negativeVals("Age of Child", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_AgeofChild"));
    utils.negativeVals("Area", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_Area_joint"));
    utils.negativeVals("Description of initial funding", com.getElementProperties("Fulldatacapturemaker", "FDC1_CD_CDD_descriptionOfInitalFund"));
    utils.negativeVals("Company Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_CompanyName"));
    utils.negativeVals("CustomerDemiseDate", com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants_CustDemiseDate"));
    utils.negativeVals("Department", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Department_joint"));
    utils.negativeVals("Employee ID", com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_Corporateid"));
    utils.negativeVals("FatherFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherFirstName"));
    utils.negativeVals("FatherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherMiddleName"));
    utils.negativeVals("FatherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_FatherLastName"));
    utils.negativeVals("GST Registration Number", com.getElementProperties("Fulldatacapturemaker", "FDC_GSTDetails_GSTRegistrationNumber_joint"));
    
    utils.negativeVals("Business Establishment Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate"));
    utils.negativeVals("Account Open Date", com.getElementProperties("Fulldatacapturemaker", "AccountOpenDate"));
    utils.negativeVals("Actual Monthly Commitment", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_ActualMonthlyCommitment"));
    utils.negativeVals("Applied Amount", com.getElementProperties("Fulldatacapturemaker", "Amount_Financial"));
    utils.negativeVals("Applied Tenor", com.getElementProperties("Fulldatacapturemaker", "AppliedTenor"));
    utils.negativeVals("Interest Rate1", com.getElementProperties("Fulldatacapturemaker", "InterestRate"));
    utils.negativeVals("Max advance ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Maxadvanceratio_joint"));
    utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV_joint"));
    utils.negativeVals("Original approved limit", com.getElementProperties("Fulldatacapturemaker", "OriginalApprovedLimit"));
    utils.negativeVals("other Card Repayment Ratio", com.getElementProperties("Fulldatacapturemaker", "OtherCardRepaymentRatio"));
    utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV_joint"));
    utils.negativeVals("Outstanding amount", com.getElementProperties("Fulldatacapturemaker", "OutstandingAmount"));
    utils.negativeVals("Remaining tenor in months", com.getElementProperties("Fulldatacapturemaker", "RemainingTenorInMonths"));
    utils.negativeVals("surrogate Insurance Premium", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_surrogateInsurancePremium"));
    
    utils.negativeVals("Incorporation Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_IncorporationDate"));
    utils.negativeVals("MaidenFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MaidenFirstName"));
   
    utils.negativeVals("State", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_AddressSection_State_txt"));
    
    utils.negativeVals("Mother Maiden Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerTab_FamilyDetails_MothersMaidenName"));
    utils.negativeVals("MotherFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherFirstName"));
    utils.negativeVals("MotherLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherLastName"));
    utils.negativeVals("MotherMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_MotherMiddleName"));
    utils.negativeVals("Name of the Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
    utils.negativeVals("No_of_Months_in_Current_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker","FDC_CD_NoofMonthsinCurrentbusinessOrganizationYY"));
    utils.negativeVals("No of Months in Current business/Organization", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinCurrentbusinessOrganizationMM"));
    utils.negativeVals("No_of_Months_in_Previous_businessPreOrganization_YY", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationYY"));
    utils.negativeVals("No of Months in Previous business/Organization", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_NoofMonthsinPreviousbusinessOrganizationMM"));
    utils.negativeVals("Number of children", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
    utils.negativeVals("Previous Employer Name", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Previousemployername"));
    utils.negativeVals("SpouseFirstName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseFirstName"));
    utils.negativeVals("SpouseLastName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseLastName"));
    utils.negativeVals("SpouseMiddleName", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_SpouseMiddleName"));

    
    utils.negativeVals("% of Share holding", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_%ofShareholding_joint"));
    
    utils.negativeVals("Applied Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Amount"));
    utils.negativeVals("Applied Tenor", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_AppliedTenor"));
    utils.negativeVals("Original approved limit", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Originalapprovedlimit"));
    utils.negativeVals("Outstanding amount", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Outstandingamount"));
    utils.negativeVals("Remaining tenor in months", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Remainingtenorinmonths"));
    utils.negativeVals("Interest Rate1", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestRate1"));
    utils.negativeVals("Interest Rate2", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_InterestRate2"));
    utils.negativeVals("Actual Monthly Commitment", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_ActualMonthlyCommitment"));
    utils.negativeVals("Mortgage CMV", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_MortgageCMV"));
    utils.negativeVals("other Card Repayment Ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_otherCardRepaymentRatio"));
    utils.negativeVals("surrogate Insurance Premium", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_surrogateInsurancePremium"));
    utils.negativeVals("Max advance ratio", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_Maxadvanceratio"));
    utils.negativeVals("Late payment charges", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_Latepaymentcharges"));
    utils.negativeVals("Customer Demise Date", com.getElementProperties("Fulldatacapturemaker", "FD_CD_CustDemiseDate"));
    utils.negativeVals("Number of children", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_NumberOfChildren"));
    utils.negativeVals("Name of the Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildName"));
    utils.negativeVals("Age of Child", com.getElementProperties("Fulldatacapturemaker", "FDM_Family_ChildAge"));
    utils.negativeVals("Advice Detail Address Type", com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"));

    
    
    //Product
    
    FullDataMakerUtils.switchToProductDetailsTab(); 
    utils.negativeVals("TermdepositSecureCC", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TDSecCC"));
    utils.negativeVals("Monthly_Repayment_Due_Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_MonthlyRepaymentDueDate"));
   
    utils.negativeVals("Account Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AccountNumber"));
    utils.negativeVals("Auto Debit Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_AutoDebitAmount"));
    utils.negativeVals("Bank Sort Code", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_BankSortCode"));
    utils.negativeVals("CC Emboss Name", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CCEmbossName"));
    utils.negativeVals("User_Code2", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_UserCode2"));
    utils.negativeVals("Beneficiary bank MICR code", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryBankMICRcode"));
    utils.negativeVals("Business Establishment Date", com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_BusinessEstablishmentDate_joint"));
    utils.negativeVals("Cash Out Portion (with Currency)", com.getElementProperties("Fulldatacapturemaker", "OutstandingAmountcurrencyy"));
    
    utils.negativeVals("Beneficiary A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryNumber"));
    utils.negativeVals("Beneficiary Name", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_BeneficiaryName"));
    utils.negativeVals("Pay Order amount", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_PayOrderamount"));
    utils.negativeVals("Pay order hand over date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Payorderhandoverdate"));
    utils.negativeVals("Payment reference", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_Paymentreference"));
    
    utils.negativeVals("EDA Account holder Name", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EDAName"));
    utils.negativeVals("Effective Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_EffectiveDate"));
    utils.negativeVals("Expiry Date", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_ExpiryDate"));
   
    
    //utils.negativeVals("Other Income for ITR Document", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("PAT for Profit and loss account", com.getElementProperties("Fulldatacapturemaker", ""));
      utils.negativeVals("PDC-Cheque No", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ChequeNo"));
      utils.negativeVals("PDC-Cheque Value", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ChequeValue"));
      utils.negativeVals("PDC-Effective Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-EffectiveDate"));
      utils.negativeVals("PDC-Expiry Date", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PDC-ExpiryDate"));
      utils.negativeVals("PDC-Total cheque No", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Total_Cheque_No"));
      utils.negativeVals("PDC-Total Cheque Value", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Total_Cheque_Value"));
    //utils.negativeVals("Premium Amount", com.getElementProperties("Fulldatacapturemaker", ""));
      utils.negativeVals("CA A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_CAA/CNumber"));
      utils.negativeVals("Emirates Skywards Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EmiratesMenbershipNum"));
      utils.negativeVals("Landmark Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_LandmarkMenbershipNum"));
      utils.negativeVals("Preferred Limit", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
      utils.negativeVals("Requested Amount (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_RequestedAmount"));
      utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Tenure"));
      utils.negativeVals("Top-Up A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Top-UpA/CNumber"));
    //utils.negativeVals("Receivables for ITR Document", com.getElementProperties("Fulldatacapturemaker", ""));
      utils.negativeVals("Requested Fee %", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamountpercentage"));
      utils.negativeVals("Requested Fee Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamount"));
      utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Requestedtenure"));
    //utils.negativeVals("Secured OD", com.getElementProperties("Fulldatacapturemaker", ""));
      
      utils.negativeVals("Term deposit on secured CC value", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_TermDepositOnSecureCCValue"));
    //utils.negativeVals("Term Loans outstanding", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Total Annual Income (before tax)/ Gross Income", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Total revenues/Sales", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Unsecured OverDraft", com.getElementProperties("Fulldatacapturemaker", ""));
     
    //utils.negativeVals("Supp C/H Address Line 1", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Supp C/H Address Line 2", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Supp C/H Address Line 3", com.getElementProperties("Fulldatacapturemaker", ""));
    //utils.negativeVals("Supp C/H Zipcode", com.getElementProperties("Fulldatacapturemaker", ""));

      utils.negativeVals("CA A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CAAccountNumber"));
      utils.negativeVals("Top-Up A/C Number", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Top-UpA/CNumber"));
      utils.negativeVals("Emirates Skywards Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_EmiratesMenbershipNum"));
      utils.negativeVals("Landmark Membership No.", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_LandmarkMenbershipNum"));
      utils.negativeVals("Requested Tenure", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Tenure"));
      utils.negativeVals("Requested Fee %", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamountpercentage"));
      utils.negativeVals("Requested Fee Amount", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_Reqfeeamount"));
      utils.negativeVals("Preferred Limit", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_PreferredLimit"));
      utils.negativeVals("Beneficiary bank MICR code", com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiarybankMICRcode"));
      utils.negativeVals("Debt Con Amount (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_DebtConAmt"));
      utils.negativeVals("Cash Out Portion (with Currency)", com.getElementProperties("Fulldatacapturemaker", "FDC_ProductDetails_CashOutPortion"));

      
    //Application
    
    FullDataMakerUtils.switchToApplicationDetailsTab(); 
    
    utils.negativeVals("Closing ID", com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ClosingID"));
    
    utils.negativeVals("CKYC ID", com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationTab_CKYCID"));
    utils.negativeVals("KYC Date Of Declaration", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCDateofDeclaration"));
    utils.negativeVals("KYC Employee Code", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeCode"));
    utils.negativeVals("KYC Employee Designation", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeDesignation"));
    utils.negativeVals("KYC Employee Name", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCEmployeeName"));
    utils.negativeVals("KYC Place Of Declaration", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCPlaceofDeclaration"));
    utils.negativeVals("KYC Verification Branch", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationBranch"));
    utils.negativeVals("KYC Verification Date", com.getElementProperties("Fulldatacapturemaker", "FDC_AD_KYCVerificationDate"));
    
    utils.negativeVals("Closing ID", com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_ClosingID"));
    
    FullDataMakerUtils.switchToIncomeDocsTab();  
    utils.negativeVals("Director Remuneration", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_DirectorRemuneration"));
    utils.negativeVals("Receivables", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_Receivables"));
    utils.negativeVals("Income from profession", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_ProfessionalIncome"));
    utils.negativeVals("Income from Business", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_BusinessIncome"));
    utils.negativeVals("Other Income", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_OtherIncome"));
    utils.negativeVals("Term Loans outstanding", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_TermLoansoutstanding"));
    utils.negativeVals("Cash Credit", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_CashCredit"));
    utils.negativeVals("Unsecured OverDraft", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_UnsecuredOverDraft"));
    utils.negativeVals("Secured OD", com.getElementProperties("Fulldatacapturemaker", "FDC_Documents_ClientCreditAssessmentDocuments_SecuredOD"));

    
    BaseProject.scenario.write("The fields are validated successfully.UAT Reference is " +uatref);
    
}

@When("^FullData: Switch Product '(.*)'$")
public void SwitchProduct(String j)
        throws Throwable {

    int i = Integer.parseInt(j);
    int k = i + 1;
    
    String tab = "xpath=(//li[@id='Tab" + k + "' and contains(@tabbedrepeatid,'Product')]//a)";
    wrap.click(BaseProject.driver, tab);
}
}
