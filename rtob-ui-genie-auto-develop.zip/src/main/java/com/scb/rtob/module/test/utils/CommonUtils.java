package com.scb.rtob.module.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.JavascriptExecutor;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.framework.glue.DocumentIndexing;
import com.scb.rtob.module.test.framework.glue.Basicdatacapturechecker;
import com.scb.rtob.module.test.framework.glue.FullDataMaker;
import com.scb.rtob.module.test.framework.glue.BaseProject;


//import com.standardchartered.techm.rtob.module.rtob.glue.RMReferralFlow;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.standardchartered.genie.model.GenieScenario;

import org.openqa.selenium.*;

public class CommonUtils {

	private static Logger logger = Logger.getLogger(CommonUtils.class);

	public static String screenShotPath = "C:/CaptureScreenshot";

	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();

	public static List<HashMap<String, String>> mydata = new ArrayList<HashMap<String, String>>();

	public List<HashMap<String, String>> inputData = new ArrayList<HashMap<String, String>>();

	public List<List<HashMap<String, String>>> mydata1 = new ArrayList<List<HashMap<String, String>>>();

	public static int rowCount = 10;

	public void convertAllExcelToMap() throws IOException{

		mydata1.clear();
		convertExcelToMap(BaseProject.excelPath, "RTOB_Input.xls", "DocumentIndexing");
		inputData = mydata;
		mydata1.add(inputData);
		logger.info(inputData);
		logger.info(mydata1);
		convertExcelToMap(BaseProject.excelPath, "RTOB_Input.xls", "DocInd_order");
		inputData = mydata;
		mydata1.add(mydata);
		logger.info(inputData);
		logger.info(mydata1);

	}

	@SuppressWarnings("deprecation")
	public static void convertExcelToMap(String FilePath,String FileName,String sheetName) throws IOException{
		mydata.clear();
		String MyFile= FilePath+File.separator+FileName;
		logger.info("MyFile[before] :"+MyFile);

		//String envName = System.getProperty("env");
		URL resource = DBUtils.class.getClassLoader().getResource("ExcelData" + File.separator + FileName);
		File file = null;
		FileInputStream fin = null;
		try {
			file = new File(resource.toURI());
			fin = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		logger.info("MyFile[after] :"+file.toString());

		//FileInputStream fin = new FileInputStream(MyFile);
		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		/*for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
		{
		    Row currentRow = sheet.getRow(i);
		    for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		    {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType())
		        {
		            case Cell.CELL_TYPE_STRING:
		                System.out.print(currentCell.getStringCellValue() + "|");
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                System.out.print(currentCell.getNumericCellValue() + "|");
		                break;

		            case Cell.CELL_TYPE_BLANK:
		                System.out.print("<blank>|");
		                break;
		        }
		    }
		    System.out.println("\n");
		}*/
		rowCount = sheet.getPhysicalNumberOfRows();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			HashMap<String, String> currentHash = new HashMap<String, String>();
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				Cell currentCell = currentRow.getCell(j);
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_NUMERIC:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue()));
					break;
				}
			}
			mydata.add(currentHash);
			//System.out.println("\n\n"+currentHash);
		}
		//logger.info(mydata);
		//logger.info(mydata.get(0));
	}



	public static String readColumn(String column,int row){
		logger.info("Row id is" + row);
		HashMap<String, String> map = mydata.get(row);
		String result=null;
		for (Entry<String, String> entry : map.entrySet()) {
			if(entry.getKey().equalsIgnoreCase(column)){
				logger.info(entry.getValue());
				result = entry.getValue();
			}

		}
		return result;


	}

	public static String readColumn1(String column){
		for(int i=0;i<10;i++){
			HashMap<String, String> map = mydata.get(i);
			String result=null;
			for (Entry<String, String> entry : map.entrySet()) {
				if(entry.getKey().equalsIgnoreCase(column)){
					logger.info(entry.getValue());
					//result = entry.getValue();
					//System.out.println(result);
				}

			}

		}
		return column;



	}

	public static String readColumnWithRowID(String column,String rowID){
		logger.info("row :"+column+":"+rowID);
		String result=null;
		try{
			for(int i=0;i<rowCount;i++){
				if(readColumn("Scenarioid", i).equalsIgnoreCase(rowID)){
					logger.info("matched with "+readColumn("Scenarioid", i));
					result = readColumn(column, i);
					break;
				}
			}
		}
		catch(IndexOutOfBoundsException I){
			logger.info("Row ID didn't match");
			I.printStackTrace();
		}
		catch(Exception E){
			logger.info("Reading from Excel has failed");
		}
		logger.info("result : "+result);
		return result;
	}

	public static void convertExcelToMapFromLocal(String FilePath,String FileName,String sheetName) throws IOException{
		mydata.clear();
		String MyFile= FilePath+File.separator+FileName;
		HSSFWorkbook book = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(MyFile)));
		FileInputStream fin = new FileInputStream(MyFile);
		//		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		//		XSSFWorkbook book = new XSSFWorkbook(fin);
		//		XSSFSheet sheet = book.getSheet(sheetName);
		/*for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
		{
		    Row currentRow = sheet.getRow(i);
		    for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		    {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType())
		        {
		            case Cell.CELL_TYPE_STRING:
		                System.out.print(currentCell.getStringCellValue() + "|");
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                System.out.print(currentCell.getNumericCellValue() + "|");
		                break;

		            case Cell.CELL_TYPE_BLANK:
		                System.out.print("<blank>|");
		                break;
		        }
		    }
		    System.out.println("\n");
		}*/
		rowCount = sheet.getPhysicalNumberOfRows();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			HashMap<String, String> currentHash = new HashMap<String, String>();
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				Cell currentCell = currentRow.getCell(j);
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_NUMERIC:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue()));
					break;
				}
			}
			mydata.add(currentHash);
			//System.out.println("\n\n"+currentHash);
		}
		//logger.info(mydata);
		//logger.info(mydata.get(0));
	}



	public static void validateField(String locator,String fieldName,String singlemulti, String dataformat,String dataType, String length, String moc,String displayEditable,String derived,String section,String tab) throws IOException, InterruptedException{

		String tabResult="NA";
		String sectionResult="NA";
		String editableResult="NA";
		String dataTypeResult="NA";
		String dataFormatResult="NA";
		String singleMultiResult="NA";
		String mandatoryResult="NA";
		String fieldLengthResult="NA";
		String derivedResult="NA";


		try {

			logger.info("Validations for Field :"+fieldName);

			if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator))){

				logger.info("Field is present in the screen");

				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties(BaseProject.propertiesFilename, locator)));               

				//wrap.screenShot(BaseProject.driver, screenShotPath, fieldName);

				tabResult = String.valueOf(wrap.verifyTabName(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator), tab));

				logger.info("***** Tab matched : "+tabResult+" *****");

				sectionResult = String.valueOf(wrap.verifySectionName(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator), section));

				logger.info("***** Section matched : "+sectionResult+" *****");

				editableResult = String.valueOf(wrap.editableFieldCheck(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator),displayEditable));

				logger.info("***** Editable Check : "+	editableResult+" *****");

				singleMultiResult = String.valueOf(wrap.validateSingleMultiple(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator), singlemulti,fieldName));

				logger.info("***** SINGLE/MULTIPLE matched : "+singleMultiResult+" *****");

				derivedResult = String.valueOf(wrap.derivedVal(BaseProject.driver,com.getElementProperties(BaseProject.propertiesFilename, locator),derived));

				logger.info("***** Derived Check : "+derivedResult+" *****");

				if(displayEditable.equalsIgnoreCase("Editable")){

					dataTypeResult = String.valueOf(wrap.fieldObjectTypeVal(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator), dataType));

					logger.info("***** DataType matched : "+dataTypeResult+" *****");

					dataFormatResult = String.valueOf(wrap.dataTypeVal(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator), dataformat));

					logger.info("***** DataFormat matched : "+dataFormatResult+" *****");

					mandatoryResult = String.valueOf(wrap.isMandatoryField(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator),moc));

					logger.info("***** Mandatory Check : "+mandatoryResult+" *****");

					if(!dataType.equalsIgnoreCase("Dropdown")){

						fieldLengthResult = String.valueOf(wrap.fieldLenghtVal(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, locator),length,dataType));

						logger.info("***** FieldLength matched : "+fieldLengthResult+" *****");

					}

				}

			}

			else{

				logger.info("Field is not present in the screen");
			}

		}
		catch(Exception E){
			logger.info("FAIL - Field Validation failed");
			E.printStackTrace();
		}

		BaseProject.reportFieldVals.add(fieldName+","+tabResult+","+sectionResult+","+editableResult+","+dataTypeResult+","+dataFormatResult+","+
				singleMultiResult+","+mandatoryResult+","+fieldLengthResult+","+derivedResult);

		/*System.out.println(tabResult+":"+sectionResult+":"+editableResult+":"+dataTypeResult+":"+dataFormatResult+":"+
							singleMultiResult+":"+mandatoryResult+":"+fieldLengthResult+":"+derivedResult);*/


	}
	/*	public static void getScreenShot(WebDriver webDriver, GenieScenario genieScenario){

		EventFiringWebDriver fwd = new EventFiringWebDriver(webDriver);
		try {
			logger.info("***** Perform getScreenShot *****");
			byte[] screenshot = fwd.getScreenshotAs(OutputType.BYTES);
			genieScenario.embed(screenshot, "image/png");

		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots.getMessage());
		}

	}*/

	// Heamalatha updated on 10 Jan
	public static void validateField_frontline(String fieldName,String locator, String dataformat, String dataType, String length, String moc,String displayEditable,String derived) throws IOException, InterruptedException{

		String tabResult="NA";
		String sectionResult="NA";
		String editableResult="NA";
		String dataTypeResult="NA";
		String dataFormatResult="NA";
		String singleMultiResult="NA";
		String mandatoryResult="NA";
		String fieldLengthResult="NA";
		String derivedResult="NA";


		try {

			logger.info("Validations for Field :"+fieldName);

			if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator))){

				logger.info("Field is present in the screen");

				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", locator)));               

				wrap.screenShot(BaseProject.driver, screenShotPath, fieldName);

				//                tabResult = String.valueOf(wrap.verifyTabName(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), tab));
				//				
				//				logger.info("***** Tab matched : "+tabResult+" *****");
				//				
				//				sectionResult = String.valueOf(wrap.verifySectionName(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), section));
				//				
				//				logger.info("***** Section matched : "+sectionResult+" *****");
				//				
				editableResult = String.valueOf(wrap.editableFieldCheck(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),displayEditable));

				logger.info("***** Editable Check : "+	editableResult+" *****");

				//				singleMultiResult = String.valueOf(wrap.validateSingleMultiple(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), singlemulti,fieldName));
				//				
				//				logger.info("***** SINGLE/MULTIPLE matched : "+singleMultiResult+" *****");

				derivedResult = String.valueOf(wrap.derivedVal(BaseProject.driver,com.getElementProperties(FullDataMaker.propertiesFilename, locator),derived));

				logger.info("***** Derived Check : "+derivedResult+" *****");

				if(displayEditable.equalsIgnoreCase("Editable")){

					dataTypeResult = String.valueOf(wrap.fieldObjectTypeVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), dataType));

					logger.info("***** DataType matched : "+dataTypeResult+" *****");

					dataFormatResult = String.valueOf(wrap.dataTypeVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), dataformat));

					logger.info("***** DataFormat matched : "+dataFormatResult+" *****");

					mandatoryResult = String.valueOf(wrap.isMandatoryField(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),moc));

					logger.info("***** Mandatory Check : "+mandatoryResult+" *****");

					if(!dataType.equalsIgnoreCase("Dropdown")){

						fieldLengthResult = String.valueOf(wrap.fieldLenghtVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),length,dataType));

						logger.info("***** FieldLength matched : "+fieldLengthResult+" *****");

					}

				}

			}

			else{

				logger.info("Field is not present in the screen");
			}

		}
		catch(Exception E){
			logger.info("FAIL - Field Validation failed");
			E.printStackTrace();
		}

		BaseProject.reportFieldVals.add(fieldName+","+editableResult+","+dataTypeResult+","+dataFormatResult+","+
				singleMultiResult+","+mandatoryResult+","+fieldLengthResult+","+derivedResult);

		/*System.out.println(tabResult+":"+sectionResult+":"+editableResult+":"+dataTypeResult+":"+dataFormatResult+":"+
							singleMultiResult+":"+mandatoryResult+":"+fieldLengthResult+":"+derivedResult);*/


	}

	public static void Read_CSV(String Field, String xpath) throws Throwable {

		//  CommonUtils.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Frontline");
		//  
		//  String Doc_category = utils.readColumnWithRowID("Document Category","1");
		//  System.out.println("Documnet List: "+Doc_category);
		//  String getval = "CLIENT VERIFICATION DOCUMENTS","CLIENT //SERVICING DOCUMENTS","INTERNAL DOCUMENTS","CLIENT TAX //DOCUMENTS","PRODUCT & SUPPORTING DOCUMENTS","FATCA  DOCUMENTS","CLIENT //CREDIT ASSESSMENT DOCUMENTS","CLIENT ID  DOCUMENTS","COLLATERAL //DOCUMENTS","Please Select...";
		//String csvFilename = "data.csv";
		//CSVReader csvReader = new CSVReader(new FileReader(csvFilename));
		//csvFilename .readHeaders();
		//String getval = csvReader.get(Field);
		//List Documnet_Category_List=Arrays.asList(getval.split(","));
		List Documnet_Category_List=Arrays.asList("CLIENT VERIFICATION DOCUMENTS","CLIENT SERVICING DOCUMENTS","INTERNAL DOCUMENTS","CLIENT TAX DOCUMENTS","PRODUCT & SUPPORTING DOCUMENTS","FATCA  DOCUMENTS","CLIENT CREDIT ASSESSMENT DOCUMENTS","CLIENT ID  DOCUMENTS","COLLATERAL DOCUMENTS","Please Select...");       
		Iterator document_category = Documnet_Category_List.iterator();
		while(document_category.hasNext()){
			String doclists=document_category.next().toString().trim().toUpperCase();
			System.out.println("Document from confluence: " + doclists);
		}     

		Collections.sort(Documnet_Category_List);
		System.out.println(Documnet_Category_List);
		switchFrame();

		ArrayList<String> doclistsort = new ArrayList();
		//List<WebElement> doc_category =BaseProject.driver.findElements(By.xpath("//select[@id='DocCategoryToUpload']"));

		WebElement element= BaseProject.driver.findElement(By.xpath(xpath));
		//WebElement ele = wrap.getElement(BaseProject.driver, Attribute)
		Select doclist=new Select(element);
		List<WebElement> doclist_count=doclist.getOptions();
		int doclist_size=doclist_count.size();

		for(WebElement ele:doclist_count)
		{
			doclistsort.add(ele.getText()); 
			System.out.println("Document from APP: " +ele.getText());
		}
		Collections.sort(doclistsort);
		System.out.println(doclistsort);

		if(Documnet_Category_List.equals(doclistsort)){
			System.out.println("Success");

		}
		else
		{
			System.out.println("Fail");
		}

		//csvReader .close();


	}

	public static void switchFrame() throws InterruptedException {
		int Last = 0;

		BaseProject.driver.switchTo().defaultContent();
		//wrap.wait(300);
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));

		}
		//logger.info("current frame name is "+ frmName.getAttribute("id"));
		Last = frames.size() - 1;
		//string currentFrame =
		logger.info("User should switch to this frame name PegaGadget" + Last + "Ifr");

		//wdwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(Last));
		BaseProject.driver.switchTo().frame(Last);
		logger.info("User switched to this frame name PegaGadget" + Last + "Ifr");
		//wrap.wait(300);
	}

		// Created by Dinesh - Jan 22
	//Modified by Hema - Feb 15
	public void negativeVals(String field,String locator) throws IOException, InterruptedException{


		logger.info("Validations for Field : "+field);

		logger.info("Retrieved Attribute path : "+locator);

		String data_type;

		if(wrap.isElementPresent(BaseProject.driver, locator)){
			logger.info("Field is present in the screen");         
			logger.info("Retrieved Locator from file "+locator);

			JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;              
			jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,locator));

			data_type = wrap.getElement(BaseProject.driver, locator).getAttribute("data-ctl"); 

			if(data_type==null)
			{
				data_type = wrap.getElement(BaseProject.driver, locator).getAttribute("type");
			}

			logger.info("Data type of an element is : "+data_type);
			String trimeddata_type = data_type.replaceAll("[^a-zA-Z]", "");
			logger.info("Trimmed data type value is : "+trimeddata_type );

			if(trimeddata_type.contains("radio"))
			{
				wrap.getElement(BaseProject.driver, locator).sendKeys("");
				wrap.elementTabOut(BaseProject.driver, locator);
				locator = locator+"/preceding-sibling::div/span";
				logger.info("The negative xpath is : "+locator);
				String negval = wrap.getTextValue(BaseProject.driver, locator);
				if(negval.contains("Value cannot"))
				{
					logger.info("inline error message is displayed as " + negval);
				}
			}

			else if(trimeddata_type.equalsIgnoreCase("Dropdown"))
			{
				//String val = DBUtils.readColumnWithRowID(field, BaseProject.scenarioID);         
//				String[] scenario= BaseProject.scenarioID.split("-");
//				logger.info("Scenario Id retrieved" + scenario );
//				logger.info("Scenario Id after splitting" + scenario[1] );

				//String val = DBUtils.readColumnWithRowID(field,scenario[1]); 
				
				String val = DBUtils.readColumnWithRowID(field,BaseProject.scenarioID); 

				logger.info(field+"value of DB is : "+ val);

				if(val.contains("Please Select"))
				{
					Thread.sleep(1000);
					wrap.selectFromDropDown(BaseProject.driver, locator, "0", "BYINDEX");
					Thread.sleep(1000);
					wrap.elementTabOut(BaseProject.driver, locator);
					if(locator.contains("elect"))
					{
						locator = locator+"/following-sibling::div/span";
					}
					else
					{
						locator = locator;
					}
					logger.info("The negative xpath is : "+locator);
					String negval = wrap.getTextValue(BaseProject.driver, locator);
					if(negval.contains("Value cannot"))
					{
						logger.info("inline error message is displayed as " + negval);

					}

				}

			}

			else if (trimeddata_type.equalsIgnoreCase("AutoCompleteAG")||trimeddata_type.equalsIgnoreCase("TextInput")||trimeddata_type.contains("Date"))
			{
				boolean errorMsgCheck = false;

				// String[] value = readColumn(field, 0).split("\\|");
				logger.info("Scenario id is "+ BaseProject.scenarioID);
				logger.info("Field is" + field);
				logger.info("Value Retrieved"+ DBUtils.readColumnWithRowID(field,BaseProject.scenarioID));
				String[] value  =DBUtils.readColumnWithRowID(field,BaseProject.scenarioID).split("\\|");  
				logger.info("Number of items to verify is : "+value.length);
				for(int i=0;i<value.length;i++)
				{

					logger.info("Negative value : "+value[i]);
					Thread.sleep(2000);
					//wrap.typeToTextBox(BaseProject.driver, value[i], locator);
					wrap.type(BaseProject.driver, value[i], locator);
					Thread.sleep(2000);
					wrap.elementTabOut(BaseProject.driver, locator);
					Thread.sleep(2000);
					//wrap.screenShot(BaseProject.driver, screenShotPath_Negative+"\\NegativeInputs", field+i);
					Thread.sleep(2000);

					errorMsgCheck = wrap.isElementPresent(BaseProject.driver,locator 
							+"/..//span[@role=\'alert\']");
					logger.info("Is error message is displayed : " + String.valueOf(errorMsgCheck));

					if(errorMsgCheck==true)
					{
						String neg_path = locator+"/..//span[@role=\'alert\']";
						logger.info("Negative validation of given element xpath is : "+ neg_path);
						logger.info("The error message of an given element is : "+ wrap.getTextValue(BaseProject.driver, neg_path));
					}

				}

				wrap.click(BaseProject.driver, locator);
				wrap.elementTabOut(BaseProject.driver, locator);
				errorMsgCheck = errorMsgCheck && wrap.isElementPresent(BaseProject.driver,locator 
						+"/..//span[@role=\'alert\']");
				logger.info("Is error message is displayed for just click and tabout from an element : " + String.valueOf(errorMsgCheck));
				if(errorMsgCheck==true)
				{
					String neg_path = locator+"/..//span[@role=\'alert\']";
					logger.info("Negative validation of given element xpath is : "+ neg_path);
					logger.info("The error message of an given element is : "+ wrap.getTextValue(BaseProject.driver, neg_path));
				}

			}

			else 
			{
				logger.info("Element is not present in the screen");
			}

		}

	}

	public static void validateFieldSV(String fieldName,String locator, String dataformat, String dataType, String length, String moc,String displayEditable,String derived) throws IOException, InterruptedException{

		String tabResult="NA";
		String sectionResult="NA";
		String editableResult="NA";
		String dataTypeResult="NA";
		String dataFormatResult="NA";
		String singleMultiResult="NA";
		String mandatoryResult="NA";
		String fieldLengthResult="NA";
		String derivedResult="NA";


		try {
			FullDataMaker.propertiesFilename="Signature_Verification";

			logger.info("Validations for Field :"+fieldName);

			if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator))){

				logger.info("Field is present in the screen");

				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties(FullDataMaker.propertiesFilename, locator)));               

				// wrap.screenShot(BaseProject.driver, screenShotPath, fieldName);

				//              tabResult = String.valueOf(wrap.verifyTabName(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), tab));
				//                    
				//                    logger.info("***** Tab matched : "+tabResult+" *****");
				//                    
				//                    sectionResult = String.valueOf(wrap.verifySectionName(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), section));
				//                    
				//                    logger.info("***** Section matched : "+sectionResult+" *****");
				//                    
				editableResult = String.valueOf(wrap.editableFieldCheck(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),displayEditable));

				logger.info("***** Editable Check : "+    editableResult+" *****");

				//                    singleMultiResult = String.valueOf(wrap.validateSingleMultiple(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), singlemulti,fieldName));
				//                    
				//                    logger.info("***** SINGLE/MULTIPLE matched : "+singleMultiResult+" *****");

				derivedResult = String.valueOf(wrap.derivedVal(BaseProject.driver,com.getElementProperties(FullDataMaker.propertiesFilename, locator),derived));

				logger.info("***** Derived Check : "+derivedResult+" *****");

				if(displayEditable.equalsIgnoreCase("Editable")){

					dataTypeResult = String.valueOf(wrap.fieldObjectTypeVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), dataType));

					logger.info("***** DataType matched : "+dataTypeResult+" *****");

					dataFormatResult = String.valueOf(wrap.dataTypeVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator), dataformat));

					logger.info("***** DataFormat matched : "+dataFormatResult+" *****");

					mandatoryResult = String.valueOf(wrap.isMandatoryField(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),moc));

					logger.info("***** Mandatory Check : "+mandatoryResult+" *****");

					if(!dataType.equalsIgnoreCase("Dropdown")){

						fieldLengthResult = String.valueOf(wrap.fieldLenghtVal(BaseProject.driver, com.getElementProperties(FullDataMaker.propertiesFilename, locator),length,dataType));

						logger.info("***** FieldLength matched : "+fieldLengthResult+" *****");

					}

				}

			}

			else{

				logger.info("Field is not present in the screen");
			}

		}
		catch(Exception E){
			logger.info("FAIL - Field Validation failed");
			E.printStackTrace();
		}

		BaseProject.reportFieldVals.add(fieldName+","+tabResult+","+sectionResult+","+editableResult+","+dataTypeResult+","+dataFormatResult+","+
				singleMultiResult+","+mandatoryResult+","+fieldLengthResult+","+derivedResult);

		/*System.out.println(tabResult+":"+sectionResult+":"+editableResult+":"+dataTypeResult+":"+dataFormatResult+":"+
                                  singleMultiResult+":"+mandatoryResult+":"+fieldLengthResult+":"+derivedResult);*/


	}


}
