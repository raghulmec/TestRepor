package com.scb.rtob.module.test.framework.glue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class FraudRiskChecker {
	
	public static Logger logger = Logger.getLogger(SignatureVerification.class);
	
	static CommonUtils utils= new CommonUtils(); 
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static List<String> uploadDoc = new ArrayList<String>();
	public static List<String> primaryUploadDoc = new ArrayList<String>();
	public static List<String> coAppUploadDoc = new ArrayList<String>();
	
	public static void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();
		// Thread.sleep(10000);
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1; 
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last);
	}
	

		@Given("^Go to Fraud Risk Checker WB home page$")
	    public void gotoFraudRiskCheckerWBHomePage() throws Throwable {

	        wrap.switch_to_default_Content(BaseProject.driver);

	        try {
	            wrap.click(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "work_basket_option"));
	            wrap.click(BaseProject.driver, com.getElementProperties("Signature_Verification", "seeall_option"));
	            wrap.getWorkbasketoption(BaseProject.driver, "Fraud Risk Checker");
	            wrap.click(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "modal_submit_button"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
	        
	        @Then("^FraudRiskChecker: select an application number$")
		    public static void selectAnApplicationNumber()
		            throws IOException, InterruptedException, ClassNotFoundException, SQLException {

			       /*DBUtils.convertDBtoMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
		           String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);*/
		        wrap.wait(5000);
			  
	           
		        String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);

		        BaseProject.appId = appId.trim();

		        logger.info("The Value going to select or Filter is [" + appId + "]");
		        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		        //wrap.wait(2000);
		        String filter = com.getElementProperties("FraudRiskChecker","filter_link");
		        String search = com.getElementProperties("FraudRiskChecker","search_text");
		        String apply_button = com.getElementProperties("FraudRiskChecker","apply_button");
		        //wrap.wait(2000);
		        wrap.click(BaseProject.driver, filter);
		        //wrap.wait(1000);
		        wrap.typeToTextBox(BaseProject.driver, appId, search);
		       // wrap.wait(1000);
		        wrap.click(BaseProject.driver, apply_button);
		 
	            switchFrame();

		       // wrap.wait(3000);

		        try {
		            BaseProject.driver.findElement(By.xpath("//div[@id='HARNESS_CONTENT']//table/tbody/tr[1]/td/div/table/tbody/tr[2]/td/div/span[text()='" + appId + "']")).click();
		        } catch (Exception e) {
		            BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
		        }
		   }
	        
	        @Then("^FraudRiskChecker: Move to Document Details tab$")
	        public void GotoDocumentDetailssection() throws Throwable{
	        	
	        	switchFrame();
	        	int rows_count,col_count;
	        	String cellText = null;
	        	
	        	//To read the number of rows in document details tab
	        	
	        	List<WebElement> row_count = BaseProject.driver.findElements(By.xpath("//table[@pl_prop='.FraudRiskVerificationList']/tbody/tr"));
	        	logger.info("Rowcount"+row_count.size());
	        	
	        	//To read the Document type values
	        	
	        	List<WebElement> column_count = BaseProject.driver.findElements(By.xpath("//table[@pl_prop='.FraudRiskVerificationList']/tbody/tr/td[@data-attribute-name='Document type']"));
	        	  		for(WebElement ele_col:column_count){
	        			logger.info("data"+ele_col.getText());	        			      			
	        			}
	        	  		
	        	
	        	List<WebElement> Screenedstatus = BaseProject.driver.findElements(By.xpath("//table[@pl_prop='.FraudRiskVerificationList']/tbody/tr/td[@data-attribute-name='Screened Status']"));
	        	 
	        	for(int i=1;i<Screenedstatus.size();i++)
	        	{
	        		WebElement ele_sampled=BaseProject.driver.findElement(By.xpath("(//select[contains(@id,'ScreenedStatus')])["+i+"]"));
	        		Select selectBox = new Select(ele_sampled);
	        		selectBox.selectByVisibleText("Sampled");
	        		WebElement sample=selectBox.getFirstSelectedOption();
	        		String screen_value=sample.getText();
		        	logger.info("Screenstatus"+screen_value);
		      
		        	wrap.wait(10000);
		        	
		        	if(screen_value.equals("Sampled")){
		        		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		                jse.executeScript("arguments[0].scrollIntoView(true);", ele_sampled);
		        		
		        		WebElement ele_status=BaseProject.driver.findElement(By.xpath("(//table[@pl_prop='.FraudRiskVerificationList']/tbody/tr/td[@data-attribute-name='Verification Method']//select[contains(@id,'VerifyMethod')])["+i+"]"));
		        		Select selectBox1 = new Select(ele_status);
		        		selectBox.selectByVisibleText("Internal");
		        		
		        		
//		        		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "Verification_Method"), "Internal", "BYVISIBLETEXT");
		        		wrap.wait(4000);
	        	}
	        	}
		     
		        	
		        	
//	        	for(WebElement ele_col1:Screenedstatus){
//	        	
//	        	wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "Screened_Status"), "Sampled", "BYVISIBLETEXT");
//	        	wrap.wait(2000);
//	        	WebElement Screenstatus=wrap.getElement(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "Screened_Status"));
//	        	 //String screen_value = Screenstatus.getText();
//	        	//wrap.verifyTextByXPath(BaseProject.driver,Screen_status,"Screened Status");
//	        	
//	        	Select selectBox = new Select(Screenstatus);
//                
//	        	WebElement sample=selectBox.getFirstSelectedOption();
//	        	String screen_value = sample.getText();
//	        	logger.info("Screenstatus"+screen_value);
//	      
//	        	wrap.wait(2000);
//	        	if(screen_value.equals("Sampled")){
//	        		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("FraudRiskChecker", "Verification_Method"), "Internal", "BYVISIBLETEXT");
//	        		wrap.wait(4000);
//	        	}
//	     	
	        }
	       	
	        
	        @Then("^FraudRiskChecker: Compare FullName$")
	  	     public void compareFullName()throws Throwable{
	        	
	        	switchFrame();
	        	
	        	String customer_details = com.getElementProperties("FraudRiskchecker","Customerdetails_tab");
	            wrap.click(BaseProject.driver, customer_details); 
	            
	        	String FullName_customer=BaseProject.driver.findElement(By.xpath("//div[@class='sectionDivStyle'][@node_name='BasicInfo']//span[text()='Full name']//parent::span/following-sibling::div//span")).getText();
	        	logger.info("Full Nme:"+FullName_customer);	
	        	
	        	String Fraudrisk_details = com.getElementProperties("FraudRiskchecker","FraudRiskCheck");
	            wrap.click(BaseProject.driver, Fraudrisk_details);	        	
	        	
	        	String FullName_fraudrisk=BaseProject.driver.findElement(By.xpath("//div[@class='sectionDivStyle'][@node_name='ApplicantSummary']//span[text()='Full Name']//parent::span/following-sibling::div//span")).getText();
	        	logger.info("Full Nme:"+FullName_fraudrisk);
	        	
	        	if(FullName_customer.equals(FullName_fraudrisk)){
	        		logger.info("Full Name matched");
	        	}else{
	        		logger.info("Full Name not matched");
	        	}        	       	       
	        	
//	        	String FullName_customer = com.getElementProperties("FraudRiskchecker", "Customerdetails_Fullname_xpath");
//	        	logger.info("Full Nme:"+FullName_customer);
//	        	String FullName_cust = wrap.getExactAttribute(BaseProject.driver,FullName_customer).getAttribute("value");
//	            logger.info("Selected FullName is: " + FullName_cust);  
	            
	                         		        
	        }
	        
	        @Then("^FraudRiskChecker: Compare Product code$")
	  	     public void compareProductcode()throws Throwable{
	        	
	        	switchFrame();
	        	
	        	String product_details = com.getElementProperties("FraudRiskchecker","Productdetails_tab");
	            wrap.click(BaseProject.driver, product_details); 
	            
	        	String productcode_customer=BaseProject.driver.findElement(By.xpath("//div[@class='sectionDivStyle'][@node_name='ProdInfoProductDetails']//span[text()='ProductCode']//parent::span/following-sibling::div//span")).getText();
	        	logger.info("productcode_customer:"+productcode_customer);	
	        	
	        	String Fraudrisk_details1 = com.getElementProperties("FraudRiskchecker","FraudRiskCheck");
	            wrap.click(BaseProject.driver, Fraudrisk_details1);	        	
	        	
	        	String productcode_fraudrisk=BaseProject.driver.findElement(By.xpath("//tr[@id='$PRequestedProduct$ppxResults$l1']/td[@data-attribute-name='Requested Product']")).getText();
	        	logger.info("Full Nmeproductcode_fraudrisk:"+productcode_fraudrisk);
	        	
	        	if(productcode_customer.contains(productcode_fraudrisk)){
	        		logger.info("Product code matched");
	        	}else{
	        		logger.info("Product code not matched");
	        	}
	               
	        }
	        
	        @Then("^FraudRiskChecker: check whether the customer is ETB/NTB$")
	  	     public void isETBNTB()throws Throwable{
	        	
	        	String ETB_NTB=BaseProject.driver.findElement(By.xpath("//div[@class='sectionDivStyle'][@node_name='ApplicantSummary']//span[text()='ETB/NTB']//parent::span/following-sibling::div//span")).getText();
	        	logger.info("Customer is ETB or NTB:"+ETB_NTB);
	        }
	        
	        }
	    