package com.scb.rtob.module.test.framework.glue;

/***************************************************************************************
Project Name: RTOB
Author: Ganga
Version: V 1.0
Date of Creation: 22 Jan 2018
Modified By:Ganga
 ***************************************************************************************/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.framework.glue.BaseProject;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;
import com.standardchartered.genie.parser.operation.ConcatenateOperation;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MEDDReviewer {

	public static Logger logger = Logger.getLogger(MEDDReviewer.class);
	File file;
	Properties CONFIG ;

	public static WebDriver driver=BaseProject.driver;
	static CommonUtils utils= new CommonUtils();

	public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
	//public static String BaseProject.scenarioID = BaseProject.scenarioID;

	public static String excelValue = BaseProject.scenarioID;

	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";

	//public static List<HashMap<String, String>> exceldata = new ArrayList<HashMap<String, String>>();
	public static LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();

	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();

	public static String propertiesFilename = "MEDDReviewer";


	@Given("^Go to MEDD Reviewer home page$")
	public void Navigate_to_MEDD()
	{
		wrap.switch_to_default_Content(BaseProject.driver);

		try {
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
			wrap.getWorkbasketoption(BaseProject.driver, "MEDD Reviewer");
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	@Then("^MEDD Reviewer: select an application number$")
	public static void select_application_number()
			throws IOException, InterruptedException, ClassNotFoundException, SQLException {
		wrap.wait(5000);
		logger.info(BaseProject.scenarioID);
		String appId = DBUtils.readColumnWithRowID("Application_ID", BaseProject.scenarioID);
		logger.info("The Value going to select or Filter is ["+appId+"]");

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		wrap.wait(2000);		
		String filter = com.getElementProperties("Fulldatacapturemaker",
				"filter_link");
		String search = com.getElementProperties("Fulldatacapturemaker",
				"search_text");
		String apply_button = com.getElementProperties("Fulldatacapturemaker",
				"apply_button");
		wrap.click(BaseProject.driver, filter);
		wrap.wait(1000);
		wrap.typeToTextBox(BaseProject.driver, appId, search);
		wrap.wait(1000);
		wrap.click(BaseProject.driver, apply_button);

		wrap.wait(10000);

		WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
		((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
		BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();

	}

	@When("^MEDDReviewer: Choose residence verification required$")
	public void select_residence_verification() throws IOException, InterruptedException{
		wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
		String varificationYes = com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ResidenceVerificationYes");
		String varificationNo = com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ResidenceVerificationNo");
		String VerificationRequired = DBUtils.readColumnWithRowID("VerificationRequired", BaseProject.scenarioID);
		if(VerificationRequired.equalsIgnoreCase("Yes"))
		{
			wrap.click(driver, varificationYes);
		}else if(VerificationRequired.equalsIgnoreCase("No"))
		{
			wrap.click(driver, varificationNo);
		}
	}


	@Given("^MEDDReviewer: Fill Residence Verification in Customer Details tab$")
	public void fill_residence_verification() throws IOException, InterruptedException{

		FullDataMakerUtils.switchToCustomerDetailsTab();
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("MEDDReviewer","verificationRequiredYes")));
		wrap.click(BaseProject.driver, com.getElementProperties("MEDDReviewer","verificationRequiredYes"));
	}

	@When("^MEDDReviewer: Application moved to Exception Reviewer workbasket$")
	public void application_move_to_CDD_reviewer_workbasket() throws IOException, InterruptedException{
		wrap.switch_to_default_Content(BaseProject.driver);

		try {
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
			wrap.getWorkbasketoption(BaseProject.driver, "Exception Reviewer");
			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
			select_application_number();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	@When("^MEDDReviewer: Submit the application in MEDD Reviewer$")
	public void submit_the_application_in_MEDD_reviewer() throws IOException, InterruptedException{

		String action_dropdown = com.getElementProperties("MEDDReviewer", "Actions_DropDown");
		String cancel_button = com.getElementProperties("MEDDReviewer", "Cancel");
		String remarks = com.getElementProperties("MEDDReviewer", "Comments");
		String Submit_button = com.getElementProperties("MEDDReviewer", "Submit");

		String actionValue = DBUtils.readColumnWithRowID("Action", BaseProject.scenarioID);
		String remarksValue = DBUtils.readColumnWithRowID("Remarks", BaseProject.scenarioID);

		if(actionValue.equalsIgnoreCase("Confirm"))
		{	
			wrap.selectFromDropDown(driver, action_dropdown, actionValue, "BYVISIBLETEXT");

		}else if(actionValue.equalsIgnoreCase("Refer to RM"))
		{
			wrap.selectFromDropDown(driver, action_dropdown, actionValue, "BYVISIBLETEXT");
		}		
		if(!remarksValue.equalsIgnoreCase("null"))
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			wrap.type(driver, remarksValue, remarks);
		}
		wrap.click(driver, Submit_button);
	}

	public  void switchFrame() throws InterruptedException {
		int Last = 0;
		Thread.sleep(500);
		driver.switchTo().defaultContent();
		Thread.sleep(500);
		List<WebElement> frames = driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		logger.info(Last);
		driver.switchTo().frame(Last);
		Thread.sleep(500);
	}

	@When("^MEDDReviewer: application search after submit the application$")
	public void verify_Workbasket_in_application_search_after_submit_application() throws Throwable
	{
		String search_link=com.getElementProperties("BasicData", "Search_link_XPATH");
		String ApplicationNo=com.getElementProperties("BasicData", "Application_ID");
		String serach_button=com.getElementProperties("BasicData", "Search_Button_XPATH");
		String moreInfo=com.getElementProperties("BasicData", "More_Info_XPATH");
		driver.switchTo().defaultContent();
		Thread.sleep(500);
		wrap.click(driver, search_link);

		switchFrame();
		Thread.sleep(500);
		wrap.type(driver,BaseProject.appId, ApplicationNo);
		wrap.click(driver, serach_button);
		Thread.sleep(500);
		wrap.click(driver, moreInfo);
		Thread.sleep(500);
		switchFrame();
		Thread.sleep(500);


		WebElement table = driver.findElement(By.xpath("//table[@id='bodyTbl_right']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));

		for (WebElement row : rows) {

			List<WebElement> cells = row.findElements(By.tagName("td"));

			for (WebElement cell : cells) {

				if (!cell.getText().contains("MEDD Reviewer"))

				{
					logger.info("Expected: MEDD Reviewer is not available in Application Search");
				}
				else
				{
					logger.info("MEDD Reviewer is still available in Application Search");
				}

			}
		}
	}

	/*	@When("^Logout the application$")
	public void logout() throws IOException, InterruptedException
	{
		boolean visi_logout=false;
		wrap.switch_to_default_Content(driver);
		visi_logout = wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).isDisplayed();
		if (visi_logout==true)
		{
			wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).click();
			logger.info("User logged out successfully");
			Thread.sleep(500);

		}

	}*/

	@And("^connect to DB and fetch MEDD dataset$")
	public static void load_MEDD_dataset() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("meddquery");
	}

	/*@And("^connect to DB and fetch BasicDataCapture dataset$")
	public static void loadBasicDataCaptureTable() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("bdquery");
	}


	@And("^connect to DB and fetch FullDataCapture dataset$")
	public static void loadFullDataCaptureTable() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("fdquery");
	}*/

	@Then("^MEDD Reviewer : Validate Field '(.+)'$")
	public  void validate_field_using_CSV(String FieldName) throws Throwable{

		logger.info("Going to switch into frame");

		switchFrame();

		logger.info("Frame switched successfully");

		BaseProject.propertiesFilename = "MEDDReviewer";
		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"MEDDReviewerFieldValidation.csv");
		try{

			if(!(Fieldval[0]).equalsIgnoreCase(null)){
				logger.info("Field validation starts"); 
				CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
			}
		}
		catch(Exception E){

			logger.info("Field : "+FieldName+" is not present in Datamodel");
		}   
	}
	
	/*public  void validateFieldStep(String FieldName) throws IOException, InterruptedException{

		wrap.wait(1000);

		logger.info("Going to scroll");

		//innerScroll();

		//switchFrame();
		BaseProject.propertiesFilename = "MEDDReviewer";

		CommonUtilsData.FieldNameData = FieldName;

		CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","MEDDReviewer");

		try{

			if(!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)){

				CommonUtils.validateField(
						CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
						CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

			}
		}

		catch(Exception E){

			logger.info("Field : "+FieldName+" is not present in Datamodel");
		}             

	}*/

	@Then("^MEDD Reviewer :Click on '(.+)' tab$")
	public void click_details_tab(String tabName)
	{
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		try {
			if(tabName.equalsIgnoreCase("CustomerDetails"))
			{
				wrap.click(driver, com.getElementProperties("MEDDReviewer", "CustomerDetails_Tab"));
			}
			if(tabName.equalsIgnoreCase("ProductDetails"))
			{
				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("scroll(0, -250);");
				wrap.click(driver, com.getElementProperties("MEDDReviewer", "ProductDetails_Tab"));
			}
			else if (tabName.equalsIgnoreCase("ApplicationDetails"))
			{
				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("scroll(0, -250);");
				wrap.click(driver, com.getElementProperties("MEDDReviewer", "ApplicationDetails_Tab"));
			} else if (tabName.equalsIgnoreCase("Documents"))
			{
				JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
				jse.executeScript("scroll(0, -250);");
				wrap.click(driver, com.getElementProperties("MEDDReviewer", "Documents_Tab"));
			}

		} catch (InterruptedException |IOException e) {
			logger.error("unable to click on "+tabName +"tab"+ e);
			Assert.fail();
		} 
	}

	public void innerScroll()
	{
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(driver);

		for(int j=0; j<8; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_DOWN).sendKeys(Keys.DOWN).build().perform();
		}
		try {
			wrap.wait(500);
		} catch (InterruptedException e) {
			logger.error("Failed to scroll page");
		}
	}

	@When("^MEDD Reviewer :validate prefilled values in product details tab")
	public void validate_prefilled_product_details_tab()
			throws Throwable {

		switchFrame();
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_CampaignCode"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_ProductCode"), DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_FundAccountChoice"), DBUtils.readColumnWithRowID("Fund_Account_Choice", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_Amount"), DBUtils.readColumnWithRowID("Deposit_Amount", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_PurposeofAccountOpening"), DBUtils.readColumnWithRowID("Purpose_of_account_opening", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_AccountRequestType"), DBUtils.readColumnWithRowID("Account_Request_Type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_AccountCurrency"), DBUtils.readColumnWithRowID("Account_Currency_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_OperatingInstruction"), DBUtils.readColumnWithRowID("Constitution_Code", BaseProject.scenarioID));
		String firstName = DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID);
		String middleName = DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID);
		String lastName= DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID);
		String accountShortName = firstName+middleName+lastName;
		logger.info("Expected account short name is : " + accountShortName);
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_AccountShortName"),accountShortName);
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_StatementType"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_Relationshiptype"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ProductDetailsTab_Customer"), DBUtils.readColumnWithRowID("Customer_Name", BaseProject.scenarioID));	 
	}


	@When("^MEDD Reviewer :validate prefilled values in customer details tab")
	public void validate_prefilled_customer_details_tab()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Customer_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Address1_Address_Type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Address1_Address_Line1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address1_Address_Line2", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address1_Address_Line3", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Address1_State", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Address1_City", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Address1_Zip_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Address1_Country", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MailingAddressIndicator"), DBUtils.readColumnWithRowID("Address1_Mailing_Address_Indicator", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("COntact_type_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Contact_Details", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_IsIndicateOfSanctionedCountry"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_NTBNonResidentIndividuals"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_IsBusinessPurpose"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ClientWishesAnonymity"), DBUtils.readColumnWithRowID("Client_wishes_anonymity_numbered_accountPrepassbook", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_IsAUMCriteria"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_DeticaResponse"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_OtherRiskFactors"), DBUtils.readColumnWithRowID("Other_risk_factorsPre_Local_RegulationsPre_Stringent_rules_applied_in_country", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_IsAlreadyEDDMEDD"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ListOfProductsOpened"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_IsCDDDeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CountryCDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_VerificationRequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_NorkomName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));       
	}

	@When("^MEDD Reviewer :validate prefilled values in application details tab")
	public void validate_prefilled_application_details_tab()
			throws Throwable {

		switchFrame();
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_SourcingID"), DBUtils.readColumnWithRowID("Sorucing_ID", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_ReferralID"), DBUtils.readColumnWithRowID("Referral_ID", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_AcquisitionChannel"), DBUtils.readColumnWithRowID("Acquisition_Channel", BaseProject.scenarioID));
		// wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_HomeBranch"), DBUtils.readColumnWithRowID("Home_Branch", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_InstitutionClassificationCode"), DBUtils.readColumnWithRowID("Institution_Classification_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "ApplicationDetailsTab_ServiceIndicatorCode"), DBUtils.readColumnWithRowID("Service_Indicator_Code", BaseProject.scenarioID));
		String firstName = DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID);
		String middleName = DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID);
		String lastName= DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID);
		String accountShortName = firstName+middleName+lastName;
		logger.info("Expected account short name is : " + accountShortName);
	}


	@When("^MEDD Reviewer :validate prefilled values in document details tab")
	public void validate_prefilled_document_details_tab()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Document_Category", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Name_of_the_Document", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Document_Number", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Document_Expiry_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Document_Signatory_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countries_of_Tax_Residence", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_CRSReasonCode"), DBUtils.readColumnWithRowID("CRS_Reason_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));

	}

	@When("^MEDD Reviewer :Click OK alert message")
	public void click_ok_alert_message(){

		wrap.switch_to_alert_dismiss("accept");
	}

	@When("^MEDD Reviewer :Validate error message for the field(.*)")
	public void validate_error_message_for_the_field(String fieldName) throws IOException, InterruptedException{
		String expectedError = "Value cannot be blank";
		String actualError = null;

		if(fieldName.contains("CDD Performed")){
			JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_CDD_Performed_Error_Message")));
			actualError=wrap.getTextValue(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_CDD_Performed_Error_Message"));	 
		}

		if(fieldName.contains("Country CDD Performed")){
			JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_Country_CDD_Performed_Error_Message")));
			actualError=wrap.getTextValue(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_Country_CDD_Performed_Error_Message"));	 
		}

		if(fieldName.contains("Verification Required")){
			JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_Verification_Required_Error_Message")));
			actualError=wrap.getTextValue(BaseProject.driver,com.getElementProperties("MEDDReviewer","CustomerDetailsTab_Verification_Required_Error_Message"));	 
		}


		System.out.println("Expected error message is = "+expectedError);
		System.out.println("Actual error message is = "+actualError);
		Assert.assertEquals(expectedError, actualError);

	}

	@Then("^MEDD Reviewer :Click on Co-Applicant1 tab$")
	public void click_on_coapplicant1_tab( ) throws InterruptedException, IOException
	{
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

		wrap.click(driver, com.getElementProperties("MEDDReviewer", "CustomerDetails_CoApplicant1Tab"));

	}

	@When("^MEDD Reviewer :validate prefilled values in customer details tab Co-Applicant1")
	public void validate_prefilled_customer_details_tab_coapplicant1()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Customer_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Address1_Address_Type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Address1_Address_Line1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address1_Address_Line2", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address1_Address_Line3", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Address1_State", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Address1_City", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Address1_Zip_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Address1_Country", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MailingAddressIndicator"), DBUtils.readColumnWithRowID("Address1_Mailing_Address_Indicator", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("COntact_type_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Contact_Details", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsIndicateOfSanctionedCountry"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_NTBNonResidentIndividuals"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsBusinessPurpose"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ClientWishesAnonymity"), DBUtils.readColumnWithRowID("Client_wishes_anonymity_numbered_accountPrepassbook1", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsAUMCriteria"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_DeticaResponse"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_OtherRiskFactors"), DBUtils.readColumnWithRowID("Other_risk_factorsPre_Local_RegulationsPre_Stringent_rules_applied_in_country1", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsAlreadyEDDMEDD"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ListOfProductsOpened"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_IsCDDDeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_NoOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AmountOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_VerificationRequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_NorkomName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));       

	}

	@When("^MEDD Reviewer :validate prefilled values in document details tab Co-Applicant1")
	public void validate_prefilled_document_details_tab_coapplicant1()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Document_Category", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Name_of_the_Document", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Document_Number", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Document_Expiry_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Document_Signatory_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countries_of_Tax_Residence", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_CRSReasonCode"), DBUtils.readColumnWithRowID("CRS_Reason_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant1_DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));
	}

	@Then("^MEDD Reviewer :Click on Co-Applicant2 tab$")
	public void click_on_coapplicant2_tab( ) throws InterruptedException, IOException
	{
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

		wrap.click(driver, com.getElementProperties("MEDDReviewer", "CustomerDetails_CoApplicant2Tab"));

	}

	@When("^MEDD Reviewer :validate prefilled values in customer details tab Co-Applicant2")
	public void validate_prefilled_customer_details_tab_coapplicant2()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ProfileType"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_RelationTypeCode"), DBUtils.readColumnWithRowID("Relationship_type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_FirstName"), DBUtils.readColumnWithRowID("First_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MiddleName"), DBUtils.readColumnWithRowID("Middle_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_LastName"), DBUtils.readColumnWithRowID("Last_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_FullName"), DBUtils.readColumnWithRowID("Customer_Name", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_DateofBirth"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_Gender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressType"), DBUtils.readColumnWithRowID("Address1_Address_Type", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine1"), DBUtils.readColumnWithRowID("Address1_Address_Line1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine2"), DBUtils.readColumnWithRowID("Address1_Address_Line2", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AddressLine3"), DBUtils.readColumnWithRowID("Address1_Address_Line3", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_State"), DBUtils.readColumnWithRowID("Address1_State", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_City"), DBUtils.readColumnWithRowID("Address1_City", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ZipCode"), DBUtils.readColumnWithRowID("Address1_Zip_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_Country"), DBUtils.readColumnWithRowID("Address1_Country", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MailingAddressIndicator"), DBUtils.readColumnWithRowID("Address1_Mailing_Address_Indicator", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_Contacttype"), DBUtils.readColumnWithRowID("COntact_type_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ContactDetails"), DBUtils.readColumnWithRowID("Contact_Details", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_InternalRemarksDetails"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_FirstNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MiddleNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_LastNamePanInfo"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryofAccountOpening"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_Nationality"), DBUtils.readColumnWithRowID("Nationality_Code1", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryofResidence"), DBUtils.readColumnWithRowID("Residence_Country_Code", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsIndicateOfSanctionedCountry"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_NTBNonResidentIndividuals"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsBusinessPurpose"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ClientWishesAnonymity"), DBUtils.readColumnWithRowID("Client_wishes_anonymity_numbered_accountPrepassbook2", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsAUMCriteria"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_DeticaResponse"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_OtherRiskFactors"), DBUtils.readColumnWithRowID("Other_risk_factorsPre_Local_RegulationsPre_Stringent_rules_applied_in_country2", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsAlreadyEDDMEDD"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ListOfProductsOpened"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_IsCDDDeficient"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryCDDPerformed"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDStatus"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDRiskCode"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_CountryCDDLastReviewedDate"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_NoOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		//			wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AmountOfTransactions"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MISCode"), DBUtils.readColumnWithRowID("MIS_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MISValue"), DBUtils.readColumnWithRowID("MIS_Value", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_VerificationRequired"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_NorkomName"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_TotalMatches"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_MatchResult"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_AlertId"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_CustomerDetailsTab_ResultMessage"), DBUtils.readColumnWithRowID("", BaseProject.scenarioID));       

	}

	@When("^MEDD Reviewer :validate prefilled values in document details tab Co-Applicant2")
	public void validate_prefilled_document_details_tab_coapplicant2()
			throws Throwable {

		switchFrame();

		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_DocumentCategory"), DBUtils.readColumnWithRowID("Document_Category", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_NameoftheDocument"), DBUtils.readColumnWithRowID("Name_of_the_Document", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_DocumentNumber"), DBUtils.readColumnWithRowID("Document_Number", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_DocumentExpiryDate"), DBUtils.readColumnWithRowID("Document_Expiry_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_DocumentSignatoryDate"), DBUtils.readColumnWithRowID("Document_Signatory_Date", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_Country(ies)ofTaxResidence"), DBUtils.readColumnWithRowID("Countries_of_Tax_Residence", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_CRSReasonCode"), DBUtils.readColumnWithRowID("CRS_Reason_Code", BaseProject.scenarioID));
		wrap.validatevalue(BaseProject.driver, com.getElementProperties("MEDDReviewer", "Co-Applicant2_DocumentsTab_CRSComments"), DBUtils.readColumnWithRowID("CRS_Comments", BaseProject.scenarioID));
	}

}



