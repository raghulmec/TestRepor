package com.scb.rtob.module.test.framework.glue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CDDException {

	public static WebDriver driver = BaseProject.driver;
	public static Wrapper wrap = new Wrapper();
	public static Commons com = new Commons();
	public static Logger logger = Logger.getLogger(CDDException.class);
	static CommonUtils utils= new CommonUtils();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static WebDriverWait wait = new WebDriverWait(driver, 30);

	@Given("^CDD: Go to CDD Exception$")
    public void Go_to_Basic_Data_Capture_home_page() throws Throwable {


        wrap.switch_to_default_Content(BaseProject.driver);


        wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
        wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));


        wrap.getWorkbasketoption(BaseProject.driver,"CDD Exception");

        wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));


    }

	@When("^CDDOAT: Verify CDD OAT Inforamtion header display and country of account opening$")
	public void verify_CDD_OAT_Information_header_display() throws IOException, InterruptedException{
		
		//wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
		System.out.println("Reading excel sheet");
		System.out.println(BaseProject.scenarioID);
		String CDD_OAT_Header = com.getElementProperties("CDDException", "CDD_OAT_Information_header");
		String CDD_OAT_country_of_account_opening = com.getElementProperties("CDDException", "CDD_OAT_CountryOF_AccountOpening");
		String CDD_OAT_country_of_account_opening_text = com.getElementProperties("CDDException", "CDD_OAT_CountryOF_AccountOpening_text");
		String CDD_OAT_CountryOf_Account_Opening_value = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Account_opening_value");
		//String CDD_OAT_Country_Value_Non_editable = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_accountOpening_value_nonEdit");

		switchFrame();
		
		com.validateFiledVisible1(BaseProject.driver, CDD_OAT_Header);

			if(wrap.getElement(BaseProject.driver, CDD_OAT_Header).isDisplayed()){

				wrap.click(BaseProject.driver, CDD_OAT_country_of_account_opening);
				com.validateFiledVisible1(BaseProject.driver, CDD_OAT_country_of_account_opening);

				if(wrap.getElement(BaseProject.driver, CDD_OAT_CountryOf_Account_Opening_value).isDisplayed()){
					com.validateFiledVisible1(BaseProject.driver, CDD_OAT_country_of_account_opening_text);
					com.validateFiledVisible1(BaseProject.driver, CDD_OAT_CountryOf_Account_Opening_value);


					if(wrap.getElement(BaseProject.driver, CDD_OAT_CountryOf_Account_Opening_value).getAttribute("value").equalsIgnoreCase("IN")){
						logger.info(wrap.getElement(BaseProject.driver, CDD_OAT_CountryOf_Account_Opening_value).getAttribute("value"));
					}
				}
			}

	}
	@When("^CDDOAT: Verify CDD OAT Country Check$")
	public void verify_CDD_OAT_Country_Check() throws IOException, InterruptedException{
		
		switchFrame();

		String country_check = com.getElementProperties("CDDException", "CDD_OAT_Country_Check");
		String CountryCheck_Nationality = com.getElementProperties("CDDException", "CDD_OAT_Nationalities_nationalities");
		String country_check_nationality_value = com.getElementProperties("CDDException", "CDD_OAT_Nationalities_nationalities_value");
		String country_check_alert_Message = com.getElementProperties("CDDException", "CDD_OAT_Country_check_Nationality_AlertMessage");
		String sanctioned_prohibited_text = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_prohibited_text");
		String sanctioned_prohibited_text_yes = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_prohibited_text_yes");
		String sanctioned_prohibited_text_no = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_prohibited_text_No");
		String Sanctioned_prohibited_text_Alert = com.getElementProperties("CDDException", "CDD_OAT_Sanctioned_prohibited_Alert");

		//CR Change
		String country_check_nationality_value_cr_change = com.getElementProperties("CDDException", "country_check_Nationality_Value_Change");



		com.validateFiledVisible1(BaseProject.driver, country_check);
		com.validateFiledVisible1(BaseProject.driver, CountryCheck_Nationality);
		com.validateFiledVisible1(BaseProject.driver, country_check_nationality_value_cr_change);


			if(wrap.getElement(BaseProject.driver, country_check).isDisplayed()){
				
				wrap.click(BaseProject.driver, country_check_nationality_value_cr_change);
				Thread.sleep(1000);
				String countryCheck = wrap.getElement(BaseProject.driver, country_check_nationality_value_cr_change).getText();
				
				logger.info(countryCheck);
				if(countryCheck.equalsIgnoreCase("CUB")||countryCheck.equalsIgnoreCase("PRK")||countryCheck.equalsIgnoreCase("IRN")||countryCheck.equalsIgnoreCase("SDN")||countryCheck.equalsIgnoreCase("SYR")||countryCheck.equalsIgnoreCase("ATG")||countryCheck.equalsIgnoreCase("DMA")||countryCheck.equalsIgnoreCase("HKG")||countryCheck.equalsIgnoreCase("KOR")||countryCheck.equalsIgnoreCase("KNA")){

					com.validateFiledVisible1(BaseProject.driver, country_check_alert_Message);
					if(wrap.getElement(BaseProject.driver, sanctioned_prohibited_text).isDisplayed()){
						wrap.click(BaseProject.driver, sanctioned_prohibited_text_no);
                        wrap.wait(1500);
						com.validateFiledVisible1(BaseProject.driver, Sanctioned_prohibited_text_Alert);
						if(wrap.getElement(BaseProject.driver, Sanctioned_prohibited_text_Alert).isDisplayed()){
							logger.info(wrap.getElement(BaseProject.driver, Sanctioned_prohibited_text_Alert).getText());
						}
						wrap.click(BaseProject.driver, sanctioned_prohibited_text_yes);
					}

				}

			}

	}

	@When("^CDDOAT: Verify the field Country of Residence$")
	public void verify_The_field_country_of_Residence() throws IOException, InterruptedException {
		String countryOfResidence = com.getElementProperties("CDDException", "CDD_OAT_countryOf_Residence");
		String countryOfResidence_value = com.getElementProperties("CDDException", "CDD_OAT_countryOf_Residence_value");
		String country_of_Residence_nonEdit = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Residence_non_edit");
		String Country_of_Residence_value_nonEdit = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Residence_value_non_edit");
		String Country_of_Residence_Sancationed_text = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Residence_Sancationed");
		String Country_of_Residence_Sancationed_text_Yes = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Residence_Sancationed_yes");
		String Country_of_Residence_Sancationed_text_No = com.getElementProperties("CDDException", "CDD_OAT_Country_Of_Residence_Sancationed_no");
		String Country_OF_Residence_sancationed_alet = com.getElementProperties("CDDException", "CDD_OAT_country_of_Residence_Sancationed_alert");

			if(wrap.getElement(BaseProject.driver, countryOfResidence).isDisplayed()==true){
				com.validateFiledVisible1(BaseProject.driver, countryOfResidence);
				com.validateFiledVisible1(BaseProject.driver, countryOfResidence_value);
				WebElement residenceValue = wrap.getElement(BaseProject.driver, countryOfResidence_value);
				if(residenceValue.isDisplayed()==true){
					//CR Change
					logger.info(wrap.getElement(BaseProject.driver, Country_OF_Residence_sancationed_alet));
					String ResidenceValue = wrap.getElement(BaseProject.driver, countryOfResidence_value).getAttribute("value");
					logger.info(ResidenceValue);
					if(ResidenceValue.equalsIgnoreCase("CU")||ResidenceValue.equalsIgnoreCase("IR")||ResidenceValue.equalsIgnoreCase("SD")||ResidenceValue.equalsIgnoreCase("SY")||ResidenceValue.equalsIgnoreCase("KP")||ResidenceValue.equalsIgnoreCase("SS")){
						com.validateFiledVisible1(BaseProject.driver, Country_of_Residence_Sancationed_text);
						wrap.click(BaseProject.driver, Country_of_Residence_Sancationed_text_No);
						if(wrap.getElement(BaseProject.driver, Country_OF_Residence_sancationed_alet).isDisplayed()==true){
							wrap.click(BaseProject.driver, Country_of_Residence_Sancationed_text_Yes);
						}else{
							wrap.click(BaseProject.driver, Country_of_Residence_Sancationed_text_Yes);
						}

					}else if(ResidenceValue.equalsIgnoreCase("IN")){
						logger.info("Selected Residence country is India");
					}else{
                        logger.info(ResidenceValue);
                    }
				}
			}


	}



	@When("^CDDOAT: Verify the field Resident of Sanctioned country Dispensation$")
	public void verify_The_field_Resident_of_sanctioned_country_Dispensation() throws IOException, InterruptedException{
		String country_Of_sanction = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country");
		String country_Of_sanction_yes = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_yes");
		String Country_Of_sanction_No = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_No");
		//String sanction_Despensation_text_non_edit = com.getElementProperties("CDDException", "CDD_OAT_Client_indicates_address_telephone_non_edit");
		//String sanction_Despensation_value_non_edit = com.getElementProperties("CDDException", "CDD_OAT_Client_indicates_address_telephone_value_non_edit");
		String Sancationed_Despensation_alet = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_AlertMessage");
		String Sancationed_Indica_Despensation_text = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_Indica_Dispenction");
		String Sancationed_Indica_Despensation_Yes = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_Indica_Dispenction_Yes");
		String Sancationed_Indica_Despensation_No = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_Indica_Dispenction_No");
		String Sancationed_Indica_Despensation_alert = com.getElementProperties("CDDException", "CDD_OAT_sanctioned_country_india_dispenction_alert");

        com.validateFiledVisible1(BaseProject.driver, country_Of_sanction);
			wrap.wait(1500);
			if(wrap.getElement(BaseProject.driver, country_Of_sanction_yes).isDisplayed()==true){
				WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, country_Of_sanction_yes);
				WebElement sanction_is_No = wrap.getElement(BaseProject.driver, Country_Of_sanction_No);
				com.validateFiledVisible1(BaseProject.driver, country_Of_sanction);
				if(sanction_is_Yes.isDisplayed()&&sanction_is_Yes.isSelected()==true){
					com.validateFiledVisible1(BaseProject.driver, Sancationed_Despensation_alet);
					if(wrap.getElement(BaseProject.driver, Sancationed_Despensation_alet).isDisplayed()==true){
						logger.info(wrap.getElement(driver, Sancationed_Despensation_alet).getText());
					}
					com.validateFiledVisible1(BaseProject.driver, Sancationed_Indica_Despensation_text);
					if(wrap.getElement(driver, Sancationed_Indica_Despensation_text).isDisplayed()==true){

						wrap.click(BaseProject.driver, Sancationed_Indica_Despensation_No);

						wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Sancationed_Indica_Despensation_alert)));
						logger.info(wrap.getElement(BaseProject.driver, Sancationed_Indica_Despensation_alert));

						wait.until(ExpectedConditions.elementToBeClickable(wrap.getElement(BaseProject.driver, Sancationed_Indica_Despensation_Yes)));

						wrap.click(BaseProject.driver, Sancationed_Indica_Despensation_Yes);
					}

				}else if(sanction_is_No.isSelected()==false){
					wrap.click(BaseProject.driver, Country_Of_sanction_No);
					//logger.info(sanction_is_No);
				}
			}

	}

	@When("^CDDOAT: Verify the NTB Non-resident Individuals who are resident and national of countries outside the Group’s footprint$")
	public void verify_the_NTB_Non_resident_Individuals() throws IOException, InterruptedException{
		String ntb_non_resident = com.getElementProperties("CDDException", "CDD_OAT_NTB_non_resident");
		String ntb_non_resident_yes = com.getElementProperties("CDDException", "CDD_OAT_NTB_Non_Resident_yes");
		String ntb_non_resident_No = com.getElementProperties("CDDException", "CDD_OAT_NTB_Non_Resident_No");

		String NTB_Non_Resident_FP_Alert = com.getElementProperties("CDDException", "CDD_OAT_NTB_Resident_Alert");
		String NTB_Non_Resident_FP_text = com.getElementProperties("CDDException", "CDD_OAT_NTB_OutSideScb_Foot_print_text");
		String NTB_Non_Resident_FP_Yes = com.getElementProperties("CDDException", "CDD_OAT_NTB_OutSideScb_Foot_print_Yes");
		String NTB_Non_Resident_FP_No = com.getElementProperties("CDDException", "CDD_OAT_NTB_OutSideScb_Foot_print_No");
		String NTB_Non_Resident_FP_No_alert = com.getElementProperties("CDDException", "CDD_OAT_NTB_Out_sideSCB_Foot_Print_alert");

		WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, ntb_non_resident_yes);
		WebElement sanction_is_No = wrap.getElement(BaseProject.driver, ntb_non_resident_No);
		com.validateFiledVisible1(BaseProject.driver, ntb_non_resident);

			if(wrap.getElement(BaseProject.driver, ntb_non_resident).isDisplayed()){
				if(sanction_is_Yes.isSelected()==true){
					wrap.click(BaseProject.driver, ntb_non_resident_yes);
					if(wrap.getElement(BaseProject.driver, NTB_Non_Resident_FP_Alert).isDisplayed()==true){

							if(wrap.getElement(BaseProject.driver, NTB_Non_Resident_FP_text).isDisplayed()==true){
								wrap.click(BaseProject.driver, NTB_Non_Resident_FP_No);
                                wrap.wait(1000);
                                logger.info(wrap.getElement(BaseProject.driver,NTB_Non_Resident_FP_No_alert).getText()+"Alert message displayed ");


								wrap.click(driver, NTB_Non_Resident_FP_Yes);
							}

					}


					//logger.info(sanction_is_Yes.getText());
				}else if(sanction_is_No.isSelected()==true){
					wrap.click(BaseProject.driver, ntb_non_resident_No);
				}
			}


	}
	@When("^CDDOAT: Verify the field of Account opening purpose$")
	public void verify_Field_Account_opening_purpose() throws IOException, InterruptedException{
		String account_opening_purpose_header = com.getElementProperties("CDDException", "CDD_OAT_Account_opening_purpose");
		String account_Opening_purpose = com.getElementProperties("CDDException", "CDD_OAT_AccountOpening_purpose_Text");
		String account_Opening_purpose_yes = com.getElementProperties("CDDException", "CDD_OAT_Account_Opening_purpose_Yes");
		String account_Opening_purpose_No = com.getElementProperties("CDDException", "CDD_OAT_Account_Opening_purpose_No");
        String accountopening_bussines_purpose = com.getElementProperties("CDDException","CDD_OAT_Account_opening_purpose_alert_message");
		WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, account_Opening_purpose_yes);
		WebElement sanction_is_No = wrap.getElement(BaseProject.driver, account_Opening_purpose_No);
		com.validateFiledVisible1(BaseProject.driver, account_opening_purpose_header);

			if(wrap.getElement(BaseProject.driver, account_Opening_purpose).isDisplayed()){
				if(sanction_is_Yes.isSelected()==true){
                    wrap.wait(1000);
					//wrap.click(BaseProject.driver, accountopening_bussines_purpose);
                    logger.info(wrap.getElement(BaseProject.driver,accountopening_bussines_purpose).getText());
                    wrap.wait(1000);
                    verify_filed_account_opening_purpose_Of_Despension();

				}else if(sanction_is_No.isSelected()==true){
					logger.info("Account opening is selected No");
					wrap.click(BaseProject.driver, account_Opening_purpose_No);
				}
			}

	}

	@When("^CDDOAT: Verify the field of Account opening purpose of Despensation$")
	public static void verify_filed_account_opening_purpose_Of_Despension() throws IOException, InterruptedException{
		String account_opening_purpose = com.getElementProperties("CDDException", "CDD_OAT_Account_opening_purpose");
		String account_opening_purpose_text_nonEdit = com.getElementProperties("CDDException", "CDD_OAT_Account_opening_purpose_NonEditable");
		String account_opening_purpose_value_nonedit = com.getElementProperties("CDDException", "CDD_OAT_Account_opening_purpose_value_NonEditable");
		String account_opening_purpose_edit_text = com.getElementProperties("CDDException", "CDD_OAT_AccountOpening_purpose_Text");
		String account_opening_purpose_edit_yes = com.getElementProperties("CDDException", "CDD_OAT_Account_Opening_purpose_Yes");
		String account_opening_purpose_edit_No = com.getElementProperties("CDDException", "CDD_OAT_Account_Opening_purpose_No");

		String account_Opening_purpose_Despension = com.getElementProperties("CDDException", "CDD_OAT_purpose_of_despenction");
		String account_Opening_purpose_yes = com.getElementProperties("CDDException", "CDD_OAT_purpose_of_despenction_yes");
		String account_Opening_purpose_No = com.getElementProperties("CDDException", "CDD_OAT_purpose_of_despenction_No");
		String accountopening_bussines_purpose_alert = com.getElementProperties("CDDException","CDD_OAT_Account_opening_purpose_bussines_alert_message");
				if(wrap.getElement(BaseProject.driver, account_Opening_purpose_Despension).isDisplayed()==true){
					com.validateFiledVisible1(BaseProject.driver,account_Opening_purpose_Despension);
                    wrap.click(BaseProject.driver,account_Opening_purpose_No);
                    wrap.wait(1000);
                    logger.info(wrap.getElement(BaseProject.driver,accountopening_bussines_purpose_alert).getText());
                    wrap.wait(1000);
					wrap.click(BaseProject.driver, account_Opening_purpose_yes);
					}else{
                    logger.info("Account opening purpose of Despensation not displayed");
                }

	}



	@When("^CDDOAT: Verify the field of Client wishes anonymity numbered account passbook$")
	public void verify_Field_Client_wishes_anonymity() throws IOException, InterruptedException{
		String anonymity = com.getElementProperties("CDDException", "CDD_OAT_anonymity");
		String anonymity_yes = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_Yes");
		String anonymity_No = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_No");
		//String anonymity_nonedit = com.getElementProperties("CDDException", "CDD_OAT_client_anonymity_NonEditable");
		//String anonymity_value_nonedit = com.getElementProperties("CDDException", "CDD_OAT_client_anonymity_value_NonEditable");
		String anonymity_Dispensation_alert = com.getElementProperties("CDDException", "CDD_OAT_anonymity_alert");
		String anonymity_Dispensation_text = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_Dispensation_text");
		String anonymity_Dispensation_yes = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_Dispensation_Yes");
		String anonymity_Dispensation_No = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_Dispensation_No");
		String anonymity_Dispensation_No_alert = com.getElementProperties("CDDException", "CDD_OAT_Anonymity_Dispensation_alert");

            com.validateFiledVisible1(BaseProject.driver, anonymity);
			if(wrap.getElement(BaseProject.driver, anonymity).isDisplayed()==true){
				WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, anonymity_yes);
				WebElement sanction_is_No = wrap.getElement(BaseProject.driver, anonymity_No);
			    wrap.click(BaseProject.driver, anonymity_yes);

				if(sanction_is_Yes.isSelected()&&sanction_is_Yes.isDisplayed()==true){
					com.validateFiledVisible1(BaseProject.driver, anonymity_Dispensation_alert);

						if(wrap.getElement(BaseProject.driver, anonymity_Dispensation_text).isDisplayed()==true){
							wrap.click(BaseProject.driver, anonymity_Dispensation_No);
                            wrap.wait(1000);
							//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, anonymity_Dispensation_No_alert)));
							com.validateFiledVisible1(BaseProject.driver, anonymity_Dispensation_No_alert);
							//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, anonymity_Dispensation_yes)));
							wrap.click(BaseProject.driver, anonymity_Dispensation_yes);
						}

					//logger.info(sanction_is_Yes.getText());
				}else if(sanction_is_No.isSelected()){
					wrap.click(BaseProject.driver, anonymity_No);
					//logger.info(sanction_is_No);
				}
			}else{
                logger.info("Client wishes anonymity (numbered account/passbook) not displyed");
            }

	}
	@When("^CDDOAT: Verify the field HNW PVB criteria$")
    public void verify_Field_HNW_PVB_Criteria() throws IOException, InterruptedException{
           String CDD_Hnw_Pvb = com.getElementProperties("CDDException", "CDD_OAT_HNW_PVB");
           String CDD_Hnw_Pvb_drop_down = com.getElementProperties("CDDException", "CDD_OAT_HNW_PVB_Value");
           //String CDD_HNW_PVB_Non_Edit = com.getElementProperties("CDDException", "CDD_OAT_HNW_PVB_Non_editable_Non_editable");

           String prohibited_attribute = com.getElementProperties("CDDException", "CDD_OAT_prohibited_attribute");
           String prohibited_attribute_yes = com.getElementProperties("CDDException", "CDD_OAT_prohibited_attribute_yes");
           String prohibited_attribute_No = com.getElementProperties("CDDException", "CDD_OAT_Prohibited_attribute_No");
           String prohibited_attribute_alert = com.getElementProperties("CDDException", "CDD_OAT_prohibited_alert");

           String clientOner_ship = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation");
           String clientOner_ship_yes = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_yes");
           String clientOner_ship_No = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_No");
           String clientOner_ship_alert = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_alert");
           
           String CDD_PVB_Criteria_pvb_text = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_country_text");
           String CDD_PVB_Criteria_pvb_yes = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_country_Yes");
           String CDD_PVB_Criteria_pvb_no = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_country_No");
           String CDD_PVB_Criteria_pvb_alert = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_alert");
           String CDD_PVB_Criteria_pvb_Dispensation_text = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_Country_Dispensation_text");
           String CDD_PVB_Criteria_pvb_Dispensation_Yes = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_Country_Dispensation_Yes");
           String CDD_PVB_Criteria_pvb_Dispensation_No = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_Country_Dispensation_No");
           String CDD_PVB_Criteria_pvb_Dispensation_alert = com.getElementProperties("CDDException", "CDD_OAT_PVB_Criteria_PVB_Country_Dispensation_alert");
           

           ArrayList<String> values = new ArrayList<String>();

           values.add("HNW Criteria Met");
           values.add("PVB Criteria Met");
           values.add("Other");


                  if(wrap.getElement(BaseProject.driver, CDD_Hnw_Pvb).isDisplayed()==true){
                        com.validateFiledVisible1(BaseProject.driver, CDD_Hnw_Pvb);
                        com.validateDropDown(BaseProject.driver, CDD_Hnw_Pvb_drop_down, values);
                        //logger.info( values);

                               if(wrap.getElement(BaseProject.driver, CDD_Hnw_Pvb_drop_down).isDisplayed()&&wrap.getElement(BaseProject.driver, CDD_Hnw_Pvb_drop_down).isEnabled()){
                                      Select select = new Select(BaseProject.driver.findElement(By.xpath(CDD_Hnw_Pvb_drop_down)));
                                      WebElement HNWPVB = select.getFirstSelectedOption();
                                      if(HNWPVB.getText().equalsIgnoreCase("Other")){

                                             wrap.selectFromDropDown(BaseProject.driver, CDD_Hnw_Pvb_drop_down, "Other", "BYVISIBLETEXT");
                                          logger.info("HNW/PVB Criteria is selected as Others");
                                      }else if(HNWPVB.getText().equalsIgnoreCase("HNW Criteria Met")){
                                             wrap.selectFromDropDown(BaseProject.driver, CDD_Hnw_Pvb_drop_down, "Other", "BYVISIBLETEXT");

                                                    if(wrap.getElement(BaseProject.driver, prohibited_attribute).isDisplayed()==true){
                                                        wrap.click(BaseProject.driver,prohibited_attribute_yes);
                                                        //   wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, prohibited_attribute_yes)));
                                                    }else if(wrap.getElement(BaseProject.driver, prohibited_attribute_alert).isDisplayed()==true){
                                                           wrap.click(BaseProject.driver, prohibited_attribute_yes);
                                                         //  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, prohibited_attribute_alert)));
                                                           com.validateFiledVisible1(BaseProject.driver, prohibited_attribute_alert);
                                                           if(wrap.getElement(BaseProject.driver, prohibited_attribute_alert).isDisplayed()==false){
                                                                  wrap.click(BaseProject.driver, prohibited_attribute_No);
                                                                 // wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, clientOner_ship)));
                                                                  com.validateFiledVisible1(BaseProject.driver, clientOner_ship);
                                                                  wrap.click(BaseProject.driver, clientOner_ship_No);
                                                                 // wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, clientOner_ship_alert)));
                                                                  com.validateFiledVisible1(BaseProject.driver, clientOner_ship_alert);
                                                                //  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, clientOner_ship_yes)));
                                                                  wrap.click(BaseProject.driver, prohibited_attribute_yes);
                                                           }
                                                    }                                                      


                                      }else if(HNWPVB.getText().equalsIgnoreCase("PVB Criteria Met")){
                                             wrap.selectFromDropDown(BaseProject.driver, CDD_Hnw_Pvb_drop_down, "PVB Criteria Met", "BYVISIBLETEXT");
                                             if(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_alert).isDisplayed()){
                                                    logger.info(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_alert).getText());
                                             }
                                             wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_text)));
                                             if(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_text).isDisplayed()){
                                                    if(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_yes).isDisplayed()&&wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_yes).isSelected()==false){
                                                           wrap.click(BaseProject.driver, CDD_PVB_Criteria_pvb_no);
                                                    }
                                                    wrap.click(BaseProject.driver, CDD_PVB_Criteria_pvb_yes);
                                                    com.validateFiledVisible1(BaseProject.driver, CDD_PVB_Criteria_pvb_alert);

                                                           if(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_yes).isSelected()){
                                                                  com.validateFiledVisible1(BaseProject.driver, CDD_PVB_Criteria_pvb_alert);
                                                                  
                                                                  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_text)));
                                                                  if(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_text).isDisplayed()){
                                                                        wrap.click(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_No);
                                                                         wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_alert)));
                                                                         com.validateFiledVisible1(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_alert);
                                                                        wrap.click(BaseProject.driver, CDD_PVB_Criteria_pvb_Dispensation_Yes);
                                                                  }
                                                           }

                                             }
                                             
                                      }


                               }else{
                                      logger.info(wrap.getElement(BaseProject.driver, CDD_Hnw_Pvb_drop_down).getAttribute("value"));
                               }

                  }

    }

	@When("^CDDOAT: verify Name Screening Checks$")
	public void verify_Name_screening_check() throws IOException, InterruptedException, ClassNotFoundException{
		String name_screening_check = com.getElementProperties("CDDException", "CDD_OAT_Name_screening_check");
		String name_screen_dropdown = com.getElementProperties("CDDException", "CDD_OAT_Name_screening_check_dropdown");
		String blockList = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_BlockList");
		String blockList_yes = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_BlockListYes");
		String blockList_No = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_BlockListNo");
		String customer_PEP = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_Customer_PEP");
		String customer_PEP_dropdown = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_customer_PEP_Dropdown");
		String countryenter_PEP = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_country_Entered_with_PEP");
		String county_PEP_alert = com.getElementProperties("CDDException", "CDD_OAT_Name_screen_alertmessage");
		String namescreencheckNon_Edit = com.getElementProperties("CDDException", "CDD_OAT_Name_Screening_Chcek_non_editable");

		switchFrame();

		utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
		//String nameScreen = utils.readColumn("Name Screening Checks", 0);
		
		String nameScreen = utils.readColumnWithRowID("Name Screening Checks", BaseProject.scenarioID);
		//String customerPEP = utils.readColumn("Customer a PEP", 0);
		String customerPEP = utils.readColumnWithRowID("Customer a PEP", BaseProject.scenarioID);
		ArrayList<String> values = new ArrayList<String>();


		values.add("Blacklist Match");
		values.add("Sanctions Match");
		values.add("PEP Match");
		values.add("No Match Found");


			if(wrap.getElement(BaseProject.driver, name_screening_check).isDisplayed()==true){
				com.validateFiledVisible1(BaseProject.driver, name_screening_check);
				com.validateDropDown(BaseProject.driver, name_screen_dropdown, values);

					if(wrap.getElement(BaseProject.driver, name_screen_dropdown).isDisplayed()&&wrap.getElement(BaseProject.driver, name_screen_dropdown).isEnabled()){


						if(nameScreen.equalsIgnoreCase("Blacklist Match")){
							wrap.selectFromDropDown(BaseProject.driver, name_screen_dropdown, nameScreen, "BYVISIBLETEXT");
							//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(blockList)));
                            wrap.wait(1000);
							com.validateFiledVisible1(BaseProject.driver, blockList);
                            wrap.wait(1000);
							if(wrap.getElement(BaseProject.driver, blockList).isDisplayed()){
								//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(blockList_yes)));
								wrap.wait(1000);
								wrap.click(BaseProject.driver, blockList_yes);
							}

						}else if(nameScreen.equalsIgnoreCase("Sanctions Match")){
							wrap.selectFromDropDown(BaseProject.driver, name_screen_dropdown, nameScreen, "BYVISIBLETEXT");
							wrap.wait(1000);
                           // wait.until(ExpectedConditions.elementToBeClickable(By.xpath(blockList)));
							com.validateFiledVisible1(BaseProject.driver, blockList);
							if(wrap.getElement(BaseProject.driver, blockList).isDisplayed()){
								//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(blockList_yes)));
								wrap.wait(1000);
								wrap.click(BaseProject.driver, blockList_yes);
							}
						}else if(nameScreen.equalsIgnoreCase("PEP Match")){
							wrap.selectFromDropDown(BaseProject.driver, name_screen_dropdown, nameScreen, "BYVISIBLETEXT");
							com.validateFiledVisible1(BaseProject.driver, customer_PEP);			
							ArrayList<String> value = new ArrayList<String>();
							value.add("Group PEP");
							value.add("No PEP");
							value.add("Local PEP");
							Thread.sleep(1000);
							wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(customer_PEP_dropdown)));
							if(wrap.getElement(BaseProject.driver, customer_PEP_dropdown).isDisplayed()){

								com.validateDropDown(BaseProject.driver, customer_PEP_dropdown, value);
								if(customerPEP.equalsIgnoreCase("Group PEP")){
									wrap.selectFromDropDown(BaseProject.driver, customer_PEP_dropdown, customerPEP, "BYVISIBLETEXT");

									com.validateFiledVisible1(BaseProject.driver, countryenter_PEP);
									wrap.selectFromDropDown(BaseProject.driver, countryenter_PEP, "TURKMENISTAN", "BYVISIBLETEXT");
									WebElement element = wrap.getElement(BaseProject.driver, county_PEP_alert);
									//logger.info(element.getText());
								}else if(customerPEP.equalsIgnoreCase("No PEP")){
									wrap.selectFromDropDown(BaseProject.driver, customer_PEP_dropdown, customerPEP, "BYVISIBLETEXT");
								}else if(customerPEP.equalsIgnoreCase("Local PEP")){
									wrap.selectFromDropDown(BaseProject.driver, customer_PEP_dropdown, customerPEP, "BYVISIBLETEXT");
								}
							}

						}else if(nameScreen.equalsIgnoreCase("No Match Found")){
							wrap.selectFromDropDown(BaseProject.driver, name_screen_dropdown, nameScreen, "BYVISIBLETEXT");
						}
					}

			}



	}
	@When("^CDDOAT: verify the Client owns/ controls 25% or more of existing SCB client of Bank with certain prohibited attributed$")
	public void verify_client_owns_existing_SCB_client() throws IOException, InterruptedException{
		String prohibited_attribute = com.getElementProperties("CDDException", "CDD_OAT_prohibited_attribute");
		String prohibited_attribute_yes = com.getElementProperties("CDDException", "CDD_OAT_prohibited_attribute_yes");
		String prohibited_attribute_No = com.getElementProperties("CDDException", "CDD_OAT_Prohibited_attribute_No");
		String prohibited_attribute_alert = com.getElementProperties("CDDException", "CDD_OAT_prohibited_alert");
		//WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, anonymity_yes);
		//WebElement sanction_is_No = wrap.getElement(BaseProject.driver, anonymity_No);
		//WebElement attribute =  wrap.getElement(BaseProject.driver, prohibited_attribute);

			if(wrap.getElement(BaseProject.driver, prohibited_attribute).isDisplayed()){
				com.validateFiledVisible1(BaseProject.driver, prohibited_attribute);
				wrap.click(BaseProject.driver, prohibited_attribute_yes);
				//logger.info(wrap.getElement(BaseProject.driver, prohibited_attribute_alert).getText());
			}


	}
	@When("^CDDOAT: verify the Client Ownership DispensationRequired$")
	public void verify_client_Ownership_DispensationRequired() throws IOException, InterruptedException{
		String clientOner_ship = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation");
		String clientOner_ship_yes = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_yes");
		String clientOner_ship_No = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_No");
		String clientOner_ship_alert = com.getElementProperties("CDDException", "CDD_OAT_clientOnership_dispensation_alert");
		//WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, anonymity_yes);
		//WebElement sanction_is_No = wrap.getElement(BaseProject.driver, anonymity_No);
		//WebElement clientOnership = wrap.getElement(BaseProject.driver, clientOner_ship);

			if(wrap.getElement(BaseProject.driver, clientOner_ship).isDisplayed()){
				com.validateFiledVisible1(BaseProject.driver, clientOner_ship);
				wrap.click(BaseProject.driver, clientOner_ship_No);
				//logger.info(wrap.getElement(BaseProject.driver, clientOner_ship_alert).getText());
			}
		}

	@When("^CDDOAT: verify the Is Adverse media true match found on the client$")
	public void verify_client_Adverse_media_true_match_found() throws IOException, InterruptedException{
		String true_match_found = com.getElementProperties("CDDException", "CDD_OAT_True_Match_found");
		String true_match_found_yes = com.getElementProperties("CDDException", "CDD_OAT_True_Match_Found_Yes");
		String true_match_found_No = com.getElementProperties("CDDException", "CDD_OAT_True_Match_Found_No");
		String true_match_found_alert = com.getElementProperties("CDDException", "CDD_OAT_True_Match_Found_alert");
        String credible_source = com.getElementProperties("CDDException", "CDD_OAT_credible_source");
        String credible_source_dropdown = com.getElementProperties("CDDException", "CDD_OAT_credible_source_dropdown");
        String  crediable_concering = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering");
        String  crediable_concering_Yes = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering_Yes");
        String  crediable_concering_alert = com.getElementProperties("CDDException", "CDD_OAT_credible_source_alert_message");
        String crediable_consering_alert = com.getElementProperties("CDDException","CDD_OAT_Advice_media_Dispenction_alert");
        String  crediable_concering_No = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering_No");
        String adverseMedia_Despensaation = com.getElementProperties("CDDException","CDD_OAT_Credible_Media_Despensation");
        String mediaDespentionYes = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_Yes");
        String mediaDespentionNo = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_No");
        String mediaDespentionAlert = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_alert");

        utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
        String credible_source_value = CommonUtils.readColumnWithRowID("credible source", BaseProject.scenarioID);


		com.validateFiledVisible1(BaseProject.driver, true_match_found);
		

			if(wrap.getElement(BaseProject.driver, true_match_found).isDisplayed()==true){
				if(wrap.getElement(BaseProject.driver, true_match_found_yes).isSelected()==false){
					wrap.click(BaseProject.driver, true_match_found_yes);
					logger.info(wrap.getElement(BaseProject.driver, true_match_found_alert).getText());
                    wrap.wait(1000);
                    ArrayList<String> values = new ArrayList<String>();

                    values.add("Detica AOC");
                    values.add("PISE / internet searches/ in country system ");
                    values.add("None of the above");
                    if(credible_source_value.equalsIgnoreCase("Detica AOC")){

                        wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, credible_source_value, "BYVISIBLETEXT");
                        com.validateFiledVisible1(BaseProject.driver, crediable_concering);
                      logger.info(wrap.getElement(BaseProject.driver,crediable_concering_alert).getText());
                      wrap.wait(1000);
                        wrap.click(BaseProject.driver, crediable_concering_Yes);
                        wrap.wait(1000);
                        if(wrap.getElement(BaseProject.driver,crediable_consering_alert).isDisplayed()) {
                            logger.info("Client has credible material adverse media");
                            if(wrap.getElement(BaseProject.driver,adverseMedia_Despensaation).isDisplayed()){

                                wrap.click(BaseProject.driver, mediaDespentionNo);
                                wrap.wait(1000);
                                if(wrap.getElement(BaseProject.driver,mediaDespentionAlert).isDisplayed()){
                                    logger.info(wrap.getElement(BaseProject.driver,mediaDespentionAlert).getText());
                                    wrap.click(BaseProject.driver, mediaDespentionYes);
                                }
                            }

                        }else{
                            wrap.click(BaseProject.driver,crediable_concering_No);
                        }


                    }else if(credible_source_value.equalsIgnoreCase("PISE / internet searches/ in country system")){
                        wrap.wait(1000);

                        wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, credible_source_value, "BYVISIBLETEXT");

                        logger.info(wrap.getElement(BaseProject.driver, crediable_concering_alert).getText());
                        wrap.wait(1000);
                        wrap.click(BaseProject.driver, crediable_concering_Yes);
                        wrap.wait(1000);
                        if(wrap.getElement(BaseProject.driver,crediable_consering_alert).isDisplayed()) {
                            logger.info("Client has credible material adverse media");
                            if(wrap.getElement(BaseProject.driver,adverseMedia_Despensaation).isDisplayed()){

                                wrap.click(BaseProject.driver, mediaDespentionNo);
                                wrap.wait(1000);
                                if(wrap.getElement(BaseProject.driver,mediaDespentionAlert).isDisplayed()){
                                    logger.info(wrap.getElement(BaseProject.driver,mediaDespentionAlert).getText());
                                    wrap.click(BaseProject.driver, mediaDespentionYes);
                                }
                            }

                        }else{
                            wrap.click(BaseProject.driver,crediable_concering_No);
                        }
                    }else if(credible_source_value.equalsIgnoreCase("None of the above")){

                        com.validateFiledVisible1(BaseProject.driver, credible_source);;
                        com.validateDropDown(BaseProject.driver, credible_source_dropdown, values);
                        wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, "None of the above", "BYVISIBLETEXT");
                    }

				}else{
					wrap.click(BaseProject.driver, true_match_found_No);
				}
			}


	}
	@When("^CDDOAT: verify the Is Adverse media true match found on the entities owned by the client$")
	public void verify_client_Adverse_media_true_match_found_on_entities_oowned() throws IOException, InterruptedException{
		String advise_match_found = com.getElementProperties("CDDException", "CDD_OAT_Advise_Media_Match_Found");
		String advise_match_dropdown = com.getElementProperties("CDDException", "CDD_OAT_Advise_Media_Match_Found_Drop_down");
        String  crediable_concering_alert = com.getElementProperties("CDDException", "CDD_OAT_credible_source_alert_message");
        String crediable_consering_alert = com.getElementProperties("CDDException","CDD_OAT_Advice_media_Dispenction_alert");
        String adverseMedia_Despensaation = com.getElementProperties("CDDException","CDD_OAT_Credible_Media_Despensation");
		String  crediable_concering = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering");
		String  crediable_concering_Yes = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering_Yes");
		String  crediable_concering_No = com.getElementProperties("CDDException", "CDD_OAT_crediable_and_concering_No");
		String mediaDespentionYes = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_Yes");
		String mediaDespentionNo = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_No");
        String mediaDespentionAlert = com.getElementProperties("CDDException", "CDD_OAT_Media_Despensation_alert");
		String credible_source = com.getElementProperties("CDDException", "CDD_OAT_credible_source");
		String credible_source_dropdown = com.getElementProperties("CDDException", "CDD_OAT_credible_source_dropdown");
		utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
		String credible_source_value = CommonUtils.readColumnWithRowID("credible source", BaseProject.scenarioID);
		//String credible_source_value = utils.readColumn("credible source", 0);


			if(wrap.getElement(BaseProject.driver, advise_match_found).isDisplayed()==true){
				Select select = new Select(wrap.getElement(BaseProject.driver,advise_match_dropdown));
                System.out.println(select.getFirstSelectedOption());
                logger.info(select.getFirstSelectedOption());

				wrap.selectFromDropDown(BaseProject.driver, advise_match_dropdown, "Yes", "BYVISIBLETEXT");
				//wrap.click(BaseProject.driver, true_match_found_No);
				//com.validateFiledVisible1(BaseProject.driver, advise_match_found);
				ArrayList<String> values = new ArrayList<String>();

				values.add("Detica AOC");
				values.add("PISE / internet searches/ in country system ");
				values.add("None of the above");
                if(credible_source_value.equalsIgnoreCase("Detica AOC")){

                    wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, credible_source_value, "BYVISIBLETEXT");
                    com.validateFiledVisible1(BaseProject.driver, crediable_concering);
                    logger.info(wrap.getElement(BaseProject.driver,crediable_concering_alert).getText());
                    wrap.wait(1000);
                    wrap.click(BaseProject.driver, crediable_concering_Yes);
                    wrap.wait(1000);
                    if(wrap.getElement(BaseProject.driver,crediable_consering_alert).isDisplayed()) {
                        logger.info("Client has credible material adverse media");
                        if(wrap.getElement(BaseProject.driver,adverseMedia_Despensaation).isDisplayed()){

                            wrap.click(BaseProject.driver, mediaDespentionNo);
                            wrap.wait(1000);
                            if(wrap.getElement(BaseProject.driver,mediaDespentionAlert).isDisplayed()){
                                logger.info(wrap.getElement(BaseProject.driver,mediaDespentionAlert).getText());
                                wrap.click(BaseProject.driver, mediaDespentionYes);
                            }
                        }

                    }else{
                        wrap.click(BaseProject.driver,crediable_concering_No);
                    }


                }else if(credible_source_value.equalsIgnoreCase("PISE / internet searches/ in country system")){
                    wrap.wait(1000);

                    wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, credible_source_value, "BYVISIBLETEXT");

                    logger.info(wrap.getElement(BaseProject.driver,crediable_concering_alert).getText());
                    wrap.wait(1000);
                    wrap.click(BaseProject.driver, crediable_concering_Yes);
                    wrap.wait(1000);
                    if(wrap.getElement(BaseProject.driver,crediable_consering_alert).isDisplayed()) {
                        logger.info("Client has credible material adverse media");
                        if(wrap.getElement(BaseProject.driver,adverseMedia_Despensaation).isDisplayed()){

                            wrap.click(BaseProject.driver, mediaDespentionNo);
                            wrap.wait(1000);
                            if(wrap.getElement(BaseProject.driver,mediaDespentionAlert).isDisplayed()){
                                logger.info(wrap.getElement(BaseProject.driver,mediaDespentionAlert).getText());
                                wrap.click(BaseProject.driver, mediaDespentionYes);
                            }
                        }

                    }else{
                        wrap.click(BaseProject.driver,crediable_concering_No);
                    }
                }else if(credible_source_value.equalsIgnoreCase("None of the above")){

                    com.validateFiledVisible1(BaseProject.driver, credible_source);;
                    com.validateDropDown(BaseProject.driver, credible_source_dropdown, values);
                    wrap.selectFromDropDown(BaseProject.driver, credible_source_dropdown, "None of the above", "BYVISIBLETEXT");
                }

			}


	}

	@When("^CDDOAT: Validate Additional Risk factor is Displayes$")
	public void verify_additional_Risk_factor() throws IOException{
		String additonalRiskFactor = com.getElementProperties("CDDException", "CDD_OAT_Additional_Risk_factor");
		String additinal_RiskFactor_edit = com.getElementProperties("CDDException", "CDD_OAT_Additional_Risk_factor_text");
		String additionalRiskFactor_dropdown = com.getElementProperties("CDDException", "CDD_OAT_additional_Risk_factor_dropdown");


			if(wrap.getElement(BaseProject.driver, additonalRiskFactor).isDisplayed()){

					if(wrap.getElement(BaseProject.driver, additinal_RiskFactor_edit).isDisplayed()==true){
						com.validateFiledVisible1(BaseProject.driver, additionalRiskFactor_dropdown);
                        Select risk = new Select(wrap.getElement(BaseProject.driver, additinal_RiskFactor_edit));
                        logger.info(risk.getFirstSelectedOption());
					}
			}
	}

	@When("^CDDOAT: Verify the Is the client a joint account holder with another client who is already EDD/MEDD$")
	public void verify_EDD_MEDD_client() throws IOException, InterruptedException{
		String edd_MEDD_header = com.getElementProperties("CDDException", "CDD_OAT_EDD_MEDD_is_already");
		String edd_MEDD_header_Yes = com.getElementProperties("CDDException", "CDD_OAT_EDD_MEDD_Yes");
		String edd_MEDD_header_No = com.getElementProperties("CDDException", "CDD_OAT_MAEDD_No");
        String CDD_OAT_MEDD_ListOfProductTypes = com.getElementProperties("CDDException", "CDD_OAT_MEDD_ListOfProductTypes");
        String CDD_OAT_MEDD_ListOfProductTypes_dropdown = com.getElementProperties("CDDException", "CDD_OAT_MEDD_ListOfProductTypes_dropdown");
      //  String edd_MEDD_header_No = com.getElementProperties("CDDException", "CDD_OAT_MAEDD_No");




				if(wrap.getElement(BaseProject.driver, edd_MEDD_header).isDisplayed()){
					if(wrap.getElement(BaseProject.driver, edd_MEDD_header_Yes).isSelected()==true){
						wrap.click(BaseProject.driver, edd_MEDD_header_Yes);
					}else{
						wrap.click(null, edd_MEDD_header_No);
                        if(wrap.getElement(BaseProject.driver,CDD_OAT_MEDD_ListOfProductTypes).isDisplayed()){
                            logger.info(wrap.getElement(BaseProject.driver,CDD_OAT_MEDD_ListOfProductTypes).getText());
                            Select product = new Select(wrap.getElement(BaseProject.driver,CDD_OAT_MEDD_ListOfProductTypes_dropdown));
                            logger.info(product.getFirstSelectedOption());
                        }
					}
				}



	}
	@When("^CDDOAT: Clcik on Get CDD Status Button$")
	public void verify_getCDD_Button_visible() throws IOException, InterruptedException{
		String getCDD = com.getElementProperties("CDDException", "CDD_OAT_Get_CDD_Button");

			if(wrap.getElement(BaseProject.driver, getCDD).isDisplayed()){
				wrap.click(BaseProject.driver, getCDD);
				Thread.sleep(2000);
			}
	/*	try{
			if(wrap.getElement(driver, getCDD).isDisplayed()){
				wrap.click(driver, getCDD);
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		String divScroll = "//*[@id='INNERDIV-SubSectionCaptureDetailsB']/div/div[1]/div";
		
		WebElement divElement = driver.findElement(By.xpath(divScroll));
		Actions a = new Actions(driver);
		for(int j=0; j<8; j++)
			a.sendKeys(divElement, Keys.ARROW_UP).build().perform();
		
		com.validateFiledVisible(driver,"//input[@id='SanctionBlacklistMatchDispY']");
		
		
		try{
			if(wrap.getElement(driver, "//input[@id='SanctionBlacklistMatchDispY']").isDisplayed()==true){
				if(wrap.getElement(driver, "//input[@id='SanctionBlacklistMatchDispY']").isSelected()==false){
					wrap.click(driver,  "//input[@id='SanctionBlacklistMatchDispY']");
					//logger.info(wrap.getElement(driver, true_match_found_alert).getText());
				}
			}}
			catch(Exception e)
			{}	
		
		for(int j=0; j<8; j++)
			a.sendKeys(divElement, Keys.ARROW_DOWN).build().perform();
		
		try{
			if(wrap.getElement(driver, getCDD).isDisplayed()){
				wrap.click(driver, getCDD);
				Thread.sleep(2000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}*/
		
		
		
		
		
	}
	@When("^CDDOAT: verify MEDD / EDD Specific Questionaries$")
	public void verify_Medd_Edd_specific_Questionaries() throws IOException, InterruptedException{

		String medd_EDD_Specific_question = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_questions");
		String medd_EDD_Specific_question_yes = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_Questions_Yes");
		String medd_EDD_Specific_question_No = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_Question_No");
		String medd_EDD_Specific_question_alert = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Alert");
		String income_or_welth_devise = com.getElementProperties("CDDException", "CDD_OAT_Income_Or_welth_drive");
		String income_or_welth_devise_dropdown = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_dropdown");
		String income_or_welth_aler_message = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_alert_message");
        String CDD_OAT_Income_or_welth_drive_alert_message_wealth = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_alert_message_wealth");
		//WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, anonymity_yes);
		//WebElement sanction_is_No = wrap.getElement(BaseProject.driver, anonymity_No);
        String incomeorWelthdropdownValues = CommonUtils.readColumnWithRowID("IncomeorWealth", BaseProject.scenarioID);
		Thread.sleep(3000);
		com.validateFiledVisible1(BaseProject.driver, medd_EDD_Specific_question);

			if(wrap.getElement(BaseProject.driver, medd_EDD_Specific_question).isDisplayed()){
				logger.info("MEDD / EDD Specific Questionaries displayed");

				wrap.click(BaseProject.driver, medd_EDD_Specific_question_yes);
				Thread.sleep(1000);
				//logger.info(wrap.getElement(BaseProject.driver, medd_EDD_Specific_question_alert).getText());

					if(wrap.getElement(BaseProject.driver, income_or_welth_devise).isDisplayed()){
						wrap.selectFromDropDown(BaseProject.driver, income_or_welth_devise_dropdown, incomeorWelthdropdownValues, "BYVISIBLETEXT");
						wrap.wait(1000);
                        Select income = new Select(wrap.getElement(BaseProject.driver,income_or_welth_devise_dropdown));
                        String incomeOrWealth = income.getFirstSelectedOption().getText();
                        if(incomeOrWealth.equalsIgnoreCase("Wealth >20% from Gambling / Gaming Industry, Money Service Bureaus, Defence Goods")) {
                            logger.info(wrap.getElement(BaseProject.driver, CDD_OAT_Income_or_welth_drive_alert_message_wealth).getText());
                            sanction_link_Based_income_welth();

                        }else if (incomeOrWealth.equalsIgnoreCase("Directly or Indirectly from Sanctioned Countries / Party")){
                            logger.info(wrap.getElement(BaseProject.driver, income_or_welth_aler_message).getText());
                            sanction_link_Based_income_welth();
                        }else if (incomeOrWealth.equalsIgnoreCase("None of the above applies to client")){
                            logger.info("None of the above applies to client displayed");
                        }
					}else
                        logger.info("Income or wealth fields are not displayed");

			}

	}

    @When("^CDDOAT: verify MEDD / EDD Specific Questionaries select on No$")
    public void verify_Medd_Edd_specific_Questionaries_select_No_option() throws IOException, InterruptedException{

        String medd_EDD_Specific_question = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_questions");
        String medd_EDD_Specific_question_yes = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_Questions_Yes");
        String CDD_OAT_Incomplete_SOWAlert = com.getElementProperties("CDDException", "CDD_OAT_Incomplete_SOWAlert");
        String CDD_OAT_Incomplete_sowQuestion = com.getElementProperties("CDDException", "CDD_OAT_Incomplete_sowQuestion");
        String CDD_OAT_Incomplete_sow_Yes = com.getElementProperties("CDDException", "CDD_OAT_Incomplete_sow_Yes");
        String CDD_OAT_Incomplete_sow_No = com.getElementProperties("CDDException", "CDD_OAT_Incomplete_sow_No");
        String CDD_OAT_incomplete_sow_no_alert = com.getElementProperties("CDDException", "CDD_OAT_incomplete_sow_no_alert");


        String medd_EDD_Specific_question_No = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Specific_Question_No");
        String medd_EDD_Specific_question_alert = com.getElementProperties("CDDException", "CDD_OAT_MEDD_EDD_Alert");
        String income_or_welth_devise = com.getElementProperties("CDDException", "CDD_OAT_Income_Or_welth_drive");
        String income_or_welth_devise_dropdown = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_dropdown");
        String income_or_welth_aler_message = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_alert_message");
        String CDD_OAT_Income_or_welth_drive_alert_message_wealth = com.getElementProperties("CDDException", "CDD_OAT_Income_or_welth_drive_alert_message_wealth");

        String incomeorWelthdropdownValues = CommonUtils.readColumnWithRowID("IncomeorWealth", BaseProject.scenarioID);
        Thread.sleep(3000);
        com.validateFiledVisible1(BaseProject.driver, medd_EDD_Specific_question);

        if(wrap.getElement(BaseProject.driver, medd_EDD_Specific_question).isDisplayed()){
            logger.info("MEDD / EDD Specific Questionaries displayed");

            wrap.click(BaseProject.driver, medd_EDD_Specific_question_No);
            wrap.wait(2000);
            if(wrap.getElement(BaseProject.driver,CDD_OAT_Incomplete_SOWAlert).isDisplayed()){
                logger.info(wrap.getElement(BaseProject.driver,CDD_OAT_Incomplete_SOWAlert).getText());

               logger.info(wrap.getElement(BaseProject.driver,CDD_OAT_Incomplete_sowQuestion).getText());
                wrap.wait(2000);
                   // wrap.click(PayloadValidations.driver, CDD_OAT_Incomplete_sow_No);
                wrap.wait(2000);
                    if (wrap.getElement(BaseProject.driver, CDD_OAT_incomplete_sow_no_alert).isDisplayed()) {
                        wrap.wait(2000);
                        logger.info(wrap.getElement(BaseProject.driver, CDD_OAT_incomplete_sow_no_alert).getText());
                        wrap.wait(2000);
                       // wrap.click(PayloadValidations.driver, CDD_OAT_Incomplete_sow_Yes);
                        wrap.wait(1000);
                        if (wrap.getElement(BaseProject.driver, income_or_welth_devise).isDisplayed()) {
                            wrap.selectFromDropDown(BaseProject.driver, income_or_welth_devise_dropdown, incomeorWelthdropdownValues, "BYVISIBLETEXT");
                            wrap.wait(1000);
                            Select income = new Select(wrap.getElement(BaseProject.driver, income_or_welth_devise_dropdown));
                            String incomeOrWealth = income.getFirstSelectedOption().getText();
                            if (incomeOrWealth.equalsIgnoreCase("Wealth >20% from Gambling / Gaming Industry, Money Service Bureaus, Defence Goods")) {
                                logger.info(wrap.getElement(BaseProject.driver, CDD_OAT_Income_or_welth_drive_alert_message_wealth).getText());
                                sanction_link_Based_income_welth();

                            } else if (incomeOrWealth.equalsIgnoreCase("Directly or Indirectly from Sanctioned Countries / Party")) {
                                logger.info(wrap.getElement(BaseProject.driver, income_or_welth_aler_message).getText());
                                sanction_link_Based_income_welth();
                            } else if (incomeOrWealth.equalsIgnoreCase("None of the above applies to client")) {
                                logger.info("None of the above applies to client displayed");
                            }
                        } else
                            logger.info("Income or wealth fields are not displayed");

                    }

            }


        }

    }


	@When("^CDDOAT: verify sanction link based income or welth$")
	public static void sanction_link_Based_income_welth() throws IOException, InterruptedException{

		String medd_EDD_Specific_question = com.getElementProperties("CDDException", "CDD_OAT_Sanctions_link_based");
		String medd_EDD_Specific_question_yes = com.getElementProperties("CDDException", "CDD_OAT_Sanctions_link_based_Yes");
		String medd_EDD_Specific_question_No = com.getElementProperties("CDDException", "CDD_OAT_Sanctions_link_based_No");
		String sowbeen_corborated = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated");
		String sowbeen_corborated_yes = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated_Yes");
		String sowbeen_corborated_No = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated_No");
		String sowBeen_alert_Message = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_Alert_message");
        String CDD_OAT_wealth_incomplete_Description = com.getElementProperties("CDDException", "CDD_OAT_wealth_incomplete_Description");
        String CDD_OAT_Welth_incomplete_Description_Yes = com.getElementProperties("CDDException", "CDD_OAT_Welth_incomplete_Description_Yes");
        String CDD_OAT_welth_incompleted_description_No = com.getElementProperties("CDDException", "CDD_OAT_welth_incompleted_description_No");
        String CDD_OAT_Sow_been_yes_Alert_message = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_yes_Alert_message");
		//WebElement sanction_is_Yes = wrap.getElement(BaseProject.driver, anonymity_yes);
		//WebElement sanction_is_No = wrap.getElement(BaseProject.driver, anonymity_No);
		com.validateFiledVisible1(BaseProject.driver, medd_EDD_Specific_question);

			if(wrap.getElement(BaseProject.driver, medd_EDD_Specific_question).isDisplayed()){
				wrap.click(BaseProject.driver, medd_EDD_Specific_question_yes);
				Thread.sleep(1000);

					if(wrap.getElement(BaseProject.driver, sowbeen_corborated).isDisplayed()){
						wrap.click(BaseProject.driver, sowbeen_corborated_No);
						wrap.wait(1000);
						logger.info(wrap.getElement(BaseProject.driver, sowBeen_alert_Message).getText());
                        if(wrap.getElement(BaseProject.driver,CDD_OAT_wealth_incomplete_Description).isDisplayed()){
                            wrap.click(BaseProject.driver,CDD_OAT_Welth_incomplete_Description_Yes);
                        }

                        wrap.click(BaseProject.driver,sowbeen_corborated_yes);
                        logger.info(wrap.getElement(BaseProject.driver,CDD_OAT_Sow_been_yes_Alert_message).getText());
					}

			}

	}
    @When("CDDOAT: Has the client's SOW been corroborated$")
    public static void hasThe_client_SOW_been_corroborated() throws IOException, InterruptedException {
        String sowbeen_corborated = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated");
        String sowbeen_corborated_yes = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated_Yes");
        String sowbeen_corborated_No = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_corroborated_No");
        String sowBeen_alert_Message = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_Alert_message");
        String CDD_OAT_wealth_incomplete_Description = com.getElementProperties("CDDException", "CDD_OAT_wealth_incomplete_Description");
        String CDD_OAT_Welth_incomplete_Description_Yes = com.getElementProperties("CDDException", "CDD_OAT_Welth_incomplete_Description_Yes");
        String CDD_OAT_welth_incompleted_description_No = com.getElementProperties("CDDException", "CDD_OAT_welth_incompleted_description_No");
        String CDD_OAT_Sow_been_yes_Alert_message = com.getElementProperties("CDDException", "CDD_OAT_Sow_been_yes_Alert_message");
        if(wrap.getElement(BaseProject.driver, sowbeen_corborated).isDisplayed()){
            wrap.click(BaseProject.driver, sowbeen_corborated_No);
            wrap.wait(1000);
            logger.info(wrap.getElement(BaseProject.driver, sowBeen_alert_Message).getText());
            if(wrap.getElement(BaseProject.driver,CDD_OAT_wealth_incomplete_Description).isDisplayed()){
                wrap.click(BaseProject.driver,CDD_OAT_Welth_incomplete_Description_Yes);
            }

            wrap.click(BaseProject.driver,sowbeen_corborated_yes);
            logger.info(wrap.getElement(BaseProject.driver,CDD_OAT_Sow_been_yes_Alert_message).getText());

            wrap.click(BaseProject.driver,CDD_OAT_welth_incompleted_description_No);
        }
    }

	public static  void switchFrame() throws InterruptedException {
		int Last = 0;
		wrap.wait(500);
		BaseProject.driver.switchTo().defaultContent();
		wrap.wait(500);
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {

			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last);
		wrap.wait(500);
		
		logger.info("Frame switched successfully");
	}

	@When("^RM: CDD Information$")
	public void CDD_Information() throws IOException, InterruptedException{
		String Assign_ResonCode = com.getElementProperties("CDDException", "CDD_info_Assigned_Reason_code");
		String Submit = com.getElementProperties("CDDException","CDDException_Submit_Button_XPATH");
		wrap.typeInSuggestionTextbox(driver, Assign_ResonCode, "code", "APV");

		wrap.click(driver, Submit); 

	}

	@When("^CDDOAT: Fill The CDD information for CDD Workbasket$")
	public void fill_The_CDD_Information_for_CDD_workbasket() throws IOException, InterruptedException{
		utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
		String ElementScroll = com.getElementProperties("CDDException", "CDDOAT_CustDet_CDDInformationHeader");
		String cddInform = com.getElementProperties("CDDException", "CDD_info_CDD_Performed_dropdown"); 
		String customer_cdd_status = com.getElementProperties("CDDException", "CDD_info_customer_CDD_status");
		String cddRiskCode = com.getElementProperties("CDDException", "CDD_info_Risk_code");
		String lastReviwDate = com.getElementProperties("CDDException", "CDD_info_last_reviewDate");
		String next_reviewDate = com.getElementProperties("CDDException", "CDD_info_next_reviewDate");
		String assigned_review = com.getElementProperties("CDDException", "CDD_info_assigned_resonCode");
		String cddRemarks = com.getElementProperties("CDDException", "CDD_info_text_area");
		String noOfTransations = com.getElementProperties("CDDException", "CDD_info_NoOf_Transation_TextBox");
		String amountOfTransations = com.getElementProperties("CDDException", "CDD_info_Amount_Of_Transation_TextBox");
		String Submit = com.getElementProperties("CDDException","CDDException_Submit_Button_XPATH");
		String CDD_Performed = CommonUtils.readColumnWithRowID("CDD Performed", BaseProject.scenarioID);
		String CDD_Status_Required = CommonUtils.readColumnWithRowID("Customer CDD StatusRequired", BaseProject.scenarioID);
		String CDD_RiskCode = CommonUtils.readColumnWithRowID("CDD Risk Code", BaseProject.scenarioID);
		String CDD_ReviewDate = CommonUtils.readColumnWithRowID("CDD Last Reviewed Date", BaseProject.scenarioID);
		String CDD_Next_Review = CommonUtils.readColumnWithRowID("CDD Next Review DateRequired", BaseProject.scenarioID);
		String CDD_ResonCode = CommonUtils.readColumnWithRowID("Assigned Reason Codes", BaseProject.scenarioID);
		String CDD_Remarks = CommonUtils.readColumnWithRowID("Internal Remarks Details", BaseProject.scenarioID);
		String CDD_NoOfTransations = CommonUtils.readColumnWithRowID("No Of Transation", BaseProject.scenarioID);
		String CDD_AmountOfTransations = CommonUtils.readColumnWithRowID("Amount Of Transation", BaseProject.scenarioID);

		//wrap.click(BaseProject.driver, ElementScroll);
		if(wrap.getElement(BaseProject.driver, ElementScroll).isDisplayed()){
			try{
				if(wrap.getElement(BaseProject.driver, cddInform).isDisplayed()){

					wrap.selectFromDropDown(BaseProject.driver, cddInform, CDD_Performed, "BYVISIBLETEXT");
				}
			}catch(ElementNotVisibleException e){
				e.printStackTrace();
			}

			try{
				if(wrap.getElement(BaseProject.driver, customer_cdd_status).isDisplayed()){

					wrap.typeToSuggestionTextbox(BaseProject.driver, customer_cdd_status, "Description", CDD_Status_Required);
				}
			}catch(ElementNotVisibleException e){
				e.printStackTrace();
			}

			try{
				if(wrap.getElement(BaseProject.driver, next_reviewDate).isDisplayed()){

					wrap.type(BaseProject.driver, CDD_Next_Review, next_reviewDate);
				}
			}catch(ElementNotVisibleException e){
				e.printStackTrace();
			}

			try{
				if(wrap.getElement(BaseProject.driver, assigned_review).isDisplayed()){

					wrap.typeToSuggestionTextbox(BaseProject.driver, assigned_review, "Description", CDD_ResonCode);
				}
			}catch(ElementNotVisibleException e){
				e.printStackTrace();
			}


			wrap.type(BaseProject.driver, CDD_Remarks, cddRemarks);
			try{
				if(wrap.getElement(BaseProject.driver, noOfTransations).isDisplayed()){
					wrap.type(BaseProject.driver, CDD_NoOfTransations, noOfTransations);
				}
			}catch(Exception e){
				logger.info(e);
			}
			
			try{
				if(wrap.getElement(BaseProject.driver, amountOfTransations).isDisplayed()){
					wrap.type(BaseProject.driver, CDD_AmountOfTransations, amountOfTransations);
				}
			}catch(Exception e){
				logger.info(e);
			}
			
			
		}


		wrap.click(BaseProject.driver, Submit);

		Thread.sleep(3000);
	}
	
	@When("^Fill CDD Information in CDD Exception Workbasket$")
	public void fill_CDD_Information_in_CDD_Exception_workbasket() throws Throwable{
		
		switchFrame();
		
		String fatcaId_Document = com.getElementProperties("CDDException", "fatca_ID_Document");
		String cddRiskRating = com.getElementProperties("CDDException", "CDD_RiskRating");
		
		String cddRiskCode = com.getElementProperties("CDDException", "CDD_info_Risk_code");
		String Submit = com.getElementProperties("CDDException","CDDExceptionSubmit_Button_XPATH");
		String cddRemarks = com.getElementProperties("CDDException", "CDD_info_text_area");
		String assigned_review = com.getElementProperties("CDDException", "CDD_info_assigned_resonCode");
		String noOfTransations = com.getElementProperties("CDDException", "CDD_info_NoOf_Transation_TextBox");
		String amountOfTransations = com.getElementProperties("CDDException", "CDD_info_Amount_Of_Transation_TextBox");
		utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","RMReferral");
		//DBUtils.convertDBtoMap("cddquery");
		String CDD_Remarks = CommonUtils.readColumnWithRowID("Internal Remarks Details", BaseProject.scenarioID);
		String CDD_ResonCode = CommonUtils.readColumnWithRowID("Assigned Reason Codes", BaseProject.scenarioID);
		String CDD_NoOfTransations = CommonUtils.readColumnWithRowID("No Of Transation", BaseProject.scenarioID);
		String CDD_AmountOfTransations = CommonUtils.readColumnWithRowID("Amount Of Transation", BaseProject.scenarioID);
		
		wrap.selectFromDropDown(BaseProject.driver, fatcaId_Document, "1", "BYINDEX");
		
		Select sel = new Select(wrap.getElement(BaseProject.driver, cddRiskCode));
		//String RiskRateSelected = sel.
		WebElement RiskRateSelected = sel.getFirstSelectedOption();
		String riskRating = RiskRateSelected.getText();
		if(riskRating.equalsIgnoreCase("Enhanced Due Diligence")){
			wrap.typeToSuggestionTextbox(BaseProject.driver, assigned_review, "Description", CDD_ResonCode);
			
			String riskCode = wrap.getElement(BaseProject.driver, cddRiskRating).getAttribute("value");
			System.out.println(riskCode);
            logger.info(riskCode);
			wrap.typeToTextBox(BaseProject.driver, CDD_Remarks, cddRemarks);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(noOfTransations)));
			wrap.type(BaseProject.driver, CDD_NoOfTransations, noOfTransations);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(amountOfTransations)));
			wrap.type(BaseProject.driver, CDD_AmountOfTransations, amountOfTransations);
			

		}else if(riskRating.equalsIgnoreCase("Standard Due Diligence")){
			String riskCode = wrap.getElement(BaseProject.driver, cddRiskRating).getAttribute("value");
			System.out.println(riskCode);
            logger.info(riskCode);
		}
		
		String Action = com.getElementProperties("CDDException","CDDExceptionAction_DropDown_ID");
		
		
		JavascriptExecutor js = (JavascriptExecutor)BaseProject.driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		

		wrap.selectFromDropDown(BaseProject.driver, Action, "Approved", "BYVISIBLETEXT");
		String Remarks=com.getElementProperties("CDDException", "CDDExceptionRemarks_TextArea_ID");
			
		wrap.type(BaseProject.driver, "TEST", Remarks);
		
		
		
		//validate_Remarks_fields_in_Customer_Detail_section();
		wrap.click(BaseProject.driver, Submit);

		Thread.sleep(3000);
		
		
		
		
		
		
		
	}
	
	@Then("^Take Screenshot for CDD$")
	public void Take_Screenshot_for_Checker() throws Throwable {

	wrap.captureScreenShot(BaseProject.driver, "CDD");

	}
	
	@Then("^CDD : Validate Field '(.+)'$")
	public static void validateFieldStep(String FieldName) throws IOException, InterruptedException{
		
		wrap.wait(1000);
		
		logger.info("Going to switch into frame");

		switchFrame();
		
		CommonUtilsData.FieldNameData = FieldName;
		
		CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"UATBasicData_Testdata_sheet.xls","CDDRev");
		
		try{
			
			if(!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)){
			
				CommonUtils.validateField(
                        CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
          			  CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));
    
    }
}

catch(Exception E){
    
    System.out.println("Field : "+FieldName+" is not present in Datamodel");
}             

}


    @When("^Country List$")
    public static void listcountry() throws InterruptedException
    {
        wrap.wait(1000);
        List <WebElement> lstcount=BaseProject.driver.findElements(By.xpath("//select[contains(@id,'CountryEntrustedPEP')]//option"));
        List <String> lstcounttxt=new ArrayList<String>();
        for(WebElement lstcount1:lstcount)
        {
            lstcounttxt.add(lstcount1.getText());
            wrap.wait(1000);
        }

        Iterator<String> it=lstcounttxt.iterator();
        while(it.hasNext()){logger.info("Business field Element text is" +it.next());}
    }
    @When("^CDDOAT: verify Name Screening Checks coapp$")
    public void verify_Name_screening_check_coapp() throws IOException, InterruptedException{

        String name_screeningprop = com.getElementProperties("CDDException", "CDD_Coapp_NorkMess");
        String name_screeningprop1 = com.getElementProperties("CDDException", "CDD_Coapp_BlistY");
        String name_screeningprop2 = com.getElementProperties("CDDException", "CDD_Coapp_BlistN");
        String name_screeningprop3 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedY");
        String name_screeningprop4 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedN");
        String name_screeningprop5 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedMatch");
        String name_screeningprop6 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedCred");
        String name_screeningprop7 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedCredY");
        String name_screeningprop8 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedCredN");
        String name_screeningprop9 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedCredMediaY");
        String name_screeningprop10 = com.getElementProperties("CDDException", "CDD_Coapp_AdMedCredMediaN");
        String name_screeningprop11 = com.getElementProperties("CDDException", "CDD_Coapp_AlEDDY");
        String name_screeningprop12 = com.getElementProperties("CDDException", "CDD_Coapp_AlEDDN");
        String name_screeningprop13 = com.getElementProperties("CDDException", "CDD_Coapp_IscustPEP");
        String name_screeningprop14 = com.getElementProperties("CDDException", "CDD_Coapp_CountEntrustPEP");


        utils.convertExcelToMap(excelPath,"RM_Workbasket.xls","CDD");
        //String nameScreen = utils.readColumn("Name Screening Checks", 0);

        String nameScreen =  CommonUtils.readColumnWithRowID("Detica Response", BaseProject.scenarioID);
        String nameScreen1 = CommonUtils.readColumnWithRowID("Sanction Disp", BaseProject.scenarioID);
        String nameScreen2 = CommonUtils.readColumnWithRowID("IsAdvMedia", BaseProject.scenarioID);
        String nameScreen3 = CommonUtils.readColumnWithRowID("IsAdvTrueMatch", BaseProject.scenarioID);
        String nameScreen4 = CommonUtils.readColumnWithRowID("IsAdvCredible", BaseProject.scenarioID);
        String nameScreen5 = CommonUtils.readColumnWithRowID("IsAdvMedConcern", BaseProject.scenarioID);
        String nameScreen6 = CommonUtils.readColumnWithRowID("CredMaterial", BaseProject.scenarioID);
        String nameScreen7 = CommonUtils.readColumnWithRowID("IsClientEDD", BaseProject.scenarioID);
        String nameScreen8 = CommonUtils.readColumnWithRowID("IscustPEP", BaseProject.scenarioID);
        String nameScreen9 = CommonUtils.readColumnWithRowID("PEPCountry", BaseProject.scenarioID);


        switchFrame();

        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Co-Applicant')]")).click();

        switch(nameScreen){

            case "Blacklist Match":

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop, nameScreen, "BYVISIBLETEXT");

                if(nameScreen1.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop1);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop2);
                }

                if(nameScreen2.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop3);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop4);
                }

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop5, nameScreen3, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop6, nameScreen4, "BYVISIBLETEXT");

                if(nameScreen5.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop7);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop8);
                }

                if(nameScreen6.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop9);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop10);
                }

                if(nameScreen7.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop11);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop12);
                }
                break;

            case "No Match Found":

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop, nameScreen, "BYVISIBLETEXT");

                if(nameScreen2.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop3);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop4);
                }
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop5, nameScreen3, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop6, nameScreen4, "BYVISIBLETEXT");

                if(nameScreen5.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop7);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop8);
                }
                if(nameScreen7.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop11);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop12);
                }
                break;

            case "Sanctions Match":

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop, nameScreen, "BYVISIBLETEXT");

                if(nameScreen1.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop1);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop2);
                }

                if(nameScreen2.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop3);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop4);
                }

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop5, nameScreen3, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop6, nameScreen4, "BYVISIBLETEXT");

                if(nameScreen5.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop7);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop8);
                }

                if(nameScreen6.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop9);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop10);
                }

                if(nameScreen7.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop11);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop12);
                }
                break;

            case "PEP Match":

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop, nameScreen, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop13, nameScreen8, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop14, nameScreen9, "BYVISIBLETEXT");

                if(nameScreen2.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop3);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop4);
                }

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop5, nameScreen3, "BYVISIBLETEXT");

                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, name_screeningprop6, nameScreen4, "BYVISIBLETEXT");

                if(nameScreen5.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop7);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop8);
                }

                if(nameScreen6.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop9);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop10);
                }

                if(nameScreen7.equalsIgnoreCase("YES")){
                    wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop11);}
                else {wrap.wait(500);
                    wrap.click(BaseProject.driver, name_screeningprop12);
                }
                break;


        }
    }
//Dinesh all changes are done - copied from jenkin pack
}
