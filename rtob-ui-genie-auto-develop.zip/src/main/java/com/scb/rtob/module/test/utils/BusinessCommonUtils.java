package com.scb.rtob.module.test.utils;


import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;



public class BusinessCommonUtils {
	
	private static Logger logger = Logger.getLogger(BusinessCommonUtils.class);
	
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static WebDriver driver;
	/*public SeleniumService service;
	public GenieScenario genieScenario;
	Properties CONFIG = new Properties();
	FileInputStream input = null;
	public BusinessCommonUtils() throws IOException
	{
		input = new FileInputStream(System.getProperty("user.dir")+File.separator+"src"+File.separator+"main"+File.separator+"java"+File.separator+"com"+File.separator+"standardchartered"+File.separator+"rtob"+File.separator+"config"+File.separator+"config.properties");
		CONFIG.load(input);
	}
	*/
	
	
public static void select_application_number(WebDriver driver,String appNumber) throws IOException, InterruptedException{

		
		Thread.sleep(1000);
		//String filter="(//a[@id='pui_filter'])[1]";
		String filter = com.getElementProperties("BasicData", "filter_link");
		String search = com.getElementProperties("BasicData","search_text");
		String apply_button = com.getElementProperties("BasicData","apply_button");
		
		wrap.click(driver, filter);
		Thread.sleep(3000);
		
		wrap.typeToTextBox(driver, appNumber, search);
		wrap.click(driver, apply_button);

		
		Thread.sleep(5000);
	
		driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
		//wrap.click(driver, "applicationNumber");
	}
	
	public static void check_application_number(WebDriver driver,String appNumber) throws IOException, InterruptedException{


	Thread.sleep(1000);

	String filter = com.getElementProperties("BasicData", "filter_link");
	String search = com.getElementProperties("BasicData","search_text");
	String apply_button = com.getElementProperties("BasicData","apply_button");
	try{
		//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
		driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).isDisplayed();
	}
	catch(org.openqa.selenium.NoSuchElementException e){
		wrap.click(driver, filter);
		Thread.sleep(1000);

		wrap.typeToTextBox(driver, appNumber, search);
		wrap.click(driver, apply_button);


		Thread.sleep(1000);
		//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();

	}
	Thread.sleep(1000);

}
	
	public static void verify_application_number(WebDriver driver, String id) throws InterruptedException, IOException {
		
		Thread.sleep(1000);
		//String filter="(//a[@id='pui_filter'])[1]";
		String filter = com.getElementProperties("BasicData", "filter_link");
		String search = com.getElementProperties("BasicData","search_text");
		String apply_button = com.getElementProperties("BasicData","apply_button");
		
		wrap.click(driver, filter);
		Thread.sleep(3000);
		
		//String appNumber = null;
		wrap.typeToTextBox(driver, id, search);
		wrap.click(driver, apply_button);
	    logger.info(id);
		
		Thread.sleep(5000);

		
	}
}
