package com.scb.rtob.module.test.framework.glue;

/***************************************************************************************
Project Name: RTOB - Base Project
Author: 
Version: V 1.0
Date of Creation: 17th March 2017
Modified By:
Reviewed By:
***************************************************************************************/
import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.awt.*;
import java.io.File;

import org.openqa.selenium.Dimension;

import java.net.URL;

import com.scb.rtob.module.test.utils.DBUtils;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xerces.impl.io.MalformedByteSequenceException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.SeleniumModule;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.config.DataModelExtraction;
import com.scb.rtob.module.test.framework.Commons;
//import com.standardchartered.techm.rtob.module.rtob.Read_xls;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.framework.XMLParser;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.scb.rtob.module.test.framework.XMLParser.envName;

public class BaseProject {
	
	static List<String> reportOrder= new ArrayList<String>();
	List <String> reportHeadersOrder= new ArrayList<String>();
	public static String testResultsFIleOrder;
	
	public static List<String> reportFieldVals= new ArrayList<String>();
	public static String testResultsFieldVals;

	List<String> report= new ArrayList<String>();
	List <String> reportHeaders= new ArrayList<String>();
	String expectedResult;
	String startDate;
	Date Stime;
	Date startTime;
	Date endTime;
	long executionDuration;
	Date time;
	int entry;
	
	public static String propertiesFilename = "BasicData";
	
	public static String scenarioID = null;
	static boolean resultSet = false;
	static boolean resultOrderSet = false;
	static boolean resultOrderHeaderSet = false;
	static boolean resultFieldValSet = false;
	static boolean resultFieldValHeaderSet = false;
	static String ModuleName = null;
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static SeleniumService seleniumService;
	public static GenieScenario genieScenario;
	public static WebDriver driver;
	public static String testResultsFIle;
	public static Robot r;
	public static String appId = null;
	CommonUtils utils= new CommonUtils(); 
	public static String excelPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"ExcelData";



//	public static String excelPath="C:"+File.separator+"BitBucket"+File.separator;
	public static String autoItPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"autoit";
	//public static String scenarioID="01";
	File file;
	private String actualresult;
	static Properties CONFIG ;
	static BusinessCommonUtils businesscommonutils= new BusinessCommonUtils();
	
	public static String UATExpectedResult=null;
	public static String UATTestCaseDescription=null;
	public static String UATTestScenarioID=null;
	
	public static Scenario scenario;
	//public static RemoteWebDriver driver;
	String browserType="chrome";
    DesiredCapabilities dr=null;
	public static String filepath=null;
	static HashMap<String, String> envmap= new HashMap<String, String>();
	
	private static Logger logger = Logger.getLogger(BaseProject.class);
	  
	public BaseProject()
	{	

		String envName = System.getProperty("env");
		logger.info("envName is " + envName);
		URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
		if (resource == null) {
			logger.info("resource is null");
			System.exit(1);
		}
			File file = null;
		FileInputStream fis = null;
		try {
		//	assert resource != null;
			if (resource != null) {
				file = new File(resource.toURI());
			}
			fis = new FileInputStream(file);
		} catch (FileNotFoundException | URISyntaxException e) {
			e.printStackTrace();
		}


		try {
		//	assert file != null;
			if (file != null) {
				fis = new FileInputStream(file);
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		Properties ENVCONFIG = new Properties();
		try {
			ENVCONFIG.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}

		for (String key : ENVCONFIG.stringPropertyNames()) {
			String value = ENVCONFIG.getProperty(key);;
			envmap.put(key, value);
		}

	}
	

	
	
	
	@When("^Open URL$")
	public void basic_open_the_application_URLtest() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		

        if(browserType.equals("chrome")){

        dr=DesiredCapabilities.chrome();

        dr.setBrowserName("chrome");

        dr.setPlatform(Platform.WINDOWS);

        }else{

                 dr=DesiredCapabilities.internetExplorer();

                 dr.setBrowserName("iexplore");

                 dr.setPlatform(Platform.WINDOWS);
				 
				 dr.setCapability("nativeEvents", false);
                 dr.setCapability("ACCEPT_SSL_CERTS", true);
                 dr.setCapability("unexpectedAlertBehaviour", "accept");
                 dr.setCapability("ignoreProtectedModeSettings", true);
                 dr.setCapability("disable-popup-blocking", true);                 
                 dr.setCapability("ignoreZoomSetting", true);
                 dr.setCapability("requireWindowFocus", true);
                 dr.setCapability("enablePersistentHover", false);

        }

        RemoteWebDriver driver=new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), dr);

        driver.navigate().to("http://10.20.234.174:12104/prweb/NOpTQhDcYLeog2Hhl-Fw2hMdMBgBIVQB*/!STANDARD");
        Thread.sleep(10000);
 
	}
	
	@Before
	public void beforeScenario(Scenario scenario) {
	    this.scenario = scenario;
	}
	
	@Before("@order")
	public void beforeOrder(Scenario scenario) throws Exception{
		
		if(resultOrderHeaderSet == false){
			
		 testResultsFIleOrder=System.getProperty("user.dir")+File.separator+ModuleName+"_"+"order"+"_"+new SimpleDateFormat("dd_MM_yyyy").format(new Date())+".csv";
		 logger.info(testResultsFIleOrder);
		 reportHeadersOrder.add("Actual,Expected,Result");
		 wrap.createNewCsv(testResultsFIleOrder, reportHeadersOrder);
		 System.out.println("size :"+reportHeadersOrder.size());
		 resultOrderHeaderSet = true;
		 
		}
	}
	
	@After("@order")
	public void afterOrder(Scenario scenario) throws Exception{
		
		if(resultOrderSet == false){
		
		wrap.writeOutPutToCSV(testResultsFIleOrder, reportOrder);
		resultOrderSet = true;
	
		}
		
	}
	
	@Before("@fieldVals")
	public void beforeFieldVals(Scenario scenario) throws Exception{
		
		if(resultFieldValHeaderSet == false){
			
		 testResultsFieldVals=System.getProperty("user.dir")+File.separator+ModuleName+"_"+"fieldVals"+"_"+new SimpleDateFormat("yyyy_MM_dd_HH_mm").format(new Date())+".csv";
		 logger.info(testResultsFieldVals);
		 reportFieldVals.add("Field Name,Tab Result,Section Result,Editable Result,Datatype Result,Dataformat Result,SingleMulti Result,Mandatory Result,Length Result,Derived Result");
		 wrap.createNewCsv(testResultsFieldVals, reportFieldVals);
		 System.out.println("size :"+reportHeadersOrder.size());
		 resultFieldValHeaderSet = true;
		 reportFieldVals.clear();
		 
		}
	}
	
	@After("@fieldVals")
	public void afterFieldVals(Scenario scenario) throws Exception{
		
		if(resultFieldValSet == false){
			
			logger.info("writing Field Vals report");
		
		wrap.writeOutPutToCSV(testResultsFieldVals, reportFieldVals);
		resultFieldValSet = true;
	
		}
		
	}
	
	public static void verifyFieldOrder(List <String> labels, String excelPath, String excelFile, String excelSheet) throws Throwable {
		
		CommonUtils.convertExcelToMap(excelPath, excelFile,excelSheet );
		
		System.out.println("size :"+labels.size());
		
		for(String ele : labels)
		{
			logger.info(ele.equalsIgnoreCase(CommonUtils.readColumn("Field Name", labels.indexOf(ele))));		
			BaseProject.reportOrder.add(ele+","+CommonUtils.readColumn("Field Name", labels.indexOf(ele))+","+ele.equalsIgnoreCase(CommonUtils.readColumn("Field Name", labels.indexOf(ele))));
		}
		
		CommonUtils.convertExcelToMap(BaseProject.excelPath, "Document_Indexing.xls", "data");
		
	}
	
	
    /**
    * @param expectedCondition,Expected condition for this particular scenario,which will be entered in the report
    */
    @When("^expected condition is '(.*)'$")
    public void setExpectedCondition(String expectedCondition){
           
           this.expectedResult=expectedCondition;
           System.out.println("\nsetExpectedCondition:" + expectedResult);
    }

	
	public void write_report_in(String realtivePath) throws IOException{

		wrap.writeOutPutToCSV(realtivePath, report);
	}
	
	@Then("^write report header$")
	public void writeReportHeader() throws IOException{
		logger.info("Report Header is loaded");
		 /*if(driver==null)
		 {
			 seleniumService.getWebDriver().get(CONFIG.getProperty("ApplicationURL"));
			 driver=seleniumService.getWebDriver();
		 }*/
		 testResultsFIle=System.getProperty("user.dir")+File.separator+ModuleName+"_"+new SimpleDateFormat("yyyy_MM_dd_HH_mm").format(new Date())+".csv";
		 logger.info("Report Header1 is loaded");
		 System.out.println(testResultsFIle);
		 logger.info("Report Header2 is loaded");
		 reportHeaders.add("Module Name,Scenario id,Scenario Description,Expected Result,Actual Result,Status,Execution Date,Start Time,End Time,Duration in Sec,ScreenShot Location,ApplicationID,UATScenarioID,UATTestCaseDescription,UATTestExpectedResults");
		 //reportHeaders.add(",,,,,,,,,");//Balaji - added
		 wrap.createNewCsv(testResultsFIle, reportHeaders);
		 
		
	}


@Before("@selenium")
    public void before(Scenario scenario) throws Exception {
		//startRecording();
		entry=1;
		Stime=Calendar.getInstance().getTime();
		this.genieScenario = (GenieScenario)scenario;
        this.seleniumService= genieScenario.getRuntime().getAttribute(SeleniumModule.SELENIUM_SERVICE, SeleniumService.class);

        String scen[]=scenario.getName().split("_");
		ModuleName=scen[0];
		scenarioID = scen[1];
		System.out.println("sceanrioID : "+scenarioID);
		resultSet = false;
        
    }

	
	 @When("^actual condition is'(.*)'$")
	    public void setActualCondition(String actualCondition){
	           
	           this.actualresult=actualCondition;
	           System.out.println("\nsetActualCondition:" + actualresult);
	    }
	
    @When("^custom step definition which opens link '(.+)'$")
    public void sampleUserDefinedOpenLink(String url) {
    	
    	
        seleniumService.getWebDriver().get(envmap.get(url));
        driver=seleniumService.getWebDriver();
		//java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        //driver.manage().window().setSize(new Dimension(screenSize.width, screenSize.height));
		//driver.manage().window().setSize(new Dimension(2600,1600));
        
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
        
        if(envmap.get("browser").equalsIgnoreCase("ie")){
        	driver.navigate ().to ("javascript:document.getElementById('overridelink').click()");
        }
 
        
        }
	@Given("^enter valid credentials '(.+)' and '(.+)'$")
	public static void enter_valid_credentails(String username,String password) throws Throwable 
	{
		System.out.println(com.getElementProperties("ProductCatalogue", "home_login_username"));
		//wrap.starttimer();
		//wrap.type(driver,CONFIG.getProperty(username),com.getElementProperties("ProductCatalogue", "home_login_username"));
		wrap.type(driver,envmap.get(username),com.getElementProperties("ProductCatalogue", "home_login_username"));
		//wrap.endtimer();
		wrap.type(driver,envmap.get(password),com.getElementProperties("ProductCatalogue", "home_login_password"));
		
		wrap.click(driver,com.getElementProperties("ProductCatalogue", "home_login_submit"));
		
		
	
	}
	
	@Given("^Launch the App Workflow User portal$")
	public static void launch_the_App_Workflow_User_portal() throws Throwable 
	{
	    wrap.click(driver, com.getElementProperties("ProductCatalogue", "appflow_launch"));
	    wrap.wait(500);
	    wrap.click(driver, com.getElementProperties("ProductCatalogue", "appflow_appWorkflow_portal"));
	    wrap.wait(2000);
	}
	
	
	//This method is for 'Click' and navigate to 'Onboarding Screen'
	
	@Given("^create onboarding$")
	public static void createOnboarding() {
		try{
			
			wrap.switch_to_default_Content(BaseProject.driver);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		String createlink = com.getElementProperties("ProductCatalogue", "createLink");
		String onbording = com.getElementProperties("ProductCatalogue", "onbordingLink");

		wrap.click(driver, createlink);
		wrap.click(driver, onbording);


		wrap.switch_to_Iframe(driver,com.getElementProperties("ProductCatalogue", "ProductCatalogue_PegaGadget1"));
		}
		catch(Exception e)
		{
			System.out.println("Unable to click on Onboarding"+e);
		}
	}
	
	/*This method is for getting the application id*/
	

	@Then("^Select the Basic Data Capture Screen '(.*)'$")
	public static boolean Select_BasicDataCapture_Screen(String screenName) throws Throwable
	{
		wrap.wait(2000);
		wrap.switchToWindow(BaseProject.driver, "AppWorkFlow User Portal");
		wrap.wait(10);
		wrap.click(BaseProject.driver, com.getElementProperties("ProductCatalogue", "ProductCatalogue_WorkBasket_WorkBasket_Button_XPATH"));
		wrap.wait(10);
	
		boolean isWorkBasketNameFound=false;
		boolean isleftpaneWBNFound=false;
		try
		{
			
			wrap.wait(2000);
			isleftpaneWBNFound = BaseProject.driver.findElement(By.xpath("//div[@id='gridBody_right']//span[@data-name='"+screenName+"']")).isDisplayed();
			System.out.println("Edd reviewer is displayed in the left pane: "+ isleftpaneWBNFound);
			if(isleftpaneWBNFound==true)
			wrap.click(BaseProject.driver, com.getElementProperties("AddlDocUploadClassify", "BasicDataCapture_Link"));
			wrap.wait(2500);
			 
			 
		}
		catch(Exception e)
		{
			System.out.println("Edd reviewer is not in the leftpaen so click on see all option");
			wrap.wait(2000);
			
			wrap.click(BaseProject.driver, com.getElementProperties("AddlDocUploadClassify", "seeall_option"));
			wrap.wait(2000);
			String pageCount =  wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("AddlDocUploadClassify", "pageCount_Allmodules")).getText();

			System.out.println(pageCount);
			for(int i=1;i <= Integer.parseInt(pageCount);i++)
			{
				List<WebElement> workBasketNameList = wrap.getElements(BaseProject.driver, "//div[@class='modal-overlay']//span[@data-name]");
				for (int j=0;j<workBasketNameList.size();j++)
				{
					System.out.println(workBasketNameList.get(j).getText());

					if(workBasketNameList.get(j).getText().trim().equalsIgnoreCase(screenName))
					{
						System.out.println("Matching screen name : " + workBasketNameList.get(j).getText());
						workBasketNameList.get(j).click();
						isWorkBasketNameFound = true;
						//if()
						wrap.click(BaseProject.driver, "//div[@class='modal-overlay']//button[@id='ModalButtonSubmit']");
						wrap.wait(2000);		
						break;
					}

				} 
				if(!isWorkBasketNameFound)

					wrap.click(BaseProject.driver,"//div[@class='modal-overlay']//table[contains(@id,'paginator')]//td[7]//button");
				wrap.wait(2000);
			}
			

		}
		return isWorkBasketNameFound;
		
	}
	
	@Given("^filter application number$")
	public void selectApplicationNumber()
	{
		try{
		System.out.println("select an appln number");
		wrap.switch_to_Iframe(BaseProject.driver, com.getElementProperties("ProductCatalogue", "ProductCatalogue_PegaGadget0"));
		wrap.wait(3000);
		utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","Sheet2");
		String appId = utils.readColumn("ApplicationId",0);
		System.out.println("appId : "+appId);
		businesscommonutils.select_application_number(BaseProject.driver, appId);
		wrap.wait(5000);
		driver.navigate().refresh();
		wrap.wait(2000);
		wrap.switch_to_Iframe(driver, com.getElementProperties("ProductCatalogue", "ProductCatalogue_PegaGadget1"));
		boolean isDisabled = driver.findElement(By.xpath("//span[text()='Primary Applicant']/ancestor::td/following-sibling::td//a")).isDisplayed();
		System.out.println("Is disabled ===== "+isDisabled);
		wrap.wait(3000);
		WebElement element =driver.findElement(By.xpath("//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", element);
		wrap.wait(2000);
		}
		catch(Exception e){
			System.out.println("The application number is not available"+e);
	}
	}
	
	/*This method is for handling warning message when user tries to close the channel*/
	
	@Given("^handling error message$")
	public void handlingWarningMessage(){
		try{
		driver.navigate().refresh();
		String createlink = com.getElementProperties("ProductCatalogue", "createLink");
		String onbording = com.getElementProperties("ProductCatalogue", "onbordingLink");
		String branchCode = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_BranchCode_TextBox_Id");
		String cancel = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_Cancel_Button_XPATH");
		
		wrap.click(driver, createlink);
		wrap.click(driver, onbording);
		
		wrap.switch_to_Iframe(driver,com.getElementProperties("ProductCatalogue", "ProductCatalogue_PegaGadget1"));
		
		wrap.wait(2000);
		
		utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","ProdCat");
		
		wrap.wait(1000);
		
		String branchCode1 = utils.readColumnWithRowID("BrachCode",BaseProject.scenarioID);
		System.out.println("branchCode1 ===== "+branchCode1);
		String actualBranchCode = branchCode1.replaceAll(File.separator+".0*$", "");
		System.out.println("actualBranchCode ===== "+actualBranchCode);
		
		wrap.typeToTextBox(driver, actualBranchCode, branchCode);
				
		String product1 = utils.readColumn("ProductCode_Description",0);
		System.out.println("product1 ===== "+product1);
		List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(",")));
		System.out.println("myList ===== "+myList);
		String prdcode = com.getElementProperties("ProductCatalogue", "productCode");
		System.out.println("prdcode ===== "+prdcode);
		System.out.println("myList.get(0) ===== "+myList.get(0));
		String mycheckbox=prdcode.replace("**data**", myList.get(0));
		wrap.click(driver, mycheckbox);

		wrap.click(driver, cancel);
		
		wrap.wait(2000);
		

		driver.findElement(By.xpath("//button[@accesskey='i']//div[@class='pzbtn-mid']")).click();
		wrap.wait(3000);
		}
		catch(Exception e){
			System.out.println("The error message is not getting displayed"+e);
	}
	}
	
	
	@When("^Logout$")
	public void logout() throws IOException, InterruptedException
	{
		wrap.logout();
		
	}
	
	
	public static void selectFrame(int difference){
        System.out.println("selectFrame ");
        try {
            int FrameNumber = BaseProject.driver.findElements(By.xpath("//iframe")).size();
            wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget"+(FrameNumber-difference)+"Ifr");
            System.out.println("PegaGadget"+(FrameNumber-difference)+"Ifr");
        }catch (Exception e){
            e.getMessage();
        }
    }
	

	@Given("^Switch to App Workflow window$")
	public static void switch_App_Workflow_User_portal() throws Throwable 
	{
		wrap.switchToNewWindow1(BaseProject.driver, 2);
	    wrap.wait(500);
	}
	

	@Given("^Switch to Pega Designer Studio window$")
	public void switch_pega_design_window() throws Throwable 
	{
		
		System.out.println(BaseProject.driver.getTitle());
		 wrap.switchToWindow(BaseProject.driver,"Pega Designer Studio");
	    System.out.println(BaseProject.driver.getTitle());
	    wrap.wait(1000);
	}
	
	@Given("^pega designer studio logout$")
	public void Pega_design_window_logout() throws Throwable 
	{
		wrap.switchToNewWindow1(BaseProject.driver, 1);
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//i[@title='DevR2Testing']")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Log off')]")).click();
		wrap.wait(1000);
	}
	
	
  
    
    @Given("^Check system functionality on save$")
    public void saveCurrentApplication() throws Throwable{
        wrap.click(driver, com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_Save_Button_XPATH"));
        wrap.wait(3000);
    }
    
  
    
    public static void switchFrame() throws InterruptedException{
        int Last=0;
        BaseProject.driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        List<WebElement> frames=BaseProject.driver.findElements(By.tagName("iframe"));
        for(WebElement frame: frames){
            
            System.out.println(frame.getAttribute("Name"));
        }
 
        Last=frames.size()-1;
        System.out.println(Last);
        BaseProject.driver.switchTo().frame(Last);
        //Thread.sleep(2000);
    }
        
    @Given("^Go to workbasket '(.*)'$")
	public void go_to_workbasket(String screenname) throws Throwable {
	    
		 wrap.switch_to_default_Content(BaseProject.driver);
			wrap.wait(3000);
			wrap.waitForElement(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "work_basket_option"), 20,"visible");
			
			if(!wrap.isElementPresent(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"))){
				wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "work_basket_option"));	
				
			}
			
			wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"));
			
			try{
                  
                        wrap.getWorkbasketoption(BaseProject.driver,screenname);
              
                  }
			
			catch (Exception E) {
			
						//wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));
                        wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"));
                        wrap.getWorkbasketoption(BaseProject.driver,screenname);
			
			}
			
		   	wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "modal_submit_button"));
			wrap.wait(500);
	}
    
    @When("^Enter credentials '(.+)' and '(.+)'$")
    public void loginToConfluence(String userId,String password) throws InterruptedException, IOException{
           
           wrap.type(driver,envmap.get(userId),com.getElementProperties("Confluence", "confluence_userName"));
           //wrap.endtimer();
           wrap.type(driver,envmap.get(password),com.getElementProperties("Confluence", "confluence_Password"));
           
           wrap.click(driver,com.getElementProperties("Confluence", "confluence_Login"));
    }
    
    @When("^Enter the workbasket name '(.+)'$")
    public void enterTheWorkbasketName(String workBasketName) throws IOException{
           int rowCount = 0;
           XSSFWorkbook wb1 = new XSSFWorkbook();
           String textString = workBasketName;
           /**********USER-INPUT***************/
           
           String RootNodeLocator = "//a[text()=\'"+textString+"\']";
           WebElement SheetName = driver.findElement(By.xpath(RootNodeLocator));
           SheetName.findElement(By.xpath("preceding::div[1]/a")).click();
           String NameOfSheet = SheetName.getText();
           XSSFSheet sh1 = wb1.createSheet(NameOfSheet);
           String TabNameCol = RootNodeLocator+"/ancestor::div[1]/following-sibling::div/ul/li";
           //ChildNode expand-icon click
           List <WebElement> TabNames = driver.findElements(By.xpath(TabNameCol));
           int TabNamesSize = TabNames.size();
           System.out.println(TabNamesSize);
           int main_loop_flag=1;
           
           while(main_loop_flag <=TabNamesSize){
                  WebElement TabName = null;
                  String TabNameLoc = TabNameCol+"["+main_loop_flag+"]/div[2]/span/a";
                  //String TabNameLoc = TabNameCol+"/span/a";
                  TabName = driver.findElement(By.xpath(TabNameLoc));
                  String TabNameString = TabName.getText();
                  System.out.println(TabNameString);
                  TabName.click();
           
           
           
                  String sectionString = TabNameLoc+"[text()=\'"+TabNameString+"\']/ancestor::div[1]/following-sibling::div/ul/li/div[2]";
                  List <WebElement> section = driver.findElements(By.xpath(sectionString));
                  int loop = section.size();
                  System.out.println(loop);
                  WebElement sectionName = null;
                  int loop_flag = 1;
                  while (loop_flag <= loop){
                        
                        String subnode_we_loc = "//a[text()=\'"+TabNameString+"\']/ancestor::div[1]/following-sibling::div/ul/li["+loop_flag+"]/div[2]/span/a";
                        sectionName = driver.findElement(By.xpath(subnode_we_loc));
                        
                               
                        String SectionLinkName = sectionName.getText();
                        System.out.println(SectionLinkName);
                        
                        sectionName.click();
                        

                        rowCount = DataModelExtraction.readHTMLTable(sh1, driver,0, rowCount, SectionLinkName, TabNameString);
    
                  //rowCount = readConfluenceTable(sh1, driver, rowCount);
                  rowCount++;
    
                  loop_flag++;
           }
                  main_loop_flag++;
                                                           
           }
           DataModelExtraction.writeToExcel(wb1,NameOfSheet);
           wb1.close();
    }

    
    
}
