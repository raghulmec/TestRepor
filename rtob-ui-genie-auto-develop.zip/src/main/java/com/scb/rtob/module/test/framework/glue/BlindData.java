package com.scb.rtob.module.test.framework.glue;
import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.SeleniumModule;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;
import com.scb.rtob.module.test.framework.glue.BaseProject;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static com.scb.rtob.module.test.framework.XMLParser.envName;

public class BlindData {
    List<String> reportHeaders = new ArrayList<String>();
    String expectedResult;
    String startDate;
    Date Stime;
    Date startTime;
    Date endTime;
    long executionDuration;
    Date time;
    int entry;

    static Wrapper wrap = new Wrapper();
    static Commons com = new Commons();
    public static SeleniumService seleniumService;
    public static GenieScenario genieScenario;
    //public static WebDriver driver=BaseProject.driver;
    public static String testResultsFIle;
    public static String screenShotPath = "C:/R2/Blind screen shot";
    public static Robot r;
    public static String appId = null;
    public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60, 1000);
    public static List<HashMap<String, String>> mydata = new ArrayList<HashMap<String, String>>();
    static CommonUtils utils = new CommonUtils();
    public static String excelPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ExcelData";
    File file;
    Properties CONFIG;
    private static Logger logger = Logger.getLogger(BaseProject.class);
    //public static WebDriverWait wait=new WebDriverWait(BaseProject.driver, 30);

    {
        String envName = System.getProperty("env");
        URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
        File file = null;
        FileInputStream fis = null;
        try {
            file = new File(resource.toURI());
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        CONFIG = new Properties();
        try {
            CONFIG.load(fis);
        } catch (IOException e) {

            e.printStackTrace();
        }

    }

    @Then("^Blind: select an application number$")
    public static void select_an_application_number()throws IOException, InterruptedException, ClassNotFoundException, SQLException {
        
        String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);
        //String appId = "IN20171202100113";
        logger.info("The Value going to select or Filter is [" + appId + "]");
        wrap.wait(3000);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");

        String filter = com.getElementProperties("Fulldatacapturemaker","filter_link");
        String search = com.getElementProperties("Fulldatacapturemaker","search_text");
        String apply_button = com.getElementProperties("Fulldatacapturemaker","apply_button");
        
        wrap.fluentWait( BaseProject.driver, filter);
        if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","filter_link"))){
        	
        	 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(filter)));
             wrap.click(BaseProject.driver, filter);
             logger.info("Filter Link Clicked on FIRST Time");
        
        } else {
        	
        	new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(filter)));
        	wrap.click(BaseProject.driver, filter);
        	logger.info("Filter Link Clicked on SECOND Time");    
        }
        
        new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(search)));
        wrap.type(BaseProject.driver, appId, search);
        wrap.click(BaseProject.driver, apply_button);

        try {
        	
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='" + appId + "']")));
            WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='" + appId + "']")));
            wrap.click(BaseProject.driver, "//span[text()='" + appId + "']");
            logger.info("Clicked on the  span[text()='" + appId + "'] Field");
            
        }  catch (Exception e) {
        	
            logger.info("Error clicking application ID: " + appId);
            e.printStackTrace();
            throw new InterruptedException();
        }
       

    }



    public static void waitUntilVisibilityOfWebElement(String attribute) {
        wait.ignoring(StaleElementReferenceException.class);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, attribute)));

    }

    public static void waitUntilVisibilityOfWebElement(WebElement elem) {
        wait.ignoring(StaleElementReferenceException.class);
        wait.until(ExpectedConditions.visibilityOf(elem));

    }


    public static boolean verifyTextBoxThnClick(WebDriver driver, String attribute) throws InterruptedException {
        try {
            wrap.fluentWait(driver, attribute);
            wrap.click(driver, attribute);

            while (!wrap.getElement(driver, attribute).isEnabled()) {
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, attribute)));
                if (!wrap.getElement(driver, attribute).isEnabled()) {
                    wrap.getElement(driver, attribute).click();
                }
            }
            return true;
        } catch (InvalidElementStateException e) {
            logger.info(e);
            logger.info(attribute);
            verifyTextBoxThnClick(driver, attribute);
            return true;
        }
    }



	/*@Before("@selenium")
    public void before(Scenario scenario) throws Exception {
		//startRecording();
		entry=1;
		Stime=Calendar.getInstance().getTime();
		this.genieScenario = (GenieScenario)scenario;
        this.seleniumService= genieScenario.getRuntime().getAttribute(SeleniumModule.SELENIUM_SERVICE, SeleniumService.class);

        String scen[]=scenario.getName().split("_");
		String ModuleName=scen[0];


    }*/

    /**
     * //* @param expectedCondition,Expected condition for this particular scenario,which will be entered in the report
     */

	/*@After("@selenium")
    public void getScreenShotAfterScenarios(Scenario scenario) throws Exception {
		String result;
		String screenShotname;
		String screenShotPath;

		startDate=wrap.getDateTime("date");
		Date eTime=Calendar.getInstance().getTime();
		executionDuration=(eTime.getTime()-Stime.getTime())/1000;

		String startTime=new SimpleDateFormat("hh:mm:ss").format(Stime);
		String endTime=new SimpleDateFormat("hh:mm:ss").format(eTime);

		String scen[]=scenario.getName().split("_");
		String userStoryId=scen[0];
		String scenarioId=scen[1];
		String scenarioDesc=scen[2];

		 Date dNow = new Date();
	      SimpleDateFormat ft =
	      new SimpleDateFormat ("dd_MM_yyyy_'at'_hh_mm_ss_a");
	      logger.info(ft.format(dNow));
		String screenshotTakenTime=ft.format(dNow);

		screenShotname=userStoryId+"_"+scenarioId+"_"+screenshotTakenTime+".jpg";

		screenShotPath=CONFIG.getProperty("ScreenshotLocation");
		String newScreenShotPath=CONFIG.getProperty("ScreenshotLocation")+File.separator+screenShotname;
		if(!userStoryId.equalsIgnoreCase("reportHeader")){
			//writeReportHeader() ;
			wrap.screenShot(seleniumService.getWebDriver(),screenShotPath,screenShotname);//this will take screen shot
			if (scenario.isFailed()){
				result=userStoryId+","+scenarioId+","+scenarioDesc+","+expectedResult+","+"Fail"+","+startDate+","+startTime+","+endTime+","+executionDuration+","+newScreenShotPath;
				report.add(result);

			}
			else{
				result=userStoryId+","+scenarioId+","+scenarioDesc+","+expectedResult+","+"Pass"+","+startDate+","+startTime+","+endTime+","+executionDuration+","+newScreenShotPath;

				report.add(result);
			}
			logger.info(testResultsFIle);
			write_report_in(testResultsFIle);
		}
		//stopRecording();
	}

	public void write_report_in(String realtivePath) throws IOException{

		wrap.writeOutPutToCSV(realtivePath, report);
	}
	 */
    /*@Then("^write report header$")
    public void writeReportHeader() throws IOException{
		 if(BaseProject.driver==null)
		 {
			 seleniumService.getWebDriver().get(CONFIG.getProperty("ApplicationURL"));
			 BaseProject.driver=seleniumService.getWebDriver();
		 }
		 testResultsFIle=System.getProperty("user.dir")+File.separator+new SimpleDateFormat("dd_MM_yyyy").format(new Date())+".csv";
		 logger.info(testResultsFIle);
		 reportHeaders.add("Module Name,Scenario id,Scenario Description,Expected Result,Status,Execution Date,Start Time,End Time,Duration in Sec,ScreenShot Location");
		 wrap.createNewCsv(testResultsFIle, reportHeaders);
		 //wrap.writeOutPutToCSV("", reportHeaders);//wrtie report headers in csv,add this in first method

	}*/





	/*@Given("^Blind: open the application URL$")
	public void openURL() throws InterruptedException {
		System.setProperty("webBaseProject.driver.chrome.BaseProject.driver",
				"C:"+File.separator+"New folder"+File.separator+"Genie3.3"+File.separator+"drivers"+File.separator+"chrome"+File.separator+"2.26"+File.separator+"chromeBaseProject.driver.exe");
		BaseProject.driver = new ChromeDriver();
		String URL = "https://10.20.234.172:8080/prweb/";
		logger.info(URL);
		BaseProject.driver.get(URL);
		wrap.wait(1000);
		BaseProject.driver.manage().window().maximize();
		// BaseProject.driver.quit();
	}

	@Given("^Blind: enter valid credentials$")
	public void enter_valid_credentails() throws Throwable {
		wrap.type(BaseProject.driver, "1539169",
				com.getElementProperties("BasicData", "home_login_username"));
		wrap.type(BaseProject.driver, "rules",
				com.getElementProperties("BasicData", "home_login_password"));
		wrap.wait(1000);
		wrap.click(BaseProject.driver,
				com.getElementProperties("BasicData", "home_login_submit"));
		wrap.wait(1000);
	}

	@Given("^Blind: Launch the App Workflow User portal$")
	public void launch_the_App_Workflow_User_portal() throws Throwable {
		wrap.click(BaseProject.driver,
				com.getElementProperties("BasicData", "appflow_launch"));
		wrap.wait(500);
		wrap.click(BaseProject.driver, com.getElementProperties("BasicData",
				"appflow_appWorkflow_portal"));
		wrap.wait(1000);
	}

	@Given("^Blind: Switch to App Workflow window$")
	public void switch_App_Workflow_User_portal() throws Throwable {
		logger.info(BaseProject.driver.getTitle());
		wrap.switchToWindow(BaseProject.driver, "AppWorkFlow User Portal");
		logger.info(BaseProject.driver.getTitle());
		wrap.wait(500);
	}

	public static void select_application_number(WebDriver BaseProject.driver,
			String appNumber) throws IOException, InterruptedException {

		wrap.wait(1000);

		String filter = com.getElementProperties("BasicData", "filter_link");
		String search = com.getElementProperties("BasicData", "search_text");
		String apply_button = com.getElementProperties("BasicData",
				"apply_button");

		wrap.click(BaseProject.driver, filter);
		wrap.wait(1000);

		wrap.typeToTextBox(BaseProject.driver, appNumber, search);
		wrap.wait(500);

		wrap.click(BaseProject.driver, apply_button);

		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='" + appNumber + "']"))
				.click();
		// wrap.click(BaseProject.driver, "applicationNumber");
	}
	 */
    @Given("^Blind: Go to Blind Data Capture home page$")
    public static void select_an_application_number1() throws IOException, InterruptedException {
    	wrap.switch_to_default_Content(BaseProject.driver);

        try {
        	
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
            logger.info("Clicked - work_basket_option");
            
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
            logger.info("Clicked - seeall_option");
            
            wrap.getWorkbasketoption(BaseProject.driver, "Blind Data Capture Maker");
            logger.info("getWorkbasketoption - Blind Data Capture Maker");
            
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
            logger.info("Clicked - modal_submit_button");
            
        } catch (Exception e) {
        	
            logger.error("Unable to go to BDC home page");
            e.printStackTrace();
            Assert.fail();
        }

    } 


    // public void Go_to_Basic_Data_Capture_page() throws Throwable {
    // wrap.switchToWindow(BaseProject.driver, "AppWorkFlow User Portal");
    // wrap.wait(10);
    // wrap.click(BaseProject.driver, com.getElementProperties("BasicData",
    // "Section_WorkBasket_Button_XPATH"));
    // wrap.wait(10);

    // wrap.click(BaseProject.driver,
    // com.getElementProperties("BasicData","Section_BasicData_Button_ID"));
    // wrap.wait(500);
    // wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
    // //wrap.wait(1000);
    // wrap.click(BaseProject.driver, com.getElementProperties("BasicData",
    // "Section_Applicantid_Filter_Button_XPATH"));
    // wrap.type(BaseProject.driver, "IN2017031000010", "Section_SearchText_TextBox_ID");
    // wrap.click(BaseProject.driver, "Section_Apply_Button_XPATH");

    /*@SuppressWarnings("deprecation")
	public void convertExcelToMap(String sheetName) throws IOException {
		mydata.clear();
		String path = "C:"+File.separator+"New folder"+File.separator+"Genie3.3"+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"BasicData_Test data_sheet1.xls";
		FileInputStream fin = new FileInputStream(path);
		book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				Cell currentCell = currentRow.getCell(j);
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					System.out.print(currentCell.getStringCellValue() + "|");
					break;
				case Cell.CELL_TYPE_NUMERIC:
					System.out.print(currentCell.getNumericCellValue() + "|");
					break;
				}
			}
			logger.info("\n");
		}
		// List<HashMap<String, String>> mydata = new ArrayList<HashMap<String,
		// String>>();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			HashMap<String, String> currentHash = new HashMap<String, String>();
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				Cell currentCell = currentRow.getCell(j);
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(),
							currentCell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_NUMERIC:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(),
							String.valueOf(currentCell.getNumericCellValue()));
					break;
				}
			}
			// logger.info(currentHash.get("username"));
			mydata.add(currentHash);
		}
		logger.info(mydata);
		logger.info(mydata.get(0));
	}


	 * @When("^Blind: Read username from excel$") public void readFromMap() throws
	 * IOException{ convertExcelToMap("BasicData");
	 * readColumn("Document Number",1); convertExcelToMap("BasicData1");
	 * readColumn("Document Number",1); }


	public String readColumn(String column, int row) {
		HashMap<String, String> map = mydata.get(row);
		String result = null;
		for (Entry<String, String> entry : map.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(column)) {
				logger.info(entry.getValue());
				result = entry.getValue();
			}

		}
		return result;

	}
	 */
    @Given("^Blind: Switch to frame$")
    public static void switchFrame() throws InterruptedException {
        int Last = 0;
        wrap.wait(500);
        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(500);
        List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
        for (WebElement frame : frames) {

            logger.info(frame.getAttribute("Name"));
        }

        Last = frames.size() - 1;
        logger.info(Last);
        BaseProject.driver.switchTo().frame(Last);
        wrap.wait(500);

        logger.info("Frame switched successfully");
    }


    @When("^Blind: click on Customer Details tab$")
    public void click_on_Customer_Details_tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        wrap.wait(500);
        switchFrame();
        String cust_details = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
        wrap.click(BaseProject.driver, cust_details);
    }


    @When("^Blind: Validate the title for minor customers$")
    public static void validate_title_for_minor() throws IOException {
        String TitleMinorError1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_TitleErrorForMinor1");
        String TitleMinorError2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_TitleErrorForMinor2");
        wrap.isElementPresent(BaseProject.driver, TitleMinorError1);
        wrap.isElementPresent(BaseProject.driver, TitleMinorError2);
    }


    /**
     * @throws Throwable
     */
    @When("^Blind: validate optional and mandatory fields in Customer Personal Details section$")
    public void validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //	wrap.wait(10000);

        //switchFrame();
		/*JavascriptExecutor js = (JavascriptExecutor)BaseProject.driver;
				js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
				wrap.wait(30000);*/
        //BaseProject.driver.findElement(By.xpath("//button[@title='Complete this assignment']/descendant::div/img[1]")).click();


        //************Thiyanesh**************/


        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
        String FullName1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
        String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
        String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
        String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
        String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
        String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");


        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");


        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

        //	//convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
        String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
        String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
        String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
        String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
        String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
        String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);
        String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code2", BaseProject.scenarioID);
        String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description2", BaseProject.scenarioID);
        String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID);
        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID);
        String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
        String Alias = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
        String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code", BaseProject.scenarioID);
        String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
        String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
        String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);


        logger.info("Going to switch into frame");

        switchFrame();
		/*BaseProject.driver.switchTo().defaultContent();
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");*/

        logger.info("Frame switched successfully");

        String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


        String Customersection = com.getElementProperties("BasicData", "Customersection");
        String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
        if (CustomerSection.equals("false")) {
            wrap.click(BaseProject.driver, Customersection);

        }

		/*String appRef = com.getElementProperties("ProductCatalogue", "appRefNo1");
		appId=wrap.getTextValue(BaseProject.driver, appRef).trim();
		appId = appId.replace("(","");
		appId = appId.replace(")","");
		System.out.println("Application id after ==== " +appId);

		String pattern="^[a-z A-Z 0-9]*$";
		if(appId.matches(pattern))
		{
				System.out.println(appId+" is alphanumeric" +"It should be Alphabets");
		}	 else
		{		 System.out.println(appId+" is not  alphanumeric");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "AppRefNo");*/

        //wrap.wait(1000);
        waitUntilVisibilityOfWebElement(Title);
        wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
        wrap.screenShot(BaseProject.driver, screenShotPath, "title");

        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(FirstName);
        wrap.click(BaseProject.driver, FirstName);
        //verifyTextBoxThnClick(BaseProject.driver,FirstName);
        wrap.type(BaseProject.driver, First_Name, FirstName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Firstname");


        //waitunlitVisiblityOfWebElement(MiddleName);
        wrap.click(BaseProject.driver, MiddleName);
        wrap.wait(4500);
        wrap.type(BaseProject.driver, Middle_Name, MiddleName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "MiddleName");


        //waitunlitVisiblityOfWebElement(LastName);
        //verifyTextBoxThnClick(BaseProject.driver,LastName);
        wrap.click(BaseProject.driver, LastName);
        wrap.wait(2500);
        wrap.type(BaseProject.driver, Last_Name, LastName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "LastName");

        //wrap.wait(500);
        //waitunlitVisiblityOfWebElement(FullName);
        //wrap.click(BaseProject.driver, LastName);
        //verifyTextBoxThnClick(BaseProject.driver,FullName);


        //wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(DateOfBirth1);
        verifyTextBoxThnClick(BaseProject.driver, DateOfBirth1);
        wrap.enterDate(BaseProject.driver, DOB, DateOfBirth1);
        wrap.screenShot(BaseProject.driver, screenShotPath, "DateofBirth");

        waitUntilVisibilityOfWebElement(FullName);
        wrap.wait(1000);
        String FullNamevalue = BaseProject.driver.findElement(By.id("FullName")).getAttribute("value");
        logger.info("FullNamevalue is" + FullNamevalue);
        wrap.wait(1000);
        String Fullnamefrmfml = First_Name + " " + Middle_Name + " " + Last_Name;
        logger.info("FullNamevalue from concatanation is" + Fullnamefrmfml);
        if (FullNamevalue.equalsIgnoreCase(Fullnamefrmfml)) {
            logger.info("Full name is concatanated via first last middle name");
        } else {
            logger.info("Full name is not concatanated via first last middle name/does not enter");
        }

        wrap.screenShot(BaseProject.driver, screenShotPath, "FullName");

		/*
		waitunlitVisiblityOfWebElement(Nationality1);
		com.suggestionTextBox2(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);
		waitunlitVisiblityOfWebElement(CountryOfBirth);
		com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(CountryOfResidence);
		com.suggestionTextBox2(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);
		 */
        //	waitunlitVisiblityOfWebElement(CountryOfBirth);

        wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(CountryOfBirth);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code, Country_Of_Birth);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CountryOfBirth");

        wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(CountryOfResidence);
        wrap.click(BaseProject.driver, CountryOfResidence);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code, Residence_Country);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CountryOfResidence");

        wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(Nationality1);
        wrap.click(BaseProject.driver, Nationality1);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1, Nationality_Code1, Nationality_Description1);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Nationality");
        wrap.wait(1000);

        //*****************Add Another Nationality*****************//

		/*if((Nationality_Description2!=null))
		{
		// Multiple Nationality Add
		wrap.wait(500);
		//r.keyPress(KeyEvent.VK_TAB);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Nationality2");
		wrap.wait(2000);
		wrap.click(BaseProject.driver, "//div[contains(@datasource,'Nationality')]//a[@title='Add a row ']");
		waitunlitVisiblityOfWebElement(Nationality2);
		com.suggestionTextBox(BaseProject.driver, Nationality2,Nationality_Code2,Nationality_Description2);
		}*/

//		waitunlitVisiblityOfWebElement(Nationality1);
//		com.suggestionTextBox(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);

        wrap.wait(1500);
        wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "B_CPDSec_Mehalaya_radioNo"));
        wrap.wait(500);

        if (wrap.isElementPresent(BaseProject.driver, ClientType)) {
            waitUntilVisibilityOfWebElement(ClientType);
            wrap.click(BaseProject.driver, ClientType);
            wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "ClientType");
        }

		/*wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//div[contains(@datasource,'Alias')]//a[@title='Add a row ']")).click();



		waitunlitVisiblityOfWebElement(AliasType1);
		wrap.click(BaseProject.driver, AliasType1);
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver,AliasType1 , Alias_Type, "BYVISIBLETEXT");
		wrap.wait(2000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType");


		String AliasNames_CCMS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_CCMS");
        String AliasNames_RLS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_RLS");
        String AliasNames_PRE=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_previos");

        String AliasName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasName1");
       // String AliasName2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2");

switch(Alias_Type){
        case "AKA (also known as)":
               waitunlitVisiblityOfWebElement(AliasFirstName);
               wrap.type(BaseProject.driver,Alias_First_Name,AliasFirstName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName");

               waitunlitVisiblityOfWebElement(AliasMiddleName);
               wrap.type(BaseProject.driver,Alias_Middle_Name,AliasMiddleName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName");

               waitunlitVisiblityOfWebElement(AliasLastName);
               wrap.type(BaseProject.driver,Alias_Last_Name,AliasLastName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName");

               break;
        case "Previous Name":

               waitunlitVisiblityOfWebElement(AliasName);
               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        case "CCMS Relationship Name":
               waitunlitVisiblityOfWebElement(AliasName);

               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        case "RLS Relationship Name":
               waitunlitVisiblityOfWebElement(AliasName);

               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        }
*/



/*
//***********************************Alias2**********************************

String	Alias_First_Name2 = DBUtils.readColumnWithRowID("Alias First Name2",BaseProject.scenarioID);
String Alias_Middle_Name2 = DBUtils.readColumnWithRowID("Alias Middle Name2",BaseProject.scenarioID);
String Alias_Last_Name2 = DBUtils.readColumnWithRowID("Alias Last Name2",BaseProject.scenarioID);
String Alias_Type2 =DBUtils.readColumnWithRowID("Alias Type2",BaseProject.scenarioID);
String Alias2 = DBUtils.readColumnWithRowID("Alias(es)2",BaseProject.scenarioID);



String AliasType2=com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasType2_Dropdown");
String AliasFirstName2=com.getElementProperties("BasicData", "BasicData_CaptureDetails_AliasFirstName2_textBox");
String AliasMiddleName2=com.getElementProperties("BasicData", "BasicData_CaptureDetails_AliasMiddleName2_textBox");
String AliasLastName2=com.getElementProperties("BasicData", "BasicData_CaptureDetails_AliasLastName2_textBox");



*/

        //Dinesh 3-Nov BD_AliasInfoSect_AliasType_DD
        wrap.wait(2000);
        if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD"))) {
            logger.info("Am in alias section going to delete the 1st row");
            wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BD_Aliases_Row1"));
            wrap.wait(2000);
            wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BD_Aliases_DelBtn"));
            wrap.wait(4000);
        }

/*if((Alias_Type2!=null))
{

	wrap.click(BaseProject.driver, "//a[contains(@name,'GetAliasName_pyWorkPage')][@title='Add a row ']");

	wrap.wait(2000);
// waitunlitVisiblityOfWebElement(AliasType2);
wrap.click(BaseProject.driver, AliasType2);
wrap.wait(1000);
wrap.selectFromDropDown(BaseProject.driver,AliasType2 , Alias_Type2, "BYVISIBLETEXT");
wrap.wait(2000);
wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType2");






switch(Alias_Type){
case "AKA (also known as)":
       waitunlitVisiblityOfWebElement(AliasFirstName2);
       wrap.type(BaseProject.driver,Alias_First_Name2,AliasFirstName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName2");

       waitunlitVisiblityOfWebElement(AliasMiddleName2);
       wrap.type(BaseProject.driver,Alias_Middle_Name2,AliasMiddleName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName2");

       waitunlitVisiblityOfWebElement(AliasLastName2);
       wrap.type(BaseProject.driver,Alias_Last_Name2,AliasLastName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName2");

       break;
case "Previous Name":

      waitunlitVisiblityOfWebElement(AliasName2);
       wrap.type(BaseProject.driver,Alias2,AliasName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName2");
       break;

case "CCMS Relationship Name":
       waitunlitVisiblityOfWebElement(AliasName2);

       wrap.type(BaseProject.driver,Alias2,AliasName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName2");
       break;

case "RLS Relationship Name":
       waitunlitVisiblityOfWebElement(AliasName2);

       wrap.type(BaseProject.driver,Alias2,AliasName2);
       wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName2");
       break;

}

	}*/

    }

    @When("^Blind: validate optional and mandatory fields in Contact section$")

    public void validate_optional_and_mandatory_fields_in_Contact_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        try {
            switchFrame();

            String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
            String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
            String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
            String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
            String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

            String preferredContact = "id=PRContact1";
            //String Area_cd = "44";
            //2203
            String Area_cd = DBUtils.readColumnWithRowID("Area Code", BaseProject.scenarioID); 
         

            String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");

            //convertExcelToMap("Sheet1");
            //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

//2203
            String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
            String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
            String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
            String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
            String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

            
          /*  String Contact_type_Code = "MO1";
            String Contact_type_Description = "Regst- Mobile No.-1";
            String Contact_Details = "5762319947";
            String ISD_Code = "91";
            String Extension_No = "2002";*/

            String Contactsection = com.getElementProperties("BasicData", "Contactsection");


            String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
            if (ContactSection.equals("false")) {
                wrap.click(BaseProject.driver, Contactsection);

            }

//2203
           // String CTD = Contact_type_Description;
            String CTD = Contact_type_Code;
            if (CTD.equals("MT1") |CTD.equals("RT1")| CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "code", CTD);
                //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
                wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
                //2203
               /* wrap.wait(3000);
                BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();*/
                //wrap.TypeToTextBoxAndTabOut(BaseProject.driver, CTD, ContactType);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


                wrap.wait(2000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails");


                wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
                wrap.wait(1000);
                wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

                wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");


                //wrap.wait(500);
                //Extension field not available after merge Hence commented
                //               wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                //               wrap.type(BaseProject.driver, Extension_No, Extension);
            } else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {


			/*wrap.click(BaseProject.driver, ContactType);
               wrap.wait(3000);
               wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
			 */
                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);

                wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails");


                //wrap.wait(500);
			/*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");*/

                wrap.wait(500);
                wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

                //wrap.wait(500);
		/*	wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
			wrap.type(BaseProject.driver, Extension_No, Extension);*/

            } else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
                wrap.wait(1000);
                BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
                //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


                //wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

                wrap.wait(1000);
                //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Areacodeprop)));
                //wrap.click(BaseProject.driver, Areacodeprop);
                verifyTextBoxThnClick(BaseProject.driver, Areacodeprop);
                wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

                wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                wrap.click(BaseProject.driver, Extension);
                wrap.type(BaseProject.driver, Extension_No, Extension);

                wrap.click(BaseProject.driver, preferredContact);
            }

		/*else if(CTD.equals("OT1")|CTD.equals("OT2")|CTD.equals("OT3")|CTD.equals("OT4")|CTD.equals("OT5")|CTD.equals("OT6")|CTD.equals("OT7")|CTD.equals("OT8")|CTD.equals("OT9")){

            waitunlitVisiblityOfWebElement(ContactType);
            //wrap.click(BaseProject.driver, ContactType);
            wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

            wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

            wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
            wrap.type(BaseProject.driver, Extension_No, Extension);

     }*/

            else {
                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);

            }
            wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");
        } catch (StaleElementReferenceException e) {
            switchFrame();

            String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
            String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
            String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
            String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
            String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

            String preferredContact = "id=PRContact1";
            String Area_cd = DBUtils.readColumnWithRowID("Area Code", BaseProject.scenarioID);

            String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");

            //convertExcelToMap("Sheet1");
            //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");


            String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
            String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
            String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
            String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
            String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);


            String Contactsection = com.getElementProperties("BasicData", "Contactsection");


            String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
            if (ContactSection.equals("false")) {
                wrap.click(BaseProject.driver, Contactsection);

            }


            String CTD = Contact_type_Description;
            if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "code", CTD);
                //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
                wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
                wrap.wait(1000);
                BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
                //wrap.TypeToTextBoxAndTabOut(BaseProject.driver, CTD, ContactType);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails");


                //wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
                wrap.wait(1000);
                wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

                wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");


                //wrap.wait(500);
                //Extension field not available after merge Hence commented
                //               wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                //               wrap.type(BaseProject.driver, Extension_No, Extension);
            } else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {


				/*wrap.click(BaseProject.driver, ContactType);
	               wrap.wait(3000);
	               wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
				 */
                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);

                wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
                wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails");


                //wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");


                wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

                //wrap.wait(500);
			/*	wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
				wrap.type(BaseProject.driver, Extension_No, Extension);*/

            } else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
                wrap.wait(1000);
                BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
                //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


                //wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

                //wrap.wait(1000);
                //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Areacodeprop)));
                //wrap.click(BaseProject.driver, Areacodeprop);
                // verifyTextBoxThnClick(BaseProject.driver,Areacodeprop);
                wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

                wrap.wait(500);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                wrap.click(BaseProject.driver, Extension);
                wrap.type(BaseProject.driver, Extension_No, Extension);

                wrap.click(BaseProject.driver, preferredContact);
            }

			/*else if(CTD.equals("OT1")|CTD.equals("OT2")|CTD.equals("OT3")|CTD.equals("OT4")|CTD.equals("OT5")|CTD.equals("OT6")|CTD.equals("OT7")|CTD.equals("OT8")|CTD.equals("OT9")){

	            waitunlitVisiblityOfWebElement(ContactType);
	            //wrap.click(BaseProject.driver, ContactType);
	            wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

	            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
	            wrap.click(BaseProject.driver, ContactDetails);
	            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


	            //wrap.wait(500);
	            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
	            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

	            wrap.click(BaseProject.driver, "//input[@id='PRContact1']");

	            wrap.wait(500);
	            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
	            wrap.type(BaseProject.driver, Extension_No, Extension);

	     }*/

            else {
                waitUntilVisibilityOfWebElement(ContactType);
                //wrap.click(BaseProject.driver, ContactType);
                wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
                wrap.click(BaseProject.driver, ContactDetails);
                wrap.type(BaseProject.driver, Contact_Details, ContactDetails);

            }

        }

    }

    @When("^Blind: validate optional and mandatory fields in Employment section$")
    public void validate_optional_and_mandatory_fields_in_Employment_section() throws Throwable {
        String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
        String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

//2203
        String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
        String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);

      /*  String Occupationcode = "543";
        String OccupationDescription = "PROFESSIONAL";*/

        String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
        String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
        if (EmploymentSection.equals("false")) {
            wrap.click(BaseProject.driver, Employmentsection);

        }

        //wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Occupation)));
        logger.info("Occupation code is " + Occupationcode);
        //wrap.selectformLOV_Values(BaseProject.driver, Occupation, Occupations);
        //wrap.typeInSuggestionTextbox(BaseProject.driver, Occupation, "code", OccupationDescription);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation");

//2203
       String isiccode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
        String isicDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);
        
       /* String isiccode = "8342";
        String isicDescription = "INFORMATION TECHNOLOGY PROFESSIONAL SERV";*/
        //wrap.captureScreenShot(BaseProject.driver, Occupation);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation");


        //wrap.typeInSuggestionTextbox(BaseProject.driver, ISIC, "code",isicDescription );
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ISIC, isicDescription,isiccode);
        // com.suggestionTextBox(BaseProject.driver, ISIC, isiccode,isicDescription);
        //wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC");

           /*
           try{
                  wrap.wait(1000);
                  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISIC)));
                  logger.info("ISIC Code "+isiccode);

                  wrap.typeInSuggestionTextbox(BaseProject.driver, ISIC, "code", isiccode);
    wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC");
           }
           catch(Exception e)
           {

           }
           */

        //2203
        /*try {
            wrap.wait(2000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISIC)));
            logger.info("ISIC Code " + isiccode);
            wrap.clear(BaseProject.driver, ISIC);
            wrap.wait(1000);
            //wrap.typeInSuggestionTextbox(BaseProject.driver, ISIC, "Description", isicDescription);
            com.suggestionTextBox_CodeDesc(BaseProject.driver, ISIC, isiccode, isicDescription);
            wrap.getElement(BaseProject.driver, ISIC).sendKeys(Keys.TAB);
            wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC");
        } catch (Exception e) {
            wrap.clear(BaseProject.driver, ISIC);
            wrap.wait(1000);
            com.suggestionTextBox_CodeDesc(BaseProject.driver, ISIC, isiccode, isicDescription);
            wrap.getElement(BaseProject.driver, ISIC).sendKeys(Keys.TAB);
        }
*/

    }


    @When("^Blind: validate optional and mandatory fields in Document Details section$")
    public void validate_optional_and_mandatory_fields_in_Document_Details_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        wrap.wait(1000);
        switchFrame();

        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);

        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }

        //WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

        try {


            wrap.wait(3000);
            String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));

            wrap.wait(1000);
            try {
                JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
                myExecutor.executeScript("arguments[0].click();", add);
            } catch (Exception e) {
                logger.info("Once again trying to click on Add button of Document detail section for blind WB");
                JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
                myExecutor.executeScript("arguments[0].click();", add);
            }

            wrap.click(BaseProject.driver, DocumentCategory);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory");


            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDocument");

            wrap.wait(1000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");


            wrap.wait(2000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate");


            //	wrap.wait(500);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
            wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate");
            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        } catch (Exception e) {


            String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);


            wrap.click(BaseProject.driver, DocumentCategory);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory");


            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDocument");

            wrap.wait(1000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");


            //wrap.wait(2000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
            wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate");


            //	wrap.wait(500);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
            wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate");
            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        }
    }

    @When("^Blind: UAT Scenarioclick on Product Details tab$")
    public void UAT_Scenario_click_on_Product_Details_tab() throws Throwable {
        wrap.wait(1000);
        switchFrame();
        // Write code here that turns the phrase above into concrete actions
        String cust_details = com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, cust_details)));
        wrap.click(BaseProject.driver, cust_details);
    }

    @Given("^Blind: Go to Basic Data Capture home page$")
    public void Go_to_Basic_Data_Capture_home_page() throws Throwable {

        //	//utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

        wrap.switch_to_default_Content(BaseProject.driver);

		/*if(!wrap.isElementPresent(BaseProject.driver, com.getElementProperties("DI", "seeall_option"))){
			wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));

		}*/
        wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
        wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));


        wrap.getWorkbasketoption(BaseProject.driver, "Blind Data Capture Maker");

        wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));


    }


    @When("^Blind: UAT Scenariovalidate optional and mandatory fields in Product Details section$")
    public void uat_Scenario_validate_optional_and_mandatory_fields_in_prd_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //int i=1,j=1;

        try {
            //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");


            String campcd = DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
            String campcddesc = DBUtils.readColumnWithRowID("CampaigncodeDescription", BaseProject.scenarioID);
            String prdcd = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);


            //Ram Implementation

            //String products = com.getElementProperties("BasicData", "differentproductselections");
            //List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
            //for(WebElement pro: listOfProduct){

            //String capmpaigncode = "xpath=(//input[@id='CampaignCode'])["+i+"]";
            //String productcode="xpath=(//select[@id='ProductCode'])["+j+"]";

            String capmpaigncode = "xpath=(//input[@id='CampaignCode'])";
            String productcode = "xpath=(//select[@id='ProductCode'])";
            String productcodetd = "xpath=(//select[@id='ProductCode'])[2]";
	      /* logger.info(capmpaigncode);
	       logger.info(productcode);

	       JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
	       executor.executeScript("arguments[0].click();", pro);
	        pro.click();*/
            //com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

            // wrap.wait(3000);
            //logger.info("(//select[@id='ProductCategory'])["+j+"]");
            //    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");
            wrap.wait(2000);
            //com.suggestionTextBox(BaseProject.driver, capmpaigncode, campcd, campcddesc);
            // wrap.typeInSuggestionTextbox(BaseProject.driver, capmpaigncode, campcddesc, campcd);
            wrap.type(BaseProject.driver, campcd, capmpaigncode);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + campcd + "')]")).click();
            // i++;

	         /* wrap.wait(1000);
	          wrap.click(BaseProject.driver, productcode);
	          wrap.wait(1000);
	          //wrap.selectFromDropDown(BaseProject.driver, productcode, "1", "BYINDEX");
	          wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
	         // j++;
*/

            if (wrap.isElementPresent(BaseProject.driver, productcode)) {
                logger.info("am in product code block in blind WB");
                wrap.wait(1000);
                //wrap.click(BaseProject.driver, productcode);
                wrap.wait(3000);
                //wrap.selectFromDropDown(BaseProject.driver, productcode, "9", "BYINDEX");
                wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
            }
            // j++;


            if (wrap.isElementPresent(BaseProject.driver, productcodetd)) {
                wrap.wait(1000);
                wrap.click(BaseProject.driver, productcodetd);
                wrap.wait(1000);
                //wrap.selectFromDropDown(BaseProject.driver, productcode, "9", "BYINDEX");
                wrap.selectFromDropDown(BaseProject.driver, productcodetd, prdcd, "BYVISIBLETEXT");
            }


            //wrap.screenShot(BaseProject.driver, "C:"+File.separator+"Arun"+File.separator+"AutomationScreenShots", Account_Request_Type);

        } catch (StaleElementReferenceException e) {
            //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");


            String campcd = DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
            String campcddesc = DBUtils.readColumnWithRowID("CampaigncodeDescription", BaseProject.scenarioID);
            String prdcd = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);


            //Ram Implementation

            //String products = com.getElementProperties("BasicData", "differentproductselections");
            //List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
            //for(WebElement pro: listOfProduct){

            //String capmpaigncode = "xpath=(//input[@id='CampaignCode'])["+i+"]";
            //String productcode="xpath=(//select[@id='ProductCode'])["+j+"]";

            String capmpaigncode = "xpath=(//input[@id='CampaignCode'])";
            String productcode = "xpath=(//select[@id='ProductCode'])";
            String productcodetd = "xpath=(//select[@id='ProductCode'])[2]";
	  	      /* logger.info(capmpaigncode);
	  	       logger.info(productcode);

	  	       JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
	  	       executor.executeScript("arguments[0].click();", pro);
	  	        pro.click();*/
            //com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

            // wrap.wait(3000);
            //logger.info("(//select[@id='ProductCategory'])["+j+"]");
            //    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");
            wrap.wait(2000);
            //com.suggestionTextBox(BaseProject.driver, capmpaigncode, campcd, campcddesc);
            // wrap.typeInSuggestionTextbox(BaseProject.driver, capmpaigncode, campcddesc, campcd);
            wrap.type(BaseProject.driver, campcd, capmpaigncode);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + campcd + "')]")).click();
            // i++;

	  	         /* wrap.wait(1000);
	  	          wrap.click(BaseProject.driver, productcode);
	  	          wrap.wait(1000);
	  	          //wrap.selectFromDropDown(BaseProject.driver, productcode, "1", "BYINDEX");
	  	          wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");*/
            // j++;

            if (wrap.isElementPresent(BaseProject.driver, productcode)) {
                wrap.wait(1000);
                wrap.click(BaseProject.driver, productcode);
                wrap.wait(1000);
                //wrap.selectFromDropDown(BaseProject.driver, productcode, "9", "BYINDEX");
                wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
            }
            // j++;


            if (wrap.isElementPresent(BaseProject.driver, productcodetd)) {
                wrap.wait(1000);
                wrap.click(BaseProject.driver, productcodetd);
                wrap.wait(1000);
                //wrap.selectFromDropDown(BaseProject.driver, productcode, "9", "BYINDEX");
                wrap.selectFromDropDown(BaseProject.driver, productcodetd, prdcd, "BYVISIBLETEXT");
            }


            //wrap.screenShot(BaseProject.driver, "C:"+File.separator+"Arun"+File.separator+"AutomationScreenShots", Account_Request_Type);

            // }
        }


    }


    @When("^Blind: validate optional and mandatory fields in Coapplicant Customer Personal Details section$")
    public void validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section()
            throws Throwable {
        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
        String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
        String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
        String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
        String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
        String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
        String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
        String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
        ////convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Titles = DBUtils.readColumnWithRowID("Title1", BaseProject.scenarioID);
        String First_Name = DBUtils.readColumnWithRowID("First Name1", BaseProject.scenarioID);
        String Middle_Name = DBUtils.readColumnWithRowID("Middle Name1", BaseProject.scenarioID);
        String Last_Name = DBUtils.readColumnWithRowID("Last Name1", BaseProject.scenarioID);
        String DOB = DBUtils.readColumnWithRowID("DOB1", BaseProject.scenarioID);
        String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code Secondary1", BaseProject.scenarioID);
        String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description Secondary1", BaseProject.scenarioID);
        String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code Secondary2", BaseProject.scenarioID);
        String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description Secondary2", BaseProject.scenarioID);
        String Nationalty = DBUtils.readColumnWithRowID("Nationality1", BaseProject.scenarioID);
        String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth1", BaseProject.scenarioID);
        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country1", BaseProject.scenarioID);
        String Alias_Type = DBUtils.readColumnWithRowID("Alias Type1", BaseProject.scenarioID);
        String Alias = DBUtils.readColumnWithRowID("Alias(es)1", BaseProject.scenarioID);
        String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
        String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code1", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code1", BaseProject.scenarioID);
        String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name1", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name1", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name1", BaseProject.scenarioID);
        String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);


        switchFrame();

        String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


        String Customersection = com.getElementProperties("BasicData", "Customersection");
        String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
        if (CustomerSection.equals("false")) {
            wrap.click(BaseProject.driver, Customersection);

        }
        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(Title);
        wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");

        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(FirstName);
        wrap.type(BaseProject.driver, First_Name, FirstName);


        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(MiddleName);
        wrap.click(BaseProject.driver, MiddleName);
        wrap.type(BaseProject.driver, Middle_Name, MiddleName);

        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(LastName);
        //wrap.click(BaseProject.driver, LastName);
        verifyTextBoxThnClick(BaseProject.driver, LastName);
        wrap.type(BaseProject.driver, Last_Name, LastName);


        //wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(DateOfBirth1);
        verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
        wrap.enterDate(BaseProject.driver, DOB, DateOfBirth2);

        waitUntilVisibilityOfWebElement(CountryOfBirth);
        //wrap.typeInSuggestionTextbox(BaseProject.driver, CountryOfBirth, codeOrDescription, value);
        //com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code, Country_Of_Birth);

        waitUntilVisibilityOfWebElement(CountryOfResidence);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code, Residence_Country);
        //com.suggestionTextBox2(BaseProject.driver, CountryOfResidence,Residence_Country_Code,Residence_Country);

        waitUntilVisibilityOfWebElement(Nationality1);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1, Nationality_Code1, Nationality_Description1);
        //com.suggestionTextBox2(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);

/*		waitunlitVisiblityOfWebElement(Nationality1);
		com.suggestionTextBox2(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);*/

		/*
		waitunlitVisiblityOfWebElement(CountryOfBirth);

		com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);

		//wrap.wait(500);


		waitunlitVisiblityOfWebElement(CountryOfResidence);

		com.suggestionTextBox2(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);


		 */

		/*waitunlitVisiblityOfWebElement(CountryOfBirth);
		com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);*/


        waitUntilVisibilityOfWebElement(ClientType);
        wrap.click(BaseProject.driver, ClientType);
        wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");


    }


    @When("^Blind: Document catagory Expire Date AlertMessage$")
    public void document_Catagory_Expire_Date_AlertMessage() throws IOException, InterruptedException, ParseException {


        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        //System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime()));
        //String date1 = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());

        //System.out.println(date1.concat("90"));
        Calendar cal = Calendar.getInstance();
        System.out.println(cal.getTime());

        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);

        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }


        switch (Document_Category) {

            case "CLIENT VERIFICATION DOCUMENTS":

                break;
            case "CLIENT TAX DOCUMENTS":

                break;

            case "CLIENT ID  DOCUMENTS":
                wrap.click(BaseProject.driver, DocumentCategory);
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
                wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");


                switch (Name_of_the_Document) {


                    case "DRIVING LIC NO":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                        cal.add(Calendar.DATE, 30);
                        String date = dateFormat.format(cal.getTime());
                        date = date.replace("/", "");
                        int dateNumDLV = Integer.parseInt(date);

                        if (dateNumDLV <= DLVExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }


                        break;

                    case "PASSPORT":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DocExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 90);
                        String passExp = dateFormat.format(cal.getTime());
                        passExp = passExp.replace("/", "");
                        int dateNumpass = Integer.parseInt(passExp);

                        if (dateNumpass >= DocExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }

                        break;

                    case "VISA":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int VisaExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 30);
                        String Visadate = dateFormat.format(cal.getTime());
                        Visadate = Visadate.replace("/", "");
                        int dateNum = Integer.parseInt(Visadate);

                        if (dateNum <= VisaExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    case "AOF":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int AOFExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 30);
                        String aofdate = dateFormat.format(cal.getTime());
                        aofdate = aofdate.replace("/", "");
                        int dateAof = Integer.parseInt(aofdate);

                        if (dateAof >= AOFExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    case "TELEPHONE BILL":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int teliExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateTeli = dateFormat.format(cal.getTime());
                        dateTeli = dateTeli.replace("/", "");
                        int teliphoneDate = Integer.parseInt(dateTeli);

                        if (teliphoneDate >= teliExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    case "ELECTRICITY BILL":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int eleExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateEle = dateFormat.format(cal.getTime());
                        dateEle = dateEle.replace("/", "");
                        int dateNumEle = Integer.parseInt(dateEle);

                        if (dateNumEle >= eleExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    case "WATER BILL":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DocExpDateWater = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateOfWater = dateFormat.format(cal.getTime());
                        dateOfWater = dateOfWater.replace("/", "");
                        int dateNumWater = Integer.parseInt(dateOfWater);

                        if (dateNumWater >= DocExpDateWater) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    case "GAS BILL":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //	wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int gasExpire = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateOfGas = dateFormat.format(cal.getTime());
                        dateOfGas = dateOfGas.replace("/", "");
                        int dateofGasinNumber = Integer.parseInt(dateOfGas);

                        if (dateofGasinNumber >= gasExpire) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        break;

                    default:
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        break;
                }

                break;
        }
    }


  /*  @Then("^Blind : Validate Field '(.+)'$")
    public static void validateFieldStep(String FieldName) throws IOException, InterruptedException {

        wrap.wait(1000);

        logger.info("Going to switch into frame");

        switchFrame();
		BaseProject.driver.switchTo().defaultContent();
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

        logger.info("Frame switched successfully");

		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//input[@id='IsCheckerSelected1']")).click();
		wrap.wait(1000);
        BaseProject.propertiesFilename="BlindData";
        CommonUtilsData.FieldNameData = FieldName;

        CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "UATBasicData_Testdata_sheet.xls", "UATBlindFiled");

        try {

            if (!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)) {

                CommonUtils.validateField(
                        CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

            }
        } catch (Exception E) {

            System.out.println("Field : " + FieldName + " is not present in Datamodel");
        }

    }*/


    @When("^Blind: validate optional and mandatory fields in Document Details section for coapp$")
    public void validate_coapp_optional_and_mandatory_fields_in_Document_Details_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category1", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document1", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number1", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date1", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date1", BaseProject.scenarioID);

        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);

        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }

        //WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

        try {



			/* wrap.wait(1000);
	 String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);
			 */

            wrap.click(BaseProject.driver, DocumentCategory);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

            wrap.wait(2000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);


            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.wait(2000);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

            //	wrap.wait(500);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        } catch (Exception e) {


            String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);


            wrap.click(BaseProject.driver, DocumentCategory);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

            wrap.click(BaseProject.driver, NameoftheDocument);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


            //	wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            wrap.click(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

            //wrap.wait(2000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

            //	wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        }
    }


    @When("^Blind: validate optional and mandatory fields in Banking Service Details section$")
    public void validate_optional_and_mandatory_fields_in_Banking_Service_Details_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String EmbossedDebitCardName = com.getElementProperties("BasicData", "BasicData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID");


        String Bankingsection = com.getElementProperties("BasicData", "Bankingsection");
        String BankingSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Banking Service Details']/../..")).getAttribute("aria-expanded");
        if (BankingSection.equals("false")) {
            wrap.click(BaseProject.driver, Bankingsection);

        }

        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String Embossed = DBUtils.readColumnWithRowID("Embossed Debit Card Name", BaseProject.scenarioID);



		/*String MandatoryErrorMsg = com.getElementProperties("BasicData", "Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);*/


        wrap.type(BaseProject.driver, Embossed, EmbossedDebitCardName);
		/*if (MandErrMsg.equals("Industry"))
	    {
	    	logger.info("Values cannot be blank for ISIC");
	    }*/

    }


    @When("^Once compled blind data is application$")
    public void onceCompletedBlindData_application_move_to() {


    }


    @When("^Blind: click on Personal Details tab$")
    public void click_on_Personal_Details_tab() throws Throwable {
        wrap.wait(1000);
        switchFrame();
        // Write code here that turns the phrase above into concrete actions
        String cust_details = com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, cust_details)));
        wrap.click(BaseProject.driver, cust_details);
    }


    @When("^Blind: validate optional and mandatory fields in Product Details section$")
    public void validate_optional_and_mandatory_fields_in_Product_Details_section() throws IOException, InterruptedException {
        // Write code here that turns the phrase above into concrete actions

        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


        String Productsection = com.getElementProperties("BasicData", "Productsection");
        String ProductSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
        if (ProductSection.equals("false")) {
            wrap.click(BaseProject.driver, Productsection);

        }

        //convertExcelToMap("Sheet1");
        //    //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String Product_Category = DBUtils.readColumnWithRowID("Product Category", BaseProject.scenarioID);
        String Product_Code = DBUtils.readColumnWithRowID("Product Code", BaseProject.scenarioID);

        wrap.click(BaseProject.driver, ProductDetails);
        wrap.selectFromDropDown(BaseProject.driver, ProductCategory, Product_Category, "BYVISIBLETEXT");
        wrap.selectFromDropDown(BaseProject.driver, ProductCode, Product_Code, "BYVISIBLETEXT");


    }

	/*@When("^Blind: validate optional and mandatory fields in A/C Setup section$")
	public void validate_optional_and_mandatory_fields_in_AC_Setup_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Purpose=com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
		String AccReqType=com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
		String AccNum=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
		String AccCurrency=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");
		String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
		String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");


	 //  //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
		//convertExcelToMap("Sheet1");
		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

		String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);



		String ACsection=com.getElementProperties("BasicData", "ACsection");
		String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
		if(ACSection.equals("false"))
		{
		  wrap.click(BaseProject.driver, ACsection);

		}


//Ram Implementation

	       String products = com.getElementProperties("BasicData", "differentproductselections");
	       List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
	       for(WebElement pro: listOfProduct){
	              pro.click();




		wrap.wait(1000);
		String ProductCategory = new Select(BaseProject.driver.findElement(By.id("ProductCategory"))).getFirstSelectedOption().getText();

	//	wrap.wait(1000);



		if(!ProductCategory.equalsIgnoreCase("CREDIT CARD"))
		{

			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

		}

	//	wrap.wait(1000);

		if(ProductCategory.equalsIgnoreCase("TERM DEPOSITS"))
		{

			wrap.type(BaseProject.driver, Minimum_Clearing_Balance, MinClearBal);

		}
		else
		{

			wrap.click(BaseProject.driver, AccReqType);
			//Actions a=new Actions(BaseProject.driver);
			WebElement element=BaseProject.driver.findElement(By.id("IsAccountType"));
			Select docname=new Select(element);
			List<WebElement> docnames=docname.getOptions();


			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

		//	wrap.wait(1000);
			if(Account_Request_Type.equalsIgnoreCase("Existing"))
			{
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");

			}


	//		wrap.typeInSuggestionTextbox(BaseProject.driver, AccCurrency, "code", Account_Currency);



			if(!Account_Request_Type.equalsIgnoreCase("DEFAULT"))
			{
				wrap.wait(2000);
				WebElement element1=BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
				JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
				myExecutor.executeScript("arguments[0].click();", element1);
				myExecutor.executeScript("arguments[0].value='"+Account_Number+"';", element1);
				wrap.wait(3000);

				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, Account_Number, AccNum);

			}
		}
	       }
	}

	 */

    @When("^Blind: Document catagory Multiple Document '(.*)'$")
    public void uat_Tc_Document_Catagory_Expire_Date_(String i) throws IOException, InterruptedException, ParseException {


        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        //System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime()));
        //String date1 = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());

        //System.out.println(date1.concat("90"));
        Calendar cal = Calendar.getInstance();
        System.out.println(cal.getTime());

        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        //String IDExpiryDate1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        //String DocumentSignatureDate=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");

        int j = Integer.parseInt(i);
        //  j = j+1;
        int k = j + 1;
        String DocumentType = "xpath=(//div[@sectionbodyid='SubSectionDocumentListB']/ul[@class='yui-nav']//a[@id='TABANCHOR'])[" + j + "]";
        //String DocumentNumber = "xpath=(//input[@id='DocumentNumber'])["+j+"]";
        String DocumentSignatureDate = "id=DocumentSignatureDate" + k;
        String IDExpiryDate1 = "id=DocumentExpiryDate" + k;
        //String DocumentNumber = "xpath=(//input[@id='DocumentNumber'])["+k+"]";


        //convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category" + i, BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document" + i, BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number" + i, BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date" + i, BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date" + i, BaseProject.scenarioID);
        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

           /*JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
           jse.executeScript("arguments[0].scrollIntoView(true);", element);*/

        String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
        WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
        myExecutor.executeScript("arguments[0].click();", add);


        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }


        switch (Document_Category) {

            case "CLIENT VERIFICATION DOCUMENTS":

                wrap.click(BaseProject.driver, DocumentCategory);
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
                wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");
                switch (Name_of_the_Document) {

                    case "DRIVING LIC NO":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                        cal.add(Calendar.DATE, 30);
                        String date = dateFormat.format(cal.getTime());
                        date = date.replace("/", "");
                        int dateNumDLV = Integer.parseInt(date);

                        if (dateNumDLV <= DLVExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

                        break;

                    case "GAS BILL":

                        wrap.wait(1000);
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.wait(1000);
                        //  wrap.click(BaseProject.driver, DocumentType);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                      /*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

                        break;

                    case "TELEPHONE BILL":

                        //wrap.wait(1000);
                        //wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        // wrap.click(BaseProject.driver, DocumentType);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
                        //wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                      /*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

                        break;

                    case "WATER BILL":

                        //wrap.wait(1000);
                        //wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        // wrap.click(BaseProject.driver, DocumentType);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
                        //wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                      /*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

                        break;


                    case "VOTERS ID":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "AADHAAR":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                }


                break;
            case "CLIENT TAX DOCUMENTS":
                wrap.click(BaseProject.driver, DocumentCategory);
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
                wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

                switch (Name_of_the_Document) {

                    case "CANADIAN TAX IDENTIFICATION":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;


                    case "CRS DOCUMENT":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "CRS VALIDATION CHECKLIST":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "FOREIGN TIN":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "FORM 60":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "GST/VAT DOCUMENT":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "TAX IDENTIFICATION NUMBER":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                         /*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);*/
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "TAX PAID  RECEIPTS":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;


                }


                break;

            case "CLIENT ID  DOCUMENTS":
                wrap.click(BaseProject.driver, DocumentCategory);
                //wrap.wait(1000);
                wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
                wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");


                switch (Name_of_the_Document) {

                    case "VOTERS ID":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "DRIVING LIC NO":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        //wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                       /* wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                        cal.add(Calendar.DATE, 30);
                        String date =dateFormat.format(cal.getTime());
                        date = date.replace("/", "");
                        int dateNumDLV = Integer.parseInt(date);

                        if(dateNumDLV<=DLVExpDate){

                               String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                                logger.info(ErrorMessage);
                               System.out.println(ErrorMessage);
                        }*/

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "PASSPORT":

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        // wrap.click(BaseProject.driver, DocumentType);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
                        //wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


                     /*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                     int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                     cal.add(Calendar.DATE, 30);
                     String date =dateFormat.format(cal.getTime());
                     date = date.replace("/", "");
                     int dateNumDLV = Integer.parseInt(date);

                     if(dateNumDLV<=DLVExpDate){

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                     }*/

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

                        break;


                    case "VISA":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int VisaExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 30);
                        String Visadate = dateFormat.format(cal.getTime());
                        Visadate = Visadate.replace("/", "");
                        int dateNum = Integer.parseInt(Visadate);

                        if (dateNum <= VisaExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "AOF":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int AOFExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 30);
                        String aofdate = dateFormat.format(cal.getTime());
                        aofdate = aofdate.replace("/", "");
                        int dateAof = Integer.parseInt(aofdate);

                        if (dateAof >= AOFExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "TELEPHONE BILL":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int teliExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateTeli = dateFormat.format(cal.getTime());
                        dateTeli = dateTeli.replace("/", "");
                        int teliphoneDate = Integer.parseInt(dateTeli);

                        if (teliphoneDate >= teliExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "ELECTRICITY BILL":

                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int eleExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateEle = dateFormat.format(cal.getTime());
                        dateEle = dateEle.replace("/", "");
                        int dateNumEle = Integer.parseInt(dateEle);

                        if (dateNumEle >= eleExpDate) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    case "WATER BILL":
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

                        wrap.click(BaseProject.driver, DocumentType);

                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        //     wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DocExpDateWater = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

                        cal.add(Calendar.DATE, 60);
                        String dateOfWater = dateFormat.format(cal.getTime());
                        dateOfWater = dateOfWater.replace("/", "");
                        int dateNumWater = Integer.parseInt(dateOfWater);

                        if (dateNumWater >= DocExpDateWater) {

                            String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                            logger.info(ErrorMessage);
                            System.out.println(ErrorMessage);
                        }
                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;

                    default:
                        wrap.click(BaseProject.driver, NameoftheDocument);
                        //wrap.wait(1000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
                        wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
                        wrap.click(BaseProject.driver, DocumentType);
                        wrap.wait(1000);
                        //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

                        //wrap.wait(2000);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
                        verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
                        wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
                        //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

                        wrap.wait(500);
                        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
                        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

                        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

                        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
                        break;
                }

                break;
        }


    }

    @Then("^Blind: Validate DOB by enter invalid value$")
    public static void invalidDOB() throws IOException, InterruptedException {

        //utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet2");

        String DOB1 = DBUtils.readColumnWithRowID("DOB1", BaseProject.scenarioID);
        String DOB2 = DBUtils.readColumnWithRowID("DOB2", BaseProject.scenarioID);
        String DOB3 = DBUtils.readColumnWithRowID("DOB3", BaseProject.scenarioID);

        wrap.wait(1000);
        logger.info("Going to switch into frame");
        switchFrame();
        logger.info("Frame switched successfully");

        wrap.wait(1000);
        wrap.enterDate(BaseProject.driver, DOB1, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        //wrap.type(BaseProject.driver, "01/01/2050", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        wrap.wait(1000);
        wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
        //wrap.wait(1000);
        String invalidPANtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Enter a valid past date')]")).getText();
        if (invalidPANtxt.contains("Enter a valid past date")) {
            logger.info("Please enter valid DOB for past date");
        } else {
            logger.info("Valid DOB entered");
        }

        wrap.wait(1000);
        wrap.enterDate(BaseProject.driver, DOB2, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        //wrap.type(BaseProject.driver, "01/01/1850", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        wrap.wait(1000);
        wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
        //wrap.wait(1000);
        String invalidPANtxt1 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Age is more than 150 years. Please Select Valid DOB')]")).getText();
        if (invalidPANtxt1.contains("Age is more than 150 years")) {
            logger.info("Please enter valid DOB for 150yrs error message");
        } else {
            logger.info("Valid DOB entered");
        }

        wrap.wait(1000);
        wrap.enterDate(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        //wrap.type(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        wrap.wait(1000);
        wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
        wrap.wait(1000);
        String invalidPANtxt2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'age should be Less than')]")).getText();
        if (invalidPANtxt2.contains("age should be Less than")) {
            logger.info("Please enter valid DOB for 100yrs error message");
        } else {
            logger.info("Valid DOB entered");
        }

    }


    @When("^Blind: validate optional and mandatory fields in A/C Setup section Old code$")
    public void validate_optional_and_mandatory_fields_in_AC_Setup_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        int Pur = 1, ActR = 1, AccNu = 2, Ser = 1, i = 1, Min = 1, j = 1;

        /*String Purpose=com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
        String AccReqType=com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
        String AccNum=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
        String AccCurrency=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");
        String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");*/


        //utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");

        //  //utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");
        //convertExcelToMap("Sheet1");
        String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
        String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
        String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency", BaseProject.scenarioID);
        String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

        String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);


        String ACsection = com.getElementProperties("BasicData", "ACsection");
        String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
        if (ACSection.equals("false")) {
            wrap.click(BaseProject.driver, ACsection);

        }


        //Ram Implementation

        String products = com.getElementProperties("BasicData", "differentproductselections");
        List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
        for (WebElement pro : listOfProduct) {

            String productCatagory = "xpath=(//select[@id='ProductCategory'])[" + i + "]";
            String Purpose = "xpath=(//select[@id='Purpose'])[" + Pur + "]";
            String AccReqType = "xpath=(//*[@id='IsAccountType'])[" + ActR + "]";
            String AccNum = "xpath=(//input[@id='AccountNumber'])[" + AccNu + "]";
            String AccCurrency = "xpath=(//input[@id='Currency'])[" + i + "]";
            String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
            String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + Min + "]";

            logger.info(productCatagory);
            logger.info(Purpose);
            logger.info(AccReqType);
            logger.info(AccNum);
            logger.info(AccCurrency);
            logger.info(ServiceType);
            logger.info(MinClearBal);


            //pro.click();

            JavascriptExecutor executor = (JavascriptExecutor) BaseProject.driver;
            executor.executeScript("arguments[0].click();", pro);

            //com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

            wrap.wait(3000);
            logger.info("(//select[@id='ProductCategory'])[" + j + "]");
            //    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");

            String ProductCategory = new Select(BaseProject.driver.findElement(By.xpath("(//select[@id='ProductCategory'])[" + j + "]"))).getFirstSelectedOption().getText();
            System.out.println("Product is" + ProductCategory);
            wrap.wait(1000);
            j++;
            switch (ProductCategory) {
                case "CREDIT CARD":
                    wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                    ActR++;
                    //     wrap.wait(1000);
                    if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                        Ser++;

                    }
                    wrap.type(BaseProject.driver, Account_Number, AccNum);
                    AccNu++;
                    break;
                case "CURRENT ACCOUNT":
                    wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                    Pur++;
                    wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                    ActR++;
                    if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                        Ser++;
                    }
                    wrap.type(BaseProject.driver, Account_Number, AccNum);
                    AccNu++;

                    break;
                case "SAVINGS ACCOUNT":
                    wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                    Pur++;
                    wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                    ActR++;
                    if (Account_Request_Type.equalsIgnoreCase("Existing") || Account_Request_Type.equalsIgnoreCase("Insta")) {
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                        Ser++;
                        wrap.type(BaseProject.driver, Account_Number, AccNum);
                        AccNu++;
                    }


                    break;

                case "TERM DEPOSITS":
                    wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                    Pur++;

                    wrap.type(BaseProject.driver, Minimum_Clearing_Balance, MinClearBal);
                    Min++;
                    break;
                case "PERSONAL LOAN":
                    wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                    Pur++;
                    wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                    ActR++;
                    if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                        wrap.wait(500);
                        wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                        Ser++;
                    }
                    break;

                case "MORTGAGE LOAN":
                    break;
                case "PROMOTIONAL PACKAGES":
                    break;

                default:

                    try {
                        if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
                            wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                            Pur++;

                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    try {
                        if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) {
                            wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                            ActR++;

                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    try {
                        if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
                            if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                                wrap.wait(500);
                                wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                                Ser++;
                            }
                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }


                    try {
                        if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
                            wrap.type(BaseProject.driver, Account_Number, AccNum);
                            AccNu++;

                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }


                    break;

            }

        }

    }

    @Then("^Blind: Fill the Product and Customer Relation$")
    public static void Fill_the_product_Customer_Relation() throws IOException, InterruptedException {

        wrap.wait(6000);

        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        String Customername = DBUtils.readColumnWithRowID("Customer Name", BaseProject.scenarioID);
        String Relationshiptypecode = DBUtils.readColumnWithRowID("Relationship type", BaseProject.scenarioID);
        WebElement heading = BaseProject.driver.findElement(By.xpath("//h2[contains(text(),'Product and Customer Relation')]"));

        wrap.wait(1000);

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", heading);

        WebElement addrow = BaseProject.driver.findElement(By.xpath("(//a[contains(@title,'Add a row')])[3]"));
        JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
        myExecutor.executeScript("arguments[0].click();", addrow);

        wrap.wait(8000);

        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname"), "2", "BYINDEX");

        wrap.wait(2500);
        wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype"));
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype"), Relationshiptypecode, "BYVISIBLETEXT");

        wrap.wait(1000);

         /*  WebElement deleterow = BaseProject.driver.findElement(By.xpath("(//a[contains(@class,'iconDelete')])[3]"));
           JavascriptExecutor myExecutor1 = ((JavascriptExecutor) BaseProject.driver);
           myExecutor.executeScript("arguments[0].click();", deleterow);*/

        //wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BaiscData_ProdDetail_DeleteRow"));
    }


    @When("^Blind: validate optional and mandatory fields in A/C Setup section$")
    public void validate_optional_and_mandatory_fields_in_AC_Setup_section_Blind() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //int Pur=1, ActR=1, AccNu = 2,Ser=1,i=2,Min=1,j=1;

	        /*String Purpose=com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
	        String AccReqType=com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
	        String AccNum=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
	        String AccCurrency=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");
	        String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
	        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");*/


        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        //  //utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
        //convertExcelToMap("Sheet1");
        String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
        String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
        String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
        String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

        String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);


        String ACsection = com.getElementProperties("BasicData", "ACsection");
	        /*String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
	        if(ACSection.equals("false"))
	        {
	               wrap.click(BaseProject.driver, ACsection);

	        }
*/


        //Ram Implementation

        String products = com.getElementProperties("BasicData", "differentproductselections");
        // List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
        // for(WebElement pro: listOfProduct){

	            /*String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+i+"]";
	            String Purpose="xpath=(//select[@id='Purpose'])["+Pur+"]";
	            String AccReqType="xpath=(//*[@id='IsAccountType'])["+ActR+"]";
	            String AccNum="xpath=(//input[@id='AccountNumber'])["+AccNu+"]";
	            String AccCurrency="xpath=(//input[@id='Currency'])["+i+"]";
	            String ServiceType ="xpath=(//*[@id='NatureOfServices'])["+i+"]";
	            String MinClearBal ="xpath=(//*[@id='MinimumClearingBalance'])["+Min+"]";*/


        String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
        String Purpose = "xpath=(//select[@id='Purpose'])";
        String AccReqType = "xpath=(//*[@id='IsAccountType'])";
        String AccNum = "xpath=(//input[@id='AccountNumber'])";
        String AccCurrency = "xpath=(//input[@id='Currency'])";
        String ServiceType = "xpath=(//*[@id='NatureOfServices'])";
        String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";

        logger.info(productCatagory);
        logger.info(Purpose);
        logger.info(AccReqType);
        logger.info(AccNum);
        logger.info(AccCurrency);
        logger.info(ServiceType);
        logger.info(MinClearBal);


        // JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
        //executor.executeScript("arguments[0].click();", pro);
        // pro.click();
        //com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

        //wrap.wait(3000);
        //logger.info("(//select[@id='ProductCategory'])["+j+"]");
        //    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");

        //String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+j+"]")).getText().trim();
        String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)")).getText().trim();
        System.out.println("Product is" + ProductCategory);
        wrap.wait(1000);
        // j++;
        switch (ProductCategory) {
            case "CREDIT CARD":

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");



	                      /* if(Account_Request_Type.equalsIgnoreCase("Existing"))
	                       {
	                              wrap.wait(500);
	                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
	                	wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
	                       }

	                       if(Account_Request_Type.equalsIgnoreCase("New"))
	                       {
	                              //wrap.wait(500);
	                              //wrap.type(BaseProject.driver, Account_Number, AccNum);
	                              wrap.wait(500);
	                              com.suggestionTextBox(BaseProject.driver, AccCurrency,Account_Currency, Account_Currency_Code);
	      	                   	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
	                       }

	                       if(!Account_Request_Type.equalsIgnoreCase("New"))
	                       {
	                              wrap.wait(500);
	                              wrap.type(BaseProject.driver, Account_Number, AccNum);
	                            	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
	                       }*/



	                       /*Pur++;
	                       ActR++;
	                       Ser++;
	                       AccNu++;
	                       i++;*/

                break;
            case "CURRENT ACCOUNT":
                logger.info("Moved to CA");
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }
                // wrap.type(BaseProject.driver, Account_Number, AccNum);
                //wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


                if (Account_Request_Type.equalsIgnoreCase("New")) {
                    //wrap.wait(500);
                    //wrap.type(BaseProject.driver, Account_Number, AccNum);
                    wrap.wait(500);
                    //com.suggestionTextBox(BaseProject.driver, AccCurrency,Account_Currency_Code, Account_Currency);
                    // com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency,Account_Currency_Code);
                    wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
                }

                if (Account_Request_Type.equalsIgnoreCase("Insta")) {
                    //wrap.wait(500);
                    //wrap.type(BaseProject.driver, Account_Number, AccNum);
                    logger.info("Am in insta section - trying to enter account number");
                          /* wrap.wait(500);
                           com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency,Account_Currency_Code);
   	                   	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");*/

                    wrap.wait(4000);
                    wrap.click(BaseProject.driver, AccNum);
                    wrap.type(BaseProject.driver, Account_Number, AccNum);
                    wrap.getElement(BaseProject.driver, AccNum).sendKeys(Keys.TAB);
                    wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
                    wrap.wait(2000);
                }



	                    /* Pur++;
	                     ActR++;
	                     Ser++;
	                     AccNu++;*/


                break;
            case "SAVINGS ACCOUNT":
                logger.info("Moved to SA");
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);

                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }
                //  wrap.type(BaseProject.driver, Account_Number, AccNum);
                //	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

                if (Account_Request_Type.equalsIgnoreCase("New")) {
                    //wrap.wait(500);
                    //wrap.type(BaseProject.driver, Account_Number, AccNum);
                    wrap.wait(500);
                    //com.suggestionTextBox(BaseProject.driver, AccCurrency,Account_Currency_Code, Account_Currency);
                    //com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency,Account_Currency_Code);
                    wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
                }


	                  /* Pur++;
	                   ActR++;
	                   Ser++;
	                   AccNu++;*/


                break;

            case "TERM DEPOSITS":
                logger.info("Moved to TD");
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
	                   /* Pur++;
	                    ActR++;
	                    Ser++;*/


                break;
            case "PERSONAL LOAN":

                logger.info("Moved to PL");

                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);

                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }


	                  /* Pur++;
	                   ActR++;
	                   Ser++;
	                   AccNu++;
*/
                break;

            case "MORTGAGE LOAN":
                break;
            case "PROMOTIONAL PACKAGES":
                break;

            default:

                try {
                    if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
                        wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                        wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
                        //Pur++;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }

                try {
                    if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) {

                        wrap.click(BaseProject.driver, AccReqType);
                        wrap.wait(1000);
                        wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                        wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");
                        // ActR++;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }

                try {
                    if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
                        if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                            wrap.wait(500);
                            wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                            wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                            // 	Ser++;
                        }
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }


                try {
                    if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
                        wrap.type(BaseProject.driver, Account_Number, AccNum);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
                        //	AccNu++;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }


                break;

        }
        //     wrap.screenShot(BaseProject.driver, "C:"+File.separator+"Arun"+File.separator+"AutomationScreenShots", Account_Request_Type);

        // }

    }

    @When("^Blind: click on Application Details tab$")
    public void click_on_Application_Details_tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        wrap.wait(2000);
        switchFrame();
        String Prod_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Prod_details)));
        wrap.click(BaseProject.driver, Prod_details);
        wrap.screenShot(BaseProject.driver, screenShotPath, "App_details");
    }




    /*@When("^Blind: Add coapplicant '(.*)'$")
	public void add_addtionalApplicant(String j)
			throws Throwable {

		switchFrame();

		int i = Integer.parseInt(j);

		int k = i+1;
		click_on_Customer_Details_tab();

		wrap.wait(3000);
		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");

		//utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

		wrap.wait(500);
		WebElement element1=BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
		JavascriptExecutor js = (JavascriptExecutor)BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");

		String	Profile_Type_Code = DBUtils.readColumnWithRowID("Coapp"+i+" ProfileType",BaseProject.scenarioID);
		String	Relation_Type_Code = DBUtils.readColumnWithRowID("Coapp"+i+" Relation Type Code",BaseProject.scenarioID);

		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Co-Applicant')])["+j+"]")).click();


			wrap.click(BaseProject.driver, profileType);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, profileType, Profile_Type_Code, "BYVISIBLETEXT");


			wrap.wait(2000);

			if(!Relation_Type_Code.isEmpty())
			{
				wrap.click(BaseProject.driver, relationTypeCode);
				wrap.wait(2000);
				wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code,"BYVISIBLETEXT");
				wrap.wait(2000);
			}

		//Customer

		String Title=com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String AddNationality=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
		String Nationality1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3=com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth=com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence=com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String AddAlias=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
		String AliasType1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasNames1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
		String RemoveAlias1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
		String AliasType2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
		String AliasNames2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
		String RemoveAlias2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
		String ClientType=com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String IDExpiryDate2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
		//String DateOfBirth2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

		String AliasFirstName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");



		String FullName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
		////convertExcelToMap("Sheet1");

		String Titles = DBUtils.readColumnWithRowID("Coapplicant"+i+" Title",BaseProject.scenarioID);
		String	First_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" First Name",BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" Middle Name",BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" Last Name",BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("Coapplicant"+i+" DOB",BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Coapplicant"+i+" Nationality Code1",BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Coapplicant"+i+" Nationality Description1",BaseProject.scenarioID);
		String Nationality_Code2= DBUtils.readColumnWithRowID("Coapplicant"+i+" Nationality Code2",BaseProject.scenarioID);
		String Nationality_Description2 = DBUtils.readColumnWithRowID("Coapplicant"+i+" Nationality Description2",BaseProject.scenarioID);
		String Country_Of_Birth = DBUtils.readColumnWithRowID("Coapplicant"+i+" Country Of Birth Description",BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Coapplicant"+i+" Residence Country Description",BaseProject.scenarioID);
		String Alias_Type =DBUtils.readColumnWithRowID("Coapplicant"+i+" Alias Type",BaseProject.scenarioID);
		String Alias = DBUtils.readColumnWithRowID("Coapplicant"+i+" Alias(es)",BaseProject.scenarioID);
		String Nationality_Code = DBUtils.readColumnWithRowID("Coapplicant"+i+" Nationality Code",BaseProject.scenarioID);
		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Coapplicant"+i+" Country Of Birth Code",BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Coapplicant"+i+" Residence Country Code",BaseProject.scenarioID);
		String	Alias_First_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" Alias First Name",BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" Alias Middle Name",BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Coapplicant"+i+" Alias Last Name",BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Coapplicant"+i+" Client Type",BaseProject.scenarioID);




		String DateOfBirth2 = "id=DateOfBirth"+k+"";

		System.out.println("Date of Birth Id: "+DateOfBirth2);

		//switchFrame();

		//String Primary=BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();



		String Customersection=com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if(CustomerSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Customersection);

		}

		wrap.wait(1000);
		//waitunlitVisiblityOfWebElement(Title);
		wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantTitle"+i);
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(FirstName);
		wrap.type(BaseProject.driver, First_Name, FirstName);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantFirstName"+i);
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(MiddleName);
		wrap.click(BaseProject.driver, MiddleName);
		wrap.type(BaseProject.driver, Middle_Name, MiddleName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantMiddleName"+i);
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(LastName);
		//wrap.click(BaseProject.driver, LastName);
		verifyTextBoxThnClick(BaseProject.driver,LastName);
		wrap.type(BaseProject.driver, Last_Name, LastName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantLastName"+i);




		//wrap.wait(2000);
		//	waitunlitVisiblityOfWebElement(DateOfBirth1);
		verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
		wrap.enterDate(BaseProject.driver,DOB, DateOfBirth2);
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDOB"+i);



		wrap.wait(1000);
		waitunlitVisiblityOfWebElement(CountryOfBirth);
		com.suggestionTextBox(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);


		wrap.screenShot(BaseProject.driver, screenShotPath, "COApplicantCountryOfBirth"+i);


		wrap.wait(1000);
		//waitunlitVisiblityOfWebElement(CountryOfResidence);

		com.suggestionTextBox(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantResidenceOfCountry"+i);


		//	waitunlitVisiblityOfWebElement(CountryOfBirth);
		wrap.wait(1000);
		waitunlitVisiblityOfWebElement(Nationality1);
		com.suggestionTextBox(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNationality"+i);




		//com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);


		waitunlitVisiblityOfWebElement(ClientType);
		wrap.click(BaseProject.driver, ClientType);
		logger.info(Client_Type);
		wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantClieentType"+i);

		//Co Applicant Alias type

		waitunlitVisiblityOfWebElement(AliasType1);
		wrap.click(BaseProject.driver, AliasType1);
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver,AliasType1 , Alias_Type, "BYVISIBLETEXT");
		wrap.wait(5000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType");


		String AliasNames_CCMS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_CCMS");
        String AliasNames_RLS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_RLS");
        String AliasNames_PRE=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_previos");

        String AliasName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasName1");
        String AliasName2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2");

switch(Alias_Type){
        case "AKA (also known as)":
               waitunlitVisiblityOfWebElement(AliasFirstName);
               wrap.type(BaseProject.driver,Alias_First_Name,AliasFirstName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName");

               waitunlitVisiblityOfWebElement(AliasMiddleName);
               wrap.type(BaseProject.driver,Alias_Middle_Name,AliasMiddleName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName");

               waitunlitVisiblityOfWebElement(AliasLastName);
               wrap.type(BaseProject.driver,Alias_Last_Name,AliasLastName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName");

               break;
        case "Previous Name":

               waitunlitVisiblityOfWebElement(AliasName);
               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        case "CCMS Relationship Name":
               waitunlitVisiblityOfWebElement(AliasName);

               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        case "RLS Relationship Name":
               waitunlitVisiblityOfWebElement(AliasName);

               wrap.type(BaseProject.driver,Alias,AliasName);
               wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
               break;

        }



		String ContactDetails=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension=com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		//convertExcelToMap("Sheet1");
		//	//utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");






		String Contact_type_Code = DBUtils.readColumnWithRowID("Coapplicant"+i+" Contact type Code1", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Coapplicant"+i+" Contact type Description1", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Coapplicant"+i+" Contact Details1", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("Coapplicant"+i+" ISD Code1", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Coapplicant"+i+" Extension1", BaseProject.scenarioID);



		String Contactsection=com.getElementProperties("BasicData", "Contactsection");



		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if(ContactSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Contactsection);

		}



		String CTD = Contact_type_Code;
		if(CTD.equals("MT1")|CTD.equals("MT2")|CTD.equals("MT3")|CTD.equals("MT4")|CTD.equals("MO5")|CTD.equals("MO6")|CTD.equals("MO7")|CTD.equals("MO8")|CTD.equals("MO9")|CTD.equals("MO1")|CTD.equals("MO2")|CTD.equals("MO3")|CTD.equals("MO4"))
		{

			wrap.click(BaseProject.driver, ContactType);
			wrap.wait(1000);
			//wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
			wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactType"+i);

			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
			wrap.click(BaseProject.driver, ContactDetails);
			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactDetails"+i);

			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantISDCode"+i);

			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
				wrap.type(BaseProject.driver, Extension_No, Extension);
		}
		else if(CTD.equals("COL")|CTD.equals("RE1")|CTD.equals("RE2")|CTD.equals("RE3")|CTD.equals("ERR")|CTD.equals("OE1")|CTD.equals("OE2")|CTD.equals("OE3")|CTD.equals("LM1")){



			wrap.click(BaseProject.driver, ContactType);
			wrap.wait(1000);
			//wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
			wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactType"+i);

			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
			wrap.click(BaseProject.driver, ContactDetails);
			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactDetails"+i);

			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantISDCode"+i);

			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
				wrap.type(BaseProject.driver, Extension_No, Extension);

		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContact");


		String Occupation=com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");





		String Occupationcode = DBUtils.readColumnWithRowID("Coapplicant"+j+" Occupation Code", BaseProject.scenarioID);
		String OccupationDescription = DBUtils.readColumnWithRowID("Coapplicant"+j+" Occupation Description", BaseProject.scenarioID);


		String Employmentsection=com.getElementProperties("BasicData", "Employmentsection");
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if(EmploymentSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Employmentsection);

		}

		//wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Occupation)));
		logger.info("Occupation code is "+Occupationcode);
		//wrap.selectformLOV_Values(BaseProject.driver, Occupation, Occupations);
		//wrap.typeInSuggestionTextbox(BaseProject.driver, Occupation, "code", OccupationDescription);
		com.suggestionTextBox(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoappOccupation"+i);



		String DocumentCategory=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument=com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");







		//convertExcelToMap("Sheet1");
		//	//utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");

		String Document_Category = DBUtils.readColumnWithRowID("Coapplicant"+i+" Document Category1",BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Coapplicant"+i+" Name of the Document1",BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Coapplicant"+i+" Document Number1",BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Coapplicant"+i+" Document Expiry Date1",BaseProject.scenarioID);
		String	Document_Signature_Date = DBUtils.readColumnWithRowID("Coapplicant"+i+" Document Signature Date1",BaseProject.scenarioID);

		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection=com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if(DocumentSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Documentsection);

		}

		//WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

		try{




			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");




			wrap.click(BaseProject.driver, NameoftheDocument);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocCatagory"+i);
			wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
			wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");




			wrap.wait(2000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNameOfTheDocument"+i);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
			wrap.type(BaseProject.driver, Document_Number, DocumentNumber);



			wrap.wait(1000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocNumber"+i);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
			wrap.enterDate(BaseProject.driver,Document_Signature_Date,DocumentSignatureDate );
			//	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantSigDate"+i);


			//	wrap.wait(500);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
			verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

			wrap.enterDate(BaseProject.driver,Document_Expiry_Date,IDExpiryDate1 );
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantExpDate");
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoappExpiryDate"+i);


			//wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
		}
		catch(Exception e)
		{


			String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
			WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
			JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
			myExecutor.executeScript("arguments[0].click();", add);


			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");




			wrap.click(BaseProject.driver, NameoftheDocument);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocCatagory"+i);
			wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
			wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");




			wrap.wait(2000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNameOfTheDocument"+i);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
			wrap.type(BaseProject.driver, Document_Number, DocumentNumber);



			wrap.wait(1000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocNumber"+i);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
			wrap.enterDate(BaseProject.driver,Document_Signature_Date,DocumentSignatureDate );
			//	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantSigDate"+i);


			//	wrap.wait(500);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
			verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

			wrap.enterDate(BaseProject.driver,Document_Expiry_Date,IDExpiryDate1 );
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantExpDate");
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoappExpiryDate"+i);


			//wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
		}



	}*/

    @When("^Blind: Add coapplicant '(.*)'$")
    public void add_addtionalApplicant(String j)
            throws Throwable {

        switchFrame();

        int i = Integer.parseInt(j);

        int k = i + 1;
        wrap.wait(1000);
        click_on_Customer_Details_tab();

           /*wrap.wait(3000);
           BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Co-Applicant')])["+i+"]")).click();
           String Add = com.getElementProperties("BasicData",
                        "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");*/

        // utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        //DBUtils.convertDBtoMap("bdquery");

           /*wrap.wait(500);
           WebElement element1=BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
           JavascriptExecutor js = (JavascriptExecutor)BaseProject.driver;
           js.executeScript("arguments[0].scrollIntoView(true);", element1);
           js.executeScript("arguments[0].click();", element1);*/


           /*String profileType = com.getElementProperties("BasicData",
                        "BasicData_CoApplicant_ProfileType_DropDown_ID");
           String relationTypeCode = com.getElementProperties("BasicData",
                        "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");

           String Profile_Type_Code = DBUtils.readColumnWithRowID("Coapp"+i+" ProfileType",BaseProject.scenarioID);
           String Relation_Type_Code = DBUtils.readColumnWithRowID("Coapp"+i+" Relation Type Code",BaseProject.scenarioID);*/

        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Co-Applicant')])[" + j + "]")).click();


                  /*wrap.click(BaseProject.driver, profileType);
                  wrap.wait(2000);
                  wrap.selectFromDropDown(BaseProject.driver, profileType, Profile_Type_Code, "BYVISIBLETEXT");*/


        wrap.wait(2000);

                  /*if(!Relation_Type_Code.isEmpty())
                  {
                        wrap.click(BaseProject.driver, relationTypeCode);
                        wrap.wait(2000);
                        wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code,"BYVISIBLETEXT");
                        wrap.wait(2000);
                  }*/

        //Customer

        String Title = "xpath=(//select[@id='Title'])[" + k + "]";
        String FirstName = "xpath=(//input[@id='FirstName'])[" + k + "]";
        String MiddleName = "xpath=(//input[@id='MiddleName'])[" + k + "]";
        String LastName = "xpath=(//input[@id='LastName'])[" + k + "]";
        String DateOfBirth1 = "xpath=(//input[@id='DateOfBirth" + k + "'])";
        String AddNationality = "xpath=(//input[@id='Title'])[" + k + "]";
        String Nationality1 = "xpath=(//input[@id='NationalityDescription1'])[" + k + "]";
        String Nationality2 = "xpath=(//input[@id='Title'])[" + k + "]";
        String Nationality3 = "xpath=(//input[@id='Title'])[" + k + "]";
        String CountryOfBirth = "xpath=(//input[@id='CountryOfBirthDescription'])[" + k + "]";
        String CountryOfResidence = "xpath=(//input[@id='CountryOfResidenceDescription'])[" + k + "]";
        String AddAlias = "xpath=(//input[@id='Title'])[" + k + "]";
        String AliasType1 = "xpath=(//select[@id='AliasType'])[" + k + "]";
        String AliasNames1 = "xpath=(//input[@id='Title'])[" + k + "]";
        String RemoveAlias1 = "xpath=(//input[@id='Title'])[" + k + "]";
        String AliasType2 = "xpath=(//input[@id='Title'])[" + k + "]";
        String AliasNames2 = "xpath=(//input[@id='Title'])[" + k + "]";
        String RemoveAlias2 = "xpath=(//input[@id='Title'])[" + k + "]";
        String ClientType = "xpath=(//select[@id='ClientType'])[" + k + "]";

        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        //String DateOfBirth2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

        String AliasFirstName = "xpath=(//input[@id='AliasFirstName'])[" + k + "]";
        String AliasMiddleName = "xpath=(//input[@id='AliasMiddleName'])[" + k + "]";
        String AliasLastName = "xpath=(//input[@id='AliasLastName'])[" + k + "]";


        String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
        ////convertExcelToMap("Sheet1");

        String Titles = DBUtils.readColumnWithRowID("Coapplicant" + i + " Title", BaseProject.scenarioID);
        String First_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " First Name", BaseProject.scenarioID);
        String Middle_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Middle Name", BaseProject.scenarioID);
        String Last_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Last Name", BaseProject.scenarioID);
        String DOB = DBUtils.readColumnWithRowID("Coapplicant" + i + " DOB", BaseProject.scenarioID);
        String Nationality_Code1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Code1", BaseProject.scenarioID);
        String Nationality_Description1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Description1", BaseProject.scenarioID);
        String Nationality_Code2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Code2", BaseProject.scenarioID);
        String Nationality_Description2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Description2", BaseProject.scenarioID);
        String Country_Of_Birth = DBUtils.readColumnWithRowID("Coapplicant" + i + " Country Of Birth Description", BaseProject.scenarioID);
        String Residence_Country = DBUtils.readColumnWithRowID("Coapplicant" + i + " Residence Country Description", BaseProject.scenarioID);
        String Alias_Type = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Type", BaseProject.scenarioID);
        String Alias = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias(es)", BaseProject.scenarioID);
        String Nationality_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Code", BaseProject.scenarioID);
        String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Country Of Birth Code", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Residence Country Code", BaseProject.scenarioID);
        String Alias_First_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias First Name", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Middle Name", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Last Name", BaseProject.scenarioID);
        String Client_Type = DBUtils.readColumnWithRowID("Coapplicant" + i + " Client Type", BaseProject.scenarioID);


        String DateOfBirth2 = "id=DateOfBirth" + k + "";

        System.out.println("Date of Birth Id: " + DateOfBirth2);

        //switchFrame();

        //String Primary=BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


        String Customersection = com.getElementProperties("BasicData", "Customersection");
        String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
        if (CustomerSection.equals("false")) {
            wrap.click(BaseProject.driver, Customersection);

        }

        wrap.wait(1000);
        //waitunlitVisiblityOfWebElement(Title);
        wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantTitle" + i);
        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(FirstName);
        wrap.type(BaseProject.driver, First_Name, FirstName);

        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantFirstName" + i);
        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(MiddleName);
        wrap.click(BaseProject.driver, MiddleName);
        wrap.type(BaseProject.driver, Middle_Name, MiddleName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantMiddleName" + i);
        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(LastName);
        //wrap.click(BaseProject.driver, LastName);
        verifyTextBoxThnClick(BaseProject.driver, LastName);
        wrap.type(BaseProject.driver, Last_Name, LastName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantLastName" + i);


        //wrap.wait(2000);
        //     waitunlitVisiblityOfWebElement(DateOfBirth1);
        verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
        wrap.enterDate(BaseProject.driver, DOB, DateOfBirth2);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDOB" + i);


        wrap.wait(1000);
        waitUntilVisibilityOfWebElement(CountryOfBirth);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth, Country_Of_Birth_Code);


        wrap.screenShot(BaseProject.driver, screenShotPath, "COApplicantCountryOfBirth" + i);


        wrap.wait(1000);
        //waitunlitVisiblityOfWebElement(CountryOfResidence);

        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country, Residence_Country_Code);

        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantResidenceOfCountry" + i);


        //     waitunlitVisiblityOfWebElement(CountryOfBirth);
        wrap.wait(1000);
        waitUntilVisibilityOfWebElement(Nationality1);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1, Nationality_Code1, Nationality_Description1);

        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNationality" + i);


        wrap.wait(1000);
        wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "B_CPDSec_Mehalaya_radioNo_CoApp"));

        //com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);


        waitUntilVisibilityOfWebElement(ClientType);
        wrap.click(BaseProject.driver, ClientType);
        logger.info(Client_Type);
        wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");

        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantClieentType" + i);

        //Co Applicant Alias type

          /* waitunlitVisiblityOfWebElement(AliasType1);
           wrap.click(BaseProject.driver, AliasType1);
           wrap.wait(1000);
           wrap.selectFromDropDown(BaseProject.driver,AliasType1 , Alias_Type, "BYVISIBLETEXT");
           wrap.wait(5000);
           wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType");


           String AliasNames_CCMS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_CCMS");
     String AliasNames_RLS=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_RLS");
     String AliasNames_PRE=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_previos");

     String AliasName=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasName1");
     String AliasName2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2");

switch(Alias_Type){
     case "AKA (also known as)":
            waitunlitVisiblityOfWebElement(AliasFirstName);
            wrap.type(BaseProject.driver,Alias_First_Name,AliasFirstName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName");

            waitunlitVisiblityOfWebElement(AliasMiddleName);
            wrap.type(BaseProject.driver,Alias_Middle_Name,AliasMiddleName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName");

            waitunlitVisiblityOfWebElement(AliasLastName);
            wrap.type(BaseProject.driver,Alias_Last_Name,AliasLastName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName");

            break;
     case "Previous Name":

            waitunlitVisiblityOfWebElement(AliasName);
            wrap.type(BaseProject.driver,Alias,AliasName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
            break;

     case "CCMS Relationship Name":
            waitunlitVisiblityOfWebElement(AliasName);

            wrap.type(BaseProject.driver,Alias,AliasName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
            break;

     case "RLS Relationship Name":
            waitunlitVisiblityOfWebElement(AliasName);

            wrap.type(BaseProject.driver,Alias,AliasName);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AliasName");
            break;

     }*/

        wrap.wait(2000);
        if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD_Coapp")))

        {
            logger.info("Am in alias section going to delete the 1st row");
            wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BD_Aliases_Row1_Coapp"));
            wrap.wait(2000);
            wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BD_Aliases_DelBtn_Coapp"));
            wrap.wait(4000);
        }

        String ContactDetails = "xpath=(//input[@id='ContactNumber'])[" + k + "]";
        String ContactType = "xpath=(//input[@id='ContactType'])[" + k + "]";
        String ContactNumber = "xpath=(//input[@id='ContactNumber'])[" + k + "]";
        String ISDCode = "xpath=(//select[@id='ISDCode'])[" + k + "]";
        String Extension = "xpath=(//input[@id='ExtensionDetails'])[" + k + "]";
        String Areacodeprop = "xpath=(//input[@id='AreaCode'])[" + k + "]";

        //convertExcelToMap("Sheet1");
        //     utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");


        String Contact_type_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact type Code1", BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact type Description1", BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact Details1", BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " ISD Code1", BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Coapplicant" + i + " Extension1", BaseProject.scenarioID);

        String Area_cd = DBUtils.readColumnWithRowID("Coapplicant" + i + " Area Code1", BaseProject.scenarioID);

        String Contactsection = com.getElementProperties("BasicData", "Contactsection");


        String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
        if (ContactSection.equals("false")) {
            wrap.click(BaseProject.driver, Contactsection);

        }


        String CTD = Contact_type_Code;
        if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {

            wrap.click(BaseProject.driver, ContactType);
            wrap.wait(1000);
            //wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
            wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactType" + i);

            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactDetails" + i);

            wrap.wait(1000);
                  /*//wrap.wait(500);
                  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                  wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
                  wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantISDCode"+i);

                  //wrap.wait(500);
                  wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                        wrap.type(BaseProject.driver, Extension_No, Extension);*/
        } else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE2") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {


            wrap.click(BaseProject.driver, ContactType);
            wrap.wait(1000);
            //wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
            wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactType" + i);

            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContactDetails" + i);

            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantISDCode" + i);

            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
            wrap.type(BaseProject.driver, Extension_No, Extension);

        } else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

            waitUntilVisibilityOfWebElement(ContactType);
            //wrap.click(BaseProject.driver, ContactType);
            wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
            //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

            //wrap.wait(1000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Areacodeprop)));
            //wrap.click(BaseProject.driver, Areacodeprop);
            // verifyTextBoxThnClick(BaseProject.driver,Areacodeprop);
            wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

            wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
            wrap.click(BaseProject.driver, Extension);
            wrap.type(BaseProject.driver, Extension_No, Extension);

            //wrap.click(BaseProject.driver, preferredContact);
        }
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContact");


        String Occupation = "xpath=(//input[@id='ProfessionDescription'])[" + k + "]";
        //String ISIC=com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");


        String Occupationcode = DBUtils.readColumnWithRowID("Coapplicant" + j + " Occupation Code", BaseProject.scenarioID);
        String OccupationDescription = DBUtils.readColumnWithRowID("Coapplicant" + j + " Occupation Description", BaseProject.scenarioID);


        String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
        String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
        if (EmploymentSection.equals("false")) {
            wrap.click(BaseProject.driver, Employmentsection);

        }

        //wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Occupation)));
        logger.info("Occupation code is " + Occupationcode);
        //wrap.selectformLOV_Values(BaseProject.driver, Occupation, Occupations);
        //wrap.typeInSuggestionTextbox(BaseProject.driver, Occupation, "code", OccupationDescription);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
        wrap.screenShot(BaseProject.driver, screenShotPath, "CoappOccupation" + i);



           /*String DocumentCategory="xpath=(//select[@id='DocumentCategory'])["+k+"]";
           String NameoftheDocument="xpath=(//select[@id='DocumentName'])["+k+"]";
           String DocumentNumber="xpath=(//input[@id='DocumentNumber'])["+k+"]";
           String IDExpiryDate1="xpath=(//input[@id='DocumentExpiryDate1'])["+k+"]";
           String DocumentSignatureDate="xpath=(//input[@id='DocumentSignatureDate1'])["+k+"]";*/

        String DocumentCategory = "xpath=(//div[@class='tabpanelnofocus' and contains(@style,'block')]//select[@id='DocumentCategory'])";
        String NameoftheDocument = "xpath=(//div[@class='tabpanelnofocus' and contains(@style,'block')]//select[@id='DocumentName'])";
        String DocumentNumber = "xpath=(//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='DocumentNumber' and contains(@data-change,'Customers(" + k + ")')])";
        String IDExpiryDate1 = "xpath=(//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='DocumentExpiryDate1' and contains(@data-change,'Customers(" + k + ")')])";
        String DocumentSignatureDate = "xpath=(//div[@class='tabpanelnofocus' and contains(@style,'block')]//input[@id='DocumentSignatureDate1' and contains(@data-change,'Customers(" + k + ")')])";


        //convertExcelToMap("Sheet1");
        //     utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Coapplicant" + i + " Document Category1", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Coapplicant" + i + " Name of the Document1", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Coapplicant" + i + " Document Number1", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Coapplicant" + i + " Document Expiry Date1", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Coapplicant" + i + " Document Signature Date1", BaseProject.scenarioID);

        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);

        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }

        //WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

        try {


            //String addtab = "(//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab '])[2]";
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            wrap.wait(2000);
            WebElement add = BaseProject.driver.findElement(By.xpath("(//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab '])[2]"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);

            wrap.click(BaseProject.driver, DocumentCategory);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");


            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocCatagory" + i);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


            wrap.wait(2000);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNameOfTheDocument" + i);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);


            wrap.wait(1000);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocNumber" + i);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantSigDate" + i);


            //     wrap.wait(500);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantExpDate");
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoappExpiryDate" + i);


            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        } catch (Exception e) {


            // String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            wrap.wait(2000);
            WebElement add = BaseProject.driver.findElement(By.xpath("(//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab '])[2]"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);


            wrap.click(BaseProject.driver, DocumentCategory);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");


            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocCatagory" + i);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


            wrap.wait(2000);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNameOfTheDocument" + i);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);


            wrap.wait(1000);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocNumber" + i);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantSigDate" + i);


            //     wrap.wait(500);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantExpDate");
            wrap.screenShot(BaseProject.driver, screenShotPath, "CoappExpiryDate" + i);


            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        }


    }

    @When("^Blind: validate optional and mandatory fields in add another Contact section '(.*)'$")
    public void uat_Tc_Validate_optional_and_mandatory_fields_in_add_another_Contact_section(String i) throws Throwable {


        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
        String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");

        int j = Integer.parseInt(i);
        int k = j + 1;
        String preferredContact = "id=PRContact" + k;

        //convertExcelToMap("Sheet1");
        //     //utils.convertExcelToMap(excelPath,"BasicData_Test data_sheet.xls","Sheet1");


        String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code" + i, BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code" + i, BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Contact Details" + i, BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("ISD Code" + i, BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Extension" + i, BaseProject.scenarioID);
        String Area_cd = DBUtils.readColumnWithRowID("Area Code" + i, BaseProject.scenarioID);


        String Contactsection = com.getElementProperties("BasicData", "Contactsection");


        String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
        if (ContactSection.equals("false")) {
            wrap.click(BaseProject.driver, Contactsection);

        }

        wrap.wait(1000);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);


        wrap.wait(2000);

        String CTD = Contact_type_Description;
        if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


            waitUntilVisibilityOfWebElement(ContactType);
            //wrap.click(BaseProject.driver, ContactType);
            //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "code", CTD);
            //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);
            wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
            //wrap.TypeToTextBoxAndTabOut(BaseProject.driver, CTD, ContactType);


            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
            wrap.wait(1000);
            wrap.click(BaseProject.driver, preferredContact);

            //wrap.wait(500);
            //Extension field not available after merge Hence commented
            //               wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
            //               wrap.type(BaseProject.driver, Extension_No, Extension);
        } else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE2") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1") | CTD.equals("LO4") | CTD.equals("EM1") | CTD.equals("EM2") | CTD.equals("EM3") | CTD.equals("EM4") | CTD.equals("EMS") | CTD.equals("ERR") | CTD.equals("EMR")) {


                  /*wrap.click(BaseProject.driver, ContactType);
            wrap.wait(3000);
            wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
                  */
            waitUntilVisibilityOfWebElement(ContactType);
            //wrap.click(BaseProject.driver, ContactType);
            wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


            //wrap.wait(500);
                  /*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
                  wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");*/

            wrap.click(BaseProject.driver, preferredContact);

            //wrap.wait(500);
                  /*       wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
                  wrap.type(BaseProject.driver, Extension_No, Extension);*/

        } else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

            waitUntilVisibilityOfWebElement(ContactType);
            //wrap.click(BaseProject.driver, ContactType);
            wrap.type(BaseProject.driver, Contact_type_Code, ContactType);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + Contact_type_Code + "')]")).click();
            //wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
            wrap.click(BaseProject.driver, ContactDetails);
            wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


            //wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
            wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

            wrap.wait(1000);
            wrap.click(BaseProject.driver, Areacodeprop);
            wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

            wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
            wrap.click(BaseProject.driver, Extension);
            wrap.type(BaseProject.driver, Extension_No, Extension);

            wrap.click(BaseProject.driver, preferredContact);
        }


        wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");

    }


    @When("^Blind: validate optional and mandatory fields in Bank Use section in Application Tab$")
    public void validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
        String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
        String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
        String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
        String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

        //2203
       /* String Sorucing_ID = "2075349";
        String Referral_ID = "2075349";
        String Acquisition_Channel = "B - Branch";
        String Fast_track_Flag ="Y - YES";
        String Application_Branch = "221 - Crescenzo Building";*/

        String Sorucing_ID = DBUtils.readColumnWithRowID("Sorucing ID", BaseProject.scenarioID);
        String Referral_ID = DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID);
        String Acquisition_Channel = DBUtils.readColumnWithRowID("Acquisition Channel", BaseProject.scenarioID);
        String Fast_track_Flag = DBUtils.readColumnWithRowID("Fast track Flag", BaseProject.scenarioID);
        String Application_Branch = DBUtils.readColumnWithRowID("Application Branch", BaseProject.scenarioID);


        String Banksection = com.getElementProperties("BasicData", "Bankusesection");
        String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
        if (BankSection.equals("false")) {
            wrap.click(BaseProject.driver, Banksection);

        }

        wrap.wait(500);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Sorucingid)));
        wrap.type(BaseProject.driver, Sorucing_ID, Sorucingid);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Sorucing_ID");


        wrap.wait(2000);


        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Referralid)));
        wrap.type(BaseProject.driver, Referral_ID, Referralid);
        wrap.screenShot(BaseProject.driver, screenShotPath, "Referralid");
        wrap.wait(500);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, AqCode)));
        wrap.selectFromDropDown(BaseProject.driver, AqCode, Acquisition_Channel, "BYVISIBLETEXT");
        wrap.screenShot(BaseProject.driver, screenShotPath, "Acquisition_Channel");
        wrap.wait(500);
        if (wrap.isElementPresent(BaseProject.driver, FasttrackFlag)) {

            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, FasttrackFlag)));
            wrap.selectFromDropDown(BaseProject.driver, FasttrackFlag, Fast_track_Flag, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "FasttrackFlag");
        }
        wrap.wait(500);
        if (wrap.isElementPresent(BaseProject.driver, Branch)) {
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Branch)));
            wrap.selectFromDropDown(BaseProject.driver, Branch, Application_Branch, "BYVISIBLETEXT");
            wrap.screenShot(BaseProject.driver, screenShotPath, "Application_Branch");

        }
    }

    @When("^Blind: validate optional and mandatory fields in AC Setup Details section in Application Tab$")
    public void validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
        String ARM = DBUtils.readColumnWithRowID("ARM Code", BaseProject.scenarioID);


        String ACsection = com.getElementProperties("BasicData", "ACsection");
        String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
        if (ACSection.equals("false")) {
            wrap.click(BaseProject.driver, ACsection);

        }

		/*String MandatoryErrorMsg = com.getElementProperties("BasicData", "Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */
        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ARMCode)));
        wrap.typeInSuggestionTextbox(BaseProject.driver, ARMCode, "code", ARM);
        wrap.screenShot(BaseProject.driver, screenShotPath, "ARMCode");
    }

    @When("^Blind: validate Remarks fields in Customer Detail Section$")
    public void validate_Remarks_fields_in_Customer_Detail_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Action = com.getElementProperties("BasicData",
                "BasicData_Action_DropDown_ID");

        String Remarks = com.getElementProperties("BasicData", "BasicData_Remarks_TextArea_ID");

        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");


//		//utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

        String remarks = DBUtils.readColumnWithRowID("Remarks", BaseProject.scenarioID);

        //	wrap.selectFromDropDown(BaseProject.driver, Action, "Approved", "BYVALUE");

        wrap.typeToTextBox(BaseProject.driver, remarks, Remarks);
    }


    @When("^Blind: validate Action in Customer Detail Section$")
    public void validate_Action_and_Remarks_fields_in_Customer_Detail_section()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        switchFrame();
        String Action = com.getElementProperties("BasicData",
                "BasicData_Action_DropDown_ID");
        String Remarks = com.getElementProperties("BasicData",
                "BasicData_Remarks_TextArea_ID");
        wrap.selectFromDropDown(BaseProject.driver, Action, "Refer To RM", "BYVALUE");
        wrap.selectFromDropDown(BaseProject.driver, Action, "Approved", "BYVALUE");

    }

    @When("^Blind: Select Refer to RM$")
    public void Select_RM()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        switchFrame();

        String Remarks = com.getElementProperties("BasicData",
                "BasicData_Remarks_TextArea_ID");

        // UAT - Dinesh - Referral - TC - 34,35,36
        String Action = com.getElementProperties("BlindData",
                "BlindData_Action_DropDown_ID");
        Select dd = new Select(wrap.getElement(BaseProject.driver, Action));
        List<WebElement> opts = dd.getOptions();
        int len = opts.size();

        for (int i = 0; i < len; i++) {
            logger.info("Dropdown " + i + " value is " + opts.get(i).getText());

            if (opts.get(i).getText().equalsIgnoreCase("Completed") || opts.get(i).getText().equalsIgnoreCase("Refer To RM"))
                logger.info("Option is either Completed or Refer To RM");
        }

        wrap.selectFromDropDown(BaseProject.driver, Action, "Completed", "BYVALUE");
        wrap.wait(1200);

        // UAT - Ends


        wrap.selectFromDropDown(BaseProject.driver, Action, "Refer To RM", "BYVALUE");


    }


    @When("^Blind: verify Save Cancel and Submit buttons in Blind Data Section for NTB single$")
    public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section_NTB_Single()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        switchFrame();
        String Cancel = com.getElementProperties("BasicData",
                "BasicData_Cancel_Button_XPATH");
        String Submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        String Save = com.getElementProperties("BasicData",
                "BasicData_Save_Button_XPATH");

        logger.info("Save visibility" + com.validateFiledVisible(BaseProject.driver, Save));
        logger.info("Save visibility is passed");
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

        wrap.wait(2000);
        logger.info("Cancel visibility" + com.validateFiledVisible(BaseProject.driver, Cancel));
        logger.info("Cancel visibility is passed");
        logger.info("Submit visibility" + com.validateFiledVisible(BaseProject.driver, Submit));
        logger.info("Submit visibility is passed");


    }


    @When("^Blind: validate Cancel buttons in Blind Data Section$")
    public void validate_Cancel_buttons_in_Basic_Data_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Cancel = com.getElementProperties("BasicData", "BasicData_Cancel_Button_XPATH");


        wrap.click(BaseProject.driver, Cancel);

    }


    @When("^Blind: validate Submit buttons in Blind Data Section$")
    public void validate_Submit_buttons_in_Basic_Data_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        wrap.wait(5000);
        String Submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
        wrap.click(BaseProject.driver, Submit);

        wrap.wait(5000);

    }

    @When("^Blind: validate Save buttons in Blind Data Section$")
    public void validate_Save_buttons_in_Basic_Data_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        String Save = com.getElementProperties("BasicData", "BasicData_Save_Button_XPATH");
        wrap.wait(3000);
        wrap.click(BaseProject.driver, Save);
    }


    @When("^Blind: verify Save Cancel and Submit buttons in Blind Data Section of Multiple Applicant$")
    public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Cancel = com.getElementProperties("BasicData",
                "BasicData_Cancel_Button_XPATH");
        String Submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        String Save = com.getElementProperties("BasicData",
                "BasicData_Save_Button_XPATH");

        com.validateFiledVisible(BaseProject.driver, Cancel);
        com.validateFiledVisible(BaseProject.driver, Submit);
        com.validateFiledVisible(BaseProject.driver, Save);

        String clickplus = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
        wrap.click(BaseProject.driver, clickplus);
        wrap.click(BaseProject.driver, clickplus);
        com.validateFiledVisible(BaseProject.driver, Cancel);
        com.validateFiledVisible(BaseProject.driver, Submit);
        com.validateFiledVisible(BaseProject.driver, Save);

    }

    // 18/03/2017 - Scenario 5

    @When("^Blind: verify Co_Applicants Add and Delete buttons in Customer Detail Section$")
    public void verify_Co_Applicants_Add_Delete_buttons_in_Customer_Detail_section()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
        String Delete = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CoapplicantRemove_Button_XPATH");


        click_on_Customer_Details_tab();
        wrap.wait(500);

        com.validateFiledEnable(BaseProject.driver, Delete);
        wrap.wait(500);

        for (int i = 1; i <= 4; i++) {


            WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
            JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
            js.executeScript("arguments[0].click();", element1);
            wrap.wait(500);

        }


        WebElement element2 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Delete this tab ']"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].click();", element2);
        wrap.wait(500);


    }

    // Scenario 69
    @When("^Blind: verify Minor Applicants in Blind Data Capture Section for ETB$")
    public void verify_Minor_Applicants_Basic_Data_Capture_Section()
            throws Throwable {

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();

        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();
		/*String Submit = com.getElementProperties("BasicData",
					"BasicData_Submit_Button_XPATH");
			wrap.click(BaseProject.driver, Submit);*/

        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
        wrap.wait(4000);
        click_on_Customer_Details_tab();
		/*Vijay
			wrap.wait(1000);
			logger.info("Before scroll div section of the page");
			String divScroll = "//div[contains(@class,'right-panel-scroll')]";

			WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));



			Actions a = new Actions(BaseProject.driver);

			for(int j=0; j<10; j++)
			{
				a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
			}
			wrap.wait(3000);
			logger.info("After scroll page");*/
        wrap.wait(500);


        String errormessage = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Primary appliacant is a minor.  Please add Guardian to proceed further.')])[3]")).getText();


        logger.info(errormessage);

        if (errormessage.contains("Primary appliacant is a minor. Please add Guardian to proceed further.")) {
            logger.info("Add Guardian Error message shows successfully");
        } else {
            logger.info("Error message for Add Guardian not shown");
            //Assert.fail();
        }

		/*wrap.wait(500);

		WebElement element1=BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor)BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);

		click_on_Customer_Details_tab();
			wrap.wait(3000);
			BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
			wrap.wait(1000);
			BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
			Actions action = new Actions(BaseProject.driver);
			action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID1");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		String MandatoryErrorMsg = com.getElementProperties("BlindData",
					"Mandatory_ErrorMsg");
			String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);


		// wrap.wait(3000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
		wrap.click(BaseProject.driver, profileType);

		WebElement element=BaseProject.driver.findElement(By.xpath("(//select[@id='ProfileType'])[2]"));
		Select sProfileType=new Select(element);
		List<WebElement> ProfileTypes=sProfileType.getOptions();

		for(WebElement option : ProfileTypes){
			if(option.getText().equals("Related Party")) {
				option.click();
				break;
			}
		}

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");
		wrap.wait(1000);
		BaseProject.driver.findElement(By.id("ProfileType")).sendKeys(Keys.TAB);


			if (MandErrMsg.equals("ProfileType")) {
				logger.info("Values cannot be blank for Profile Type");
			}
		wrap.wait(4000);
		waitunlitVisiblityOfWebElement(relationTypeCode);
		wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "Guarantor",
				"BYVISIBLETEXT");
		if (MandErrMsg.equals("RelatedPartyType")) {
				logger.info("Values cannot be blank for Relation Type Code");
			}

		validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
		validate_optional_and_mandatory_fields_in_Contact_section();
		validate_optional_and_mandatory_fields_in_Employment_section();
		//validate_optional_and_mandatory_fields_in_Document_Details_section();
		validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();

		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();*/

        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

		/*click_on_Customer_Details_tab();
		wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		Actions action = new Actions(BaseProject.driver);
		action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();
		 */

        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID1");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		/*String MandatoryErrorMsg = com.getElementProperties("BasicData",
				"Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */

        //wrap.wait(3000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("Related Party")) {
                option.click();
                break;
            }
        }


        wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");
        //wrap.wait(1000);
        //BaseProject.driver.findElement(By.id("ProfileType")).sendKeys(Keys.TAB);


		/*	if (MandErrMsg.equals("ProfileType")) {
			logger.info("Values cannot be blank for Profile Type");
		}*/
        //wrap.wait(4000);
        waitUntilVisibilityOfWebElement(relationTypeCode);
        wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "Guarantor",
                "BYVISIBLETEXT");
		/*if (MandErrMsg.equals("RelatedPartyType")) {
			logger.info("Values cannot be blank for Relation Type Code");
		}*/

        String title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID1");
        wrap.wait(1000);
        wrap.click(BaseProject.driver, title);
        wrap.selectFromDropDown(BaseProject.driver, title, "MR - Mister", "BYVISIBLETEXT");

        String first = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID1");
        wrap.wait(1000);
        wrap.click(BaseProject.driver, first);
        wrap.type(BaseProject.driver, "Thiyanes", first);

        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID1");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID1");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID1");
        String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID1");
        String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
        String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID1");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID1");
        String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
        String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
        String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
        String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
        String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType1");

        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
        ////convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Titles = DBUtils.readColumnWithRowID("Title1", BaseProject.scenarioID);
        String First_Name = DBUtils.readColumnWithRowID("First Name1", BaseProject.scenarioID);
        String Middle_Name = DBUtils.readColumnWithRowID("Middle Name1", BaseProject.scenarioID);
        String Last_Name = DBUtils.readColumnWithRowID("Last Name1", BaseProject.scenarioID);
        String DOB = DBUtils.readColumnWithRowID("DOB1", BaseProject.scenarioID);
        String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code Secondary1", BaseProject.scenarioID);
        String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description Secondary1", BaseProject.scenarioID);
        String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code Secondary2", BaseProject.scenarioID);
        String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description Secondary2", BaseProject.scenarioID);
        String Nationalty = DBUtils.readColumnWithRowID("Nationality1", BaseProject.scenarioID);
        String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth1", BaseProject.scenarioID);
        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country1", BaseProject.scenarioID);
        String Alias_Type = DBUtils.readColumnWithRowID("Alias Type1", BaseProject.scenarioID);
        String Alias = DBUtils.readColumnWithRowID("Alias(es)1", BaseProject.scenarioID);
        String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
        String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code1", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code1", BaseProject.scenarioID);
        String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name1", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name1", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name1", BaseProject.scenarioID);
        String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);

        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(MiddleName);
        wrap.click(BaseProject.driver, MiddleName);
        wrap.type(BaseProject.driver, Middle_Name, MiddleName);

        //wrap.wait(500);
        waitUntilVisibilityOfWebElement(LastName);
        //wrap.click(BaseProject.driver, LastName);
        verifyTextBoxThnClick(BaseProject.driver, LastName);
        wrap.type(BaseProject.driver, Last_Name, LastName);


        //wrap.wait(2000);
        //	waitunlitVisiblityOfWebElement(DateOfBirth1);
        verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
        wrap.enterDate(BaseProject.driver, DOB, DateOfBirth2);

        waitUntilVisibilityOfWebElement(CountryOfBirth);
        //wrap.typeInSuggestionTextbox(BaseProject.driver, CountryOfBirth, codeOrDescription, value);
        //com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code, Country_Of_Birth);

        waitUntilVisibilityOfWebElement(CountryOfResidence);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code, Residence_Country);
        //com.suggestionTextBox2(BaseProject.driver, CountryOfResidence,Residence_Country_Code,Residence_Country);

        waitUntilVisibilityOfWebElement(Nationality1);
        com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1, Nationality_Code1, Nationality_Description1);
        //com.suggestionTextBox2(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);

		/*		waitunlitVisiblityOfWebElement(Nationality1);
				com.suggestionTextBox2(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);*/

				/*
				waitunlitVisiblityOfWebElement(CountryOfBirth);

				com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);

				//wrap.wait(500);


				waitunlitVisiblityOfWebElement(CountryOfResidence);

				com.suggestionTextBox2(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);


				 */

				/*waitunlitVisiblityOfWebElement(CountryOfBirth);
				com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);*/


        waitUntilVisibilityOfWebElement(ClientType);
        wrap.click(BaseProject.driver, ClientType);
        wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");

        //Contact

        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH1");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID1");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_ID1");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID1");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


        //convertExcelToMap("Sheet1");
        ////utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");


        String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);


        String Contactsection = com.getElementProperties("BasicData", "Contactsection");

        waitUntilVisibilityOfWebElement(ContactType);
        wrap.click(BaseProject.driver, ContactType);
        //wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
        //com.suggestionTextBox(BaseProject.driver, ContactType, "MO9","Mobile No.-9");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, Contact_type_Description, Contact_type_Code);
        wrap.wait(1000);
        //com.mobileSuggestionTextBox(BaseProject.driver, ContactType, Contact_type_Code, Contact_type_Description);

        wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);

        //wrap.wait(1000);
        //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        waitUntilVisibilityOfWebElement(ContactDetails);
        wrap.click(BaseProject.driver, ContactDetails);
        //wrap.wait(1000);
        wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


        //wrap.wait(500);
        //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
        waitUntilVisibilityOfWebElement(ISDCode);
        wrap.click(BaseProject.driver, ISDCode);
        wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");

        //Employment

        String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID1");
        String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Occupations = DBUtils.readColumnWithRowID("Occupation", BaseProject.scenarioID);
        String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);


        String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
        String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
        if (EmploymentSection.equals("false")) {
            wrap.click(BaseProject.driver, Employmentsection);

        }

        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Occupation)));
        logger.info("Occupation code is " + Occupationcode);

        wrap.typeInSuggestionTextbox(BaseProject.driver, Occupation, "Description", Occupationcode);

        String isic1 = DBUtils.readColumnWithRowID("ISIC", BaseProject.scenarioID);
        String isiccode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);

        //Document

        String DocumentCategory1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID1");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID1");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID1");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID1");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID1");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category1", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document1", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number1", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date1", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date1", BaseProject.scenarioID);

        WebElement element11 = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element11);

        String Documentsection = com.getElementProperties("BasicData", "Documentsection");
        String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
        if (DocumentSection.equals("false")) {
            wrap.click(BaseProject.driver, Documentsection);

        }

        //WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

        try {



					/* wrap.wait(1000);
			 String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
				WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
				JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
				myExecutor.executeScript("arguments[0].click();", add);
					 */

            wrap.click(BaseProject.driver, DocumentCategory1);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory1)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory1, Document_Category, "BYVISIBLETEXT");

            wrap.click(BaseProject.driver, NameoftheDocument);
            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

            wrap.wait(2000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

            wrap.wait(1000);
            //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

            //	wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        } catch (Exception e) {


            String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
            WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", add);


            wrap.click(BaseProject.driver, DocumentCategory1);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory1)));
            wrap.selectFromDropDown(BaseProject.driver, DocumentCategory1, Document_Category, "BYVISIBLETEXT");

            wrap.click(BaseProject.driver, NameoftheDocument);
            //wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
            wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


            //	wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
            wrap.click(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

            //wrap.wait(2000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
            verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
            wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
            //	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

            //	wrap.wait(500);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
            verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

            wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

            //wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
        }

        //validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        //validate_optional_and_mandatory_fields_in_Contact_section();
        //validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();

    }

    @When("^Blind: verify Minor Applicants in Blind Data Capture Section for NTB$")
    public void verify_Minor_Applicants_Basic_Data_Capture_Section_NTB()
            throws Throwable {
        verify_Minor_Applicants_Basic_Data_Capture_Section();
    }

    // Scenario 65

    @When("^Blind: verify Save Cancel and Submit buttons in Blind Data Section for ETB single and Multiple $")
    public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section_ETB()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Cancel = com.getElementProperties("BasicData",
                "BasicData_Cancel_Button_XPATH");
        String Submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        String Save = com.getElementProperties("BasicData",
                "BasicData_Save_Button_XPATH");

        com.validateFiledVisible(BaseProject.driver, Cancel);
        com.validateFiledVisible(BaseProject.driver, Submit);
        com.validateFiledVisible(BaseProject.driver, Save);

        String clickplus = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
        wrap.click(BaseProject.driver, clickplus);
        wrap.click(BaseProject.driver, clickplus);
        com.validateFiledVisible(BaseProject.driver, Cancel);
        com.validateFiledVisible(BaseProject.driver, Submit);
        com.validateFiledVisible(BaseProject.driver, Save);

    }

    // Scenario 66

    @When("^Blind: validate add/Delete button for Primary applicants for ETB $")
    public void validate_Add_Delete_primary1() throws Throwable {
        String cust_details = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
        wrap.click(BaseProject.driver, cust_details);
        String Add_primary = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
        String DeleteButton = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CoapplicantRemove_Button_XPATH");
        String primaryapptext = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_primaryapplicant_text");
        String coapptext = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_primaryapplicant_text");
        if (primaryapptext.contains("Primary Applicant"))
            logger.info("It contains primary applicant");

        wrap.click(BaseProject.driver, Add_primary);
        if (coapptext.contains("Co-Applicant"))
            logger.info("It contains Co-Applicant");

        wrap.click(BaseProject.driver, Add_primary);
        if (coapptext.contains("Co-Applicant"))
            logger.info("It contains Co-Applicant");

        wrap.click(BaseProject.driver, DeleteButton);
        if (primaryapptext.contains("Primary Applicant")
                && coapptext.contains("Co-Applicant"))
            logger.info("It contains primary and co-applicant");

        wrap.click(BaseProject.driver, DeleteButton);
        if (primaryapptext.contains("Primary Applicant"))
            logger.info("It contains primary applicant");

    }


    @When("^Blind: Add Product '(.*)'$")
    public void add_addtionalproduct(String j)
            throws Throwable {

        int i = Integer.parseInt(j);
        int k = i + 1;
        wrap.wait(3000);
        //String Add = com.getElementProperties("BasicData","BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");

        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsBB']//a[@title='Add a tab ']"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

        String campcd = DBUtils.readColumnWithRowID("Campaigncode" + i + "", BaseProject.scenarioID);
        String campcddesc = DBUtils.readColumnWithRowID("CampaigncodeDescription" + i + "", BaseProject.scenarioID);
        String prdcd = DBUtils.readColumnWithRowID("ProductCode" + i + "", BaseProject.scenarioID);
        //String capmpaigncode = "xpath=(//input[@id='CampaignCode'])["+i+"]";
        String capmpaigncode = "xpath=(//label[@for='CampaignCode" + k + "']//following::div//input[@id='CampaignCode'])";
        //String productcode1="xpath=(//select[@id='ProductCode'])["+((2*i)+1)+"]";
        //String productcode="xpath=(//select[@id='ProductCode'])["+i+"]";
        //String productcode="xpath=(//select[contains(@data-change,'Products("+k+")')])";
        //String productcode="xpath=(//select[@id='ProductCode'])";
        String productcode = "xpath=(//select[@id='ProductCode' and contains(@data-change,'Products(" + k + ")')])";

        String productcodetd = "xpath=(//select[@id='ProductCode' and contains(@data-change,'Products(" + k + ")')])[2]";

        wrap.wait(2000);
        //com.suggestionTextBox(BaseProject.driver, capmpaigncode, campcd, campcddesc);
        //wrap.typeInSuggestionTextbox(BaseProject.driver, capmpaigncode, campcddesc, campcd);
        wrap.type(BaseProject.driver, campcd, capmpaigncode);
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + campcd + "')]")).click();
        wrap.wait(2000);
        BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + campcd + "')]")).sendKeys(Keys.TAB);

        if (wrap.isElementPresent(BaseProject.driver, productcode)) {
            //wrap.wait(1000);
            //wrap.click(BaseProject.driver, productcode);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, productcode)));
            verifyTextBoxThnClick(BaseProject.driver, productcode);
            //wrap.click(BaseProject.driver, productcode);
            wrap.wait(3000);
            wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
        }

        if (wrap.isElementPresent(BaseProject.driver, productcodetd)) {
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, productcodetd)));
            verifyTextBoxThnClick(BaseProject.driver, productcodetd);
            //wrap.click(BaseProject.driver, productcode);
            wrap.wait(3000);
            wrap.selectFromDropDown(BaseProject.driver, productcodetd, prdcd, "BYVISIBLETEXT");
        }


    }


    @When("^Blind: Add account section '(.*)'$")
    public void Addaccsection(String j) throws Throwable {

        int i = Integer.parseInt(j);

        int k = i + 2;
        int m = i + 1;

        //utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

        String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening" + i + "", BaseProject.scenarioID);
        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type" + i + "", BaseProject.scenarioID);
        String Service_Type = DBUtils.readColumnWithRowID("Service Type" + i + "", BaseProject.scenarioID);
        String Account_Number = DBUtils.readColumnWithRowID("Account Number" + i + "", BaseProject.scenarioID);
        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency" + i + "", BaseProject.scenarioID);
        String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code" + i + "", BaseProject.scenarioID);

        String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);


        String ACsection = com.getElementProperties("BasicData", "ACsection");


        String products = com.getElementProperties("BasicData", "differentproductselections");


        String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
        //String Purpose="xpath=(//select[@id='Purpose'])["+i+"]";
        String Purpose = "xpath=//select[@id='Purpose' and contains(@data-focus,'Products(" + m + ")')]";
        //String AccReqType="xpath=(//*[@id='IsAccountType'])["+i+"]";
        String AccReqType = "xpath=(//select[@id='IsAccountType' and contains(@data-change,'Products(" + m + ")')])";
        //String AccNum="xpath=(//input[@id='AccountNumber'])["+k+"]";
        String AccNum = "xpath=(//input[@id='AccountNumber' and contains(@data-focus,'Products(" + m + ")')])";
        String AccCurrency = "xpath=(//input[@id='Currency'])[" + k + "]";
        String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
        String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + i + "]";

        logger.info(productCatagory);
        logger.info(Purpose);
        logger.info(AccReqType);
        logger.info(AccNum);
        logger.info(AccCurrency);
        logger.info(ServiceType);
        logger.info(MinClearBal);


        String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)")).getText().trim();
        System.out.println("Product is" + ProductCategory);
        wrap.wait(1000);

        switch (ProductCategory) {
            case "CREDIT CARD":

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }

                           /*if(Account_Request_Type.equalsIgnoreCase("New"))
                           {
                                  //wrap.wait(500);
                                  //wrap.type(BaseProject.driver, Account_Number, AccNum);
                                  wrap.wait(500);
                                  com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency_Code,Account_Currency);
                               wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
                           }
                           */
                if (!Account_Request_Type.equalsIgnoreCase("New")) {
                    wrap.wait(500);
                    wrap.type(BaseProject.driver, Account_Number, AccNum);
                    wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
                }


                break;
            case "CURRENT ACCOUNT":
                logger.info("Moved to CA");
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }
                // wrap.type(BaseProject.driver, Account_Number, AccNum);
                //wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

                  /* if(Account_Request_Type.equalsIgnoreCase("New"))
                   {
                          //wrap.wait(500);
                          //wrap.type(BaseProject.driver, Account_Number, AccNum);
                          wrap.wait(500);
                          com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency,Account_Currency_Code);
                         wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
                   }
                         */


                break;
            case "SAVINGS ACCOUNT":
                logger.info("Moved to SA");
                wrap.wait(1000);
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.wait(1000);
                // wrap.click(BaseProject.driver, AccReqType);

                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.wait(3000);
                wrap.getElement(BaseProject.driver, AccReqType).sendKeys(Keys.TAB);
                wrap.wait(4000);
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }
                // wrap.type(BaseProject.driver, Account_Number, AccNum);
                //wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


                break;

            case "TERM DEPOSITS":
                logger.info("Moved to TD");
                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");


                break;
            case "PERSONAL LOAN":

                logger.info("Moved to PL");

                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

                wrap.click(BaseProject.driver, AccReqType);
                wrap.wait(1000);

                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                    wrap.wait(500);
                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                    wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
                }


                break;

            case "MORTGAGE LOAN":
                break;
            case "PROMOTIONAL PACKAGES":
                break;

            default:

                try {
                    if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
                        wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
                        wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
                        //Pur++;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }

                try {
                    if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) {

                        wrap.click(BaseProject.driver, AccReqType);
                        wrap.wait(1000);
                        wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
                        wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


                    }
                } catch (Exception e) {
                    System.out.println(e);
                }

                try {
                    if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
                        if (Account_Request_Type.equalsIgnoreCase("Existing")) {
                            wrap.wait(500);
                            wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
                            wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");

                        }
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }


                try {
                    if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
                        wrap.type(BaseProject.driver, Account_Number, AccNum);
                        wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


                    }
                } catch (Exception e) {
                    System.out.println(e);
                }


                break;

        }


    }


    // Scenario 70
    @When("^Blind: verify Guardian Applicants in Blind Data Capture Section for ETB$")
    public void verify_Guardian_Applicants_Basic_Data_Capture_Section()
            throws Throwable {

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/*Vijaywrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

		/*click_on_Customer_Details_tab();
		wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		Actions action = new Actions(BaseProject.driver);
		action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();
		 */

        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		/*String MandatoryErrorMsg = com.getElementProperties("BasicData",
				"Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */

        //wrap.wait(3000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("Related Party")) {
                option.click();
                break;
            }
        }


        wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");
        wrap.wait(1000);
        BaseProject.driver.findElement(By.id("ProfileType")).sendKeys(Keys.TAB);


		/*	if (MandErrMsg.equals("ProfileType")) {
			logger.info("Values cannot be blank for Profile Type");
		}*/
        //wrap.wait(4000);
        waitUntilVisibilityOfWebElement(relationTypeCode);
        wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "Guarantor",
                "BYVISIBLETEXT");
		/*if (MandErrMsg.equals("RelatedPartyType")) {
			logger.info("Values cannot be blank for Relation Type Code");
		}*/

        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();
    }


    @When("^Blind: verify to add another Guardian Applicants in Basic Data Capture Section for ETB$")
    public void verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section()
            throws Throwable {
        verify_Guardian_Applicants_Basic_Data_Capture_Section();
        String submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        wrap.click(BaseProject.driver, submit);
        String clntdrop = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_ProfileType_Client_XPATH");
        if (clntdrop.contains("CLIENT"))
            logger.info("Primary applicant defaulted to CLIENT type");

    }

    @When("^Blind: verify Guardian Applicants in Blind Data Capture Section for NTB$")
    public void verify_Guardian_Applicants_Basic_Data_Capture_Section_NTB()
            throws Throwable {
        verify_Guardian_Applicants_Basic_Data_Capture_Section();
    }

    @When("^Blind: verify to add another Guardian Applicants in Blind Data Capture Section for NTB$")
    public void verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section_NTB()
            throws Throwable {
        verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section();
    }


    // Scenario 71
    @When("^Blind: verify POA Applicants in Blind Data Capture Section for ETB$")
    public void verify_POA_Applicants_Basic_Data_Capture_Section()
            throws Throwable {
        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
		 wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

		/*click_on_Customer_Details_tab();
		wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		Actions action = new Actions(BaseProject.driver);
		action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();
		 */

        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		/*String MandatoryErrorMsg = com.getElementProperties("BlindData",
				"Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */

        //	wrap.wait(3000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("Related Party")) {
                option.click();
                break;
            }
        }


        wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");
        wrap.wait(1000);
        BaseProject.driver.findElement(By.id("ProfileType")).sendKeys(Keys.TAB);


		/*	if (MandErrMsg.equals("ProfileType")) {
			logger.info("Values cannot be blank for Profile Type");
		}*/
        //wrap.wait(4000);
        waitUntilVisibilityOfWebElement(relationTypeCode);
        wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "POWER OF ATTORNEY",
                "BYVISIBLETEXT");
		/*if (MandErrMsg.equals("RelatedPartyType")) {
			logger.info("Values cannot be blank for Relation Type Code");
		}*/

        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }

    @When("^Blind: verify to add another POA Applicants in Blind Data Capture Section for ETB$")
    public void verify_Addextra_POA_Applicants_Basic_Data_Capture_Section()
            throws Throwable {
        verify_Guardian_Applicants_Basic_Data_Capture_Section();
        String submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        wrap.click(BaseProject.driver, submit);
        String clntdrop = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_ProfileType_Client_XPATH");
        if (clntdrop.contains("CLIENT"))
            logger.info("Primary applicant defaulted to CLIENT type");

    }

    @When("^Blind: verify POA Applicants in Blind Data Capture Section for NTB$")
    public void verify_POA_Applicants_Basic_Data_Capture_Section_NTB()
            throws Throwable {
        verify_POA_Applicants_Basic_Data_Capture_Section();
    }

    @When("^Blind: verify to add another POA Applicants in Blind Data Capture Section for NTB$")
    public void verify_Addextra_POA_Applicants_Basic_Data_Capture_Section_NTB()
            throws Throwable {
        verify_Addextra_POA_Applicants_Basic_Data_Capture_Section();
    }

    // Scenario 75

    @When("^Blind: Verify the ACTIONS dropdown options and its functions (ETB)$")
    public void Verify_Actions_Dropdown_forETB() throws Throwable {
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();
        validate_Action_and_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();

    }

    // Scenario 61


    @When("^Blind: verify Save Cancel and Submit buttons in Blind Data Section for NTB Multiple$")
    public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section_NTB_Multiple()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String Cancel = com.getElementProperties("BasicData",
                "BasicData_Cancel_Button_XPATH");
        String Submit = com.getElementProperties("BasicData",
                "BasicData_Submit_Button_XPATH");
        String Save = com.getElementProperties("BasicData",
                "BasicData_Save_Button_XPATH");


        verify_Co_Applicants_Add_Delete_buttons_in_Customer_Detail_section();

        logger.info("Save visibility" + com.validateFiledVisible(BaseProject.driver, Save));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

        wrap.wait(3000);
        logger.info("Cancel visibility" + com.validateFiledVisible(BaseProject.driver, Cancel));
        logger.info("Submit visibility" + com.validateFiledVisible(BaseProject.driver, Submit));


    }

    // Scenario 72

    @When("^Blind: validate optional and mandatory fields in Product Details section for ETB$")
    public void validate_optional_and_mandatory_fields_in_Product_Details_section_ETB()
            throws Throwable {
        validate_optional_and_mandatory_fields_in_Product_Details_section();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
    }

    @When("^Blind: validate optional and mandatory fields in Product Details section for NTB$")
    public void validate_optional_and_mandatory_fields_in_Product_Details_section_NTB()
            throws Throwable {
        validate_optional_and_mandatory_fields_in_Product_Details_section();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
    }

    // Scenario 73

    @When("^Blind: click on Customer Details tab for ETB$")
    public void click_on_Customer_Details_tab1() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        click_on_Customer_Details_tab();
    }

    @When("^Blind: validate optional and mandatory fields in Customer Personal Details section for ETB$")
    public void validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section1()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();

    }

    @When("^Blind: validate optional and mandatory fields in Customer Personal Details section for NTB$")
    public void validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section2()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();

    }

    // Scenario 74

    @When("^Blind: Verify the ACTIONS dropdown options and its functions (NTB)")
    public void Verify_Actions_Dropdown_forNTB() throws Throwable {
        Verify_Actions_Dropdown_forETB();

    }

    // Scenario 57

    @When("^Blind: Verify the Application status as WIP in Search page for ETB")
    public static void search(WebDriver driver, String appNumber)
            throws IOException, InterruptedException {

        String search = com.getElementProperties("Search", "search");
        String applicationid = com.getElementProperties("Search",
                "applicationid");
        String searchbutton = com
                .getElementProperties("Search", "searchbutton");
        String information = com.getElementProperties("Search", "information");
        String moreinfo = com.getElementProperties("Search", "moreinfo");

        wrap.click(BaseProject.driver, search);
        wrap.wait(500);
        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
        wrap.typeToTextBox(BaseProject.driver, appNumber, applicationid);
        wrap.click(BaseProject.driver, searchbutton);
        wrap.wait(500);

        wrap.read_Table(BaseProject.driver, information);
        wrap.click(BaseProject.driver, moreinfo);
        wrap.switch_to_default_Content(BaseProject.driver);

        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
        wrap.read_Table(BaseProject.driver, information);
        wrap.switch_to_default_Content(BaseProject.driver);

    }


    @When("^Blind: Accept Mandatory Field Alert")
    public void accept_Mandatory_Field_Alert() throws Throwable {

        BaseProject.driver.switchTo().defaultContent();
        logger.info("Switched to default content");
        wrap.wait(2000);
        BaseProject.driver.switchTo().alert().accept();


    }

    @When("^Blind: verify Coapplicant Applicants in Blind Data Capture Section for ETB$")
    public void verify_Coapplicant_Applicants_Basic_Data_Capture_Section()
            throws Throwable {
        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/*Vijay wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);


        wrap.wait(6000);


        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }


    @When("^Blind: Validate Account No field in Customer Detail Section$")
    public void Validate_Account_No_field_in_Customer_Detail_Section() throws Throwable {
        wrap.wait(1000);
        switchFrame();
        wrap.wait(1000);
        String AccountNum = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
        wrap.click(BaseProject.driver, AccountNum);
        String maxLen = wrap.getElement(BaseProject.driver, AccountNum).getAttribute("maxlength");
        int maxLeng = Integer.parseInt(maxLen);

        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        //convertExcelToMap("Sheet1");

        String Acc_No = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);

        wrap.typeToTextBox(BaseProject.driver, Acc_No, AccountNum);
        int actTxtLen = wrap.getElement(BaseProject.driver, AccountNum).getAttribute("value").length();
        logger.info("The length of Account No is : " + actTxtLen);

        if (actTxtLen == maxLeng)

            logger.info("Account No is Valid");
        else
            logger.info("Account No should be 11 digits");


    }

    @When("^verify the applicant status in Application Search Blind Data$")
    public void verify_the_applicant_status_in_Application_Search_Basic_Data() throws Throwable {
        String appnum = BaseProject.appId;
        String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
        String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
        String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
        String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(3000);
        wrap.click(BaseProject.driver, search_link);
        //wrap.wait(3000);
        switchFrame();
        wrap.wait(3000);
        wrap.type(BaseProject.driver, appnum, ApplicationNo);
        wrap.click(BaseProject.driver, serach_button);
        wrap.wait(1000);
        wrap.click(BaseProject.driver, moreInfo);
        switchFrame();
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//a[text()='" + appnum + "']")).click();
        wrap.wait(1000);
        switchFrame();
        //String status=com.getElementProperties("BasicData", "Status_XPATH");
        String status = BaseProject.driver.findElement(By.xpath("//span[text()='Status']//following-sibling::div//a")).getText();
        logger.info(status);
        if (status.startsWith("WIP")) {
            logger.info("Status is displayed correctly");
            logger.info("Status is displayed with WIP");
        } else {
            logger.info("No status is with WIP");
            logger.info("Status is not displayed with WIP");
            //BaseProject.driver.quit();
        }

    }

    @When("^Blind: verify Workbasket in application search before Basic Data completion$")
    public void verify_Workbasket_In_Application_Search_Before_Basic_Data_Completion() throws Throwable {
        String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
        String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
        String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
        String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(500);
        wrap.click(BaseProject.driver, search_link);
        //wrap.wait(3000);
        switchFrame();
        wrap.wait(500);
        wrap.type(BaseProject.driver, BaseProject.appId, ApplicationNo);
        wrap.click(BaseProject.driver, serach_button);
        wrap.wait(500);
        wrap.click(BaseProject.driver, moreInfo);
        wrap.wait(500);
        switchFrame();
        wrap.wait(500);

        String BasicData = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'BasicDataCapture')]")).getText();

        Assert.assertEquals("BasicDataCapture", BasicData);


    }


    @When("^Blind: verify Workbasket in application search after Blind Data completion$")
    public void verify_Workbasket_In_Application_Search_After_Basic_Data_Completion() throws Throwable {
        String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
        String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
        String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
        String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(500);
        wrap.click(BaseProject.driver, search_link);
        //wrap.wait(3000);
        switchFrame();
        wrap.wait(500);
        wrap.type(BaseProject.driver, "IN20170410000065", ApplicationNo);
        //wrap.type(BaseProject.driver,BaseProject.appId, ApplicationNo);
        wrap.click(BaseProject.driver, serach_button);
        wrap.wait(500);
        wrap.click(BaseProject.driver, moreInfo);
        wrap.wait(500);
        switchFrame();
        wrap.wait(500);


		/*WebElement table = BaseProject.driver.findElement(By.xpath("//table[@id='bodyTbl_right']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));

		for (WebElement row : rows) {

			List<WebElement> cells = row.findElements(By.tagName("td"));

			for (WebElement cell : cells) {

				if (!cell.getText().contains("BasicDataCapture"))

				{
					logger.info("Expected: Basic Data capture not avaialble in Application Search Workbaset");
			}
				else
				{
					logger.info("Basic Data capture still avaialble in Application Search Workbaset");
					BaseProject.driver.quit();
				}

		}
	}*/

        List<WebElement> irows = BaseProject.driver.findElements(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr"));
        int iRowsCount = irows.size();
        List<WebElement> icols = BaseProject.driver.findElements(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr//th"));
        int iColsCount = icols.size();
        logger.info("Selected web table has " + iRowsCount + " Rows and " + iColsCount + " Columns");
        logger.info("");


        for (int i = 1; i <= iRowsCount; i++) {

            for (int j = 1; j <= iColsCount; j++) {
                if (i == 1) {
                    WebElement val = BaseProject.driver.findElement(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr[" + i + "]//th[" + j + "]"));
                    String a = val.getText();
                    System.out.print(a);

                } else {
                    WebElement val = BaseProject.driver.findElement(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr[" + i + "]//td[" + j + "]//span"));
                    String a = val.getText();
                    System.out.print(a);
                }
            }
            logger.info("");
        }

    }


	/*@Then("^release the application$")
	public void release_the_application() throws Throwable {

		//switchFrame();
		BaseProject.driver.findElement(By.xpath("//button[contains(text(),'Release')]")).click();

		boolean isWorkBasketNameFound = false;
		BaseProject.driver.findElement(By.xpath("(//span/button)[9]")).click();
		logger.info("The Release button is clicked successfully");
		wrap.wait(2000);


		try{
		BaseProject.driver.findElement(By.xpath("//span[text()='Confirm close']//preceding::table//following-sibling::div//div[text()='Discard']")).click();
		wrap.wait(2000);
		logger.info("The discard button is clicked successfully");
		}catch(Exception e)
		{


		}


		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.wait(2000);
		try{
		BaseProject.driver.findElement(By.xpath("//span[text()='My Worklist']")).click();
		wrap.wait(2000);

		wrap.switchFrame();

		String filter = com.getElementProperties("Fulldatacapturemaker",
				"filter_link");
		String search = com.getElementProperties("Fulldatacapturemaker",
				"search_text");
		String apply_button = com.getElementProperties("Fulldatacapturemaker",
				"apply_button");
		try {
			BaseProject.driver.findElement(By.xpath("//span[text()='" + appNumber + "']"))
					.click();
		} catch (org.openqa.selenium.NoSuchElementException e) {
			wrap.click(BaseProject.driver, filter);
			wrap.wait(1000);

			wrap.typeToTextBox(BaseProject.driver, appNumber, search);
			wrap.wait(1000);
			wrap.click(BaseProject.driver, apply_button);

			wrap.wait(1000);
			BaseProject.driver.findElement(By.xpath("//span/a[text()='"+appNumber+"']//parent::span//parent::div//parent::td//preceding-sibling::td//input[@type='checkbox']"))
					.click();

		}

		wrap.wait(2000);
		BaseProject.driver.findElement(By.xpath("//span/a[text()=' Release']")).click();
		logger.info("The Release button is clicked successfully");
		//wrap.wait(2000);
		//BaseProject.driver.quit();
		//logger.info("Closing the browser instance successfully");

		}
		catch(Exception e)

		{
			logger.info("The application ID is moved to right bucket so closing the browser instance");
			//BaseProject.driver.quit();
		}

	}*/


    @When("^Blind: Resident not allowed for PIS NRO/NRE products$")
    public void validate_Resident_Notallowed_PIS_NRONRE_Products() throws Throwable {

        wrap.wait(3000);

        String errormessage = BaseProject.driver.findElement(By.xpath("(//div/span[text()='Primary Applicant Country of Residence should not be IN for NR products'])[3]")).getText();

        logger.info("Retrived Error message" + errormessage);
        // List<WebElement>errormessages= BaseProject.driver.findElements(By.xpath("//div[@bsimplelayout='true']/div//div[@class='content-inner ']/div[@class='field-item dataValueRead']/span[text()='Primary Applicant Country of Residence should not be IN for NR products']"));

        if (errormessage.contains("Residence should not be IN for NR products")) {
            logger.info(" Primary Applicant Country of Residence should not be IN for NR products Error message shows successfully");
        } else {
            logger.info("Error message for Primary Applicant Country of Residence should not be IN for NR products not shown");
            Assert.fail();
        }
    }


    @When("^Blind: Non-Resident not allowed for NDPMS products$")
    public void validate_NonResident_Notallowed_NDPMS_Products() throws Throwable {

        String cust_details = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
        wrap.click(BaseProject.driver, cust_details);


        BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']")).click();

        WebElement element = BaseProject.driver.findElement(By.id("CountryOfResidenceDescription"));
        ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        logger.info("Moved to Country of Residence");


        wrap.wait(2000);
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CountryOfResidence)));
        com.selectInSuggestionBox(BaseProject.driver, CountryOfResidence, "MY", "MALAYSIA");


        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


        wrap.wait(3000);

        String errormessage = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Non-Resident User Not allowed for 371 - NDPMS Linked Savings Account Product')])[3]")).getText();
        logger.info("Retrieved Error message:" + errormessage);
        wrap.wait(3000);

        if (errormessage.contains("User Not allowed for 371")) {
            logger.info(" Non-Resident User Not allowed for 371 Error message shows successfully");
        } else {
            logger.info("Retrieved Error Message:" + errormessage);
            logger.info("Error message for Non-Resident User Not allowed for 371 not shown");
            Assert.fail();
        }

    }

    @When("^Blind: validate ISD Code default to 91 for Resident country is INDIA$")
    public void validate_ISDCode_Default_91_For_Residentcountry_INDIA()
            throws Throwable {


        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        //convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);


        switchFrame();

        String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CountryOfResidence)));
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code, Residence_Country);

        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");


        String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		/*String Contactsection=com.getElementProperties("BasicData", "Contactsection");

		wrap.scroll_to(BaseProject.driver, Contactsection);
		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if(ContactSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Contactsection);

		}

		wrap.click(BaseProject.driver, ContactType);
		wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");*/


        waitUntilVisibilityOfWebElement(ContactType);
        wrap.click(BaseProject.driver, ContactType);
        //wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
        //com.suggestionTextBox(BaseProject.driver, ContactType, "MO9","Mobile No.-9");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, Contact_type_Description, Contact_type_Code);
        wrap.wait(1000);
        wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);

        //wrap.wait(1000);
        //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        waitUntilVisibilityOfWebElement(ContactDetails);
        wrap.click(BaseProject.driver, ContactDetails);
        wrap.type(BaseProject.driver, Contact_Details, ContactDetails);

        wrap.wait(2000);
        Select ISDValues = new Select(BaseProject.driver.findElement(By.id("ISDCode")));
        String Selectedvalue = ISDValues.getFirstSelectedOption().getText();
        logger.info("Defaulted value is:" + Selectedvalue);

        Assert.assertEquals(Selectedvalue, "91");
        logger.info("Defaulted to 91 successfully");

    }


    @When("^Blind: validate ISD Code not default to 91 for Resident country is not INDIA$")
    public void validate_ISDCode_NotDefault_91_For_Residentcountry_Notas_INDIA()
            throws Throwable {


        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        //convertExcelToMap("Sheet1");
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);


        switchFrame();

        String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CountryOfResidence)));
        com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, "MY", "MALAYSIA");


        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");


        String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		/*String Contactsection=com.getElementProperties("BasicData", "Contactsection");

		wrap.scroll_to(BaseProject.driver, Contactsection);
		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if(ContactSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Contactsection);

		}

		wrap.click(BaseProject.driver, ContactType);
		wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");*/

        waitUntilVisibilityOfWebElement(ContactType);
        wrap.click(BaseProject.driver, ContactType);
        //wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
        //com.suggestionTextBox(BaseProject.driver, ContactType, "MO9","Mobile No.-9");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "Mobile No-1","MT1");
        //wrap.typeInSuggestionTextbox(BaseProject.driver, ContactType, Contact_type_Description, Contact_type_Code);
        wrap.wait(1000);
        wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);

        //wrap.wait(1000);
        //wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        waitUntilVisibilityOfWebElement(ContactDetails);
        wrap.click(BaseProject.driver, ContactDetails);
        wrap.type(BaseProject.driver, Contact_Details, ContactDetails);

        Thread.sleep(1000);
        Select ISDValues = new Select(BaseProject.driver.findElement(By.id("ISDCode")));
        String Selectedvalue = ISDValues.getFirstSelectedOption().getText();
        logger.info("Defaulted value is:" + Selectedvalue);


        if (!Selectedvalue.equals("91")) {

            logger.info("Not Defaulted to 91 successfully");
        } else {
            logger.info("Defaulted to 91 wrongly");
            Assert.fail();
        }
    }

    @When("^Blind: Enter Multiple Product Data in A/C Setup section$")
    public void enter_multiple_productData_in_AC_Setup_section() throws Throwable {

        validate_optional_and_mandatory_fields_in_AC_Setup_section();


        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
        String Account_Number2 = DBUtils.readColumnWithRowID("Account Number2", BaseProject.scenarioID);

        if (!Account_Request_Type.equalsIgnoreCase("New")) {
            WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", element1);
            myExecutor.executeScript("arguments[0].value='" + Account_Number2 + "';", element1);
        }


        validate_optional_and_mandatory_fields_in_AC_Setup_section();

        String Account_Number3 = DBUtils.readColumnWithRowID("Account Number3", BaseProject.scenarioID);
        if (!Account_Request_Type.equalsIgnoreCase("New")) {
            WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", element1);
            myExecutor.executeScript("arguments[0].value='" + Account_Number3 + "';", element1);
        }


        validate_optional_and_mandatory_fields_in_AC_Setup_section();

        String Account_Number4 = DBUtils.readColumnWithRowID("Account Number4", BaseProject.scenarioID);

        if (!Account_Request_Type.equalsIgnoreCase("New")) {
            WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
            JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
            myExecutor.executeScript("arguments[0].click();", element1);
            myExecutor.executeScript("arguments[0].value='" + Account_Number4 + "';", element1);
        }


    }

    @Given("^Blind: Verify Multiple Products in Basic Data Capture$")
    public void multipleProductSelect1() throws IOException, InterruptedException {
        //utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","ProdCat");


        String product1 = utils.readColumn("ProductCode_Description", 0);
        logger.info("product1 ===== " + product1);
        List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(",")));
        logger.info("myList ===== " + myList);
        for (int i = 0; i < myList.size(); i++) {
            String EachProduct = myList.get(i).trim();
            logger.info(EachProduct);

        }

        int a = 0;

        List<String> allproductExcel = new ArrayList<String>(Arrays.asList(product1.split(",")));

        for (String eachproductExcel : allproductExcel) {
            logger.info("Product from Excel: " + eachproductExcel);

            List<WebElement> allproductBasicData = BaseProject.driver.findElements(By.xpath("//li[contains(@tabbedrepeatid,'SubSectionProductDetailsBTR')]//nobr/span"));

            for (WebElement eachproductBasicData : allproductBasicData) {
                String productBasicData = eachproductBasicData.getText();
                logger.info("Product from Basic Data: " + productBasicData);

                if (eachproductExcel.contains(productBasicData)) {
                    logger.info("Products Selected in Product Catelogue: " + eachproductExcel + "is avaialble in Basic Data: " + productBasicData);
                    a = 1;
                    break;
                } else {
                    a = 0;
                }

            }

            if (a == 0) {
                logger.info("Products Selected in Product Catelogue is not avaialble in Basic Data");
                Assert.fail();
            }
        }
    }

    @When("^Blind: verify the applicant using Account Number in Application Search '(.*)'$")
    public void verify_the_applicant_usingAccountNumber_in_Application_Search(String appNumber) throws Throwable {
        String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
        String AccountNumber = com.getElementProperties("BasicData", "AccountNumber_ID");
        String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
        String firstApplicant = com.getElementProperties("BasicData", "FirstApplicant");


        wrap.wait(3000);
        wrap.click(BaseProject.driver, search_link);
        switchFrame();
        wrap.wait(3000);
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
        String Account_Number2 = DBUtils.readColumnWithRowID("Account Number2", BaseProject.scenarioID);
        String Account_Number3 = DBUtils.readColumnWithRowID("Account Number3", BaseProject.scenarioID);
        String Account_Number4 = DBUtils.readColumnWithRowID("Account Number4", BaseProject.scenarioID);

        wrap.type(BaseProject.driver, Account_Number, AccountNumber);
        wrap.click(BaseProject.driver, serach_button);
        String FirstApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
        Assert.assertEquals(appNumber, FirstApplicant);

        wrap.type(BaseProject.driver, Account_Number2, AccountNumber);
        wrap.click(BaseProject.driver, serach_button);
        String SecondApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
        Assert.assertEquals(appNumber, SecondApplicant);

        wrap.type(BaseProject.driver, Account_Number3, AccountNumber);
        wrap.click(BaseProject.driver, serach_button);
        String ThirdApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
        Assert.assertEquals(appNumber, ThirdApplicant);

        wrap.type(BaseProject.driver, Account_Number4, AccountNumber);
        wrap.click(BaseProject.driver, serach_button);
        String FourthApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
        Assert.assertEquals(appNumber, FourthApplicant);

    }

    @Given("^Blind: Verify Multiple Products in Blind Data Capture$")
    public void multipleProductSelect() throws IOException, InterruptedException {
        //utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet.xls","ProdCat");


        String product1 = utils.readColumn("ProductCode_Description", 0);
        logger.info("product1 ===== " + product1);
        List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(",")));
        logger.info("myList ===== " + myList);
        for (int i = 0; i < myList.size(); i++) {
            String EachProduct = myList.get(i).trim();
            logger.info(EachProduct);

        }

        int a = 0;

        List<String> allproductExcel = new ArrayList<String>(Arrays.asList(product1.split(",")));

        for (String eachproductExcel : allproductExcel) {
            logger.info("Product from Excel: " + eachproductExcel);

            List<WebElement> allproductBasicData = BaseProject.driver.findElements(By.xpath("//li[contains(@tabbedrepeatid,'SubSectionProductDetailsBTR')]//nobr/span"));

            for (WebElement eachproductBasicData : allproductBasicData) {
                String productBasicData = eachproductBasicData.getText();
                logger.info("Product from Basic Data: " + productBasicData);

                if (eachproductExcel.contains(productBasicData)) {
                    logger.info("Products Selected in Product Catelogue: " + eachproductExcel + "is avaialble in Basic Data: " + productBasicData);
                    a = 1;
                    break;
                } else {
                    a = 0;
                }

            }

            if (a == 0) {
                logger.info("Products Selected in Product Catelogue is not avaialble in Basic Data");
                Assert.fail();
            }
        }
    }


    @When("^Blind: verify restriction SanctionedCountry$")
    public void verify_restriction_SanctionedCountry() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String errormessage = com.getElementProperties("BasicData", "BasicData_SancationedCountry_XPATH");
        String BasicData_ContactTypeText_XPATH = com.getElementProperties("BasicData", "BasicData_ContactTypeText_XPATH");

        String expectederror = "Email belongs to sanctioned country";

        switchFrame();

        WebElement element = wrap.getElement(BaseProject.driver, BasicData_ContactTypeText_XPATH);
        ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);


        wrap.click(BaseProject.driver, ContactType);
        wrap.wait(1000);
        wrap.selectFromDropDown(BaseProject.driver, ContactType, "FOR EMAIL CONTACT", "BYVISIBLETEXT");

        // Cuba
        wrap.wait(500);
        wrap.type(BaseProject.driver, "Test@gov.CU", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        String actualerror = wrap.getTextValue(BaseProject.driver, errormessage);
        Assert.assertEquals(expectederror, actualerror);


        // Iran

        wrap.wait(2000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        wrap.type(BaseProject.driver, "Test@gov.IR", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        Assert.assertEquals(expectederror, actualerror);

        // North Korea

        wrap.wait(2000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        wrap.type(BaseProject.driver, "Test@gov.KP", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        Assert.assertEquals(expectederror, actualerror);


        // South Sudan

        wrap.wait(2000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        wrap.type(BaseProject.driver, "Test@gov.SS", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        Assert.assertEquals(expectederror, actualerror);


        // Sudan

        wrap.wait(2000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        wrap.type(BaseProject.driver, "Test@gov.SD", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        Assert.assertEquals(expectederror, actualerror);


        // Syria

        wrap.wait(2000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
        wrap.type(BaseProject.driver, "Test@gov.SY", ContactDetails);
        BaseProject.driver.findElement(By.id("ContactNumber")).sendKeys(Keys.TAB);
        Assert.assertEquals(expectederror, actualerror);

    }

    @When("^Blind: Enter Country of residence to Non-Residence$")
    public void enter_CountryofResidence_to_nonResidence() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        String cust_details = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
        wrap.click(BaseProject.driver, cust_details);


        BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']")).click();

        WebElement element = BaseProject.driver.findElement(By.id("CountryOfResidenceDescription"));
        ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        logger.info("Moved to Country of Residence");


        wrap.wait(2000);
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

        wrap.wait(1000);
        com.selectInSuggestionBox(BaseProject.driver, CountryOfResidence, "SG", "SINGAPORE");
    }


    @When("^Blind: Select NDPS Product in Product Details section$")
    public void select_NDPSProduct() throws IOException, InterruptedException {
        // Write code here that turns the phrase above into concrete actions

        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


        wrap.click(BaseProject.driver, ProductDetails);
        wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "SAVINGS ACCOUNT", "BYVISIBLETEXT");
        wrap.wait(3000);
        wrap.selectFromDropDown(BaseProject.driver, ProductCode, "371 - NDPMS Linked Savings Account", "BYVISIBLETEXT");


    }


    @When("^Blind: Select NRO Product in Product Details section$")
    public void select_NROProduct() throws IOException, InterruptedException {
        // Write code here that turns the phrase above into concrete actions

        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


        wrap.click(BaseProject.driver, ProductDetails);
        wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "SAVINGS ACCOUNT", "BYVISIBLETEXT");
        wrap.wait(3000);
        wrap.selectFromDropDown(BaseProject.driver, ProductCode, "350 - PIS NRO ACCOUNT", "BYVISIBLETEXT");


    }

    @When("^Blind: verify Coapplicant NON-CLEINT in Blind Data Capture Section$")
    public void verify_coapplicant_NonClient_Basic_Data_Capture_Section()
            throws Throwable {
        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
	 wrap.wait(1000);
	logger.info("Before scroll div section of the page");
	String divScroll = "//div[contains(@class,'right-panel-scroll')]";

	WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

	Actions a = new Actions(BaseProject.driver);

	for(int j=0; j<10; j++)
	{
		a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
	}
	wrap.wait(3000);
	logger.info("After scroll page");*/
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].click();", element1);


        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


        //	wrap.wait(3000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("NON-CLIENT")) {
                option.click();
                break;
            }
        }


        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();

        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }

    @When("^Blind: verify Coapplicant in Blind Data Capture Section$")
    public void verify_coapplicant_Basic_Data_Capture_Section()
            throws Throwable {
        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
		 wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].click();", element1);


        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


        //	wrap.wait(3000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("CLIENT")) {
                option.click();
                break;
            }
        }


        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();

        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }

    @Given("^Blind: validate editable/non editable in Customer details$")
    public void validate_editable_non_editable_in_Customer_details() throws Throwable {

        wrap.wait(1000);
        switchFrame();
        wrap.wait(1000);


        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
        String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
        String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        com.validateEditable1(BaseProject.driver, Title, "Title");
        com.validateEditable1(BaseProject.driver, FirstName, "FirstName");
        com.validateEditable1(BaseProject.driver, MiddleName, "MiddleName");
        com.validateEditable1(BaseProject.driver, LastName, "LastName");
        com.validateEditable1(BaseProject.driver, DateOfBirth1, "DateOfBirth");
        com.validateEditable1(BaseProject.driver, Nationality1, "Nationality");
        com.validateEditable1(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
        com.validateEditable1(BaseProject.driver, CountryOfResidence, "CountryOfResidence");
        if (wrap.isElementPresent(BaseProject.driver, ClientType)) {
            com.validateEditable1(BaseProject.driver, ClientType, "ClientType");
        }
        com.validateEditable1(BaseProject.driver, AliasType1, "AliasType");

        com.validateEditable1(BaseProject.driver, ContactType, "ContactType");
        //com.validateEditable1(BaseProject.driver,ISDCode,"ISDCode");
        //com.validateEditable1(BaseProject.driver,Extension,"Extension");

        com.validateEditable1(BaseProject.driver, Occupation, "Occupation");

        com.validateEditable1(BaseProject.driver, ISIC, "ISIC");

		/*		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);
		wrap.wait(1000);
		 */        //System.out.println("DocumentCategory--------------------"+DocumentCategory);
		/*	String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);
		 */
        com.validateEditable1(BaseProject.driver, DocumentCategory, "DocumentCategory");
        com.validateEditable1(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
        com.validateEditable1(BaseProject.driver, DocumentNumber, "DocumentNumber");
        com.validateEditable1(BaseProject.driver, IDExpiryDate1, "IDExpiryDate1");
        com.validateEditable1(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");


    }


    @Given("^Blind: validate editable/non editable in Product details$")
    public void validate_editable_non_editable_in_Product_details() throws Throwable {

        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        wrap.click(BaseProject.driver, ProductDetails);
        wrap.wait(1000);

        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
        String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
        String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
        String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
        String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");


        com.validateEditable1(BaseProject.driver, ProductCategory, "ProductCategory");
        com.validateEditable1(BaseProject.driver, ProductCode, "ProductCode");
        //	com.validateEditable1(BaseProject.driver,MinClearBal,"MinClearBal");
        com.validateEditable1(BaseProject.driver, Purpose, "Purpose");
        com.validateEditable1(BaseProject.driver, AccReqType, "AccReqType");
        //com.validateEditable1(BaseProject.driver,AccCurrency,"AccCurrency");
        //com.validateEditable1(BaseProject.driver,AccNum,"AccNum");


    }

    @When("^Blind: verify Coapplicant Applicants in Basic Data Capture Section for ETB$")
    public void verify_Coapplicant_Applicants_Basic_Data_Capture_Section1()
            throws Throwable {
        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


        wrap.wait(1000);
        logger.info("Before scroll div section of the page");
        String divScroll = "//div[contains(@class,'right-panel-scroll')]";

        WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

        Actions a = new Actions(BaseProject.driver);

        for (int j = 0; j < 10; j++) {
            a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
        }
        wrap.wait(3000);
        logger.info("After scroll page");
        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].click();", element1);


        wrap.wait(6000);


        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        //validate_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }

    @Given("^Blind: validate editable/non editable in Application details$")
    public void validate_editable_non_editable_in_Application_details() throws Throwable {

        String App_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
        wrap.click(BaseProject.driver, App_details);
        wrap.wait(1000);


        String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
        String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
        String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
        String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
        String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

        String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");


        com.validateEditable1(BaseProject.driver, Sorucingid, "Sorucingid");
        com.validateEditable1(BaseProject.driver, Referralid, "Referralid");
        com.validateEditable1(BaseProject.driver, AqCode, "AcquisitionCode");
        com.validateEditable1(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
        com.validateEditable1(BaseProject.driver, Branch, "ApplicationBranch");
        com.validateEditable1(BaseProject.driver, ARMCode, "ARMCode");

    }


    @When("^Blind: Validate Mandatory fields in Customer Detail Section$")
    public void Validate_Mandatory_fields_in_Customer_Detail_Section() throws Throwable {
        switchFrame();
        wrap.wait(1000);
        String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
        wrap.scroll_to(BaseProject.driver, submit);
        wrap.click(BaseProject.driver, submit);
        accept_Mandatory_Field_Alert();
        wrap.wait(1000);
        switchFrame();
        wrap.wait(1000);


        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Title_Mandmsg_XPATH"), "Title");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Firstname_Mandmsg_XPATH"), "First name");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Date_of_birth_Mandmsg_XPATH"), "DOB");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "CountryOfBirth_Mandmsg_XPATH"), "Country Of Birth");

        if (wrap.isElementPresent(BaseProject.driver, "Client_Type_Mandmsg_XPATH")) {
            com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Client_Type_Mandmsg_XPATH"), "Client Type");
        }
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Alias_Type_Mandmsg_XPATH"), "Alias Type");

        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Contact_Type_Mandmsg_XPATH"), "Contact Type");
        //com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ISD_Type_Mandmsg_XPATH"), "ISD Code");

        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Occupation_Mandmsg_XPATH"), "Occupation");
        //com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ISIC_Mandmsg_XPATH"), "Occupation");


        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Doc_Category_Mandmsg"), "Document Category");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Name_Of_Document_Mandmsg_XPATH"), "Name of the Document");

        //	com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Remarks_Mandmsg_XPATH"), "Remarks");
    }

    @When("^Blind: Validate Mandatory fields in Product Detail Section$")
    public void Validate_Mandatory_fields_in_Product_Detail_Section() throws Throwable {
        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        wrap.click(BaseProject.driver, ProductDetails);
        wrap.wait(4000);
        String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
        wrap.scroll_to(BaseProject.driver, submit);
        wrap.click(BaseProject.driver, submit);
        accept_Mandatory_Field_Alert();
        wrap.wait(1000);
        switchFrame();
        wrap.wait(1000);

        //com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Purpose_of_account_Mandmsg_XPATH"), "Purpose of account");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Account_Request_Type_Mandmsg_XPATH"), "Account Request Type");
        //	com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Account_Number_Mandmsg_XPATH"), "Account Number");
    }

    @When("^Blind: Validate Mandatory fields in Application Detail Section$")
    public void Validate_Mandatory_fields_in_Application_Detail_Section() throws Throwable {
        String Prod_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
        wrap.click(BaseProject.driver, Prod_details);
        wrap.wait(1000);
        String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
        wrap.scroll_to(BaseProject.driver, submit);
        wrap.click(BaseProject.driver, submit);
        accept_Mandatory_Field_Alert();
        wrap.wait(1000);
        switchFrame();
        wrap.wait(1000);

        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Sourcing_Code_Mandmsg_XPATH"), "Sourcing ID");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Referral_Code_Mandmsg_XPATH"), "Referral ID");
        com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ARM_Code_Mandmsg_XPATH"), "ARM code");
        //	com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ApplicationBranch_Mandmsg_XPATH"), "Home Branch");
    }

    @When("^Blind: Validate alpha numeric fields in Customer Detail Section$")
    public void Validate_alpha_numeric_fields_in_Customer_Detail_Section() throws Throwable {


        String Remarks = com.getElementProperties("BasicData",
                "BasicData_Remarks_TextArea_ID");
        wrap.type(BaseProject.driver, "TEST", Remarks);

        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
        String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
        String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
        String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
        String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
        String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
        String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
        String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");
        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");

        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

        String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
        String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");

        wrap.scroll_to(BaseProject.driver, Title);
        waitUntilVisibilityOfWebElement(Title);
        com.validateAlphanumeric(BaseProject.driver, Title, "Title");
        com.validateAlphanumeric(BaseProject.driver, FirstName, "FirstName");
        com.validateAlphanumeric(BaseProject.driver, MiddleName, "MiddleName");
        com.validateAlphanumeric(BaseProject.driver, LastName, "LastName");
        com.validateAlphanumeric(BaseProject.driver, DateOfBirth1, "DateOfBirth");
        com.validateAlphanumeric(BaseProject.driver, Nationality1, "Nationality");
        com.validateAlphanumeric(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
        com.validateAlphanumeric(BaseProject.driver, CountryOfResidence, "CountryOfResidence");
        com.validateAlphanumeric(BaseProject.driver, ClientType, "ClientType");
        com.validateAlphanumeric(BaseProject.driver, AliasType1, "AliasType1");

		/*try{

			com.validateAlphanumeric(BaseProject.driver,AliasFirstName , "AliasFirstName");
			com.validateAlphanumeric(BaseProject.driver,AliasMiddleName , "AliasMiddleName");
			com.validateAlphanumeric(BaseProject.driver,AliasLastName , "AliasLastName");

		}
		catch(Exception e)
		{

			com.validateAlphanumeric(BaseProject.driver,AliasNames1,"Alias Full Name");
		}*/

        try {
            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, ContactType, "ContactType");
			/*com.validateAlphanumeric(BaseProject.driver, ContactDetails, "ContactDetails");
			com.validateAlphanumeric(BaseProject.driver,ISDCode, "ISDCode");
			com.validateAlphanumeric(BaseProject.driver,Extension, "Extension");*/
        } catch (Exception e) {

            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, ContactType, "ContactType");
			/*com.validateAlphanumeric(BaseProject.driver, ContactDetails, "ContactDetails");
			com.validateAlphanumeric(BaseProject.driver,ISDCode, "ISDCode");
			com.validateAlphanumeric(BaseProject.driver,Extension, "Extension");*/
        }

        try {

            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, Occupation, "Occupation");
            com.validateAlphanumeric(BaseProject.driver, ISIC, "ISIC");
        } catch (Exception e) {
            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, Occupation, "Occupation");
            com.validateAlphanumeric(BaseProject.driver, ISIC, "ISIC");
        }

        try {

            logger.info("Clicking Document Category Section");
            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, DocumentCategory, "DocumentCategory");
            com.validateAlphanumeric(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
            com.validateAlphanumeric(BaseProject.driver, DocumentNumber, "DocumentNumber");
            com.validateAlphanumeric(BaseProject.driver, IDExpiryDate1, "IDExpiryDate1");
            com.validateAlphanumeric(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");
        } catch (Exception e) {

            logger.info("Clicking Document Category Section");
            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
            element.click();
            com.validateAlphanumeric(BaseProject.driver, DocumentCategory, "DocumentCategory");
            com.validateAlphanumeric(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
            com.validateAlphanumeric(BaseProject.driver, DocumentNumber, "DocumentNumber");
            com.validateAlphanumeric(BaseProject.driver, IDExpiryDate1, "IDExpiryDate1");
            com.validateAlphanumeric(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");

        }

        com.validateAlphanumeric(BaseProject.driver, Remarks, "Remarks");
    }


    @When("^Blind: Validate alpha numeric fields in Product Detail Section$")
    public void Validate_alpha_numeric_fields_in_Product_Detail_Section() throws Throwable {


        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
        String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
        String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
        String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
        String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");


        com.validateAlphanumeric(BaseProject.driver, ProductCategory, "ProductCategory");
        com.validateAlphanumeric(BaseProject.driver, ProductCode, "ProductCode");
        //	com.validateAlphanumeric(BaseProject.driver,MinClearBal , "MinClearBal");
        com.validateAlphanumeric(BaseProject.driver, Purpose, "Purpose of Account Opening");
        com.validateAlphanumeric(BaseProject.driver, AccReqType, "AccReqType");
        //com.validateAlphanumeric(BaseProject.driver, AccNum, "Acc Number");
        //com.validateAlphanumeric(BaseProject.driver, AccCurrency, "Acc Currency");

    }


    @When("^Blind: Validate alpha numeric fields in Application Detail Section$")
    public void Validate_alpha_numeric_fields_in_Application_Detail_Section() throws Throwable {

        String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
        String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
        String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
        String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
        String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

        String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");

        com.validateAlphanumeric(BaseProject.driver, Sorucingid, "Sorucingid");
        com.validateAlphanumeric(BaseProject.driver, Referralid, "Referralid");
        com.validateAlphanumeric(BaseProject.driver, AqCode, "AcquisitionCode");
        com.validateAlphanumeric(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
        com.validateAlphanumeric(BaseProject.driver, Branch, "Branch");
        com.validateAlphanumeric(BaseProject.driver, ARMCode, "ARM Code");


    }

    @Given("^Blind: select multiple products$")
    public void multipleProductSelectBasic() {
        try {
            String branchCode = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_BranchCode_TextBox_Id");
            String submit = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_Submit_Button_XPATH");
            logger.info("BranchCode ===== " + branchCode);

            //utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","ProdCat");

            wrap.wait(1000);

            String branchCode1 = utils.readColumn("BrachCode", 0);
            logger.info("branchCode1 ===== " + branchCode1);
            String actualBranchCode = branchCode1.replaceAll(File.separator + ".0*$", "");
            logger.info("actualBranchCode ===== " + actualBranchCode);

            wrap.typeToTextBox(BaseProject.driver, actualBranchCode, branchCode);

            String product1 = utils.readColumn("ProductCode_Description", 0);
            logger.info("product1 ===== " + product1);
            List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(",")));
            logger.info("myList ===== " + myList);
            String prdcode = com.getElementProperties("ProductCatalogue", "productCode");
            logger.info("prdcode ===== " + prdcode);
            logger.info("myList.get(0) ===== " + myList.get(0));
            for (int i = 0; i < myList.size(); i++) {
                String mycheckbox = prdcode.replace("**data**", myList.get(i));
                wrap.click(BaseProject.driver, mycheckbox);
            }

            wrap.wait(1000);
            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, submit)));
            wrap.click(BaseProject.driver, submit);

            wrap.wait(2000);
        } catch (Exception e) {
            logger.info("The product is not getting selected" + e);
        }
    }

    @Given("Verify field order in Blind customer page1")
    public void verifybasicFieldOrder1() throws Throwable {
        Thread.sleep(2000);

        List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsB']//span[contains(text(),'Full name')]"));

        List<String> fieldLabels = new ArrayList<String>();

        for (WebElement we : fields) {

            fieldLabels.add(we.getText());
        }
        Iterator<String> it = fieldLabels.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order");

    }

    @Given("Verify field order in Blind product page2")
    public void verifybasicFieldOrder2() throws Throwable {
        Thread.sleep(2000);
        List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsBB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsBB']//span[contains(text(),'Account Status')]"));

        List<String> fieldLabels = new ArrayList<String>();

        for (WebElement we : fields) {

            fieldLabels.add(we.getText());
        }
        Iterator<String> it = fieldLabels.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order2");

    }

    @Given("Verify field order in Blind application page3")
    public void verifybasicFieldOrder3() throws Throwable {
        Thread.sleep(4000);
        List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsBBB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsBBB']//span[contains(text(),'Segment')]"));

        List<String> fieldLabels = new ArrayList<String>();

        for (WebElement we : fields) {

            fieldLabels.add(we.getText());
        }
        Iterator<String> it = fieldLabels.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order3");

    }

    @Given("^Blind Data Capture Customer Details tab Length Validation$")
    public void basic_Data_Capture_Customer_Details_tab_Length_Validation() throws IOException, InterruptedException {

        String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
        String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
        String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
        String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
        String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
        String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
        String extenctionDetails = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
        String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
        String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
        String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
        String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
        String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
        String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
        String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
        String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
        String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
        String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
        String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");

        String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


        String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
        String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");


        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String docExpireDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String docSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
        //String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        //String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        wrap.switch_to_default_Content(BaseProject.driver);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("PegaGadget1Ifr"));
        //wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

        String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
        String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

        //utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

        String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
        String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
        String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
        String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
        String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
        String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
        String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);
        String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code2", BaseProject.scenarioID);
        String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description2", BaseProject.scenarioID);
        String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth", BaseProject.scenarioID);
        String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
        String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
        String Alias = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
        String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code", BaseProject.scenarioID);
        String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
        String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
        String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
        String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);
        String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
        String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
        String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
        String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
        String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

        String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
        String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);

        String isiccode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
        String isicDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
        WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));


        String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
        String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
        String maxInputVal1 = "4561024958";

        String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
        String maxdate = "0202199002020202020202";

        String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");

        //	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxInputVal1, accnumber);


        wrap.TextFieldMaxLengthValidation(BaseProject.driver, First_Name, FirstName);

        wrap.wait(4000);
        wrap.screenShot(BaseProject.driver, screenShotPath, "FirstName-Length");

        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Middle_Name, MiddleName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "MiddleName-Length");
        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Last_Name, LastName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "LastName-Length");
        //	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, DateOfBirth1);

        waitUntilVisibilityOfWebElement(AliasType1);
        wrap.click(BaseProject.driver, AliasType1);
        wrap.wait(1000);
        wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
        wrap.wait(2000);

        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_First_Name, AliasFirstName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName-Length");
        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName-Length");
        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_Last_Name, AliasLastName);
        wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName-Length");

        waitUntilVisibilityOfWebElement(ContactType);
        //wrap.click(BaseProject.driver, ContactType);
        //wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "code", CTD);
        wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, "MT1");
        //wrap.TypeToTextBoxAndTabOut(BaseProject.driver, CTD, ContactType);
        wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Contact_Details, ContactDetails);
        wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails-Length");
        //	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxInputVal, Extension);


        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Document_Number, documentNumber);
        wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber-Length");
        //	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, docSignatureDate);
        //	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, docExpireDate);


    }

    @Given("^Blind Data Capture ProductDetails tab Length Validation$")
    public void basic_data_capture_productDetails_tab_length_validation() throws IOException, InterruptedException {

        String productDetailsTab = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
        String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
        String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
        String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
        String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");

        String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
        String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
        String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
        wrap.click(BaseProject.driver, productDetailsTab);


        String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);

        try {
            wrap.TextFieldMaxLengthValidation(BaseProject.driver, Account_Number, AccNum);
            wrap.screenShot(BaseProject.driver, screenShotPath, "AccountNumber-Length");

        } catch (Exception e) {

        }

    }


    @Given("^Blind Data capture Application Details tab length validation$")
    public void basic_Data_capture_Application_Details_tab_length_validation() throws IOException, InterruptedException {
        String sourceId = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
        String referralId = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
        String applicationHeader = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
        String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
        String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
        String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
        waitUntilVisibilityOfWebElement(applicationHeader);
        wrap.click(BaseProject.driver, applicationHeader);


        String Sorucing_ID = DBUtils.readColumnWithRowID("Sorucing ID", BaseProject.scenarioID);
        String Referral_ID = DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID);
        String Acquisition_Channel = DBUtils.readColumnWithRowID("Acquisition Channel", BaseProject.scenarioID);
        String Fast_track_Flag = DBUtils.readColumnWithRowID("Fast track Flag", BaseProject.scenarioID);
        String Application_Branch = DBUtils.readColumnWithRowID("Application Branch", BaseProject.scenarioID);


        waitUntilVisibilityOfWebElement(sourceId);
        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Sorucing_ID, sourceId);
        wrap.screenShot(BaseProject.driver, screenShotPath, "SourcingId-Length");
        waitUntilVisibilityOfWebElement(referralId);
        wrap.TextFieldMaxLengthValidation(BaseProject.driver, Referral_ID, referralId);
        wrap.screenShot(BaseProject.driver, screenShotPath, "ReferralId-Length");
    }

    @When("^Blind: Switch to Default Content$")
    public void switch_defaultContent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        wrap.wait(3000);
        BaseProject.driver.switchTo().defaultContent();
        logger.info("Switched to Default Content");

    }


    // Scenario 71
    @When("^Blind: verify Other than Applicants in Blind Data Capture Section")
    public void verify_Other_Applicants_Basic_Data_Capture_Section()
            throws Throwable {
        String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
        String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
        String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
        String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
        String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


        //convertExcelToMap("Sheet1");
        //	//utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");

        String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
        String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

        click_on_Customer_Details_tab();
        validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_optional_and_mandatory_fields_in_Document_Details_section();
        click_on_Personal_Details_tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_section();
        click_on_Application_Details_tab();
        validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
        validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
        click_on_Customer_Details_tab();


        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

        String profileType = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");

        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("Related Party")) {
                option.click();
                break;
            }
        }

        String Relation_Type_Code = DBUtils.readColumnWithRowID("Relation Type Code", BaseProject.scenarioID);

        wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");

        wrap.wait(4000);
        wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code, "BYVISIBLETEXT");

        validate_optional_and_mandatory_fields_in_Coapplicant_Customer_Personal_Details_section();
        validate_optional_and_mandatory_fields_in_Contact_section();
        validate_optional_and_mandatory_fields_in_Employment_section();
        validate_coapp_optional_and_mandatory_fields_in_Document_Details_section();
        validate_Remarks_fields_in_Customer_Detail_section();
        validate_Submit_buttons_in_Basic_Data_section();


    }


    

    @When("^Blind: Changes product in Product Details section$")
    public void change_product_in_Product_Details_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");



		/*String Productsection=com.getElementProperties("BasicData", "Productsection");
		String ProductSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
		if(ProductSection.equals("false"))
		{
			wrap.click(BaseProject.driver, Productsection);

		}


		wrap.click(BaseProject.driver, ProductDetails);*/
        click_on_Personal_Details_tab();
        logger.info("Going to change Product Category");
        wrap.click(BaseProject.driver, ProductCategory);
        wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "PERSONAL LOAN", "BYVISIBLETEXT");
        wrap.wait(3000);
        wrap.click(BaseProject.driver, ProductCode);
        wrap.wait(2000);
        logger.info("Going to change Product Code");
        wrap.selectFromDropDown(BaseProject.driver, ProductCode, "PL001 - LORDS PERSONAL LOAN", "BYVISIBLETEXT");


    }


    @When("^Blind: validate mandatory field in banking service detail section$")
    public void blind_validate_mandatory_field_in_banking_service_detail_section() throws Throwable {
        String BlindD_BankingServiceDetail_EmbossDebName_label = com.getElementProperties("BasicData", "BD_BankingServiceDetail_EmbossDebName_label");
        String BlindD_BankingServiceDetail_header = com.getElementProperties("BasicData", "BD_BankingServiceDetail_header");
        String BlindData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID = com.getElementProperties("BasicData", "BasicData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID");

        String Embossed_Name = DBUtils.readColumnWithRowID("Embossed Debit Card Name", BaseProject.scenarioID);

        boolean BSD_header_display = false;

        BSD_header_display = wrap.getExactAttribute(BaseProject.driver, BlindD_BankingServiceDetail_EmbossDebName_label).isDisplayed();

        if (BSD_header_display) {
            wrap.waitForElement(BaseProject.driver, BlindD_BankingServiceDetail_EmbossDebName_label, 20, "visible");
            wrap.type(BaseProject.driver, Embossed_Name, BlindData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID);

        } else {
            wrap.click(BaseProject.driver, BlindD_BankingServiceDetail_header);
            wrap.waitForElement(BaseProject.driver, BlindD_BankingServiceDetail_EmbossDebName_label, 20, "visible");
            wrap.type(BaseProject.driver, Embossed_Name, BlindData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID);
        }
    }

    /////////////////////////////// Dinesh code - BLC - POA coapplicant ends here ////////////////////////////////

    /////////////////////////////// Dinesh code - UAT new scenario 16-Jun //////////////////////////////////////////////

    public void closing_the_application_withSaveChanges() throws IOException, InterruptedException {
        String close = com.getElementProperties("BasicData", "Close_button");
        wrap.click(BaseProject.driver, close);

        try {
            if (wrap.getTextValue(BaseProject.driver, com.getElementProperties("BasicData", "ConfirmClose_Modal_title")).equalsIgnoreCase("Confirm close")) {
                logger.info("Confirm close modal window is displayed");
                wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "Modal_save"));
                logger.info("Clicked on Save button and closing the application with the latest changes made by the user.");
            }
        } catch (Exception e) {
            logger.info("User not made any change in the application so closed the application without confirming second time");
        }
        logger.info("The application will close and moved in My workbasket after clicking on close button.");

    }


/////////////////////////////// Dinesh code - UAT new scenario ends here ///////////////////////////////////


    //UAT - Dinesh - July 14
// TC's - 481 - 487
    @Then("^Verify NDPMS account functionality for BlindData$")
    public void Verify_NDPMS_account_functionality_for_BlindData() throws InterruptedException, IOException {
        wrap.wait(1000);
        switchFrame();
// Write code here that turns the phrase above into concrete actions
        String cust_details = com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, cust_details)));
        wrap.click(BaseProject.driver, cust_details);

        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");

        Select procode = new Select(wrap.getElement(BaseProject.driver, ProductCode));
        String procode_option = procode.getFirstSelectedOption().getText();
        if (procode_option.equalsIgnoreCase("371 - NDPMS Linked Savings Account")) {
            logger.info("The user has selected the savings account whose product code is " + procode_option);
            logger.info("Please select other than INDIA for the Residence Country field in Customer detail section.");
            logger.info("User should feed all the mandatory field before submitting the application.");

            Actions aa = new Actions(BaseProject.driver);
            aa.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

            wrap.wait(3000);
            String Submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
            wrap.click(BaseProject.driver, Submit);

            wrap.wait(5000);

            Iterator itr = wrap.getElements(BaseProject.driver, com.getElementProperties("BlindData", "inline_Error")).iterator();

            while (itr.hasNext()) {
                WebElement err = (WebElement) itr.next();
                logger.info("inline error message : " + err.getText());
            }
        }

    }

    // TC's 488 -494
    @Then("^Verify email field functionality for blinddata$")
    public void Verify_email_field_functionality() throws InterruptedException, IOException {
        String email_field = com.getElementProperties("BlindData", "email_field");

        wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "kfjdkslfjald", email_field);
        wrap.wait(1500);
        wrap.waitForElement(BaseProject.driver, com.getElementProperties("BlindData", "email_inlineErr"), 2000, "visible");
        boolean is_inlineErr_dis = wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BlindData", "email_inlineErr"));
        if (is_inlineErr_dis) {
            String err_txt = wrap.getElement(BaseProject.driver, email_field).getText();
            String mand_char = "@.";

            boolean result = emailValidation(err_txt, mand_char);

            if (result == false) {
                logger.info("The entered text in email field has not include @ or . so the given text is invalid");
            }


        }

    }

    public boolean emailValidation(String input, String mandate) {
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            for (int j = 0; j < mandate.length(); j++) {
                if (mandate.charAt(j) == ch) {
                    return true;
                }

            }
        }
        return false;
    }

    // TC's - 495 - 504
    @Then("^Verify PIS NRE/NRO account functionality for BlindData$")
    public void Verify_PIS_NRENRO_account_functionality_for_BlindData() throws InterruptedException, IOException {
        wrap.wait(1000);
        switchFrame();
// Write code here that turns the phrase above into concrete actions
        String cust_details = com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, cust_details)));
        wrap.click(BaseProject.driver, cust_details);

        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");

        Select procode = new Select(wrap.getElement(BaseProject.driver, ProductCode));
        String procode_option = procode.getFirstSelectedOption().getText();
        if (procode_option.equalsIgnoreCase("349	- PIS NRE ACCOUNT") || procode_option.equalsIgnoreCase("349	- PIS NRO ACCOUNT")) {
            logger.info("The user has selected the savings account whose product code is " + procode_option);
            logger.info("Please select other than INDIA for the Residence Country field in Customer detail section.");
            logger.info("User should feed all the mandatory field before submitting the application.");

            Actions aa = new Actions(BaseProject.driver);
            aa.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

            wrap.wait(3000);
            String Submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
            wrap.click(BaseProject.driver, Submit);

            wrap.wait(5000);

            Iterator itr = wrap.getElements(BaseProject.driver, com.getElementProperties("BlindData", "inline_Error")).iterator();

            while (itr.hasNext()) {
                WebElement err = (WebElement) itr.next();
                logger.info("inline error message : " + err.getText());
            }
        }

    }

//Thiyanes-UAT

    @When("^Blind: click on cancel button$")
    public void click_cancel() throws IOException, InterruptedException {
        String cancel = com.getElementProperties("BasicData", "BasicData_app_details_Cancel_Button");
        wrap.click(BaseProject.driver, cancel);
        String cancelmsg = com.getElementProperties("BasicData", "BasicData_app_details_Cancel_message");
        String canceloverlay = com.getElementProperties("BasicData", "BasicData_app_details_Cancel_Overlay");
        String canceltxt = wrap.getTextValue(BaseProject.driver, cancelmsg);
        logger.info("Cancel overlay message is" + canceltxt);

        waitUntilVisibilityOfWebElement(canceloverlay);
        wrap.click(BaseProject.driver, canceloverlay);


    }

    @When("^Blind: click on delete button for primary$")
    public void click_delete() throws IOException, InterruptedException {
        String delete = BaseProject.driver.findElement(By.xpath("//a[contains(@temptitle,'Delete this tab')]")).getAttribute("disabled");
        if (delete.equalsIgnoreCase("disabled")) {
            logger.info("User is restricted to delete primary Applicant");
        }


    }

    @When("^Blind: validate contact details$")
    public void Con_Details() throws IOException, InterruptedException {
        String condet = com.getElementProperties("BasicData", "BasicData_app_details_Condetail");
        if (wrap.isElementPresent(BaseProject.driver, condet)) {
            logger.info("Contact detail element is present");
        }
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");

        waitUntilVisibilityOfWebElement(ContactType);
        wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, "MT1");

        wrap.wait(1000);
        String condettxtbx = BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).getAttribute("maxlength");
        logger.info("Max value of contact details is" + condettxtbx);
        String condettxt = BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).getAttribute("type");
        logger.info("type value of contact details is" + condettxt);
        wrap.wait(1000);
        BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).sendKeys("AAbb12345");
        logger.info("Contact detail should be numeric");
        String contdet = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Contact Details')]")).getAttribute("class");
        if (contdet.contains("Required")) {
            logger.info("Contact detail should be mandatory");
        }


        waitUntilVisibilityOfWebElement(ContactType);
        wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, "OTB");
        wrap.wait(1000);
        String condettxtbx1 = BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).getAttribute("maxlength");
        logger.info("Max value of contact details is" + condettxtbx1);
        String contdet1 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Contact Details')]")).getAttribute("class");
        if (contdet1.contains("Required")) {
            logger.info("Contact detail should be mandatory");
        }

        waitUntilVisibilityOfWebElement(ContactType);
        wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, "RE1");
        wrap.wait(1000);
        String condettxtbx2 = BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).getAttribute("maxlength");
        logger.info("Max value of contact details is" + condettxtbx2);
        String contdet2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Contact Details')]")).getAttribute("class");
        if (contdet2.contains("Required")) {
            logger.info("Contact detail should be mandatory");
        }

        String condetdata = BaseProject.driver.findElement(By.xpath("//input[@id='ContactNumber']")).getAttribute("data-ctl");
        if (condetdata.contains("TextInput")) {
            logger.info("It should be display-editable");
        }


    }

    @When("^Blind: Relation type code options$")
    public void verify_RelationtypeOptions_Blind_Data_Capture_Section()
            throws Throwable {

        click_on_Customer_Details_tab();
        String Add = com.getElementProperties("BasicData",
                "BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


        wrap.wait(500);
        WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);

        String profileType = com.getElementProperties("BasicData", "BasicData_CoApplicant_ProfileType_DropDown_ID");
        String relationTypeCode = com.getElementProperties("BasicData",
                "BasicData_CoApplicant_RelationTypeCode_DropDown_ID");
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, profileType)));
        wrap.click(BaseProject.driver, profileType);

        WebElement element = BaseProject.driver.findElement(By.id("ProfileType"));
        Select sProfileType = new Select(element);
        List<WebElement> ProfileTypes = sProfileType.getOptions();

        for (WebElement option : ProfileTypes) {
            if (option.getText().equals("Related Party")) {
                option.click();
                break;
            }
        }


        wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");
        //wrap.wait(1000);
        //BaseProject.driver.findElement(By.id("ProfileType")).sendKeys(Keys.TAB);


	/*     if (MandErrMsg.equals("ProfileType")) {
              logger.info("Values cannot be blank for Profile Type");
       }*/
        //wrap.wait(4000);

        waitUntilVisibilityOfWebElement(relationTypeCode);
        WebElement AccReq = BaseProject.driver.findElement(By.id("RelatedPartyType"));
        Select select = new Select(AccReq);
        List<WebElement> AccReqoption = select.getAllSelectedOptions();


        for (int i = 0; i < AccReqoption.size(); i++)

        {
            String txt = AccReqoption.get(i).getText();
            logger.info("Dropdown " + i + " value is " + txt);


            if (txt.equalsIgnoreCase("Power of Attorney") || txt.equalsIgnoreCase("Guardian")) {

                logger.info("Related party code has POA/Guardian");
            }

        }
    }

    //Ganga
    @Then("^Take Screenshot for Blind Data Capture Maker$")
    public void Take_Screenshot_for_Checker() throws Throwable {

        wrap.captureScreenShot(BaseProject.driver, "Blind Data Capture Maker");

    }


    @When("^Blind: select alias type in Customer Personal Details section$")
    public void select_alias_type_in_Customer_Personal_Details_section() {
        try {
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
            String Alias = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
            String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
            String AliasNames_CCMS = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_CCMS");
            String AliasNames_RLS = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_RLS");
            String AliasNames_PRE = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID_previos");
            logger.info("Going to switch into frame");

            switchFrame();
              /*BaseProject.driver.switchTo().defaultContent();
                           wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");*/
            logger.info("Frame switched successfully");
            String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();
            String Customersection = com.getElementProperties("BasicData", "Customersection");
            String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
            if (CustomerSection.equals("false")) {
                wrap.click(BaseProject.driver, Customersection);

            }
            waitUntilVisibilityOfWebElement(AliasType1);
            wrap.click(BaseProject.driver, AliasType1);
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, AliasType1, "Previous Name", "BYVISIBLETEXT");
            wrap.wait(4000);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: select contact type as Office Telephone in Customer Personal Details section$")
    public void select_contact_type_OT_in_Customer_Personal_Details_section() {

        try {
            String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");

            switchFrame();
            waitUntilVisibilityOfWebElement(ContactType);
            wrap.click(BaseProject.driver, ContactType);
            wrap.wait(1000);
            wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "OTA", ContactType);
            wrap.wait(1000);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Read Excel$")
    public void readExcel()
            throws Throwable {
        //utils.convertExcelToMap(excelPath,"Checkerorder.xls","Basic");
    }

    @Then("^Blind: Select '(.+)'$")
    public static void select_value(String selval) throws IOException, InterruptedException {

        wrap.wait(1000);
        logger.info("Going to switch into frame");
        switchFrame();
        logger.info("Frame switched successfully");
        wrap.wait(1000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"), "CLIENT ID DOCUMENTS", "BYVISIBLETEXT");
        wrap.wait(1000);
        wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), selval, "BYVISIBLETEXT");

    }

    @When("^Blind: choose campaign code as SA$")
    public static void choose_campaign_code_SA() {
        try {
            String CampaignCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_CampaignCode_SuggestionBox_ID");
            String Productsection = com.getElementProperties("BasicData", "Productsection");
            String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
            String ProductSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
            if (ProductSection.equals("false")) {
                wrap.click(BaseProject.driver, Productsection);

            }
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            //String Campaign_Code = DBUtils.readColumnWithRowID("Campaign Code", BaseProject.scenarioID);
            String Campaign_Code = "SA316";
            //String Campaign_Description = DBUtils.readColumnWithRowID("Campaign Description", BaseProject.scenarioID);
            wrap.click(BaseProject.driver, ProductDetails);
            wrap.type(BaseProject.driver, Campaign_Code, CampaignCode);
            wrap.wait(1000);
            BaseProject.driver.findElement(By.xpath("//table[@pl_prop_class='SCB-FW-AppWorkFlowFW-Data-Master-Campaigns']")).click();
            wrap.wait(1000);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: choose account request type as existing$")
    public static void choose_account_request_type() {
        String Account_Request_Type = "Existing";
        try {
            String ACsection = com.getElementProperties("BasicData", "ACsection");
            String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
            if (ACSection.equals("false")) {
                wrap.click(BaseProject.driver, ACsection);

            }
            //String AccountRequestType = "//*[@id='IsAccountType']";
            String AccountRequestType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
            wrap.click(BaseProject.driver, AccountRequestType);
            wrap.selectFromDropDown(BaseProject.driver, AccountRequestType, Account_Request_Type, "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate pan number$")
    public static void validate_pan_no() throws IOException {
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
    	String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
       // String Document_Number = "ABCPE1234F";
        String PAN_Number = Document_Number.toUpperCase();
        String PAN_Format = "[A-Z]{5}[0-9]{4}[A-Z]{1}";

        boolean validatePAN = Pattern.compile(PAN_Format).matcher(PAN_Number).matches();

        char pan_fourthchar = PAN_Number.charAt(3);

        if (PAN_Number.length() == 10) {
            logger.info("PAN Number length is 10");
            if (pan_fourthchar == 'P') {
                logger.info("Fourth character is P for PAN Number");

                if (validatePAN == true) {
                    logger.info("PAN format validation is successful");
                } else {
                    logger.info("PAN format validation failed");
                }
            } else {
                logger.info("Fourth character is invalid for PAN Number");
            }
        } else if (PAN_Number.length() > 10) {
            logger.info("PAN Number length is more than 10");
        } else if (PAN_Number.length() < 10) {
            logger.info("PAN Number length is less than 10");
        }
    }

    @When("^Blind: Enter Document Number$")
    public void enter_document_number() {
        try {
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
            String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
            WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
            JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
            jse.executeScript("arguments[0].scrollIntoView(true);", element);

            String Documentsection = com.getElementProperties("BasicData", "Documentsection");
            String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
            if (DocumentSection.equals("false")) {
                wrap.click(BaseProject.driver, Documentsection);

            }
            wrap.wait(1000);
            verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
            wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
            wrap.wait(500);
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate PAN error message$")
    public static void validat_error_message_pan() {
        try {
            String PANValidationError = com.getElementProperties("BasicData", "BasicData_PAN_ErrorMsg");
            wrap.isElementPresent(BaseProject.driver, PANValidationError);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @When("^Blind: Validate Aadhar number$")
    public static void validate_aadhar() throws IOException {
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        //String Document_Number = "098765432145";
        String Aadhar_Format = "[0-9]{12}";
        boolean validateAadhar = Pattern.compile(Aadhar_Format).matcher(Document_Number).matches();
        if (validateAadhar == true) {
            logger.info("Aadhar length validation is successful");
        } else {
            logger.info("Aadhar length validation is not successful");
            logger.info("Aadhar number exceeds more than 12 characters");
        }
    }

    @When("^Blind: Validate Special Character for Document number$")
    public static void validat_special_character_document_number() throws IOException {
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        //String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
        String Document_Number  ="0987654$";
        //String Document_Number = "0987/"+File.separator+"-()145";
        char[] Document_Number_arr = Document_Number.toCharArray();
        boolean Special_Char_available = Pattern.compile("[^A-Za-z0-9]").matcher(Document_Number).find();
        if (Special_Char_available == true) {
            logger.info("Document number value contains special characters");
            for (int i = 0; i < Document_Number_arr.length; i++) {
                if (Document_Number_arr[i] == '/') {
                    logger.info("Document number value contains allowed special characters");
                } else if (Document_Number_arr[i] == '\\') {
                    logger.info("Document number value contains allowed special characters");
                } else if (Document_Number_arr[i] == '-') {
                    logger.info("Document number value contains allowed special characters");
                } else if (Document_Number_arr[i] == '(') {
                    logger.info("Document number value contains allowed special characters");
                } else if (Document_Number_arr[i] == ')') {
                    logger.info("Document number value contains allowed special characters");
                } else {
                    logger.info("Document number value contains invalid special characters");
                }
            }
        } else {
            logger.info("Document number value does not contain any special characters");
        }
    }

    @When("^Blind: Validate document number error message$")
    public static void validate_doc_number_error_message() throws InterruptedException {
        try {
            wrap.wait(1000);
            String DocNumberValidationError = com.getElementProperties("BasicData", "BasicData_Special_Character_ErrorMsg");
            wrap.isElementPresent(BaseProject.driver, DocNumberValidationError);
            logger.info("Special character validation message is shown for document number");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate document expiry date$")
    public void validate_document_expiry_date() throws InterruptedException, IOException {
       // String IDExpiryDate1 = "id=DocumentExpiryDate";
        String IDExpiryDate1  = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate_DateText_ID");
        Calendar cal = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
        wrap.wait(1000);
        logger.info("Going to switch into frame");
        switchFrame();
        logger.info("Frame switched successfully");
        wrap.wait(1000);
        wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
        verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
        wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
        wrap.elementTabOut(BaseProject.driver, IDExpiryDate1);
        wrap.wait(1000);
        int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
        cal.add(Calendar.DATE, 30);
        String date = dateFormat.format(cal.getTime());
        date = date.replace("/", "");
        int dateNumDLV = Integer.parseInt(date);
        if (dateNumDLV <= DLVExpDate) {
String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@id='$PpyWorkPage$pCustomers$l1$pDocumentList$l1$pDocumentExpiryDateError']/span").getText();
           // String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
            logger.info(ErrorMessage);
            System.out.println(ErrorMessage);
        }
    }

    @When("^Blind: Validate Special Character for Name and enter value$")
    public static void validat_special_character_name() {
        try {
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
            String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
            String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
            String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
            String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
            String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
            char[] Document_Number_arr = First_Name.toCharArray();
            boolean Special_Char_FirstName = Pattern.compile("[^A-Za-z0-9]").matcher(First_Name).find();
            boolean Special_Char_MiddleName = Pattern.compile("[^A-Za-z0-9]").matcher(Middle_Name).find();
            boolean Special_Char_LastName = Pattern.compile("[^A-Za-z0-9]").matcher(Last_Name).find();

            if (Special_Char_FirstName == true) {
                logger.info("First Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&' || Document_Number_arr[i] == '/') {
                        logger.info("First Name value contains allowed special characters");
                        enter_first_name();
                    } else {
                        logger.info("First Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("First Name value does not contain any special characters");
                enter_first_name();
            }


            if (Special_Char_MiddleName == true) {
                logger.info("Middle Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&' || Document_Number_arr[i] == '/') {
                        logger.info("Middle Name value contains allowed special characters");
                        enter_middle_name();
                    } else {
                        logger.info("Middle Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("Middle Name value does not contain any special characters");
                enter_middle_name();
            }

            if (Special_Char_LastName == true) {
                logger.info("Last Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&' || Document_Number_arr[i] == '/') {
                        logger.info("Last Name value contains allowed special characters");
                        enter_last_name();

                    } else {
                        logger.info("Last Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("Document number value does not contain any special characters");
                enter_last_name();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Enter First Name$")
    public static void enter_first_name() throws IOException {
        try {
            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);
            String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
            String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
            waitUntilVisibilityOfWebElement(FirstName);
            wrap.type(BaseProject.driver, First_Name, FirstName);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Enter Middle Name$")
    public static void enter_middle_name() {
        try {
            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);
            String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
            String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
            waitUntilVisibilityOfWebElement(MiddleName);
            wrap.click(BaseProject.driver, MiddleName);
            wrap.type(BaseProject.driver, Middle_Name, MiddleName);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Enter Last Name$")
    public static void enter_last_name() {
        try {
            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);
            String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
            String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
            waitUntilVisibilityOfWebElement(LastName);
            verifyTextBoxThnClick(BaseProject.driver, LastName);
            wrap.type(BaseProject.driver, Last_Name, LastName);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate Special Character for Alias Name and enter value$")
    public static void validat_special_character_alias_name() throws InterruptedException {
        try {
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
            String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
            String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");
            String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
            String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
            String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
            char[] Document_Number_arr = Alias_First_Name.toCharArray();
            String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
            String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);

            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);
            waitUntilVisibilityOfWebElement(AliasType1);
            wrap.click(BaseProject.driver, AliasType1);
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, AliasType1, Alias_Type, "BYVISIBLETEXT");
            wrap.wait(2000);

            boolean Special_Char_AFirstName = Pattern.compile("[^A-Za-z0-9]").matcher(Alias_First_Name).find();
            boolean Special_Char_AMiddleName = Pattern.compile("[^A-Za-z0-9]").matcher(Alias_Middle_Name).find();
            boolean Special_Char_ALastName = Pattern.compile("[^A-Za-z0-9]").matcher(Alias_Last_Name).find();

            if (Special_Char_AFirstName == true) {
                logger.info("First Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&') {
                        logger.info("Alias First Name value contains allowed special characters");
                        enter_alias_first_name();
                    } else {
                        logger.info("Alias First Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("Alias First Name value does not contain any special characters");
                enter_alias_first_name();
            }

            if (Special_Char_AMiddleName == true) {
                logger.info("Alias Middle Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&') {
                        logger.info("Alias Middle Name value contains allowed special characters");
                        enter_alias_middle_name();
                    } else {
                        logger.info("Alias Middle Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("Alias Middle Name value does not contain any special characters");
                enter_alias_middle_name();
            }


            if (Special_Char_ALastName == true) {
                logger.info("Alias Last Name value contains special characters");
                for (int i = 0; i < Document_Number_arr.length; i++) {
                    if (Document_Number_arr[i] == '@' || Document_Number_arr[i] == '&') {
                        logger.info("Alias Last Name value contains allowed special characters");
                        enter_alias_last_name();
                    } else {
                        logger.info("Alias Last Name value contains invalid special characters");
                    }
                }
            } else {
                logger.info("Alias Last Name value does not contain any special characters");
                enter_alias_last_name();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Enter Alias First Name$")
    public static void enter_alias_first_name() throws IOException {
        try {
            String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
            String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
            waitUntilVisibilityOfWebElement(AliasFirstName);
            wrap.type(BaseProject.driver, Alias_First_Name, AliasFirstName);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @When("^Blind: Enter Alias Middle Name$")
    public static void enter_alias_middle_name() throws IOException {
        try {
            String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
            String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
            waitUntilVisibilityOfWebElement(AliasMiddleName);
            wrap.type(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @When("^Blind: Enter Alias Last Name$")
    public static void enter_alias_last_name() throws IOException {
        try {
            String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");
            String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
            waitUntilVisibilityOfWebElement(AliasLastName);
            wrap.type(BaseProject.driver, Alias_Last_Name, AliasLastName);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate DOB and enter value$")
    public static void validate_DOB() throws InterruptedException, IOException {
        try {
            //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
            String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
            String dob_list[] = DOB.split("/");
            String dob_year = dob_list[2];
            logger.info("DOB year is :" + " " + dob_year);

            String sysDate = wrap.getDateTime("date");
            String sysDate_list[] = sysDate.split("/");
            String sysdate_year = sysDate_list[2];
            logger.info("SYSDATE year is :" + " " + sysdate_year);

            int dob_year_i = Integer.parseInt(dob_year);
            int sysdate_year_i = Integer.parseInt(sysdate_year);

            int dob_year_diff = dob_year_i - sysdate_year_i;
            logger.info("Difference in year value is :" + " " + dob_year_diff);

            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);

            if (dob_year_diff > 0) {
                logger.info("DOB value is future dated");
                wrap.enterDate(BaseProject.driver, DOB, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
                wrap.wait(1000);
                wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
                String invalidDOBtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Enter a valid past date')]")).getText();
                wrap.captureScreenShot(BaseProject.driver, "DOB validation");
                if (invalidDOBtxt.contains("Enter a valid past date")) {
                    logger.info("Please enter valid DOB for past date");
                } else {
                    logger.info("Valid DOB entered");
                }
            }
            if (dob_year_diff < 0) {
                int dob_year_diff1 = Math.abs(dob_year_diff);

                if (dob_year_diff >= (150)) {
                    logger.info("DOB value is more than 150 years");
                    wrap.wait(1000);
                    wrap.enterDate(BaseProject.driver, DOB, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
                    wrap.wait(1000);
                    wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
                    wrap.wait(1000);
                    String invalidDOBtxt2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Age is more than 150 years. Please Select Valid DOB')]")).getText();
                    wrap.captureScreenShot(BaseProject.driver, "DOB validation");
                    if (invalidDOBtxt2.contains("Age is more than 150 years")) {
                        logger.info("Age is more than 150 years. Please Select Valid DOB");
                    } else {
                        logger.info("Valid DOB entered");
                    }
                } else if (dob_year_diff > (100) || dob_year_diff <= (149)) {
                    logger.info("DOB value is more than 100 years");
                    wrap.wait(1000);
                    wrap.enterDate(BaseProject.driver, DOB, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
                    wrap.wait(1000);
                    wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
                    wrap.wait(1000);
                    String invalidDOBtxt2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'age should be Less than')]")).getText();
                    wrap.captureScreenShot(BaseProject.driver, "DOB validation");
                    if (invalidDOBtxt2.contains("age should be Less than")) {
                        logger.info("Please enter valid DOB for 100yrs error message");
                    } else {
                        logger.info("Valid DOB entered");
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @When("^Blind: Validate the derivation logic for Alias fullname$")
    public static boolean validate_derivation_logic_alias_fullname() throws IOException {
        boolean returnValue = false;

        String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
        String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
        String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");
        String AliasFullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFullName");
        String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");

        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
        String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
        String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
        move_to_customer_details_section();

        try {
            wrap.wait(1000);
            wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
            wrap.wait(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        waitUntilVisibilityOfWebElement(AliasFirstName);
        try {
            wrap.type(BaseProject.driver, Alias_First_Name, AliasFirstName);
           // wrap.captureScreenShot(BaseProject.driver, "Blind Alias firstname");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        waitUntilVisibilityOfWebElement(AliasMiddleName);
        try {
            wrap.type(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
            //wrap.captureScreenShot(BaseProject.driver, "AliasMiddleName");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        waitUntilVisibilityOfWebElement(AliasLastName);
        try {
            wrap.TypeToTextBoxAndTabOut(BaseProject.driver, Alias_Last_Name, AliasLastName);
           // wrap.captureScreenShot(BaseProject.driver, "AliasLastName");
            wrap.wait(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        try {
            wrap.wait(1000);
            boolean aliasfullname_available = wrap.isElementPresent(BaseProject.driver, AliasFullName);
            if (aliasfullname_available == true) {
                String AliasFullNameActual = wrap.getTextValue(BaseProject.driver, AliasFullName);
                logger.info("AliasFullNameActual is " + AliasFullNameActual);
                String AliasFullNameExpected = Alias_First_Name + " " + Alias_Middle_Name + " " + Alias_Last_Name;
                logger.info("AliasFullNameExpected is " + AliasFullNameExpected);
                if (AliasFullNameExpected.equals(AliasFullNameActual.toUpperCase())) {
                    returnValue = true;
                } else {
                    returnValue = false;
                }
            } else {
                logger.info("Unable to retrieve value from alias full name");
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return returnValue;

    }

    public static void move_to_customer_details_section() {
        try {
            wrap.wait(1000);
            logger.info("Going to switch into frame");
            switchFrame();
            logger.info("Frame switched successfully");
            wrap.wait(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    @When("^Validate occupation field default value for minor customer$")
    public static void validate_occupation_field_for_minor() throws IOException, InterruptedException {
        String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");

        String Occupations = DBUtils.readColumnWithRowID("Occupation", BaseProject.scenarioID);
        String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);

        move_to_customer_details_section();
        enter_DOB();

        String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
        String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
        if (EmploymentSection.equals("false")) {
            wrap.click(BaseProject.driver, Employmentsection);

        }

        wrap.wait(1000);

        WebElement occupation_element = wrap.getElement(BaseProject.driver, Occupation);
        wait.until(ExpectedConditions.visibilityOf(occupation_element));
        String occupation_Actualvalue = occupation_element.getAttribute("value");
        //String occupation_Actualvalue = wrap.getTextValue(BaseProject.driver, Occupation);

        String occupation_Expectedvalue = "Minor";
        if (occupation_Expectedvalue.equals(occupation_Actualvalue)) {
            logger.info("Occupation value is defaulted to Minor");
            Assert.assertEquals(occupation_Expectedvalue, occupation_Actualvalue);
        }
    }

    public static void enter_DOB() throws IOException, InterruptedException {
        //utils.convertExcelToMap(excelPath,"BlindData_Test data_sheet.xls","Sheet1");
        String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
        logger.info("Going to enter DOB value");
        wrap.enterDate(BaseProject.driver, DOB, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
        wrap.wait(1000);
        wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
    }
    
    @When("^Blind: Data filling in Products Details Tab under Product Detail section$")
    public void Data_filling_in_Products_Details_Tab_under_Product_Detail_section() throws IOException, InterruptedException {
    	
    	// This method will fill Details under Products Details Section 
    	// This method can handle Bundle products aswell

        //String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_Field");
        String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
        String ActiveProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_ActiveDropDown_ID");
        String Productsection = com.getElementProperties("BasicData", "Productsection");
        String Product_Section = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
        String CampaignCode= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
        String ProductCategoryAppears=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
        String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
        String Term=com.getElementProperties("BasicData", "BasicData_productdetails_Term");
        String TenureType=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
        String BundleIndicatorProperty=com.getElementProperties("BasicData", "ProductsDetails_BundleIndicator");
        String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
        String BundleIndicator;
        
       
        if (Product_Section.equals("false"))
        {
            wrap.click(BaseProject.driver, Productsection);
            logger.info("Clicked on Product Details Tab");
        }

        String Campaign_Code= DBUtils.readColumnWithRowID("CampaignCode", BaseProject.scenarioID);
        String Product_Code = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);
        String TD_Term = DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID);
        String TD_Tenure = DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID);

        String ProductCategoryText;
        
        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        WebElement Campaign_code = BaseProject.driver.findElement(By.xpath(CampaignCode));
	    jse.executeScript("arguments[0].click();",Campaign_code );
  
//        wrap.click(BaseProject.driver, CampaignCode);
        com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, CampaignCode, Campaign_Code, null);
        logger.info("Entered Campaign Code SuccessFully");
       
        wrap.wait(2000);
//        ProductCategoryText=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryAppears)).getText();
        ProductCategoryText=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();

        wrap.selectFromDropDown(BaseProject.driver, ProductCode, Product_Code , "BYVISIBLETEXT");
        logger.info("Entered Campaign Code SuccessFully");
        
        wrap.wait(2000);
        
        logger.info("Product Category 1 is : "+ProductCategoryText);
        if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
        {
	        wrap.type(BaseProject.driver, TD_Term , Term);
	        wrap.wait(2000);
	        wrap.selectFromDropDown(BaseProject.driver, TenureType , TD_Tenure, "BYVISIBLETEXT");
	        logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
        }
        else
        {
        	logger.info("Successfully filled Data in Products Details Section");
        }
        
        wrap.waitForElementVisibility(BaseProject.driver,BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)));
        BundleIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)).getText();
        logger.info("Bundle Indicator is : "+BundleIndicator);
        if(!BundleIndicator.equalsIgnoreCase("NA"))
        {  	       	        	 
        	wrap.wait(2000);
//        	 wrap.waitForElementVisibility(BaseProject.driver,BaseProject.driver.findElement(wrap.getExactAttributeBY(PD_ActiveTabs)));             
             List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
        	 logger.info("Number of TABS is : "+ TabNo.size());
        	 
        	 String derivedCampCode=null;

             for (int c = 1; c < TabNo.size(); c++) 
             {
            	 wrap.wait(2000);
            	 logger.info("Inside Loop"+c);
                 String Product_CodeX = DBUtils.readColumnWithRowID("ProductCode" + c + "", BaseProject.scenarioID); 
                 jse.executeScript("arguments[0].click();", TabNo.get(c));
                 logger.info("TAB NAME. : "+TabNo.get(1).getText());
                 derivedCampCode=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
                 logger.info("Derived "+(c+1)+" Campaign Code : "+derivedCampCode);
                 wrap.selectFromDropDown(BaseProject.driver, ActiveProductCode, Product_CodeX , "BYVISIBLETEXT");
                
                 if(derivedCampCode.equalsIgnoreCase("TERM DEPOSITS"))
                 {
         	        wrap.type(BaseProject.driver, TD_Term , Term);
         	        wrap.selectFromDropDown(BaseProject.driver, TenureType, TD_Tenure , "BYVISIBLETEXT");
         	        logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
                 }
             }
             
             jse.executeScript("arguments[0].click();", TabNo.get(0));
        	
        }
        else
        { logger.info("Bundle Indicator is : NA");}
        
        logger.info("************************************DATA FILLING IN PRODUCT DETAILS SECTION - COMPLETED****************************************************");
    }
    
    public static void ClickRadioButton( WebDriver driver, String InAttribute , String Value) throws InterruptedException
    {
    	if(Value.equalsIgnoreCase("YES"))
    	{
//    		driver.findElement(wrap.getExactAttributeBY(InAttribute)).click();
    		wrap.click(driver, InAttribute);
    		logger.info("Clicking YES for Attribute: "+ InAttribute);
    	}
    	else if (Value.equalsIgnoreCase("NO"))
    	{
    		wrap.click(driver, InAttribute);
//    		driver.findElement(wrap.getExactAttributeBY(InAttribute)).click();
    		logger.info("Clicking NO for Attribute: "+ InAttribute);
    		
    	}
    	else
    	{
    		logger.info("USER HAD NOT PROVIDED PROPER DATA");
    		
    	}
    	
    }

    @When("^Blind: Data filling in Products Details Tab under A/C Setup section for single Product$")
    public void validate_optional_and_mandatory_fields_in_AC_Setup_section_for_singleProduct() throws Throwable {
    	
    	logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");
    	
    	String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
    	String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
        String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
        String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
        String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
    	String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
    	String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
        String ACsection = com.getElementProperties("BasicData", "ACsection");
        String products = com.getElementProperties("BasicData", "differentproductselections");
        String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
        String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
        String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";
     
    	String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
        String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
        String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
//        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
        String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
        String AcNo_PL = DBUtils.readColumnWithRowID("AccountNumber_PL", BaseProject.scenarioID);
        String RefAccountNumber = DBUtils.readColumnWithRowID("RefAccountNumber", BaseProject.scenarioID);
        String RefAccountCurrency = DBUtils.readColumnWithRowID("RefAccountCurrency", BaseProject.scenarioID);
        
        logger.info("Purpose_of_account_opening :" + Purpose_of_account_opening);
        logger.info("Account_Request_Type :" + Account_Request_Type);
        logger.info("Service_Type :" + Service_Type);
        logger.info("Account_Number :" + Account_Number);
        logger.info("Account_Currency_Code :" + Account_Currency_Code);
        logger.info("AcNo_PL :" + AcNo_PL);
        logger.info("RefAccountNumber :" + RefAccountNumber);
        logger.info("RefAccountCurrency :" + RefAccountCurrency);
        
      	 JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
   		 String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
   		 logger.info("Product is " + ProductCategory);

   		 switch (ProductCategory) 
   		 {
   			case "CREDIT CARD":	 
   				
   				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");		
   				if (Account_Request_Type.equalsIgnoreCase("New")) 
   					{	
   						logger.info("Account Request Type = NEW");
   						wrap.wait(2000);
   						wrap.click(BaseProject.driver, AccNum);
   			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   			    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   					}	
   				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
   						
   						logger.info("Account Request Type = INSTA");
   						wrap.wait(2000);
   						wrap.click(BaseProject.driver, AccNum);
   			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   			    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   					}
   				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
   					
   						logger.info("Account Request Type = Existing");
   						wrap.wait(2000);
   						wrap.click(BaseProject.driver, AccNum);
   			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   			    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   					}

   				break;
   			case "CURRENT ACCOUNT":
   				logger.info("Moved to CURRENT ACCOUNT");
   				wrap.wait(1000);
   				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
   				
   				wrap.wait(1000);
   				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
   				
   				if (Account_Request_Type.equalsIgnoreCase("New")) 
   				{						
   					logger.info("Account Request Type = NEW");
   					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
   					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
   					wrap.wait(1000);
   				}	
   				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
   					logger.info("Account Request Type = INSTA");						
   					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
   					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
   					wrap.wait(2000);
   					wrap.click(BaseProject.driver, AccNum);
   		            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   		    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   				}
   				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
   					logger.info("Account Request Type = EXISTING");
   					wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
   					
   					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
   					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
   					wrap.wait(2000);
   					wrap.click(BaseProject.driver, AccNum);
   		            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   		    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   				}	
   				break;
   				
   			case "SAVINGS ACCOUNT":
   				logger.info("Moved to SA");
   				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
   				wrap.wait(1500);
   				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

   				if (Account_Request_Type.equalsIgnoreCase("New")) 
   				{						
   					logger.info("Account Request Type = NEW");
   					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
   				}	
   				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
   					logger.info("Account Request Type = INSTA");						
   					wrap.wait(2000);
   					wrap.click(BaseProject.driver, AccNum);
   		            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   		    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   				}
   				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
   					wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
   					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);	                    
   					wrap.wait(2000);
   					wrap.click(BaseProject.driver, AccNum);
   		            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
   		    	    jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
   					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);

   				}

   				break;

   			case "TERM DEPOSITS":
   				logger.info("Moved to TD");
   				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
   				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
   				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
   				wrap.wait(1000);

   				break;
   			case "PERSONAL LOAN":
   				logger.info("Moved to PERSONAL LOAN");
   				wrap.wait(1000);
   				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

   				wrap.wait(1000);
   				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
   				
   				if (Account_Request_Type.equalsIgnoreCase("New")) 
   				{						
   					logger.info("Account Request Type = NEW");
   				}	
   				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
   					logger.info("Account Request Type = INSTA");
   					wrap.click(BaseProject.driver, AccNum);
   					wrap.type(BaseProject.driver, AcNo_PL, AccNum);
   				}
   				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
   					logger.info("Account Request Type = EXISTING");
   					wrap.click(BaseProject.driver, AccNum);
   					wrap.type(BaseProject.driver, AcNo_PL, AccNum);

   				}
   				break;	
   			case "MORTGAGE LOAN":
   				break;
   			case "PROMOTIONAL PACKAGES":
   				break;

   			default:

   				try {
   					if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
   						wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
   						wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
   						//Pur++;

   					}
   				} catch (Exception e) {
   					System.out.println(e);
   				}

   				try {
   					if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
   					{

   						wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
   						wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

   					}
   				} catch (Exception e) {
   					System.out.println(e);
   				}

   				try {
   					if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
   						if (Account_Request_Type.equalsIgnoreCase("Existing")) {
   							wrap.wait(1500);
   							wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
   							wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
   						}
   					}
   				} catch (Exception e) {
   					System.out.println(e);
   				}


   				try {
   					if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
   						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
   						wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

   					}
   				} catch (Exception e) {
   					System.out.println(e);
   				}
   				break;
   			  

           }
             wrap.wait(1500);
    
	   	logger.info("***********************DATA FILLING IN ACCOUNT SETTUP SECTION - COMPLETED*********************************");
    }

    @When("^Blind: Data filling in Products Details Tab under A/C Setup section for AllProducts$")
    public void validate_optional_and_mandatory_fields_in_AC_Setup_section_for_AllProducts() throws Throwable {
    	
    	logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");
    	
    	String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
    	String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
        String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
        String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
        String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
    	String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
    	String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
        String ACsection = com.getElementProperties("BasicData", "ACsection");
        String products = com.getElementProperties("BasicData", "differentproductselections");
        String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
        String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
        String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";      
      
    	String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
        String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
        String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
        String Account_Number = DBUtils.readColumnWithRowID("Account_Number", BaseProject.scenarioID);
//        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
        String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
        String AcNo_PL = DBUtils.readColumnWithRowID("AccountNumber_PL", BaseProject.scenarioID);
        String RefAccountNumber = DBUtils.readColumnWithRowID("RefAccountNumber", BaseProject.scenarioID);
        String RefAccountCurrency = DBUtils.readColumnWithRowID("RefAccountCurrency", BaseProject.scenarioID);
         
        wrap.wait(1000);		 
    	List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
    	
    	JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
    	myExecutor.executeScript("arguments[0].click();", TabNo.get(0));
   	 	logger.info("Number of TABS is : "+ TabNo.size());
   	 	
   	 	
	   	 for (int c = 0; c < TabNo.size(); c++) 
	     {
	   		 wrap.wait(3000);	
	    	 logger.info("Inside Loop"+(c+1));
	    	 myExecutor.executeScript("arguments[0].click();", TabNo.get(c));
	    	 myExecutor.executeScript("scroll(0, 250);");
             logger.info("TAB NAME : "+TabNo.get(1).getText());
             
             String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
             logger.info("Product is" + ProductCategory);

             switch (ProductCategory) 
             {
	            case "CREDIT CARD":	 
	            	wrap.wait(1000);
	                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");	
	                wrap.wait(2000);
					if (Account_Request_Type.equalsIgnoreCase("New")) 
						{						
							logger.info("Account Request Type = NEW");
						}	
					else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
							logger.info("Account Request Type = INSTA");
							wrap.wait(2000);
							wrap.click(BaseProject.driver, AccNum);
				            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
							wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
						}
					else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
							wrap.wait(2000);
							wrap.click(BaseProject.driver, AccNum);
				            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
							wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
						}
	
	                break;
	            case "CURRENT ACCOUNT":
	                logger.info("Moved to CURRENT ACCOUNT");
	                wrap.wait(1000);
	                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
	                wrap.wait(2000);
	                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					
					if (Account_Request_Type.equalsIgnoreCase("New")) 
					{						
						logger.info("Account Request Type = NEW");
	                    wrap.wait(1500);
	                    //com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
	                    wrap.wait(1000);
	                }	
	                else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
						logger.info("Account Request Type = INSTA");						
	                    wrap.wait(1500);
	                    //com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
	                    wrap.wait(2000);
						wrap.click(BaseProject.driver, AccNum);
			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
			            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                }
					else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						logger.info("Account Request Type = EXISTING");
	                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
	                    wrap.wait(1500);
	                    //com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                    wrap.click(BaseProject.driver, AccCurrency);
	                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
	                    wrap.wait(2000);
						wrap.click(BaseProject.driver, AccNum);
			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
			            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                }	
	                break;
	                
	            case "SAVINGS ACCOUNT":
	                logger.info("Moved to SA");
	                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
	                wrap.wait(1500);
	                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
	
					if (Account_Request_Type.equalsIgnoreCase("New")) 
					{						
						logger.info("Account Request Type = NEW");
	                    wrap.wait(1500);
//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                    wrap.click(BaseProject.driver, AccCurrency);
	                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
	                }	
	                else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
						logger.info("Account Request Type = INSTA");						
	                    wrap.wait(1500);
//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
	                    wrap.wait(2000);
						wrap.click(BaseProject.driver, AccNum);
			            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
			            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                }
					else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
		                    wrap.wait(1000);
		                    wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
		                    wrap.wait(1500);
	//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
		                    wrap.wait(2000);
							wrap.click(BaseProject.driver, AccNum);
				            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
							wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);

	                }
	
	                break;
	
	            case "TERM DEPOSITS":
	                logger.info("Moved to TD");
	                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
//                    com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
                    // wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
                    wrap.wait(1000);
	
	                break;
				case "PERSONAL LOAN":
	                logger.info("Moved to PERSONAL LOAN");
	                wrap.wait(1000);
	                wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
	
	                wrap.wait(1000);
	                wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					
					if (Account_Request_Type.equalsIgnoreCase("New")) 
					{						
						logger.info("Account Request Type = NEW");
	                }	
	                else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
						logger.info("Account Request Type = INSTA");
						wrap.click(BaseProject.driver, AccNum);
	                    wrap.type(BaseProject.driver, AcNo_PL, AccNum);
	                }
					else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						logger.info("Account Request Type = EXISTING");
						wrap.click(BaseProject.driver, AccNum);
	                    wrap.type(BaseProject.driver, AcNo_PL, AccNum);

	                }
	                break;	
	            case "MORTGAGE LOAN":
	                break;
	            case "PROMOTIONAL PACKAGES":
	                break;
	
	            default:
	
	                try {
	                    if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
	                        wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
	                        wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
	                        //Pur++;
	
	                    }
	                } catch (Exception e) {
	                    System.out.println(e);
	                }
	
	                try {
	                    if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
	                    {
	
	                        wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
	                        wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");
	
	                    }
	                } catch (Exception e) {
	                    System.out.println(e);
	                }
	
	                try {
	                    if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
	                        if (Account_Request_Type.equalsIgnoreCase("Existing")) {
	                            wrap.wait(1500);
	                            wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
	                            wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
	                        }
	                    }
	                } catch (Exception e) {
	                    System.out.println(e);
	                }
	
	
	                try {
	                    if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
	                    	wrap.wait(2000);
							wrap.click(BaseProject.driver, AccNum);
				            WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				            myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
							wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                        wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
	
	                    }
	                } catch (Exception e) {
	                    System.out.println(e);
	                }
	                break;
	              

        }
             wrap.wait(1500);
    }
	   	myExecutor.executeScript("arguments[0].click();", TabNo.get(0));
	   	logger.info("***********************DATA FILLING IN ACCOUNT SETTUP SECTION - COMPLETED*********************************");
    } 


    @Then("^Blind: Data Filling in Product and Customer Relation$")
    public static void DataFilling_the_product_Customer_Relation() throws IOException, InterruptedException {

     logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");

  
     String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
     String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
     String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
     String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
     String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
     String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
     String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
     String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
     String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
     String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
     String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
     String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");
     String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
     String ProductDetails_header=com.getElementProperties("BasicData", "ProductDetails_header");
     
     String FirstName_CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID);
     String MiddleName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID);
     String LastName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID);

     String FirstName_CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID);
     String MiddleName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID);
     String LastName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID);   
  
     String Customername_Primary = DBUtils.readColumnWithRowID("Customer Name", BaseProject.scenarioID);    
     String Relationshiptypecode_Primary = DBUtils.readColumnWithRowID("Relationship type", BaseProject.scenarioID);
     
     String Customername_CoApp_One = (DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID)).toUpperCase(); 
     String Relationshiptypecode__CoApp_One = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant1", BaseProject.scenarioID);
  
     String Customername__CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID)).toUpperCase();
     String Relationshiptypecode_CoApp_Two = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant2", BaseProject.scenarioID);     
 	 
     logger.info("Customername_CoApp_One :"+Customername_CoApp_One);
     logger.info("Relationshiptypecode__CoApp_One :"+Relationshiptypecode__CoApp_One);
     logger.info("Customername__CoApp_Two :"+Customername__CoApp_Two);
     logger.info("Relationshiptypecode_CoApp_Two :"+Relationshiptypecode_CoApp_Two);
     
     String ProductCategoryText=null;
     
 	 JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
 	 List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
// 	 WebElement addrow = BaseProject.driver.findElement(By.xpath(ProdAndCustomer_AddRow));
 	 jse.executeScript("arguments[0].click();", TabNo.get(0));
	 logger.info("Number of TABS is : "+ TabNo.size());
	 		 	
   	 for (int c = 0; c < TabNo.size(); c++) 
     {	
    	 logger.info("Inside Loop"+(c+1));
    	 jse.executeScript("arguments[0].click();", TabNo.get(c));
    	 
    	 ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
    	 logger.info("ProductCategoryText : "+ ProductCategoryText);
    	 
    	 WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading));
         jse.executeScript("arguments[0].scrollIntoView(true);", heading);
         
         boolean isCustomerPresent = BaseProject.driver.findElement(By.xpath(AvailableCustomer)).isDisplayed();
         if(isCustomerPresent)
         {
        	 logger.info("Customer Relationship details Available");
        	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
        	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
        	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
        	 
        	 logger.info(Customername_CoApp_One!=null && Customername_CoApp_One.contains("null"));
        	 if(Customername_CoApp_One!=null && Customername_CoApp_One.contains("null"))
            	 {
            		 logger.info("Adding Customer Relationship details - CO APPLICANT ONE");
            	     logger.info("Customername_CoApp_One : "+ Customername_CoApp_One);
            	     wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
            		 wrap.wait(2000);
            	     wrap.selectFromDropDown(BaseProject.driver, CoApplicant_One_CustomerProperty, Customername_CoApp_One,  "BYVISIBLETEXT");
            	     wrap.selectFromDropDown(BaseProject.driver, Relationship_One_Property, Relationshiptypecode__CoApp_One,  "BYVISIBLETEXT");
            	     
            	     logger.info(Customername__CoApp_Two!=null && Customername__CoApp_Two.contains("null"));
            	     if(Customername__CoApp_Two!=null && Customername__CoApp_Two.contains("null") )
                	 {
            	    	 if(!ProductCategoryText.equalsIgnoreCase("PERSONAL LOAN"))
            	    	 {
            	    	 logger.info("Adding Customer Relationship details - CO APPLICANT TWO");
            	         logger.info("Customername__CoApp_Two : "+ Customername__CoApp_Two);
                		 wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
                		 wrap.wait(2000);
//            	    	 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(CoApplicant_Two_CustomerProperty)));
                	     wrap.selectFromDropDown(BaseProject.driver, CoApplicant_Two_CustomerProperty, Customername__CoApp_Two,  "BYVISIBLETEXT");
                	     wrap.selectFromDropDown(BaseProject.driver, Relationship_Two_Property, Relationshiptypecode_CoApp_Two,  "BYVISIBLETEXT");
            	    	 }else{logger.info(" Cannot add more relationship Type for PERSONAL LOAN ");}
                	                	    	 
                	 }
            	     else
                	 {
                		 logger.info("COAPPLICANT TWO DETAILS NOT PROVIDED");
                	 }		 
            	 }
            	 else
            	 {
            		 logger.info("COAPPLICANT ONE DETAILS NOT PROVIDED");
            	 }	 
         }
         else
         {
        	 logger.info("Customer Relationship details Available");
        	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
        	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
        	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
         }	 
     }
   	 
	 WebElement heading_PD = BaseProject.driver.findElement(By.xpath(ProductDetails_header));
     jse.executeScript("arguments[0].scrollIntoView(true);", heading_PD);
     logger.info("************************************Product and Customer Relation- ENDS*****************************************************");

    }

    @When("^Blind: Add Product and details '(.*)'$")
    public void add_product_details(String j)throws Throwable 
    {
    	logger.info("**************************************Adding Multiple Product - Starts****************************************************");

    	//**************************************Product Details Section - Starts****************************************************
    	
    	System.out.println("No. Given is: "+j);
    	int i = Integer.parseInt(j);
        int k = i + 1;

        String AssTab=com.getElementProperties("BasicData", "AddTab");
        String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
        String ProductDetails = com.getElementProperties("BasicData", "Productsection");
        String CampaignCode= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
        String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_Field");        
        String DepositType = com.getElementProperties("BasicData", "ProductCode_or_DepositType_DropDown_Xpath");        
        String ActiveProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_ActiveDropDown_ID");        
        String ProductCategoryTextAppears=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
        String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
        String Term=com.getElementProperties("BasicData", "BasicData_productdetails_Term");
        String TenureType=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
        String BundleIndicatorProperty=com.getElementProperties("BasicData", "ProductsDetails_BundleIndicator");
//        String Acquisition_indicator_Text=com.getElementProperties("BasicData", "Acquisition_indicator_Text");
        
        
        String campcd_new = DBUtils.readColumnWithRowID("Campaigncode" + i + "", BaseProject.scenarioID);
        String ProductCode_or_DepositType_new = DBUtils.readColumnWithRowID("ProductCode" + i + "", BaseProject.scenarioID);
        String campcd_old=DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
        String TD_Term= DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID);
        String TD_Tenure=DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID);
        String ProductCategoryText=null;
        String BundleIndicator;
        String AcquisitionIndicator;
        
        
        logger.info("campcd_new :"+campcd_new);
        logger.info("ProductCode_or_DepositType_new :"+ProductCode_or_DepositType_new);
        logger.info("campcd_old :"+campcd_old);
        logger.info("TD_Term :"+TD_Term);
        logger.info("TD_Tenure :"+TD_Tenure);
       

        JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
        
        
        if(!campcd_new.equalsIgnoreCase(campcd_old))
        {
        	logger.info("campcd_new != campcd_old");
        	
            WebElement Add_Tab = BaseProject.driver.findElement(By.xpath(AssTab));
    	    jse.executeScript("arguments[0].scrollIntoView(true);",Add_Tab );

            wrap.click(BaseProject.driver, AssTab);  	    
            logger.info("Clicked on Add Tab");
            
            wrap.wait(2000);
            List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
            logger.info("Number of TABS is : "+ TabNo.size());
            jse.executeScript("arguments[0].click();", TabNo.get(i));
            
            if(k>TabNo.size())
            {
                wrap.click(BaseProject.driver, AssTab);  	    
                logger.info("Clicked on Add Tab");               
                wrap.wait(2000);
                
                List<WebElement> TabNo_Validate = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
                if(k==TabNo_Validate.size()){logger.info("Number of TABS is : "+ TabNo_Validate.size());jse.executeScript("arguments[0].click();", TabNo.get(i));}
                else{logger.info("No of Tabs is not equal to the given input");}}
            else if(k==TabNo.size()){logger.info("No of Tabs is equal to the given input");}
            
            com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, CampaignCode, campcd_new, null);
            logger.info("Entered Campaign Code SuccessFully");
           
            wrap.wait(2000);
            new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ProductCategoryActive)));
            ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
            logger.info("Product Category is : "+ProductCategoryText);
            
            if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
            {
                wrap.selectFromDropDown(BaseProject.driver, DepositType, ProductCode_or_DepositType_new , "BYVISIBLETEXT");
                logger.info("Selected Deposit Type SuccessFully");
                
//                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(BundleIndicatorProperty)));                
//                BundleIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)).getText();
//                logger.info("Bundle Indicator is : "+BundleIndicator);
                
//                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(Acquisition_indicator_Text)));                
//                AcquisitionIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(Acquisition_indicator_Text)).getText();
//                logger.info("Bundle Indicator is : "+AcquisitionIndicator);
                
    	        wrap.type(BaseProject.driver, TD_Term , Term);
    	        wrap.selectFromDropDown(BaseProject.driver, TenureType , TD_Tenure, "BYVISIBLETEXT");
    	        logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
            }
            else
            {
                wrap.selectFromDropDown(BaseProject.driver, DepositType, ProductCode_or_DepositType_new , "BYVISIBLETEXT");
                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(wrap.getExactAttributeBY(BundleIndicatorProperty)));  
                
                logger.info("Selected Deposit Type SuccessFully");

            }}
        else
        {
            logger.info("**** ERROR: CAMPAIGN CODE FOR NEW PRODUCT IS SAME AS OLD ONE*****");
        	
        }
        //**************************************Product Details Section - Ends****************************************************   
        //**************************************Account Setup Section - Starts****************************************************
    	logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");
    	
    	String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
        String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
        String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
        String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
    	String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
        String ACsection = com.getElementProperties("BasicData", "ACsection");
        String products = com.getElementProperties("BasicData", "differentproductselections");
        String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
        String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");

    	String Purpose_of_account_opening_new = DBUtils.readColumnWithRowID("Purpose of account opening" + i + "", BaseProject.scenarioID);
        String Account_Request_Type_new = DBUtils.readColumnWithRowID("Account Request Type" + i + "", BaseProject.scenarioID);
        String Service_Type_new = DBUtils.readColumnWithRowID("Service Type" + i + "", BaseProject.scenarioID);
        String Account_Number_new = DBUtils.readColumnWithRowID("Account_Number" + i + "", BaseProject.scenarioID);
        String Account_Currency_Code_new = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
        String AcNo_PL_new=DBUtils.readColumnWithRowID("AccountNumber_PL" + i + "", BaseProject.scenarioID);
        
        logger.info("Purpose_of_account_opening_new : "+Purpose_of_account_opening_new);
        logger.info("Account_Request_Type_new : "+Account_Request_Type_new);
        logger.info("Service_Type_new : "+Service_Type_new);
        logger.info("Account_Number_new : "+Account_Number_new);
        logger.info("Account_Currency_Code_new : "+Account_Currency_Code_new);
        logger.info("AcNo_PL_new : "+AcNo_PL_new);      
        
        WebElement AC_section = BaseProject.driver.findElement(By.xpath(ACsection));
	    jse.executeScript("arguments[0].scrollIntoView(true);",AC_section );
           
        switch (ProductCategoryText) 
	     {
	        case "CREDIT CARD":	 
	        	logger.info("ProductCategoryText = CREDIT CARD");
	        	
	            wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");	
	            wrap.wait(2000);
				if (Account_Request_Type_new.equalsIgnoreCase("New")) 
					{						
						logger.info("Account Request Type = NEW");
					}	
				else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
						logger.info("Account Request Type = INSTA");
						wrap.wait(2000);
						WebElement Acc_Num_cc = BaseProject.driver.findElement(By.xpath(AccNum));
					    jse.executeScript("arguments[0].scrollIntoView(true);",Acc_Num_cc );
	                    wrap.click(BaseProject.driver, AccNum);
						wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
					}
				else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
						wrap.wait(1000);
						WebElement Acc_Num_cc = BaseProject.driver.findElement(By.xpath(AccNum));
						jse.executeScript("arguments[0].scrollIntoView(true);",Acc_Num_cc );
	                    wrap.click(BaseProject.driver, AccNum);
						wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
					}
	
	            break;
	        case "CURRENT ACCOUNT":
	        	logger.info("ProductCategoryText = CURRENT ACCOUNT");
	            wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
	            wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
	            wrap.wait(2000);
				
				if (Account_Request_Type_new.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
	                //com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                //wrap.type(BaseProject.driver, Account_Currency_Code_new, AccCurrency);	 
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);
	            }	
	            else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");						
	                //com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
	                //wrap.type(BaseProject.driver, Account_Currency_Code_new, AccCurrency);
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);
	                wrap.click(BaseProject.driver, AccNum);
	                wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
	            }
				else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
					logger.info("Account Request Type = EXISTING");
	                wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
	                //wrap.click(BaseProject.driver, AccCurrency);
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                    
	                wrap.click(BaseProject.driver, AccNum);
	                wrap.type(BaseProject.driver, Account_Number_new, AccNum);
	            }	
	            break;
	            
	        case "SAVINGS ACCOUNT":
	            logger.info("Moved to SA");
	            wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
	            wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
	            wrap.wait(2000);
	
				if (Account_Request_Type_new.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
	                wrap.click(BaseProject.driver, AccCurrency);
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                     
	            }	
	            else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");						
	                wrap.click(BaseProject.driver, AccCurrency);
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                   
	                wrap.type(BaseProject.driver, Account_Number_new, AccNum);
	            }
				else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
					logger.info("Account Request Type = EXISTING");
	                wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
	                //wrap.click(BaseProject.driver, AccCurrency);
	                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                  
	                wrap.click(BaseProject.driver, AccNum);
	                wrap.type(BaseProject.driver, Account_Number_new, AccNum);
	
	            }
				wrap.wait(2000);
	
	            break;
	
	        case "TERM DEPOSITS":
	            logger.info("Moved to TD");
	            wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
                wrap.click(BaseProject.driver, AccCurrency);
                //com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                  
	            wrap.wait(1000);
	
	            break;
			case "PERSONAL LOAN":
	            logger.info("Moved to PERSONAL LOAN");
	            wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");	
	            wrap.wait(2000);
	            wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
	            wrap.wait(2000);				
				if (Account_Request_Type_new.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
	            }	
	            else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");
					wrap.click(BaseProject.driver, AccNum);
	                wrap.type(BaseProject.driver, AcNo_PL_new, AccNum);
	            }
				else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
					logger.info("Account Request Type = EXISTING");
					wrap.click(BaseProject.driver, AccNum);
	                wrap.type(BaseProject.driver, AcNo_PL_new, AccNum);
	
	            }
	            break;	
	        case "MORTGAGE LOAN":
	            break;
	        case "PROMOTIONAL PACKAGES":
	            break;
	
	        default:
	        	logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@Unable to find PRODUCT CATEGORY@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
	
	            try {
	                if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
	                    wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
	                    wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
	                    //Pur++;
	
	                }
	            } catch (Exception e) {
	                System.out.println(e);
	            }
	
	            try {
	                if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
	                {
	
	                    wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
	                    wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");
	
	                }
	            } catch (Exception e) {
	                System.out.println(e);
	            }
	
	            try {
	                if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
	                    if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
	                        wrap.wait(1500);
	                        wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
	                        wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
	                    }
	                }
	            } catch (Exception e) {
	                System.out.println(e);
	            }
	
	
	            try {
	                if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
	                    wrap.type(BaseProject.driver, Account_Number_new, AccNum);
	                    wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
	
	                }
	            } catch (Exception e) {
	                System.out.println(e);
	            }
	            break;
	     		}
     
     	//**************************************Account Setup Section - ENDS****************************************************
     	//**************************************Term Deposit Section - ENDS****************************************************
		 	logger.info("***************************** DEPOSIT INFO SECTION STARTS- TD**************************************");


			
		   	 if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
         {
		   		 
		 	 String Productsection = com.getElementProperties("BasicData", "Productsection");
		 	 String DepositAmount = com.getElementProperties("BasicData", "DepositInfo_DepositAmount");
		     String ValueDate = com.getElementProperties("BasicData", "DepositInfo_ValueDate");
		     String FundAccountChoice = com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice");
		     String ChequeNumber = com.getElementProperties("BasicData", "DepositInfo_ChequeNumber");
		     String ChequeDate = com.getElementProperties("BasicData", "DepositInfo_ChequeDate");
		     String ChequeDrawnOn= com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn");
		     String ChequeSuspenseAmount=com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount");
		     String Amount=com.getElementProperties("BasicData", "DepositInfo_Amount");
		     String RollOverChoiceYes=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes");
		     String RollOverChoiceNo=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No");
		     String RollInstruction=com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction");
		     String InterestFrequency = com.getElementProperties("BasicData", "DepositInfo_InterestFrequency");
		     String TwoInOneYes= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_Yes");
		     String TwoInOneNo= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_No");
		     String MaturityDate=com.getElementProperties("BasicData", "DepositInfo__MaturityDate");
		     String LienY=com.getElementProperties("BasicData", "DepositInfo_LienY");
		     String LienN=com.getElementProperties("BasicData", "DepositInfo_LienN");
		     String LienAmount=com.getElementProperties("BasicData", "DepositInfo_LienAmount");
		     String LienExpiryDate=com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate");
		     String LienNarration=com.getElementProperties("BasicData", "DepositInfo_LienNarration");
		     //String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
		     String NoOFDeposit=com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit");
		     String TypeOfTwoInOne=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne");
		     String TypeOfTwoInOneAccountNumber=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber");
		     String TypeOfTwoInOneAccountCurrency=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency");
		     String FundAccountNo = com.getElementProperties("BasicData", "DepositInfo_FundAccountNumber");
		     String PaymentMode = com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode");
		     String InterestAccountNumber = com.getElementProperties("BasicData", "BD_TD_TD_InterestAccountNo");
		     String DepositInfo_heading=com.getElementProperties("BasicData", "DepositInfo_header");
		     
		     ////////////////////// DB

		     String Deposit_Amount = DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID);
		     String Value_Date = DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID);
		     String FundAccount_Choice = DBUtils.readColumnWithRowID("TD_FundAccountChoice", BaseProject.scenarioID);
		     String FundAccount_No = DBUtils.readColumnWithRowID("FundAccount_No", BaseProject.scenarioID);
		     String Cheque_Number = DBUtils.readColumnWithRowID("Cheque_Number", BaseProject.scenarioID);
		     String Cheque_Date = DBUtils.readColumnWithRowID("Cheque_Date", BaseProject.scenarioID);
		     String ChequeDrawn_On= DBUtils.readColumnWithRowID("ChequeDrawn_On", BaseProject.scenarioID);
		     String ChequeSuspense_Account=DBUtils.readColumnWithRowID("ChequeSuspense_Account", BaseProject.scenarioID);
		     String Amount_DI=DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID);
		     String RollOverChoice= DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
		     String InterestAccount_Number=DBUtils.readColumnWithRowID("InterestAccountNo", BaseProject.scenarioID);
		     String Interest_Frequency = DBUtils.readColumnWithRowID("TD_InterestFrequency", BaseProject.scenarioID);
//		     String TwoInOne_No= DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID);
		     String Maturity_Date=DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID);
		     String Lien=DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID);
		     String Lien_Amount=DBUtils.readColumnWithRowID("Lien_Amount", BaseProject.scenarioID);
		     String LienExpiry_Date=DBUtils.readColumnWithRowID("LienExpiry_Date", BaseProject.scenarioID);
//			 String Lien_Narration=DBUtils.readColumnWithRowID("Lien_Narration", BaseProject.scenarioID);
//			 String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
		     String No_of_Deposit=DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID);
		     String RollOver_Choice=DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
		     String RollOverInstruction=DBUtils.readColumnWithRowID("RollOverInstruction", BaseProject.scenarioID);
		     String TwoInOne= DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID);
		     String TypeOf2in1=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne", BaseProject.scenarioID);
		     String TypeOfTwoInOne_AccountNumber=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountNumber", BaseProject.scenarioID);
		     String TypeOfTwoInOne_AccountCurrency=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountCurrency", BaseProject.scenarioID);


		     logger.info("Deposit_Amount: "+Deposit_Amount);
		     logger.info("Value_Date: "+Value_Date);
		     logger.info("FundAccount_Choice: "+FundAccount_Choice);
		     logger.info("FundAccount_No: "+FundAccount_No);
		     logger.info("Cheque_Number: "+Cheque_Number);
		     logger.info("Cheque_Date: "+Cheque_Date);
		     logger.info("ChequeDrawn_On: "+ChequeDrawn_On);
		     logger.info("ChequeSuspense_Account: "+ChequeSuspense_Account);
		     logger.info("Amount_DI: "+Amount_DI);
		     logger.info("RollOverChoice: "+RollOverChoice);
		     logger.info("InterestAccount_Number: "+InterestAccount_Number);
		     logger.info("Interest_Frequency: "+Interest_Frequency);
		     logger.info("Lien: "+Lien);
		     logger.info("Lien_Amount: "+Lien_Amount);
		     logger.info("LienExpiry_Date: "+LienExpiry_Date);
		     logger.info("No_of_Deposit: "+No_of_Deposit);
		     logger.info("RollOver_Choice: "+RollOver_Choice);
		     logger.info("RollOverInstruction: "+RollOverInstruction);
		     logger.info("TwoInOne: "+TwoInOne);
		     logger.info("TypeOf2in1: "+TypeOf2in1);
		     logger.info("TypeOfTwoInOne_AccountNumber: "+TypeOfTwoInOne_AccountNumber);
		     logger.info("TypeOfTwoInOne_AccountCurrency: "+TypeOfTwoInOne_AccountCurrency);     
		   	 
		     
		     jse.executeScript("scroll(0, 250);");	 	   		 
		   		 
		   		 
		   	 WebElement DepositInfo_hdng = BaseProject.driver.findElement(By.xpath(DepositInfo_heading));
		     jse.executeScript("arguments[0].scrollIntoView(true);",DepositInfo_hdng );		                 
			 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DepositAmount)));
			 
			 wrap.type(BaseProject.driver, Deposit_Amount, DepositAmount);
			 logger.info("Entered Deposit Amount SuccessFully");
			 
			 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ValueDate)));
			 
			 wrap.wait(2000);
			 wrap.enterDate(BaseProject.driver, Value_Date ,ValueDate);
			 logger.info("Entered Value Date SuccessFully");

			 /////////////--- CHEQUE/EXISTING CASA/ZERO BALANCE section
			 wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
			 wrap.wait(2000);
			 if(FundAccount_Choice.equalsIgnoreCase("CHEQUE"))
			 {
				 logger.info("FundAccount_Choice : CHEQUE");
				logger.info("Selected CHEQUE SuccessFully");
				
				wrap.type(BaseProject.driver, Cheque_Number, ChequeNumber );
				logger.info("Entered Cheque Number SuccessFully");
				
				wrap.wait(2000);
				wrap.enterDate(BaseProject.driver, Cheque_Date ,ChequeDate);
				logger.info("Entered Cheque Date SuccessFully");
				wrap.wait(2000); 
				wrap.type(BaseProject.driver, ChequeDrawn_On, ChequeDrawnOn);
				logger.info("Entered Cheque Drawn On SuccessFully");
				wrap.wait(2000);
				wrap.selectFromDropDown(BaseProject.driver, ChequeSuspenseAmount, ChequeSuspense_Account , "BYVISIBLETEXT");
				logger.info("Selected CHEQUE Suspense Amount SuccessFully");
				
				wrap.type(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");
				}
			  else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA"))
			  {
				logger.info("FundAccount_Choice : EXISTING CASA");
				logger.info("Selected EXISTING CASA SuccessFully");
				
				wrap.type(BaseProject.driver, FundAccount_No, FundAccountNo);
				logger.info("Entered Fund Account Number SuccessFully");
				
				wrap.type(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");
				 
			  }
//          else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA")) -- NEW CASA is not applicable for the product
			  else if(FundAccount_Choice.equalsIgnoreCase("ZERO BALANCE"))
			  {
				logger.info("FundAccount_Choice : ZERO BALANCE");
				logger.info("Selected ZERO BALANCE SuccessFully");

			  }
			 
			/////////////////// Roll over choice
			 
			 if(RollOverChoice.equalsIgnoreCase("YES"))
			 {
				 BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceYes, RollOverChoice);
				 logger.info("Clicked YES on Roll Over Choice");
				 if(RollOverInstruction.equalsIgnoreCase("PRINCIPAL"))
				 {
					 wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
					 logger.info("Drop Down Selected for Roll Over Instruction ");
				 }
//     		 wrap.typeToSuggestionTextbox(BaseProject.driver, InterestFrequency , "Code", Interest_Frequency);
				 com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, InterestFrequency, Interest_Frequency, "NA");
				 logger.info("Entered Interest Frequenct - Suggestion Text Box");
				 
			 }
			 else
			 {
				 BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceNo, RollOverChoice);
				 logger.info("Clicked NO on Roll Over Choice");
			 }
			 
			/////////////////////// 2-in-1 section    	 
			 if(TwoInOne.equalsIgnoreCase("YES"))	 
			 {	 
				 BasicData.ClickRadioButton(BaseProject.driver, TwoInOneYes, TwoInOne);
				 logger.info("Clicked YES on 2-in-1");
				 
				 wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOne , TypeOf2in1 , "BYVISIBLETEXT");
				 logger.info("Selected Type of 2-in-1 from Drop Down");
				 
				 wrap.typeToTextBox(BaseProject.driver, TypeOfTwoInOne_AccountNumber, TypeOfTwoInOneAccountNumber);
				 logger.info("Entered 2-in-1 Account No.");
				 
				 wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOneAccountCurrency , TypeOfTwoInOne_AccountCurrency , "BYVISIBLETEXT");
				 logger.info("Selected 2-in-1 Account Currency from Drop Down");
				 
			 }
			 else
			 {
				 BasicData.ClickRadioButton(BaseProject.driver, TwoInOneNo, TwoInOne);
				 logger.info("Selected >>>NO<<< 2-in-1 Radio Button");
			 }
			 
			 /////////////////////// Lien Section
			  
			 if(Lien.equalsIgnoreCase("YES"))	 
			 {	 
				 BasicData.ClickRadioButton(BaseProject.driver, LienY, Lien);
				 logger.info("Selected >>>LIEN->YES <<< Radio Button");
				 
				 wrap.typeToTextBox(BaseProject.driver, Lien_Amount, LienAmount);
				 logger.info("Entered LIEN AMOUNT Successfull");
				 //wrap.typeToSuggestionTextbox(BaseProject.driver, LienNarration , "Code", Lien_Narration);
				 
			 }
			 else
			 {
				 BasicData.ClickRadioButton(BaseProject.driver, LienN, Lien); 
				 logger.info("Selected >>>LIEN->NO <<< Radio Button");
			 }
			 wrap.type(BaseProject.driver, No_of_Deposit, NoOFDeposit);
			 logger.info("Entered NO OF DEPOSIT Successfully");      
        	 
         }
			else{logger.info("Deposit Section not Available for selected product");}
	   	 
	   	logger.info("*************************************DATA FILLING IN DEPOSIT SECTION - COMPLETED*************************************************");
	    logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");

	     
	     String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
	     String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
	     String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
	     String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
	     String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
	     String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
	     String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
	     String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
	     String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
	     String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
	     String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");
	     
//	     String FirstName_CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID);
//	     String MiddleName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID);
//	     String LastName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID);
//
//	     String FirstName_CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID);
//	     String MiddleName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID);
//	     String LastName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID);
	     
	     String Customername_Primary = DBUtils.readColumnWithRowID("Customer Name", BaseProject.scenarioID);    
	     String Relationshiptypecode_Primary = DBUtils.readColumnWithRowID("Relationship type", BaseProject.scenarioID);
	     
	     String Customername_CoApp_One = (DBUtils.readColumnWithRowID("Coapplicant1 Full Name", BaseProject.scenarioID)).toUpperCase(); 
	     String Relationshiptypecode__CoApp_One = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant1", BaseProject.scenarioID);

	     String Customername_CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 Full Name", BaseProject.scenarioID)).toUpperCase();
//	     String Customername__CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID)).toUpperCase();   
	     String Relationshiptypecode_CoApp_Two = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant2", BaseProject.scenarioID);     
	 	 
	     logger.info("Customername_CoApp_One :"+Customername_CoApp_One);
	     logger.info("Relationshiptypecode__CoApp_One :"+Relationshiptypecode__CoApp_One);
	     logger.info("Customername__CoApp_Two :"+Customername_CoApp_Two);
	     logger.info("Relationshiptypecode_CoApp_Two :"+Relationshiptypecode_CoApp_Two);

	     
	     
	   	 jse.executeScript("scroll(0, 250);");
//    	 WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading)); 	 
//       jse.executeScript("arguments[0].scrollIntoView(true);", heading);        
         WebElement isCustomerAvailable = BaseProject.driver.findElement(By.xpath(AvailableCustomer));
         boolean isCustomerPresent= isCustomerAvailable.isDisplayed();         
         
         if(isCustomerPresent)
         {
        	 logger.info("Customer Relationship details Available");
        	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
        	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
        	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
		        
            	 if(Customername_CoApp_One!=null)
            	 {
            		 logger.info("Adding Customer Relationship details - CO APPLICANT ONE");
            		 
                	 boolean loop_Flag=true;
                	 while (loop_Flag)
                	 {
                		 logger.info("Inside loopFlag 1");
//                		 jse.executeScript("arguments[0].click();", addrow);
                		 wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
                		 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty))));
                		 if(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty)).isDisplayed()){loop_Flag=false;}
                		 else{logger.info("Select Customer DropDown is not displayed");}
                	}
            	     wrap.selectFromDropDown(BaseProject.driver, CoApplicant_One_CustomerProperty, Customername_CoApp_One,  "BYVISIBLETEXT");
            	     wrap.selectFromDropDown(BaseProject.driver, Relationship_One_Property, Relationshiptypecode__CoApp_One,  "BYVISIBLETEXT");
//            	     new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(addrow));
            	     wrap.wait(2000);
            	     
            	     logger.info(Customername_CoApp_Two!=null);
            	     if(Customername_CoApp_Two!=null )
                	 {
            	    	 logger.info("Adding Customer Relationship details - CO APPLICANT TWO");
                    	 boolean loopFlag=true;
                    	 while (loopFlag)
                    	 {
                    		 logger.info("Inside loopFlag 2");
//                    		 jse.executeScript("arguments[0].click();", addrow);
                    		 wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
                    		 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_Two_CustomerProperty))));
                    		 if(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty)).isDisplayed()){loopFlag=false;}
                    		 else{logger.info("Select Customer DropDown is not displayed");}
                    	}        	    	 
                	     wrap.selectFromDropDown(BaseProject.driver, CoApplicant_Two_CustomerProperty, Customername_CoApp_Two,  "BYVISIBLETEXT");
                	     wrap.selectFromDropDown(BaseProject.driver, Relationship_Two_Property, Relationshiptypecode_CoApp_Two,  "BYVISIBLETEXT");
                	                	    	 
                	 }
            	     else
                	 {
                		 logger.info("COAPPLICANT TWO DETAILS NOT PROVIDED or CONTAINS ***NULL*** VALUE IN IT");
                	 }		 
            	 }
            	 else
            	 {
            		 logger.info("COAPPLICANT ONE DETAILS NOT PROVIDED or CONTAINS ***NULL*** VALUE IN IT");
            	 }	 
         }
         else
         {
        	 logger.info("Customer Relationship details Available");
        	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
        	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
        	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
         }	 
	     

	     logger.info("************************************Product and Customer Relation- ENDS*****************************************************");
     
     
        }  	
		
    @Then("^Blind : Validate Field values '(.+)'$")
	public static void validateFieldStepChecker(String FieldName) throws Throwable{
		
    	logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");
		
    	JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
    	BaseProject.propertiesFilename = "BlindData";
		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BasicDataModel.csv");
		try{

			if(!(Fieldval[0]).equalsIgnoreCase(null)){
				js.executeScript("arguments[0].scrollIntoView(true);",Fieldval[11]);
				wrap.click(BaseProject.driver, com.getElementProperties("BlindData", Fieldval[11]));
				
				wrap.wait(2000);
				logger.info("Field validation starts"); 
						CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);

			}
		}

		catch(Exception E){

			System.out.println("Field : "+FieldName+" is not present in Datamodel");
		}            

	}
    
    @Then("^Blind: Data Filling in Product and Customer Relation for Primary$")
    public static void DataFilling_the_product_Customer_Relation_For_Primary() throws IOException, InterruptedException {

     logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");

  
     String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
     String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
     String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
     String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
     String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
     String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
     String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
     String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
     String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
     String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
     String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
     String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");
     String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
     String ProductDetails_header=com.getElementProperties("BasicData", "ProductDetails_header");
     
     
     String ProductCategoryText=null;
     
 	 JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
	 
	 ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
	 logger.info("ProductCategoryText : "+ ProductCategoryText);
	 
	 WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading));
     jse.executeScript("arguments[0].scrollIntoView(true);", heading);
     
     boolean isCustomerPresent = BaseProject.driver.findElement(By.xpath(AvailableCustomer)).isDisplayed();
     if(isCustomerPresent)
     {
    	 logger.info("Customer Relationship details Available");
    	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
    	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
    	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
    	 
     }
     else
     {
    	 logger.info("Customer Relationship details Available");
    	 String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
    	 String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
    	 logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
     }	 

   	 
     logger.info("************************************Product and Customer Relation- ENDS*****************************************************");

    }
@Then("^Blind: application details tab is clicked$")

    public static void into_applications_tab() throws InterruptedException, IOException{
    	
    	logger.info("**************************************Application Details Tab- STARTS*******************************************************");
    	
    	 wrap.switch_to_default_Content(BaseProject.driver);
         wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
         wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ApplicationTab"));
         wrap.wait(1000);
         wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
         wrap.wait(1000);        
    }
    
    @Then("^Blind: do the UI Validation part$")
    public static void do_the_UI_Validation(){

      
      List<WebElement> a=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'AOF Date')] | //span[contains(text(),'Application Created Date')] | //span[contains(text(),'Sourcing ID')] | //span[contains(text(),'Referral ID')] | //span[contains(text(),'Country Of Account Opening')] | //span[contains(text(),'Channel Reference No')] | //span[contains(text(),'Source Reference')] |  //span[contains(text(),'Application Branch')] | //label[contains(text(),'Fast track Flag')] | //label[contains(text(),'Acquisition Channel')]"));
      
      Iterator<WebElement> itr2=a.iterator();
      
      while(itr2.hasNext())
      {
      	String b=itr2.next().getText();
      	System.out.println(b + "\n");
      }

    }
    
    @Then("^Blind: do the dropdown Validation of Application Branch$")
    public static void do_the_dropdown_Validation(){

      
    	List<WebElement> c=BaseProject.driver.findElements(By.xpath("//select[@id='ApplicationBranch']/option"));
        
    	//List<WebElement> e=BaseProject.driver.findElements(By.xpath("//select[@id='AcquisitionCode']/option"));
        
    	//List<WebElement> f=BaseProject.driver.findElements(By.xpath("//select[@id='Priority']/option"));
        
        Iterator<WebElement> itr2=c.iterator();
        
        while(itr2.hasNext())
        {
        	String d=itr2.next().getText();
        	System.out.println(d + "\n");
        }}
    
	    @Then("^Blind: Check for negative validation for customer details tab$")
	    public static void negativeForProductsDetailsTab() throws IOException, InterruptedException 
	    	{
	    	
	    	utils.convertExcelToMap(BasicData.excelPath, "Datamodel.xls", "Negative");
	    	
	    	//Products Details Section Fields:
			utils.negativeVals("Promotion / Campaign Code", com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode"));
	    	utils.negativeVals("ProductCode", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Prdcd"));
	    	utils.negativeVals("Term", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
	    	utils.negativeVals("Tenure Type", com.getElementProperties("BasicData", "BD_TD_TD_TenureType"));
	    	
	    	//A/C Setup Section Fields:
	    	utils.negativeVals("Purpose of account opening", com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath"));
	    	utils.negativeVals("Account Request Type", com.getElementProperties("BasicData", "AcSetup_AcReqType"));
	    	utils.negativeVals("Account Currency", com.getElementProperties("BasicData", "AcSetup_AccountCurrency"));
	    	utils.negativeVals("Account Number", com.getElementProperties("BasicData", "AcSetup_AccountNumber"));
	    	utils.negativeVals("Service Type", com.getElementProperties("BasicData", "AcSetup_ServiceType"));
	    	
	    	
	    	//Term Deposite Section:
	    	utils.negativeVals("Deposit Amount", com.getElementProperties("BasicData", "DepositInfo_DepositAmount"));
	    	utils.negativeVals("Value Date", com.getElementProperties("BasicData", "DepositInfo_ValueDate"));
	    	utils.negativeVals("Fund Account Choice", com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice"));
	    	utils.negativeVals("Cheque Number", com.getElementProperties("BasicData", "DepositInfo_ChequeNumber"));
	    	utils.negativeVals("Cheque Date", com.getElementProperties("BasicData", "DepositInfo_ChequeDate"));
	    	utils.negativeVals("Cheque Drawn on", com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn"));
	    	utils.negativeVals("Cheque suspense Account", com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount"));
	    	utils.negativeVals("Amount", com.getElementProperties("BasicData", "DepositInfo_Amount"));
	    	utils.negativeVals("Roll Over Choice", com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes"));
			utils.negativeVals("Roll Over Choice", com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No"));
	    	utils.negativeVals("Roll Over Instruction", com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction"));
	    	utils.negativeVals("Payment Mode", com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode"));
	    	utils.negativeVals("Interest - Frequency", com.getElementProperties("BasicData", "DepositInfo_InterestFrequency"));
	    	utils.negativeVals("Interest Account No", com.getElementProperties("BasicData", "BD_TD_TD_InterestAccountNo"));
	    	utils.negativeVals("Interest Customer Name", com.getElementProperties("BasicData", "FD_AddressLine1"));
	    	utils.negativeVals("Interest Account Currency", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
	    	utils.negativeVals("Interest Account Relationship Number", com.getElementProperties("BasicData", "BD_TD_TD_TenureType"));
	    	utils.negativeVals("Interest Account Benefeciary Name", com.getElementProperties("BasicData", "FDC_CD_AddressSection_AddressType_suggestionBox"));
	    	utils.negativeVals("Interest Account Address Type", com.getElementProperties("BasicData", "FD_AddressLine1"));
	    	utils.negativeVals("Interest Account Disposal Code", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
	    	utils.negativeVals("2-in-1", com.getElementProperties("BasicData", "DepositInfo_LienY"));
		    utils.negativeVals("2-in-1", com.getElementProperties("BasicData", "DepositInfo_LienN"));
	    	utils.negativeVals("Maturity Date", com.getElementProperties("BasicData", "DepositInfo__MaturityDate"));
	    	utils.negativeVals("Type of 2-in-1", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne"));
	    	utils.negativeVals("2-in-1 Account No", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber"));
	    	utils.negativeVals("2-in-1 Currency", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency"));
	    	utils.negativeVals("Lien", com.getElementProperties("BasicData", "DepositInfo_LienY"));
			utils.negativeVals("Lien", com.getElementProperties("BasicData", "DepositInfo_LienN"));
	    	utils.negativeVals("Lien Amount", com.getElementProperties("BasicData", "DepositInfo_LienAmount"));
	    	utils.negativeVals("Lien Expiry Date", com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate"));
	    	utils.negativeVals("Lien Narration", com.getElementProperties("BasicData", "DepositInfo_LienNarration"));
	    	utils.negativeVals("No of Deposit", com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit"));
	    
	    	}
    
    

	    @When("^Blind: Data filling in Products Details Tab under Deposite Info if Available$")
	    public void Data_filling_in_Products_Details_Tab_under_DepositInfo_section() throws IOException, InterruptedException 
	    {    
	    	
	    	logger.info("***************************** DEPOSIT INFO SECTION STARTS- TD**************************************");
	    	String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
	        String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
	        
	    	
	        
	        wrap.wait(2000);		 
	    	List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
	    	
	    	JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
	    	myExecutor.executeScript("arguments[0].click();", TabNo.get(0));   	 	
	    	logger.info("Total Number of TABS : "+ (TabNo.size()));
		 	
	   	 	
	   	 	int tabNo=0;
	   	 	boolean tdFlag=false;
	   	 	
		   	 for (int c = 0; c < TabNo.size(); c++) 
		     {
		   		 wrap.wait(1000);	
		    	 logger.info("Inside Loop : "+(c+1));
		    	 myExecutor.executeScript("arguments[0].click();", TabNo.get(c));
	             logger.info("TAB NAME : "+TabNo.get(c).getText());
	             
	             String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
	             logger.info("Product is" + ProductCategory);
	             
	             if(ProductCategory.equalsIgnoreCase("TERM DEPOSITS"))
	             {
	            	 logger.info("TD PRODUCT is in Tab: "+(c+1));
	            	 tabNo=c;
	            	 tdFlag=true;
	            	 
	             }
	             else
	             {
	            	 logger.info("THERE IS NO TD PRODUCT");
	             }
		     }
		   	 
				if(tdFlag)
	            {
					String Productsection = com.getElementProperties("BasicData", "Productsection");
			    	String DepositAmount = com.getElementProperties("BasicData", "DepositInfo_DepositAmount");
			        String ValueDate = com.getElementProperties("BasicData", "DepositInfo_ValueDate");
			        String FundAccountChoice = com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice");
			        String ChequeNumber = com.getElementProperties("BasicData", "DepositInfo_ChequeNumber");
			        String ChequeDate = com.getElementProperties("BasicData", "DepositInfo_ChequeDate");
			        String ChequeDrawnOn= com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn");
			        String ChequeSuspenseAmount=com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount");
			        String Amount=com.getElementProperties("BasicData", "DepositInfo_Amount");
			        String RollOverChoiceYes=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes");
			        String RollOverChoiceNo=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No");
			        String RollInstruction=com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction");
			        String InterestFrequency = com.getElementProperties("BasicData", "DepositInfo_InterestFrequency");
			        String TwoInOneYes= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_Yes");
			        String TwoInOneNo= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_No");
			        String MaturityDate=com.getElementProperties("BasicData", "DepositInfo__MaturityDate");
			        String LienY=com.getElementProperties("BasicData", "DepositInfo_LienY");
			        String LienN=com.getElementProperties("BasicData", "DepositInfo_LienN");
			        String LienAmount=com.getElementProperties("BasicData", "DepositInfo_LienAmount");
			        String LienExpiryDate=com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate");
			        String LienNarration=com.getElementProperties("BasicData", "DepositInfo_LienNarration");
			        String NoOFDeposit=com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit");
			        String TypeOfTwoInOne=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne");
			        String TypeOfTwoInOneAccountNumber=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber");
			        String TypeOfTwoInOneAccountCurrency=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency");
			        String FundAccountNo = com.getElementProperties("BasicData", "DepositInfo_FundAccountNumber");
			        String PaymentMode = com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode");
			        String InterestAccountNumber = com.getElementProperties("BasicData", "BD_TD_TD_InterestAccountNo");

			        String DepositInfo_header=com.getElementProperties("BasicData", "DepositInfo_header");
			        
			        ////////////////////// DB        
			    	String Deposit_Amount = DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID);
			        String Value_Date = DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID);
			        String FundAccount_Choice = DBUtils.readColumnWithRowID("TD_FundAccountChoice", BaseProject.scenarioID);
			        String FundAccount_No = DBUtils.readColumnWithRowID("FundAccount_No", BaseProject.scenarioID);
			        String Cheque_Number = DBUtils.readColumnWithRowID("Cheque_Number", BaseProject.scenarioID);
			        String Cheque_Date = DBUtils.readColumnWithRowID("Cheque_Date", BaseProject.scenarioID);
			        String ChequeDrawn_On= DBUtils.readColumnWithRowID("ChequeDrawn_On", BaseProject.scenarioID);
			        String ChequeSuspense_Account=DBUtils.readColumnWithRowID("ChequeSuspense_Account", BaseProject.scenarioID);
			        String Amount_DI=DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID);
			        String RollOverChoice= DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			        String InterestAccount_Number=DBUtils.readColumnWithRowID("InterestAccountNo", BaseProject.scenarioID);
			        String Interest_Frequency = DBUtils.readColumnWithRowID("TD_InterestFrequency", BaseProject.scenarioID);
//			        String TwoInOne_No= DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID);
			        String Maturity_Date=DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID);
			        String Lien=DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID);
			        String Lien_Amount=DBUtils.readColumnWithRowID("Lien_Amount", BaseProject.scenarioID);
			        String LienExpiry_Date=DBUtils.readColumnWithRowID("LienExpiry_Date", BaseProject.scenarioID);
//			        String Lien_Narration=DBUtils.readColumnWithRowID("Lien_Narration", BaseProject.scenarioID);
//			      String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
			        String No_of_Deposit=DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID);
			        String RollOver_Choice=DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			        String RollOverInstruction=DBUtils.readColumnWithRowID("RollOverInstruction", BaseProject.scenarioID);
			        String TwoInOne= DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID);
			        String TypeOf2in1=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne", BaseProject.scenarioID);
			        String TypeOfTwoInOne_AccountNumber=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountNumber", BaseProject.scenarioID);
			        String TypeOfTwoInOne_AccountCurrency=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountCurrency", BaseProject.scenarioID);
			   
			        
			        logger.info("Deposit_Amount: "+Deposit_Amount);
			        logger.info("Value_Date: "+Value_Date);
			        logger.info("FundAccount_Choice: "+FundAccount_Choice);
			        logger.info("FundAccount_No: "+FundAccount_No);
			        logger.info("Cheque_Number: "+Cheque_Number);
			        logger.info("Cheque_Date: "+Cheque_Date);
			        logger.info("ChequeDrawn_On: "+ChequeDrawn_On);
			        logger.info("ChequeSuspense_Account: "+ChequeSuspense_Account);
			        logger.info("Amount_DI: "+Amount_DI);
			        logger.info("RollOverChoice: "+RollOverChoice);
			        logger.info("InterestAccount_Number: "+InterestAccount_Number);
			        logger.info("Interest_Frequency: "+Interest_Frequency);
			        logger.info("Lien: "+Lien);
			        logger.info("Lien_Amount: "+Lien_Amount);
			        logger.info("LienExpiry_Date: "+LienExpiry_Date);
			        logger.info("No_of_Deposit: "+No_of_Deposit);
			        logger.info("RollOver_Choice: "+RollOver_Choice);
			        logger.info("RollOverInstruction: "+RollOverInstruction);
			        logger.info("TwoInOne: "+TwoInOne);
			        logger.info("TypeOf2in1: "+TypeOf2in1);
			        logger.info("TypeOfTwoInOne_AccountNumber: "+TypeOfTwoInOne_AccountNumber);
			        logger.info("TypeOfTwoInOne_AccountCurrency: "+TypeOfTwoInOne_AccountCurrency);
				 
				 myExecutor.executeScript("arguments[0].click();", TabNo.get(tabNo));
				 WebElement DI_heading = BaseProject.driver.findElement(By.xpath(DepositInfo_header));
				 myExecutor.executeScript("arguments[0].scrollIntoView(true);", DI_heading);  
				 		                 
				 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DepositAmount)));
				 
				 wrap.type(BaseProject.driver, Deposit_Amount, DepositAmount);
				 logger.info("Entered Deposit Amount SuccessFully");
				 
//				 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ValueDate)));
				 
				 wrap.wait(2000);
				 WebElement ValueDateClick = BaseProject.driver.findElement(By.xpath(ValueDate));
				 myExecutor.executeScript("arguments[0].click();", ValueDateClick);
				 
				 wrap.enterDate(BaseProject.driver, Value_Date ,ValueDate);

				 logger.info("Entered Value Date SuccessFully");

				 /////////////--- CHEQUE/EXISTING CASA/ZERO BALANCE section
				 
				 if(FundAccount_Choice.equalsIgnoreCase("CHEQUE"))
				 {
					wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
					logger.info("Selected CHEQUE SuccessFully");
					
					wrap.type(BaseProject.driver, Cheque_Number, ChequeNumber );
					logger.info("Entered Cheque Number SuccessFully");
					
					wrap.wait(1000);
					wrap.enterDate(BaseProject.driver, Cheque_Date ,ChequeDate);
					logger.info("Entered Cheque Date SuccessFully");
					 
					wrap.type(BaseProject.driver, ChequeDrawn_On, ChequeDrawnOn);
					logger.info("Entered Cheque Drawn On SuccessFully");
					
					wrap.selectFromDropDown(BaseProject.driver, ChequeSuspenseAmount, ChequeSuspense_Account , "BYVISIBLETEXT");
					logger.info("Selected CHEQUE Suspense Amount SuccessFully");
					
					wrap.type(BaseProject.driver, Amount_DI, Amount);
					logger.info("Entered Amount SuccessFully");
					}
				  else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA"))
				  {
					wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
					logger.info("Selected EXISTING CASA SuccessFully");

					wrap.typeToTextBox(BaseProject.driver, FundAccount_No, FundAccountNo);
					logger.info("Entered Fund Account Number SuccessFully");
					
					wrap.typeToTextBox(BaseProject.driver, Amount_DI, Amount);
					logger.info("Entered Amount SuccessFully");
					 
				  }
//	             else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA")) -- NEW CASA is not applicable for the product
				  else if(FundAccount_Choice.equalsIgnoreCase("ZERO BALANCE"))
				  {
					wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
					logger.info("Selected ZERO BALANCE SuccessFully");

				  }
				 
				/////////////////// Roll over choice
				 
				 if(RollOverChoice.equalsIgnoreCase("YES"))
				 {
					 BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceYes, RollOverChoice);
					 logger.info("Clicked YES on Roll Over Choice");
					 if(RollOverInstruction.equalsIgnoreCase("PRINCIPAL"))
					 {
						 wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
						 logger.info("Drop Down Selected for Roll Over Instruction ");
					 }
//	        		 wrap.typeToSuggestionTextbox(BaseProject.driver, InterestFrequency , "Code", Interest_Frequency);
					 com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, InterestFrequency, Interest_Frequency, null);
					 logger.info("Entered Interest Frequenct - Suggestion Text Box");
					 
				 }
				 else
				 {
					 BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceNo, RollOverChoice);
					 logger.info("Clicked NO on Roll Over Choice");
				 }
				 
				/////////////////////// 2-in-1 section    	 
				 if(TwoInOne.equalsIgnoreCase("YES"))	 
				 {	 
					 BasicData.ClickRadioButton(BaseProject.driver, TwoInOneYes, TwoInOne);
					 logger.info("Clicked YES on 2-in-1");
					 
					 wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOne , TypeOf2in1 , "BYVISIBLETEXT");
					 logger.info("Selected Type of 2-in-1 from Drop Down");
					 
					 wrap.typeToTextBox(BaseProject.driver, TypeOfTwoInOne_AccountNumber, TypeOfTwoInOneAccountNumber);
					 logger.info("Entered 2-in-1 Account No.");
					 
					 wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOneAccountCurrency , TypeOfTwoInOne_AccountCurrency , "BYVISIBLETEXT");
					 logger.info("Selected 2-in-1 Account Currency from Drop Down");
					 
				 }
				 else
				 {
					 BasicData.ClickRadioButton(BaseProject.driver, TwoInOneNo, TwoInOne);
					 logger.info("Selected >>>NO<<< 2-in-1 Radio Button");
				 }
				 
				 /////////////////////// Lien Section
				myExecutor.executeScript("window.scrollBy(0,document.body.scrollHeight)");
				  
				 if(Lien.equalsIgnoreCase("YES"))	 
				 {	 
					 BasicData.ClickRadioButton(BaseProject.driver, LienY, Lien);
					 logger.info("Selected >>>LIEN->YES <<< Radio Button");
					 
					 wrap.typeToTextBox(BaseProject.driver, Lien_Amount, LienAmount);
					 logger.info("Entered LIEN AMOUNT Successfull");
//	        		 wrap.typeToSuggestionTextbox(BaseProject.driver, LienNarration , "Code", Lien_Narration);
					 
				 }
				 else
				 {
					 BasicData.ClickRadioButton(BaseProject.driver, LienN, Lien); 
					 logger.info("Selected >>>LIEN->NO <<< Radio Button");
				 }
				 wrap.type(BaseProject.driver, No_of_Deposit, NoOFDeposit);
				 logger.info("Entered NO OF DEPOSIT Successfully");      
	           	 
	            }
		   	 
		   	logger.info("*************************************DATA FILLING IN DEPOSIT SECTION - COMPLETED*************************************************");

	    	}
	    
	    @When("^Blind: Clicking Save Button$")
	    public void Clicking_Save_Button() throws Throwable {
	        
	        String Save = com.getElementProperties("BasicData", "BasicData_Save_Button_XPATH");
	        wrap.scroll_to(BaseProject.driver, Save);
	        
	        try {
	        	
	        	wrap.click_wait(BaseProject.driver, Save);
	            logger.info("********* Save Button Clicked *************");
	            
	        }catch (Exception e){
	        	
	            e.printStackTrace();
	            logger.info("Unable to Click on Save Button");
	        }
	    }

	    // Added on 19 feb
	    @Then("^Blind: Switch to Product details tab$")
		public static void switchToProductDetailsTab() throws InterruptedException, IOException {

			wrap.switch_to_default_Content(BaseProject.driver);
			wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
			wrap.click(BaseProject.driver, com.getElementProperties("BlindData", "BlindData_ProductDetail_ProductDetails_Button_XPATH"));
			wrap.wait(2000);
		}
	    
	    @Then("^Blind: Check for negative validation for Document Number$")
		public static void negativeValidationForDocumentNumber() throws IOException, InterruptedException 
		{
			utils.negativeVals("Document Number", com.getElementProperties("BlindData", "BlindData_CustomerDetail_DocumentNumber_TextBox_ID"));
		}
	    
	    @Then("^Blind: Goto Co-Applicant1$")
		public static void gotoApplicant() throws IOException, InterruptedException 
		{
			wrap.click(BaseProject.driver, com.getElementProperties("BlindData", "BlindData_CustomerDetail_coapplicant_XPATH"));
		}
	    
	    @Then("^Blind: Check for negative validation for Account Currency Code$")
		public static void negativeValidationForAccountCurrencyCode() throws IOException, InterruptedException 
		{
			utils.negativeVals("Account Currency Code", com.getElementProperties("BasicData", "AcSetup_AccountCurrency"));
		}
		
		@Then("^Blind: Check for negative validation for First Name$")
		public static void negativeValidationForFirstName() throws IOException, InterruptedException 
		{
			utils.negativeVals("First Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID"));
		}
		
		@Then("^Blind: Check for negative validation for Middle Name$")
		public static void negativeValidationForMiddleName() throws IOException, InterruptedException 
		{
			utils.negativeVals("Middle Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID"));
		}
		
		@Then("^Blind: Check for negative validation for Last Name$")
		public static void negativeValidationForLastName() throws IOException, InterruptedException 
		{
			utils.negativeVals("Last Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID"));
		}
		
		@Then("^Blind: Check for negative validation for Alias First Name$")
		public static void negativeValidationForAliasFirstName() throws IOException, InterruptedException 
		{
			utils.negativeVals("Alias First Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1"));
		}
		
		@Then("^Blind: Check for negative validation for Alias Middle Name$")
		public static void negativeValidationForAliasMiddleName() throws IOException, InterruptedException 
		{
			utils.negativeVals("Alias Middle Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1"));
		}
		
		@Then("^Blind: Check for negative validation for Alias Last Name$")
		public static void negativeValidationForAliasLastName() throws IOException, InterruptedException 
		{
			utils.negativeVals("Alias Last Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1"));
		}
		
		@Then("^Blind: Choose Alias Type$")
		public static void chooseAliasType() throws IOException, InterruptedException 
		{
			String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1");	
			String Aliassection = com.getElementProperties("BasicData", "Aliassection");
			String AddAliasButton = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddAlias_Button");	
			
			String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);

			wrap.scroll_to(BaseProject.driver, Aliassection);  
			String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
			if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

				String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
				if (AliasSection.equals("false")) {
					wrap.click(BaseProject.driver, Aliassection);

				}

				wrap.click(BaseProject.driver, AddAliasButton);
				logger.info("Alias Add Button Clicked");

				if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1"))) {	
					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
					String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
					logger.info("Selected Alias type is: " + AliasValue);		
					} else {
					logger.info("Alias Information Not Entered");
				}

			} else {
				logger.info("Alias Info Section Not Available");
			}

		}	
		
		@Then("^Blind: Check for negative validation for Nationality$")
		public static void negativeValidationForNationality() throws IOException, InterruptedException 
		{
			utils.negativeVals("Nationality Code1", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality_ListBox_ID"));
		}


		@Then("^Blind: Check for negative validation for Country Of Birth$")
		public static void negativeValidationForCountryOfBirth() throws IOException, InterruptedException 
		{
			utils.negativeVals("Nationality Code1", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID"));
		}
			
		@Then("^Blind: Check for negative validation for Residence Country$")
		public static void negativeValidationForResidenceCountry() throws IOException, InterruptedException 
		{
			utils.negativeVals("Residence Country Code", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID"));
		}
		
		@Then("^Blind: Check for negative validation for Contact Details$")
		public static void negativeValidationForContactDetails() throws IOException, InterruptedException 
		{
			utils.negativeVals("Contact Details", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH"));
		}
		
		@Then("^Blind: Choose Alias Type for coapplicant$")
		public static void chooseAliasTypeForCoapplicant() throws IOException, InterruptedException 
		{
			String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD_Coapp");	
			String Aliassection = com.getElementProperties("BasicData", "Aliassection");
					
			String Alias_Type = DBUtils.readColumnWithRowID("Coapplicant1 Alias Type2", BaseProject.scenarioID);

			wrap.scroll_to(BaseProject.driver, Aliassection);  
			String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
			if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

				String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
				if (AliasSection.equals("false")) {
					wrap.click(BaseProject.driver, Aliassection);

				}

				/*wrap.click(BaseProject.driver, AddAliasButton);
				logger.info("Alias Add Button Clicked");*/

				if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD_Coapp"))) {	
					wrap.wait(2000);
					wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
					String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
					logger.info("Selected Alias type is: " + AliasValue);		
					} else {
					logger.info("Alias Information Not Entered");
				}

			} else {
				logger.info("Alias Info Section Not Available");
			}

		}	
		
	    @Then("^Blind : Validate Field '(.+)'$")
	    public  void validateField(String FieldName) throws Throwable{

			logger.info("Going to switch into frame");

			switchFrame();

			logger.info("Frame switched successfully");

			BaseProject.propertiesFilename = "BasicData";
			CommonUtilsData.FieldNameData = FieldName; 
			String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BasicDataModel.csv");
			try{
				if(!(Fieldval[0]).equalsIgnoreCase(null)){
					logger.info("Field validation starts"); 
					CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
				}
			}
			catch(Exception E){

				logger.info("Field : "+FieldName+" is not present in Datamodel");
			}   
		}
	    
	    @When("^Blind:Select contact type and Check if extension details field is enabled$")
	    public void extensionDetailsEnabled() throws IOException, InterruptedException
	    {
	    	 String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
	    	 String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
	    	 String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
	    	     waitUntilVisibilityOfWebElement(ContactType);
	    	        wrap.click(BaseProject.driver, ContactType);
	    			wrap.TypeToTextBoxAndTabOut(BaseProject.driver, Contact_type_Code, ContactType);
	    			if(Contact_type_Code.contains("OT"))
	    			{
	    			wrap.isElementEnabled(BaseProject.driver, Extension);
	    			}
	    			else
	    			{
	    				logger.info("Contact type selected is other than OT");
	    			}
	    }
		
	    @When("^Blind:Delete primary applicant$")
	    public void deletePrimaryApplicant() throws IOException, InterruptedException
	    {
	    	logger.info("Going to click delete primary applicant button");
	    	wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "PrimaryApplicant_deletebutton"));
	    	wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_primaryapplicant_XPATH"));

	    }
	    
	    
	    @When("^Blind:Select contact type$")
	    public void selectContactType() throws IOException, InterruptedException
	    {
	    	wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
	    	switchFrame();
	    	String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
	    	 String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID"); 
	    	 wrap.wait(1000);
	    	// waitUntilVisibilityOfWebElement(ContactType);
	    	 wrap.click(BaseProject.driver, ContactType);
	    	 wrap.TypeToTextBoxAndTabOut(BaseProject.driver, Contact_type_Code, ContactType);
	    }
	    	
	    @When("^Blind:Choose campaign code$")
	    public void chooseCampaignCode() throws IOException, InterruptedException
	    {
			
	    	 String CampaignCode= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
	    	        String Campaign_Code= DBUtils.readColumnWithRowID("CampaignCode", BaseProject.scenarioID);
	    			 JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
	    	        WebElement Campaign_code = BaseProject.driver.findElement(By.xpath(CampaignCode));
	    		    jse.executeScript("arguments[0].click();",Campaign_code );
	    	        com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, CampaignCode, Campaign_Code, null);
	    	        logger.info("Entered Campaign Code SuccessFully");
	    }
	   
	    @When("^Blind:Enter DOB for minor and validate the occupation displayed$")
	    public void validateOccupationForMinor() throws IOException, InterruptedException
	    {
	    	 int i = Integer.parseInt("1");
			 int k = i + 1;
	    	 String DOB = DBUtils.readColumnWithRowID("Coapplicant" + i + " DOB", BaseProject.scenarioID);		   
			     String DateOfBirth2 = "id=DateOfBirth" + k + "";
			     System.out.println("Date of Birth Id: " + DateOfBirth2);
			     verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
			     wrap.enterDate(BaseProject.driver, DOB, DateOfBirth2);
			   String occupationDisplayed =  wrap.getValue(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID"));
			   if(occupationDisplayed.equalsIgnoreCase("Minor"))
			   {
				   logger.info("Occupation is displayed as Minor");
			   }
	    }
	    
	    @Then("^Blind : Validate Field with UnifiedTestCaseRef '(.+)' '(.+)'$")
	    public  void validateField(String FieldName,String unifiedTestCaseRef) throws Throwable{

			logger.info("Going to switch into frame");

			switchFrame();

			logger.info("Frame switched successfully");

			BaseProject.propertiesFilename = "BasicData";
			CommonUtilsData.FieldNameData = FieldName; 
			String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BasicDataModel.csv");
			try{
				if(!(Fieldval[0]).equalsIgnoreCase(null)){
					logger.info("Field validation starts"); 
					CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
				}
			}
			catch(Exception E){

				logger.info("Field : "+FieldName+" is not present in Datamodel");
			}   
		}
	    
}
