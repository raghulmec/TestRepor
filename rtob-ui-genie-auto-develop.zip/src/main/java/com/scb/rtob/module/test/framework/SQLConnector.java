package com.scb.rtob.module.test.framework;		
import  java.sql.Connection;		
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;		

import cucumber.api.java.en.Then;
public class  SQLConnector {
	
	
	@Then("^Validate Genie DB$")
	public static String Result(String RelNo) throws ClassNotFoundException, SQLException
	{
		String dbUrl ="jdbc:db2://10.112.185.56:50070/INEBBS";					
		RelNo="0100000000100013";
		//Database Username		
		String username ="indb2rpt";	
        
		//Database Password		
		String password ="xs3ri3s";				

		//Query to Execute		
		String query = "select * from DB2INST1.REL where RELATIONSHIPNO IN ('"+RelNo+"')";	
        
 	    //Load mysql jdbc driver		
   	    Class.forName("com.ibm.db2.jcc.DB2Driver");			
   
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	System.out.println("Connnected with DB");
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					

			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);							
 
 		// While Loop to iterate through all data and print results		
		while (rs.next()){
			
			if (rs.getString("FULLNAME") != null)
				
				System.out.println("Tested the Rel No in eBBS: "+RelNo);
			System.out.println("Below is the full naame of the Rel No");
	        		System.out.println(rs.getString("FULLNAME"));	
	        		return rs.getString("FULLNAME");	
            }
		return "Rel No Not found";		
		
		
		
		
			 // closing DB Connection		
						

	
		
		
	}
	
    	
}