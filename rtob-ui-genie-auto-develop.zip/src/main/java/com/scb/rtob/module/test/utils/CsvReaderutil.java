package com.scb.rtob.module.test.utils;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

//import com.csvreader.CsvReader;
import com.opencsv.CSVReader;
import com.scb.rtob.module.test.framework.glue.BaseProject;
//import com.scb.rtob.module.test.framework.glue.Basicdatacapturechecker;=
import com.scb.rtob.module.test.framework.glue.Basicdatacapturechecker;

public class CsvReaderutil { 
	public static WebDriver driver=BaseProject.driver;
	private static Logger logger = Logger.getLogger(Basicdatacapturechecker.class);
	public static String csvpath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData\\";



	@SuppressWarnings("unchecked")
	public static void Read_values_from_CSV(String Field, String xpath,String filename) throws Throwable {
//		try { 
//			String csvFilename = csvpath+filename;
//			//			String csvFilename = "C:\\Automation files\\Framework workspace\\RTOB\\BDC_CheckerLOVvalues.csv"; 
//			BufferedReader br = new BufferedReader( new FileReader(csvFilename));
//			CsvReader products = new CsvReader(br);
//			//products.getValues();
//			products.readHeaders();
//			while (products.readRecord())
//			{
//				String productID = products.get(Field);
//				List Documnet_Category_List=Arrays.asList(productID.split(","));
//
//				Iterator document_category = Documnet_Category_List.iterator();
//				while(document_category.hasNext()){
//					String doclists=document_category.next().toString().trim().toUpperCase();
//					logger.info("Value from CSV: " + doclists);
//				}     
//
//				Collections.sort(Documnet_Category_List);
//				logger.info(Documnet_Category_List);
//				switchFrame();
//
//				ArrayList<String> doclistsort = new ArrayList();
//				WebElement element= BaseProject.driver.findElement(By.xpath(xpath));
//				JavascriptExecutor js = (JavascriptExecutor) driver;
//				js.executeScript("arguments[0].scrollIntoView(true);",element);
//				//WebElement ele = wrap.getElement(BaseProject.driver, Attribute)
//				Select doclist=new Select(element);
//				List<WebElement> doclist_count=doclist.getOptions(); 
//				Boolean check = false;
//				for(WebElement ele:doclist_count)
//				{
//					if(!ele.getText().equalsIgnoreCase("Please Select..."))
//					{
//						doclistsort.add(ele.getText()); 
//						logger.info("LOV from APP: " +ele.getText());
//					}
//				}
//				Collections.sort(doclistsort);
//				logger.info("Values added to the list: "+doclistsort);
//				//logger.info(doclistsort);
//				for(int i=0;i<=doclistsort.size();i++)
//				{
//					if(Documnet_Category_List.get(i).equals(doclistsort.get(i))){
//						logger.info("LOV value: "+Documnet_Category_List.get(i)+ " value matches");
//						if(i==Documnet_Category_List.size()-1)
//						{check=true;}
//					}
//					else
//					{
//						logger.info("LOV value: "+Documnet_Category_List.get(i)+ " does not matches");
//
//					} 
//					if(i==Documnet_Category_List.size()-1){
//						if(check){
//							logger.info("List matches with the available LOV values");
//							break;
//						}
//						else{
//							logger.info("List does not matches with the available LOV values");
//							break;}
//					}	
//				}
//				products.close(); 
//				break;
//			}
//
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

	}
	
	@SuppressWarnings("unchecked")
	public static void Read_DIvalues_from_CSV(String Field, String xpath,String filename) throws Throwable {
//		try { 
//			String csvFilename = csvpath+filename;
//			//			String csvFilename = "C:\\Automation files\\Framework workspace\\RTOB\\BDC_CheckerLOVvalues.csv"; 
//			BufferedReader br = new BufferedReader( new FileReader(csvFilename));
//			CsvReader products = new CsvReader(br);
//			//products.getValues();
//			products.readHeaders();
//			while (products.readRecord())
//			{
//				String productID = products.get(Field);
//				List Document_Category_List=Arrays.asList(productID.split(","));
//
//				Iterator document_category = Document_Category_List.iterator();
//				while(document_category.hasNext()){
//					String doclists=document_category.next().toString().trim().toUpperCase();
//					//logger.info("Value from CSV: " + doclists);
//				}     
//
//				Collections.sort(Document_Category_List);
//				
//				List<String> TargetNames = new ArrayList<String>();
//				ArrayList<String> doclistsort = new ArrayList();
//				WebElement element= BaseProject.driver.findElement(By.xpath(xpath));
//				JavascriptExecutor js = (JavascriptExecutor) driver;
//				js.executeScript("arguments[0].scrollIntoView(true);",element);
//				List<WebElement> DocCat = BaseProject.driver.findElements(By.xpath(xpath));
//				
//				for (WebElement TarName : DocCat) {
//	                if(!TarName.getAttribute("style").contains("none")){
//	                	String TarDocName = TarName.getAttribute("textContent"); 
//	                	System.out.println(TarDocName);
//	                	TargetNames.add(TarDocName);
//	                	 
//	                }
//	            }
//				
//				Boolean check = false;
//				Collections.sort(TargetNames);
//				logger.info("Values added to the list: "+TargetNames);
//				for(int i=0;i<Document_Category_List.size();i++)
//				{
//					for(int j=0;j<TargetNames.size();j++){
//						if(Document_Category_List.get(i).equals(TargetNames.get(j))){
//							logger.info("LOV value: "+Document_Category_List.get(i)+ " value matches");
//							if(i==Document_Category_List.size()-1)
//							{check=true;}
//						}
//						/*else
//						{
//							logger.info("LOV value: "+Documnet_Category_List.get(i)+ " does not matches");
//						} */
//					}
//						if(i==Document_Category_List.size()-1){
//							if(check){
//								logger.info("List matches with the available LOV values");
//								break;
//							}
//							else{
//								logger.info("List does not matches with the available LOV values");
//								break;}
//						}	
//					
//				}
//				products.close(); 
//				break;
//			}
//
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

	}
	
	@SuppressWarnings("unchecked")
	public static void Read_valueattribute(String Field, String xpath,String filename) throws Throwable {
//		try { 
//			String csvFilename = csvpath+filename;
//			//			String csvFilename = "C:\\Automation files\\Framework workspace\\RTOB\\BDC_CheckerLOVvalues.csv"; 
//			BufferedReader br = new BufferedReader( new FileReader(csvFilename));
//			CsvReader products = new CsvReader(br);
//			//products.getValues();
//			products.readHeaders();
//			while (products.readRecord())
//			{
//				String productID = products.get(Field);
//				List Documnet_Category_List=Arrays.asList(productID.split(","));
//
//				Iterator document_category = Documnet_Category_List.iterator();
//				while(document_category.hasNext()){
//					String doclists=document_category.next().toString().trim().toUpperCase();
//					logger.info("Value from CSV: " + doclists);
//				}     
//
//				Collections.sort(Documnet_Category_List);
//				logger.info(Documnet_Category_List);
//				switchFrame();
//
//				ArrayList<String> doclistsort = new ArrayList();
//				WebElement element= BaseProject.driver.findElement(By.xpath(xpath));
//				JavascriptExecutor js = (JavascriptExecutor) driver;
//				js.executeScript("arguments[0].scrollIntoView(true);",element);
//				//WebElement ele = wrap.getElement(BaseProject.driver, Attribute)
//				Select doclist=new Select(element);
//				List<WebElement> doclist_count=doclist.getOptions(); 
//				Boolean check = false;
//				for(WebElement ele:doclist_count)
//				{
//					if(!ele.getText().equalsIgnoreCase("Please Select..."))
//					{
//						doclistsort.add(ele.getAttribute("value")); 
//						logger.info("LOV from APP: " +ele.getAttribute("value"));
//					}
//				}
//				Collections.sort(doclistsort);
//				logger.info("Values added to the list: "+doclistsort);
//				//logger.info(doclistsort);
//				for(int i=0;i<=doclistsort.size();i++)
//				{
//					if(Documnet_Category_List.get(i).equals(doclistsort.get(i))){
//						logger.info("LOV value: "+Documnet_Category_List.get(i)+ " value matches");
//						if(i==Documnet_Category_List.size()-1)
//						{check=true;}
//					}
//					else
//					{
//						logger.info("LOV value: "+Documnet_Category_List.get(i)+ " does not matches");
//
//					} 
//					if(i==Documnet_Category_List.size()-1){
//						if(check){
//							logger.info("List matches with the available LOV values");
//							break;
//						}
//						else{
//							logger.info("List does not matches with the available LOV values");
//							break;}
//					}	
//				}
//				products.close(); 
//				break;
//			}
//
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

	}

	public static String[] Validate_field_using_CSV(String Fieldname,String filename) throws Throwable {

		String[] returnvalueList = null; 
		try { 
			String csvFilename = csvpath+filename;
			//			String csvFilename = "C:\\Automation files\\Framework workspace\\RTOB\\BDC_CheckerFieldVal.csv"; 
			CSVReader csvreader = new CSVReader(new FileReader(csvFilename), ';', '"', 1); 
			List<String[]> allRows = csvreader.readAll(); 
			for(String[] row : allRows){
				logger.info(row);
				String[] Readrowvalue =row[0].split(",");
				//List<String> Readrowvalue = Arrays.asList(Arrays.toString(row).split(",|\\[|\\]"));
				String val = Readrowvalue[0];
				if(val.equalsIgnoreCase(Fieldname))
				{
					returnvalueList = Readrowvalue; 
					//logger.info(returnvalueList); 
					csvreader.close();
					logger.info("Values retrived from CSV file for the field: "+Fieldname);
					break;
				}  
				//				}
			}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.info("File not found issue faced while retriving from CSV file for the field: "+Fieldname);
		} catch (IOException e) {
			e.printStackTrace();
			logger.info("Read issue faced while retriving from CSV file for the field: "+Fieldname);
		} 
		return returnvalueList; 
	}

	public static String isStringPresentinCSV(String Fieldname,String filename) throws Throwable {
        
        String result = Fieldname+" NOT PRESENT";
        try{
               
               String csvFilename = csvpath+filename;
               CSVReader csvreader = new CSVReader(new FileReader(csvFilename),';','"',1);
               List<String[]> allRows = csvreader.readAll();
               for(String[] row : allRows){
                      String[] Readrowvalue =row[0].split(",");
                      String val = Readrowvalue[0];
                      if(val.equalsIgnoreCase(Fieldname))
                      {
                            result = Fieldname+" PRESENT"; 
                            csvreader.close();
                             break;
                      }
                      else
                      {
                    	  result = Fieldname+"NOT PRESENT";
                      }
                      
               }

        }
        catch (FileNotFoundException e) {
               e.printStackTrace();
               logger.info("File not found issue faced while retriving from CSV file for the field: "+Fieldname);
        } catch (IOException e) {
               e.printStackTrace();
               logger.info("Read issue faced while retriving from CSV file for the field: "+Fieldname);
        } 
        
        return result;
        
  }


	public static  void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {

			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last); 
	}



}
