package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;

public class WBValidation {

	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	public static SeleniumService seleniumService;
	public static GenieScenario genieScenario;
			
	static CommonUtils utils = new CommonUtils();
	public static List<String> wbyes = new ArrayList<String>();
	public static List<String> wbno = new ArrayList<String>();
	public static List<String> wblist = new ArrayList<String>();
	
	File file;
	Properties CONFIG;
	private static Logger logger = Logger.getLogger(WBValidation.class);
	public static WebDriver driver = BaseProject.driver;
	public static String[] wbs = { "Product Selection Maker","Basic Data Capture Maker","Blind Data Capture Maker","Full Data Capture Maker",
		"Basic Data Capture Checker","Exception Data Checker","Full Data Capture Checker","Dedupe Reviewer","Signature Verification",
		"RM Referral","CDD Exception","CDD Reviewer","MEDD Reviewer","Sigcap Maker","Sigcap Checker","CUCO Maker",
		"CUCO Checker","Exception Reviewer","EDD Reviewer","Archival","Document Indexing","Fraud Check Checker",
		"Fraud Check Maker","Cheque Initiation","Cheque Clearance","Insta Upload Exceptions","Investment Maker",
		"Investment Checker","TD Interest posting Maker","TD Interest posting Checker","TD Manual posting Maker","TD Manual posting Checker",
		"Communication Checker","ManualCDDReviewer","Investigation","InternalVerificationWB","OperationsReferralWB","FrontlineReferralWB","Employee Banking WB",
		"MasterDataCheckerWB" };

	@And("^connected to security matrix dataset$")
    public static void loadSecurityMatrix() throws IOException,ClassNotFoundException, SQLException {
        DBUtils.convertDBtoMap("securitymatrix");
        logger.info("wbs----------"+wbs.length);
        int col_count=DBUtils.columnCount;
        logger.info("Column Count------"+col_count);
        int row_count=DBUtils.rowCount;
        logger.info("Row Count------"+row_count);
        logger.info("wbs.length------"+wbs.length);
    }
	
	
	public static void readDB(String Column,String Scenarioid) throws IOException
	{
		String Col_Value=DBUtils.readColumnWithRowID(Column, Scenarioid);
		if(Col_Value.equalsIgnoreCase("Yes"))
		{
			wbyes.add(DBUtils.readColumn(Column, Scenarioid));
			logger.info("Column name--------"+DBUtils.readColumn(Column, Scenarioid));
		}
		else
		{
			wbno.add(DBUtils.readColumn(Column, Scenarioid));
		}
	}
	
		public static void read_Values_From_DB(String Scenarioid) throws Throwable {
		
		for(int i=0;i<wbs.length;i++)
		{
			readDB(wbs[i],Scenarioid);
		}
		
	}
		
	@Given("^Read values from workbasket$")
	public static void read_Values_From_Workbasket() throws Throwable {

		wrap.waitForElement(BaseProject.driver, com.getElementProperties(
				"FullDatacaptureMaker", "work_basket_option"), 30, "visible");
		wrap.click(BaseProject.driver, com.getElementProperties(
				"FullDatacaptureMaker", "work_basket_option"));

		try{
		WebElement see_all=wrap.getExactAttribute(BaseProject.driver,com.getElementProperties("DI", "seeall_option"));
		if(see_all.isDisplayed()){		
		wrap.click(BaseProject.driver,com.getElementProperties("DI", "seeall_option"));
		getWorkbasketOption(BaseProject.driver);
		wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "modal_submit_button"));
		}
		}
		catch(Exception e)
		{
            List<WebElement> wbs=BaseProject.driver.findElements(By.xpath("//input[@id='D_pyWorkbasketsInMyWorkGroupPpxResults1colWidthGBR']//..//div/table//tr//span"));
            
            for(WebElement wb:wbs)
            {
                   String wbname=wb.getText();
                   if(!wbname.equals("")){
                	   wblist.add(wbname.trim());
                	   wrap.wait(2000);}
            }
		}
}

	public static boolean compareList(List ls1, List ls2){
		
		Collections.sort(ls1);
		Collections.sort(ls2);
	    
		if(ls1.equals(ls2))
			return true;
		else
			return false;
	    
	}
	
	@Given("^Validate assigned workbasket$")
	public static void validate_Assigned_Workbasket() throws Throwable {
		logger.info("wblist items are " + wblist);
		logger.info("wbyes items are " + wbyes);
		boolean res=compareList(wblist,wbyes);
		
		if(res==true)
		{
			logger.info("Result is " + res);
			logger.info("PASS: Assigned workbaskets are displayed correctly");
		}
		else
		{
			logger.info("Result is " + res);
			logger.info("FAIL: Assigned workbaskets are not displayed correctly");
		}

	}

	@Given("^Validate unassigned workbasket$")
	public static void validate_Unassigned_Workbasket() throws Throwable {
				
		boolean res1=false;
		
		for(int i=0;i<wbno.size();i++)
		{
			if(wblist.contains(wbno.get(i)))
				res1=true;
		}
		
		if (res1==true)
			logger.info("FAIL : UnAssigned workbaskets are displayed");
		else
			logger.info("PASS: UnAssigned workbaskets are not displayed");
	}

	public static void clearList()
	{
		wblist.clear();
		wbyes.clear();
		wbno.clear();
	}
	
	public static void getWorkbasketOption(WebDriver driver)
			throws IOException, InterruptedException {
		// boolean isFound=false;
		/*List<WebElement> workBasketItems = wrap.getExactAttributes(driver,
				com.getElementProperties("DI", "Workbasket_items"));*/
		String pages= wrap.getTextValue(BaseProject.driver, com.getElementProperties("DI", "modal_totalnoofpages"));
		int pageno=Integer.parseInt(pages);
		
		for (int i = 0; i < pageno; i++) {
			wrap.wait(2000);
			List<WebElement> workBasketItems =	wrap.getExactAttributes(driver, com.getElementProperties("DI","Workbasket_items"));
			for (WebElement we : workBasketItems) {
				String wbname = we.getText();
				if (wbname != null) {
					wblist.add(wbname.trim());
					//wrap.captureScreenShot(BaseProject.driver,"SecurityMatrix");
				}
				
			}
			wrap.wait(2000);
			wrap.click(driver,com.getElementProperties("DI", "modal_next_button"));
		}
		
	}

	public static void logout() throws IOException, InterruptedException 
    { 
            boolean visi_logout=false; 
            wrap.switch_to_default_Content(driver); 
            visi_logout = wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).isDisplayed(); 

            if (visi_logout==true) 
            { 
                    //wrap.getElement(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")).click(); 
                    wrap.click(driver, com.getElementProperties("ProductCatalogue","logOut_xpath")); 
                    logger.info("User logged out successfully"); 
                    wrap.wait(3000); 
            //      ProductCatalogue.driver.quit(); 
                    try { 
                            //switch_to_Parent_Window(); 
                    } catch (Throwable e) { 
                                                            e.printStackTrace(); 
                    } 
            } 
            
    }

	
	@Given("^validate workbaskets$")
	public static void validate_Workbaskets() throws Throwable {
		
		int row_count=DBUtils.rowCount;
		
		for(int i=1;i<=row_count;i++)
		{
			String i1=Integer.toString(i);
			String uname=DBUtils.readColumnWithRowID("UserID", i1);
			if(uname!=null){
			wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("UserID", i1),
					com.getElementProperties("ProductCatalogue","home_login_username"));
			wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID(
					"Password", i1),com.getElementProperties("ProductCatalogue","home_login_password"));
			wrap.wait(2000);
			wrap.click(driver, com.getElementProperties("ProductCatalogue",
					"home_login_submit"));
			wrap.wait(2000);
			read_Values_From_Workbasket();
			read_Values_From_DB(i1);
			validate_Assigned_Workbasket();
			validate_Unassigned_Workbasket();
			clearList();
			logout();
			}
		}
	}

}