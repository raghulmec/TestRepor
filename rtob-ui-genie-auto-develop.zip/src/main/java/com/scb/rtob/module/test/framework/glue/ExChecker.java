package com.scb.rtob.module.test.framework.glue;

//import java.awt.List;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument.Config;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;




import com.scb.rtob.module.test.utils.BusinessCommonUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExChecker {
	File file;
	Properties CONFIG ;
	
	static BusinessCommonUtils businessutils= new BusinessCommonUtils();
	public static WebDriver driver=BaseProject.driver;
	private static Logger logger = Logger.getLogger(ExChecker.class);
	public static List<HashMap<String, String>> exceldata = new ArrayList<HashMap<String, String>>();
	public static LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();
	// public static List<HashMap<String, String>> mydata = new
	// ArrayList<HashMap<String, String>>();

	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	
	public ExChecker() throws URISyntaxException
	{
		
		
		
		  String envName = System.getProperty("env");
	        URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
//		 file = new File(System.getProperty("user.dir")+"\\src\\main\\java\\com\\standardchartered\\techm\\rtob\\config\\config.properties");
		FileInputStream fis = null;
		try {
			file = new File(resource.toURI());
            fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		 CONFIG = new Properties();
		try {
			CONFIG.load(fis);
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}

	/*@Given("^openURL$")
	public void openURL() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Genie_Workspace\\com.scb.awfSITR1\\drivers\\chrome\\2.8\\chromedriver.exe");
		driver = new ChromeDriver();
		String URL = "https://10.20.234.172:8080/prweb/";
//		System.out.println(URL);
		driver.get(URL);
		//		Thread.sleep(5000);
		driver.manage().window().maximize();

	}*/

/*	@Given("^enter valid credentials '(.*)'$")
	public void enter_valid_credentails(String UserId) throws Throwable {
		wrap.type(driver, UserId, com.getElementProperties("ExceptionChecker", "home_login_username"));
		wrap.type(driver, "rules",
				com.getElementProperties("ExceptionChecker", "home_login_password"));
		Thread.sleep(5000);
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "home_login_submit"));
		Thread.sleep(5000);
	}

	@Given("^Launch the App Workflow User portal$")
	public void launch_the_App_Workflow_User_portal() throws Throwable {
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "appflow_launch"));
		Thread.sleep(2000);
		wrap.click(driver, com.getElementProperties("ExceptionChecker",
				"appflow_appWorkflow_portal"));
		Thread.sleep(5000);
	}

	
*/
	
	@Given("^find and open ApplicationID '(.*)'$")
	public void userIsInAppworkflowUserPortal(String ApplicationID) throws Throwable {

		try {

			switchFrame();
			//wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
//			System.out.println("switched");
			wrap.select_application_number(driver, BaseProject.appId);
//			System.out.println("App Id filtered");

			wrap.switch_to_default_Content(driver);

		} catch (Exception E) {

		}

		// wrap.type(driver, "IN20170317000050",
		// com.getElementProperties("ExceptionChecker", "ApplicationId_SearchText"));
		// wrap.click(driver, com.getElementProperties("ExceptionChecker", "Apply"));
		// wrap.click(driver, com.getElementProperties("ExceptionChecker",
		// "AppworkflowID_Click "));
	}

	@Then("^user should validate all the fields are in read only format for primary applicant$")
	public void userShouldValidateFieldsReadonlyForPrimaryApplicant()
			throws Throwable {
					IterateviaWebTable();
					driver.quit();
					
	}

	@Then("^user should validate all the fields are in read only format for primary applicant and CoApplicant$")
	public void userShouldValidateFieldsReadonlForPrimaryWithCoApplicant()
			throws Throwable {
		try {
			IterateviaWebTable();
			WebElement co_Applicanttab = (new WebDriverWait(driver, 600))
					  .until(ExpectedConditions.presenceOfElementLocated(By.xpath(com.getElementProperties("ExceptionChecker", "Co-applicanttab"))));
			
			Boolean co_applicationstatus = co_Applicanttab.isEnabled();

			// Validation for Co-applicant details

			if (co_applicationstatus) {

				co_Applicanttab.click();
				Thread.sleep(3000);
				WebElement co_customer_personal_detail_expander = wrap
						.getElement(driver, com.getElementProperties(
								"ExceptionChecker",
								"co_Customer_Personal_detail_expander"));

				String co_status = co_customer_personal_detail_expander
						.getAttribute("aria-expanded");

				Boolean co_CPDEnabled = Boolean.valueOf(co_status);
				
				if (!co_CPDEnabled) {
					co_customer_personal_detail_expander.click();

				}
				
				System.out.println("Co-Applicant Fields....");
				coCustomerpersonaldetails();
				coAddCustomerpersonaldetails();
				co_Contactdetails();
				coEmploymentDetails();				
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			wrap.screenShot(driver,CONFIG.getProperty("ScreenshotLocation"), "Joint_Applicant_Customer_Fields");
		}

		

		//wrap.browserquit();
	}	
	


	@Given("^read excel$")
	public void excel() throws IOException{
		convertExcelToMap("Sheet1","");
		readColumn("First name", 0);
	}
	
	
	@Then ("^user should validate values not corrected by the checker is not displayed$")
	public void userShouldValidateValuesNotCorrectedByCheckerIsNotDisplayed() throws Throwable {
		
		CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");
		try {

			convertExcelwithExceptionCheckerTable();
			convertExcelToMap(com.getElementProperties("ExceptionChecker", "Matched_Record_SheetName"), com.getElementProperties("ExceptionChecker", "Non_Matched_Record_File"));
			
			HashMap<String, String> map1 = exceldata.get(0);
			if (map1.size()==tabledata.entrySet().size())
			{
				System.out.println("Total count is " + map1.size());
				for (Entry<String, String> entry : map1.entrySet()) {
					for (Entry<String, String> entry1 : tabledata.entrySet()) {
						
					if (entry.getKey().equalsIgnoreCase(entry1.getKey())) {
											
							System.out.println(entry.getKey() + " in Excel is not matched with the Exception Checker Webtable "+entry1.getKey());
							
						}
					
					}
					System.out.println("Excel and Webtable fields are differs.");
				}
			}
			else
			{
				System.out.println("No of Columns in Excel is not matches with Exception checker Webtable");
			}
			
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		//wrap.browserquit();
	}
	
	@Then("^user should validate only the values corrected by the checker$")
	public void userShouldValidateOnlyValuesCorrectedByChecker()
			throws Throwable {
		CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");
		try {

			convertExcelwithExceptionCheckerTable();
			convertExcelToMap(com.getElementProperties("ExceptionChecker", "Matched_Record_SheetName"),com.getElementProperties("ExceptionChecker", "Matched_Record_File"));
			
			HashMap<String, String> map1 = exceldata.get(0);
			
			
			for (Entry<String, String> entry : map1.entrySet()) {
				for (Entry<String, String> entry1 : tabledata.entrySet()) {
				if (entry.getKey().equalsIgnoreCase(entry1.getKey())) {
					if (entry.getValue().equalsIgnoreCase(entry1.getValue())) {
					
						System.out.println(entry.getKey() + " in Excel = "+ entry.getValue()+" is matched with the Exception Checker Webtable "+entry1.getKey()+"="+entry1.getValue());
						System.out.println();
						}
					}
				}
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		//wrap.browserquit();
	}
	
	@Then ("^Reject the application$")
    public void performActionReturnToMaker() throws Throwable {
    	CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");
        // Write code here that turns the phrase above into concrete actions
              wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
       String Exception_Checker_Dropdown_XPATH=com.getElementProperties("ExceptionChecker", "Exception_Checker_Dropdown_XPATH");
       String Submit=com.getElementProperties("ExceptionChecker","page_submit");
        wrap.selectFromDropDown(BaseProject.driver,Exception_Checker_Dropdown_XPATH,"Reject","BYVISIBLETEXT");
        //wrap.click(driver, com.getElementProperties("Checker", "Submit"));
        wrap.wait(4000);
        wrap.click(BaseProject.driver, Submit);
              wrap.wait(3000);
    }


	////
	/**
	 * @throws Throwable,test
	 */
//	@Then("^user should validate only$")
//	public void user_should_validate_only()
//			throws Throwable {
//
//		try {
//
//			//convertExcelwithExceptionCheckerTable();
//			convertExcelToMap(com.getElementProperties("ExceptionChecker", "Matched_Record_File"),com.getElementProperties("ExceptionChecker", "Matched_Record_SheetName"));
//
//			boolean result = new HashSet<>(exceldata).equals(new HashSet<>(tabledata));
//			int i=0;
//			for(LinkedHashMap<String, String> map:exceldata){//each map in the list
//				for(String key:exceldata.get(i).keySet()){//each key in one map
//					if(exceldata.get(i).get(key).equalsIgnoreCase(tabledata.get(i).get(key))){
//						System.out.println(exceldata.get(i).get(key)+"="+"True");
//					}
//					else{
//						System.out.println(exceldata.get(i).get(key)+"="+"False");
//					}
//				}
//				
//				i++;
//			}
//			
//			
//			System.out.println(result);
//		}
//
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}


	@Then("^verify return to maker option in the action dropdown$")
	public void verify_return_to_maker_option_in_the_action_dropdown()
			throws Throwable {

	}

	

	@Then("^user should verify the mandatory fields which have no changes in Basic data module$")
	public void user_should_verify_the_mandatory_fields_which_have_no_changes_in_basic_data_module()
			throws Throwable {

	}

	@Then("^user should able to save the application$")
	public void user_should_able_to_save_the_application() throws Throwable {

	}

	@And("^user should able to retrive the application in order to work$")
	public void user_should_able_to_retrive_the_application_in_order_to_work()
			throws Throwable {

	}

	public void convertExcelToMap1(String FileName, String sheetName) throws IOException {
		exceldata.clear();
		String path = com.getElementProperties("ExceptionChecker", "Matched_Record_File");
		FileInputStream fin = new FileInputStream(path);
		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		/*for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				Cell currentCell = currentRow.getCell(j);
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					System.out.print(currentCell.getStringCellValue() + "|");
					break;
				case Cell.CELL_TYPE_NUMERIC:
					System.out.print(currentCell.getNumericCellValue() + "|");
					break;
				}
			}
			System.out.println("\n");
		}
		// List<HashMap<String, String>> mydata = new ArrayList<HashMap<String,
		// String>>();*/
		
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
			Row currentRow = sheet.getRow(i);
			
			for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
				
				Cell currentCell = currentRow.getCell(j);
				LinkedHashMap<String, String> currentHash = new LinkedHashMap<String, String>();			
				switch (currentCell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(),
							currentCell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_NUMERIC:
					currentHash.put(HeaderRow.getCell(j).getStringCellValue(), 
							NumberToTextConverter.toText(currentCell.getNumericCellValue()));
					//String.valueOf(currentCell.getNumericCellValue()));
					break;
				}
				exceldata.add(currentHash);
			}


		}
		System.out.println("exceldata: "+exceldata);

	}
	
	public void convertExcelToMap(String sheetName, String FilePath) throws IOException{
		exceldata.clear();
//		String path = com.getElementProperties("ExceptionChecker", "Matched_Record_File");
		FileInputStream fin = new FileInputStream(FilePath);
		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		/*for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
		{
		    Row currentRow = sheet.getRow(i);
		    for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		    {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType())
		        {
		            case Cell.CELL_TYPE_STRING:
//		                System.out.print(currentCell.getStringCellValue() + "|");
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
//		                System.out.print(currentCell.getNumericCellValue() + "|");
		                break;
		        }
		    }
		    System.out.println("\n");
		}*/
//		List<HashMap<String, String>> mydata = new ArrayList<HashMap<String, String>>();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
		    Row currentRow = sheet.getRow(i);
		    HashMap<String, String> currentHash = new HashMap<String, String>();
		    for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType()) {
		            case Cell.CELL_TYPE_STRING:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue()));
		                break;
		        }
		    }
//	        System.out.println(currentHash.get("username"));
		    exceldata.add(currentHash);
		    		}
		book.close();
	System.out.println(exceldata);
//		System.out.println(exceldata.get(0));
	}

	public static  void switchFrame() throws InterruptedException{
		int Last=0;
		driver.switchTo().defaultContent();

		List<WebElement> frames=driver.findElements(By.tagName("iframe"));
		for(WebElement frame: frames){
//			System.out.println(frame.getAttribute("Name"));
		}
		Last=frames.size()-1;
		driver.switchTo().frame(Last);
	}

	public String readColumn(String column, int row) {
		HashMap<String, String> map = exceldata.get(row);
		String result = null;
		for (Entry<String, String> entry : map.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(column)) {
				System.out.println(entry.getValue());
				result = entry.getValue();
			}

		}
		return result;
	}

	public void IterateviaWebTable() throws IOException, InterruptedException {
		try {
			switchFrame();

			Thread.sleep(2000);
//			System.out.println("switched to inner frame");
			// Verify fields are disabled in Table.			CommonUtils.convertExcelToMap(BaseProject.excelPath,"ExCheckerUATMapping.xls","Sheet1");

//			readexcel();
			try {
				WebElement clickCustomerDetailsTab = (new WebDriverWait(driver, 360))
						  .until(ExpectedConditions.presenceOfElementLocated(By.xpath(com.getElementProperties("ExceptionChecker", "Customerdetailstab"))));
				clickCustomerDetailsTab.click();

				WebElement customer_personal_detail_expander = wrap.getElement(
						driver, com.getElementProperties("ExceptionChecker",
								"Customer_Personal_detail_expander"));

				String status = customer_personal_detail_expander
						.getAttribute("aria-expanded");

				Boolean CPDEnabled = Boolean.valueOf(status);

				if (!CPDEnabled) {
					customer_personal_detail_expander.click();

				}

				System.out.println("Primary Applicant Fields....");

				Customerpersonaldetails();
				AdditionalCustomerpersonaldetails();
				Contactdetails();
				Employmentdetails();



			} catch (NoSuchElementException e) {

				e.printStackTrace();
			}
		} catch (NoSuchFrameException e1) {

			e1.printStackTrace();
		}		
		finally {
			//wrap.screenShot(driver,CONFIG.getProperty("ScreenshotLocation") , "Primary_Applicant_Customer_Fields");
		}
	}

	public void convertExcelwithExceptionCheckerTable() throws InterruptedException, IOException
	{
		tabledata.clear();

		switchFrame();
		Thread.sleep(3000);
		System.out.println("switched to  frame");

		// Clicking the Customer Details Tab
		wrap.getElement(
				driver,
				com.getElementProperties("ExceptionChecker",
						"Customerdetailstab")).click();

		// Expanding the Customer details tab even it is collapsed.

		WebElement customer_personal_detail_expander = wrap.getElement(
				driver, com.getElementProperties("ExceptionChecker",
						"Customer_Personal_detail_expander"));

		String status = customer_personal_detail_expander
				.getAttribute("aria-expanded");

		Boolean CPDEnabled = Boolean.valueOf(status);

		if (!CPDEnabled) {
			customer_personal_detail_expander.click();

		}

		//			Reading the Customer details tab checker values.

		List<WebElement> customer_personal_detail_rows = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "Customer_Personal_detail_TotalRows"));
		List<WebElement> no_items_to_display_in_cpd = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "No_of_cols_in_cpd"));
		for (int i = 2; i <= customer_personal_detail_rows.size(); i++) {
			String Field=null, cpd_checker=null;

			//				If No records is found no record will be displayed.
			if(no_items_to_display_in_cpd.size()==1)
			{
				break;	
			}	
			//				Pushing the values in to Map and List.

//			LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();

			Field = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "Iterative_Identify_field_in_cpd")).getText();

			//		Read value if the field contains date picker.
			if(Field.equalsIgnoreCase("Date of birth")||Field.contains("Expiry"))
			{

				cpd_checker = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "Iterateive_cpd_checker_date")).getAttribute("value");

			}
			//				Read value if the field contains Dropdown.
			else if (Field.equalsIgnoreCase("Title"))
			{

				cpd_checker = new Select(wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "Iterateive_cpd_checker_dropdown"))).getFirstSelectedOption().getText();
			}
			//				Read value from text field.
			else{

				cpd_checker = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "Iterateive_cpd_checker")).getAttribute("value");
			}
			tabledata.put(Field, cpd_checker);

			//tabledata.add(tabledata);

		}

		//			Reading the Additonal Customer details tab checker values.

		List<WebElement> Additional_customer_personal_detail_rows = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "Customer_Persoanl_detail_Alias_TotalRows"));
		List<WebElement> no_items_additonal_cpd = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "no_items_additonal_cpd"));
		for (int j = 2; j <= Additional_customer_personal_detail_rows.size(); j++) {
			String Field=null, acpd_checker=null;
			if(no_items_additonal_cpd.size()==1)
			{
				break;	
			}	
//			LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();

			Field = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_additional_cpd")+j+com.getElementProperties("ExceptionChecker", "iterative_field_in_additonal_cpd")).getText();
			acpd_checker = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_additional_cpd")+j+com.getElementProperties("ExceptionChecker", "Iterative_apcd_checker")).getAttribute("value");
			tabledata.put(Field, acpd_checker);
			//tabledata.add(tabledata);

		}

		//				Reading the Contact detail values.			
		List<WebElement> contact_detail_rows = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "Contact_TotalRows"));
		List<WebElement> no_items_in_contact = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "no_items_contact"));
		for (int i = 2; i <= contact_detail_rows.size(); i++) {
			String Field=null, contact_checker=null;
			if(no_items_in_contact.size()==1)
			{
				break;	
			}	

			for(int j=1;j<=2;j++){
//				LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();
				Field = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_contact")+i+com.getElementProperties("ExceptionChecker", "iterative_filed_in_contact")+j+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact")).getText();
				if (Field.equalsIgnoreCase("Country/ISD Code"))
				{

					contact_checker = new Select(wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Contact_checker"))).getFirstSelectedOption().getText();
				}
				else{
					contact_checker = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_contact")+i+com.getElementProperties("ExceptionChecker", "Iterative_contact_checker")).getAttribute("value");
				}

				tabledata.put(Field, contact_checker);


				//tabledata.add(tabledata);

			}
		}		
		//				Reading the Employment detail values.
		List<WebElement> Employment_detail_rows = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "Employment_Totalrows"));

		List<WebElement> no_items_in_employment = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "no_items_employment"));

		for (int j = 2; j <= Employment_detail_rows.size(); j++) {
			String Field=null, emp_checker=null;
			if(no_items_in_employment.size()==1)
			{
				break;	
			}	

//			LinkedHashMap<String, String> tabledata = new LinkedHashMap<String, String>();

			Field = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_employment")+j+com.getElementProperties("ExceptionChecker", "Iterative_field_in_employment")).getText();

			emp_checker = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_employment")+j+com.getElementProperties("ExceptionChecker", "Iterative_checker")).getAttribute("value");
			tabledata.put(Field, emp_checker);


			//tabledata.add(tabledata);
		}
		System.out.println(tabledata);
	}

	public void Customerpersonaldetails() throws IOException
	{
		List<WebElement> customer_personal_detail_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Customer_Personal_detail_TotalRows"));
		for (int i = 2; i <= customer_personal_detail_rows.size(); i++) {
			
			List<WebElement> No_of_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));	
			int cpdcolsize = No_of_columns.size();
			if (cpdcolsize == 1) {
				System.out
				.println("No items in Customer Personal Alias Table");
			}
			for (int j = 2; j <= No_of_columns.size(); j++) {

				WebElement tabledata_attributes = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement cpd_checkboxes = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_cpd")+i+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+j+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
				WebElement tableheader = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "cpd_tableheader")+j+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				Boolean EnableData = cpd_checkboxes.isEnabled();

				if (EnableData) {
					System.out.println(tabledata_attributes.getText()
							+ " in " + tableheader.getText()
							+ " is Enabled");
				}

				else {
					System.out.println(tabledata_attributes.getText()
							+ " in " + tableheader.getText()
							+ " is Disabled");
				}
				System.out.println();
			}

		}
	}
	public void AdditionalCustomerpersonaldetails() throws IOException
	{
		List<WebElement> additional_customer_personal_detail_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Customer_Persoanl_detail_Alias_TotalRows"));
		for (int e = 2; e <= additional_customer_personal_detail_rows
				.size(); e++) {

			List<WebElement> No_of_cols = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_additional_cpd")+e+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			int contactrowsize = No_of_cols.size();
			if (contactrowsize == 1) {
				System.out
				.println("No items in Customer Personal Alias Table");
			}

			for (int f = 2; f <= contactrowsize; f++) {
				WebElement additonaldata_attributes = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_additional_cpd")+e+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement additonaldata_checkboxes = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_additional_cpd")+e+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+f+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
				WebElement cpdtableheader = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "acpd_tableheader")+f+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				Boolean value = additonaldata_checkboxes.isEnabled();

				if (value) {
					System.out.println(additonaldata_attributes
							.getText()
							+ " in "
							+ cpdtableheader.getText() + " is Enabled");
				}

				else {
					System.out
					.println(additonaldata_attributes.getText()
							+ " in " + cpdtableheader.getText()
							+ " is Disabled");
				}
				System.out.println();
			}

		}
	}
	public void Contactdetails() throws IOException
	{
		
		try{
		WebElement contact_expander = wrap.getElement(driver, com
				.getElementProperties("ExceptionChecker", "contaact_expander"));
		String contactstatus = contact_expander
				.getAttribute("aria-expanded");
		Boolean contactEnabled = Boolean.valueOf(contactstatus);

		if (!contactEnabled) {
			contact_expander.click();
		}

		List<WebElement> contact_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Contact_TotalRows"));
		for (int c = 2; c <= contact_rows.size(); c++) {
			List<WebElement> No_of_contact_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_contact")+c+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			if (No_of_contact_columns.size() == 1) {
				System.out.println("No items in Contact Table");
			}
			for (int d = 2; d <= No_of_contact_columns.size(); d++) {

				WebElement contact = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_contact")+c+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement contacttableheader = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "contact_tableheader")+d+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));

				if (d == No_of_contact_columns.size()) {
									WebElement contactdata1 = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "contact_tablerow"));
					Boolean contactdisabledata = contactdata1
							.isEnabled();
					if (contactdisabledata) {
						System.out.println(contact.getText() + " in "
								+ contacttableheader.getText()
								+ " is Enabled");
					}

					else {
						System.out.println(contact.getText() + " in "
								+ contacttableheader.getText()
								+ " is Disabled");

					}
					System.out.println();
					break;
				} else if (d < No_of_contact_columns.size()) {

					WebElement contactdata = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_contact")+c+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+d+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
					Boolean contactenabledata = contactdata.isEnabled();
					if (contactenabledata) {
						System.out.println(contact.getText() + " in "
								+ contacttableheader.getText()
								+ " is Enabled");
					}

					else {
						System.out.println(contact.getText() + " in "
								+ contacttableheader.getText()
								+ " is Disabled");

					}
					System.out.println();
				}
			}

		}}
		catch(Exception e)
		{
		}
		
	}
	public void Employmentdetails() throws IOException
	{
		
		List<WebElement>employment_expander = wrap
				.getElements(driver, com.getElementProperties("ExceptionChecker",
						"employment_expander"));
		if (employment_expander .size() == 0) {
			System.out.println("No items in Employment Table");
		}
		
		else{
			WebElement employment_expander1 = wrap.getElement(driver, com.getElementProperties("ExceptionChecker","employment_expander"));
			String employmentstatus = employment_expander1
					.getAttribute("aria-expanded");
			Boolean employmentEnabled = Boolean.valueOf(employmentstatus);

			if (!employmentEnabled) {
				employment_expander1.click();
			}

			List<WebElement> employment_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Employment_Totalrows"));
			for (int x = 2; x <= employment_rows.size(); x++) {
				List<WebElement> No_of_employment_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_employment")+x+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
				if (No_of_employment_columns.size() == 1) {
					System.out.println("No items in Employment Table");
				}
				for (int y = 2; y <= No_of_employment_columns.size(); y++) {
					
					WebElement employment = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_employment")+x+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
					WebElement employmentdata = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "Identify_field_in_employment")+x+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+y+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
					WebElement employmenttableheader = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "employment_tableheader")+y+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
					Boolean contactenabledata = employmentdata.isEnabled();

					if (contactenabledata) {
						System.out.println(employment.getText() + " in "
								+ employmenttableheader.getText()
								+ " is Enabled");
					}

					else {
						System.out.println(employment.getText() + " in "
								+ employmenttableheader.getText()
								+ " is Disabled");

					}
					System.out.println();
				}
			}
		}  

	}
	public void coCustomerpersonaldetails() throws IOException{
		List<WebElement> co_customer_personal_detail_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_customer_personal_detail_rows"));
		for (int i = 2; i <= co_customer_personal_detail_rows
				.size(); i++) {
			List<WebElement> co_No_of_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_customer_personal_detail_cols")+i+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			int co_cpdcolsize = co_No_of_columns.size();
			if (co_cpdcolsize == 1) {
				System.out
				.println("No items in Customer Personal Table");
			}
			for (int j = 2; j <= co_No_of_columns.size(); j++) {

				WebElement co_tabledata_attributes = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_customer_personal_detail_cols")+i+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement co_cpd_checkboxes = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_customer_personal_detail_cols")+i+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+j+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
				WebElement co_tableheader = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_cpd_tableheader")+j+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				
				Boolean co_EnableData = co_cpd_checkboxes
						.isEnabled();

				if (co_EnableData) {
					System.out.println(co_tabledata_attributes
							.getText()
							+ " in "
							+ co_tableheader.getText()
							+ " is Enabled");
				}

				else {
					System.out.println(co_tabledata_attributes
							.getText()
							+ " in "
							+ co_tableheader.getText()
							+ " is Disabled");
				}
				System.out.println();
			}

		}
	}

	public void coAddCustomerpersonaldetails() throws IOException{
		List<WebElement> co_additional_customer_personal_detail_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_add_customer_personal_detail_rows"));
		for (int e = 2; e <= co_additional_customer_personal_detail_rows
				.size(); e++) {
			List<WebElement> co_No_of_cols = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_add_customer_personal_detail_cols")+e+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			int co_contactrowsize = co_No_of_cols.size();
			if (co_contactrowsize == 1) {
				System.out
				.println("No items in Customer Personal Alias Table");
			}

			for (int f = 2; f <= co_contactrowsize; f++) {
				
				WebElement co_additonaldata_attributes = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_add_customer_personal_detail_cols")+e+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement co_additonaldata_checkboxes = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_add_customer_personal_detail_cols")+e+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+f+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
				WebElement co_cpdtableheader = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_add_cpd_tableheader")+f+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				
				Boolean co_value = co_additonaldata_checkboxes
						.isEnabled();

				if (co_value) {
					System.out.println(co_additonaldata_attributes
							.getText()
							+ " in "
							+ co_cpdtableheader.getText()
							+ " is Enabled");
				}

				else {
					System.out.println(co_additonaldata_attributes
							.getText()
							+ " in "
							+ co_cpdtableheader.getText()
							+ " is Disabled");
				}
				System.out.println();
			}

		}
	}
	public void co_Contactdetails() throws IOException{
		WebElement co_contact_expander = wrap.getElement(driver,
				com.getElementProperties("ExceptionChecker",
						"co_contaact_expander"));
		String co_contactstatus = co_contact_expander
				.getAttribute("aria-expanded");
		Boolean co_contactEnabled = Boolean
				.valueOf(co_contactstatus);
		System.out.println(co_contactEnabled
				+ "Contact collapse/expand button");
		if (!co_contactEnabled) {

			co_contact_expander.click();
			System.out.println("Contact is enabled");
		}
		List<WebElement> co_contact_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Co_Contact_TotalRows"));
		for (int c = 2; c <= co_contact_rows.size(); c++) {
			List<WebElement> co_No_of_contact_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_add_contact_detail_cols")+c+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			if (co_No_of_contact_columns.size() == 1) {
				System.out.println("No items in Contact Table");
			}
			for (int d = 2; d <= co_No_of_contact_columns.size(); d++) {

				WebElement co_contact = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "co_add_contact_detail_cols")+c+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement co_contacttableheader = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "co_contact_tableheader")+d+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				if (d == co_No_of_contact_columns.size()) {
					WebElement co_contactdata1 = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "contactdata1"));
					Boolean co_contactdisabledata = co_contactdata1
							.isEnabled();
					if (co_contactdisabledata) {
						System.out.println(co_contact.getText()
								+ " in "
								+ co_contacttableheader.getText()
								+ " is Enabled");
					}

					else {
						System.out.println(co_contact.getText()
								+ " in "
								+ co_contacttableheader.getText()
								+ " is Disabled");

					}
					System.out.println();
					break;
				} else if (d < co_No_of_contact_columns.size()) {
					WebElement co_contactdata = wrap.getExactAttribute(driver, com.getElementProperties("ExceptionChecker", "co_add_contact_detail_cols")+c+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+d+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
					Boolean co_contactenabledata = co_contactdata
							.isEnabled();
					if (co_contactenabledata) {
						System.out.println(co_contact.getText()
								+ " in "
								+ co_contacttableheader.getText()
								+ " is Enabled");
					}

					else {
						System.out.println(co_contact.getText()
								+ " in "
								+ co_contacttableheader.getText()
								+ " is Disabled");

					}
					System.out.println();
				}
			}

		}
}
	public void coEmploymentDetails() throws IOException{
		WebElement co_employment_expander = wrap.getElement(driver,
				com.getElementProperties("ExceptionChecker",
						"co_employment_expander"));
		
		String co_employmentstatus = co_employment_expander
				.getAttribute("aria-expanded");
		Boolean co_employmentEnabled = Boolean
				.valueOf(co_employmentstatus);

		if (!co_employmentEnabled) {
			co_employment_expander.click();
		}

		List<WebElement> co_employment_rows = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "Co_Employment_TotalRows"));
		for (int x1 = 2; x1 <= co_employment_rows.size(); x1++) {
			List<WebElement> co_No_of_employment_columns = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "co_emp_detail_cols")+x1+com.getElementProperties("ExceptionChecker", "iteratecustomertablerows_last"));
			if (co_No_of_employment_columns.size() == 1) {
				System.out.println("No items in Employment Table");
			}
			for (int y1 = 2; y1 <= co_No_of_employment_columns
					.size(); y1++) {
				WebElement co_employment = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_emp_detail_cols")+x1+com.getElementProperties("ExceptionChecker", "iteratecustomertablecols_last"));
				WebElement co_employmentdata = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_emp_detail_cols")+x1+com.getElementProperties("ExceptionChecker", "cpd_checkboxes")+y1+com.getElementProperties("ExceptionChecker", "iterative_cpd_checkboxes"));
				WebElement co_employmenttableheader = wrap.getElement(driver, com.getElementProperties("ExceptionChecker", "co_emp_tableheader")+y1+com.getElementProperties("ExceptionChecker", "another_iterative_filed_in_contact"));
				Boolean co_employmentenabledata = co_employmentdata
						.isEnabled();

				if (co_employmentenabledata) {
					System.out.println(co_employment.getText()
							+ " in "
							+ co_employmenttableheader.getText()
							+ " is Enabled");
				}

				else {
					System.out.println(co_employment.getText()
							+ " in "
							+ co_employmenttableheader.getText()
							+ " is Disabled");

				}
				System.out.println();

			}

		}
}
	
//	public static void CompareList(List<LinkedHashMap<String,String>> listOfMap1,List<LinkedHashMap<String,String>> listOfMap2) throws IOException{
//
//		//Map<String,String> diffValuesMap = new HashMap<String,String>();
//		List<String> tempList= new <String>ArrayList();
//		String difVal;
//		HashSet<String> diffHeaderhset = new HashSet<String>();
//		List<String> diffHeaderList;
//		List<String> diffValue= new <String>ArrayList();
//		for(int i=0;i<listOfMap1.size();i++){
//			Map<String,String> diffValuesMap = new HashMap<String,String>();//save the differences as map between 2 baskets and saves
//
//			HashMap<String,String> sheet1= listOfMap1.get(i);//returns the map in list1
//			HashMap<String,String> sheet2=listOfMap2.get(i);//returns the map in list2
//			String id=sheet1.get("ID");
//			//System.out.println(id);
//			//difVal;
//			for(Entry<String, String> record:sheet1.entrySet()){
//				String key=record.getKey();//sheet1 key
//				String value=record.getValue();//sheet2 value
//				diffHeaderhset.add(key);//headeras are added in an hashset for the checker sheet column headers
//				if(!sheet1.get(key).equalsIgnoreCase(sheet2.get(key))){
//					difVal=sheet1.get(key)+"|"+sheet2.get(key);
//					diffValuesMap.put(key, difVal);//the difference is stored a map each row diff is a map
//
//				}
//				else{
//					difVal=key+"Nil,";
//					diffValuesMap.put(key, "Nil");
//				}
//
//			}
//
//			addInMapOfMaps(id,diffValuesMap);
//
//		}
//
//		putCheckerDataInCsv(checkerValues);//this contains the entire difference as hashmap
//	}
	@Then("^user release the application$")
	public void userReleaseTheApplication() throws Throwable {
		
		wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
		WebElement Release = (new WebDriverWait(driver, 20))
				  .until(ExpectedConditions.presenceOfElementLocated(By.xpath(com.getElementProperties("ExceptionChecker", "Release"))));

		int i = 50,j=150;
		
				JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("javascript:window.scrollBy("+j+","+i+")");
      wrap.wait(2000);
      j+=i;
      Release.click();
      System.out.println(Release);
            
      driver.quit();
	}
//      
//            {
//                  JavascriptExecutor js1 = (JavascriptExecutor) driver;
//             js1.executeScript("javascript:window.scrollBy(350,100)"); 
//            
//            }
//             
//                  {
//            	 Release.click();
//                  logger.info(Release.getAttribute("checked"));
//                  }
//             
//            }
//		
		


	@Then ("^user release the application and logout$")
	public void userReleaseTheApplicationAndLogout() throws Throwable {
		
		WebElement Release = (new WebDriverWait(driver, 10))
				  .until(ExpectedConditions.presenceOfElementLocated(By.xpath(com.getElementProperties("ExceptionChecker", "Release"))));
		boolean visi_release = Release.isDisplayed();
		if(visi_release==true)
		{
			Release.click();
		}
		
//		driver.findElement(By.xpath("(//span/button)[9]")).click();
		
		Thread.sleep(3000);
//		System.out.println("The Release button is clicked successfully");
//		wrap.wait(2000);
		
//		driver.findElement(By.xpath("//span[text()='Confirm close']//preceding::table//following-sibling::div//div[text()='Discard']")).click();
//		wrap.wait(2000);
//		System.out.println("The discard button is clicked successfully");
		
		wrap.switch_to_default_Content(driver);
//		System.out.println("Frame switched to default content");
//		wrap.wait(2000);
		
		/*wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
		System.out.println("Frame switched to PegaGadget0Ifr");*/
		WebElement LogOut = (new WebDriverWait(driver, 10))
				  .until(ExpectedConditions.presenceOfElementLocated(By.xpath(com.getElementProperties("ExceptionChecker", "Logout"))));
		
		boolean visi_logout = LogOut.isDisplayed();
		if (visi_logout==true)
			LogOut.click();
//		System.out.println("User logged out successfully");
		
		driver.quit();
//		System.out.println("Closing the browser instance successfully");
	}



//Siva-----------------------------------------------------------------------------

	/*@Given("^Go_to_ExceptionChecker$")
    public void Go_to_ExceptionChecker() throws Throwable {
          
	   Thread.sleep(5000);
           wrap.click(driver, com.getElementProperties("ExceptionChecker", "work_basket_option"));
          Thread.sleep(2000);
           
          wrap.click(driver, com.getElementProperties("ExceptionChecker", "modal_wb_Exceptionchecker"));
          wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "seeall_option"));
           Thread.sleep(1000);
          List<WebElement> list = wrap.getExactAttributes(driver, com.getElementProperties("FullDataCaptureMaker", "workbasket_AllModules")); 

           Iterator<WebElement> itr = list.iterator();
           while(itr.hasNext()){
                  WebElement workbasket = itr.next();

                  try{
                        if(workbasket.getText().equalsIgnoreCase(workbasketModule)){
                               workbasket.click();
                        }
                  }catch(ElementNotVisibleException e){
                        wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_next_button"));
                        Thread.sleep(1000);

                        if(workbasket.getText().equalsIgnoreCase(workbasketModule)){
                               workbasket.click();
                        }
                  }
           }

      //     wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_next_button"));
           Thread.sleep(1000);
         //  wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_wb_Exceptionchecker"));
          
           wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_submit_button"));
           //Thread.sleep(5000);      

    }*/


 /*@Then ("^PerformAction '(.*)'$")
    public void performaction_Return_to_Maker(String Data) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
        wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
        wrap.selectFromDropDown(driver,com.getElementProperties("ExceptionChecker", "action_drp"),Data,"BYVISIBLETEXT");
        wrap.click(driver, com.getElementProperties("ExceptionChecker", "page_submit"));
   	 Thread.sleep(5000);
    }*/

/*@Then ("^Click submit$")
    public void click_submit() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
    	wrap.type(driver, "Remarks", com.getElementProperties("ExceptionChecker", "Remarks"));
    	 wrap.click(driver, com.getElementProperties("ExceptionChecker", "page_submit"));
       	 Thread.sleep(3000);
    	
    }*/


/*@Given("^Go to Datacapture Review$")
   public void go_to_Datacapture_Review() throws Throwable {
	   Thread.sleep(1000);
       // Write code here that turns the phrase above into concrete actions
	   wrap.click(driver, com.getElementProperties("ExceptionChecker", "work_basket_option"));
	   Thread.sleep(5000);
	   wrap.click(driver, com.getElementProperties("ExceptionChecker", "modal_wb_Checkerreview"));
	   driver.switchTo().defaultContent();
	   wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
		Thread.sleep(5000);
	   businessutils.select_application_number(driver, "IN20170329000032");
	   //businessutils.select_application_number(driver, BaseProject.appId);
	   driver.switchTo().defaultContent();
	   
	   
	   
	   


	  		Thread.sleep(1000);

	  		String filter = com.getElementProperties("ExceptionChecker", "filter_link");
	  		String search = com.getElementProperties("ExceptionChecker","search_text");
	  		String apply_button = com.getElementProperties("ExceptionChecker","apply_button");
	  		try{
	  			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
	  			driver.findElement(By.xpath("//span[text()='"+BaseProject.appId+"']")).click();
	  			//driver.findElement(By.xpath("//span[text()='IN20170329000032']")).click();
	  		}
	  		catch(Exception e){
	  			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
	  			wrap.click(driver, filter);
	  			Thread.sleep(1000);

	  			//wrap.typeToTextBox(driver, appNumber, search);
	  			wrap.typeToTextBox(driver,BaseProject.appId , search);
	  			wrap.click(driver, apply_button);


	  			Thread.sleep(1000);
	  			//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
	  			driver.findElement(By.xpath("//span[text()='"+BaseProject.appId+"']")).click();
	  			//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();

	  		}
	  		Thread.sleep(1000);
	  wrap.switch_to_default_Content(driver);
	  	
   }
*/

 
 
 
/* @When ("^select application number '(.*)'$")
 public static void select_application_number(String appNumber) throws IOException, InterruptedException{


		Thread.sleep(1000);

		String filter = com.getElementProperties("ExceptionChecker", "filter_link");
		String search = com.getElementProperties("ExceptionChecker","search_text");
		String apply_button = com.getElementProperties("ExceptionChecker","apply_button");
		try{
			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
		}
		catch(Exception e){
			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			wrap.click(driver, filter);
			Thread.sleep(1000);

			wrap.typeToTextBox(driver, appNumber, search);
			wrap.click(driver, apply_button);


			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();

		}
		Thread.sleep(1000);
wrap.switch_to_default_Content(driver);
	}*/
 
 //////////Aparna

	

	@Given("^enter valid credentials$")
	public void credentials() throws Throwable {
		wrap.type(driver, "1245081",
				com.getElementProperties("ExceptionChecker", "home_login_username"));
		wrap.type(driver, "rules",
				com.getElementProperties("ExceptionChecker", "home_login_password"));
		Thread.sleep(5000);
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "home_login_submit"));
		Thread.sleep(5000);
	}

	

	/*@Given("^Switch to App Workflow window$")
	public void switch_App_Workflow_User_portal() throws Throwable {
		System.out.println(driver.getTitle());
		wrap.switchToWindow(driver, "AppWorkFlow User Portal");
		System.out.println(driver.getTitle());
		Thread.sleep(5000);
	}*/

	@Given("^Go to ExceptionChecker home page$")
	public void gotoExCheckHomePage() throws Throwable {
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "work_basket_option"));
		Thread.sleep(2000);
		// wrap.click(driver, com.getElementProperties("ExceptionChecker",
		// "seeall_option"));
		// Thread.sleep(2000);
		wrap.click(driver,
				com.getElementProperties("ExceptionChecker", "modal_workbasket_Exp"));
		Thread.sleep(1000);
		System.out.println("clicked");
		Thread.sleep(5000);
		
		wrap.click(BaseProject.driver, com.getElementProperties("ExceptionChecker", "seeall_option"));
		
		
	    wrap.getWorkbasketoption(BaseProject.driver,"Exception Data Checker");
	   
		wrap.click(BaseProject.driver, com.getElementProperties("ExceptionChecker", "modal_submit_button"));
		
		// wrap.click(driver, com.getElementProperties("ExceptionChecker",
		// "modal_submit_button"));
		
		
		//wrap.select_application_number(driver, BaseProject.appId);
		
	}

	
	@Given("^Exception: Go to Exception Checker page$")
	public static void selectAnApplicationNumber1() throws IOException,
			InterruptedException {

		// String appNumber="IN20170320000060";
		// wrap.switchToWindow(driver, "AppWorkFlow User Portal");
		Thread.sleep(5000);
		wrap.click(driver, com.getElementProperties("ExceptionChecker",
				"work_basket_option"));
		Thread.sleep(5000);

		wrap.click(driver, com.getElementProperties("ExceptionChecker","modal_workbasket_Exp"));
		Thread.sleep(5000);

		
	

  		String filter = com.getElementProperties("ExceptionChecker", "filter_link");
  		String search = com.getElementProperties("ExceptionChecker","search_text");
  		String apply_button = com.getElementProperties("ExceptionChecker","apply_button");
  		try{
  			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
  			driver.findElement(By.xpath("//span[text()='"+BaseProject.appId+"']")).click();
  			//driver.findElement(By.xpath("//span[text()='IN20170329000032']")).click();
  		}
  		catch(Exception e){
  			 wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
  			wrap.click(driver, filter);
  			Thread.sleep(1000);

  			//wrap.typeToTextBox(driver, appNumber, search);
  			wrap.typeToTextBox(driver, BaseProject.appId, search);
  			wrap.click(driver, apply_button);


  			Thread.sleep(1000);
  			//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();
  			driver.findElement(By.xpath("//span[text()='"+BaseProject.appId+"']")).click();
  			//driver.findElement(By.xpath("//span[text()='"+appNumber+"']")).click();

  		}
  		Thread.sleep(1000);
  wrap.switch_to_default_Content(driver);
		
		
	//	wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
	//Thread.sleep(5000);
	//	businessutils.select_application_number(driver, "IN20170329000032");
		//businessutils.select_application_number(driver, BaseProject.appId);
	//	wrap.switch_to_default_Content(driver);

	}

	

	@Then("^user should validate all the fields are in read only format for single applicant$")
	public void user_should_validate_all_the_fields_are_in_read_only_format_for_single_applicant()
			throws Throwable {

	}

	@Then("^user should validate all the fields are in read only format for joint applicant$")
	public void user_should_validate_all_the_fields_are_in_read_only_format_for_joint_applicant()
			throws Throwable {

	}

	@Then("^user should validate all the fields are in read only format$")
	public void user_should_validate_all_the_fields_are_in_read_only_format()
			throws Throwable {

	}

	
	

	/*
	 * @And("^click on Save button$") public void click_on_Save_button() throws
	 * Throwable {
	 * 
	 * try {
	 * 
	 * 
	 * wrap.selectFromDropDown(driver, com.getElementProperties("ExceptionChecker",
	 * "Action_dropdown1"), "Approved", "BYVISIBLETEXT");
	 * System.out.println("Read"); wrap.type(driver, "Text",
	 * com.getElementProperties("ExceptionChecker", "Remarks")); Thread.sleep(5000);
	 * wrap.switch_to_default_Content(driver);
	 * System.out.println("Switchedout"); Thread.sleep(5000);
	 * //wrap.click(driver, com.getElementProperties("Excheck", "save");
	 * 
	 * } catch (Exception e) { System.out.println("frame not switched"); } }
	 */

	

	
	@Then("^verify approved option in the action dropdown and enter remarks and submit$")
	public void verifyApprovedOptionInActionDropdown()
			throws Throwable {
		// Select dropdown=new Select((WebElement)
		// driver.findElement(By.id("DataCaptureActionList")));
		// dropdown.selectByVisibleText("Approved");
		CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");

		try {
			wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
			System.out.println("switched");

			wrap.selectFromDropDown(driver,
					com.getElementProperties("ExceptionChecker", "Action_dropdown1"),
					"Approved", "BYVISIBLETEXT");
			System.out.println("Read");
			wrap.type(driver, "Text",
					com.getElementProperties("ExceptionChecker", "Remarks"));

			wrap.click(driver, com.getElementProperties("ExceptionChecker", "submit"));
			System.out.println("submit successfully");
			wrap.switch_to_default_Content(driver);
			System.out.println("Switchedout");
			Thread.sleep(5000);
			wrap.click(driver,
					com.getElementProperties("ExceptionChecker", "seeall_option"));
			Thread.sleep(5000);
			wrap.click(driver,
					com.getElementProperties("ExceptionChecker", "modal_next_button"));
			Thread.sleep(5000);
			wrap.click(driver,
					com.getElementProperties("ExceptionChecker", "modal_next_button"));
			Thread.sleep(5000);
			wrap.click(driver, com.getElementProperties("ExceptionChecker",
					"modal_workbasket_fulldata"));
			System.out.println("fulldata");
			wrap.click(driver,
					com.getElementProperties("ExceptionChecker", "modal_submit_button"));
			Thread.sleep(5000);
			wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			System.out.println("switched");
			wrap.select_application_number(driver, BaseProject.appId);
			System.out.println("App Id filtered");

		} catch (Exception e) {
			System.out.println("frame not switched");
		}
		// wrap.selectFromDropDown(driver,
		// getElementProperties("ContactTypecls"), "Mobile", "BYVISIBLETEXT");
		// Select dropdown=new Select(WebElement)
		// driver.findElement(By.id("DataCaptureActionList"))
	}

	

	
	

	@And("^select Return to maker option from drop down list$")
	public void select_return_to_maker_option_from_drop_down_list()
			throws Throwable {

		try {
			wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
			System.out.println("switched");

			wrap.selectFromDropDown(driver,
					com.getElementProperties("ExceptionChecker", "Action_dropdown1"),
					"Return to Maker", "BYVISIBLETEXT");
			System.out.println("Read");

		} catch (Exception e) {
			System.out.println("frame not switched");
		}
		// wrap.selectFromDropDown(driver,
		// getElementProperties("ContactTypecls"), "Mobile", "BYVISIBLETEXT");
		// Select dropdown=new Select(WebElement)
		// driver.findElement(By.id("DataCaptureActionList"))
	}

	@And("^Enter Remarks and click save$")
	public void click_save_and_submit_button() throws Throwable {
		
		CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");
		
		try {
//			wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
			switchFrame();
			System.out.println("switched");

			wrap.selectFromDropDown(driver,
					com.getElementProperties("ExceptionChecker", "Action_dropdown1"),
					"Approved", "BYVISIBLETEXT");
			System.out.println("Read");
			wrap.wait(2000);
			wrap.type(driver, "Text", com.getElementProperties("ExceptionChecker", "Remarks"));
			wrap.click(driver, com.getElementProperties("ExceptionChecker", "Exp_save"));
			wrap.click(driver, com.getElementProperties("ExceptionChecker", "Exp_close"));
			wrap.switch_to_default_Content(driver);
			System.out.println("Switchedout");

		}

		catch (Exception e) {
		}
	}

	@And("^check whether the application id  available in exception checker worklist$")
	public void check_whether_the_application_id_available_in_exception_checker_worklist() throws Throwable{

		try {
			// switch_App_Workflow_User_portal();
			wrap.click(driver, com.getElementProperties("ExceptionChecker", "Worklist"));
			System.out.println("clicked");
			Thread.sleep(5000);
			// switchFrame();
			// wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
			// System.out.println("switched");
			// wrap.switch_to_default_Content(driver);
			switchFrame();
			Thread.sleep(5000);
			wrap.select_application_number(driver, BaseProject.appId);
			wrap.switch_to_default_Content(driver);
			System.out.println("Switchedout");
			switchFrame();
			System.out.println("switched");
			System.out.println(wrap.getElement(driver, com.getElementProperties("ExceptionChecker","Remarks")).getText());
			 
			// wrap.click(driver, com.getElementProperties("ExceptionChecker",
			// "AppworkflowID_Click"));

			Thread.sleep(5000);
			System.out.println("filtered");

		}

		catch (Exception e) {
			System.out.println("not filtered");
		}
	}


 




 
 
 
@Given("^Go to FullDataCapture Maker home page '(.+)'$")
 public void Go_to_FullDataCaptureMaker_home_page(String workbasketModule) throws Throwable {
       
	   Thread.sleep(5000);
        wrap.click(driver, com.getElementProperties("ExceptionChecker", "work_basket_option"));
       Thread.sleep(2000);
        
    //    wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_wb_Exceptionchecker"));
       wrap.click(driver, com.getElementProperties("ExceptionChecker", "seeall_option"));
        Thread.sleep(1000);
       List<WebElement> list = wrap.getExactAttributes(driver, com.getElementProperties("ExceptionChecker", "workbasket_AllModules")); 

        Iterator<WebElement> itr = list.iterator();
        while(itr.hasNext()){
               WebElement workbasket = itr.next();

               try{
                     if(workbasket.getText().equalsIgnoreCase(workbasketModule)){
                            workbasket.click();
                     }
               }catch(ElementNotVisibleException e){
                     wrap.click(driver, com.getElementProperties("ExceptionChecker", "modal_next_button"));
                     Thread.sleep(1000);

                     if(workbasket.getText().equalsIgnoreCase(workbasketModule)){
                            workbasket.click();
                     }
               }
        }

   //     wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_next_button"));
        Thread.sleep(1000);
      //  wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "modal_wb_Exceptionchecker"));
       
        wrap.click(driver, com.getElementProperties("ExceptionChecker", "modal_submit_button"));
        //Thread.sleep(5000);      

 }


 
/* @Given("^Switch to Main window$")
 public void switch_to_Main_window() throws Throwable {
        //System.out.println(driver.getTitle());
        //wrap.switchToWindow(driver,"AppWorkFlow User Portal");
  //      wrap.switchToWindow(driver, "Pega Designer Studio");
        //wrap.switch_to_window();
        System.out.println(driver.getTitle());
        
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "mainWindow_clipboardLink"));
 Thread.sleep(2000);
 System.out.println(driver.getTitle());
//  wrap.switchToWindow(driver, "Clipboard Viewer - Google Chrome");
 Thread.sleep(2000);
 System.out.println(driver.getTitle());
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "clipboard_standard_dropdown"));
 
  Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "dropdown_linkorder"));
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "select_pyworkpage_link"));
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "select_customer_link"));
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "select_customer1_link"));
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "basicDataCapture_link"));
 
  Thread.sleep(2000);
 List<WebElement> basicData = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "readvalues_basic_and_blindData"));
 for(WebElement basicValues: basicData){
        System.out.println(basicValues.getText());
 }
 
 // wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "readvalues_basic_and_blindData"));
 Thread.sleep(2000);
 wrap.click(driver, com.getElementProperties("ExceptionChecker", "blindDataCapture_link"));
 Thread.sleep(2000);
 List<WebElement> blindData = wrap.getElements(driver, com.getElementProperties("ExceptionChecker", "readvalues_basic_and_blindData"));
 for(WebElement blindValues: blindData){
        System.out.println(blindValues.getText());
 }
 //wrap.click(driver, com.getElementProperties("FullDataCaptureMaker", "readvalues_basic_and_blindData"));
 Thread.sleep(2000);
 }
 @And ("^logout the application$")
	public void logout_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
 	wrap.switch_to_default_Content(driver);
	   wrap.click(driver, com.getElementProperties("ExceptionChecker", "home_logout"));
	   driver.quit();
	}*/
 /*@Given("^Verify the application number'(.+)'$")
 public void verify_the_application_number(String appNumber) throws Throwable {
     // Write code here that turns the phrase above into concrete actions
 	
   wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");
   Thread.sleep(2000);
  
 }
public static void getTable()
{
	 wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
	WebElement eleTable = driver.findElement(By.xpath("//li[@title='RM Referral' and @aria-selected='true' ]//ancestor::div[@class='scrlCntr']//following-sibling::div//div[@data-node-id='RMReworkDetails']//table[@class='gridTable ']"));
	
	List<WebElement> trws= eleTable.findElements(By.tagName("tr"));
	System.out.println(trws.size());

	for (WebElement tr : trws) {
		
		List<WebElement> tds=tr.findElements(By.tagName("td"));
				for (WebElement td : tds) {
					System.out.println(td.getText());
					
				}
		
	}
}
 */
 
@Then("^Verify if the validation of Field Title is present under the category Customer Details1$")
public void verifyTitleField1() throws IOException, InterruptedException
{
	
	try {
	
		switchFrame();
		com.validateAlphanumeric(BaseProject.driver, "Title_CustDetails_XPATH", "VARCHAR");
		boolean isTitleDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_Title_Label_XPATH"))).isDisplayed();
		logger.info("isTitleDisplayed ==== "+isTitleDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
}

@Then("^Verify if the validation of Field Name of the Document is present under the category Customer Details1$")
public void verifyDocumentNameField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "NameofDoc_CustDetails_XPATH", "VARCHAR");
		boolean isDocumentNameDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_DocName_Label_XPATH"))).isDisplayed();
		logger.info("isDocumentNameDisplayed ==== "+isDocumentNameDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Document Number is present under the category Customer Details1$")
public void verifyDocumentNumbField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "DocNumber_CustDetails_XPATH", "VARCHAR");
		boolean isDocumentNumbDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_DocNumb_Label_XPATH"))).isDisplayed();
		logger.info("isDocumentNumbDisplayed ==== "+isDocumentNumbDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Document Expiry Date is present under the category Customer Details1$")
public void verifyDocumentExprDateField1() throws IOException, InterruptedException
{

	try{
//		com.validateAlphanumeric(BaseProject.driver, "DocExpiryDate_CustDetails_XPATH", "VARCHAR");
		boolean isDocumentExprDateDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_DocExprDate_Label_XPATH"))).isDisplayed();
		logger.info("isDocumentExprDateDisplayed ==== "+isDocumentExprDateDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
}

@Then("^Verify if the validation of Field First Name is present under the category Customer Details1$")
public void verifyFirstNameField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "FirstName_CustDetails_XPATH", "VARCHAR");
		boolean isFirstNameDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_FirstName_Label_XPATH"))).isDisplayed();
		logger.info("isFirstNameDisplayed ==== "+isFirstNameDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Middle Name is present under the category Customer Details1$")
public void verifyMiddleNameField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "MiddleName_CustDetails_XPATH", "VARCHAR");
		boolean isMiddleNameDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_MiddleName_Label_XPATH"))).isDisplayed();
		logger.info("isMiddleNameDisplayed ==== "+isMiddleNameDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Last Name is present under the category Customer Details1$")
public void verifyLastNameField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "LastName_CustDetails_XPATH", "VARCHAR");
		boolean isLastNameDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_LastName_Label_XPATH"))).isDisplayed();
		logger.info("isLastNameDisplayed ==== "+isLastNameDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Date of Birth is present under the category Customer Details1$")
public void verifyDoBField1() throws IOException, InterruptedException
{
	
	try{
	boolean isDoBDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_DoB_Label_XPATH"))).isDisplayed();
	logger.info("isDoBDisplayed ==== "+isDoBDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Alias Type is present under the category Customer Details1$")
public void verifyAliasTypeField1() throws IOException, InterruptedException
{

	try{
//		com.validateAlphanumeric(BaseProject.driver, "LastName_CustDetails_XPATH", "VARCHAR");
		boolean isAliasTypeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AliasType_Label_XPATH"))).isDisplayed();
		logger.info("isAliasTypeDisplayed ==== "+isAliasTypeDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
}

@Then("^Verify if the validation of Nationality is present under the category Customer Details1$")
public void verifyNationalityField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "Nationality_CustDetails_XPATH", "VARCHAR");
		boolean isNationalityDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_Nationality_Label_XPATH"))).isDisplayed();
		logger.info("isNationalityDisplayed ==== "+isNationalityDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Country of Birth is present under the category Customer Details1$")
public void verifyCountryofBirthField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "CountryofBirth_CustDetails_XPATH", "VARCHAR");
		boolean isCountryofBirthDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_CountryofBirth_Label_XPATH"))).isDisplayed();
		logger.info("isCountryofBirthDisplayed ==== "+isCountryofBirthDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Country of Residence is present under the category Customer Details1$")
public void verifyCountryofResidenceField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "CountryofResidence_CustDetails_XPATH", "VARCHAR");
		boolean isCountryofResidenceDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_CountryofResid_Label_XPATH"))).isDisplayed();
		logger.info("isCountryofResidenceDisplayed ==== "+isCountryofResidenceDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Contact Details is present under the category Customer Details1$")
public void verifyContactDetailsField1() throws IOException, InterruptedException
{

	try{
		
		boolean isContactDetailsDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ContactDetails_Label_XPATH"))).isDisplayed();
		logger.info("isContactDetailsDisplayed ==== "+isContactDetailsDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of ISD Code is present under the category Customer Details1$")
public void verifyISDCodeField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "ISDCode_CustDetails_XPATH", "VARCHAR");
		boolean isISDCodeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ISDCode_Label_XPATH"))).isDisplayed();
		logger.info("isISDCodeDisplayed ==== "+isISDCodeDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Occupation is present under the category Customer Details1$")
public void verifyOccupationField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "Occupation_CustDetails_XPATH", "VARCHAR");
		boolean isOccupationDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_Occupation_Label_XPATH"))).isDisplayed();
		logger.info("isOccupationDisplayed ==== "+isOccupationDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Document Signature Date is present under the category Customer Details1$")
public void verifyDocSignDateField1() throws IOException, InterruptedException
{

	try{
	boolean isDocSignDateDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_DocSignDate_Label_XPATH"))).isDisplayed();
	logger.info("isDocSignDateDisplayed ==== "+isDocSignDateDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Product Code is present under the category Product Details1$")
public void verifyProdCodeField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "ProdCode_ProdDetails_XPATH", "VARCHAR");	
		boolean isProdCodeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ProdCode_Label_XPATH"))).isDisplayed();
		logger.info("isProdCodeDisplayed ==== "+isProdCodeDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}


@Then("^Verify if the validation of Field Purpose of account opening is present under the category Product Details1$")
public void verifyAcctOpenPurposeField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "PurposeofAcc_ProdDetails_XPATH", "VARCHAR");
		boolean isAcctOpenPurposeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AcctOpenPurpose_Label_XPATH"))).isDisplayed();
		logger.info("isAcctOpenPurposeDisplayed ==== "+isAcctOpenPurposeDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}


@Then("^Verify if the validation of Field Account Type is present under the category Product Details1$")
public void verifyAcctTypeField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "AccType_ProdDetails_XPATH", "VARCHAR");
		boolean isAccTypeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AccType_Label_XPATH"))).isDisplayed();
		logger.info("isAccTypeDisplayed ==== "+isAccTypeDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Account Number is present under the category Product Details1$")
public void verifyAcctNoField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "AccNo_ProdDetails_XPATH", "VARCHAR");
		boolean isAcctNoDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AcctNo_Label_XPATH"))).isDisplayed();
		logger.info("isAcctNoDisplayed ==== "+isAcctNoDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only"); 
	}
	
}

@Then("^Verify if the validation of Field Account Currency is present under the category Product Details1$")
public void verifyAccCurrencyField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "AccCurrency_ProdDetails_XPATH", "VARCHAR");
		boolean isAccCurrencyDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AccCurrency_Label_XPATH"))).isDisplayed();
		logger.info("isAccCurrencyDisplayed ==== "+isAccCurrencyDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Campaign Code is present under the category Product Details1$")
public void verifyCampaignCodeField1() throws IOException, InterruptedException
{
	
	try{
		com.validateAlphanumeric(BaseProject.driver, "CampaignCode_ProdDetails_XPATH", "VARCHAR");
		boolean isCampaignCodeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_CampaignCode_Label_XPATH"))).isDisplayed();
		logger.info("isCampaignCodeDisplayed ==== "+isCampaignCodeDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field ARM Code is present under the category Application Details1$")
public void verifyARMCodeField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "ARMCode_AppDetails_XPATH", "VARCHAR");
		boolean isARMCodeDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ARMCode_Label_XPATH"))).isDisplayed();
		logger.info("isARMCodeDisplayed ==== "+isARMCodeDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Source ID is present under the category Application Details1$")
public void verifySourceIDField1() throws IOException, InterruptedException
{

	try{
//		com.validateAlphanumeric(BaseProject.driver, "SourcingID_AppDetails_XPATH", "VARCHAR");
		boolean isSourceIDDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_SourceID_Label_XPATH"))).isDisplayed();
		logger.info("isSourceIDDisplayed ==== "+isSourceIDDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Referral ID is present under the category Application Details1$")
public void verifyReferralIDField1() throws IOException, InterruptedException
{

	try{
//		com.validateAlphanumeric(BaseProject.driver, "ReferralID_AppDetails_XPATH", "VARCHAR");
		boolean isReferralIDDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ReferralID_Label_XPATH"))).isDisplayed();
		logger.info("isReferralIDDisplayed ==== "+isReferralIDDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Acquisition Channel is present under the category Application Details1$")
public void verifyAcqChannelField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "AcquisitionChannel_AppDetails_XPATH", "VARCHAR");
		boolean isAcqChannelDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_AcqChannel_Label_XPATH"))).isDisplayed();
		logger.info("isAcqChannelDisplayed ==== "+isAcqChannelDisplayed);	
	}
	catch(Exception e){
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Fastrack Flag is present under the category Application Details1$")
public void verifyFastrackFlagField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "Fastrackflag_AppDetails_XPATH", "VARCHAR");	
		boolean isFastrackFlagDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_FastrackFlag_Label_XPATH"))).isDisplayed();
		logger.info("isFastrackFlagDisplayed ==== "+isFastrackFlagDisplayed);	
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}

@Then("^Verify if the validation of Field Application Branch is present under the category Application Details1$")
public void verifyApplnBranchField1() throws IOException, InterruptedException
{

	try{
		com.validateAlphanumeric(BaseProject.driver, "AppBranch_AppDetails_XPATH", "VARCHAR");	
		boolean isApplnBranchDisplayed = BaseProject.driver.findElement(By.xpath(com.getElementProperties("Checker", "Checker_ApplnBranch_Label_XPATH"))).isDisplayed();
		logger.info("isApplnBranchDisplayed ==== "+isApplnBranchDisplayed);
	}
	catch(Exception e){
		
		System.out.println("Field is read only");
	}
	
}
 

@Then("^Take Screenshot$")
public void takeScreenshot() throws Throwable {

wrap.captureScreenShot(BaseProject.driver, "Exception Checker");
}

/*
@Then("^ExChecker : Validate Field '(.+)'$")
public static void validateFieldStep(String FieldName) throws IOException, InterruptedException{
	
	CommonUtilsData.FieldNameData = FieldName;
    
    CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data_Updated");
    
    try{
           
           if(!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)){
           
                 CommonUtils.validateField(
                               CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData),
                               CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
                 			  CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));
           
           }
    }
    
    catch(Exception E){
           
           System.out.println("Field : "+FieldName+" is not present in Datamodel");
    }          
	
}
*/

@Then("^ExChecker : Validate Field '(.+)'$")
public static void validateFieldStepChecker(String FieldName) throws Throwable{

       //checkerHeadersvalue=wrap.getHeadersFromCsv(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\" +"Datamodel - Checker1.csv", ",");
       //CsvCompare.convertCsvMapOfMap(System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData\\"+"Datamodel - Checker1.csv",CheckerData,"\n");

       logger.info("Going to switch into frame");

      switchFrame();

       logger.info("Frame switched successfully");

       String S = wrap.getElement(driver, com.getElementProperties("Checker", "Checker_PrimaryApplicant_Tab_XPATH")).getText();

      logger.info("The String is" + S);

       CommonUtilsData.FieldNameData = FieldName; 
       String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"ExceptionCheckerFieldVal.csv");
       //CsvCompare.readCsv(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\" +"Datamodel - Checker1.csv", ",");

       //            CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel - Checker1.xls", "Sheet1");

       //            wrap.wait(2000);

       //wrap.fluentWait(driver, com.getElementProperties("Checker", "Checker_PrimaryApplicant_Tab_XPATH"));


       try{

              if(!(Fieldval[0]).equalsIgnoreCase(null)){

//                    wrap.click(driver, com.getElementProperties("ExceptionChecker", Fieldval[11]));

//                    wrap.wait(2000);

                    //wrap.fluentWait(driver, com.getElementProperties("Checker", "Checker_Data_checkboxes"));

                    logger.info("Field validation starts"); 
                     CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
                    }
       }

       catch(Exception E){

              System.out.println("Field : "+FieldName+" is not present in Datamodel");
       }            

}


/*public static void validateField(String fieldName,String locator, String dataFormat, String dataType, String length, String displayEditable) throws IOException, InterruptedException{
	
	try {
		
		logger.info("Validations for Field :"+fieldName);
		
		if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator))){
			
			logger.info("Field is present in the screen");
			
			if(displayEditable.equalsIgnoreCase("DNE")){
					
				if(wrap.isElementEditable(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator))){
					
					System.out.println("***** The field is Editable - Editable Check : true *****");
					System.out.println("***** DataFormat macthed : "+com.validateVarchar(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator), dataFormat)+" *****");
					System.out.println("***** DataType macthed : "+wrap.fieldObjectTypeVal(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator), dataType)+" *****");
					
					//System.out.println("***** Mandatory Check : "+wrap.isMandatoryField(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator),moc)+" *****");
					
					if(!dataType.equalsIgnoreCase("dropdown")){
						System.out.println("***** FieldLength macthed : "+wrap.fieldLenghtVal(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator), length)+" *****");
					}						
				}
			
				else{
					
					System.out.println("***** The field is not Editable - Editable Check : false *****");
					
				}
				
			}
			
			else{					
					if(!wrap.isElementEditable(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", locator))){
						System.out.println("***** The field is Editable - Editable Check : true *****");
					}
					
					else{
						System.out.println("***** The field is not Editable - Editable Check : false *****");
						
					}	
			}
			
		}
		
		else{
			
			logger.info("FAIL - Field is not present in the screen");
		}
		
	}
	catch(Exception E){
		logger.info("FAIL - Validation failed");
		E.printStackTrace();
	}
	
	
}*/




/*@Then("^Validate the data format of first name$")
public void validatedataformatfirstname() throws IOException, InterruptedException {
	
	try{
		CommonUtilsData.convertExcelToMap(BaseProject.excelPath,"Datamodel.xls","Data");
	wrap.wait(2000);
	wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
	String firstNameText = driver.findElement(By.xpath("(//*[@id='CheckerValue'])[1]")).getText();
	System.out.println("Firstname text printed : "+firstNameText);
	
	com.validateVarchar(BaseProject.driver, "(//*[@id='CheckerValue'])[1]", firstNameText);
	
	wrap.fieldObjectTypeVal(driver, "(//*[@id='CheckerValue'])[1]", dataType);
	wrap.fieldLenghtVal(driver, "(//*[@id='CheckerValue'])[1]", length);
	}
	catch (Exception e) {
	}*/

@Then("^Read excel$")
public static void readexcel() throws IOException
{
	CommonUtils.convertExcelToMap(BaseProject.excelPath, "ExCheckerUATMapping.xls", "Sheet1");
}
}