package com.scb.rtob.module.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.scb.rtob.module.test.framework.glue.DocumentIndexing;
import com.scb.rtob.module.test.framework.glue.BaseProject;

public class CommonUtilsData {

	private static Logger logger = Logger.getLogger(CommonUtilsData.class);
	
	public static List<HashMap<String, String>> FieldData = new ArrayList<HashMap<String, String>>();
	
	public static int rowCount = 10;
	
	public static String FieldNameData = null;
	
	@SuppressWarnings("deprecation")
	public static void convertExcelToMap(String FilePath,String FileName,String sheetName) throws IOException{
		FieldData.clear();
		String MyFile= FilePath+File.separator+FileName;
		FileInputStream fin = new FileInputStream(MyFile);
		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
		/*for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
		{
		    Row currentRow = sheet.getRow(i);
		    for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		    {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType())
		        {
		            case Cell.CELL_TYPE_STRING:
		                System.out.print(currentCell.getStringCellValue() + "|");
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                System.out.print(currentCell.getNumericCellValue() + "|");
		                break;
		              
		            case Cell.CELL_TYPE_BLANK:
		                System.out.print("<blank>|");
		                break;
		        }
		    }
		    System.out.println("\n");
		}*/
		rowCount = sheet.getPhysicalNumberOfRows();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
		    Row currentRow = sheet.getRow(i);
		    HashMap<String, String> currentHash = new HashMap<String, String>();
		    for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType()) {
		            case Cell.CELL_TYPE_STRING:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue()));
		                break;
		        }
		    }
		    FieldData.add(currentHash);
		    //System.out.println("\n\n"+currentHash);
		}
		//logger.info(FieldData);
		//logger.info(FieldData.get(0));
	}
	
	
	
	public static String readColumn(String column,int row){
		HashMap<String, String> map = FieldData.get(row);
		String result=null;
        for (Entry<String, String> entry : map.entrySet()) {
        	if(entry.getKey().equalsIgnoreCase(column)){
        		//logger.info(entry.getValue());
        		result = entry.getValue();
        	}

        }
       return result;
       
       
	}
	
	public static String readColumnWithRowID(String column,String FieldName){
		//logger.info("row :"+column+":"+FieldName);
		String result=null;
		try{
			for(int i=0;i<rowCount;i++){
				if(readColumn("Field Name", i).equalsIgnoreCase(FieldName)){
//					logger.info("matched with "+readColumn("Field Name", i));
					result = readColumn(column, i);
					break;
				}
			}
		}
		catch(IndexOutOfBoundsException I){
			logger.info("Field Name didn't match");
		}
		catch(Exception E){
			logger.info("Reading from Excel has failed");
		}
//		logger.info("result : "+result);
		return result;
	}

}
