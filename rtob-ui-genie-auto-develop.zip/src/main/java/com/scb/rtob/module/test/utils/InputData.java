package com.scb.rtob.module.test.utils;

import java.util.HashMap;
import java.util.Map;

public class InputData {
	
	public final static String DOCUMENT_INDEXING ="DocumentIndexing";
	public final static String PRODUCT_CATALOGUE ="ProdCat";
	public final static String HARD_COPY ="HardCopy";
	
	public static Map<String, String>  inputDataMap = new HashMap<String, String>();
	
	public static void inputDatMap(){
		
		inputDataMap.put("DOCUMENT_INDEXING", InputData.DOCUMENT_INDEXING);
		inputDataMap.put("PRODUCT_CATALOGUE", InputData.PRODUCT_CATALOGUE);
		inputDataMap.put("HARD_COPY", InputData.HARD_COPY);
		
	}

}
