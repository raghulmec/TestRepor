package com.scb.rtob.module.test.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by 1566035 on 7/31/2017.
 */
public final class TDMConfiguration {

    private static String TMP_CONFIG_FILENAME = "tdm.config.properties";
    private static String TMP_RESTFUL_ENDPOINT = "";
    private static String TMP_BASICAUTH_KEY = "";
    private static String TMP_REFRESH_WAIT_MS = "1000";
    private static String TMP_REFRESH_WAIT_RETRY_LIMIT = "10";
    private static String TMP_GENERATOR_ID = "0";
    private static String TMP_CONFIGURATION_ID = "0";
    private static String TMP_NAME = "";
    private static String TMP_DESCRIPTION = "";
    private static String TMP_FDC_GENERATOR_ID = "";
    private static String TMP_FDC_CONFIGURATION_ID = "";

    private static Properties prop = new Properties();
    private static InputStream inputstream = null;

    static{
        try {
            //String envName = System.getProperty("env").toLowerCase().trim();
            String envName = "sit";
            inputstream = TDMConfiguration.class.getClassLoader().getResourceAsStream(envName + "." + TMP_CONFIG_FILENAME);


            if( inputstream==null){
                System.out.println("Unable to find config file:" + envName + "." + TMP_CONFIG_FILENAME);
            }
            else{
                //load properties file and get the properties values
                prop.load(inputstream);
                TMP_RESTFUL_ENDPOINT = prop.getProperty("tdm.endpoint.url");
                TMP_BASICAUTH_KEY = prop.getProperty("tdm.authorization.key");
                TMP_REFRESH_WAIT_MS = prop.getProperty("tdm.publish.refresh.wait.milisecond");
                TMP_REFRESH_WAIT_RETRY_LIMIT = prop.getProperty("tdm.publish.refresh.wait.retry.limit");
                TMP_GENERATOR_ID = prop.getProperty("tdm.publish.generatorId");
                TMP_CONFIGURATION_ID = prop.getProperty("tdm.publish.configurationId");
                TMP_NAME = prop.getProperty("tdm.publish.name");
                TMP_DESCRIPTION = prop.getProperty("tdm.publish.description");
                TMP_FDC_GENERATOR_ID = prop.getProperty("tdm.publish.fdc.generatorId");
                TMP_FDC_CONFIGURATION_ID = prop.getProperty("tdm.publish.fdc.configurationId");
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        finally{
            if( inputstream!=null){
                try{
                    inputstream.close();
                }
                catch(IOException e){
                    e.printStackTrace();
                }
            }
        }

    }
    public final static String CONFIG_FILENAME = TMP_CONFIG_FILENAME;
    public final static String RESTFUL_ENDPOINT = TMP_RESTFUL_ENDPOINT;
    public final static String BASICAUTH_KEY = TMP_BASICAUTH_KEY;
    public final static int REFRESH_WAIT_MS = Integer.valueOf(TMP_REFRESH_WAIT_MS);
    public final static int REFRESH_WAIT_RETRY_LIMIT = Integer.valueOf(TMP_REFRESH_WAIT_RETRY_LIMIT);
    public final static String  GENERATOR_ID = TMP_GENERATOR_ID;
    public final static String  CONFIGURATION_ID = TMP_CONFIGURATION_ID;
    public final static String  NAME = TMP_NAME;
    public final static String  DESCRIPTION = TMP_DESCRIPTION;
    public final static String  FDC_GENERATOR_ID = TMP_FDC_GENERATOR_ID;
    public final static String  FDC_CONFIGURATION_ID = TMP_FDC_CONFIGURATION_ID;
}
