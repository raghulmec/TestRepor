package com.scb.rtob.module.test.framework;

import com.standardchartered.genie.GenieRuntime;
import com.standardchartered.genie.module.BaseGenieGlueModule;

import java.util.ArrayList;
import java.util.List;

public class GenieUiModule extends BaseGenieGlueModule {
    @Override
    public String getName() {
        return "genie_ui";
    }

    @Override
    public void initialise(GenieRuntime runtime) {
        runtime.addListener(new GenieUiModuleListener(runtime));
    }

    @Override
    public List<String> getGluePaths() {
        List<String> gluePaths = new ArrayList<>();
        gluePaths.add("classpath:com.scb.rtob.module.test.framework.glue");
        gluePaths.add("classpath:snippet");
        return gluePaths;
    }

}
