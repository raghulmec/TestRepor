package com.scb.rtob.module.test.framework.glue;

import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Exceptionreviewer {

    public static Logger logger = Logger.getLogger(Exceptionreviewer.class);

    static Wrapper wrap = new Wrapper();
    static Commons com = new Commons();
    public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
    static String Co_xpath = null;
    static String MultipleProducts_xpath = null;
    CommonUtils utils = new CommonUtils();
    public static String excelPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ExcelData";
    //Neethu code below two line declaration for co-applicant
    public static int FDC_Co_Applicant = 0, FDC_Co_Applicant1 = 0;
    public static String Coapp = "Coapp";
//	public static int increment_Applicant = 1;


    @Given("^Go to Exception Reviewer home page$")
    public void go_to_Full_data_Capture_home_page() throws Throwable {

        wrap.switch_to_default_Content(BaseProject.driver);

        try {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
            wrap.getWorkbasketoption(BaseProject.driver, "Exception Reviewer");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void switchFrame() throws InterruptedException {
        int Last = 0;

        BaseProject.driver.switchTo().defaultContent();
        wrap.wait(300);
        List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
        for (WebElement frame : frames) {
            logger.info(frame.getAttribute("Name"));

        }
        //logger.info("current frame name is "+ frmName.getAttribute("id"));
        Last = frames.size() - 1;
        //string currentFrame =
        logger.info("User should switch to this frame name PegaGadget" + Last + "Ifr");

        //wdwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(Last));
        BaseProject.driver.switchTo().frame(Last);
        logger.info("User switched to this frame name PegaGadget" + Last + "Ifr");
        wrap.wait(300);
    }
    
    
    @Given("^Click Submit in Exception Reviewer$")
    public void click_submit() throws Throwable {

        switchFrame();
        
        wrap.click(BaseProject.driver, com.getElementProperties("ExceptionReviewer", "Exception_Reviewer_Retry"));
       // ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", com.getElementProperties("ExceptionReviewer", "Exception_Reviewer_Comments"));
        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("window.scrollBy(-1000,0)", ""); 
        wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("Place of Birth", BaseProject.scenarioID), com.getElementProperties("ExceptionReviewer", "Exception_Reviewer_Comments"));
       // ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", com.getElementProperties("ExceptionReviewer", "Exception_Reviewer_Submit"));
       // JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("window.scrollBy(1000,0)", ""); 

        wrap.click(BaseProject.driver, com.getElementProperties("ExceptionReviewer", "Exception_Reviewer_Submit"));
    
}
}
