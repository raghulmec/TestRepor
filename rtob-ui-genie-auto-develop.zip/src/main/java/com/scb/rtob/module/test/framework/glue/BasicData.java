package com.scb.rtob.module.test.framework.glue;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import cucumber.api.java.en.And;

import org.junit.Assert;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import com.google.common.base.Function;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.SeleniumModule;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;
import com.scb.rtob.module.test.framework.glue.BaseProject;
import com.steadystate.css.parser.ParseException;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static com.scb.rtob.module.test.framework.XMLParser.envName;


public class BasicData {


	List<String> report = new ArrayList<String>();
	List<String> reportHeaders = new ArrayList<String>();
	String expectedResult;
	String startDate;
	Date Stime;
	Date startTime;
	Date endTime;
	long executionDuration;
	Date time;
	int entry;

	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	static CsvReaderutil csvread = new CsvReaderutil();

	public static String testResultsFIle;
	public static Robot r;
	public static String appId = null;
	public static WebDriverWait wait = new WebDriverWait(BaseProject.driver, 30);
	public static List<HashMap<String, String>> mydata = new ArrayList<HashMap<String, String>>();
	static CommonUtils utils = new CommonUtils();
	public static String excelPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator + "resources" + File.separator + "ExcelData";
	public static String screenShotPath = "C:/R2/Basic Screen shot";
	File file;
	Properties CONFIG;
	private static Logger logger = Logger.getLogger(BasicData.class);
	//public static WebDriverWait wait=new WebDriverWait(BaseProject.driver, 30);
	public static String propertiesFilename = "BasicData";
	{
		String envName = System.getProperty("env");
		URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
		File file = null;
		FileInputStream fis = null;
		try {
			file = new File(resource.toURI());
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		CONFIG = new Properties();
		try {
			CONFIG.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}

		String[] scenario= BaseProject.scenarioID.split("-");
		BaseProject.scenarioID=scenario[1];
		  logger.info("Scenario Id retrieved" + scenario );
		  logger.info("Scenario Id after splitting" + scenario[1] );
	}


	public static void waitunlitVisiblityOfWebElement(String attribute) {
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, attribute)));

	}


	public boolean verifyTextBoxThnClick(WebDriver driver, String attribute) throws InterruptedException {
		try {
			wrap.fluentWait(driver, attribute);
			wrap.click(driver, attribute);

			while (!wrap.getElement(driver, attribute).isEnabled()) {

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, attribute)));
				if (!wrap.getElement(driver, attribute).isEnabled()) {
					wrap.getElement(driver, attribute).click();
				}
			}
			return true;
		} catch (InvalidElementStateException e) {
			logger.info(e);
			logger.info(attribute);
			verifyTextBoxThnClick(driver, attribute);
			return true;
		}
	}

	@And("^connected to basic dataset$")
	public static void loadBasicDataset() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("bdquery");
	}

	@And("^connected to full dataset$")
	public static void loadFullDataset() throws IOException,ClassNotFoundException, SQLException {
		DBUtils.convertDBtoMap("fdquery");
	}

	@Then("^Basic: select an application number$")
	public static void select_an_application_number()throws IOException, InterruptedException {
		
		String appId = DBUtils.readColumnWithRowID("ApplicationID", BaseProject.scenarioID);
		logger.info("The Value going to select or Filter is [" + appId + "]");
		wrap.wait(3000);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");

		String filter = com.getElementProperties("Fulldatacapturemaker","filter_link");
		String search = com.getElementProperties("Fulldatacapturemaker","search_text");
		String apply_button = com.getElementProperties("Fulldatacapturemaker","apply_button");

		wrap.fluentWait( BaseProject.driver, filter);
		if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker","filter_link"))){

			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(filter)));
			wrap.click(BaseProject.driver, filter);
			logger.info("Filter Link Clicked on FIRST Time");

		} else {

			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(filter)));
			wrap.click(BaseProject.driver, filter);
			logger.info("Filter Link Clicked on SECOND Time");    
		}

		new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(search)));
		wrap.type(BaseProject.driver, appId, search);
		wrap.click(BaseProject.driver, apply_button);

		try {

			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='" + appId + "']")));
			WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='" + appId + "']")));
			wrap.click(BaseProject.driver, "//span[text()='" + appId + "']");
			logger.info("Clicked on the  span[text()='" + appId + "'] Field");

		}  catch (Exception e) {

			logger.info("Error clicking application ID: " + appId);
			e.printStackTrace();
			throw new InterruptedException();
		}
	}

	@Then("^Basic : Switch to Customer details tab$")
	public static void switchToCustomerDetailsTab() throws InterruptedException, IOException {

		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CD_CustomerDetails_Link"));
		wrap.wait(1000);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		wrap.wait(1000);
	}
	
	@Then("^Basic: Goto CoApplicant1$")
	public static void CoApplicant_Tab1() throws InterruptedException, IOException {
		wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CoApplicant1"));
	}
	

	@Given("^Basic: Switch to frame$")
	public static void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));

		for (WebElement frame : frames) {

			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		if(Last < 1){
			Last = 0;
		}

		logger.info(Last);

		try {

			WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe["+Last+"]")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("body")));

			wrap.wait(500);
			logger.info("Frame switched successfully");

		} catch (InterruptedException e) {

			logger.error("Unable to switch frame switched");
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Given("^Basic: Go to Basic Data Capture home page$")
	public void Go_to_Basic_Data_Capture_home_page() throws Throwable {

		wrap.switch_to_default_Content(BaseProject.driver);

		try {
			
			wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "SideLevelMenuLink"));
			logger.info("Clicked on Side Level Menu Bar");
			

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
			logger.info("Clicked - work_basket_option");

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
			logger.info("Clicked - seeall_option");

			wrap.getWorkbasketoption(BaseProject.driver, "Basic Data Capture Maker");
			logger.info("getWorkbasketoption - Basic Data Capture Maker");

			wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
			logger.info("Clicked - modal_submit_button");

		} catch (Exception e) {

			logger.error("Unable to go to BDC home page");
			e.printStackTrace();
			Assert.fail();
		}

	}


	@When("^Basic: click on Customer Details tab$")
	public void clickOnCustomerDetailsTab() throws Throwable {

		wrap.wait(1000);
		switchFrame();
		String cust_details = com.getElementProperties("BasicData","BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
		wrap.click(BaseProject.driver, cust_details);
	}

	@When("^Basic: Switch to Tab '(.+)'$")
	public void Switch_to_Tab(String SectionName) throws Throwable {

		wrap.wait(1000);
		switchFrame();
		String Sectionname = BaseProject.driver.findElement(By.xpath("//h2[text()='"+ SectionName + "']"));
		wrap.click(BaseProject.driver, Sectionname);
	}


	@When("^Basic: Read Excel$")
	public void readExcel()
			throws Throwable {
		utils.convertExcelToMap(excelPath, "Checkerorder.xls", "Sheet1");

		//String Titles = DBUtils.readColumnWithRowID("Title",BaseProject.scenarioID);
	}
	@When("^Basic: Clicking Save Button$")
	public void clickSaveButton() throws Throwable {

		String Save = com.getElementProperties("BasicData", "BasicData_Save_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, Save);

		try {

			wrap.click_wait(BaseProject.driver, Save);
			logger.info("********* Save Button Clicked *************");
			wait.until(ExpectedConditions.refreshed(null));

		}catch (Exception e){

			e.printStackTrace();
			logger.info("Unable to Click on Save Button");
		}
	}


	@When("^Basic: Fill Data in Customer Personal Details section$")
	public void fillDataInCustomerPersonalDetailsSection() throws Throwable {

		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String FullName1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
		String Mehalaya_NO= com.getElementProperties("BasicData", "BasicData_CustomerDetails_Mehalaya_radioNo");
		String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddNationality_Button");

		String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
		String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);
		String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code2", BaseProject.scenarioID);
		String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description2", BaseProject.scenarioID);
		String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID);
		String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code", BaseProject.scenarioID);
		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

		WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60, 500);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Customer Personal Detail']/../..")));
		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}

		wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
		logger.info("Title Entered");

		wrap.click_wait(BaseProject.driver, FirstName);
		wrap.type_wait(BaseProject.driver, First_Name, FirstName);
		logger.info("FirstName Entered");

		wrap.wait(1000);
		wrap.click_wait(BaseProject.driver, MiddleName);
		wrap.type_wait(BaseProject.driver, Middle_Name, MiddleName);
		logger.info("MiddleName Entered");

		wrap.click_wait(BaseProject.driver,LastName);
		wrap.type_wait(BaseProject.driver, Last_Name, LastName);
		logger.info("LastName Entered");

		wrap.click_wait(BaseProject.driver, DateOfBirth1);
		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB, DateOfBirth1);
		logger.info("DOB Entered");

		com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
		logger.info("Country of Birth Selected");

		com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);
		logger.info("Residency Country Selected");

		if(Wrapper.getValue(BaseProject.driver, Nationality1).equalsIgnoreCase(Nationality_Description1)) {
			logger.info("Nationality1 Already Exist !!!!!");
		} else {
			logger.info("Nationality1 Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);
			logger.info("Nationality1 Selected");
		}


		//*****************Adding Nationality2*****************//	

		/*if((Nationality_Description2!=null)) {

			wrap.wait(1000);
			wrap.click(BaseProject.driver, AddNationality);
			waitunlitVisiblityOfWebElement(Nationality2);
			com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality2,Nationality_Code2,Nationality_Description2);
			logger.info("Nationality2 Selected");
			}*/

		//wrap.scroll_to(BaseProject.driver, Mehalaya_NO);
		wrap.click_wait(BaseProject.driver,Mehalaya_NO);
		logger.info("Mehalaya Radio Button Selected");

		wrap.fluentWait(BaseProject.driver, ClientType);
		wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");
		String clientTypeValue = wrap.getExactAttribute(BaseProject.driver, ClientType).getAttribute("value");
		logger.info("Selected client type is: " + clientTypeValue);


		//******************Adding Alias*********************

		String Alias_First_Name2 = DBUtils.readColumnWithRowID("Alias First Name2", BaseProject.scenarioID);
		String Alias_Middle_Name2 = DBUtils.readColumnWithRowID("Alias Middle Name2", BaseProject.scenarioID);
		String Alias_Last_Name2 = DBUtils.readColumnWithRowID("Alias Last Name2", BaseProject.scenarioID);
		String Alias_Type2 = DBUtils.readColumnWithRowID("Alias Type2", BaseProject.scenarioID);
		String Aliases2 = DBUtils.readColumnWithRowID("Alias(es)2", BaseProject.scenarioID);
		String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
		String Aliases = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);

		String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1");
		String AliasPreviousName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_1");
		String AddAliasButton = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddAlias_Button");
		String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasType_2");
		String AliasFirstName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_2");
		String AliasMiddleName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_2");
		String AliasLastName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_2");
		String AliasPreviousName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_2");
		String Aliassection = com.getElementProperties("BasicData", "Aliassection");
		String NoAlias = com.getElementProperties("BasicData", "BasicData_CustomerDeatils_NoAliasAvailable");

		wrap.scroll_to(BaseProject.driver, Aliassection);  
		String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
		if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

			String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
			if (AliasSection.equals("false")) {
				wrap.click(BaseProject.driver, Aliassection);

			}

			/*wrap.click(BaseProject.driver, AddAliasButton);
			logger.info("Alias Add Button Clicked");*/

			if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1"))) {	
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
				String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
				logger.info("Selected Alias type is: " + AliasValue);

				switch(Alias_Type){

				case "AKA (also known as)":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName)));
					wrap.type(BaseProject.driver, Alias_First_Name, AliasFirstName);
					logger.info("Alias FirstName Entered");

					wrap.type(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
					logger.info("Alias MiddleName Entered");

					wrap.type(BaseProject.driver, Alias_Last_Name, AliasLastName);
					logger.info("Alias LastName Entered");

					break;

				case "Previous Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Aliases Name Entered");

					break;

				case "CCMS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Aliases Name Entered");

					break;

				case "RLS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Aliases Name Entered");

					break;
				}
				/*
	            logger.info("The Alias Info Add Alias Value is Present as: " + Alias_Type2);

	            if (Alias_Type2.equalsIgnoreCase("AKA (also known as)")||Alias_Type2.equalsIgnoreCase("Previous Name")||Alias_Type2.equalsIgnoreCase("CCMS Relationship Name")
	            		||Alias_Type2.equalsIgnoreCase("RLS Relationship Name")) {

		            wrap.wait(1000); 
		            wrap.click(BaseProject.driver, AddAliasButton);

		            wrap.wait(2000);
		            wrap.selectFromDropDown(BaseProject.driver, AliasType2, Alias_Type2, "BYVISIBLETEXT");
		            String AliasValue2 = wrap.getExactAttribute(BaseProject.driver, AliasType2).getAttribute("value");
		            logger.info("Selected Alias type is: " + AliasValue2);

		            switch(Alias_Type2){

		            		case "AKA (also known as)":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName2)));
		                        wrap.type(BaseProject.driver, Alias_First_Name2, AliasFirstName2);
		                        logger.info("Alias FirstName2 Entered");

		                        wrap.type(BaseProject.driver, Alias_Middle_Name2, AliasMiddleName2);
		                        logger.info("Alias MiddleName2 Entered");

		                        wrap.type(BaseProject.driver, Alias_Last_Name2, AliasLastName2);
		                        logger.info("Alias LastName2 Entered");

		            			break;

		            		case "Previous Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("Aliases Name2 Entered");

		                        break;

		            		case "CCMS Relationship Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("Aliases Name2 Entered");

		                        break;

		            		case "RLS Relationship Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("Aliases Name2 Entered");

		                        break;
		            }	

	            } else {
	            	logger.info("No Data Avaialble to Add Another Alias Info");
	            }*/

			} else {
				logger.info("Alias Information Not Entered");
			}

		} else {
			logger.info("Alias Info Section Not Available");
		}

	}

	@When("^Basic: validate optional and mandatory fields in Contact section$")
	public void validateFieldsInContactSection() throws Throwable {

		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
		String preferredContact = com.getElementProperties("BasicData", "BasicData_CustomerDetails_preferredContact");
		String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");

		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);
		String Area_cd = DBUtils.readColumnWithRowID("Area Code", BaseProject.scenarioID);
		String Preferred_contact = DBUtils.readColumnWithRowID("Contact_Preferred_contact", BaseProject.scenarioID);

		String Contactsection = com.getElementProperties("BasicData", "Contactsection");

		wrap.scroll_to(BaseProject.driver, ContactType);

		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}

		String CTD = Contact_type_Code;
		if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


			logger.info("************Going to Fill data of Mobile***********");
			com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
			logger.info("Contact Type Selected");

			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			logger.info("Contact Details Entered");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
			logger.info("ISD Code Selected");

			wrap.wait(1000);
			wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
			logger.info("Preferred Contact Checked");

			logger.info("**************Data Filled for Mobile***************");


		} else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {

			logger.info("*******************Going to Fill data of Resident*************************");
			com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
			logger.info("Contact Type Selected");

			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			logger.info("Contact Details Entered");

			wrap.wait(1000);
			wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
			logger.info("Preferred Contact Checked");

			logger.info("****************Data Filled for Resident*******************");

		} else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

			logger.info("***************Going to Fill data of Telephone*********************");
			com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
			logger.info("Contact Type Selected");

			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			logger.info("Contact Details Entered");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
			logger.info("ISD Code Selected");

			//wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

			wrap.click_wait(BaseProject.driver, Extension);
			wrap.type(BaseProject.driver, Extension_No, Extension);
			logger.info("Extension Entered");

			wrap.wait(1000);
			wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
			logger.info("Preferred Contact Checked");

			logger.info("***************Data Filled for Telephone*********************");
		}

		else {

			logger.info("************Going to Fill data of Contact Type with No CODE found**************");
			com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
			logger.info("Contact Type Selected");

			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
			logger.info("Contact Details Entered");

			logger.info("************Data Filled for Contact Type with No CODE found****************");
		}

	}

	@When("^Basic: Add Another Contact '(.*)'$")
	public void Add_Another_Contact(String i) throws Throwable {

		int j = Integer.parseInt(i);
		int k = j + 1;

		String ContactType = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='"+k+ "']//input[@id='ContactType']";
		String ContactDetails = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//input[@id='ContactNumber']";
		String ISDCode = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//select[@id='ISDCode']";
		String Extension = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//input[@id='ExtensionDetails']";
		String preferredContact = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//input[@id='PRContact" +k+ "']";

		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code"+ i, BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description"+ i, BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details"+ i, BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code"+ i, BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension"+ i, BaseProject.scenarioID);
		String Area_cd = DBUtils.readColumnWithRowID("Area Code"+ i, BaseProject.scenarioID);
		String Preferred_contact = DBUtils.readColumnWithRowID("Contact_Preferred_contact"+ i, BaseProject.scenarioID);
		String Contactsection = com.getElementProperties("BasicData", "Contactsection");

		wrap.wait(1000);
		if(Contact_type_Code.equalsIgnoreCase("MT1") || Contact_type_Code.equalsIgnoreCase("MT2") || Contact_type_Code.equalsIgnoreCase("MT3") || 
				Contact_type_Code.equalsIgnoreCase("MT4") || Contact_type_Code.equalsIgnoreCase("MO5") || Contact_type_Code.equalsIgnoreCase("MO6") || 
				Contact_type_Code.equalsIgnoreCase("MO7") || Contact_type_Code.equalsIgnoreCase("MO8") || Contact_type_Code.equalsIgnoreCase("MO9") || 
				Contact_type_Code.equalsIgnoreCase("MO1") || Contact_type_Code.equalsIgnoreCase("MO2") || Contact_type_Code.equalsIgnoreCase("MO3") || 
				Contact_type_Code.equalsIgnoreCase("MO4") || Contact_type_Code.equalsIgnoreCase("COL") || Contact_type_Code.equalsIgnoreCase("RE1") || 
				Contact_type_Code.equalsIgnoreCase("RE1") || Contact_type_Code.equalsIgnoreCase("RE3") || Contact_type_Code.equalsIgnoreCase("ERR") || 
				Contact_type_Code.equalsIgnoreCase("OE1") || Contact_type_Code.equalsIgnoreCase("OE2") || Contact_type_Code.equalsIgnoreCase("OE3") || 
				Contact_type_Code.equalsIgnoreCase("LM1") || Contact_type_Code.equalsIgnoreCase("OT1") || Contact_type_Code.equalsIgnoreCase("OT2") || 
				Contact_type_Code.equalsIgnoreCase("OT3") || Contact_type_Code.equalsIgnoreCase("OT4") || Contact_type_Code.equalsIgnoreCase("OT5") || 
				Contact_type_Code.equalsIgnoreCase("OT6") || Contact_type_Code.equalsIgnoreCase("OT7") || Contact_type_Code.equalsIgnoreCase("OT8") || 
				Contact_type_Code.equalsIgnoreCase("OT9") || Contact_type_Code.equalsIgnoreCase("OTA") || Contact_type_Code.equalsIgnoreCase("OTB") || 
				Contact_type_Code.equalsIgnoreCase("OTC") || Contact_type_Code.equalsIgnoreCase("LO1") || Contact_type_Code.equalsIgnoreCase("LO2") || 
				Contact_type_Code.equalsIgnoreCase("LO3") || Contact_type_Code.equalsIgnoreCase("RT3") || Contact_type_Code.equalsIgnoreCase("EMR") ||
				Contact_type_Code.equalsIgnoreCase("RT1")) {

			wrap.scroll_to(BaseProject.driver, Contactsection);

			WebElement AddContactButton = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']"));
			JavascriptExecutor Addcontact = (JavascriptExecutor)BaseProject.driver;
			Addcontact.executeScript("arguments[0].scrollIntoView(true);", AddContactButton);
			Addcontact.executeScript("arguments[0].click();", AddContactButton);
			logger.info("Add Button is Clicked for Contacts");

			wrap.wait(1000);
			String CTD = Contact_type_Code;
			if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


				logger.info("************Going to Fill data of Mobile***********");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
				logger.info("Contact Details Entered");

				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
				logger.info("ISD Code Selected");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
				logger.info("Preferred Contact Checked");

				logger.info("**************Data Filled for Mobile***************");


			} else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1") | CTD.equals("EMR")) {

				logger.info("*******************Going to Fill data of Resident*************************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
				logger.info("Contact Details Entered");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
				logger.info("Preferred Contact Checked");

				logger.info("****************Data Filled for Resident*******************");

			} else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")
					| CTD.equals("RT3") | CTD.equals("RT1") ) {

				logger.info("***************Going to Fill data of Telephone*********************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
				logger.info("Contact Details Entered");

				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
				logger.info("ISD Code Selected");

				//wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

				wrap.click_wait(BaseProject.driver, Extension);
				wrap.type(BaseProject.driver, Extension_No, Extension);
				logger.info("Extension Entered");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
				logger.info("Preferred Contact Checked");

				logger.info("***************Data Filled for Telephone*********************");
			}

			else {

				logger.info("************Going to Fill data of Contact Type with No CODE found**************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
				logger.info("Contact Details Entered");

				logger.info("************Data Filled for Contact Type with No CODE found****************");
			}

		} else {
			logger.info("Contact Type Code Did Not Match with DB!!!!!!");
			logger.info("Another Contact Not Added");
		}    

	}

	@When("^Basic: validate optional and mandatory fields in Employment section$")
	public void validateFieldsInEmploymentSection() throws Throwable {
		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
		String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);
		String ISICcode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
		String ISICDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);
		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");

		wrap.scroll_to(BaseProject.driver,Employmentsection );
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
		logger.info("Occupation Selected");

		com.suggestionTextBox_CodeDesc(BaseProject.driver, ISIC, ISICcode, ISICDescription);
		logger.info("ISIC Slected");

	}

	@When("^Basic: validate optional and mandatory fields in Document Details sectionss$")
	public void validate_optional_and_mandatory_fields_in_Document_Details_sections() throws Throwable {

		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);

		List<WebElement> docNo = wrap.getElements(BaseProject.driver, "//div[@pl_prop='.DocumentList']//li[contains(@hpref,'pDocumentList')]//table//tr//td[1]//span");


		for (int c = 0; c < docNo.size(); c++) {
			wrap.waitForElementVisibility(BaseProject.driver,docNo.get(c));
			myExecutor.executeScript("arguments[0].click();", docNo.get(c));
			wrap.wait(2000);
			String docName = docNo.get(c).getText();
			logger.info(docName);


			String documentCategory = wrap.getTextValue(BaseProject.driver, "//div[contains(@id,'SubSectionCustomerDetail') and contains(@style,'block')]//div[contains(@id,'SubSectionDocumentListBTR') and contains(@style,'block')]//table//tr//td//div[@bsimplelayout='true']/div[1]/div/span");
			String documentName = wrap.getTextValue(BaseProject.driver, "//div[contains(@id,'SubSectionCustomerDetail') and contains(@style,'block')]//div[contains(@id,'SubSectionDocumentListBTR') and contains(@style,'block')]//table//tr//td//div[@bsimplelayout='true']/div[2]/div/span");

			logger.info(c + ". Document category  : " + documentCategory);
			logger.info(c + ". Document name  : " + documentName);

			if (documentName.contains("AADHAAR")){
				wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("AADHAAR", BaseProject.scenarioID), "//div[contains(@id,'SubSectionCustomerDetail') and contains(@style,'block')]//div[contains(@id,'SubSectionDocumentListBTR') and contains(@style,'block')]//input[@id='DocumentNumber']");

			} else if (documentName.contains("PAN")) {
				wrap.type(BaseProject.driver, DBUtils.readColumnWithRowID("PAN", BaseProject.scenarioID), "//div[contains(@id,'SubSectionCustomerDetail') and contains(@style,'block')]//div[contains(@id,'SubSectionDocumentListBTR') and contains(@style,'block')]//input[@id='DocumentNumber']");
			}
		}


	}

	@When("^Basic: validate optional and mandatory fields in Document Details section$")
	public void validateFieldsInDocumentDetailsSection() throws Throwable {

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String DocumentExipryDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
		String DocumentNumber1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber1");
		String DocumentExipryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1");
		String DocumentSignatureDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate1");
		String DocumentNumber2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber2");
		String DocumentExipryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2");
		String DocumentSignatureDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate2");
		String DocumentNumber3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber3");
		String DocumentExipryDate3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate3");
		String DocumentSignatureDate3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate3");
		String DocumentNumber4 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber4");
		String DocumentExipryDate4 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate4");
		String DocumentSignatureDate4 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate4");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		String Document_Category1 = DBUtils.readColumnWithRowID("Document Category1", BaseProject.scenarioID);
		String Name_of_the_Document1 = DBUtils.readColumnWithRowID("Name of the Document1", BaseProject.scenarioID);
		String Document_Number1 = DBUtils.readColumnWithRowID("Document Number1", BaseProject.scenarioID);
		String Document_Expiry_Date1 = DBUtils.readColumnWithRowID("Document Expiry Date1", BaseProject.scenarioID);
		String Document_Signature_Date1 = DBUtils.readColumnWithRowID("Document Signature Date1", BaseProject.scenarioID);
		String Document_Number2 = DBUtils.readColumnWithRowID("Document Number2", BaseProject.scenarioID);
		String Document_Expiry_Date2 = DBUtils.readColumnWithRowID("Document Expiry Date2", BaseProject.scenarioID);
		String Document_Signature_Date2 = DBUtils.readColumnWithRowID("Document Signature Date2", BaseProject.scenarioID);
		String Document_Number3 = DBUtils.readColumnWithRowID("Document Number3", BaseProject.scenarioID);
		String Document_Expiry_Date3 = DBUtils.readColumnWithRowID("Document Expiry Date3", BaseProject.scenarioID);
		String Document_Signature_Date3 = DBUtils.readColumnWithRowID("Document Signature Date3", BaseProject.scenarioID);
		String Document_Number4 = DBUtils.readColumnWithRowID("Document Number4", BaseProject.scenarioID);
		String Document_Expiry_Date4 = DBUtils.readColumnWithRowID("Document Expiry Date4", BaseProject.scenarioID);
		String Document_Signature_Date4 = DBUtils.readColumnWithRowID("Document Signature Date4", BaseProject.scenarioID);
		String DocDetailSection = com.getElementProperties("BasicData", "Documentsection");

		wrap.scroll_to(BaseProject.driver, DocDetailSection);

		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, DocDetailSection);

		}

		List<WebElement> Doclist = BaseProject.driver.findElements(By.xpath("//div[@pl_prop='.DocumentList']//li[contains(@hpref,'pDocumentList')]//table//tr//td[1]//span"));
		logger.info("Document section size:   "+Doclist.size());

		JavascriptExecutor Documentslist = ((JavascriptExecutor) BaseProject.driver);

		for(int i=1; i<=Doclist.size(); i++) {

			Documentslist.executeScript("arguments[0].click();", Doclist.get(i-1));

			wrap.wait(1000);
			String DocumentTab = Doclist.get(i-1).getText();
			logger.info("**********"+ DocumentTab + "*************");
			logger.info("Please be ensure The Document is Available from Document indexing !!!!!!!!");

			//String DocName = wrap.SelectedValueDropDown(BaseProject.driver,"//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+ i +"']//span[text()='Name of the Document']/parent::label/following-sibling::div//select");
			String DocName = Wrapper.getTextValue(BaseProject.driver,"//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+ i +"']//span[text()='Name of the Document']/parent::label/following-sibling::div/div/select");
			logger.info(i +". " + DocName);

			if(i==1) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 1 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
					logger.info("Document Number Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
					logger.info("Document Signatory Date Entered");

					if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate))){
						wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate)));
						wrap.type(BaseProject.driver, Document_Expiry_Date, DocumentExipryDate);
						logger.info("Document Expiry Date Entered");
					}
					else
					{
						logger.info("Expiry Date field is not present");
					}

				} else {
					logger.info("****** Documents Details Tab 1 Filled ************");
				}

			} else if(i==2) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 2 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number1, DocumentNumber1);
					logger.info("Document Number1 Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date1, DocumentSignatureDate1);
					logger.info("Document Signatory Date1 Entered");

					if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate1))){
						wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate1)));
						wrap.type(BaseProject.driver, Document_Expiry_Date1, DocumentExipryDate1);
						logger.info("Document Expiry Date1 Entered");
					}
					else
					{
						logger.info("Expiry Date field is not present");
					}
					

				} else {
					logger.info("****** Documents Details Tab 2 Filled ************");
				}

			} else if(i==3) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 3 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number2, DocumentNumber2);
					logger.info("Document Number2 Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date2, DocumentSignatureDate2);
					logger.info("Document Signatory Date2 Entered");

					if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate2))){
						wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate2)));
						wrap.type(BaseProject.driver, Document_Expiry_Date2, DocumentExipryDate2);
						logger.info("Document Expiry Date2 Entered");
					}
					else
					{
						logger.info("Expiry Date field is not present");
					}
					

				} else {
					logger.info("****** Documents Details Tab 3 Filled ************");
				}

			} else if(i==4) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 4 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number3, DocumentNumber3);
					logger.info("Document Number3 Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date3, DocumentSignatureDate3);
					logger.info("Document Signatory Date3 Entered");

					if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate3))){
						wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate3)));
						wrap.type(BaseProject.driver, Document_Expiry_Date3, DocumentExipryDate3);
						logger.info("Document Expiry Date3 Entered");
					}
					else
					{
						logger.info("Expiry Date field is not present");
					}
					

				} else {
					logger.info("****** Documents Details Tab 4 Filled ************");
				}

			} else if(i==5) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 5 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number4, DocumentNumber4);
					logger.info("Document Number4 Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date4, DocumentSignatureDate4);
					logger.info("Document Signatory Date4 Entered");

					if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate4))){
						wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate4)));
						wrap.type(BaseProject.driver, Document_Expiry_Date4, DocumentExipryDate4);
						logger.info("Document Expiry Date4 Entered");
					}
					else
					{
						logger.info("Expiry Date field is not present");
					}
					

				} else {
					logger.info("****** Documents Details Tab 5 Filled ************");
				}

			} else {
				logger.info("*********** No Document Tab Found *************");
			}

		}
	}

	@When("^Basic: Fill Data in Customer Personal Details section for ETB$")
	public void Fill_Data_in_Customer_Personal_Details_section_for_ETB() throws Throwable {

		String Existing_AccNo = DBUtils.readColumnWithRowID("ETBAccountNumber", BaseProject.scenarioID);
		String Existing_RelNo = DBUtils.readColumnWithRowID("RelationshipNo", BaseProject.scenarioID);

		String ExistingAccNo = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ExistingAccountNumber_TextBox_XPATH");
		String AccInfo_SearchButton = com.getElementProperties("BasicData", "BasicData_CustomerDeatils_AccInfo_Search_Button");

		String AccInfo_Select_checkbox = "//td[div[span[contains(text(),'"+ Existing_RelNo +"')]]]/preceding-sibling::td[1]/div/input[@type='checkbox']";
		String AccInfo_IsPrimary_checkbox = "//td[div[span[contains(text(),'"+ Existing_RelNo +"')]]]/following-sibling::td[2]/div/input[@type='checkbox']";
		String AccInfo_AddButton = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AccInfo_Add_Button");
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String FullName1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
		String Mehalaya_NO= com.getElementProperties("BasicData", "BasicData_CustomerDetails_Mehalaya_radioNo");
		String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddNationality_Button");

		String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
		String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);
		String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code2", BaseProject.scenarioID);
		String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description2", BaseProject.scenarioID);
		String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID);
		String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code", BaseProject.scenarioID);
		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

		WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60, 500);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Account Information']/../..")));
		String AccountInformationSection = com.getElementProperties("BasicData", "AccountInformationSection");
		String AccInfosection = BaseProject.driver.findElement(By.xpath("//h2[text()='Account Information']/../..")).getAttribute("aria-expanded");
		if (AccInfosection.equals("false")) {
			wrap.click(BaseProject.driver, AccountInformationSection);

		}

		wrap.type_wait(BaseProject.driver, Existing_AccNo, ExistingAccNo);
		logger.info("Existing Account Number Entered");

		wrap.click_wait(BaseProject.driver, AccInfo_SearchButton);
		logger.info("Account Information Search Button Clicked");

		wrap.wait(2000);
		List<WebElement> ExistinRelNo = BaseProject.driver.findElements(By.xpath("//tr[th[div[div[div[contains(text(),'Existing Relationship No')]]]]]/following-sibling::tr/td[2]/div/span"));
		logger.info(ExistinRelNo.size());

		wrap.wait(2000);
		for(int i=0; i<ExistinRelNo.size(); i++) {

			String Actual_RelNo = ExistinRelNo.get(i).getText();

			if(Actual_RelNo.equalsIgnoreCase(Existing_RelNo)) {

				wrap.click_wait(BaseProject.driver, AccInfo_Select_checkbox);
				wrap.click_wait(BaseProject.driver, AccInfo_IsPrimary_checkbox);
				wrap.click_wait(BaseProject.driver, AccInfo_AddButton);
				logger.info("Checkbox Selected and ADD Button clicked");

			} else {

				logger.info(" Existing Realtionship.No Did NOT Match");
			}
		}

		wrap.wait(3000);

		if(wrap.SelectedValueDropDown(BaseProject.driver, Title).equalsIgnoreCase(Titles)) {
			logger.info("ETB-Title Already Exist !!!!!!");	
		} else {
			logger.info("ETB-Title Not Exist!!!");
			wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
			logger.info("ETB-Title Entered");
		}

		if(Wrapper.getValue(BaseProject.driver, FirstName).equalsIgnoreCase(First_Name)) {	
			logger.info("ETB-FirstName Already Exist !!!!!!");	
		} else {
			logger.info("ETB-FirstName Not Exist!!!");
			wrap.click_wait(BaseProject.driver, FirstName);
			wrap.type_wait(BaseProject.driver, First_Name, FirstName);
			logger.info("ETB-FirstName Entered");
		}

		if(Wrapper.getValue(BaseProject.driver, MiddleName).equalsIgnoreCase(Middle_Name)) {
			logger.info("ETB-MiddleName Already Exist !!!!!");
		} else {
			logger.info("ETB- MiddleName Not Exist!!!");
			wrap.click_wait(BaseProject.driver, MiddleName);
			wrap.type_wait(BaseProject.driver, Middle_Name, MiddleName);
			logger.info("ETB-MiddleName Entered");
		}

		if(Wrapper.getValue(BaseProject.driver, LastName).equalsIgnoreCase(Last_Name)) {
			logger.info("ETB-LastName Already Exist !!!!!");
		} else {
			logger.info("ETB- LastName Not Exist!!!");
			wrap.click_wait(BaseProject.driver,LastName);
			wrap.type_wait(BaseProject.driver, Last_Name, LastName);
			logger.info("LastName Entered");
		}

		if(Wrapper.getValue(BaseProject.driver, DateOfBirth1).equalsIgnoreCase(DOB)) {
			logger.info("ETB-DateOfBirth Already Exist !!!!!");
		} else {
			logger.info("ETB- DateOfBirth Not Exist!!!");
			wrap.click_wait(BaseProject.driver, DateOfBirth1);
			wrap.wait(1000);
			wrap.enterDate(BaseProject.driver, DOB, DateOfBirth1);
			logger.info("DateOfBirth Entered");
		}

		if(Wrapper.getValue(BaseProject.driver, CountryOfBirth).equalsIgnoreCase(Country_Of_Birth)) {
			logger.info("ETB-CountryOfBirth Already Exist !!!!!");
		} else {
			logger.info("ETB- CountryOfBirth Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
			logger.info("Country of Birth Selected");
		}

		if(Wrapper.getValue(BaseProject.driver, CountryOfResidence).equalsIgnoreCase(Residence_Country)) {
			logger.info("ETB-CountryOfResidence Already Exist !!!!!");
		} else {
			logger.info("ETB- CountryOfResidence Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);
			logger.info("Residency Country Selected");
		}


		if(Wrapper.getValue(BaseProject.driver, Nationality1).equalsIgnoreCase(Nationality_Description1)) {
			logger.info("ETB-Nationality1 Already Exist !!!!!");
		} else {
			logger.info("ETB- Nationality1 Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);
			logger.info("Nationality1 Selected");
		}


		//*****************Adding Nationality2*****************	

		/* if(Wrapper.getValue(BaseProject.driver, Nationality2).equalsIgnoreCase(Nationality_Description2)) {
	        logger.info("ETB-Nationality2 Already Exist !!!!!");
        } else {
        	logger.info("ETB- Nationality2 Not Exist!!!");
        	if((Nationality_Description2!=null)) {

				wrap.wait(2000);
				wrap.click(BaseProject.driver, AddNationality);
				waitunlitVisiblityOfWebElement(Nationality2);
				com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality2,Nationality_Code2,Nationality_Description2);
				logger.info("Nationality2 Selected");
			}
        }*/

		if(Wrapper.getValue(BaseProject.driver, Mehalaya_NO).equalsIgnoreCase("N")) {
			logger.info("ETB-Mehalaya_NO Already Exist !!!!!");
		} else {
			logger.info("ETB- Mehalaya_NO Not Exist!!!");
			wrap.scroll_to(BaseProject.driver, Mehalaya_NO);
			wrap.click_wait(BaseProject.driver,Mehalaya_NO);
			logger.info("Mehalaya Radio Button Selected");
		}

		String ClientTypeEnabled = BaseProject.driver.findElement(By.xpath("//div[@node_name='BasicInfo']//div[@section_index='8']//label")).getAttribute("for");
		logger.info("ClientTypeEnabled is: "+ ClientTypeEnabled);

		if(ClientTypeEnabled.equalsIgnoreCase("ClientType")) {
			if(Wrapper.getValue(BaseProject.driver, ClientType).equalsIgnoreCase(Client_Type)) {
				logger.info("ETB-ClientType Already Exist !!!!!");
			} else {
				logger.info("ETB- ClientType Not Exist!!!");
				wrap.fluentWait(BaseProject.driver, ClientType);
				wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");
				String clientTypeValue = wrap.getExactAttribute(BaseProject.driver, ClientType).getAttribute("value");
				logger.info("ETB- Selected client type is: " + clientTypeValue);
			}
		} else {
			logger.info("ETB-Client Type Field Not Present !!!");
		}


		//******************ETB -Adding Alias*********************

		String Alias_First_Name2 = DBUtils.readColumnWithRowID("Alias First Name2", BaseProject.scenarioID);
		String Alias_Middle_Name2 = DBUtils.readColumnWithRowID("Alias Middle Name2", BaseProject.scenarioID);
		String Alias_Last_Name2 = DBUtils.readColumnWithRowID("Alias Last Name2", BaseProject.scenarioID);
		String Alias_Type2 = DBUtils.readColumnWithRowID("Alias Type2", BaseProject.scenarioID);
		String Aliases2 = DBUtils.readColumnWithRowID("Alias(es)2", BaseProject.scenarioID);
		String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
		String Aliases = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);

		String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1");
		String AliasPreviousName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_1");
		String AddAliasButton = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
		String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasType_2");
		String AliasFirstName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_2");
		String AliasMiddleName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_2");
		String AliasLastName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_2");
		String AliasPreviousName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_2");
		String Aliassection = com.getElementProperties("BasicData", "Aliassection");

		wrap.scroll_to(BaseProject.driver, Aliassection);
		String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
		if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

			String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
			if (AliasSection.equals("false")) {
				wrap.click(BaseProject.driver, Aliassection);

			}

			if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1"))) {	
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
				String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
				logger.info("ETB- Selected Alias type is: " + AliasValue);

				switch(Alias_Type){

				case "AKA (also known as)":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName)));
					wrap.type(BaseProject.driver, Alias_First_Name, AliasFirstName);
					logger.info("ETB- Alias FirstName Entered");

					wrap.type(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
					logger.info("ETB- Alias MiddleName Entered");

					wrap.type(BaseProject.driver, Alias_Last_Name, AliasLastName);
					logger.info("ETB- Alias LastName Entered");

					break;

				case "Previous Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("ETB- Aliases Name Entered");

					break;

				case "CCMS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("ETB- Aliases Name Entered");

					break;

				case "RLS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("ETB- Aliases Name Entered");

					break;
				}

				/*logger.info("ETB- The Alias Info Add Alias Value is Present as: " + Alias_Type2);

	            if (Alias_Type2.equalsIgnoreCase("AKA (also known as)")||Alias_Type2.equalsIgnoreCase("Previous Name")||Alias_Type2.equalsIgnoreCase("CCMS Relationship Name")
	            		||Alias_Type2.equalsIgnoreCase("RLS Relationship Name")) {

		            wrap.wait(1000); 
		            wrap.click(BaseProject.driver, AddAliasButton);

		            wrap.wait(2000);
		            wrap.selectFromDropDown(BaseProject.driver, AliasType2, Alias_Type2, "BYVISIBLETEXT");
		            String AliasValue2 = wrap.getExactAttribute(BaseProject.driver, AliasType2).getAttribute("value");
		            logger.info("ETB- Selected Alias type is: " + AliasValue2);

		            switch(Alias_Type2){

		            		case "AKA (also known as)":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName2)));
		                        wrap.type(BaseProject.driver, Alias_First_Name2, AliasFirstName2);
		                        logger.info("ETB- Alias FirstName2 Entered");

		                        wrap.type(BaseProject.driver, Alias_Middle_Name2, AliasMiddleName2);
		                        logger.info("ETB- Alias MiddleName2 Entered");

		                        wrap.type(BaseProject.driver, Alias_Last_Name2, AliasLastName2);
		                        logger.info("ETB- Alias LastName2 Entered");

		            			break;

		            		case "Previous Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("ETB- Aliases Name2 Entered");

		                        break;

		            		case "CCMS Relationship Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("ETB- Aliases Name2 Entered");

		                        break;

		            		case "RLS Relationship Name":

		            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
		                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
		                        logger.info("ETB- Aliases Name2 Entered");

		                        break;
		            }	

	            } else {
	            	logger.info("ETB- No Data Avaialble to Add Another Alias Info");
	            }*/

			} else {
				logger.info("ETB- Alias Information Not Entered");
			}

		} else {
			logger.info("ETB- Alias Info Section Not Available");
		}
	}


	@When("^Basic: validate optional and mandatory fields in Contact section for ETB$")
	public void validate_optional_and_mandatory_fields_in_Contact_section_for_ETB() throws Throwable {

		/*String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
        String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
        String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
        String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
        String preferredContact = com.getElementProperties("BasicData", "BasicData_CustomerDetails_preferredContact");
        String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");*/

		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);
		String Area_cd = DBUtils.readColumnWithRowID("Area Code", BaseProject.scenarioID);
		String Preferred_contact = DBUtils.readColumnWithRowID("Contact_Preferred_contact", BaseProject.scenarioID);
		String Contactsection = com.getElementProperties("BasicData", "Contactsection");
		String ContactTypes = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");

		wrap.scroll_to(BaseProject.driver, ContactTypes);

		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}

		List<WebElement> Contactlist = BaseProject.driver.findElements(By.xpath("//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@pl_prop='.Contacts']//li[contains(@hpref,'pContacts')]//table//tr//td[1]//span"));
		logger.info("Contact List are: "+Contactlist.size());

		JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
		for(int i=0; i<Contactlist.size(); i++) {

			wrap.wait(1000);
			jse.executeScript("arguments[0].click();", Contactlist.get(i));
			logger.info("Going to Click on Contact List -" + i);

			int k= i+1;
			String ContactType = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='"+k+ "']//input[@id='ContactType']";
			String ContactDetails = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//input[@id='ContactNumber']";
			String ISDCode = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//select[@id='ISDCode']";
			String Extension = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[contains(@id,'ContactInfo')]/table[@pl_index='" +k+ "']//input[@id='ExtensionDetails']";
			String preferredContact = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//input[@id='PRContact" +k+ "']";


			if(i==0 || i==1 || i==2 ||i==3 || i==4) {

				String CTD = Wrapper.getValue(BaseProject.driver, ContactType);
				if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


					logger.info("************Going to Fill data of Mobile***********");
					com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
					logger.info("Contact Type Selected");

					wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
					logger.info("Contact Details Entered");

					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
					logger.info("ISD Code Selected");

					wrap.wait(1000);
					wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
					logger.info("Preferred Contact Checked");

					logger.info("**************Data Filled for Mobile***************");


				} else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {

					logger.info("*******************Going to Fill data of Resident*************************");
					com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
					logger.info("Contact Type Selected");

					wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
					logger.info("Contact Details Entered");

					wrap.wait(1000);
					wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
					logger.info("Preferred Contact Checked");

					logger.info("****************Data Filled for Resident*******************");

				} else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

					logger.info("***************Going to Fill data of Telephone*********************");
					com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
					logger.info("Contact Type Selected");

					wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
					logger.info("Contact Details Entered");

					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");
					logger.info("ISD Code Selected");

					//wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

					wrap.click_wait(BaseProject.driver, Extension);
					wrap.type(BaseProject.driver, Extension_No, Extension);
					logger.info("Extension Entered");

					wrap.wait(1000);
					wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
					logger.info("Preferred Contact Checked");

					logger.info("***************Data Filled for Telephone*********************");
				}

				else {

					logger.info("************Going to Fill data of Contact Type with No CODE found**************");
					com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description);
					logger.info("Contact Type Selected");

					wrap.type(BaseProject.driver, Contact_Details, ContactDetails);
					logger.info("Contact Details Entered");

					wrap.wait(1000);
					wrap.checkBoxSelect(BaseProject.driver, Preferred_contact, preferredContact);
					logger.info("Preferred Contact Checked");

					logger.info("************Data Filled for Contact Type with No CODE found****************");
				}
			}

		} 	  
	}

	@When("^Basic: validate optional and mandatory fields in Employment section for ETB$")
	public void validate_optional_and_mandatory_fields_in_Employment_section_for_ETB() throws Throwable {
		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
		String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);
		String ISICcode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
		String ISICDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);

		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
		wrap.scroll_to(BaseProject.driver, Employmentsection);

		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		if(Wrapper.getValue(BaseProject.driver, Occupation).equalsIgnoreCase(OccupationDescription)) {
			logger.info("ETB-Occupation Already Exist !!!!!");
		} else {
			logger.info("ETB- Occupation Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
			logger.info("ETB-Occupation Selected");
		}

		if(Wrapper.getValue(BaseProject.driver, ISIC).equalsIgnoreCase(ISICDescription)) {
			logger.info("ETB-ISIC Already Exist !!!!!");
		} else {
			logger.info("ETB- ISIC Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, ISIC, ISICcode, ISICDescription);
			logger.info("ETB-ISIC Slected");
		}

	}

	@When("^Basic: validate optional and mandatory fields in Document Details section for ETB$")
	public void validate_optional_and_mandatory_fields_in_Document_Details_section_for_ETB() throws Throwable {

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String DocumentExipryDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
		String DocumentNumber1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber1");
		String DocumentExipryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1");
		String DocumentSignatureDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate1");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		String Document_Category1 = DBUtils.readColumnWithRowID("Document Category1", BaseProject.scenarioID);
		String Name_of_the_Document1 = DBUtils.readColumnWithRowID("Name of the Document1", BaseProject.scenarioID);
		String Document_Number1 = DBUtils.readColumnWithRowID("Document Number1", BaseProject.scenarioID);
		String Document_Expiry_Date1 = DBUtils.readColumnWithRowID("Document Expiry Date1", BaseProject.scenarioID);
		String Document_Signature_Date1 = DBUtils.readColumnWithRowID("Document Signature Date1", BaseProject.scenarioID);
		String DocDetailSection = com.getElementProperties("BasicData", "Documentsection");

		wrap.scroll_to(BaseProject.driver, DocDetailSection);

		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, DocDetailSection);

		} 

		List<WebElement> Doclist = BaseProject.driver.findElements(By.xpath("//div[@pl_prop='.DocumentList']//li[contains(@hpref,'pDocumentList')]//table//tr//td[1]//span"));
		logger.info(Doclist.size());

		JavascriptExecutor Documentslist = ((JavascriptExecutor) BaseProject.driver);

		for(int i=1; i<=Doclist.size(); i++) {

			Documentslist.executeScript("arguments[0].click();", Doclist.get(i-1));

			wrap.wait(1000);
			String DocumentTab = Doclist.get(i-1).getText();
			logger.info("**********"+ DocumentTab + "*************");

			String DocName = Wrapper.getTextValue(BaseProject.driver,"//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+ i +"']//span[text()='Name of the Document']/parent::span/following-sibling::div/span");
			logger.info(i +". " + DocName);

			if(i==1) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 1 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
					logger.info("Document Number Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
					logger.info("Document Signatory Date Entered");

					wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate)));
					wrap.type(BaseProject.driver, Document_Expiry_Date, DocumentExipryDate);
					logger.info("Document Expiry Date Entered");

				} else {
					logger.info("****** Documents Details Tab 1 Filled ************");
				}

			} else if(i==2) {

				if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
						||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
						||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

					logger.info("*************** Filling Document Tab 2 ****************");
					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Number1, DocumentNumber1);
					logger.info("Document Number1 Entered");

					wrap.wait(1000);
					wrap.type(BaseProject.driver, Document_Signature_Date1, DocumentSignatureDate1);
					logger.info("Document Signatory Date1 Entered");

					wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate1)));
					wrap.type(BaseProject.driver, Document_Expiry_Date1, DocumentExipryDate1);
					logger.info("Document Expiry Date1 Entered");

				} else {
					logger.info("****** Documents Details Tab 2 Filled ************");
				}

			} else {
				logger.info("*********** No Document Tab Found *************");
			}

		}
	}

	@When("^Basic: validate optional and mandatory fields in Banking Service Details section$")
	public void validate_optional_and_mandatory_fields_in_Banking_Service_Details_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String EmbossedDebitCardName = com.getElementProperties("BasicData", "BasicData_BankingServiceDetail_EmbossedDebitCardName_TextBox_ID");


		String Bankingsection = com.getElementProperties("BasicData", "Bankingsection");
		String BankingSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Banking Service Details']/../..")).getAttribute("aria-expanded");
		if (BankingSection.equals("false")) {
			wrap.click(BaseProject.driver, Bankingsection);

		}

		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
		String Embossed = DBUtils.readColumnWithRowID("Embossed Debit Card Name", BaseProject.scenarioID);



		/*String MandatoryErrorMsg = com.getElementProperties("BasicData", "Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);*/


		wrap.type(BaseProject.driver, Embossed, EmbossedDebitCardName);
		/*if (MandErrMsg.equals("Industry"))
	    {
	    	logger.info("Values cannot be blank for ISIC");
	    }*/
		wrap.screenShot(BaseProject.driver, screenShotPath, "EmbossedDebitCardName");
	}


	@When("^Basic: click on Personal Details tab$")
	public void click_on_Personal_Details_tab() throws Throwable {
		wrap.wait(1000);
		switchFrame();
		// Write code here that turns the phrase above into concrete actions
		String cust_details = com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH");
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, cust_details)));
		wrap.click(BaseProject.driver, cust_details);
	}
	@When("^Basic: validate optional and mandatory fields in Product Details section$")
	public void validate_optional_and_mandatory_fields_in_Product_Details_section() throws IOException, InterruptedException {
		// Write code here that turns the phrase above into concrete actions

		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


		String Productsection = com.getElementProperties("BasicData", "Productsection");
		String ProductSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
		if (ProductSection.equals("false")) {
			wrap.click(BaseProject.driver, Productsection);

		}

		//convertExcelToMap("Sheet1");
		//    utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
		String Product_Category = DBUtils.readColumnWithRowID("Product Category", BaseProject.scenarioID);
		String Product_Code = DBUtils.readColumnWithRowID("Product Code", BaseProject.scenarioID);

		wrap.click(BaseProject.driver, ProductDetails);
		wrap.selectFromDropDown(BaseProject.driver, ProductCategory, Product_Category, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ProductCategory");
		wrap.selectFromDropDown(BaseProject.driver, ProductCode, Product_Code, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ProductCode");


	}

	/*@When("^Basic: validate optional and mandatory fields in A/C Setup section$")
	public void validate_optional_and_mandatory_fields_in_AC_Setup_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Purpose=com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
		String AccReqType=com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
		String AccNum=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
		String AccCurrency=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");
		String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
		String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");


	 //  utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
		//convertExcelToMap("Sheet1");
		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

		String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);



		String ACsection=com.getElementProperties("BasicData", "ACsection");
		String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
		if(ACSection.equals("false"))
		{
		  wrap.click(BaseProject.driver, ACsection);

		}


//Ram Implementation

	       String products = com.getElementProperties("BasicData", "differentproductselections");
	       List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
	       for(WebElement pro: listOfProduct){
	              pro.click();




		wrap.wait(1000);
		String ProductCategory = new Select(BaseProject.driver.findElement(By.id("ProductCategory"))).getFirstSelectedOption().getText();

	//	wrap.wait(1000);



		if(!ProductCategory.equalsIgnoreCase("CREDIT CARD"))
		{

			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

		}

	//	wrap.wait(1000);

		if(ProductCategory.equalsIgnoreCase("TERM DEPOSITS"))
		{

			wrap.type(BaseProject.driver, Minimum_Clearing_Balance, MinClearBal);

		}
		else
		{

			wrap.click(BaseProject.driver, AccReqType);
			//Actions a=new Actions(BaseProject.driver);
			WebElement element=BaseProject.driver.findElement(By.id("IsAccountType"));
			Select docname=new Select(element);
			List<WebElement> docnames=docname.getOptions();


			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

		//	wrap.wait(1000);
			if(Account_Request_Type.equalsIgnoreCase("Existing"))
			{
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");

			}


	//		wrap.typeInSuggestionTextbox(BaseProject.driver, AccCurrency, "code", Account_Currency);



			if(!Account_Request_Type.equalsIgnoreCase("DEFAULT"))
			{
				wrap.wait(2000);
				WebElement element1=BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
				JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
				myExecutor.executeScript("arguments[0].click();", element1);
				myExecutor.executeScript("arguments[0].value='"+Account_Number+"';", element1);
				wrap.wait(3000);

				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);

			}
		}
	       }
	}

	 */
	@When("^Basic: validate optional and mandatory fields in A/C Setup section$")
	public void validate_optional_and_mandatory_fields_in_AC_Setup_section() throws Throwable {

		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

		String ACsection = com.getElementProperties("BasicData", "ACsection");
		/*String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
	        if(ACSection.equals("false"))
	        {
	               wrap.click(BaseProject.driver, ACsection);

	        }
		 */

		String products = com.getElementProperties("BasicData", "differentproductselections");
		// List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
		// for(WebElement pro: listOfProduct){

		/*String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+i+"]";
	            String Purpose="xpath=(//select[@id='Purpose'])["+Pur+"]";
	            String AccReqType="xpath=(//*[@id='IsAccountType'])["+ActR+"]";
	            String AccNum="xpath=(//input[@id='AccountNumber'])["+AccNu+"]";
	            String AccCurrency="xpath=(//input[@id='Currency'])["+i+"]";
	            String ServiceType ="xpath=(//*[@id='NatureOfServices'])["+i+"]";
	            String MinClearBal ="xpath=(//*[@id='MinimumClearingBalance'])["+Min+"]";*/


		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		String Purpose = "xpath=(//select[@id='Purpose'])";
		String AccReqType = "xpath=(//*[@id='IsAccountType'])";
		String AccNum = "xpath=(//input[@id='AccountNumber'])[2]";
		String AccCurrency = "xpath=(//input[@id='Currency'])[2]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";

		logger.info(productCatagory);
		logger.info(Purpose);
		logger.info(AccReqType);
		logger.info(AccNum);
		logger.info(AccCurrency);
		logger.info(ServiceType);
		logger.info(MinClearBal);


		// JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
		//executor.executeScript("arguments[0].click();", pro);
		// pro.click();
		//com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

		//wrap.wait(3000);
		//logger.info("(//select[@id='ProductCategory'])["+j+"]");
		//    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");

		//String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+j+"]")).getText().trim();
		wrap.waitForElementVisibility(BaseProject.driver,"(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)",20 );
		String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)")).getText().trim();
		logger.info("Product is" + ProductCategory);

		// j++;
		switch (ProductCategory) {
		case "CREDIT CARD":

			wrap.click(BaseProject.driver, AccReqType);
			//wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				//wrap.wait(1500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");

				wrap.wait(1500);
				com.suggestionTextBox_CodeDesc(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");

				wrap.wait(1500);
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
			}

			/* if(Account_Request_Type.equalsIgnoreCase("New"))
	                       {
	                              //wrap.wait(500);
	                              //wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                              wrap.wait(500);
	                              com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency_Code,Account_Currency);
	      	                   	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
	                       }*/

			/* if(!Account_Request_Type.equalsIgnoreCase("New"))
	                       {
	                              wrap.wait(500);
	                              wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                            	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
	                       }
			 */
			if (Account_Request_Type.equalsIgnoreCase("Insta")) {

				com.suggestionTextBox_CodeDesc(BaseProject.driver, AccCurrency, Account_Currency, Account_Currency_Code);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");

				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
			}

			break;
		case "CURRENT ACCOUNT":
			logger.info("Moved to CA");
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(1500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");


				wrap.wait(1500);
				com.suggestionTextBox_CodeDesc(BaseProject.driver, AccCurrency, Account_Currency, Account_Currency_Code);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");

				wrap.wait(1500);
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


			}

			break;
		case "SAVINGS ACCOUNT":
			logger.info("Moved to SA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(1500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}

			if (Account_Request_Type.equalsIgnoreCase("New")) {

				Boolean isBlindPresent = BaseProject.driver.findElements(By.xpath("//input[@id='Currency']")).size() == 1;
				if(isBlindPresent) {
					AccCurrency = "xpath=(//input[@id='Currency'])";
				}
				logger.info(AccCurrency);

				wrap.wait(1500);
				//commented out the below code because INR is always the default value
				//wrap.SelectAutosuggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency_Code);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
			}

			break;

		case "TERM DEPOSITS":
			logger.info("Moved to TD");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
			com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			break;
		case "PERSONAL LOAN":

			logger.info("Moved to PL");
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(1500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}

			break;

		case "MORTGAGE LOAN":
			break;
		case "PROMOTIONAL PACKAGES":
			break;

		default:

			try {
				if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
					wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
					//Pur++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
				{

					wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
					if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						wrap.wait(1500);
						wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}


			try {
				if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
					wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

				}
			} catch (Exception e) {
				System.out.println(e);
			}
			break;

		}
	}


	@When("^Basic: click on Application Details tab$")
	public void click_on_Application_Details_tab() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//wrap.wait(2000);
		//switchFrame();
		String Prod_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
		wrap.waitForElementVisibility(BaseProject.driver, Prod_details,20);
		wrap.click(BaseProject.driver, Prod_details);
		wrap.screenShot(BaseProject.driver, screenShotPath, "App_details");
	}

	@When("^Basic: validate optional and mandatory fields in Bank Use section in Application Tab$")
	public void validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		//wrap.wait(1000);
		//utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");

		//DBUtils.convertDBtoMap("bdquery");
		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");
		String countryofopening = com.getElementProperties("BasicData", "BasicData_AppDetail_CountryOfAccountOpening");


		String Sorucing_ID = DBUtils.readColumnWithRowID("Sorucing ID", BaseProject.scenarioID);
		String Referral_ID = DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID);
		String Acquisition_Channel = DBUtils.readColumnWithRowID("Acquisition Channel", BaseProject.scenarioID);
		String Fast_track_Flag = DBUtils.readColumnWithRowID("Fast track Flag", BaseProject.scenarioID);
		String Application_Branch = DBUtils.readColumnWithRowID("Application Branch", BaseProject.scenarioID);


		String Banksection = com.getElementProperties("BasicData", "Bankusesection");
		wrap.waitForElementVisibility(BaseProject.driver, Banksection,20);
		String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
		if (BankSection.equals("false")) {
			wrap.click(BaseProject.driver, Banksection);

		}

		//wrap.wait(500);

		wrap.type(BaseProject.driver, Sorucing_ID, Sorucingid);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Sorucing_ID");


		//wrap.wait(2000);



		wrap.type(BaseProject.driver, Referral_ID, Referralid);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Referralid");
		wrap.wait(1000);

		wrap.selectFromDropDown(BaseProject.driver, AqCode, Acquisition_Channel, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Acquisition_Channel");

		/*wrap.wait(1000);
		String countryopen=BaseProject.driver.findElement(By.xpath("//input[@id='CountryOfAccountOpening']")).getAttribute("value").toString().trim();
		logger.info(countryopen);
		if(countryopen.contains("IN")){logger.info("Country is defaulted to INDIA");}*/

		//wrap.wait(500);

		wrap.selectFromDropDown(BaseProject.driver, FasttrackFlag, Fast_track_Flag, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "FasttrackFlag");

		//wrap.wait(500);

		wrap.selectFromDropDown(BaseProject.driver, Branch, Application_Branch, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Application_Branch");


	}


	@When("^Basic: validate optional and mandatory fields in AC Setup Details section in Application Tab$")
	public void validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		String ACsection = com.getElementProperties("BasicData", "ACsection");
		wrap.waitForElementVisibility(BaseProject.driver,ACsection,20);
		String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
		if (ACSection.equals("false")) {
			wrap.click(BaseProject.driver, ACsection);

		}
	}


	@When("^Basic: validate Action in Customer Detail Section$")
	public void validate_Action_and_Remarks_fields_in_Customer_Detail_section()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		//	switchFrame();
		String Action = com.getElementProperties("BasicData",
				"BasicData_Action_DropDown_ID");
		String Remarks = com.getElementProperties("BasicData",
				"BasicData_Remarks_TextArea_ID");


		wrap.selectFromDropDown(BaseProject.driver, Action, "Refer To RM", "BYVISIBLETEXT");
		logger.info("Refer to RM is selected");
		wrap.selectFromDropDown(BaseProject.driver, Action, "Completed", "BYVISIBLETEXT");
		logger.info("Complete is selected");
	}

	@When("^Basic: Select Refer to RM$")
	public void select_ReferToRM()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		String Action = com.getElementProperties("BasicData",
				"BasicData_Action_DropDown_ID");


		wrap.selectFromDropDown(BaseProject.driver, Action, "Refer To RM", "BYVALUE");
		logger.info("Refer to RM is selected");
	}


	@When("^Basic: validate Remarks fields in Customer Detail Section$")
	public void validate_Remarks_fields_in_Customer_Detail_section() throws Throwable {

		//        switchFrame();

		String Action = com.getElementProperties("BasicData",
				"BasicData_Action_DropDown_ID");

		String Remarks = com.getElementProperties("BasicData", "BasicData_Remarks_TextArea_ID");

		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

		WebElement w = BaseProject.driver.findElement(By.xpath(Action));
		logger.info(w.getTagName());
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", w.findElement(By.xpath("//option[@value='Completed']")), "selected", "true");


		//		utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		//String remarks = DBUtils.readColumnWithRowID("Remarks",BaseProject.scenarioID);

		//        wrap.selectFromDropDown(BaseProject.driver, Action, "Completed", "BYVISIBLETEXT");

		//wrap.type(BaseProject.driver, "Completed", Action);

		//wrap.typeToTextBox(BaseProject.driver, "Completed", Remarks);
	}


	@When("^Basic: validate Cancel buttons in Basic Data Section$")
	public void validate_Cancel_buttons_in_Basic_Data_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Cancel = com.getElementProperties("BasicData", "BasicData_Cancel_Button_XPATH");


		wrap.click(BaseProject.driver, Cancel);

	}


	@When("^Basic: validate Submit buttons in Basic Data Section$")
	public void validate_Submit_buttons_in_Basic_Data_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		// wrap.switch_to_default_Content(BaseProject.driver);
		String Submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, Submit);
		wrap.wait(500);
		wrap.click(BaseProject.driver, Submit);
		logger.info("Submit Button Clicked");
		wrap.wait(12000);


	}


	@When("^Basic: validate Save buttons in Basic Data Section$")
	public void validate_Save_buttons_in_Basic_Data_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//switchFrame();

		String Save = com.getElementProperties("BasicData", "BasicData_Save_Button_XPATH");
		try {
			wrap.click(BaseProject.driver, Save);
			wrap.wait(4000);
		}catch (Exception e){
			e.printStackTrace();
		}
	}


	@When("^Basic: verify Save Cancel and Submit buttons in Basic Data Section of Multiple Applicant$")
	public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Cancel = com.getElementProperties("BasicData",
				"BasicData_Cancel_Button_XPATH");
		String Submit = com.getElementProperties("BasicData",
				"BasicData_Submit_Button_XPATH");
		String Save = com.getElementProperties("BasicData",
				"BasicData_Save_Button_XPATH");

		com.validateFiledVisible(BaseProject.driver, Cancel);
		com.validateFiledVisible(BaseProject.driver, Submit);
		com.validateFiledVisible(BaseProject.driver, Save);

		String clickplus = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
		wrap.click(BaseProject.driver, clickplus);
		wrap.click(BaseProject.driver, clickplus);
		com.validateFiledVisible(BaseProject.driver, Cancel);
		com.validateFiledVisible(BaseProject.driver, Submit);
		com.validateFiledVisible(BaseProject.driver, Save);

	}

	// 18/03/2017 - Scenario 5

	@When("^Basic: verify Co_Applicants Add and Delete buttons in Customer Detail Section$")
	public void verify_Co_Applicants_Add_Delete_buttons_in_Customer_Detail_section()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
		String Delete = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_CoapplicantRemove_Button_XPATH");


		clickOnCustomerDetailsTab();
		wrap.wait(500);

		com.validateFiledEnable(BaseProject.driver, Delete);
		wrap.wait(500);

		for (int i = 1; i <= 4; i++) {


			WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
			JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
			js.executeScript("arguments[0].click();", element1);
			wrap.wait(500);

		}


		WebElement element2 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Delete this tab ']"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].click();", element2);
		wrap.wait(500);


	}

	@When("^Basic: validate add/Delete button for Primary applicants for ETB $")
	public void validate_Add_Delete_primary1() throws Throwable {
		String cust_details = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
		wrap.click(BaseProject.driver, cust_details);
		String Add_primary = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");
		String DeleteButton = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_CoapplicantRemove_Button_XPATH");
		String primaryapptext = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_primaryapplicant_text");
		String coapptext = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_primaryapplicant_text");
		if (primaryapptext.contains("Primary Applicant"))
			logger.info("It contains primary applicant");

		wrap.click(BaseProject.driver, Add_primary);
		if (coapptext.contains("Co-Applicant"))
			logger.info("It contains Co-Applicant");

		wrap.click(BaseProject.driver, Add_primary);
		if (coapptext.contains("Co-Applicant"))
			logger.info("It contains Co-Applicant");

		wrap.click(BaseProject.driver, DeleteButton);
		if (primaryapptext.contains("Primary Applicant")
				&& coapptext.contains("Co-Applicant"))
			logger.info("It contains primary and co-applicant");

		wrap.click(BaseProject.driver, DeleteButton);
		if (primaryapptext.contains("Primary Applicant"))
			logger.info("It contains primary applicant");

	}


	@Given("^Basic: Verify Multiple Products in Basic Data Capture$")
	public void multipleProductSelect() throws IOException, InterruptedException {
		//	utils.convertExcelToMap(excelPath,"ProductCatalogue_Testdata_Sheet1.xls","ProdCat");


		wrap.screenShot(BaseProject.driver, screenShotPath, "List of Products");

		utils.convertExcelToMap(excelPath, "NewBDTestDataSheet.xls", "Sheet1");

		String product1 = DBUtils.readColumnWithRowID("ProductCode_Description", BaseProject.scenarioID);

		logger.info("product1 ===== " + product1);
		List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(" , ")));
		logger.info("myList ===== " + myList);
		for (int i = 0; i < myList.size(); i++) {
			String EachProduct = myList.get(i).trim();
			logger.info(EachProduct);

		}

		int a = 0;

		List<String> allproductExcel = new ArrayList<String>(Arrays.asList(product1.split(" , ")));

		for (String eachproductExcel : allproductExcel) {
			logger.info("Product from Excel: " + eachproductExcel);

			List<WebElement> allproductBasicData = BaseProject.driver.findElements(By.xpath("//li[contains(@tabbedrepeatid,'SubSectionProductDetailsBTR')]//nobr/span"));

			for (WebElement eachproductBasicData : allproductBasicData) {
				String productBasicData = eachproductBasicData.getText();
				logger.info("Product from Basic Data: " + productBasicData);

				if (eachproductExcel.contains(productBasicData)) {
					logger.info("Products Selected in Product Catelogue: " + eachproductExcel + "is avaialble in Basic Data: " + productBasicData);
					a = 1;
					break;
				} else {
					a = 0;
				}

			}

			if (a == 0) {
				logger.info("Products Selected in Product Catelogue is not avaialble in Basic Data");
				Assert.fail();
			}
		}
	}


	@When("^Basic: Resident not allowed for PIS NRO/NRE products$")
	public void validate_Resident_Notallowed_PIS_NRONRE_Products() throws Throwable {

		wrap.wait(3000);

		String errormessage = BaseProject.driver.findElement(By.xpath("(//div/span[text()='Primary Applicant Country of Residence should not be IN for NR products'])[3]")).getText();

		logger.info("Retrived Error message" + errormessage);
		// List<WebElement>errormessages= BaseProject.driver.findElements(By.xpath("//div[@bsimplelayout='true']/div//div[@class='content-inner ']/div[@class='field-item dataValueRead']/span[text()='Primary Applicant Country of Residence should not be IN for NR products']"));

		if (errormessage.contains("Residence should not be IN for NR products")) {
			logger.info(" Primary Applicant Country of Residence should not be IN for NR products Error message shows successfully");
		} else {
			logger.info("Error message for Primary Applicant Country of Residence should not be IN for NR products not shown");
			Assert.fail();
		}
	}


	@When("^Basic: Non-Resident not allowed for NDPMS products$")
	public void validate_NonResident_Notallowed_NDPMS_Products() throws Throwable {

		String cust_details = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_CustomerDetails_Button_XPATH");

		wrap.click(BaseProject.driver, cust_details);


		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']")).click();

		WebElement element = BaseProject.driver.findElement(By.id("CountryOfResidenceDescription"));
		((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
		logger.info("Moved to Country of Residence");


		wrap.wait(2000);
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, CountryOfResidence)));
		com.selectInSuggestionBox(BaseProject.driver, CountryOfResidence, "MY", "MALAYSIA");


		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();


		wrap.wait(3000);

		String errormessage = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Non-Resident User Not allowed for 371 - NDPMS Linked Savings Account Product')])[3]")).getText();
		logger.info("Retrieved Error message:" + errormessage);
		wrap.wait(3000);

		if (errormessage.contains("User Not allowed for 371")) {
			logger.info(" Non-Resident User Not allowed for 371 Error message shows successfully");
		} else {
			logger.info("Retrieved Error Message:" + errormessage);
			logger.info("Error message for Non-Resident User Not allowed for 371 not shown");
			Assert.fail();
		}

	}

	@When("^Basic: verify restriction SanctionedCountry$")
	public void verify_restriction_SanctionedCountry() throws Throwable {


		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactDetailsText = "//span[text()='Contact Details']";


		String errormessage = "//*[text()='Please Do Not Provide Sanction Email ID']";

		String expectederror = "Please Do Not Provide Sanction Email ID";


		switchFrame();

		wrap.wait(1000);
		wrap.scroll_to(BaseProject.driver, ContactType);
		com.mobileSuggestionTextBox(BaseProject.driver, ContactType, "EMR", "Personal Email Address");


		// Cuba

		wrap.wait(2000);
		wrap.type(BaseProject.driver, "Test@gov.CU", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		String actualerror = wrap.getTextValue(BaseProject.driver, errormessage);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);


		// Iran


		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.type(BaseProject.driver, "Test@gov.IR", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);

		// North Korea


		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.type(BaseProject.driver, "Test@gov.KP", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);


		// South Sudan


		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.type(BaseProject.driver, "Test@gov.SS", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);


		// Sudan

		wrap.wait(2000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.type(BaseProject.driver, "Test@gov.SD", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);


		// Syria

		wrap.wait(2000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.type(BaseProject.driver, "Test@gov.SY", ContactDetails);
		wrap.click(BaseProject.driver, ContactDetailsText);
		wrap.wait(2000);
		logger.info(actualerror);
		Assert.assertEquals(expectederror, actualerror);

	}

	@When("^Basic: Enter Country of residence to Non-Residence$")
	public void enter_CountryofResidence_to_nonResidence() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		String cust_details = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
		wrap.click(BaseProject.driver, cust_details);


		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']")).click();

		WebElement element = BaseProject.driver.findElement(By.id("CountryOfResidenceDescription"));
		((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);
		logger.info("Moved to Country of Residence");


		wrap.wait(2000);
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		wrap.wait(1000);
		com.selectInSuggestionBox(BaseProject.driver, CountryOfResidence, "SG", "SINGAPORE");
	}


	@When("^Basic: Select NDPS Product in Product Details section$")
	public void select_NDPSProduct() throws IOException, InterruptedException {
		// Write code here that turns the phrase above into concrete actions

		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


		wrap.click(BaseProject.driver, ProductDetails);

		wrap.click(BaseProject.driver, ProductCategory);
		wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "SAVINGS ACCOUNT", "BYVISIBLETEXT");
		wrap.wait(3000);
		wrap.click(BaseProject.driver, ProductCode);
		wrap.selectFromDropDown(BaseProject.driver, ProductCode, "371 - NDPMS Linked Savings Account", "BYVISIBLETEXT");


	}


	@When("^Basic: Select NRO Product in Product Details section$")
	public void select_NROProduct() throws IOException, InterruptedException {
		// Write code here that turns the phrase above into concrete actions

		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


		wrap.click(BaseProject.driver, ProductDetails);
		wrap.click(BaseProject.driver, ProductCategory);
		wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "SAVINGS ACCOUNT", "BYVISIBLETEXT");
		wrap.wait(3000);
		wrap.click(BaseProject.driver, ProductCode);
		wrap.selectFromDropDown(BaseProject.driver, ProductCode, "350 - PIS NRO ACCOUNT", "BYVISIBLETEXT");


	}

	// Scenario 70
	@When("^Basic: verify Guardian Applicants in Basic Data Capture Section for ETB$")
	public void verify_Guardian_Applicants_Basic_Data_Capture_Section()
			throws Throwable {

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/*Vijaywrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);

		/*clickOnCustomerDetailsTab();
		wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		Actions action = new Actions(BaseProject.driver);
		action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();
		 */

		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		/*String MandatoryErrorMsg = com.getElementProperties("BasicData",
				"Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */

		//wrap.wait(3000);

		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");


		/*	if (MandErrMsg.equals("ProfileType")) {
			logger.info("Values cannot be blank for Profile Type");
		}*/
		wrap.wait(4000);
		wrap.click(BaseProject.driver, relationTypeCode);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "Guarantor",
				"BYVISIBLETEXT");
		/*if (MandErrMsg.equals("RelatedPartyType")) {
			logger.info("Values cannot be blank for Relation Type Code");
		}*/
		wrap.wait(4000);
		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();
		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();
	}

	@When("^Basic: verify to add another Guardian Applicants in Basic Data Capture Section for ETB$")
	public void verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section()
			throws Throwable {
		verify_Guardian_Applicants_Basic_Data_Capture_Section();
		String submit = com.getElementProperties("BasicData",
				"BasicData_Submit_Button_XPATH");
		wrap.click(BaseProject.driver, submit);
		String clntdrop = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_ProfileType_Client_XPATH");
		if (clntdrop.contains("CLIENT"))
			logger.info("Primary applicant defaulted to CLIENT type");

	}

	@When("^Basic: verify Guardian Applicants in Basic Data Capture Section for NTB$")
	public void verify_Guardian_Applicants_Basic_Data_Capture_Section_NTB()
			throws Throwable {
		verify_Guardian_Applicants_Basic_Data_Capture_Section();
	}

	@When("^Basic: verify to add another Guardian Applicants in Basic Data Capture Section for NTB$")
	public void verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section_NTB()
			throws Throwable {
		verify_Addextra_Guardian_Applicants_Basic_Data_Capture_Section();
	}


	// Scenario 71
	@When("^Basic: verify POA Applicants in Basic Data Capture Section for ETB$")
	public void verify_POA_Applicants_Basic_Data_Capture_Section()
			throws Throwable {
		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
		 wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);

		/*clickOnCustomerDetailsTab();
		wrap.wait(3000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a")).click();
		Actions action = new Actions(BaseProject.driver);
		action.doubleClick(BaseProject.driver.findElement(By.xpath("//span[text()='Primary Applicant']//ancestor::li/following-sibling::li//table[@id='TABHEADER']//a"))).build().perform();
		 */

		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		/*String MandatoryErrorMsg = com.getElementProperties("BlindData",
				"Mandatory_ErrorMsg");
		String MandErrMsg = wrap.getAttributeOfId(BaseProject.driver, MandatoryErrorMsg);
		 */

		//	wrap.wait(3000);

		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");


		wrap.wait(2000);
		wrap.click(BaseProject.driver, relationTypeCode);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, "POWER OF ATTORNEY",
				"BYVISIBLETEXT");
		wrap.wait(4000);
		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();
		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();


	}

	@When("^Basic: verify to add another POA Applicants in Basic Data Capture Section for ETB$")
	public void verify_Addextra_POA_Applicants_Basic_Data_Capture_Section()
			throws Throwable {
		verify_Guardian_Applicants_Basic_Data_Capture_Section();
		String submit = com.getElementProperties("BasicData",
				"BasicData_Submit_Button_XPATH");
		wrap.click(BaseProject.driver, submit);
		String clntdrop = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_ProfileType_Client_XPATH");
		if (clntdrop.contains("CLIENT"))
			logger.info("Primary applicant defaulted to CLIENT type");

	}

	@When("^Basic: verify POA Applicants in Basic Data Capture Section for NTB$")
	public void verify_POA_Applicants_Basic_Data_Capture_Section_NTB()
			throws Throwable {
		verify_POA_Applicants_Basic_Data_Capture_Section();
	}

	@When("^Basic: verify to add another POA Applicants in Basic Data Capture Section for NTB$")
	public void verify_Addextra_POA_Applicants_Basic_Data_Capture_Section_NTB()
			throws Throwable {
		verify_Addextra_POA_Applicants_Basic_Data_Capture_Section();
	}

	// Scenario 75

	@When("^Basic: Verify the ACTIONS dropdown options and its functions (ETB)$")
	public void Verify_Actions_Dropdown_forETB() throws Throwable {
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		//validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();
		validate_Action_and_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();

	}

	// Scenario 61

	@When("^Basic: verify Save Cancel and Submit buttons in Basic Data Section for NTB single$")
	public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section_NTB_Single()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		switchFrame();
		String Cancel = com.getElementProperties("BasicData",
				"BasicData_Cancel_Button_XPATH");
		String Submit = com.getElementProperties("BasicData",
				"BasicData_Submit_Button_XPATH");
		String Save = com.getElementProperties("BasicData",
				"BasicData_Save_Button_XPATH");

		logger.info("Save visibility" + com.validateFiledVisible(BaseProject.driver, Save));
		logger.info("Save visibility is passed");
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

		wrap.wait(2000);
		logger.info("Cancel visibility" + com.validateFiledVisible(BaseProject.driver, Cancel));
		logger.info("Cancel visibility is passed");
		logger.info("Submit visibility" + com.validateFiledVisible(BaseProject.driver, Submit));
		logger.info("Submit visibility is passed");


	}


	@When("^Basic: verify Save Cancel and Submit buttons in Basic Data Section for NTB Multiple$")
	public void verify_Save_Cancel_and_Submit_buttons_in_Basic_Data_section_NTB_Multiple()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Cancel = com.getElementProperties("BasicData",
				"BasicData_Cancel_Button_XPATH");
		String Submit = com.getElementProperties("BasicData",
				"BasicData_Submit_Button_XPATH");
		String Save = com.getElementProperties("BasicData",
				"BasicData_Save_Button_XPATH");


		verify_Co_Applicants_Add_Delete_buttons_in_Customer_Detail_section();

		logger.info("Save visibility" + com.validateFiledVisible(BaseProject.driver, Save));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

		wrap.wait(3000);
		logger.info("Cancel visibility" + com.validateFiledVisible(BaseProject.driver, Cancel));
		logger.info("Submit visibility" + com.validateFiledVisible(BaseProject.driver, Submit));


	}

	// Scenario 72

	@When("^Basic: validate optional and mandatory fields in Product Details section for ETB$")
	public void validate_optional_and_mandatory_fields_in_Product_Details_section_ETB()
			throws Throwable {
		validate_optional_and_mandatory_fields_in_Product_Details_section();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
	}

	@When("^Basic: validate optional and mandatory fields in Product Details section for NTB$")
	public void validate_optional_and_mandatory_fields_in_Product_Details_section_NTB()
			throws Throwable {
		validate_optional_and_mandatory_fields_in_Product_Details_section();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
	}

	// Scenario 73

	@When("^Basic: click on Customer Details tab for ETB$")
	public void click_on_Customer_Details_tab1() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		clickOnCustomerDetailsTab();
	}

	@When("^Basic: validate optional and mandatory fields in Customer Personal Details section for ETB$")
	public void validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section1()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		//validateFieldsInDocumentDetailsSection();

	}

	@When("^Basic: validate optional and mandatory fields in Customer Personal Details section for NTB$")
	public void validate_optional_and_mandatory_fields_in_Customer_Personal_Details_section2()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		//validateFieldsInDocumentDetailsSection();

	}

	// Scenario 74

	@When("^Basic: Verify the ACTIONS dropdown options and its functions (NTB)")
	public void Verify_Actions_Dropdown_forNTB() throws Throwable {
		Verify_Actions_Dropdown_forETB();

	}

	// Scenario 57

	@When("^Basic: Verify the Application status as WIP in Search page for ETB")
	public static void search(WebDriver driver, String appNumber)
			throws IOException, InterruptedException {

		String search = com.getElementProperties("Search", "search");
		String applicationid = com.getElementProperties("Search",
				"applicationid");
		String searchbutton = com
				.getElementProperties("Search", "searchbutton");
		String information = com.getElementProperties("Search", "information");
		String moreinfo = com.getElementProperties("Search", "moreinfo");

		wrap.click(BaseProject.driver, search);
		wrap.wait(500);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		wrap.typeToTextBox(BaseProject.driver, appNumber, applicationid);
		wrap.click(BaseProject.driver, searchbutton);
		wrap.wait(500);

		wrap.read_Table(BaseProject.driver, information);
		wrap.click(BaseProject.driver, moreinfo);
		wrap.switch_to_default_Content(BaseProject.driver);

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
		wrap.read_Table(BaseProject.driver, information);
		wrap.switch_to_default_Content(BaseProject.driver);

	}


	@When("^Basic: Accept Mandatory Field Alert")
	public void accept_Mandatory_Field_Alert() throws Throwable {

		BaseProject.driver.switchTo().defaultContent();
		logger.info("Switched to default content");
		wrap.wait(2000);
		BaseProject.driver.switchTo().alert().accept();


	}

	@When("^Basic: verify Coapplicant Applicants in Basic Data Capture Section for ETB$")
	public void verify_Coapplicant_Applicants_Basic_Data_Capture_Section()
			throws Throwable {
		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		//validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/*Vijay wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);


		wrap.wait(6000);


		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();
		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();



	}


	@When("^Basic: Validate Account No throws error if less than 11 in Customer Detail Section$")
	public void Validate_Account_No_field_in_Customer_Detail_Section() throws Throwable {
		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);
		String AccountNum = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		wrap.click(BaseProject.driver, AccountNum);
		/*	String maxLen = wrap.getElement(BaseProject.driver, AccountNum).getAttribute("maxlength");
		int maxLeng = Integer.parseInt(maxLen);
		 */
		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");
		//convertExcelToMap("Sheet1");

		String Acc_No = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);

		int acc = Acc_No.length();

		wrap.typeToTextBox(BaseProject.driver, Acc_No, AccountNum);
		int actTxtLen = wrap.getElement(BaseProject.driver, AccountNum).getAttribute("value").length();
		logger.info("The length of Account No is : " + actTxtLen);

		BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).click();
		wrap.wait(2000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "ExistingAccountNumber");

		if (actTxtLen == 11) {
			logger.info("Account No is Valid");

		} else {
			logger.info("Account No should be 11 digits");
		}


	}

	@When("^verify the applicant status in Application Search Basic Data$")
	public void verify_the_applicant_status_in_Application_Search_Basic_Data() throws Throwable {
		//String appnum=BaseProject.appId;

		utils.convertExcelToMap(excelPath, "ProductCatalogue_Testdata_Sheet1.xls", "ApplicationNo");
		String appnum = DBUtils.readColumnWithRowID("ApplicationId", BaseProject.scenarioID);
		String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
		String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
		String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
		String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
		BaseProject.driver.switchTo().defaultContent();
		wrap.wait(3000);
		wrap.click(BaseProject.driver, search_link);
		//wrap.wait(3000);
		switchFrame();
		wrap.wait(3000);
		wrap.type(BaseProject.driver, appnum, ApplicationNo);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AppNo");
		wrap.click(BaseProject.driver, serach_button);
		wrap.screenShot(BaseProject.driver, screenShotPath, "search");
		wrap.wait(1000);
		wrap.click(BaseProject.driver, moreInfo);
		wrap.screenShot(BaseProject.driver, screenShotPath, "moreinfo");
		switchFrame();
		wrap.wait(1000);
		String wbname = BaseProject.driver.findElement(By.xpath("//td[@data-attribute-name='Work Basket Name']//div")).getText();
		logger.info(wbname);
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("//a[text()='" + appnum + "']")).click();
		wrap.wait(1000);
		switchFrame();
		//String status=com.getElementProperties("BasicData", "Status_XPATH");
		wrap.wait(1000);
		String status = BaseProject.driver.findElement(By.xpath("//span[text()='Status']//following-sibling::div//a")).getText();
		logger.info(status);
		if (status.startsWith("WIP")) {
			logger.info("Status is displayed correctly");
			logger.info("Status is displayed with WIP");
			wrap.screenShot(BaseProject.driver, screenShotPath, "WIP");
		} else {
			logger.info("No status is with WIP");
			logger.info("Status is not displayed with WIP");
			wrap.screenShot(BaseProject.driver, screenShotPath, "WIP");
			//BaseProject.driver.quit();
			Assert.fail();
		}

	}

	@When("^Basic: verify Workbasket in application search before Basic Data completion$")
	public void verify_Workbasket_In_Application_Search_Before_Basic_Data_Completion() throws Throwable {
		String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
		String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
		String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
		String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
		BaseProject.driver.switchTo().defaultContent();
		wrap.wait(500);
		wrap.click(BaseProject.driver, search_link);
		//wrap.wait(3000);
		switchFrame();
		wrap.wait(500);
		wrap.type(BaseProject.driver, BaseProject.appId, ApplicationNo);
		wrap.click(BaseProject.driver, serach_button);
		wrap.wait(500);
		wrap.click(BaseProject.driver, moreInfo);
		wrap.wait(500);
		switchFrame();
		wrap.wait(500);

		String BasicData = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'BasicDataCapture')]")).getText();

		Assert.assertEquals("BasicDataCapture", BasicData);


	}


	@When("^Basic: verify Workbasket in application search after Basic Data completion$")
	public void verify_Workbasket_In_Application_Search_After_Basic_Data_Completion() throws Throwable {
		String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
		String ApplicationNo = com.getElementProperties("BasicData", "Application_ID");
		String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
		String moreInfo = com.getElementProperties("BasicData", "More_Info_XPATH");
		BaseProject.driver.switchTo().defaultContent();
		wrap.wait(500);
		wrap.click(BaseProject.driver, search_link);
		//wrap.wait(3000);
		switchFrame();
		wrap.wait(500);
		wrap.type(BaseProject.driver, "IN20170410000065", ApplicationNo);
		//wrap.type(BaseProject.driver,BaseProject.appId, ApplicationNo);
		wrap.click(BaseProject.driver, serach_button);
		wrap.wait(500);
		wrap.click(BaseProject.driver, moreInfo);
		wrap.wait(500);
		switchFrame();
		wrap.wait(500);


		/*WebElement table = BaseProject.driver.findElement(By.xpath("//table[@id='bodyTbl_right']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));

		for (WebElement row : rows) {

			List<WebElement> cells = row.findElements(By.tagName("td"));

			for (WebElement cell : cells) {

				if (!cell.getText().contains("BasicDataCapture"))

				{
					logger.info("Expected: Basic Data capture not avaialble in Application Search Workbaset");
			}
				else
				{
					logger.info("Basic Data capture still avaialble in Application Search Workbaset");
					BaseProject.driver.quit();
				}

		}
	}*/

		List<WebElement> irows = BaseProject.driver.findElements(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr"));
		int iRowsCount = irows.size();
		List<WebElement> icols = BaseProject.driver.findElements(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr//th"));
		int iColsCount = icols.size();
		logger.info("Selected web table has " + iRowsCount + " Rows and " + iColsCount + " Columns");
		logger.info("");


		for (int i = 1; i <= iRowsCount; i++) {

			for (int j = 1; j <= iColsCount; j++) {
				if (i == 1) {
					WebElement val = BaseProject.driver.findElement(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr[" + i + "]//th[" + j + "]"));
					String a = val.getText();
					System.out.print(a);

				} else {
					WebElement val = BaseProject.driver.findElement(By.xpath("//div[@id='modalWrapper']//div[@id='gridBody_right']//table//tr[" + i + "]//td[" + j + "]//span"));
					String a = val.getText();
					System.out.print(a);
				}
			}
			logger.info("");
		}

	}

	@When("^Basic: validate ISD Code default to 91 for Resident country is INDIA$")
	public void validate_ISDCode_Default_91_For_Residentcountry_INDIA()
			throws Throwable {


		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		waitunlitVisiblityOfWebElement(CountryOfResidence);
		com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, "IN", "INDIA");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryofResidence");

		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");


		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		String Contactsection = com.getElementProperties("BasicData", "Contactsection");


		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}


		String CTD = "Mobile No-1";
		if (CTD.equals("Mobile No-1") | CTD.equals("Mobile No-2") | CTD.equals("Mobile No-3") | CTD.equals("Mobile No-4") | CTD.equals("Mobile No.-5") | CTD.equals("Mobile No.-6") | CTD.equals("Mobile No.-7") | CTD.equals("Mobile No.-8") | CTD.equals("Mobile No.-9")) {

			wrap.click(BaseProject.driver, ContactType);
			wrap.wait(3000);
			wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");

			waitunlitVisiblityOfWebElement(ContactType);
			wrap.click(BaseProject.driver, ContactType);
			wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);


		}

		wrap.wait(2000);
		Select ISDValues = new Select(BaseProject.driver.findElement(By.id("ISDCode")));
		String Selectedvalue = ISDValues.getFirstSelectedOption().getText();
		logger.info("Defaulted value is:" + Selectedvalue);

		Assert.assertEquals(Selectedvalue, "91");
		logger.info("Defaulted to 91 successfully");

		wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");
	}


	@When("^Basic: validate ISD Code not default to 91 for Resident country is not INDIA$")
	public void validate_ISDCode_NotDefault_91_For_Residentcountry_Notas_INDIA()
			throws Throwable {


		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		waitunlitVisiblityOfWebElement(CountryOfResidence);
		com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, "MY", "MALAYSIA");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryofResidence");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");


		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		String Contactsection = com.getElementProperties("BasicData", "Contactsection");

		wrap.scroll_to(BaseProject.driver, Contactsection);
		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}

		wrap.click(BaseProject.driver, ContactType);
		wrap.wait(1000);
		wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);

		wrap.wait(2000);
		Select ISDValues = new Select(BaseProject.driver.findElement(By.id("ISDCode")));
		String Selectedvalue = ISDValues.getFirstSelectedOption().getText();
		logger.info("Defaulted value is:" + Selectedvalue);


		if (!Selectedvalue.equals("91")) {

			logger.info("Not Defaulted to 91 successfully");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");
		} else {
			logger.info("Defaulted to 91 wrongly");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode");
			Assert.fail();
		}
	}

	@When("^Basic: Enter Multiple Product Data in A/C Setup section$")
	public void enter_multiple_productData_in_AC_Setup_section() throws Throwable {

		validate_optional_and_mandatory_fields_in_AC_Setup_section();


		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Account_Number2 = DBUtils.readColumnWithRowID("Account Number2", BaseProject.scenarioID);

		if (!Account_Request_Type.equalsIgnoreCase("New")) {
			WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
			JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
			myExecutor.executeScript("arguments[0].click();", element1);
			myExecutor.executeScript("arguments[0].value='" + Account_Number2 + "';", element1);
		}


		validate_optional_and_mandatory_fields_in_AC_Setup_section();

		String Account_Number3 = DBUtils.readColumnWithRowID("Account Number3", BaseProject.scenarioID);
		if (!Account_Request_Type.equalsIgnoreCase("New")) {
			WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
			JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
			myExecutor.executeScript("arguments[0].click();", element1);
			myExecutor.executeScript("arguments[0].value='" + Account_Number3 + "';", element1);
		}


		validate_optional_and_mandatory_fields_in_AC_Setup_section();

		String Account_Number4 = DBUtils.readColumnWithRowID("Account Number4", BaseProject.scenarioID);

		if (!Account_Request_Type.equalsIgnoreCase("New")) {
			WebElement element1 = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']//ancestor::div[contains(@id,'OUTERFRAME')]//span[text()='Account Number']//ancestor::label//following-sibling::div//input[@type='text']"));
			JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
			myExecutor.executeScript("arguments[0].click();", element1);
			myExecutor.executeScript("arguments[0].value='" + Account_Number4 + "';", element1);
		}


	}

	@When("^Basic: verify the applicant using Account Number in Application Search '(.*)'$")
	public void verify_the_applicant_usingAccountNumber_in_Application_Search(String appNumber) throws Throwable {
		String search_link = com.getElementProperties("BasicData", "Search_link_XPATH");
		String AccountNumber = com.getElementProperties("BasicData", "AccountNumber_ID");
		String serach_button = com.getElementProperties("BasicData", "Search_Button_XPATH");
		String firstApplicant = com.getElementProperties("BasicData", "FirstApplicant");


		wrap.wait(3000);
		wrap.click(BaseProject.driver, search_link);
		switchFrame();
		wrap.wait(3000);
		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Number2 = DBUtils.readColumnWithRowID("Account Number2", BaseProject.scenarioID);
		String Account_Number3 = DBUtils.readColumnWithRowID("Account Number3", BaseProject.scenarioID);
		String Account_Number4 = DBUtils.readColumnWithRowID("Account Number4", BaseProject.scenarioID);

		wrap.type(BaseProject.driver, Account_Number, AccountNumber);
		wrap.click(BaseProject.driver, serach_button);
		String FirstApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
		Assert.assertEquals(appNumber, FirstApplicant);

		wrap.type(BaseProject.driver, Account_Number2, AccountNumber);
		wrap.click(BaseProject.driver, serach_button);
		String SecondApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
		Assert.assertEquals(appNumber, SecondApplicant);

		wrap.type(BaseProject.driver, Account_Number3, AccountNumber);
		wrap.click(BaseProject.driver, serach_button);
		String ThirdApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
		Assert.assertEquals(appNumber, ThirdApplicant);

		wrap.type(BaseProject.driver, Account_Number4, AccountNumber);
		wrap.click(BaseProject.driver, serach_button);
		String FourthApplicant = wrap.getTextValue(BaseProject.driver, firstApplicant);
		Assert.assertEquals(appNumber, FourthApplicant);

	}


	@When("^Basic: verify Coapplicant NON-CLEINT in Basic Data Capture Section$")
	public void verify_coapplicant_NonClient_Basic_Data_Capture_Section()
			throws Throwable {
		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
	 wrap.wait(1000);
	logger.info("Before scroll div section of the page");
	String divScroll = "//div[contains(@class,'right-panel-scroll')]";

	WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

	Actions a = new Actions(BaseProject.driver);

	for(int j=0; j<10; j++)
	{
		a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
	}
	wrap.wait(3000);
	logger.info("After scroll page");*/
		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].click();", element1);


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		wrap.wait(3000);
		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);


		wrap.selectFromDropDown(BaseProject.driver, profileType, "NON-CLIENT", "BYVISIBLETEXT");
		wrap.wait(3000);

		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();

		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();


	}

	@When("^Basic: verify Coapplicant in Basic Data Capture Section$")
	public void verify_coapplicant_Basic_Data_Capture_Section()
			throws Throwable {
		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		/* Vijay
		 wrap.wait(1000);
		logger.info("Before scroll div section of the page");
		String divScroll = "//div[contains(@class,'right-panel-scroll')]";

		WebElement divElement = BaseProject.driver.findElement(By.xpath(divScroll));

		Actions a = new Actions(BaseProject.driver);

		for(int j=0; j<10; j++)
		{
			a.sendKeys(divElement, Keys.ARROW_UP).sendKeys(Keys.UP).build().perform();
		}
		wrap.wait(3000);
		logger.info("After scroll page");*/
		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].click();", element1);


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		wrap.wait(3000);
		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, "CLIENT", "BYVISIBLETEXT");


		wrap.wait(4000);

		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();

		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();


	}

	@Given("^Basic: validate editable/non editable in Customer details$")
	public void validate_editable_non_editable_in_Customer_details() throws Throwable {

		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);
		String searchby = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		String acccurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");

		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");

		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		com.validateEditable1(BaseProject.driver, searchby, "searchby");
		com.validateEditable1(BaseProject.driver, accnumber, "accnumber");
		com.validateEditable1(BaseProject.driver, acccurrency, "acccurrency");

		com.validateEditable1(BaseProject.driver, Title, "Title");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Title-Editable");
		com.validateEditable1(BaseProject.driver, FirstName, "FirstName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "FirstName-Editable");
		com.validateEditable1(BaseProject.driver, MiddleName, "MiddleName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "MiddleName-Editable");
		com.validateEditable1(BaseProject.driver, LastName, "LastName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "LastName-Editable");
		com.validateEditable1(BaseProject.driver, DateOfBirth1, "DateOfBirth");
		wrap.screenShot(BaseProject.driver, screenShotPath, "DateofBirth-Editable");
		com.validateEditable1(BaseProject.driver, Nationality1, "Nationality");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Nationality-Editable");
		com.validateEditable1(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryofBirth-Editable");
		com.validateEditable1(BaseProject.driver, CountryOfResidence, "CountryOfResidence");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryofResidence-Editable");
		com.validateEditable1(BaseProject.driver, ClientType, "ClientType");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ClientType-Editable");


		wrap.scroll_to(BaseProject.driver, AliasType1);

		com.validateEditable1(BaseProject.driver, AliasType1, "AliasType");


		wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
		wrap.wait(2000);

		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType-Editable");

		com.validateEditable1(BaseProject.driver, AliasFirstName, "AliasFirstName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFN-Editable");
		com.validateEditable1(BaseProject.driver, AliasMiddleName, "AliasMiddleName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMN-Editable");
		com.validateEditable1(BaseProject.driver, AliasLastName, "AliasLastName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLN-Editable");


		com.validateEditable1(BaseProject.driver, ContactType, "ContactType");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType-Editable");

		wrap.click(BaseProject.driver, ContactType);
		wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "MT1", ContactType);

		com.validateEditable1(BaseProject.driver, ContactDetails, "ContactDetails");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails-Editable");
		wrap.wait(1000);
		try {
			com.validateEditable1(BaseProject.driver, ISDCode, "ISDCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode-Editable");
		} catch (Exception e) {

		}
		//	com.validateEditable1(BaseProject.driver,Extension,"Extension");

		com.validateEditable1(BaseProject.driver, Occupation, "Occupation");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation-Editable");
		com.validateEditable1(BaseProject.driver, ISIC, "ISIC");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC-Editable");

		/*		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);
		wrap.wait(1000);
		 */        //System.out.println("DocumentCategory--------------------"+DocumentCategory);
		/*	String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);
		 */
		com.validateEditable1(BaseProject.driver, DocumentCategory, "DocumentCategory");
		wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory-Editable");
		com.validateEditable1(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
		wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDocument-Editable");
		com.validateEditable1(BaseProject.driver, DocumentNumber, "DocumentNumber");
		wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber-Editable");
		com.validateEditable1(BaseProject.driver, IDExpiryDate1, "IDExpiryDate1");
		wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate-Editable");
		com.validateEditable1(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");
		wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate-Editable");


	}


	@Given("^Basic: validate editable/non editable in Product details$")
	public void validate_editable_non_editable_in_Product_details() throws Throwable {

		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		wrap.click(BaseProject.driver, ProductDetails);
		wrap.wait(1000);

		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
		String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
		String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
		String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
		String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
		String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");

		String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");

		//		com.validateEditable1(BaseProject.driver,ProductCategory,"ProductCategory");
		//		com.validateEditable1(BaseProject.driver,ProductCode,"ProductCode");
		//
		//		try{
		//			com.validateEditable1(BaseProject.driver,MinClearBal,"MinClearBal");
		//		}catch(Exception e )
		//		{
		//
		//		}


		try {


			String Campigncode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Campaigncode_Text_ID");

			com.validateEditable1(BaseProject.driver, Campigncode, "Campigncode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Campigncode-Editable");
			com.validateEditable1(BaseProject.driver, Purpose, "Purpose");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose-Editable");
			com.validateEditable1(BaseProject.driver, AccReqType, "AccReqType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType-Editable");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, "Existing", "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Existing-Editable");

			wrap.wait(2000);
			com.validateEditable1(BaseProject.driver, ServiceType, "ServiceType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType-Editable");
			com.validateEditable1(BaseProject.driver, AccCurrency, "AccCurrency");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccCurrency-Editable");


			com.validateEditable1(BaseProject.driver, AccNum, "AccNum");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccNum-Editable");
		} catch (Exception e) {
		}


	}


	@Given("^Basic: validate editable/non editable in Application details$")
	public void validate_editable_non_editable_in_Application_details() throws Throwable {

		String App_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
		wrap.click(BaseProject.driver, App_details);
		wrap.wait(3000);


		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");

		String AppCretDate = com.getElementProperties("BasicData", "BasicData_app_details_Application_AppCretDate");
		String ChannelRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_ChannelRef");
		String SourceRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_SourceRef");
		String SegmentCode = com.getElementProperties("BasicData", "BasicData_app_details_Application_SegmentCode");

		try {
			com.validateEditable1(BaseProject.driver, AppCretDate, "AppCretDate");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AppCretDate-Editable");

			com.validateEditable1(BaseProject.driver, Sorucingid, "Sorucingid");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Sorucingid-Editable");

			com.validateEditable1(BaseProject.driver, Referralid, "Referralid");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Referralid-Editable");

			com.validateEditable1(BaseProject.driver, ChannelRef, "ChannelRef");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ChannelRef-Editable");

			com.validateEditable1(BaseProject.driver, SourceRef, "SourceRef");
			wrap.screenShot(BaseProject.driver, screenShotPath, "SourceRef-Editable");


			com.validateEditable1(BaseProject.driver, AqCode, "AcquisitionCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AcquisitionCode-Editable");

			com.validateEditable1(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
			wrap.screenShot(BaseProject.driver, screenShotPath, "FasttrackFlag-Editable");

			com.validateEditable1(BaseProject.driver, Branch, "ApplicationBranch");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ApplicationBranch-Editable");

			com.validateEditable1(BaseProject.driver, ARMCode, "ARMCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ARMCode-Editable");

			com.validateEditable1(BaseProject.driver, SegmentCode, "SegmentCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "SegmentCode-Editable");
		} catch (Exception e) {

		}
	}


	@When("^Basic: Validate Mandatory fields in Customer Detail Section$")
	public void Validate_Mandatory_fields_in_Customer_Detail_Section() throws Throwable {
		switchFrame();
		wrap.wait(1000);
		String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, submit);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Submit");
		wrap.click(BaseProject.driver, submit);

		accept_Mandatory_Field_Alert();

		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);

		wrap.screenShot(BaseProject.driver, screenShotPath, "MandatoryFieldsErrorMessage");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Title_Mandmsg_XPATH"), "Title");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Firstname_Mandmsg_XPATH"), "First name");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Date_of_birth_Mandmsg_XPATH"), "DOB");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "CountryOfBirth_Mandmsg_XPATH"), "Country Of Birth");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Client_Type_Mandmsg_XPATH"), "Client Type");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Alias_Type_Mandmsg_XPATH"), "Alias Type");

		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Contact_Type_Mandmsg_XPATH"), "Contact Type");
		//	com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ISD_Type_Mandmsg_XPATH"), "ISD Code");

		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Occupation_Mandmsg_XPATH"), "Occupation");
		//com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ISIC_Mandmsg_XPATH"), "Occupation");


		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Doc_Category_Mandmsg"), "Document Category");
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Name_Of_Document_Mandmsg_XPATH"), "Name of the Document");

		//	com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Remarks_Mandmsg_XPATH"), "Remarks");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");

		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");

		wrap.scroll_to(BaseProject.driver, AliasType1);

		wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
		wrap.wait(2000);


		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}


		wrap.click(BaseProject.driver, DocumentCategory);
		//wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
		wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, "CLIENT ID  DOCUMENTS", "BYVISIBLETEXT");

		wrap.click(BaseProject.driver, NameoftheDocument);
		wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
		wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, "PASSPORT", "BYVISIBLETEXT");


		wrap.wait(1000);
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);

		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
		wrap.click(BaseProject.driver, DocumentSignatureDate);

		wrap.wait(3000);


		wrap.scroll_to(BaseProject.driver, submit);
		wrap.click(BaseProject.driver, submit);
		accept_Mandatory_Field_Alert();
		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);

		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "AliasFirstName_Mandmsg_XPATH"), "AliasFirstName");
		try {


			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "DocNumber_Mandmsg_XPATH"), "DocNumber");
			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ExpiryDate_Mandmsg_XPATH"), "DocExpiryDate");
		} catch (Exception e) {

		}
	}

	@When("^Basic: Validate Mandatory fields in Product Detail Section$")
	public void Validate_Mandatory_fields_in_Product_Detail_Section() throws Throwable {
		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		wrap.click(BaseProject.driver, ProductDetails);
		wrap.wait(4000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Submit");
		String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, submit);
		wrap.click(BaseProject.driver, submit);
		accept_Mandatory_Field_Alert();
		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);

		try {
			wrap.screenShot(BaseProject.driver, screenShotPath, "MandatoryFieldsErrorMessage");
			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Purpose_of_account_Mandmsg_XPATH"), "Purpose of account");
			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Account_Request_Type_Mandmsg_XPATH"), "Account Request Type");
			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Account_Number_Mandmsg_XPATH"), "Account Number");
		} catch (Exception e) {

		}
	}

	@When("^Basic: Validate Mandatory fields in Application Detail Section$")
	public void Validate_Mandatory_fields_in_Application_Detail_Section() throws Throwable {
		String Prod_details = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
		wrap.click(BaseProject.driver, Prod_details);
		wrap.wait(1000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Submit");
		String submit = com.getElementProperties("BasicData", "BasicData_Submit_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, submit);
		wrap.click(BaseProject.driver, submit);
		accept_Mandatory_Field_Alert();
		wrap.wait(1000);
		switchFrame();
		wrap.wait(1000);

		try {

			wrap.screenShot(BaseProject.driver, screenShotPath, "MandatoryFieldsErrorMessage");
			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Sourcing_Code_Mandmsg_XPATH"), "Sourcing ID");

			com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "Referral_Code_Mandmsg_XPATH"), "Referral ID");
		} catch (Exception e) {

		}
		com.IsMandatory(BaseProject.driver, com.getElementProperties("BasicData", "ARM_Code_Mandmsg_XPATH"), "ARM");
	}

	@When("^Basic: Validate alpha numeric fields in Customer Detail Section$")
	public void Validate_alpha_numeric_fields_in_Customer_Detail_Section() throws Throwable {


		String Remarks = com.getElementProperties("BasicData",
				"BasicData_Remarks_TextArea_ID");
		wrap.type(BaseProject.driver, "TEST", Remarks);

		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
		String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
		String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
		String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
		String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
		String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
		String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");

		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String searchby = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		String acccurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");


		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);


		com.validateAlphanumeric(BaseProject.driver, searchby, "searchby");
		wrap.screenShot(BaseProject.driver, screenShotPath, "searchby-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, accnumber, "Existing account number");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Existing account number-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, acccurrency, "Existing account currency");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Existing account currency-DataFormat");


		wrap.scroll_to(BaseProject.driver, Title);
		waitunlitVisiblityOfWebElement(Title);
		com.validateAlphanumeric(BaseProject.driver, Title, "Title");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Title-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, FirstName, "FirstName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "FirstName-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, MiddleName, "MiddleName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "MiddleName-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, LastName, "LastName");
		wrap.screenShot(BaseProject.driver, screenShotPath, "LastName-DataFormat");


		com.validateAlphanumeric(BaseProject.driver, Nationality1, "Nationality");


		wrap.screenShot(BaseProject.driver, screenShotPath, "Nationality-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryOfBirth-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, CountryOfResidence, "CountryOfResidence");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CountryOfResidence-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, ClientType, "ClientType");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ClientType-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, AliasType1, "AliasType1");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasType1-DataFormat");

		try {

			com.validateAlphanumeric(BaseProject.driver, AliasFirstName, "AliasFirstName");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, AliasMiddleName, "AliasMiddleName");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, AliasLastName, "AliasLastName");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName-DataFormat");

		} catch (Exception e) {

			com.validateAlphanumeric(BaseProject.driver, AliasNames1, "Alias Full Name");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Alias Full Name-DataFormat");
		}

		try {
			com.validateAlphanumeric(BaseProject.driver, ContactType, "ContactType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ContactDetails, "ContactDetails");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ISDCode, "ISDCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode-DataFormat");
			//	com.validateAlphanumeric(BaseProject.driver,Extension, "Extension");
		} catch (Exception e) {

			WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']"));
			element.click();
			com.validateAlphanumeric(BaseProject.driver, ContactType, "ContactType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ContactDetails, "ContactDetails");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ISDCode, "ISDCode");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISDCode-DataFormat");
			// com.validateAlphanumeric(BaseProject.driver,Extension, "Extension");
		}

		try {

			com.validateAlphanumeric(BaseProject.driver, Occupation, "Occupation");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ISIC, "ISIC");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC-DataFormat");
		} catch (Exception e) {
			WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']"));
			element.click();
			com.validateAlphanumeric(BaseProject.driver, Occupation, "Occupation");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, ISIC, "ISIC");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ISIC-DataFormat");
		}

		try {

			com.validateAlphanumeric(BaseProject.driver, DocumentCategory, "DocumentCategory");
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
			wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDocument-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, DocumentNumber, "DocumentNumber");
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber-DataFormat");
			com.validateDateFormat(BaseProject.driver, IDExpiryDate1, Document_Expiry_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate1-DataFormat");
			com.validateDateFormat(BaseProject.driver, DocumentSignatureDate, Document_Signature_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate-DataFormat");
		} catch (Exception e) {

			logger.info("Clicking Document Category Section");
			WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
			element.click();

			com.validateAlphanumeric(BaseProject.driver, DocumentCategory, "DocumentCategory");
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
			wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDocument-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, DocumentNumber, "DocumentNumber");
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber-DataFormat");

		}

		try {

			com.validateDateFormat(BaseProject.driver, IDExpiryDate1, Document_Expiry_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate1-DataFormat");
			com.validateDateFormat(BaseProject.driver, DocumentSignatureDate, Document_Signature_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate-DataFormat");
		} catch (Exception e) {
			logger.info("Clicking Document Category Section");
			WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));
			element.click();
			com.validateDateFormat(BaseProject.driver, IDExpiryDate1, Document_Expiry_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "IDExpiryDate1-DataFormat");
			com.validateDateFormat(BaseProject.driver, DocumentSignatureDate, Document_Signature_Date);
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentSignatureDate-DataFormat");

		}
		com.validateAlphanumeric(BaseProject.driver, Remarks, "Remarks");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks-DataFormat");
	}


	@When("^Basic: Validate alpha numeric fields in Product Detail Section$")
	public void Validate_alpha_numeric_fields_in_Product_Detail_Section() throws Throwable {

		String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
		String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
		String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
		String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
		String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
		String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");


		com.validateAlphanumeric(BaseProject.driver, ProductCategory, "ProductCategory");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, ProductCode, "ProductCode");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks-DataFormat");


		String Campigncode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Campaigncode_Text_ID");
		com.validateAlphanumeric(BaseProject.driver, Campigncode, "Campigncode");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks-DataFormat");


		try {
			com.validateAlphanumeric(BaseProject.driver, MinClearBal, "MinClearBal");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks-DataFormat");

			com.validateAlphanumeric(BaseProject.driver, Purpose, "Purpose of Account Opening");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose-DataFormat");
			com.validateAlphanumeric(BaseProject.driver, AccReqType, "AccReqType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType-DataFormat");


			wrap.click(BaseProject.driver, AccReqType);

			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, "Existing", "BYVISIBLETEXT");

			wrap.wait(2000);

			wrap.selectFromDropDown(BaseProject.driver, ServiceType, "Addition of Holder", "BYVISIBLETEXT");
			com.validateAlphanumeric(BaseProject.driver, ServiceType, "ServiceType");
			wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType-DataFormat");
		} catch (Exception e) {
		}
		try {
			com.validateAlphanumeric(BaseProject.driver, AccNum, "Acc Number");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccNum-DataFormat");
		} catch (Exception e) {

		}
		com.validateAlphanumeric(BaseProject.driver, AccCurrency, "Acc Currency");

	}


	@When("^Basic: Validate alpha numeric fields in Application Detail Section$")
	public void Validate_alpha_numeric_fields_in_Application_Detail_Section() throws Throwable {

		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");

		String AppCretDate = com.getElementProperties("BasicData", "BasicData_app_details_Application_AppCretDate");
		String ChannelRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_ChannelRef");
		String SourceRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_SourceRef");
		String SegmentCode = com.getElementProperties("BasicData", "BasicData_app_details_Application_SegmentCode");

		com.validateAlphanumeric(BaseProject.driver, AppCretDate, "AppCretDate");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AppCretDate-DataFormat");

		com.validateAlphanumeric(BaseProject.driver, Sorucingid, "Sorucingid");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Sorucingid-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, Referralid, "Referralid");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Referralid-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, AqCode, "AcquisitionCode");
		wrap.screenShot(BaseProject.driver, screenShotPath, "AcquisitionCode-DataFormat");

		com.validateAlphanumeric(BaseProject.driver, ChannelRef, "ChannelRef");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ChannelRef-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, SourceRef, "SourceRef");
		wrap.screenShot(BaseProject.driver, screenShotPath, "SourceRef-DataFormat");

		com.validateAlphanumeric(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
		wrap.screenShot(BaseProject.driver, screenShotPath, "FasttrackFlag-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, Branch, "Branch");
		wrap.screenShot(BaseProject.driver, screenShotPath, "Branch-DataFormat");
		com.validateAlphanumeric(BaseProject.driver, ARMCode, "ARM Code");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ARMCode-DataFormat");

		com.validateAlphanumeric(BaseProject.driver, SegmentCode, "SegmentCode");
		wrap.screenShot(BaseProject.driver, screenShotPath, "SegmentCode-DataFormat");

	}

	@Given("^Basic: select multiple products$")
	public void multipleProductSelectBasic() {
		try {
			String branchCode = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_BranchCode_TextBox_Id");
			String submit = com.getElementProperties("ProductCatalogue", "ProductCatalogue_OnBoarding_Submit_Button_XPATH");
			logger.info("BranchCode ===== " + branchCode);

			utils.convertExcelToMap(excelPath, "ProductCatalogue_Testdata_Sheet1.xls", "ProdCat");

			wrap.wait(1000);

			String branchCode1 = utils.readColumn("BrachCode", 0);
			logger.info("branchCode1 ===== " + branchCode1);
			String actualBranchCode = branchCode1.replaceAll(File.separator + ".0*$", "");
			logger.info("actualBranchCode ===== " + actualBranchCode);

			wrap.typeToTextBox(BaseProject.driver, actualBranchCode, branchCode);

			String product1 = utils.readColumn("ProductCode_Description", 0);
			logger.info("product1 ===== " + product1);
			List<String> myList = new ArrayList<String>(Arrays.asList(product1.split(",")));
			logger.info("myList ===== " + myList);
			String prdcode = com.getElementProperties("ProductCatalogue", "productCode");
			logger.info("prdcode ===== " + prdcode);
			logger.info("myList.get(0) ===== " + myList.get(0));
			for (int i = 0; i < myList.size(); i++) {
				String mycheckbox = prdcode.replace("**data**", myList.get(i));
				wrap.click(BaseProject.driver, mycheckbox);
			}

			wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, submit)));
			wrap.click(BaseProject.driver, submit);

			wrap.wait(2000);
		} catch (Exception e) {
			logger.info("The product is not getting selected" + e);
		}
	}

	@Given("Verify field order in Basic customer page1")
	public void verifybasicFieldOrder1() throws Throwable {
		Thread.sleep(2000);

		List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsB']//span[contains(text(),'Full name')]"));

		List<String> fieldLabels = new ArrayList<String>();

		for (WebElement we : fields) {

			fieldLabels.add(we.getText());
		}
		Iterator<String> it = fieldLabels.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

		BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order");

		wrap.screenShot(BaseProject.driver, screenShotPath, "CustomerDetailsFields");
	}

	@Given("Verify field order in Basic product page2")
	public void verifybasicFieldOrder2() throws Throwable {
		Thread.sleep(2000);
		List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsBB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsBB']//span[contains(text(),'Account Status')]"));

		List<String> fieldLabels = new ArrayList<String>();

		for (WebElement we : fields) {

			fieldLabels.add(we.getText());
		}
		Iterator<String> it = fieldLabels.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

		BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order2");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ProductDetailsFields");
	}

	@Given("Verify field order in Basic application page3")
	public void verifybasicFieldOrder3() throws Throwable {
		Thread.sleep(4000);
		List<WebElement> fields = BaseProject.driver.findElements(By.xpath("//div[@id='INNERDIV-SubSectionCaptureDetailsBBB']//label | //div[@id='INNERDIV-SubSectionCaptureDetailsBBB']//span[contains(text(),'Segment')]"));

		List<String> fieldLabels = new ArrayList<String>();

		for (WebElement we : fields) {

			fieldLabels.add(we.getText());
		}
		Iterator<String> it = fieldLabels.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

		BaseProject.verifyFieldOrder(fieldLabels, BaseProject.excelPath, "Basicorder.xls", "order3");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ApplicationDetailsFields");

	}


	@Given("^Basic Data Capture Customer Details tab Length Validation$")
	public void basic_Data_Capture_Customer_Details_tab_Length_Validation() throws IOException, InterruptedException {

		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
		String extenctionDetails = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
		String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
		String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
		String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
		String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");

		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
		String DateOfBirth2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");


		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String docExpireDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String docSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
		//String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		//String documentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		wrap.switch_to_default_Content(BaseProject.driver);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("PegaGadget1Ifr"));
		//wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

		String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");

		String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
		String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);
		String Nationality_Code2 = DBUtils.readColumnWithRowID("Nationality Code2", BaseProject.scenarioID);
		String Nationality_Description2 = DBUtils.readColumnWithRowID("Nationality Description2", BaseProject.scenarioID);
		String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth", BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country", BaseProject.scenarioID);
		String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
		String Alias = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
		String Nationality_Code = DBUtils.readColumnWithRowID("Nationality Code", BaseProject.scenarioID);
		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);
		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
		String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);

		String isiccode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
		String isicDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));


		String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
		String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
		String maxInputVal1 = "4561024958";

		String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
		String maxdate = "0202199002020202020202";

		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");

		//	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxInputVal1, accnumber);


		wrap.TextFieldMaxLengthValidation(BaseProject.driver, First_Name, FirstName);

		wrap.wait(4000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "FirstName-Length");

		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Middle_Name, MiddleName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "MiddleName-Length");
		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Last_Name, LastName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "LastName-Length");
		//	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, DateOfBirth1);

		waitunlitVisiblityOfWebElement(AliasType1);
		wrap.click(BaseProject.driver, AliasType1);
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
		wrap.wait(2000);

		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_First_Name, AliasFirstName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasFirstName-Length");
		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasMiddleName-Length");
		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Alias_Last_Name, AliasLastName);
		wrap.screenShot(BaseProject.driver, screenShotPath, "AliasLastName-Length");

		waitunlitVisiblityOfWebElement(ContactType);
		//wrap.click(BaseProject.driver, ContactType);
		//wrap.typeToSuggestionTextbox(BaseProject.driver, ContactType, "code", CTD);
		wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, "MT1");
		//wrap.TypeToTextBoxAndTabOut(BaseProject.driver, CTD, ContactType);
		wrap.screenShot(BaseProject.driver, screenShotPath, "ContactType");


		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Contact_Details, ContactDetails);
		wrap.screenShot(BaseProject.driver, screenShotPath, "ContactDetails-Length");
		//	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxInputVal, Extension);


		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Document_Number, documentNumber);
		wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber-Length");
		//	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, docSignatureDate);
		//	wrap.TextFieldMaxLengthValidation(BaseProject.driver, maxdate, docExpireDate);


	}

	@Given("^Basic Data Capture ProductDetails tab Length Validation$")
	public void basic_data_capture_productDetails_tab_length_validation() throws IOException, InterruptedException {

		String productDetailsTab = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
		String Purpose = com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
		String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");
		String AccReqType = com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
		String AccNum = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
		String AccCurrency = com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");

		String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
		String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
		String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
		wrap.click(BaseProject.driver, productDetailsTab);


		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);

		try {
			wrap.TextFieldMaxLengthValidation(BaseProject.driver, Account_Number, AccNum);
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccountNumber-Length");

		} catch (Exception e) {

		}

	}

	@Given("^Basic Data capture Application Details tab length validation$")
	public void basic_Data_capture_Application_Details_tab_length_validation() throws IOException, InterruptedException {
		String sourceId = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String referralId = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String applicationHeader = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH");
		String maxInputTxt = "akjdhfjkahdfkhdfkjhdiurweuieyriqyeriyqiweryihdfjkahfkjhakdfhjkasdfhiuweyiqyweiryiauefhkjsdfhauiwehruiwqeyriquwehfihasdfiuahweuiryiqweyr";
		String maxInputVal = "8794545646123132134678976868768436546798764321633476943786";
		String maxInputID = "735873489378894357934895893475931245DR7899464RAD78745453ASDF131345646764DRGVHR54312027";
		waitunlitVisiblityOfWebElement(applicationHeader);
		wrap.click(BaseProject.driver, applicationHeader);


		String Sorucing_ID = DBUtils.readColumnWithRowID("Sorucing ID", BaseProject.scenarioID);
		String Referral_ID = DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID);
		String Acquisition_Channel = DBUtils.readColumnWithRowID("Acquisition Channel", BaseProject.scenarioID);
		String Fast_track_Flag = DBUtils.readColumnWithRowID("Fast track Flag", BaseProject.scenarioID);
		String Application_Branch = DBUtils.readColumnWithRowID("Application Branch", BaseProject.scenarioID);


		waitunlitVisiblityOfWebElement(sourceId);
		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Sorucing_ID, sourceId);
		wrap.screenShot(BaseProject.driver, screenShotPath, "SourcingId-Length");
		waitunlitVisiblityOfWebElement(referralId);
		wrap.TextFieldMaxLengthValidation(BaseProject.driver, Referral_ID, referralId);
		wrap.screenShot(BaseProject.driver, screenShotPath, "ReferralId-Length");
	}


	// Scenario 71
	@When("^Basic: verify Other than Applicants in Basic Data Capture Section")
	public void verify_Other_Applicants_Basic_Data_Capture_Section()
			throws Throwable {
		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);

		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");


		String Relation_Type_Code = DBUtils.readColumnWithRowID("Relation Type Code", BaseProject.scenarioID);

		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, "Related Party", "BYVISIBLETEXT");


		wrap.wait(2000);
		wrap.click(BaseProject.driver, relationTypeCode);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code, "BYVISIBLETEXT");
		wrap.wait(3000);
		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();
		validate_Remarks_fields_in_Customer_Detail_section();
		validate_Submit_buttons_in_Basic_Data_section();


	}



	@When("^Basic: Changes product in Product Details section$")
	public void change_product_in_Product_Details_section() throws IOException, InterruptedException {
		// Write code here that turns the phrase above into concrete actions

		String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_DropDown_ID");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");


		String Productsection = com.getElementProperties("BasicData", "Productsection");
		String ProductSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
		if (ProductSection.equals("false")) {
			wrap.click(BaseProject.driver, Productsection);

		}


		wrap.click(BaseProject.driver, ProductDetails);
		logger.info("Going to change Product Category");
		wrap.click(BaseProject.driver, ProductCategory);
		wrap.selectFromDropDown(BaseProject.driver, ProductCategory, "PERSONAL LOAN", "BYVISIBLETEXT");
		wrap.wait(3000);
		wrap.click(BaseProject.driver, ProductCode);
		wrap.wait(2000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "ProductCategory");

		logger.info("Going to change Product Code");
		wrap.selectFromDropDown(BaseProject.driver, ProductCode, "PL001 - LORDS PERSONAL LOAN", "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "ProductCode");

	}


	@When("^Basic: Document catagory Expire Date AlertMessage$")
	public void document_Catagory_Expire_Date_AlertMessage() throws IOException, InterruptedException, ParseException {

		switchFrame();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		//System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime()));
		//String date1 = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());

		//System.out.println(date1.concat("90"));
		Calendar cal = Calendar.getInstance();
		System.out.println(cal.getTime());

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//  utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");


		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}

		String error = "ONE OR MORE DOCUMENTS SUBMITTED ARE EXPIRED OR DUE FOR EXPIRY";

		switch (Document_Category) {

		case "CLIENT VERIFICATION DOCUMENTS":

			break;
		case "CLIENT TAX DOCUMENTS":

			break;

		case "CLIENT ID  DOCUMENTS":
			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentCategory");

			switch (Name_of_the_Document) {


			case "DRIVING LIC NO":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");


				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
				cal.add(Calendar.DATE, 30);
				String date = dateFormat.format(cal.getTime());
				date = date.replace("/", "");
				int dateNumDLV = Integer.parseInt(date);

				if (dateNumDLV <= DLVExpDate) {
					wrap.wait(4000);
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);

					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					Assert.assertEquals(error, ErrorMessage);
				}


				break;

			case "PASSPORT":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);


				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DocExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 90);
				String passExp = dateFormat.format(cal.getTime());
				passExp = passExp.replace("/", "");
				int dateNumpass = Integer.parseInt(passExp);

				if (dateNumpass >= DocExpDate) {

					wrap.wait(4000);
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					Assert.assertEquals(error, ErrorMessage);


				}

				break;

			case "VISA":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");


				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int VisaExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 30);
				String Visadate = dateFormat.format(cal.getTime());
				Visadate = Visadate.replace("/", "");
				int dateNum = Integer.parseInt(Visadate);

				if (dateNum <= VisaExpDate) {
					wrap.wait(4000);
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);

					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					Assert.assertEquals(error, ErrorMessage);
				}
				break;

			case "AOF":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int AOFExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 30);
				String aofdate = dateFormat.format(cal.getTime());
				aofdate = aofdate.replace("/", "");
				int dateAof = Integer.parseInt(aofdate);

				if (dateAof >= AOFExpDate) {
					wrap.wait(4000);
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					Assert.assertEquals(error, ErrorMessage);

				}
				break;

			case "TELEPHONE BILL":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int teliExpDate = Integer.parseInt(Document_Signature_Date.replace("/", ""));

				cal.add(Calendar.DATE, -60);
				String dateTeli = dateFormat.format(cal.getTime());
				dateTeli = dateTeli.replace("/", "");
				int teliphoneDate = Integer.parseInt(dateTeli);

				if (teliphoneDate >= teliExpDate) {
					wrap.wait(4000);
					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
					Assert.assertEquals(error, ErrorMessage);
				}
				break;

			case "ELECTRICITY BILL":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int eleExpDate = Integer.parseInt(Document_Signature_Date.replace("/", ""));

				cal.add(Calendar.DATE, -60);
				String dateEle = dateFormat.format(cal.getTime());
				dateEle = dateEle.replace("/", "");
				int dateNumEle = Integer.parseInt(dateEle);

				if (dateNumEle <= eleExpDate) {

					wrap.wait(4000);
					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
					Assert.assertEquals(error, ErrorMessage);
				}
				break;

			case "WATER BILL":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DocExpDateWater = Integer.parseInt(Document_Signature_Date.replace("/", ""));

				cal.add(Calendar.DATE, -60);
				String dateOfWater = dateFormat.format(cal.getTime());
				dateOfWater = dateOfWater.replace("/", "");
				int dateNumWater = Integer.parseInt(dateOfWater);

				if (dateNumWater >= DocExpDateWater) {
					wrap.wait(4000);
					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
					Assert.assertEquals(error, ErrorMessage);
				}
				break;

			default:

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "NameoftheDoc");
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentNumber");
				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.screenShot(BaseProject.driver, screenShotPath, "SignatureDate");
				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);
				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.screenShot(BaseProject.driver, screenShotPath, "ExpiryDate");

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DocExpDate1 = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 90);
				String passExp1 = dateFormat.format(cal.getTime());
				passExp = passExp1.replace("/", "");
				int dateNumpass1 = Integer.parseInt(passExp);

				if (dateNumpass1 >= DocExpDate1) {
					wrap.screenShot(BaseProject.driver, screenShotPath, "ErrorMessage");
					wrap.wait(4000);
					String ErrorMessage = wrap.getElement(BaseProject.driver, "//*[text()='One or more documents submitted are expired or due for expiry']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
					Assert.assertEquals(error, ErrorMessage);
				}

				break;
			}

			break;
		}
	}


	@When("^Basic: Fill Multiple Documents$")
	public void multiple_docuumentDetails() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);
		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));


		wrap.click(BaseProject.driver, DocumentCategory);
		//wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
		wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

		wrap.click(BaseProject.driver, NameoftheDocument);
		wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
		wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


		wrap.wait(1000);
		//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
		verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
		wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

		//wrap.wait(2000);
		//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
		verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
		wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
		//	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

		//	wrap.wait(500);
		//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
		verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

		wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

		//wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);


		String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);


		String DocumentCategory2 = "xpath=(//select[@id='DocumentCategory'])[2]";
		String NameoftheDocument2 = "xpath=(//select[@id='DocumentName'])[2]";
		String DocumentNumber2 = "xpath=(//input[@id='DocumentNumber'])[2]";


		wrap.click(BaseProject.driver, DocumentCategory);
		//wrap.wait(1000);
		//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
		wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, "CLIENT ID  DOCUMENTS", "BYVISIBLETEXT");

		wrap.wait(3000);
		wrap.click(BaseProject.driver, NameoftheDocument);

		wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, "AADHAAR ", "BYVISIBLETEXT");


		verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
		wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

	}

	@When("^Basic: Add and Enter Email address$")
	public void add_EmailAddress() throws Throwable {


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");


		String Contact_type_Code = DBUtils.readColumnWithRowID("Email Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Email Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Email Contact Details", BaseProject.scenarioID);


		String addtab = "//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);


		wrap.wait(1000);


		wrap.click(BaseProject.driver, ContactType);
		wrap.wait(3000);
		wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");


		//wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
		wrap.click(BaseProject.driver, ContactDetails);
		wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


	}

	@When("^Basic: Switch to Default Content$")
	public void switch_defaultContent() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		wrap.wait(3000);
		BaseProject.driver.switchTo().defaultContent();
		logger.info("Switched to Default Content");

	}


	@When("^Basic: Verify Field level Tab functionality Customer Tab$")
	public void verify_tabFunctionality_CutomerTab()
			throws Throwable {
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}


		com.tab(BaseProject.driver, Title);
		com.tab(BaseProject.driver, FirstName);
		com.tab(BaseProject.driver, MiddleName);
		com.tab(BaseProject.driver, LastName);
		com.tab(BaseProject.driver, DateOfBirth1);
		com.tab(BaseProject.driver, Nationality1);
		com.tab(BaseProject.driver, CountryOfBirth);
		com.tab(BaseProject.driver, CountryOfResidence);
		com.tab(BaseProject.driver, ClientType);
		com.tab(BaseProject.driver, AliasType1);
		com.tab(BaseProject.driver, ContactType);
		com.tab(BaseProject.driver, ISDCode);
		com.tab(BaseProject.driver, Extension);
		com.tab(BaseProject.driver, Occupation);
		com.tab(BaseProject.driver, ISIC);
		com.tab(BaseProject.driver, DocumentCategory);
		com.tab(BaseProject.driver, NameoftheDocument);
		com.tab(BaseProject.driver, DocumentSignatureDate);
		com.tab(BaseProject.driver, IDExpiryDate1);


	}


	@When("^Basic: Verify Field level Tab functionality Product Tab$")
	public void verify_tabFunctionality_Product()
			throws Throwable {

		click_on_Personal_Details_tab();

		int Pur = 1, ActR = 1, AccNu = 2, Ser = 1, i = 1, Min = 1;
		String productCatagory = "xpath=(//select[@id='ProductCategory'])[" + i + "]";
		String Purpose = "xpath=(//select[@id='Purpose'])[" + Pur + "]";
		String AccReqType = "xpath=(//*[@id='IsAccountType'])[" + ActR + "]";
		String AccNum = "xpath=(//input[@id='AccountNumber'])[" + AccNu + "]";
		String AccCurrency = "xpath=(//input[@id='Currency'])[" + i + "]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + Min + "]";

		com.tab(BaseProject.driver, productCatagory);

		com.tab(BaseProject.driver, Purpose);
		com.tab(BaseProject.driver, AccNum);
		com.tab(BaseProject.driver, AccCurrency);
	}


	@When("^Basic: Verify Field level Tab functionality Application Tab$")
	public void verify_tabFunctionality_Application()
			throws Throwable {


		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		click_on_Application_Details_tab();

		String Banksection = com.getElementProperties("BasicData", "Bankusesection");
		String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
		if (BankSection.equals("false")) {
			wrap.click(BaseProject.driver, Banksection);

		}


		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");
		String Remarks = com.getElementProperties("BasicData",
				"BasicData_Remarks_TextArea_ID");


		com.tab(BaseProject.driver, Sorucingid);
		com.tab(BaseProject.driver, Referralid);
		com.tab(BaseProject.driver, AqCode);
		com.tab(BaseProject.driver, FasttrackFlag);
		com.tab(BaseProject.driver, Branch);
		com.tab(BaseProject.driver, ARMCode);
		com.tab(BaseProject.driver, Remarks);


	}

	@When("^Basic: Verify field values are not empty in Customer Tab$")
	public void verify_fieldValuesnotempty_CustomerTab()
			throws Throwable {
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		utils.convertExcelToMap(excelPath, File.separator + "UATBasicData_Testdata_sheet.xls", "Basic");


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}

		String searchby = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		String acccurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");

		com.validateIsNotEmptyDropDown(BaseProject.driver, Title, "Title");
		com.validateIsEmpty(BaseProject.driver, accnumber, "Existing account number");
		com.validateIsNotEmpty(BaseProject.driver, acccurrency, "Existing account currency");

		com.validateIsNotEmpty(BaseProject.driver, FirstName, "FirstName");

		com.validateIsNotEmptyDropDown(BaseProject.driver, Title, "Title");
		com.validateIsNotEmpty(BaseProject.driver, FirstName, "FirstName");
		com.validateIsNotEmpty(BaseProject.driver, MiddleName, "MiddleName");
		com.validateIsNotEmpty(BaseProject.driver, LastName, "LastName");
		com.validateIsNotEmpty(BaseProject.driver, DateOfBirth1, "DateOfBirth");
		com.validateIsNotEmpty(BaseProject.driver, Nationality1, "Nationality");
		com.validateIsNotEmpty(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
		com.validateIsNotEmpty(BaseProject.driver, CountryOfResidence, "CountryOfResidence");

		com.validateIsNotEmptyDropDown(BaseProject.driver, AliasType1, "AliasType");
		try {
			com.validateIsNotEmpty(BaseProject.driver, AliasFirstName, "AliasFirstName");
			com.validateIsNotEmpty(BaseProject.driver, AliasMiddleName, "AliasMiddleName");
			com.validateIsNotEmpty(BaseProject.driver, AliasLastName, "AliasLastName");
		} catch (Exception e) {

		}

		com.validateIsNotEmptyDropDown(BaseProject.driver, ClientType, "ClientType");


		String Contactsection = com.getElementProperties("BasicData", "Contactsection");


		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}


		com.validateIsNotEmptyDropDown(BaseProject.driver, ContactType, "ContactType");
		com.validateIsNotEmpty(BaseProject.driver, ContactDetails, "ContactDetails");
		com.validateIsNotEmptyDropDown(BaseProject.driver, ISDCode, "ISDCode");
		com.validateIsNotEmpty(BaseProject.driver, Extension, "Extension");


		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		com.validateIsNotEmpty(BaseProject.driver, Occupation, "Occupation");
		com.validateIsNotEmpty(BaseProject.driver, ISIC, "ISIC");

		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}


		com.validateIsNotEmptyDropDown(BaseProject.driver, DocumentCategory, "DocumentCategory");
		com.validateIsNotEmptyDropDown(BaseProject.driver, NameoftheDocument, "NameoftheDocument");
		com.validateIsNotEmpty(BaseProject.driver, DocumentNumber, "DocumentNumber");
		com.validateIsNotEmpty(BaseProject.driver, IDExpiryDate1, "IDExpiryDate");
		com.validateIsNotEmpty(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");


	}


	@When("^Basic: Verify field values are not empty in Product Tab$")
	public void verify_fieldValues_ProductTab()
			throws Throwable {

		click_on_Personal_Details_tab();

		int Pur = 1, ActR = 1, AccNu = 2, Ser = 1, i = 1, Min = 1;

		String productCatagory = "xpath=(//select[@id='ProductCategory'])[" + i + "]";
		String Purpose = "xpath=(//select[@id='Purpose'])[" + Pur + "]";
		String Campigncode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Campaigncode_Text_ID");

		String AccReqType = "xpath=(//*[@id='IsAccountType'])[" + ActR + "]";
		String AccNum = "xpath=(//input[@id='AccountNumber'])[" + AccNu + "]";
		String AccCurrency = "xpath=(//input[@id='Currency'])[" + i + "]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";

		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + Min + "]";


		try {
			com.validateIsNotEmptyDropDown(BaseProject.driver, Purpose, "Purpose");
			com.validateIsNotEmptyDropDown(BaseProject.driver, AccReqType, "AccReqType");
			com.validateIsNotEmptyDropDown(BaseProject.driver, Campigncode, "Campigncode");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, "Existing", "BYVISIBLETEXT");

			com.validateIsNotEmptyDropDown(BaseProject.driver, AccReqType, "AccReqType");
			com.validateIsNotEmptyDropDown(BaseProject.driver, ServiceType, "ServiceType");
			com.validateIsNotEmpty(BaseProject.driver, AccNum, "AccNum");
			com.validateIsNotEmpty(BaseProject.driver, AccCurrency, "AccCurrency");

		} catch (Exception e) {

		}

	}


	@When("^Basic: Verify field values are not empty in Application Tab$")
	public void verify_fieldValues_notEmpty_ApplicationTab()
			throws Throwable {

		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		click_on_Application_Details_tab();

		String Banksection = com.getElementProperties("BasicData", "Bankusesection");
		String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
		if (BankSection.equals("false")) {
			wrap.click(BaseProject.driver, Banksection);

		}


		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");


		com.validateIsNotEmpty(BaseProject.driver, Sorucingid, "Sorucingid");
		com.validateIsNotEmpty(BaseProject.driver, Referralid, "Referralid");
		com.validateIsNotEmptyDropDown(BaseProject.driver, AqCode, "AqCode");
		com.validateIsNotEmptyDropDown(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
		com.validateIsNotEmptyDropDown(BaseProject.driver, Branch, "Branch");

		com.validateIsNotEmpty(BaseProject.driver, ARMCode, "ARMCode");


	}


	@When("^Basic: Verify field values are empty in Customer Tab$")
	public void verify_fieldValues_Empty()
			throws Throwable {
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}

		String searchby = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		String acccurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");

		com.validateIsNotEmptyDropDown(BaseProject.driver, Title, "Title");
		com.validateIsEmpty(BaseProject.driver, accnumber, "Existing account number");
		com.validateIsNotEmpty(BaseProject.driver, acccurrency, "Existing account currency");

		com.validateIsEmpty(BaseProject.driver, FirstName, "FirstName");
		com.validateIsEmpty(BaseProject.driver, MiddleName, "MiddleName");
		com.validateIsEmpty(BaseProject.driver, LastName, "LastName");
		com.validateIsEmpty(BaseProject.driver, DateOfBirth1, "DateOfBirth");
		//	com.validateIsEmpty(BaseProject.driver,Nationality1,"Nationality");
		com.validateIsEmpty(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
		//	com.validateIsEmpty(BaseProject.driver,CountryOfResidence,"CountryOfResidence");


		try {
			com.validateIsEmpty(BaseProject.driver, AliasFirstName, "AliasFirstName");
			com.validateIsEmpty(BaseProject.driver, AliasMiddleName, "AliasMiddleName");
			com.validateIsEmpty(BaseProject.driver, AliasLastName, "AliasLastName");
		} catch (Exception e) {

		}


		String Contactsection = com.getElementProperties("BasicData", "Contactsection");


		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}


		//	com.validateIsEmpty(BaseProject.driver,ContactDetails,"ContactDetails");
		com.validateIsEmpty(BaseProject.driver, Extension, "Extension");


		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		com.validateIsEmpty(BaseProject.driver, Occupation, "Occupation");
		//		com.validateIsEmpty(BaseProject.driver,ISIC,"ISIC");

		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}


		com.validateIsEmpty(BaseProject.driver, DocumentNumber, "DocumentNumber");
		com.validateIsEmpty(BaseProject.driver, IDExpiryDate1, "IDExpiryDate");
		com.validateIsEmpty(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");


	}


	@When("^Basic: Verify field values are empty in Product Tab$")
	public void verify_fieldValues_Empty_ProductTab()
			throws Throwable {

		click_on_Personal_Details_tab();

		int Pur = 1, ActR = 1, AccNu = 2, Ser = 1, i = 1, Min = 1;
		String productCatagory = "xpath=(//select[@id='ProductCategory'])[" + i + "]";
		String Purpose = "xpath=(//select[@id='Purpose'])[" + Pur + "]";
		String AccReqType = "xpath=(//*[@id='IsAccountType'])[" + ActR + "]";
		String AccNum = "xpath=(//input[@id='AccountNumber'])[" + AccNu + "]";
		String AccCurrency = "xpath=(//input[@id='Currency'])[" + i + "]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + Min + "]";


		try {
			//  	com.validateIsEmpty(BaseProject.driver,AccNum,"AccNum");
			//	com.validateIsEmpty(BaseProject.driver,AccCurrency,"AccCurrency");

		} catch (Exception e) {

		}

	}


	@When("^Basic: Verify field values are empty in Application Tab$")
	public void verify_fieldValues_Empty_ApplicationTab()
			throws Throwable {

		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		click_on_Application_Details_tab();

		String Banksection = com.getElementProperties("BasicData", "Bankusesection");
		String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
		if (BankSection.equals("false")) {
			wrap.click(BaseProject.driver, Banksection);

		}


		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");


		com.validateIsEmpty(BaseProject.driver, Sorucingid, "Sorucingid");
		com.validateIsEmpty(BaseProject.driver, Referralid, "Referralid");

		com.validateIsEmpty(BaseProject.driver, ARMCode, "ARMCode");


	}

	@Then("^Basic: release the application$")
	public void Basic_release_the_application1() throws Throwable {
		switchFrame();
		logger.info("Frame switched successfully");
		wrap.wait(1000);
		//wrap.scroll_to(BaseProject.driver,"//button[@accesskey='R']");
		logger.info("Going to click Release");
		wrap.click(BaseProject.driver, "//button[@accesskey='R']");
		//BaseProject.driver.findElement(By.xpath("//button[@accesskey='R']")).click();
		//handle_alert_popup_for_cancel_instapack_debit();

		try {
			BaseProject.driver.findElement(By.xpath("//span[text()='Confirm close']//preceding::table//following-sibling::div//u[contains(text(),'D')]")).click();
		} catch (Exception e) {

		}
		Thread.sleep(4000);
	}


	@Then("^Basic: close the application$")
	public void Basic_close_the_application1() throws Throwable {
		switchFrame();
		logger.info("Frame switched successfully");
		wrap.wait(1000);
		wrap.scroll_to(BaseProject.driver, "//button[@accesskey='o']");
		BaseProject.driver.findElement(By.xpath("//button[@accesskey='o']")).click();
		//handle_alert_popup_for_cancel_instapack_debit();

		try {
			BaseProject.driver.findElement(By.xpath("//span[text()='Confirm close']//preceding::table//following-sibling::div//u[contains(text(),'D')]")).click();
		} catch (Exception e) {

		}
		Thread.sleep(4000);
	}


	@When("^Basic: Verify userinput derived fields in Customer Tab$")
	public void verify_userInput_derived_fields_CustomerTab()
			throws Throwable {


		String searchby = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String accnumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountNumber_TextBox_XPATH");
		String acccurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");


		String ProfileType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ProfileType_DropDown_ID");
		String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_Text_ID");
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");

		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");


		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}

		com.validateDropDownDerived(BaseProject.driver, searchby, "searchby");
		com.validateUserInput(BaseProject.driver, accnumber, "accnumber");
		com.validateDerived(BaseProject.driver, acccurrency, "acccurrency");


		com.validateDropDownDerived(BaseProject.driver, ProfileType, "ProfileType");
		com.validateDropDownDerived(BaseProject.driver, Title, "Title");

		com.validateUserInput(BaseProject.driver, FirstName, "FirstName");
		com.validateUserInput(BaseProject.driver, MiddleName, "MiddleName");
		com.validateUserInput(BaseProject.driver, LastName, "LastName");
		com.validateUserInput(BaseProject.driver, FullName, "LastName");
		com.validateUserInput(BaseProject.driver, DateOfBirth1, "DateOfBirth");
		com.validateDerived(BaseProject.driver, Nationality1, "Nationality");
		com.validateUserInput(BaseProject.driver, CountryOfBirth, "CountryOfBirth");
		com.validateDerived(BaseProject.driver, CountryOfResidence, "CountryOfResidence");

		com.validateDropDownDerived(BaseProject.driver, ClientType, "ClientType");
		com.validateDropDownDerived(BaseProject.driver, AliasType1, "AliasType");

		waitunlitVisiblityOfWebElement(AliasType1);
		wrap.click(BaseProject.driver, AliasType1);
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");
		wrap.wait(2000);


		com.validateUserInput(BaseProject.driver, AliasFirstName, "AliasFirstName");
		com.validateUserInput(BaseProject.driver, AliasMiddleName, "AliasMiddleName");
		com.validateUserInput(BaseProject.driver, AliasLastName, "AliasLastName");


		String Contactsection = com.getElementProperties("BasicData", "Contactsection");


		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}


		com.validateDropDownDerived(BaseProject.driver, ContactType, "ContactType");


		wrap.click(BaseProject.driver, ContactType);
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, ContactType, "Mobile No-1", "BYVISIBLETEXT");
		wrap.wait(2000);


		com.validateUserInput(BaseProject.driver, ContactDetails, "ContactDetails");
		com.validateDropDownDerived(BaseProject.driver, ISDCode, "ISDCode");
		com.validateUserInput(BaseProject.driver, Extension, "Extension");


		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		com.validateUserInput(BaseProject.driver, Occupation, "Occupation");
		com.validateDerived(BaseProject.driver, ISIC, "ISIC");

		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}

		com.validateDropDownDerived(BaseProject.driver, DocumentCategory, "Document Category");
		com.validateDropDownDerived(BaseProject.driver, NameoftheDocument, "Name of the Document");

		com.validateUserInput(BaseProject.driver, DocumentNumber, "DocumentNumber");
		com.validateUserInput(BaseProject.driver, IDExpiryDate1, "IDExpiryDate");
		com.validateUserInput(BaseProject.driver, DocumentSignatureDate, "DocumentSignatureDate");


	}


	@When("^Basic: Verify userinput derived fields in Product Tab$")
	public void verify_userInput_derived_fields_ProductTab()
			throws Throwable {

		click_on_Personal_Details_tab();
		String Campigncode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Campaigncode_Text_ID");

		int Pur = 1, ActR = 1, AccNu = 2, Ser = 1, i = 1, Min = 1;
		String productCatagory = "xpath=(//select[@id='ProductCategory'])[" + i + "]";
		String productCode = "xpath=(//select[@id='ProductCode'])[" + i + "]";
		String Purpose = "xpath=(//select[@id='Purpose'])[" + Pur + "]";
		String AccReqType = "xpath=(//*[@id='IsAccountType'])[" + ActR + "]";
		String AccNum = "xpath=(//input[@id='AccountNumber'])[" + AccNu + "]";
		String AccCurrency = "xpath=(//input[@id='Currency'])[" + AccNu + "]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + Min + "]";


		com.validateDropDownDerived(BaseProject.driver, productCatagory, "productCatagory");
		com.validateDropDownDerived(BaseProject.driver, productCode, "productCode");
		com.validateUserInput(BaseProject.driver, Campigncode, "Campigncode");


		com.validateDropDownDerived(BaseProject.driver, Purpose, "Purpose");
		try {
			com.validateUserInput(BaseProject.driver, AccNum, "AccNum");
		} catch (Exception e) {
		}
		com.validateDropDownDerived(BaseProject.driver, AccReqType, "AccReqType");

		wrap.click(BaseProject.driver, AccReqType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, AccReqType, "Existing", "BYVISIBLETEXT");


		wrap.wait(2000);

		com.validateDropDownDerived(BaseProject.driver, ServiceType, "ServiceType");

		com.validateDerived(BaseProject.driver, AccCurrency, "AccCurrency");

	}


	@When("^Basic: Verify userinput derived fields in Application Tab$")
	public void verify_userInput_derived_fields_ApplicationTab()
			throws Throwable {

		String Sorucingid = com.getElementProperties("BasicData", "BasicData_app_details_sourceid");
		String Referralid = com.getElementProperties("BasicData", "BasicData_app_details_app_details_ReferralID");
		String AqCode = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AcquisitionCode");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag");
		String Branch = com.getElementProperties("BasicData", "BasicData_app_details_Application_Branch");

		click_on_Application_Details_tab();

		String Banksection = com.getElementProperties("BasicData", "Bankusesection");
		String BankSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Bank Use']/../..")).getAttribute("aria-expanded");
		if (BankSection.equals("false")) {
			wrap.click(BaseProject.driver, Banksection);

		}


		String ARMCode = com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ARMCode_ListBox_ID");
		String AppCretDate = com.getElementProperties("BasicData", "BasicData_app_details_Application_AppCretDate");
		String ChannelRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_ChannelRef");
		String SourceRef = com.getElementProperties("BasicData", "BasicData_app_details_Application_SourceRef");
		String SegmentCode = com.getElementProperties("BasicData", "BasicData_app_details_Application_SegmentCode");


		com.validateDerivedText(BaseProject.driver, AppCretDate, "AppCretDate");
		com.validateUserInput(BaseProject.driver, Sorucingid, "Sorucingid");
		com.validateUserInput(BaseProject.driver, Referralid, "Referralid");
		com.validateDropDownDerived(BaseProject.driver, AqCode, "AqCode");
		com.validateUserInputText(BaseProject.driver, ChannelRef, "ChannelRef");
		com.validateUserInputText(BaseProject.driver, SourceRef, "SourceRef");

		com.validateDropDownDerived(BaseProject.driver, FasttrackFlag, "FasttrackFlag");
		com.validateDropDownDerived(BaseProject.driver, Branch, "Branch");
		com.validateUserInput(BaseProject.driver, ARMCode, "ARMCode");
		com.validateUserInputText(BaseProject.driver, SegmentCode, "SegmentCode");

	}


	@When("^Basic: Fill Primary applicant and one applicant$")
	public void add_PrimaryApplicant_addtionalApplicant()
			throws Throwable {

		clickOnCustomerDetailsTab();
		fillDataInCustomerPersonalDetailsSection();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validateFieldsInDocumentDetailsSection();
		click_on_Personal_Details_tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_section();
		click_on_Application_Details_tab();
		validate_optional_and_mandatory_fields_in_BankUse_Details_section_Application_Tab();
		validate_optional_and_mandatory_fields_in_AC_Setup_Details_section_Application_Tab();
		clickOnCustomerDetailsTab();


		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");


		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");

		String Profile_Type_Code = DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID);
		String Relation_Type_Code = DBUtils.readColumnWithRowID("Relation Type Code", BaseProject.scenarioID);


		wrap.wait(3000);
		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, Profile_Type_Code, "BYVISIBLETEXT");


		wrap.wait(4000);

		if (Relation_Type_Code.equals("Related Party")) {
			wrap.click(BaseProject.driver, relationTypeCode);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code, "BYVISIBLETEXT");
			wrap.wait(4000);
		}
		Fill_Data_in_Customer_Personal_Details_section_for_ETB();
		validateFieldsInContactSection();
		validateFieldsInEmploymentSection();
		validate_optional_and_mandatory_fields_in_Document_Details_sections();


	}


	@When("^Basic: UAT scenario Add coapplicant '(.*)'$")
	public void uat_Scenario_add_addtionalCoApplicant(String j)
			throws Throwable {

		wrap.wait(1000);
		switchFrame();

		int i = Integer.parseInt(j);

		int k = i + 1;
		clickOnCustomerDetailsTab();

		wrap.wait(3000);
		String Add = com.getElementProperties("BasicData",
				"BasicData_CustomerDetail_PrimaryapplicantAdd_Button_XPATH");

		utils.convertExcelToMap(excelPath, "NewBDTestDataSheet.xls", "Sheet1");

		wrap.wait(500);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);


		String profileType = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_ProfileType_DropDown_ID");
		String relationTypeCode = com.getElementProperties("BasicData",
				"BasicData_CoApplicant_RelationTypeCode_DropDown_ID");

		String Profile_Type_Code = DBUtils.readColumnWithRowID("Coapp" + j + " ProfileType", BaseProject.scenarioID);
		String Relation_Type_Code = DBUtils.readColumnWithRowID("Coapp" + j + " Relation Type Code", BaseProject.scenarioID);


		wrap.click(BaseProject.driver, profileType);
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, profileType, Profile_Type_Code, "BYVISIBLETEXT");


		wrap.wait(2000);

		if (!Relation_Type_Code.isEmpty()) {
			wrap.click(BaseProject.driver, relationTypeCode);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, relationTypeCode, Relation_Type_Code, "BYVISIBLETEXT");
			wrap.wait(2000);
		}

		//Customer

		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
		String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
		String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddNationality_ID");
		String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
		String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
		String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
		String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
		String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
		String AddAlias = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AddAlias_Button_XPATH");
		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasNames1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames1_TextBox_ID");
		String RemoveAlias1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias1_Button_XPATH");
		String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType2_DropDown_ID");
		String AliasNames2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasNames2_TextBox_ID");
		String RemoveAlias2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_RemoveAlias2_Button_XPATH");
		String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");

		String IDExpiryDate2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate2_DateText_ID");
		//String DateOfBirth2=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth2_DateText_ID");

		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");


		String FullName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
		////convertExcelToMap("Sheet1");

		String Titles = DBUtils.readColumnWithRowID("Coapp" + j + " Title", BaseProject.scenarioID);
		String First_Name = DBUtils.readColumnWithRowID("Coapp" + j + " First Name", BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Coapp" + j + " Middle Name", BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Coapp" + j + " Last Name", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("Coapp" + j + " DOB", BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Coapp" + j + " Nationality Code1", BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Coapp" + j + " Nationality Description1", BaseProject.scenarioID);
		String Nationality_Code2 = DBUtils.readColumnWithRowID("Coapp" + j + " Nationality Code2", BaseProject.scenarioID);
		String Nationality_Description2 = DBUtils.readColumnWithRowID("Coapp" + j + " Nationality Description2", BaseProject.scenarioID);
		String Country_Of_Birth = DBUtils.readColumnWithRowID("Coapp" + j + " Country Of Birth", BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Coapp" + j + " Residence Country", BaseProject.scenarioID);
		String Alias_Type = DBUtils.readColumnWithRowID("Coapp" + j + " Alias Type", BaseProject.scenarioID);
		String Alias = DBUtils.readColumnWithRowID("Coapp" + j + " Alias(es)", BaseProject.scenarioID);
		String Nationality_Code = DBUtils.readColumnWithRowID("Coapp" + j + " Nationality Code", BaseProject.scenarioID);
		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Coapp" + j + " Country Of Birth Code", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Coapp" + j + " Residence Country Code", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Coapp" + j + " Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Coapp" + j + " Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Coapp" + j + " Alias Last Name", BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Coapp" + j + " Client Type", BaseProject.scenarioID);


		String DateOfBirth2 = "id=DateOfBirth" + k + "";

		System.out.println("Date of Birth Id: " + DateOfBirth2);

		switchFrame();

		String Primary = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Primary Applicant')]")).getText();


		String Customersection = com.getElementProperties("BasicData", "Customersection");
		String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
		if (CustomerSection.equals("false")) {
			wrap.click(BaseProject.driver, Customersection);

		}
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(Title);
		wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantTitle");
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(FirstName);
		wrap.type(BaseProject.driver, First_Name, FirstName);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantFirstName");
		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(MiddleName);
		wrap.click(BaseProject.driver, MiddleName);
		wrap.type(BaseProject.driver, Middle_Name, MiddleName);

		//wrap.wait(500);
		waitunlitVisiblityOfWebElement(LastName);
		//wrap.click(BaseProject.driver, LastName);
		verifyTextBoxThnClick(BaseProject.driver, LastName);
		wrap.type(BaseProject.driver, Last_Name, LastName);


		//wrap.wait(2000);
		//	waitunlitVisiblityOfWebElement(DateOfBirth1);
		verifyTextBoxThnClick(BaseProject.driver, DateOfBirth2);
		wrap.enterDate(BaseProject.driver, DOB, DateOfBirth2);
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDOB");

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, FirstName);

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, MiddleName);

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, LastName);

		waitunlitVisiblityOfWebElement(FullName);
		wrap.wait(1000);
		String FullNamevalue = BaseProject.driver.findElement(By.id("FullName")).getAttribute("value");
		logger.info("FullNamevalue is" + FullNamevalue);
		wrap.wait(1000);
		String Fullnamefrmfml = First_Name + " " + Middle_Name + " " + Last_Name;
		logger.info("FullNamevalue from concatanation is" + Fullnamefrmfml);
		if (FullNamevalue.equalsIgnoreCase(Fullnamefrmfml)) {
			logger.info("Full name is concatanated via first last middle name");
		} else {
			logger.info("Full name is not concatanated via first last middle name/does not enter");
		}

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, FullName);

		wrap.screenShot(BaseProject.driver, screenShotPath, "FullName");


		wrap.wait(1000);
		waitunlitVisiblityOfWebElement(CountryOfBirth);
		com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code, Country_Of_Birth);


		wrap.screenShot(BaseProject.driver, screenShotPath, "COApplicantCountryOfBirth");
		wrap.wait(1000);
		waitunlitVisiblityOfWebElement(CountryOfResidence);

		com.suggestionTextBox2(BaseProject.driver, CountryOfResidence, Residence_Country_Code, Residence_Country);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantResidenceOfCountry");


		//	waitunlitVisiblityOfWebElement(CountryOfBirth);
		wrap.wait(1000);
		waitunlitVisiblityOfWebElement(Nationality1);
		com.suggestionTextBox2(BaseProject.driver, Nationality1, Nationality_Code1, Nationality_Description1);

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNationality");


		//com.suggestionTextBox2(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);


		waitunlitVisiblityOfWebElement(ClientType);
		wrap.click(BaseProject.driver, ClientType);
		wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");

		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantClieentType");

		wrap.wait(2000);
		BaseProject.driver.findElement(By.xpath("(//div[contains(@datasource,'Alias')]//a[@title='Add a row '])[2]")).click();

		String fname = "ERF'@/&";
		String fname1 = "ERF'@/&";
		String fname2 = "ERF'@/&";

		wrap.wait(1000);
		String Altype = "xpath=(//select[@id='AliasType'])[2]";
		wrap.selectFromDropDown(BaseProject.driver, Altype, "AKA (also known as)", "BYVISIBLETEXT");

		wrap.wait(1000);
		String Alfn = "xpath=(//input[@id='AliasFirstName'])[2]";
		wrap.type(BaseProject.driver, fname, Alfn);

		wrap.wait(1000);
		String Almn = "xpath=(//input[@id='AliasMiddleName'])[2]";
		wrap.type(BaseProject.driver, fname1, Almn);

		wrap.wait(1000);
		String Alln = "xpath=(//input[@id='AliasLastName'])[2]";
		wrap.type(BaseProject.driver, fname2, Alln);

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, Alfn);

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, Almn);

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, Alln);


		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Alias Full Name')]//following-sibling::div//span)[2]")).sendKeys(Keys.TAB);
		wrap.wait(1000);
		String AliasFullNamevalue = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Alias Full Name')]//following-sibling::div//span)[2]")).getText();
		logger.info("Alias FullNamevalue is" + AliasFullNamevalue);
		wrap.wait(1000);
		String AliasFullnamefrmfml = fname + " " + fname1 + " " + fname2;
		logger.info("FullNamevalue from concatanation is" + Fullnamefrmfml);
		if (AliasFullNamevalue.equalsIgnoreCase(AliasFullnamefrmfml)) {
			logger.info("Alias Full name is concatanated via first last middle name");
		} else {
			logger.info("Alias Full name is not concatanated via first last middle name/does not enter");
		}

		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, AliasLastName);

		wrap.screenShot(BaseProject.driver, screenShotPath, "FullName");

		String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ContactNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactNumber_TextBox_XPATH");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");


		String Contact_type_Code = DBUtils.readColumnWithRowID("Coapp" + j + " Contact type", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Coapp" + j + " Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Coapp" + j + " Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("Coapp" + j + " ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Coapp" + j + " Extension", BaseProject.scenarioID);


		String Contactsection = com.getElementProperties("BasicData", "Contactsection");


		String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
		if (ContactSection.equals("false")) {
			wrap.click(BaseProject.driver, Contactsection);

		}


		String CTD = Contact_type_Code;
		if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9")) {

			wrap.click(BaseProject.driver, ContactType);
			wrap.wait(1000);
			//wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");
			wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);


			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
			wrap.click(BaseProject.driver, ContactDetails);
			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");


			//wrap.wait(500);
			/*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
			wrap.type(BaseProject.driver, Extension_No, Extension);*/
		} else if (CTD.equals("COL") | CTD.equals("Personal email address 1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {


			wrap.click(BaseProject.driver, ContactType);
			wrap.wait(1000);
			//wrap.selectFromDropDown(BaseProject.driver, ContactType, Contact_type_Description, "BYVISIBLETEXT");

			wrap.SelectAutosuggestionTextBox(BaseProject.driver, ContactType, CTD);

			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ContactDetails)));
			wrap.click(BaseProject.driver, ContactDetails);
			wrap.type(BaseProject.driver, Contact_Details, ContactDetails);


			//wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, ISDCode)));
			wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code, "BYVISIBLETEXT");


			//wrap.wait(500);
			/*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Extension)));
			wrap.type(BaseProject.driver, Extension_No, Extension);*/

		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantContact");

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Occupations = DBUtils.readColumnWithRowID("Coapp" + j + " Occupation", BaseProject.scenarioID);
		String Occupationcode = DBUtils.readColumnWithRowID("Coapp" + j + " Occupation Code", BaseProject.scenarioID);


		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		wrap.wait(1000);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Occupation)));
		logger.info("Occupation code is " + Occupationcode);

		wrap.selectformLOV_Values(BaseProject.driver, Occupation, Occupations);
		//wrap.typeInSuggestionTextbox(BaseProject.driver, Occupation, "Description", Occupationcode);
		wrap.screenShot(BaseProject.driver, screenShotPath, "Occupation");

		String isic1 = DBUtils.readColumnWithRowID("Coapp" + j + " ISIC", BaseProject.scenarioID);
		String isiccode = DBUtils.readColumnWithRowID("Coapp" + j + " ISIC Code", BaseProject.scenarioID);


		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		String IDExpiryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");


		//convertExcelToMap("Sheet1");
		//	utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");

		String Document_Category = DBUtils.readColumnWithRowID("Coapp" + j + " Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Coapp" + j + " Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Coapp" + j + " Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Coapp" + j + " Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Coapp" + j + " Document Signature Date", BaseProject.scenarioID);

		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}

		//WebElement doc=wrap.getExactAttribute(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"));

		try {


			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

			wrap.click(BaseProject.driver, NameoftheDocument);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocCatagory");
			wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
			wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

			wrap.wait(2000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantNameOfTheDocument");
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
			wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

			wrap.wait(1000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantDocumentNumber");
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
			wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
			//	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

			//	wrap.wait(500);
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
			verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

			wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
			wrap.screenShot(BaseProject.driver, screenShotPath, "CoApplicantExpDate");

			//wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
		} catch (Exception e) {


			String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
			WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
			JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
			myExecutor.executeScript("arguments[0].click();", add);


			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

			wrap.click(BaseProject.driver, NameoftheDocument);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
			wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");


			//	wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
			wrap.click(BaseProject.driver, DocumentNumber);
			wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

			//wrap.wait(2000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
			verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
			wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
			//	wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

			//	wrap.wait(500);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
			verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

			wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

			//wrap.enterDate(BaseProject.driver,IDExpiryDate1, Document_Expiry_Date);
		}


	}

	@When("^Basic: UAT Scenariovalidate optional and mandatory fields in Product Details section$")
	public void uat_Scenario_validate_optional_and_mandatory_fields_in_prd_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		//int i=1,j=1;


		//utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");
		//DBUtils.convertDBtoMap("bdquery");

		String campcd = DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
		String campcddesc = DBUtils.readColumnWithRowID("CampaigncodeDescription", BaseProject.scenarioID);
		String prdcd = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);



		//String products = com.getElementProperties("BasicData", "differentproductselections");
		//List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
		//for(WebElement pro: listOfProduct){

		//String capmpaigncode = "xpath=(//input[@id='CampaignCode'])["+i+"]";
		//String productcode="xpath=(//select[@id='ProductCode'])["+j+"]";

		String capmpaigncode = "xpath=(//input[@id='CampaignCode'])";
		String productcode = "xpath=(//select[@id='ProductCode'])";
		String productcodetd = "xpath=(//select[@id='ProductCode'])[2]";

		wrap.SelectAutosuggestionTextBox(BaseProject.driver, capmpaigncode, campcd);
		wrap.wait(2000);

		//wrap.waitForElementVisibility(BaseProject.driver,productcode,20);
		if (wrap.isElementPresent(BaseProject.driver, productcode)) {

			wrap.click(BaseProject.driver, productcode);
			wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
			wrap.wait(2000);
		}
		// j++;

		//        if (wrap.isElementPresent(BaseProject.driver, productcodetd)) {
		//            wrap.click(BaseProject.driver, productcodetd);
		//            wrap.selectFromDropDown(BaseProject.driver, productcodetd, prdcd, "BYVISIBLETEXT");
		//        }

		//wrap.screenShot(BaseProject.driver, "C:"+File.separator+"Arun"+File.separator+"AutomationScreenShots", Account_Request_Type);

		// }

	}

	@When("^Basic: UAT Scenario validate optional and mandatory fields in A/C Setup section$")
	public void uat_Scenario_validate_optional_and_mandatory_fields_in_AC_Setup_section() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		//int Pur=1, ActR=1, AccNu = 2,Ser=1,i=1,Min=1,j=1;

		/*String Purpose=com.getElementProperties("BasicData", "BasicData_ProductDetails_PurposeofAccountOpening_DropDown_ID");
	        String AccReqType=com.getElementProperties("BasicData", "BasicData_ProductDetails_AcountRequestType_DropDown_ID");
	        String AccNum=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountNumber_TextBox_XPATH");
	        String AccCurrency=com.getElementProperties("BasicData", "BasicData_ProductDetails_AccountCurrency_ListBox_XPATH1");
	        String ServiceType = com.getElementProperties("BasicData", "BasicData_ProductDetails_ServiceType_ListBox_ID");
	        String MinClearBal = com.getElementProperties("BasicData", "BasicData_ProductDetails_MinimumClearingBalance_TextBox_ID");*/


		utils.convertExcelToMap(excelPath, "BasicData_Test data_sheet.xls", "Sheet1");

		//  utils.convertExcelToMap(excelPath,File.separator+"UATBasicData_Testdata_sheet.xls","Basic");
		//convertExcelToMap("Sheet1");
		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

		String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);


		String ACsection = com.getElementProperties("BasicData", "ACsection");
		String ACSection = BaseProject.driver.findElement(By.xpath("//h2[text()='A/C Setup']/../..")).getAttribute("aria-expanded");
		if (ACSection.equals("false")) {
			wrap.click(BaseProject.driver, ACsection);

		}


		//Ram Implementation

		String products = com.getElementProperties("BasicData", "differentproductselections");
		//  List<WebElement> listOfProduct = wrap.getElements(BaseProject.driver, products);
		//  for(WebElement pro: listOfProduct){

		//String productCatagory = "xpath=(//select[@id='ProductCategory'])["+i+"]";
		/*String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+i+"]";
	            String Purpose="xpath=(//select[@id='Purpose'])["+Pur+"]";
	            String AccReqType="xpath=(//*[@id='IsAccountType'])["+ActR+"]";
	            String AccNum="xpath=(//input[@id='AccountNumber'])["+AccNu+"]";
	            String AccCurrency="xpath=(//input[@id='Currency'])["+i+"]";
	            String ServiceType ="xpath=(//*[@id='NatureOfServices'])["+i+"]";
	            String MinClearBal ="xpath=(//*[@id='MinimumClearingBalance'])["+Min+"]";*/

		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		String Purpose = "xpath=(//select[@id='Purpose'])";
		String AccReqType = "xpath=(//*[@id='IsAccountType'])";
		String AccNum = "xpath=(//input[@id='AccountNumber'])";
		String AccCurrency = "xpath=(//input[@id='Currency'])[2]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";

		logger.info(productCatagory);
		logger.info(Purpose);
		logger.info(AccReqType);
		logger.info(AccNum);
		logger.info(AccCurrency);
		logger.info(ServiceType);
		logger.info(MinClearBal);


		//JavascriptExecutor executor = (JavascriptExecutor)BaseProject.driver;
		//executor.executeScript("arguments[0].click();", pro);
		// pro.click();
		//com.verifyTextBoxThnClick(BaseProject.driver, Account_Request_Type);

		//wrap.wait(3000);
		//logger.info("(//select[@id='ProductCategory'])["+j+"]");
		//    wrap.click(BaseProject.driver, "xpath=(//select[@id='ProductCategory'])["+j+"]");

		//String ProductCategory = new Select(BaseProject.driver.findElement(By.xpath("(//select[@id='ProductCategory'])["+j+"]"))).getFirstSelectedOption().getText();
		//String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)["+j+"]")).getText();
		String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)")).getText();
		System.out.println("Product is" + ProductCategory);
		wrap.wait(1000);
		//j++;
		switch (ProductCategory) {
		case "CREDIT CARD":

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
			}
			wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);


			/* Pur++;
	                       ActR++;
	                       Ser++;
	                       AccNu++;*/

			break;
		case "CURRENT ACCOUNT":
			logger.info("Moved to CA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
			}
			wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);



			/* Pur++;
	                     ActR++;
	                     Ser++;
	                     AccNu++;*/


			break;
		case "SAVINGS ACCOUNT":
			logger.info("Moved to SA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
			}
			wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);


			/*  Pur++;
	                   ActR++;
	                   Ser++;
	                   AccNu++;*/


			break;

		case "TERM DEPOSITS":
			logger.info("Moved to TD");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			/*
	                    Pur++;
	                    ActR++;
	                    Ser++;*/


			break;
		case "PERSONAL LOAN":

			logger.info("Moved to PL");

			wrap.click(BaseProject.driver, Purpose);
			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
			}


			/* Pur++;
	                   ActR++;
	                   Ser++;
	                   AccNu++;*/

			break;

		case "MORTGAGE LOAN":
			break;
		case "PROMOTIONAL PACKAGES":
			break;

		default:

			try {
				if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
					wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
					// Pur++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) {

					wrap.click(BaseProject.driver, AccReqType);
					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					// ActR++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
					if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						wrap.wait(500);
						wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
						// Ser++;
					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}


			try {
				if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
					// AccNu++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}


			break;

		}
		wrap.screenShot(BaseProject.driver, "C:" + File.separator + "Arun" + File.separator + "AutomationScreenShots", Account_Request_Type);

		// }

	}
	
	@When("^Basic : Add New Product$")
	public void Add_New_Product() throws InterruptedException, IOException{
		wrap.wait(1000);
		//wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_NewProdTab"));	
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//a[@name='ProductDetails_pyWorkPage_7' and @title='Add a tab ']"));
        JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element1);
        js.executeScript("arguments[0].click();", element1);
        wrap.wait(2000);
	}

	@When("^Basic: Add coapplicant '(.*)'$")
	public void addCoapplicant(String j) throws Throwable {

		int i = Integer.parseInt(j);
		int k = i + 1;
		wrap.wait(1000);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_HOME);
		robot.keyRelease(KeyEvent.VK_HOME);

		String CustomerDetailsSection = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CustomerDetails_Button_XPATH");
		wrap.scroll_to(BaseProject.driver, CustomerDetailsSection);

		wrap.wait(1000);
		List<WebElement> CustomersTab = BaseProject.driver.findElements(By.xpath("//div[@pl_prop='.Customers']//li[contains(@tabbedrepeatid,'SubSectionCustomerDetailBBBBBBBBTR')]/a"));
		logger.info("*****Total Customer available as: "+ CustomersTab.size() + "******");

		if(CustomersTab.size()>i) {

			logger.info("Adding Co-Applicant");
			BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Co-Applicant')])[" + j + "]")).click();

			String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
			String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
			String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
			String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");
			String FullName1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FullName_TextBox_ID");
			String DateOfBirth1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID");
			String Nationality1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality1_ID");
			String Nationality2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality2_ID");
			String Nationality3 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality3_ID");
			String CountryOfBirth = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID");
			String CountryOfResidence = com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID");
			String ClientType = com.getElementProperties("BasicData", "BasicData_customerdetails_details_ClientType");
			String Mehalaya_NO= com.getElementProperties("BasicData", "BasicData_CustomerDetails_Mehalaya_radioNo");
			String AddNationality = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddNationality_Button");

			String Titles = DBUtils.readColumnWithRowID("Coapplicant" + i + " Title", BaseProject.scenarioID);
			String First_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " First Name", BaseProject.scenarioID);
			String Middle_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Middle Name", BaseProject.scenarioID);
			String Last_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Last Name", BaseProject.scenarioID);
			String DOB = DBUtils.readColumnWithRowID("Coapplicant" + i + " DOB", BaseProject.scenarioID);
			String Nationality_Code1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Code1", BaseProject.scenarioID);
			String Nationality_Description1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Description1", BaseProject.scenarioID);
			String Nationality_Code2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Code2", BaseProject.scenarioID);
			String Nationality_Description2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Nationality Description2", BaseProject.scenarioID);
			String Country_Of_Birth = DBUtils.readColumnWithRowID("Coapplicant" + i + " Country Of Birth Description", BaseProject.scenarioID);
			String Residence_Country = DBUtils.readColumnWithRowID("Coapplicant" + i + " Residence Country Description", BaseProject.scenarioID);
			String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Country Of Birth Code", BaseProject.scenarioID);
			String Residence_Country_Code = DBUtils.readColumnWithRowID("Coapplicant" + i + " Residence Country Code", BaseProject.scenarioID);
			String Client_Type = DBUtils.readColumnWithRowID("Coapplicant" + i + " Client Type", BaseProject.scenarioID);

			wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");

			WebDriverWait wait = new WebDriverWait(BaseProject.driver, 60, 500);

			String Customersection = com.getElementProperties("BasicData", "Customersection");
			String CustomerSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Customer Personal Detail']/../..")).getAttribute("aria-expanded");
			if (CustomerSection.equals("false")) {
				wrap.click(BaseProject.driver, Customersection);

			}

			wrap.selectFromDropDown(BaseProject.driver, Title, Titles, "BYVISIBLETEXT");
			logger.info("Co-Applicant Title Entered");

			wrap.click_wait(BaseProject.driver, FirstName);
			wrap.type_wait(BaseProject.driver, First_Name, FirstName);
			logger.info("Co-Applicant FirstName Entered");

			wrap.wait(1000);
			wrap.click_wait(BaseProject.driver, MiddleName);
			wrap.type_wait(BaseProject.driver, Middle_Name, MiddleName);
			logger.info("Co-Applicant MiddleName Entered");

			wrap.click_wait(BaseProject.driver,LastName);
			wrap.type_wait(BaseProject.driver, Last_Name, LastName);
			logger.info("Co-Applicant LastName Entered");

			wrap.click_wait(BaseProject.driver, DateOfBirth1);
			wrap.wait(1000);
			wrap.enterDate(BaseProject.driver, DOB, DateOfBirth1);
			logger.info("Co-Applicant DOB Entered");

			com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfBirth, Country_Of_Birth_Code,Country_Of_Birth);
		logger.info("Co-Applicant Country of Birth Selected");

		com.suggestionTextBox_CodeDesc(BaseProject.driver, CountryOfResidence, Residence_Country_Code,Residence_Country);
		logger.info("Co-Applicant Residency Country Selected");

		if(Wrapper.getValue(BaseProject.driver, Nationality1).equalsIgnoreCase(Nationality_Description1)) {
	        logger.info("Co-Applicant Nationality1 Already Exist !!!!!");
        } else {
        	logger.info("Co-Applicant Nationality1 Not Exist!!!");
			com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality1,Nationality_Code1,Nationality_Description1);
			logger.info("Co-Applicant Nationality1 Selected");
        }			

		//*****************Adding Nationality2*****************	

//		if((Nationality_Description2!=null)) {
//			
//			wrap.wait(2000);
//			wrap.click(BaseProject.driver, AddNationality);
//			waitunlitVisiblityOfWebElement(Nationality2);
//			com.suggestionTextBox_CodeDesc(BaseProject.driver, Nationality2,Nationality_Code2,Nationality_Description2);
//			logger.info("Nationality2 Selected");
//			}
			 
			wrap.scroll_to(BaseProject.driver, Mehalaya_NO);
			wrap.click_wait(BaseProject.driver,Mehalaya_NO);
			logger.info("Co-Applicant Mehalaya Radio Button Selected");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, ClientType, Client_Type, "BYVISIBLETEXT");
			String clientTypeValue = wrap.getExactAttribute(BaseProject.driver, ClientType).getAttribute("value");
			logger.info("Selected Co-Applicant client type is: " + clientTypeValue);


			//*************Co-Applicant Alias type**************

			String Alias_Type = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Type", BaseProject.scenarioID);
			String Aliases = DBUtils.readColumnWithRowID("Coapplicant" + i + " Aliases", BaseProject.scenarioID);
			String Alias_First_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias First Name", BaseProject.scenarioID);
			String Alias_Middle_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Middle Name", BaseProject.scenarioID);
			String Alias_Last_Name = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Last Name", BaseProject.scenarioID);
			String Alias_First_Name2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias First Name2", BaseProject.scenarioID);
			String Alias_Middle_Name2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Middle Name2", BaseProject.scenarioID);
			String Alias_Last_Name2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Last Name2", BaseProject.scenarioID);
			String Alias_Type2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Alias Type2", BaseProject.scenarioID);
			String Aliases2 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Aliases2", BaseProject.scenarioID);

			String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1");
			String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1");
			String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1");
			String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1");
			String AliasPreviousName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_1");
			String AddAliasButton = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddAlias_Button");
			String AliasType2 = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasType_2");
			String AliasFirstName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_2");
			String AliasMiddleName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_2");
			String AliasLastName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_2");
			String AliasPreviousName2 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_2");
			String Aliassection = com.getElementProperties("BasicData", "Aliassection");
			String NoAlias = com.getElementProperties("BasicData", "BasicData_CustomerDeatils_NoAliasAvailable");
			//String AliasInfoHeader= com.getElementProperties("BasicData", "BasicData_CustomerDetail_CoApp_AliasInfo_Header");

			wrap.scroll_to(BaseProject.driver, Aliassection);

			String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
			if (AliasSection.equals("false")) {
				wrap.click(BaseProject.driver, Aliassection);

			}

			//wrap.scroll_to(BaseProject.driver, "AliasInfoHeader");
			wrap.wait(1000);
			wrap.click(BaseProject.driver, AddAliasButton);
			logger.info("Alias Add Button Clicked");

			if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1"))) {	
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
				String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
				logger.info("Selected Co-Applicant Alias type is: " + AliasValue);

				switch(Alias_Type){

				case "AKA (also known as)":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName)));
					wrap.type(BaseProject.driver, Alias_First_Name, AliasFirstName);
					logger.info("Co-Applicant Alias FirstName Entered");

					wrap.type(BaseProject.driver, Alias_Middle_Name, AliasMiddleName);
					logger.info("Co-Applicant Alias MiddleName Entered");

					wrap.type(BaseProject.driver, Alias_Last_Name, AliasLastName);
					logger.info("Co-Applicant Alias LastName Entered");

					break;

				case "Previous Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Co-Applicant Aliases Name Entered");

					break;

				case "CCMS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Co-Applicant Aliases Name Entered");

					break;

				case "RLS Relationship Name":

					new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName)));
					wrap.type(BaseProject.driver, Aliases, AliasPreviousName);
					logger.info("Co-Applicant Aliases Name Entered");

					break;
				}

				/*logger.info("Co-Applicant The Alias Info Add Alias Value is Present as: " + Alias_Type2);

            if (Alias_Type2.equalsIgnoreCase("AKA (also known as)")||Alias_Type2.equalsIgnoreCase("Previous Name")||Alias_Type2.equalsIgnoreCase("CCMS Relationship Name")
            		||Alias_Type2.equalsIgnoreCase("RLS Relationship Name")) {

	            wrap.wait(1000); 
	            wrap.click(BaseProject.driver, AddAliasButton);

	            wrap.wait(2000);
	            wrap.selectFromDropDown(BaseProject.driver, AliasType2, Alias_Type2, "BYVISIBLETEXT");
	            String AliasValue2 = wrap.getExactAttribute(BaseProject.driver, AliasType2).getAttribute("value");
	            logger.info("Selected Co-Applicant Alias type2 is: " + AliasValue2);

	            switch(Alias_Type2){

	            		case "AKA (also known as)":

	            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasFirstName2)));
	                        wrap.type(BaseProject.driver, Alias_First_Name2, AliasFirstName2);
	                        logger.info("Co-Applicant Alias FirstName2 Entered");

	                        wrap.type(BaseProject.driver, Alias_Middle_Name2, AliasMiddleName2);
	                        logger.info("Co-Applicant Alias MiddleName2 Entered");

	                        wrap.type(BaseProject.driver, Alias_Last_Name2, AliasLastName2);
	                        logger.info("Co-Applicant Alias LastName2 Entered");

	            			break;

	            		case "Previous Name":

	            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
	                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
	                        logger.info("Co-Applicant Aliases Name2 Entered");

	                        break;

	            		case "CCMS Relationship Name":

	            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
	                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
	                        logger.info("Co-Applicant Aliases Name2 Entered");

	                        break;

	            		case "RLS Relationship Name":

	            			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(AliasPreviousName2)));
	                        wrap.type(BaseProject.driver, Aliases2, AliasPreviousName2);
	                        logger.info("Co-Applicant Aliases Name2 Entered");

	                        break;
		            }	

	            } else {
	            	logger.info("Co-Applicant No Data Avaialble to Add Another Alias Info");
	            }*/

			} else {
				logger.info("Co-Applicant Alias Information Not Entered");
			}


			//*************Co-Applicant Contact **************

			String ContactDetails = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH");
			String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
			String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
			String Extension = com.getElementProperties("BasicData", "BasicData_Contact_Extension");
			String preferredContact = com.getElementProperties("BasicData", "BasicData_CustomerDetails_preferredContact");
			String Areacodeprop = com.getElementProperties("BasicData", "BasicData_Contact_AreaCode");

			String Contact_type_Code1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact type Code1", BaseProject.scenarioID);
			String Contact_type_Description1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact type Description1", BaseProject.scenarioID);
			String Contact_Details1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Contact Details1", BaseProject.scenarioID);
			String ISD_Code1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " ISD Code1", BaseProject.scenarioID);
			String Extension_No1 = DBUtils.readColumnWithRowID("Coapplicant" + i + " Extension1", BaseProject.scenarioID);
			String Preferred_contact1 = DBUtils.readColumnWithRowID("Coapplicant" + i +" Contact_Preferred_contact1", BaseProject.scenarioID);
			String Contactsection = com.getElementProperties("BasicData", "Contactsection");

			wrap.scroll_to(BaseProject.driver, ContactType);

			String ContactSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Contact']/../..")).getAttribute("aria-expanded");
			if (ContactSection.equals("false")) {
				wrap.click(BaseProject.driver, Contactsection);

			}

			String CTD = Contact_type_Code1;
			if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {

				logger.info("*************Co-Applicant Going to Fill data of Mobile***********");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description1);
				logger.info("Co-Applicant Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details1, ContactDetails);
				logger.info("Co-Applicant Contact Details Entered");

				wrap.wait(1000);
				wrap.click_wait(BaseProject.driver, ISDCode);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code1, "BYVISIBLETEXT");
				logger.info("Co-Applicant ISD Code Selected");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact1, preferredContact);
				logger.info("Co-Applicant Preferred Contact Checked");

				logger.info("**************Co-Applicant Data Filled for Mobile***************");


			} else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {

				logger.info("********************Co-Applicant Going to Fill data of Resident*************************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description1);
				logger.info("Co-Applicant Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details1, ContactDetails);
				logger.info("Co-Applicant Contact Details Entered");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact1, preferredContact);
				logger.info("Co-Applicant Preferred Contact Checked");

				logger.info("*****************Co-Applicant Data Filled for Resident*******************");


			} else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

				logger.info("****************Co-Applicant Going to Fill data of Telephone*********************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description1);
				logger.info("Co-Applicant Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details1, ContactDetails);
				logger.info("Co-Applicant Contact Details Entered");

				wrap.wait(2000);
				wrap.click_wait(BaseProject.driver, ISDCode);
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode, ISD_Code1, "BYVISIBLETEXT");
				logger.info("Co-Applicant ISD Code Selected");

				//wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

				wrap.click_wait(BaseProject.driver, Extension);
				wrap.type(BaseProject.driver, Extension_No1, Extension);
				logger.info("Co-Applicant Extension Entered");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact1, preferredContact);
				logger.info("Co-Applicant Preferred Contact Checked");

				logger.info("****************Co-Applicant Data Filled for Telephone*********************");

			} else {

				logger.info("*************Co-Applicant Going to Fill data of Contact Type with No CODE found**************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType, CTD, Contact_type_Description1);
				logger.info("Co-Applicant Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details1, ContactDetails);
				logger.info("Co-Applicant Contact Details Entered");

				wrap.wait(1000);
				wrap.checkBoxSelect(BaseProject.driver, Preferred_contact1, preferredContact);
				logger.info("Co-Applicant Preferred Contact Checked");

				logger.info("*************Co-Applicant Data Filled for Contact Type with No CODE found****************");
			}


			//*************Co-Applicant Employment **************

			String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");

			String Occupationcode = DBUtils.readColumnWithRowID("Coapplicant" + j + " Occupation Code", BaseProject.scenarioID);
			String OccupationDescription = DBUtils.readColumnWithRowID("Coapplicant" + j + " Occupation Description", BaseProject.scenarioID);

			String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");
			String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
			if (EmploymentSection.equals("false")) {
				wrap.click(BaseProject.driver, Employmentsection);

			}

			com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
			logger.info("Co-Applicant Occupation Selected");


			//*************Co-Applicant Document Details **************

			String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
			String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
			String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
			String DocumentExipryDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate_DateText_ID");
			String DocumentSignatureDate = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");
			String DocumentNumber1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber1");
			String DocumentExipryDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1");
			String DocumentSignatureDate1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate1");

			String Document_Category1 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Category1", BaseProject.scenarioID);
			String Name_of_the_Document1 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Name of the Document1", BaseProject.scenarioID);
			String Document_Number1 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Number1", BaseProject.scenarioID);
			String Document_Expiry_Date1 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Expiry Date1", BaseProject.scenarioID);
			String Document_Signature_Date1 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Signature Date1", BaseProject.scenarioID);
			String Document_Category2 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Category2", BaseProject.scenarioID);
			String Name_of_the_Document2 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Name of the Document2", BaseProject.scenarioID);
			String Document_Number2 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Number2", BaseProject.scenarioID);
			String Document_Expiry_Date2 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Expiry Date2", BaseProject.scenarioID);
			String Document_Signature_Date2 = DBUtils.readColumnWithRowID("Coapplicant" +i+" Document Signature Date2", BaseProject.scenarioID);
			String DocDetailSection = com.getElementProperties("BasicData", "Documentsection");

			wrap.scroll_to(BaseProject.driver, DocDetailSection);

			String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
			if (DocumentSection.equals("false")) {
				wrap.click(BaseProject.driver, DocDetailSection);

			}

			List<WebElement> Doclist = BaseProject.driver.findElements(By.xpath("//div[@pl_prop='.DocumentList']//li[contains(@hpref,'pDocumentList')]//table//tr//td[1]//span"));
			logger.info(Doclist.size());

			JavascriptExecutor Documentslist = ((JavascriptExecutor) BaseProject.driver);

			for(int n=1; n<=Doclist.size(); n++) {

				Documentslist.executeScript("arguments[0].click();", Doclist.get(n-1));

				wrap.wait(1000);
				String DocumentTab = Doclist.get(n-1).getText();
				logger.info("*Co-Applicant *********"+ DocumentTab + "*************");

				String DocName = Wrapper.getTextValue(BaseProject.driver,"//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+ i +"']//span[text()='Name of the Document']/parent::label/following-sibling::div/div/select");
				logger.info(n +". " + DocName);

				if(n==1) {

					if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
							||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
							||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

						logger.info("*************** Co-Applicant Filling Document Tab 1 ****************");
						wrap.wait(1000);
						wrap.type(BaseProject.driver, Document_Number1, DocumentNumber);
						logger.info("Co-Applicant Document Number Entered");

						wrap.wait(1000);
						wrap.type(BaseProject.driver, Document_Signature_Date1, DocumentSignatureDate);
						logger.info("Co-Applicant Document Signatory Date Entered");

						if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate))){
							wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate)));
							wrap.type(BaseProject.driver, Document_Expiry_Date1, DocumentExipryDate);
							logger.info("Co-Applicant Document Expiry Date Entered");
						}
						else
						{
							logger.info("Expiry Date field is not present");
						}
						

					} else {
						logger.info("****** Co-Applicant Documents Details Tab 1 Filled ************");
					}

				} else if(n==2) {

					if(DocName.contains("AADHAAR")||DocName.contains("PAN NO")||DocName.contains("PASSPORT")||DocName.contains("DRIVING LIC NO")||DocName.contains("NREGA JOB CARD")
							||DocName.contains("VOTERS ID")||DocName.contains("GAS BILL")||DocName.contains("FORM 60")||DocName.contains("ELECTRICITY BILL")
							||DocName.contains("PAN NO-Temp")||DocName.contains("EMBASSY / UNO LETTERS")||DocName.contains("NATIONAL IDENTITY CARD")) {

						logger.info("*************** Co-Applicant Filling Document Tab 2 ****************");
						wrap.wait(1000);
						wrap.type(BaseProject.driver, Document_Number2, DocumentNumber1);
						logger.info("Co-Applicant Document Number1 Entered");

						wrap.wait(1000);
						wrap.type(BaseProject.driver, Document_Signature_Date2, DocumentSignatureDate1);
						logger.info("Co-Applicant Document Signatory Date1 Entered");

						if(wrap.isElementPresent(BaseProject.driver, com.getElementProperties(BaseProject.propertiesFilename, DocumentExipryDate1))){
							wait.until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DocumentExipryDate1)));
							wrap.type(BaseProject.driver, Document_Expiry_Date2, DocumentExipryDate1);
							logger.info("Co-Applicant Document Expiry Date1 Entered");
						}
						else
						{
							logger.info("Expiry Date field is not present");
						}
						

					} else {
						logger.info("****** Co-Applicant Documents Details Tab 2 Filled ************");
					}        
				}
			}

		}
	}

	// RAM Implementation


	@When("^Basic: UAT TC Document catagory Multiple Document '(.*)'$")
	public void uat_Tc_Document_Catagory_Expire_Date_(String i) throws IOException, InterruptedException, ParseException {


		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		//System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime()));
		//String date1 = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());

		//System.out.println(date1.concat("90"));
		Calendar cal = Calendar.getInstance();
		System.out.println(cal.getTime());

		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		String DocumentNumber = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");
		//String IDExpiryDate1=com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1_DateText_ID");
		//String DocumentSignatureDate=com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate_ID");

		int j = Integer.parseInt(i);
		//  j = j+1;
		int k = j + 1;
		String DocumentType = "xpath=(//div[@sectionbodyid='SubSectionDocumentListB']/ul[@class='yui-nav']//a[@id='TABANCHOR'])[" + j + "]";
		//String DocumentNumber = "xpath=(//input[@id='DocumentNumber'])["+j+"]";
		String DocumentSignatureDate = "id=DocumentSignatureDate" + k;
		String IDExpiryDate1 = "id=DocumentExpiryDate" + k;
		//String DocumentNumber = "xpath=(//input[@id='DocumentNumber'])["+k+"]";


		//convertExcelToMap("Sheet1");
		utils.convertExcelToMap(excelPath, "NewBDTestDataSheet.xls", "Sheet1");

		String Document_Category = DBUtils.readColumnWithRowID("Document Category" + i, BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document" + i, BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number" + i, BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date" + i, BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date" + i, BaseProject.scenarioID);
		WebElement element = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']"));

		/*JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
           jse.executeScript("arguments[0].scrollIntoView(true);", element);*/

		String addtab = "//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']";
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, addtab)));
		WebElement add = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionDocumentListB']//a[@title='Add a tab ']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", add);


		String Documentsection = com.getElementProperties("BasicData", "Documentsection");
		String DocumentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Document Details']/../..")).getAttribute("aria-expanded");
		if (DocumentSection.equals("false")) {
			wrap.click(BaseProject.driver, Documentsection);

		}


		switch (Document_Category) {

		case "CLIENT VERIFICATION DOCUMENTS":

			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");
			switch (Name_of_the_Document) {

			case "DRIVING LIC NO":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				//wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
				cal.add(Calendar.DATE, 30);
				String date = dateFormat.format(cal.getTime());
				date = date.replace("/", "");
				int dateNumDLV = Integer.parseInt(date);

				if (dateNumDLV <= DLVExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

				break;

			case "PAN NO-Temp":

				wrap.wait(1000);
				verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
				// wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				//wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
				// wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				/* int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

				break;

			case "GAS BILL":

				wrap.wait(1000);
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.wait(1000);
				//  wrap.click(BaseProject.driver, DocumentType);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				/*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

				break;

			case "TELEPHONE BILL":

				//wrap.wait(1000);
				//wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				// wrap.click(BaseProject.driver, DocumentType);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
				//wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				/*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

				break;

			case "WATER BILL":

				//wrap.wait(1000);
				//wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				verifyTextBoxThnClick(BaseProject.driver, NameoftheDocument);
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				// wrap.click(BaseProject.driver, DocumentType);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentNumber);
				//wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				/*wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                             logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");

				break;


			case "VOTERS ID":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "AADHAAR":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			}


			break;
		case "CLIENT TAX DOCUMENTS":
			wrap.click(BaseProject.driver, DocumentCategory);
			//wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");

			switch (Name_of_the_Document) {

			case "CANADIAN TAX IDENTIFICATION":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;


			case "CRS DOCUMENT":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "CRS VALIDATION CHECKLIST":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "FOREIGN TIN":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "FORM 60":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "GST/VAT DOCUMENT":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "TAX IDENTIFICATION NUMBER":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				/*wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
                        wrap.click(BaseProject.driver, DocumentNumber);
                        wrap.type(BaseProject.driver, Document_Number, DocumentNumber);*/
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "TAX PAID  RECEIPTS":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;


			}


			break;

		case "CLIENT ID  DOCUMENTS":
			wrap.click(BaseProject.driver, DocumentCategory);
			wrap.wait(1000);
			wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentCategory)));
			wrap.selectFromDropDown(BaseProject.driver, DocumentCategory, Document_Category, "BYVISIBLETEXT");


			switch (Name_of_the_Document) {

			case "VOTERS ID":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "DRIVING LIC NO":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				//wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				/* wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                        int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                        cal.add(Calendar.DATE, 30);
                        String date =dateFormat.format(cal.getTime());
                        date = date.replace("/", "");
                        int dateNumDLV = Integer.parseInt(date);

                        if(dateNumDLV<=DLVExpDate){

                               String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                                logger.info(ErrorMessage);
                               System.out.println(ErrorMessage);
                        }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "PAN NO":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				//wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);


				/* wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
                      int DLVExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));
                      cal.add(Calendar.DATE, 30);
                      String date =dateFormat.format(cal.getTime());
                      date = date.replace("/", "");
                      int dateNumDLV = Integer.parseInt(date);

                      if(dateNumDLV<=DLVExpDate){

                             String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
                              logger.info(ErrorMessage);
                             System.out.println(ErrorMessage);
                      }*/

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "PASSPORT":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);
				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DocExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 90);
				String passExp = dateFormat.format(cal.getTime());
				passExp = passExp.replace("/", "");
				int dateNumpass = Integer.parseInt(passExp);

				if (dateNumpass >= DocExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "VISA":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int VisaExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 30);
				String Visadate = dateFormat.format(cal.getTime());
				Visadate = Visadate.replace("/", "");
				int dateNum = Integer.parseInt(Visadate);

				if (dateNum <= VisaExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "AOF":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int AOFExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 30);
				String aofdate = dateFormat.format(cal.getTime());
				aofdate = aofdate.replace("/", "");
				int dateAof = Integer.parseInt(aofdate);

				if (dateAof >= AOFExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "TELEPHONE BILL":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int teliExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 60);
				String dateTeli = dateFormat.format(cal.getTime());
				dateTeli = dateTeli.replace("/", "");
				int teliphoneDate = Integer.parseInt(dateTeli);

				if (teliphoneDate >= teliExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "ELECTRICITY BILL":

				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int eleExpDate = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 60);
				String dateEle = dateFormat.format(cal.getTime());
				dateEle = dateEle.replace("/", "");
				int dateNumEle = Integer.parseInt(dateEle);

				if (dateNumEle >= eleExpDate) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			case "WATER BILL":
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");

				wrap.click(BaseProject.driver, DocumentType);

				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				//     wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.click(BaseProject.driver, "//span[text()='Is Document Available?']");
				int DocExpDateWater = Integer.parseInt(Document_Expiry_Date.replace("/", ""));

				cal.add(Calendar.DATE, 60);
				String dateOfWater = dateFormat.format(cal.getTime());
				dateOfWater = dateOfWater.replace("/", "");
				int dateNumWater = Integer.parseInt(dateOfWater);

				if (dateNumWater >= DocExpDateWater) {

					String ErrorMessage = wrap.getElement(BaseProject.driver, "//div[@swp='.DocExpiryFlag']").getText();
					logger.info(ErrorMessage);
					System.out.println(ErrorMessage);
				}
				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;

			default:
				wrap.click(BaseProject.driver, NameoftheDocument);
				//wrap.wait(1000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, NameoftheDocument)));
				wrap.selectFromDropDown(BaseProject.driver, NameoftheDocument, Name_of_the_Document, "BYVISIBLETEXT");
				wrap.click(BaseProject.driver, DocumentType);
				wrap.wait(1000);
				//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentNumber)));
				wrap.click(BaseProject.driver, DocumentNumber);
				wrap.type(BaseProject.driver, Document_Number, DocumentNumber);

				//wrap.wait(2000);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, DocumentSignatureDate)));
				verifyTextBoxThnClick(BaseProject.driver, DocumentSignatureDate);
				wrap.enterDate(BaseProject.driver, Document_Signature_Date, DocumentSignatureDate);
				//     wrap.enterDate(BaseProject.driver,DocumentSignatureDate, Document_Signature_Date);

				wrap.wait(500);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, IDExpiryDate1)));
				verifyTextBoxThnClick(BaseProject.driver, IDExpiryDate1);

				wrap.enterDate(BaseProject.driver, Document_Expiry_Date, IDExpiryDate1);

				wrap.screenShot(BaseProject.driver, screenShotPath, "DocumentDetails");
				break;
			}

			break;
		}


	}

	@When("^Basic: validate optional and mandatory fields in Add Another Contact section '(.*)'$")
	public void Validate_optional_and_mandatory_fields_in_add_another_Contact_section(String i) throws Throwable {

		int j = Integer.parseInt(i);
		int k = j + 1;

		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code" + i, BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Code" + i, BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details" + i, BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code" + i, BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension" + i, BaseProject.scenarioID);
		String Area_cd = DBUtils.readColumnWithRowID("Area Code" + i, BaseProject.scenarioID);

		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String Contactsection = com.getElementProperties("BasicData", "Contactsection");

		wrap.scroll_to(BaseProject.driver, ContactType);

		wrap.wait(500);
		WebElement AddContact = BaseProject.driver.findElement(By.xpath("//div[@sectionbodyid='SubSectionContactInfoB']//a[@title='Add a tab ']"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", AddContact);
		js.executeScript("arguments[0].click();", AddContact);
		System.out.println("clicked on another contact");

		wrap.wait(1000);

		for(int n=1; n<=j; n++) {

			n=n+1;

			String ContactType1 ="//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+n+"']//span[text()='Contact Type']/parent::label/following-sibling::div//input";
			String ContactDetails1 = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+n+"']//span[text()='Contact Details']/parent::label/following-sibling::div//input";
			String ISDCode1 = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+n+"']//span[text()='ISD Code']/parent::label/following-sibling::div//select";
			String ExtensionDetails1 = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+n+"']//label[text()='Extension Details']/following-sibling::div//input";
			String PreferredContact1 = "//div[contains(@id,'SubSectionCustomerDetail') and @class='tabpanelnofocus' and contains(@style,'block')]//div[@aria-labelledby='Tab"+n+"']//label[text()='Preferred Contact']/following-sibling::div//input[@id]";

			String CTD = Contact_type_Code;

			if (CTD.equals("MT1") | CTD.equals("MT2") | CTD.equals("MT3") | CTD.equals("MT4") | CTD.equals("MO5") | CTD.equals("MO6") | CTD.equals("MO7") | CTD.equals("MO8") | CTD.equals("MO9") | CTD.equals("MO1") | CTD.equals("MO2") | CTD.equals("MO3") | CTD.equals("MO4")) {


				logger.info("************Going to Fill data of Mobile***********");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType1, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails1);
				logger.info("Contact Details Entered");

				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode1, ISD_Code, "BYVISIBLETEXT");
				logger.info("ISD Code Selected");

				wrap.wait(1000);
				wrap.click_wait(BaseProject.driver, PreferredContact1);
				logger.info("Preferred Contact Checked");

				logger.info("**************Data Filled for Mobile***************");


			} else if (CTD.equals("COL") | CTD.equals("RE1") | CTD.equals("RE1") | CTD.equals("RE3") | CTD.equals("ERR") | CTD.equals("OE1") | CTD.equals("OE2") | CTD.equals("OE3") | CTD.equals("LM1")) {

				logger.info("*******************Going to Fill data of Resident*************************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType1, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails1);
				logger.info("Contact Details Entered");

				logger.info("****************Data Filled for Resident*******************");

			} else if (CTD.equals("OT1") | CTD.equals("OT2") | CTD.equals("OT3") | CTD.equals("OT4") | CTD.equals("OT5") | CTD.equals("OT6") | CTD.equals("OT7") | CTD.equals("OT8") | CTD.equals("OT9") | CTD.equals("OTA") | CTD.equals("OTB") | CTD.equals("OTC") | CTD.equals("LO1") | CTD.equals("LO2") | CTD.equals("LO3")) {

				logger.info("***************Going to Fill data of Telephone*********************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType1, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails1);
				logger.info("Contact Details Entered");

				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, ISDCode1, ISD_Code, "BYVISIBLETEXT");
				logger.info("ISD Code Selected");

				//wrap.type(BaseProject.driver, Area_cd, Areacodeprop);

				wrap.click_wait(BaseProject.driver, ExtensionDetails1);
				wrap.type(BaseProject.driver, Extension_No, ExtensionDetails1);
				logger.info("Extension Entered");

				wrap.wait(1000);
				wrap.click_wait(BaseProject.driver, PreferredContact1);
				logger.info("Preferred Contact Checked");

				logger.info("***************Data Filled for Telephone*********************");
			}

			else {

				logger.info("************Going to Fill data of Contact Type with No CODE found**************");
				com.suggestionTextBox_Code(BaseProject.driver, ContactType1, CTD, Contact_type_Description);
				logger.info("Contact Type Selected");

				wrap.type(BaseProject.driver, Contact_Details, ContactDetails1);
				logger.info("Contact Details Entered");

				logger.info("************Data Filled for Contact Type with No CODE found****************");
			}
		}

	}


	@Then("^Basic: Select '(.+)'$")
	public static void select_value(String selval) throws IOException, InterruptedException {

		wrap.wait(1000);
		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"), "CLIENT ID DOCUMENTS", "BYVISIBLETEXT");
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), selval, "BYVISIBLETEXT");
	}

	@Then("^Basic: Validate name accepts splcharacters$")
	public static void valsplcharnames() throws IOException, InterruptedException {

		wrap.wait(1000);
		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");
		wrap.wait(1000);

		String FirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID");
		String MiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID");
		String LastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID");

		String AliasType1 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasType1_DropDown_ID");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID");

		String docno = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", FirstName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, FirstName);

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", MiddleName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, MiddleName);

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", LastName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, LastName);

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, AliasType1, "AKA (also known as)", "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", AliasFirstName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, AliasFirstName);

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", AliasMiddleName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, AliasMiddleName);

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", AliasLastName);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, AliasLastName);

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"), "CLIENT ID DOCUMENTS", "BYVISIBLETEXT");
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), "DRIVING LIC NO", "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", docno);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, docno);

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), "VOTERS ID", "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, "', @, &,  /", docno);
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, docno);

	}

	@Then("^Basic: Validate PAN Number by enter invalid value$")
	public static void invalidPAN() throws IOException, InterruptedException {

		wrap.wait(1000);
		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");
		wrap.wait(1000);

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"), "CLIENT ID DOCUMENTS", "BYVISIBLETEXT");
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), "PAN NO", "BYVISIBLETEXT");
		wrap.wait(1000);
		wrap.type(BaseProject.driver, "AGTYT5678J", com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));
		wrap.wait(1000);
		BaseProject.driver.findElement(By.xpath("")).sendKeys(Keys.TAB);
		String invalidPANtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Please enter correct value')]")).getText();
		if (invalidPANtxt.contains("Please enter correct value")) {
			logger.info("Please enter valid PAN number");
		} else {
			logger.info("Valid PAN number entered");
		}
	}

	@Then("^Basic: Validate DOB by enter invalid value$")
	public static void invalidDOB() throws IOException, InterruptedException {

		utils.convertExcelToMap(excelPath, "BasicData_Test data_sheet.xls", "Sheet2");

		String DOB1 = DBUtils.readColumnWithRowID("DOB1", BaseProject.scenarioID);
		String DOB2 = DBUtils.readColumnWithRowID("DOB2", BaseProject.scenarioID);
		String DOB3 = DBUtils.readColumnWithRowID("DOB3", BaseProject.scenarioID);
		String DOB4 = DBUtils.readColumnWithRowID("DOB4", BaseProject.scenarioID);

		wrap.wait(1000);
		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB1, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, "01/01/2050", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		//wrap.wait(1000);
		String invalidPANtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Enter a valid past date')]")).getText();
		if (invalidPANtxt.contains("Enter a valid past date")) {
			logger.info("Please enter valid DOB for past date");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB1");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB2, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, "01/01/1850", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		//wrap.wait(1000);
		String invalidPANtxt1 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Age is more than 150 years. Please Select Valid DOB')]")).getText();
		if (invalidPANtxt1.contains("Age is more than 150 years")) {
			logger.info("Please enter valid DOB for 150yrs error message");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB2");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		wrap.wait(1000);
		String invalidPANtxt2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'age should be Less than')]")).getText();
		if (invalidPANtxt2.contains("age should be Less than")) {
			logger.info("Please enter valid DOB for 100yrs error message");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB3");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB4, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		wrap.wait(1000);
		if (BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Date of birth is selected more than 100 years')]")).isDisplayed()) {
			String invalidPANtxt3 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Date of birth is selected more than 100 years')]")).getText();
			if (invalidPANtxt3.contains("Date of birth is selected more than 100 years")) {
				logger.info("Date of birth is selected more than 100 years");
			} else {
				logger.info("Invalid error message");
			}
		} else {
			logger.info("Element is not available");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB4");

	}

	@Then("^Basic: Validate DOB by enter invalid value coapp$")
	public static void invalidDOBcoapp() throws IOException, InterruptedException {

		wrap.wait(1000);
		switchFrame();

		wrap.wait(2000);
		WebElement element1 = BaseProject.driver.findElement(By.xpath("//ul[@class='yui-nav']//span[text()='Primary Applicant']/ancestor::li//following-sibling::li//a[@title='Add a tab ']"));
		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element1);
		js.executeScript("arguments[0].click();", element1);

		utils.convertExcelToMap(excelPath, "BasicData_Test data_sheet.xls", "Sheet2");

		String DOB1 = DBUtils.readColumnWithRowID("DOB1", BaseProject.scenarioID);
		String DOB2 = DBUtils.readColumnWithRowID("DOB2", BaseProject.scenarioID);
		String DOB3 = DBUtils.readColumnWithRowID("DOB3", BaseProject.scenarioID);
		String DOB4 = DBUtils.readColumnWithRowID("DOB4", BaseProject.scenarioID);

		wrap.wait(1000);
		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB1, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, "01/01/2050", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		//wrap.wait(1000);
		String invalidPANtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Enter a valid past date')]")).getText();
		if (invalidPANtxt.contains("Enter a valid past date")) {
			logger.info("Please enter valid DOB for past date");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB1");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB2, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, "01/01/1850", com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		//wrap.wait(1000);
		String invalidPANtxt1 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Age is more than 150 years. Please Select Valid DOB')]")).getText();
		if (invalidPANtxt1.contains("Age is more than 150 years")) {
			logger.info("Please enter valid DOB for 150yrs error message");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB2");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		wrap.wait(1000);
		String invalidPANtxt2 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'age should be Less than')]")).getText();
		if (invalidPANtxt2.contains("age should be Less than")) {
			logger.info("Please enter valid DOB for 100yrs error message");
		} else {
			logger.info("Valid DOB entered");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB3");

		wrap.wait(1000);
		wrap.enterDate(BaseProject.driver, DOB4, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		//wrap.type(BaseProject.driver, DOB3, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath"));
		wrap.wait(1000);
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB4");
		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BD_CD_DOB_CommonXpath")).sendKeys(Keys.TAB);
		wrap.wait(1000);
		if (BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Date of birth is selected more than 100 years')]")).isDisplayed()) {
			String invalidPANtxt3 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Date of birth is selected more than 100 years')]")).getText();
			if (invalidPANtxt3.contains("Date of birth is selected more than 100 years")) {
				logger.info("Date of birth is selected more than 100 years");
			} else {
				logger.info("Invalid error message");
			}
		} else {
			logger.info("Element is not available");
		}
		wrap.screenShot(BaseProject.driver, screenShotPath, "DOB4");

	}


	@Then("^Basic: validate PAN number length limitation$")
	public static void PANnolength() throws IOException, InterruptedException {

		logger.info("Going to switch into frame");
		switchFrame();
		logger.info("Frame switched successfully");

		utils.convertExcelToMap(excelPath, "BasicData_Test data_sheet.xls", "Sheet2");

		String NameofDocument1 = DBUtils.readColumnWithRowID("NameofDocument1", BaseProject.scenarioID);
		String PAN1 = DBUtils.readColumnWithRowID("PAN1", BaseProject.scenarioID);
		String PAN2 = DBUtils.readColumnWithRowID("PAN2", BaseProject.scenarioID);
		String NameofDocument2 = DBUtils.readColumnWithRowID("NameofDocument2", BaseProject.scenarioID);
		String Aadhaar = DBUtils.readColumnWithRowID("Aadhaar", BaseProject.scenarioID);
		String NameofDocument3 = DBUtils.readColumnWithRowID("NameofDocument3", BaseProject.scenarioID);
		String DRL = DBUtils.readColumnWithRowID("DRL", BaseProject.scenarioID);
		String NameofDocument4 = DBUtils.readColumnWithRowID("NameofDocument4", BaseProject.scenarioID);
		String VoterID = DBUtils.readColumnWithRowID("VoterID", BaseProject.scenarioID);


		//PAN
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID"), "CLIENT ID DOCUMENTS", "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), NameofDocument1, "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, PAN1, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));

		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID")).sendKeys(Keys.TAB);

		wrap.wait(1000);
		String PANtxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Length should be 10')]")).getText();

		if (PANtxt.contains("Length should")) {
			logger.info("Invalid PAN No entered");
		}

		wrap.wait(1000);
		wrap.type(BaseProject.driver, PAN2, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));

		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID")).sendKeys(Keys.TAB);

		wrap.wait(1000);
		String PANtxt1 = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Please enter correct value')]")).getText();

		if (PANtxt1.contains("Please enter")) {
			logger.info("Invalid PAN No entered without P");
		}

		//AADHAAR
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), NameofDocument2, "BYVISIBLETEXT");

		/*wrap.wait(1000);
		wrap.type(BaseProject.driver, "123456789011", com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));

		wrap.wait(1000);
		WebElement Aadhartxt=BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Please enter valid AADHAR Number')]"));
		//String Aadhaartxt=BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Please enter valid AADHAR Number')]")).getText();

		if(!Aadhartxt.isDisplayed()){logger.info("valid Aadhaar No entered");}*/

		wrap.wait(1000);
		wrap.type(BaseProject.driver, Aadhaar, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));

		wrap.wait(1000);
		wrap.getElement(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID")).sendKeys(Keys.TAB);

		wrap.wait(1000);
		String Aadhaartxt = BaseProject.driver.findElement(By.xpath("//span[contains(text(),'Please enter valid AADHAR Number')]")).getText();

		if (Aadhaartxt.contains("valid AADHAR")) {
			logger.info("Invalid Aadhaar No entered");
		} else {
			logger.info("valid Aadhaar No entered");
		}

		//DRL
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), NameofDocument3, "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, DRL, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));

		//VOTER ID
		wrap.wait(1000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID"), NameofDocument4, "BYVISIBLETEXT");

		wrap.wait(1000);
		wrap.type(BaseProject.driver, VoterID, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));
		wrap.wait(1000);
		wrap.splcharval(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber_TextBox_ID"));


	}

	@When("^Basic: Add account section '(.*)'$")
	public void addAccsection(String j) throws Throwable {

		int i = Integer.parseInt(j);

		int k = i + 2;
		int m = i + 1;

		utils.convertExcelToMap(excelPath, "NewBDTestDataSheet.xls", "Sheet1");

		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening" + i + "", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type" + i + "", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type" + i + "", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number" + i + "", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency" + i + "", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code" + i + "", BaseProject.scenarioID);

		String Minimum_Clearing_Balance = DBUtils.readColumnWithRowID("Minimum Clearing Balance", BaseProject.scenarioID);


		String ACsection = com.getElementProperties("BasicData", "ACsection");


		String products = com.getElementProperties("BasicData", "differentproductselections");


		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		//String Purpose="xpath=(//select[@id='Purpose'])["+i+"]";
		String Purpose = "xpath=//select[@id='Purpose' and contains(@data-focus,'Products(" + m + ")')]";
		//String AccReqType="xpath=(//*[@id='IsAccountType'])["+i+"]";
		String AccReqType = "xpath=(//select[@id='IsAccountType' and contains(@data-change,'Products(" + m + ")')])";
		//String AccNum="xpath=(//input[@id='AccountNumber'])["+k+"]";
		String AccNum = "xpath=(//input[@id='AccountNumber' and contains(@data-focus,'Products(" + m + ")')])";
		String AccCurrency = "xpath=(//input[@id='Currency'])[" + k + "]";
		String ServiceType = "xpath=(//*[@id='NatureOfServices'])[" + i + "]";
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])[" + i + "]";

		logger.info(productCatagory);
		logger.info(Purpose);
		logger.info(AccReqType);
		logger.info(AccNum);
		logger.info(AccCurrency);
		logger.info(ServiceType);
		logger.info(MinClearBal);


		String ProductCategory = BaseProject.driver.findElement(By.xpath("(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)")).getText().trim();
		System.out.println("Product is" + ProductCategory);
		wrap.wait(1000);

		switch (ProductCategory) {
		case "CREDIT CARD":

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}

			/*if(Account_Request_Type.equalsIgnoreCase("New"))
	                       {
	                              //wrap.wait(500);
	                              //wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
	                              wrap.wait(500);
	                              com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency_Code,Account_Currency);
	      	                   	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
	                       }
			 */
			if (!Account_Request_Type.equalsIgnoreCase("New")) {
				wrap.wait(500);
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");
			}


			break;
		case "CURRENT ACCOUNT":
			logger.info("Moved to CA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}
			// wrap.type(BaseProject.driver, Account_Number, AccNum);
			//wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

			/* if(Account_Request_Type.equalsIgnoreCase("New"))
                      {
                             //wrap.wait(500);
                             //wrap.type(BaseProject.driver, Account_Number, AccNum);
                             wrap.wait(500);
                             com.suggestionTextBox(BaseProject.driver, AccCurrency, Account_Currency,Account_Currency_Code);
     	                   	wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Currency");
                      }
			 */


			break;
		case "SAVINGS ACCOUNT":
			logger.info("Moved to SA");
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.wait(1000);
			// wrap.click(BaseProject.driver, AccReqType);

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.wait(3000);
			wrap.getElement(BaseProject.driver, AccReqType).sendKeys(Keys.TAB);
			wrap.wait(4000);
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}
			// wrap.type(BaseProject.driver, Account_Number, AccNum);
			//wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


			break;

		case "TERM DEPOSITS":
			logger.info("Moved to TD");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");


			break;
		case "PERSONAL LOAN":

			logger.info("Moved to PL");

			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");

			wrap.click(BaseProject.driver, AccReqType);
			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
			wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


			if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.wait(500);
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
			}


			break;

		case "MORTGAGE LOAN":
			break;
		case "PROMOTIONAL PACKAGES":
			break;

		default:

			try {
				if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
					wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
					//Pur++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) {

					wrap.click(BaseProject.driver, AccReqType);
					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");


				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
					if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						wrap.wait(500);
						wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");

					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}


			try {
				if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
					wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");


				}
			} catch (Exception e) {
				System.out.println(e);
			}


			break;

		}


	}


	@When("^Basic: UAT Scenariovalidate optional and mandatory fields in Product Details section for TD$")
	public void uat_Scenario_validate_optional_and_mandatory_fields_in_prd__TD() throws Throwable {
		// Write code here that turns the phrase above into concrete actions


		//            utils.convertExcelToMap(excelPath,"NewBDTestDataSheet.xls","Sheet1");


		String campcd = DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
		String campcddesc = DBUtils.readColumnWithRowID("CampaigncodeDescription", BaseProject.scenarioID);
		String prdcd = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);

		String capmpaigncode = "xpath=(//input[@id='CampaignCode'])";
		String productcode = "xpath=(//select[@id='ProductCode'])";
		String productcodetd = "xpath=(//select[@id='ProductCode'])[2]";

		wrap.wait(4000);

		wrap.type(BaseProject.driver, campcd, capmpaigncode);
		wrap.wait(4000);
		BaseProject.driver.findElement(By.xpath("//tr[contains(@data-gargs,'" + campcd + "')]")).click();

		wrap.wait(4000);

		if (wrap.isElementPresent(BaseProject.driver, productcode)) {
			logger.info("am in product code block in basic WB");
			wrap.wait(2000);

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, productcode, prdcd, "BYVISIBLETEXT");
		}

		wrap.wait(2000);
		if (wrap.isElementPresent(BaseProject.driver, productcodetd)) {
			wrap.wait(1000);
			wrap.click(BaseProject.driver, productcodetd);
			wrap.wait(1000);

			wrap.selectFromDropDown(BaseProject.driver, productcodetd, prdcd, "BYVISIBLETEXT");
		}

		wrap.wait(3000);
		wrap.type(BaseProject.driver, "12", com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Term_txt"));

		wrap.wait(3000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Tenure_DD"), "Months", "BYVISIBLETEXT");


		wrap.wait(2000);
		wrap.type(BaseProject.driver, "23456",
				com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetails_DI_DepositAmount_Term"));
		wrap.wait(1500);
		wrap.enterDate(BaseProject.driver, "30/11/2017",
				com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetails_DI_ValueDate_Term"));
		wrap.wait(2000);
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_FundAccountChoice_DD"),
				DBUtils.readColumnWithRowID("Fund Account Choice", BaseProject.scenarioID), "BYVISIBLETEXT");
		wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Lien_No"));

		wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetails_DI_Roll_Over_Choice_Y_Term"));
		wrap.wait(2000);

		wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DI_Roll_Over_Instruction_PandInterest_Term"));
		wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_DI_Roll_Over_Instruction_PandInterest_Term"),
				"Principal and Interest", "BYVISIBLETEXT");

		wrap.typeInSuggestionTextbox(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD1_ProductDetailsSec_Interest_Frequency"), "code",
				"M");


	}

	///////----------> @@@@@


	@Then("^Basic: Switch to Product details tab$")
	public static void switchToProductDetailsTab() throws InterruptedException, IOException {

		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		//        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"));
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH")));
        wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH"), 20);
        wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ProductDetail_ProductDetails_Button_XPATH"));
		wrap.wait(2000);

	}

	@Then("^Basic: Switch to Application details tab$")
	public static void switchToApplicationDetailsTab() throws InterruptedException, IOException {

		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		//        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetails_Link"));
		wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ApplicationDetails_ApplicationDetails_Button_XPATH"));


	}

	@Then("^Basic: Negative case for Campaign code$")
	public static void passDataForNegativeAleart() throws  InterruptedException, IOException
	{
		String Locator1= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
		String AlertLocator= com.getElementProperties("BasicData", "ProductDetails_PromotionCode_Aleart");
		BasicData.NegativeAleart(Locator1,AlertLocator);

	}

	public static void NegativeAleart(String Locator1, String AlertLocator) throws InterruptedException, IOException
	{


		//################# >> With Random Data
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, Locator1)));
		WebElement element1=BaseProject.driver.findElement(By.xpath(Locator1));
		element1.click();
		element1.clear();

		wrap.TypeToTextBoxAndTabOut(BaseProject.driver, "SSSSSS", Locator1);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, AlertLocator)));
		WebElement element2=BaseProject.driver.findElement(By.xpath(AlertLocator));
		element2.click();

		if(wrap.isElementPresent(BaseProject.driver, AlertLocator))
		{	
			String AleartMsg = element2.getText();
			wrap.wait();
			logger.info("****Alert msg available :"+ AleartMsg);
		}
		else 
		{
			logger.info("****Alert msg not available****");
		}

		//################# >> With Blank Data
		element1.click();
		element1.clear();
		element1.sendKeys(Keys.TAB);
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(BaseProject.driver, AlertLocator)));

		if(wrap.isElementPresent(BaseProject.driver, AlertLocator))
		{	
			String AleartMsg = element2.getText();
			wrap.wait();
			logger.info("****Alert msg available :"+ AleartMsg);
		}
		else 
		{
			logger.info("****Alert msg not available****");
		}
	}

	@Then("^Basic: Validate fields for product '(.+)'$")
	public static void ValidateFieldsforproduct(String ProductName) throws IOException, InterruptedException 
	{

		String Locator= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
		switch (ProductName) {
		case "CA":
			wrap.typeToSuggestionTextbox(BaseProject.driver, Locator, "Code", "INCA00NA00000421");
			wrap.waitForElementVisibility(BaseProject.driver,  com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears"),10);
			logger.info("PRODUCT : CURRENT ACCOUNT");
			break;

		case "SA":
			wrap.typeToSuggestionTextbox(BaseProject.driver, Locator, "Code", "INSA00NA00000323");
			wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears"),10);
			logger.info("PRODUCT : SAVINGS ACCOUNT SECTION");
			break;

		case "TD":
			wrap.typeToSuggestionTextbox(BaseProject.driver, Locator, "Code", "INTD0PRB0000STFF");
			//        	 wrap.waitForElementVisibility(BaseProject.driver,  com.getElementProperties("BasicData", "BasicData_ProductCategory"),10);
			logger.info("PRODUCT : TERM DEPOSIT SECTION");
			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID"),"SCSF", "value");
			wrap.type(BaseProject.driver, "2", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
			wrap.selectFromDropDown(BaseProject.driver, com.getElementProperties("BasicData", "BD_TD_TD_TenureType"),"Y", "value");
			break;

		case "CC":
			wrap.typeToSuggestionTextbox(BaseProject.driver, Locator, "Code", "INCC00NA175EMRIA");
			wrap.waitForElementVisibility(BaseProject.driver,  com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears"),10);
			logger.info("PRODUCT : CREDIT CARD");
			break;

		case "PL":
			wrap.typeToSuggestionTextbox(BaseProject.driver, Locator, "Code", "INPL6075L004001");
			wrap.waitForElementVisibility(BaseProject.driver,  com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears"),10);
			logger.info("PRODUCT : PERSONAL LOAN");
			break;
		}


	}


	@When("^Basic: Data filling in Products Details Tab under Deposite Info if Available$")
	public void dataFillingInProductDetailsTabUnderDepositInfoSection() throws IOException, InterruptedException 
	{    

		logger.info("***************************** DEPOSIT INFO SECTION STARTS- TD**************************************");
		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");



		wrap.wait(2000);		 
		List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);

		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", TabNo.get(0));   	 	
		logger.info("Total Number of TABS : "+ (TabNo.size()));


		int tabNo=0;
		boolean tdFlag=false;

		for (int c = 0; c < TabNo.size(); c++) 
		{
			wrap.wait(1000);	
			logger.info("Inside Loop : "+(c+1));
			myExecutor.executeScript("arguments[0].click();", TabNo.get(c));
			logger.info("TAB NAME : "+TabNo.get(c).getText());

			String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
			logger.info("Product is" + ProductCategory);

			if(ProductCategory.equalsIgnoreCase("TERM DEPOSITS"))
			{
				logger.info("TD PRODUCT is in Tab: "+(c+1));
				tabNo=c;
				tdFlag=true;

			}
			else
			{
				logger.info("THERE IS NO TD PRODUCT");
			}
		}

		if(tdFlag)
		{
			String Productsection = com.getElementProperties("BasicData", "Productsection");
			String DepositAmount = com.getElementProperties("BasicData", "DepositInfo_DepositAmount");
			String ValueDate = com.getElementProperties("BasicData", "DepositInfo_ValueDate");
			String FundAccountChoice = com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice");
			String ChequeNumber = com.getElementProperties("BasicData", "DepositInfo_ChequeNumber");
			String ChequeDate = com.getElementProperties("BasicData", "DepositInfo_ChequeDate");
			String ChequeDrawnOn= com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn");
			String ChequeSuspenseAmount=com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount");
			String Amount=com.getElementProperties("BasicData", "DepositInfo_Amount");
			String RollOverChoiceYes=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes");
			String RollOverChoiceNo=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No");
			String RollInstruction=com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction");
			String InterestFrequency = com.getElementProperties("BasicData", "DepositInfo_InterestFrequency");
			String TwoInOneYes= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_Yes");
			String TwoInOneNo= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_No");
			String MaturityDate=com.getElementProperties("BasicData", "DepositInfo__MaturityDate");
			String LienY=com.getElementProperties("BasicData", "DepositInfo_LienY");
			String LienN=com.getElementProperties("BasicData", "DepositInfo_LienN");
			String LienAmount=com.getElementProperties("BasicData", "DepositInfo_LienAmount");
			String LienExpiryDate=com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate");
			String LienNarration=com.getElementProperties("BasicData", "DepositInfo_LienNarration");
			String NoOFDeposit=com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit");
			String TypeOfTwoInOne=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne");
			String TypeOfTwoInOneAccountNumber=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber");
			String TypeOfTwoInOneAccountCurrency=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency");
			String FundAccountNo = com.getElementProperties("BasicData", "DepositInfo_FundAccountNumber");

			String PaymentMode = com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode");
			String InterestRelationshipNo = com.getElementProperties("BasicData", "TD_DepositeInfo_InterestRelationshipNo");
			String TD_DepositeInfo_GetDetails = com.getElementProperties("BasicData", "TD_DepositeInfo_GetDetails");
			String TD_DepositeInfo_Benefeciary_Name = com.getElementProperties("BasicData", "TD_DepositeInfo_Interest_Account_Benefeciary_Name");
			String DepositInfo_header=com.getElementProperties("BasicData", "DepositInfo_header");




			////////////////////// DB        
			String Deposit_Amount = DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID);
			String Value_Date = DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID);
			String FundAccount_Choice = DBUtils.readColumnWithRowID("TD_FundAccountChoice", BaseProject.scenarioID);
			String FundAccount_No = DBUtils.readColumnWithRowID("FundAccount_No", BaseProject.scenarioID);
			String Cheque_Number = DBUtils.readColumnWithRowID("Cheque_Number", BaseProject.scenarioID);
			String Cheque_Date = DBUtils.readColumnWithRowID("Cheque_Date", BaseProject.scenarioID);
			String ChequeDrawn_On= DBUtils.readColumnWithRowID("ChequeDrawn_On", BaseProject.scenarioID);
			String ChequeSuspense_Account=DBUtils.readColumnWithRowID("ChequeSuspense_Account", BaseProject.scenarioID);
			String Amount_DI=DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID);
			String RollOverChoice= DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			String InterestAccount_Number=DBUtils.readColumnWithRowID("InterestAccountNo", BaseProject.scenarioID);
			String Interest_Frequency = DBUtils.readColumnWithRowID("TD_InterestFrequency", BaseProject.scenarioID);
			//		        String TwoInOne_No= DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID);
			String Maturity_Date=DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID);
			String Lien=DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID);
			String Lien_Amount=DBUtils.readColumnWithRowID("Lien_Amount", BaseProject.scenarioID);
			String LienExpiry_Date=DBUtils.readColumnWithRowID("LienExpiry_Date", BaseProject.scenarioID);
			//		        String Lien_Narration=DBUtils.readColumnWithRowID("Lien_Narration", BaseProject.scenarioID);
			//		        String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
			String No_of_Deposit=DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID);
			String RollOver_Choice=DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			String RollOverInstruction=DBUtils.readColumnWithRowID("RollOverInstruction", BaseProject.scenarioID);
			String TwoInOne= DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID);
			String TypeOf2in1=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne", BaseProject.scenarioID);
			String TypeOfTwoInOne_AccountNumber=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountNumber", BaseProject.scenarioID);
			String TypeOfTwoInOne_AccountCurrency=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountCurrency", BaseProject.scenarioID);
			String TD_DepositeInfo_PaymentMode= DBUtils.readColumnWithRowID("TD_DepositeInfo_PaymentMode", BaseProject.scenarioID);
			String TD_DepositeInfo_InterestRelationshipNo=DBUtils.readColumnWithRowID("TD_DepositeInfo_InterestRelationshipNo", BaseProject.scenarioID);
			String TD_DepositeInfo_Interest_Account_Benefeciary_Name=DBUtils.readColumnWithRowID("TD_DepositeInfo_Interest_Account_Benefeciary_Name", BaseProject.scenarioID);


			logger.info("Deposit_Amount: "+Deposit_Amount);
			logger.info("Value_Date: "+Value_Date);
			logger.info("FundAccount_Choice: "+FundAccount_Choice);
			logger.info("FundAccount_No: "+FundAccount_No);
			logger.info("Cheque_Number: "+Cheque_Number);
			logger.info("Cheque_Date: "+Cheque_Date);
			logger.info("ChequeDrawn_On: "+ChequeDrawn_On);
			logger.info("ChequeSuspense_Account: "+ChequeSuspense_Account);
			logger.info("Amount_DI: "+Amount_DI);
			logger.info("RollOverChoice: "+RollOverChoice);
			logger.info("InterestAccount_Number: "+InterestAccount_Number);
			logger.info("Interest_Frequency: "+Interest_Frequency);
			logger.info("Lien: "+Lien);
			logger.info("Lien_Amount: "+Lien_Amount);
			logger.info("LienExpiry_Date: "+LienExpiry_Date);
			logger.info("No_of_Deposit: "+No_of_Deposit);
			logger.info("RollOver_Choice: "+RollOver_Choice);
			logger.info("RollOverInstruction: "+RollOverInstruction);
			logger.info("TwoInOne: "+TwoInOne);
			logger.info("TypeOf2in1: "+TypeOf2in1);
			logger.info("TypeOfTwoInOne_AccountNumber: "+TypeOfTwoInOne_AccountNumber);
			logger.info("TypeOfTwoInOne_AccountCurrency: "+TypeOfTwoInOne_AccountCurrency);

			myExecutor.executeScript("arguments[0].click();", TabNo.get(tabNo));
			WebElement DI_heading = BaseProject.driver.findElement(By.xpath(DepositInfo_header));
			myExecutor.executeScript("arguments[0].scrollIntoView(true);", DI_heading);  

			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DepositAmount)));

			wrap.type(BaseProject.driver, Deposit_Amount, DepositAmount);
			logger.info("Entered Deposit Amount SuccessFully");

			//			 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ValueDate)));

			wrap.wait(2000);
			WebElement ValueDateClick = BaseProject.driver.findElement(By.xpath(ValueDate));
			myExecutor.executeScript("arguments[0].click();", ValueDateClick);

			wrap.enterDate(BaseProject.driver, Value_Date ,ValueDate);

			logger.info("Entered Value Date SuccessFully");

			/////////////--- CHEQUE/EXISTING CASA/ZERO BALANCE section

			if(FundAccount_Choice.equalsIgnoreCase("CHEQUE"))
			{
				wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
				logger.info("Selected CHEQUE SuccessFully");

				wrap.type(BaseProject.driver, Cheque_Number, ChequeNumber );
				logger.info("Entered Cheque Number SuccessFully");

				wrap.wait(1000);
				wrap.enterDate(BaseProject.driver, Cheque_Date ,ChequeDate);
				logger.info("Entered Cheque Date SuccessFully");

				wrap.type(BaseProject.driver, ChequeDrawn_On, ChequeDrawnOn);
				logger.info("Entered Cheque Drawn On SuccessFully");

				wrap.selectFromDropDown(BaseProject.driver, ChequeSuspenseAmount, ChequeSuspense_Account , "BYVISIBLETEXT");
				logger.info("Selected CHEQUE Suspense Amount SuccessFully");

				wrap.type(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");
			}
			else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA"))
			{
				wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
				logger.info("Selected EXISTING CASA SuccessFully");

				wrap.typeToTextBox(BaseProject.driver, FundAccount_No, FundAccountNo);
				logger.info("Entered Fund Account Number SuccessFully");

				wrap.typeToTextBox(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");

			}
			//             else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA")) -- NEW CASA is not applicable for the product
			else if(FundAccount_Choice.equalsIgnoreCase("ZERO BALANCE"))
			{
				wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
				logger.info("Selected ZERO BALANCE SuccessFully");

			}

			/////////////////// Roll over choice

			if(RollOverChoice.equalsIgnoreCase("YES"))
			{
				BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceYes, RollOverChoice);
				logger.info("Clicked YES on Roll Over Choice");
				if(RollOverInstruction.equalsIgnoreCase("PRINCIPAL"))
				{
					wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Roll Over Instruction ");

					wrap.selectFromDropDown(BaseProject.driver, TD_DepositeInfo_PaymentMode, PaymentMode , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Payment Mode ");

					wrap.typeToTextBox(BaseProject.driver, TD_DepositeInfo_InterestRelationshipNo , InterestRelationshipNo);
					logger.info("Interest Rel No entered Successfully");

					wrap.click(BaseProject.driver, TD_DepositeInfo_GetDetails);
					wrap.wait(2000);

					wrap.typeToTextBox(BaseProject.driver, TD_DepositeInfo_Interest_Account_Benefeciary_Name, TD_DepositeInfo_Benefeciary_Name);
					logger.info("Interest Rel No entered Successfully");

				}
				else if(RollOverInstruction.equalsIgnoreCase("Principal and interest"))
				{
					wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Roll Over Instruction: PRINCIPAL and interest ");

					wrap.wait(1000);

				}
				else{ 

					logger.info("Kindly Provide Proper Data for Roll Over Instruction from Dropdown ");
				}
				//        		 wrap.typeToSuggestionTextbox(BaseProject.driver, InterestFrequency , "Code", Interest_Frequency);
				com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, InterestFrequency, Interest_Frequency, null);
				logger.info("Entered Interest Frequenct - Suggestion Text Box");

			}
			else
			{
				BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceNo, RollOverChoice);
				logger.info("Clicked NO on Roll Over Choice");
			}

			/////////////////////// 2-in-1 section    	 
			if(TwoInOne.equalsIgnoreCase("YES"))	 
			{	 
				BasicData.ClickRadioButton(BaseProject.driver, TwoInOneYes, TwoInOne);
				logger.info("Clicked YES on 2-in-1");

				wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOne , TypeOf2in1 , "BYVISIBLETEXT");
				logger.info("Selected Type of 2-in-1 from Drop Down");

				wrap.typeToTextBox(BaseProject.driver, TypeOfTwoInOne_AccountNumber, TypeOfTwoInOneAccountNumber);
				logger.info("Entered 2-in-1 Account No.");

				wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOneAccountCurrency , TypeOfTwoInOne_AccountCurrency , "BYVISIBLETEXT");
				logger.info("Selected 2-in-1 Account Currency from Drop Down");

			}
			else
			{
				BasicData.ClickRadioButton(BaseProject.driver, TwoInOneNo, TwoInOne);
				logger.info("Selected >>>NO<<< 2-in-1 Radio Button");
			}

			/////////////////////// Lien Section
			myExecutor.executeScript("window.scrollBy(0,document.body.scrollHeight)");

			if(Lien.equalsIgnoreCase("YES"))	 
			{	 
				BasicData.ClickRadioButton(BaseProject.driver, LienY, Lien);
				logger.info("Selected >>>LIEN->YES <<< Radio Button");

				wrap.typeToTextBox(BaseProject.driver, Lien_Amount, LienAmount);
				logger.info("Entered LIEN AMOUNT Successfull");
				//        		 wrap.typeToSuggestionTextbox(BaseProject.driver, LienNarration , "Code", Lien_Narration);

			}
			else
			{
				BasicData.ClickRadioButton(BaseProject.driver, LienN, Lien); 
				logger.info("Selected >>>LIEN->NO <<< Radio Button");
			}
			wrap.type(BaseProject.driver, No_of_Deposit, NoOFDeposit);
			logger.info("Entered NO OF DEPOSIT Successfully");      

		}

		logger.info("*************************************DATA FILLING IN DEPOSIT SECTION - COMPLETED*************************************************");

	}

	@When("^Basic: Data filling in Products Details Tab under Product Detail section$")
	public void dataFillingInProductDetailsTab() throws IOException, InterruptedException {

		// This method will fill Details under Products Details Section 
		// This method can handle Bundle products aswell

		//String ProductDetails = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductDetails_Button_XPATH");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_Field");
		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_DropDown_ID");
		String ActiveProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_ActiveDropDown_ID");
		String Productsection = com.getElementProperties("BasicData", "Productsection");
		String Product_Section = BaseProject.driver.findElement(By.xpath("//h2[text()='Product Details']/../..")).getAttribute("aria-expanded");
		String CampaignCode= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
		String ProductCategoryAppears=com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_Field");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
		String Term=com.getElementProperties("BasicData", "BasicData_productdetails_Term");
		String TenureType=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
		String BundleIndicatorProperty=com.getElementProperties("BasicData", "ProductsDetails_BundleIndicator");
		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String SpecialRate=com.getElementProperties("BasicData", "BasicData_Product_SpecialRate");
		String BundleIndicator;


		if (Product_Section.equals("false"))
		{
			wrap.click(BaseProject.driver, Productsection);
			logger.info("Clicked on Product Details Tab");
		}

		String Campaign_Code= DBUtils.readColumnWithRowID("CampaignCode", BaseProject.scenarioID);
		String Product_Code = DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID);
		String TD_Term = DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID);
		String TD_Tenure = DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID);
		String Special_Rate = DBUtils.readColumnWithRowID("SpecialRate", BaseProject.scenarioID);

		String ProductCategoryText;

		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;
		WebElement Campaign_code = BaseProject.driver.findElement(By.xpath(CampaignCode));
		jse.executeScript("arguments[0].click();",Campaign_code );

		 //wrap.click(BaseProject.driver, CampaignCode);
		com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, CampaignCode, Campaign_Code, null);
		logger.info("Entered Campaign Code SuccessFully");

		wrap.wait(2000);
		//        ProductCategoryText=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryAppears)).getText();
		ProductCategoryText=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
		wrap.wait(1000);
		
		wrap.selectFromDropDown(BaseProject.driver, ProductCode, Product_Code , "BYVISIBLETEXT");
		logger.info("Entered Campaign Code SuccessFully");

		wrap.type(BaseProject.driver, Special_Rate , SpecialRate);
		wrap.wait(2000);

		logger.info("Product Category 1 is : "+ProductCategoryText);
		if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
		{
			wrap.type(BaseProject.driver, TD_Term , Term);
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, TenureType , TD_Tenure, "BYVISIBLETEXT");
			logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
		}
		else
		{
			logger.info("Successfully filled Data in Products Details Section");
		}

		wrap.waitForElementVisibility(BaseProject.driver,BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)));
		BundleIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)).getText();
		logger.info("Bundle Indicator is : "+BundleIndicator);
		if(!BundleIndicator.equalsIgnoreCase("NA"))
		{  	       	        	 
			wrap.wait(2000);
			//        	 wrap.waitForElementVisibility(BaseProject.driver,BaseProject.driver.findElement(wrap.getExactAttributeBY(PD_ActiveTabs)));             
			List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
			logger.info("Number of TABS is : "+ TabNo.size());

			String derivedCampCode=null;

			for (int c = 1; c < TabNo.size(); c++) 
			{
				wrap.wait(2000);
				logger.info("Inside Loop"+c);
				String Product_CodeX = DBUtils.readColumnWithRowID("ProductCode" + c + "", BaseProject.scenarioID); 
				jse.executeScript("arguments[0].click();", TabNo.get(c));
				logger.info("TAB NAME. : "+TabNo.get(1).getText());
				derivedCampCode=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
				logger.info("Derived "+(c+1)+" Campaign Code : "+derivedCampCode);
				wrap.selectFromDropDown(BaseProject.driver, ActiveProductCode, Product_CodeX , "BYVISIBLETEXT");

				if(derivedCampCode.equalsIgnoreCase("TERM DEPOSITS"))
				{
					wrap.type(BaseProject.driver, TD_Term , Term);
					wrap.selectFromDropDown(BaseProject.driver, TenureType, TD_Tenure , "BYVISIBLETEXT");
					logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
				}
				wrap.type(BaseProject.driver, Special_Rate , SpecialRate);
			}

			jse.executeScript("arguments[0].click();", TabNo.get(0));

		}
		else
		{ logger.info("Bundle Indicator is : NA");}

		logger.info("************************************DATA FILLING IN PRODUCT DETAILS SECTION - COMPLETED****************************************************");
	}

	public static void ClickRadioButton( WebDriver driver, String InAttribute , String Value) throws InterruptedException
	{
		if(Value.equalsIgnoreCase("YES"))
		{
			//    		driver.findElement(wrap.getExactAttributeBY(InAttribute)).click();
			wrap.click(driver, InAttribute);
			logger.info("Clicking YES for Attribute: "+ InAttribute);
		}
		else if (Value.equalsIgnoreCase("NO"))
		{
			wrap.click(driver, InAttribute);
			//    		driver.findElement(wrap.getExactAttributeBY(InAttribute)).click();
			logger.info("Clicking NO for Attribute: "+ InAttribute);

		}
		else
		{
			logger.info("USER HAD NOT PROVIDED PROPER DATA");

		}

	}

	@When("^Basic: Data filling in Products Details Tab under A/C Setup section for single Product$")
	public void dataFillingInAcSetupSectionforSingleProducts() throws Throwable {

		logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");

		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
		String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
		String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
		String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
		String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String ACsection = com.getElementProperties("BasicData", "ACsection");
		String products = com.getElementProperties("BasicData", "differentproductselections");
		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";

		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		//        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
		String AcNo_PL = DBUtils.readColumnWithRowID("AccountNumber_PL", BaseProject.scenarioID);
		String RefAccountNumber = DBUtils.readColumnWithRowID("RefAccountNumber", BaseProject.scenarioID);
		String RefAccountCurrency = DBUtils.readColumnWithRowID("RefAccountCurrency", BaseProject.scenarioID);

		logger.info("Purpose_of_account_opening :" + Purpose_of_account_opening);
		logger.info("Account_Request_Type :" + Account_Request_Type);
		logger.info("Service_Type :" + Service_Type);
		logger.info("Account_Number :" + Account_Number);
		logger.info("Account_Currency_Code :" + Account_Currency_Code);
		logger.info("AcNo_PL :" + AcNo_PL);
		logger.info("RefAccountNumber :" + RefAccountNumber);
		logger.info("RefAccountCurrency :" + RefAccountCurrency);

		JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
		String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
		logger.info("Product is " + ProductCategory);

		switch (ProductCategory) 
		{
		case "CREDIT CARD":	 

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");		
			if (Account_Request_Type.equalsIgnoreCase("New")) 
			{	
				logger.info("Account Request Type = NEW");
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}	
			else if (Account_Request_Type.equalsIgnoreCase("Insta")) {

				logger.info("Account Request Type = INSTA");
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}
			else if (Account_Request_Type.equalsIgnoreCase("Existing")) {

				logger.info("Account Request Type = Existing");
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}

			break;
		case "CURRENT ACCOUNT":
			logger.info("Moved to CURRENT ACCOUNT");
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

			if (Account_Request_Type.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
				wrap.wait(1000);
			}	
			else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");						
				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}
			else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				logger.info("Account Request Type = EXISTING");
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");

				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}	
			break;

		case "SAVINGS ACCOUNT":
			logger.info("Moved to SA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			wrap.wait(1500);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

			if (Account_Request_Type.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
			}	
			else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");						
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
			}
			else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);	                    
				wrap.wait(2000);
				wrap.click(BaseProject.driver, AccNum);
				WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",ACNum );
				wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);

			}

			break;

		case "TERM DEPOSITS":
			logger.info("Moved to TD");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
			//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
			// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
			wrap.wait(1000);

			break;
		case "PERSONAL LOAN":
			logger.info("Moved to PERSONAL LOAN");
			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

			wrap.wait(1000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

			if (Account_Request_Type.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
			}	
			else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, AcNo_PL, AccNum);
			}
			else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
				logger.info("Account Request Type = EXISTING");
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, AcNo_PL, AccNum);

			}
			break;	
		case "MORTGAGE LOAN":
			break;
		case "PROMOTIONAL PACKAGES":
			break;

		default:

			try {
				if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
					wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
					//Pur++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
				{

					wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
					if (Account_Request_Type.equalsIgnoreCase("Existing")) {
						wrap.wait(1500);
						wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}


			try {
				if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
					wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

				}
			} catch (Exception e) {
				System.out.println(e);
			}
			break;


		}
		wrap.wait(1500);

		logger.info("***********************DATA FILLING IN ACCOUNT SETTUP SECTION - COMPLETED*********************************");
	}

	@When("^Basic: Data filling in Products Details Tab under A/C Setup section for AllProducts$")
	public void dataFillingInAcSetupSectionforAllProducts() throws Throwable {

		logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");

		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
		String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
		String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
		String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
		String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String ACsection = com.getElementProperties("BasicData", "ACsection");
		String products = com.getElementProperties("BasicData", "differentproductselections");
		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String MinClearBal = "xpath=(//*[@id='MinimumClearingBalance'])";      

		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account_Number", BaseProject.scenarioID);
		//        String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
		String AcNo_PL = DBUtils.readColumnWithRowID("AccountNumber_PL", BaseProject.scenarioID);
		String RefAccountNumber = DBUtils.readColumnWithRowID("RefAccountNumber", BaseProject.scenarioID);
		String RefAccountCurrency = DBUtils.readColumnWithRowID("RefAccountCurrency", BaseProject.scenarioID);

		wrap.wait(1000);		 
		List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);

		JavascriptExecutor myExecutor = ((JavascriptExecutor) BaseProject.driver);
		myExecutor.executeScript("arguments[0].click();", TabNo.get(0));
		logger.info("Number of TABS is : "+ TabNo.size());


		for (int c = 0; c < TabNo.size(); c++) 
		{
			wrap.wait(3000);	
			logger.info("Inside Loop"+(c+1));
			myExecutor.executeScript("arguments[0].click();", TabNo.get(c));
			myExecutor.executeScript("scroll(0, 250);");
			logger.info("TAB NAME : "+TabNo.get(1).getText());

			String ProductCategory=BaseProject.driver.findElement(wrap.getExactAttributeBY(ProductCategoryActive)).getText();
			logger.info("Product is" + ProductCategory);

			switch (ProductCategory) 
			{
			case "CREDIT CARD":	 
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");	
				wrap.wait(2000);
				if (Account_Request_Type.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
				}	
				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				}
				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				}

				break;
			case "CURRENT ACCOUNT":
				logger.info("Moved to CURRENT ACCOUNT");
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
				wrap.wait(2000);
				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

				if (Account_Request_Type.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
					wrap.wait(1000);
				}	
				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");						
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				}
				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
					logger.info("Account Request Type = EXISTING");
					wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					wrap.click(BaseProject.driver, AccCurrency);
					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				}	
				break;

			case "SAVINGS ACCOUNT":
				logger.info("Moved to SA");
				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
				wrap.wait(1500);
				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

				if (Account_Request_Type.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					wrap.click(BaseProject.driver, AccCurrency);
					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
				}	
				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");						
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
				}
				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
					wrap.wait(1000);
					wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
					wrap.wait(1500);
					//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
					wrap.wait(2000);
					wrap.click(BaseProject.driver, AccNum);
					WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
					myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
					wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);

				}

				break;

			case "TERM DEPOSITS":
				logger.info("Moved to TD");
				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
				//                    com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				// wrap.type(BaseProject.driver, Account_Currency_Code, AccCurrency);	                    
				wrap.wait(1000);

				break;
			case "PERSONAL LOAN":
				logger.info("Moved to PERSONAL LOAN");
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");

				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");

				if (Account_Request_Type.equalsIgnoreCase("New")) 
				{						
					logger.info("Account Request Type = NEW");
				}	
				else if (Account_Request_Type.equalsIgnoreCase("Insta")) {
					logger.info("Account Request Type = INSTA");
					wrap.click(BaseProject.driver, AccNum);
					wrap.type(BaseProject.driver, AcNo_PL, AccNum);
				}
				else if (Account_Request_Type.equalsIgnoreCase("Existing")) {
					logger.info("Account Request Type = EXISTING");
					wrap.click(BaseProject.driver, AccNum);
					wrap.type(BaseProject.driver, AcNo_PL, AccNum);

				}
				break;	
			case "MORTGAGE LOAN":
				break;
			case "PROMOTIONAL PACKAGES":
				break;

			default:

				try {
					if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
						wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
						//Pur++;

					}
				} catch (Exception e) {
					System.out.println(e);
				}

				try {
					if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
					{

						wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

					}
				} catch (Exception e) {
					System.out.println(e);
				}

				try {
					if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
						if (Account_Request_Type.equalsIgnoreCase("Existing")) {
							wrap.wait(1500);
							wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type, "BYVISIBLETEXT");
							wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
						}
					}
				} catch (Exception e) {
					System.out.println(e);
				}


				try {
					if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
						wrap.wait(2000);
						wrap.click(BaseProject.driver, AccNum);
						WebElement ACNum = BaseProject.driver.findElement(By.xpath(AccNum));
						myExecutor.executeScript("arguments[0].scrollIntoView(true);",ACNum );
						wrap.typeToTextBox(BaseProject.driver, Account_Number, AccNum);
						wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

					}
				} catch (Exception e) {
					System.out.println(e);
				}
				break;


			}
			wrap.wait(1500);
		}
		myExecutor.executeScript("arguments[0].click();", TabNo.get(0));
		logger.info("***********************DATA FILLING IN ACCOUNT SETTUP SECTION - COMPLETED*********************************");
	} 

	@Then("^Basic: Data Filling in Product and Customer Relation$")
	public static void dataFillingInProductCustomerRelation() throws IOException, InterruptedException {

		logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");


		String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
		String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
		String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
		String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
		String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
		String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
		String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
		String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
		String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
		String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
		String ProductDetails_header=com.getElementProperties("BasicData", "ProductDetails_header");

		String FirstName_CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID);
		String MiddleName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID);
		String LastName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID);

		String FirstName_CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID);
		String MiddleName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID);
		String LastName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID);   

		String Customername_Primary = DBUtils.readColumnWithRowID("Customer Name", BaseProject.scenarioID);    
		String Relationshiptypecode_Primary = DBUtils.readColumnWithRowID("Relationship type", BaseProject.scenarioID);

		String Customername_CoApp_One = (DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID)).toUpperCase(); 
		String Relationshiptypecode__CoApp_One = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant1", BaseProject.scenarioID);

		String Customername__CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID)).toUpperCase();
		String Relationshiptypecode_CoApp_Two = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant2", BaseProject.scenarioID);     

		logger.info("Customername_CoApp_One :"+Customername_CoApp_One);
		logger.info("Relationshiptypecode__CoApp_One :"+Relationshiptypecode__CoApp_One);
		logger.info("Customername__CoApp_Two :"+Customername__CoApp_Two);
		logger.info("Relationshiptypecode_CoApp_Two :"+Relationshiptypecode_CoApp_Two);

		String ProductCategoryText=null;

		JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);
		List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
		// 	 WebElement addrow = BaseProject.driver.findElement(By.xpath(ProdAndCustomer_AddRow));
		jse.executeScript("arguments[0].click();", TabNo.get(0));
		logger.info("Number of TABS is : "+ TabNo.size());

		for (int c = 0; c < TabNo.size(); c++) 
		{	
			logger.info("Inside Loop"+(c+1));
			jse.executeScript("arguments[0].click();", TabNo.get(c));

			ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
			logger.info("ProductCategoryText : "+ ProductCategoryText);

			WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading));
			jse.executeScript("arguments[0].scrollIntoView(true);", heading);

			boolean isCustomerPresent = BaseProject.driver.findElement(By.xpath(AvailableCustomer)).isDisplayed();
			if(isCustomerPresent)
			{
				logger.info("Customer Relationship details Available");
				String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
				String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
				logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);

				logger.info(Customername_CoApp_One!=null && Customername_CoApp_One.contains("null"));
				if(Customername_CoApp_One!=null && Customername_CoApp_One.contains("null"))
				{
					logger.info("Adding Customer Relationship details - CO APPLICANT ONE");
					logger.info("Customername_CoApp_One : "+ Customername_CoApp_One);
					wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
					wrap.wait(2000);
					wrap.selectFromDropDown(BaseProject.driver, CoApplicant_One_CustomerProperty, Customername_CoApp_One,  "BYVISIBLETEXT");
					wrap.selectFromDropDown(BaseProject.driver, Relationship_One_Property, Relationshiptypecode__CoApp_One,  "BYVISIBLETEXT");

					logger.info(Customername__CoApp_Two!=null && Customername__CoApp_Two.contains("null"));
					if(Customername__CoApp_Two!=null && Customername__CoApp_Two.contains("null") )
					{
						if(!ProductCategoryText.equalsIgnoreCase("PERSONAL LOAN"))
						{
							logger.info("Adding Customer Relationship details - CO APPLICANT TWO");
							logger.info("Customername__CoApp_Two : "+ Customername__CoApp_Two);
							wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
							wrap.wait(2000);
							//            	    	 new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(CoApplicant_Two_CustomerProperty)));
							wrap.selectFromDropDown(BaseProject.driver, CoApplicant_Two_CustomerProperty, Customername__CoApp_Two,  "BYVISIBLETEXT");
							wrap.selectFromDropDown(BaseProject.driver, Relationship_Two_Property, Relationshiptypecode_CoApp_Two,  "BYVISIBLETEXT");
						}else{logger.info(" Cannot add more relationship Type for PERSONAL LOAN ");}

					}
					else
					{
						logger.info("COAPPLICANT TWO DETAILS NOT PROVIDED");
					}		 
				}
				else
				{
					logger.info("COAPPLICANT ONE DETAILS NOT PROVIDED");
				}	 
			}
			else
			{
				logger.info("Customer Relationship details Available");
				String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
				String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
				logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
			}	 
		}

		WebElement heading_PD = BaseProject.driver.findElement(By.xpath(ProductDetails_header));
		jse.executeScript("arguments[0].scrollIntoView(true);", heading_PD);
		logger.info("************************************Product and Customer Relation- ENDS*****************************************************");

	}

	@When("^Basic: Add Product and details '(.*)'$")
	public void addProduct(String j)throws Throwable 
	{
		logger.info("**************************************Adding Multiple Product - Starts****************************************************");

		//**************************************Product Details Section - Starts****************************************************

		System.out.println("No. Given is: "+j);
		int i = Integer.parseInt(j);
		int k = i + 1;

		String AssTab=com.getElementProperties("BasicData", "AddProductTab");
		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String ProductDetails = com.getElementProperties("BasicData", "Productsection");
		String CampaignCode= com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode");
		String ProductCategory = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCategory_Field");        
		String DepositType = com.getElementProperties("BasicData", "ProductCode_or_DepositType_DropDown_Xpath");        
		String ActiveProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_ActiveDropDown_ID");        
		String ProductCategoryTextAppears=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_TextAppears");
		String Term=com.getElementProperties("BasicData", "BasicData_productdetails_Term");
		String TenureType=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
		String BundleIndicatorProperty=com.getElementProperties("BasicData", "ProductsDetails_BundleIndicator");
		//        String Acquisition_indicator_Text=com.getElementProperties("BasicData", "Acquisition_indicator_Text");


		String campcd_new = DBUtils.readColumnWithRowID("Campaigncode" + i + "", BaseProject.scenarioID);
		String ProductCode_or_DepositType_new = DBUtils.readColumnWithRowID("ProductCode" + i + "", BaseProject.scenarioID);
		String campcd_old=DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID);
		String TD_Term= DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID);
		String TD_Tenure=DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID);
		String ProductCategoryText=null;
		String BundleIndicator;
		String AcquisitionIndicator;


		logger.info("campcd_new :"+campcd_new);
		logger.info("ProductCode_or_DepositType_new :"+ProductCode_or_DepositType_new);
		logger.info("campcd_old :"+campcd_old);
		logger.info("TD_Term :"+TD_Term);
		logger.info("TD_Tenure :"+TD_Tenure);


		JavascriptExecutor jse = (JavascriptExecutor) BaseProject.driver;


		if(!campcd_new.equalsIgnoreCase(campcd_old))
		{
			logger.info("campcd_new != campcd_old");

			WebElement Add_Tab = BaseProject.driver.findElement(By.xpath(AssTab));
			jse.executeScript("arguments[0].scrollIntoView(true);",Add_Tab );

			wrap.click(BaseProject.driver, AssTab);  
			wrap.wait(3000);
			logger.info("Clicked on Add Tab");

			wrap.wait(5000);
			List<WebElement> TabNo = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
			logger.info("Number of TABS is : "+ TabNo.size());
			jse.executeScript("arguments[0].click();", TabNo.get(i));

			if(k>TabNo.size())
			{
				wrap.click(BaseProject.driver, AssTab);          
				wrap.wait(3000);		  	    
				logger.info("Clicked on Add Tab");     

				List<WebElement> TabNo_Validate = wrap.getElements(BaseProject.driver, PD_ActiveTabs);
				if(k==TabNo_Validate.size())
					{logger.info("Number of TABS is : "+ TabNo_Validate.size());jse.executeScript("arguments[0].click();", TabNo.get(i));}
				else
					{logger.info("No of Tabs is not equal to the given input");}
			}
			else if(k==TabNo.size()){logger.info("No of Tabs is equal to the given input");}

			com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, CampaignCode, campcd_new, null);
			logger.info("Entered Campaign Code SuccessFully");

			wrap.wait(2000);
			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ProductCategoryActive)));
			ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
			logger.info("Product Category is : "+ProductCategoryText);

			if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
			{
				wrap.selectFromDropDown(BaseProject.driver, DepositType, ProductCode_or_DepositType_new , "BYVISIBLETEXT");
				logger.info("Selected Deposit Type SuccessFully");

				//                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(BundleIndicatorProperty)));                
				//                BundleIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(BundleIndicatorProperty)).getText();
				//                logger.info("Bundle Indicator is : "+BundleIndicator);

				//                new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(Acquisition_indicator_Text)));                
				//                AcquisitionIndicator=BaseProject.driver.findElement(wrap.getExactAttributeBY(Acquisition_indicator_Text)).getText();
				//                logger.info("Bundle Indicator is : "+AcquisitionIndicator);

				wrap.type(BaseProject.driver, TD_Term , Term);
				wrap.selectFromDropDown(BaseProject.driver, TenureType , TD_Tenure, "BYVISIBLETEXT");
				logger.info("Successfully filled Data in ***PD Tab->Products Details Section***");
			}
			else
			{
				wrap.selectFromDropDown(BaseProject.driver, DepositType, ProductCode_or_DepositType_new , "BYVISIBLETEXT");
				new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOfElementLocated(wrap.getExactAttributeBY(BundleIndicatorProperty)));  

				logger.info("Selected Deposit Type SuccessFully");

			}}
		else
		{
			logger.info("**** ERROR: CAMPAIGN CODE FOR NEW PRODUCT IS SAME AS OLD ONE*****");

		}
		//**************************************Product Details Section - Ends****************************************************   
		//**************************************Account Setup Section - Starts****************************************************
		logger.info("******************************************Data filling in Products Details Tab >> A/C Setup section STARTS*********************************");

		String AccNum=com.getElementProperties("BasicData", "AcSetup_AccountNumber");
		String AccCurrency = com.getElementProperties("BasicData", "AcSetup_AccountCurrency");
		String AccReqType = com.getElementProperties("BasicData", "AcSetup_AcReqType");
		String ServiceType = com.getElementProperties("BasicData", "AcSetup_ServiceType");
		String Purposeofaccountopening = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String ACsection = com.getElementProperties("BasicData", "ACsection");
		String products = com.getElementProperties("BasicData", "differentproductselections");
		String productCatagory = "xpath=(//span[contains(text(),'Product Category')]//ancestor::span[@class='field-caption dataLabelForRead']//following-sibling::div//span)";
		String Purpose = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");

		String Purpose_of_account_opening_new = DBUtils.readColumnWithRowID("Purpose of account opening" + i + "", BaseProject.scenarioID);
		String Account_Request_Type_new = DBUtils.readColumnWithRowID("Account Request Type" + i + "", BaseProject.scenarioID);
		String Service_Type_new = DBUtils.readColumnWithRowID("Service Type" + i + "", BaseProject.scenarioID);
		String Account_Number_new = DBUtils.readColumnWithRowID("Account_Number" + i + "", BaseProject.scenarioID);
		String Account_Currency_Code_new = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);
		String AcNo_PL_new=DBUtils.readColumnWithRowID("AccountNumber_PL" + i + "", BaseProject.scenarioID);

		logger.info("Purpose_of_account_opening_new : "+Purpose_of_account_opening_new);
		logger.info("Account_Request_Type_new : "+Account_Request_Type_new);
		logger.info("Service_Type_new : "+Service_Type_new);
		logger.info("Account_Number_new : "+Account_Number_new);
		logger.info("Account_Currency_Code_new : "+Account_Currency_Code_new);
		logger.info("AcNo_PL_new : "+AcNo_PL_new);      

		WebElement AC_section = BaseProject.driver.findElement(By.xpath(ACsection));
		jse.executeScript("arguments[0].scrollIntoView(true);",AC_section );

		switch (ProductCategoryText) 
		{
		case "CREDIT CARD":	 
			logger.info("ProductCategoryText = CREDIT CARD");

			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");	
			wrap.wait(2000);
			if (Account_Request_Type_new.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
			}	
			else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");
				wrap.wait(2000);
				WebElement Acc_Num_cc = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",Acc_Num_cc );
				wrap.click(BaseProject.driver, AccNum);
				wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
			}
			else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
				wrap.wait(1000);
				WebElement Acc_Num_cc = BaseProject.driver.findElement(By.xpath(AccNum));
				jse.executeScript("arguments[0].scrollIntoView(true);",Acc_Num_cc );
				wrap.click(BaseProject.driver, AccNum);
				wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
			}

			break;
		case "CURRENT ACCOUNT":
			logger.info("ProductCategoryText = CURRENT ACCOUNT");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
			wrap.wait(2000);

			if (Account_Request_Type_new.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				//wrap.type(BaseProject.driver, Account_Currency_Code_new, AccCurrency);	 
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);
			}	
			else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");						
				//com.suggestionTextBox2(BaseProject.driver, AccCurrency, Account_Currency_Code, Account_Currency_Code);
				//wrap.type(BaseProject.driver, Account_Currency_Code_new, AccCurrency);
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);
				wrap.click(BaseProject.driver, AccNum);
				wrap.typeToTextBox(BaseProject.driver, Account_Number_new, AccNum);
			}
			else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
				logger.info("Account Request Type = EXISTING");
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
				//wrap.click(BaseProject.driver, AccCurrency);
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                    
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, Account_Number_new, AccNum);
			}	
			break;

		case "SAVINGS ACCOUNT":
			logger.info("Moved to SA");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
			wrap.wait(2000);

			if (Account_Request_Type_new.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
				wrap.click(BaseProject.driver, AccCurrency);
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                     
			}	
			else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");						
				wrap.click(BaseProject.driver, AccCurrency);
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                   
				wrap.type(BaseProject.driver, Account_Number_new, AccNum);
			}
			else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
				logger.info("Account Request Type = EXISTING");
				wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
				//wrap.click(BaseProject.driver, AccCurrency);
				//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                  
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, Account_Number_new, AccNum);

			}
			wrap.wait(2000);

			break;

		case "TERM DEPOSITS":
			logger.info("Moved to TD");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
			wrap.click(BaseProject.driver, AccCurrency);
			//com.typetoSuggestionTextBoxUsingCode(BaseProject.driver, AccCurrency, Account_Currency_Code_new, null);                  
			wrap.wait(1000);

			break;
		case "PERSONAL LOAN":
			logger.info("Moved to PERSONAL LOAN");
			wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");	
			wrap.wait(2000);
			wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
			wrap.wait(2000);				
			if (Account_Request_Type_new.equalsIgnoreCase("New")) 
			{						
				logger.info("Account Request Type = NEW");
			}	
			else if (Account_Request_Type_new.equalsIgnoreCase("Insta")) {
				logger.info("Account Request Type = INSTA");
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, AcNo_PL_new, AccNum);
			}
			else if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
				logger.info("Account Request Type = EXISTING");
				wrap.click(BaseProject.driver, AccNum);
				wrap.type(BaseProject.driver, AcNo_PL_new, AccNum);

			}
			break;	
		case "MORTGAGE LOAN":
			break;
		case "PROMOTIONAL PACKAGES":
			break;

		default:
			logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@Unable to find PRODUCT CATEGORY@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

			try {
				if (wrap.getElement(BaseProject.driver, Purpose).isEnabled()) {
					wrap.selectFromDropDown(BaseProject.driver, Purpose, Purpose_of_account_opening_new, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "Purpose");
					//Pur++;

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, AccReqType).isEnabled()) 
				{

					wrap.selectFromDropDown(BaseProject.driver, AccReqType, Account_Request_Type_new, "BYVISIBLETEXT");
					wrap.screenShot(BaseProject.driver, screenShotPath, "AccReqType");

				}
			} catch (Exception e) {
				System.out.println(e);
			}

			try {
				if (wrap.getElement(BaseProject.driver, ServiceType).isEnabled()) {
					if (Account_Request_Type_new.equalsIgnoreCase("Existing")) {
						wrap.wait(1500);
						wrap.selectFromDropDown(BaseProject.driver, ServiceType, Service_Type_new, "BYVISIBLETEXT");
						wrap.screenShot(BaseProject.driver, screenShotPath, "ServiceType");
					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}


			try {
				if (wrap.getElement(BaseProject.driver, AccNum).isEnabled()) {
					wrap.type(BaseProject.driver, Account_Number_new, AccNum);
					wrap.screenShot(BaseProject.driver, screenShotPath, "Account_Number");

				}
			} catch (Exception e) {
				System.out.println(e);
			}
			break;
		}

		//**************************************Account Setup Section - ENDS****************************************************
		//**************************************Term Deposit Section - ENDS****************************************************
		logger.info("***************************** DEPOSIT INFO SECTION STARTS- TD**************************************");



		if(ProductCategoryText.equalsIgnoreCase("TERM DEPOSITS"))
		{

			String Productsection = com.getElementProperties("BasicData", "Productsection");
			String DepositAmount = com.getElementProperties("BasicData", "DepositInfo_DepositAmount");
			String ValueDate = com.getElementProperties("BasicData", "DepositInfo_ValueDate");
			String FundAccountChoice = com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice");
			String ChequeNumber = com.getElementProperties("BasicData", "DepositInfo_ChequeNumber");
			String ChequeDate = com.getElementProperties("BasicData", "DepositInfo_ChequeDate");
			String ChequeDrawnOn= com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn");
			String ChequeSuspenseAmount=com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount");
			String Amount=com.getElementProperties("BasicData", "DepositInfo_Amount");
			String RollOverChoiceYes=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes");
			String RollOverChoiceNo=com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No");
			String RollInstruction=com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction");
			String InterestFrequency = com.getElementProperties("BasicData", "DepositInfo_InterestFrequency");
			String TwoInOneYes= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_Yes");
			String TwoInOneNo= com.getElementProperties("BasicData", "DepositInfo_TwoInOne_No");
			String MaturityDate=com.getElementProperties("BasicData", "DepositInfo__MaturityDate");
			String LienY=com.getElementProperties("BasicData", "DepositInfo_LienY");
			String LienN=com.getElementProperties("BasicData", "DepositInfo_LienN");
			String LienAmount=com.getElementProperties("BasicData", "DepositInfo_LienAmount");
			String LienExpiryDate=com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate");
			String LienNarration=com.getElementProperties("BasicData", "DepositInfo_LienNarration");
			//String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
			String NoOFDeposit=com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit");
			String TypeOfTwoInOne=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne");
			String TypeOfTwoInOneAccountNumber=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber");
			String TypeOfTwoInOneAccountCurrency=com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency");
			String FundAccountNo = com.getElementProperties("BasicData", "DepositInfo_FundAccountNumber");
			String PaymentMode = com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode");
			String InterestAccountNumber = com.getElementProperties("BasicData", "BD_TD_TD_InterestAccountNo");
			String DepositInfo_heading=com.getElementProperties("BasicData", "DepositInfo_header");
			String InterestRelationshipNo = com.getElementProperties("BasicData", "TD_DepositeInfo_InterestRelationshipNo");
			String TD_DepositeInfo_GetDetails = com.getElementProperties("BasicData", "TD_DepositeInfo_GetDetails");
			String TD_DepositeInfo_Benefeciary_Name = com.getElementProperties("BasicData", "TD_DepositeInfo_Interest_Account_Benefeciary_Name");
			String DepositInfo_header=com.getElementProperties("BasicData", "DepositInfo_header");

			////////////////////// DB

			String Deposit_Amount = DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID);
			String Value_Date = DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID);
			String FundAccount_Choice = DBUtils.readColumnWithRowID("TD_FundAccountChoice", BaseProject.scenarioID);
			String FundAccount_No = DBUtils.readColumnWithRowID("FundAccount_No", BaseProject.scenarioID);
			String Cheque_Number = DBUtils.readColumnWithRowID("Cheque_Number", BaseProject.scenarioID);
			String Cheque_Date = DBUtils.readColumnWithRowID("Cheque_Date", BaseProject.scenarioID);
			String ChequeDrawn_On= DBUtils.readColumnWithRowID("ChequeDrawn_On", BaseProject.scenarioID);
			String ChequeSuspense_Account=DBUtils.readColumnWithRowID("ChequeSuspense_Account", BaseProject.scenarioID);
			String Amount_DI=DBUtils.readColumnWithRowID("Amount", BaseProject.scenarioID);
			String RollOverChoice= DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			String InterestAccount_Number=DBUtils.readColumnWithRowID("InterestAccountNo", BaseProject.scenarioID);
			String Interest_Frequency = DBUtils.readColumnWithRowID("TD_InterestFrequency", BaseProject.scenarioID);
			//		     String TwoInOne_No= DBUtils.readColumnWithRowID("Term", BaseProject.scenarioID);
			String Maturity_Date=DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID);
			String Lien=DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID);
			String Lien_Amount=DBUtils.readColumnWithRowID("Lien_Amount", BaseProject.scenarioID);
			String LienExpiry_Date=DBUtils.readColumnWithRowID("LienExpiry_Date", BaseProject.scenarioID);
			//			 String Lien_Narration=DBUtils.readColumnWithRowID("Lien_Narration", BaseProject.scenarioID);
			//			 String Linkage=com.getElementProperties("BasicData", "BD_TD_TD_TenureType");
			String No_of_Deposit=DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID);
			String RollOver_Choice=DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID);
			String RollOverInstruction=DBUtils.readColumnWithRowID("RollOverInstruction", BaseProject.scenarioID);
			String TwoInOne= DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID);
			String TypeOf2in1=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne", BaseProject.scenarioID);
			String TypeOfTwoInOne_AccountNumber=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountNumber", BaseProject.scenarioID);
			String TypeOfTwoInOne_AccountCurrency=DBUtils.readColumnWithRowID("TD_TypeOfTwoInOne_AccountCurrency", BaseProject.scenarioID);

			String TD_DepositeInfo_PaymentMode= DBUtils.readColumnWithRowID("TD_DepositeInfo_PaymentMode", BaseProject.scenarioID);
			String TD_DepositeInfo_InterestRelationshipNo=DBUtils.readColumnWithRowID("TD_DepositeInfo_InterestRelationshipNo", BaseProject.scenarioID);
			String TD_DepositeInfo_Interest_Account_Benefeciary_Name=DBUtils.readColumnWithRowID("TD_DepositeInfo_Interest_Account_Benefeciary_Name", BaseProject.scenarioID);



			logger.info("Deposit_Amount: "+Deposit_Amount);
			logger.info("Value_Date: "+Value_Date);
			logger.info("FundAccount_Choice: "+FundAccount_Choice);
			logger.info("FundAccount_No: "+FundAccount_No);
			logger.info("Cheque_Number: "+Cheque_Number);
			logger.info("Cheque_Date: "+Cheque_Date);
			logger.info("ChequeDrawn_On: "+ChequeDrawn_On);
			logger.info("ChequeSuspense_Account: "+ChequeSuspense_Account);
			logger.info("Amount_DI: "+Amount_DI);
			logger.info("RollOverChoice: "+RollOverChoice);
			logger.info("InterestAccount_Number: "+InterestAccount_Number);
			logger.info("Interest_Frequency: "+Interest_Frequency);
			logger.info("Lien: "+Lien);
			logger.info("Lien_Amount: "+Lien_Amount);
			logger.info("LienExpiry_Date: "+LienExpiry_Date);
			logger.info("No_of_Deposit: "+No_of_Deposit);
			logger.info("RollOver_Choice: "+RollOver_Choice);
			logger.info("RollOverInstruction: "+RollOverInstruction);
			logger.info("TwoInOne: "+TwoInOne);
			logger.info("TypeOf2in1: "+TypeOf2in1);
			logger.info("TypeOfTwoInOne_AccountNumber: "+TypeOfTwoInOne_AccountNumber);
			logger.info("TypeOfTwoInOne_AccountCurrency: "+TypeOfTwoInOne_AccountCurrency);     


			jse.executeScript("scroll(0, 250);");	 	   		 


			WebElement DepositInfo_hdng = BaseProject.driver.findElement(By.xpath(DepositInfo_heading));
			jse.executeScript("arguments[0].scrollIntoView(true);",DepositInfo_hdng );		                 
			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(DepositAmount)));

			wrap.type(BaseProject.driver, Deposit_Amount, DepositAmount);
			logger.info("Entered Deposit Amount SuccessFully");

			new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(wrap.getExactAttributeBY(ValueDate)));

			wrap.wait(2000);
			wrap.enterDate(BaseProject.driver, Value_Date ,ValueDate);
			logger.info("Entered Value Date SuccessFully");

			/////////////--- CHEQUE/EXISTING CASA/ZERO BALANCE section
			wrap.selectFromDropDown(BaseProject.driver, FundAccountChoice, FundAccount_Choice , "BYVISIBLETEXT");
			wrap.wait(2000);
			if(FundAccount_Choice.equalsIgnoreCase("CHEQUE"))
			{
				logger.info("FundAccount_Choice : CHEQUE");
				logger.info("Selected CHEQUE SuccessFully");

				wrap.type(BaseProject.driver, Cheque_Number, ChequeNumber );
				logger.info("Entered Cheque Number SuccessFully");

				wrap.wait(2000);
				wrap.enterDate(BaseProject.driver, Cheque_Date ,ChequeDate);
				logger.info("Entered Cheque Date SuccessFully");
				wrap.wait(2000); 
				wrap.type(BaseProject.driver, ChequeDrawn_On, ChequeDrawnOn);
				logger.info("Entered Cheque Drawn On SuccessFully");
				wrap.wait(2000);
				wrap.selectFromDropDown(BaseProject.driver, ChequeSuspenseAmount, ChequeSuspense_Account , "BYVISIBLETEXT");
				logger.info("Selected CHEQUE Suspense Amount SuccessFully");

				wrap.type(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");
			}
			else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA"))
			{
				logger.info("FundAccount_Choice : EXISTING CASA");
				logger.info("Selected EXISTING CASA SuccessFully");

				wrap.type(BaseProject.driver, FundAccount_No, FundAccountNo);
				logger.info("Entered Fund Account Number SuccessFully");

				wrap.type(BaseProject.driver, Amount_DI, Amount);
				logger.info("Entered Amount SuccessFully");

			}
			//          else if(FundAccount_Choice.equalsIgnoreCase("EXISTING CASA")) -- NEW CASA is not applicable for the product
			else if(FundAccount_Choice.equalsIgnoreCase("ZERO BALANCE"))
			{
				logger.info("FundAccount_Choice : ZERO BALANCE");
				logger.info("Selected ZERO BALANCE SuccessFully");

			}

			/////////////////// Roll over choice

			if(RollOverChoice.equalsIgnoreCase("YES"))
			{
				BasicData.ClickRadioButton(BaseProject.driver, RollOverChoiceYes, RollOverChoice);
				logger.info("Clicked YES on Roll Over Choice");
				if(RollOverInstruction.equalsIgnoreCase("PRINCIPAL"))
				{
					wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Roll Over Instruction ");

					wrap.selectFromDropDown(BaseProject.driver, TD_DepositeInfo_PaymentMode, PaymentMode , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Payment Mode ");

					wrap.typeToTextBox(BaseProject.driver, TD_DepositeInfo_InterestRelationshipNo , InterestRelationshipNo);
					logger.info("Interest Rel No entered Successfully");

					wrap.click(BaseProject.driver, TD_DepositeInfo_GetDetails);
					wrap.wait(2000);

					wrap.typeToTextBox(BaseProject.driver, TD_DepositeInfo_Interest_Account_Benefeciary_Name, TD_DepositeInfo_Benefeciary_Name);
					logger.info("Interest Rel No entered Successfully");

				}
				else if(RollOverInstruction.equalsIgnoreCase("Principal and interest"))
				{
					wrap.selectFromDropDown(BaseProject.driver, RollInstruction, RollOverInstruction , "BYVISIBLETEXT");
					logger.info("Drop Down Selected for Roll Over Instruction: PRINCIPAL and interest ");

					wrap.wait(1000);

				}
				else{ 

					logger.info("Kindly Provide Proper Data for Roll Over Instruction from Dropdown ");
				}

				/////////////////////// 2-in-1 section    	 
				if(TwoInOne.equalsIgnoreCase("YES"))	 
				{	 
					BasicData.ClickRadioButton(BaseProject.driver, TwoInOneYes, TwoInOne);
					logger.info("Clicked YES on 2-in-1");

					wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOne , TypeOf2in1 , "BYVISIBLETEXT");
					logger.info("Selected Type of 2-in-1 from Drop Down");

					wrap.typeToTextBox(BaseProject.driver, TypeOfTwoInOne_AccountNumber, TypeOfTwoInOneAccountNumber);
					logger.info("Entered 2-in-1 Account No.");

					wrap.selectFromDropDown(BaseProject.driver, TypeOfTwoInOneAccountCurrency , TypeOfTwoInOne_AccountCurrency , "BYVISIBLETEXT");
					logger.info("Selected 2-in-1 Account Currency from Drop Down");

				}
				else
				{
					BasicData.ClickRadioButton(BaseProject.driver, TwoInOneNo, TwoInOne);
					logger.info("Selected >>>NO<<< 2-in-1 Radio Button");
				}

				/////////////////////// Lien Section

				if(Lien.equalsIgnoreCase("YES"))	 
				{	 
					BasicData.ClickRadioButton(BaseProject.driver, LienY, Lien);
					logger.info("Selected >>>LIEN->YES <<< Radio Button");

					wrap.typeToTextBox(BaseProject.driver, Lien_Amount, LienAmount);
					logger.info("Entered LIEN AMOUNT Successfull");
					//wrap.typeToSuggestionTextbox(BaseProject.driver, LienNarration , "Code", Lien_Narration);

				}
				else
				{
					BasicData.ClickRadioButton(BaseProject.driver, LienN, Lien); 
					logger.info("Selected >>>LIEN->NO <<< Radio Button");
				}
				wrap.type(BaseProject.driver, No_of_Deposit, NoOFDeposit);
				logger.info("Entered NO OF DEPOSIT Successfully");      

			}
			else{logger.info("Deposit Section not Available for selected product");}

			logger.info("*************************************DATA FILLING IN DEPOSIT SECTION - COMPLETED*************************************************");
			logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");


			String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
			String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
			String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
			String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
			String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
			String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
			String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
			String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
			String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
			String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
			String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");

			//	     String FirstName_CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 First Name", BaseProject.scenarioID);
			//	     String MiddleName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", BaseProject.scenarioID);
			//	     String LastName__CoApp_One=DBUtils.readColumnWithRowID("Coapplicant1 Last Name", BaseProject.scenarioID);
			//
			//	     String FirstName_CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID);
			//	     String MiddleName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID);
			//	     String LastName__CoApp_Two=DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID);

			String Customername_Primary = DBUtils.readColumnWithRowID("Customer Name", BaseProject.scenarioID);    
			String Relationshiptypecode_Primary = DBUtils.readColumnWithRowID("Relationship type", BaseProject.scenarioID);

			String Customername_CoApp_One = (DBUtils.readColumnWithRowID("Coapplicant1 Full Name", BaseProject.scenarioID)).toUpperCase(); 
			String Relationshiptypecode__CoApp_One = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant1", BaseProject.scenarioID);

			String Customername_CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 Full Name", BaseProject.scenarioID)).toUpperCase();
			//	     String Customername__CoApp_Two = (DBUtils.readColumnWithRowID("Coapplicant2 First Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Middle Name", BaseProject.scenarioID)+" "+DBUtils.readColumnWithRowID("Coapplicant2 Last Name", BaseProject.scenarioID)).toUpperCase();   
			String Relationshiptypecode_CoApp_Two = DBUtils.readColumnWithRowID("RelationshipType_Coapplicant2", BaseProject.scenarioID);     

			logger.info("Customername_CoApp_One :"+Customername_CoApp_One);
			logger.info("Relationshiptypecode__CoApp_One :"+Relationshiptypecode__CoApp_One);
			logger.info("Customername__CoApp_Two :"+Customername_CoApp_Two);
			logger.info("Relationshiptypecode_CoApp_Two :"+Relationshiptypecode_CoApp_Two);



			jse.executeScript("scroll(0, 250);");
			//    	 WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading)); 	 
			//       jse.executeScript("arguments[0].scrollIntoView(true);", heading);        
			WebElement isCustomerAvailable = BaseProject.driver.findElement(By.xpath(AvailableCustomer));
			boolean isCustomerPresent= isCustomerAvailable.isDisplayed();         

			if(isCustomerPresent)
			{
				logger.info("Customer Relationship details Available");
				String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
				String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
				logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);

				if(Customername_CoApp_One!=null)
				{
					logger.info("Adding Customer Relationship details - CO APPLICANT ONE");

					boolean loop_Flag=true;
					while (loop_Flag)
					{
						logger.info("Inside loopFlag 1");
						//                		 jse.executeScript("arguments[0].click();", addrow);
						wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
						new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty))));
						if(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty)).isDisplayed()){loop_Flag=false;}
						else{logger.info("Select Customer DropDown is not displayed");}
					}
					wrap.selectFromDropDown(BaseProject.driver, CoApplicant_One_CustomerProperty, Customername_CoApp_One,  "BYVISIBLETEXT");
					wrap.selectFromDropDown(BaseProject.driver, Relationship_One_Property, Relationshiptypecode__CoApp_One,  "BYVISIBLETEXT");
					//            	     new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(addrow));
					wrap.wait(2000);

					logger.info(Customername_CoApp_Two!=null);
					if(Customername_CoApp_Two!=null )
					{
						logger.info("Adding Customer Relationship details - CO APPLICANT TWO");
						boolean loopFlag=true;
						while (loopFlag)
						{
							logger.info("Inside loopFlag 2");
							//                    		 jse.executeScript("arguments[0].click();", addrow);
							wrap.click(BaseProject.driver, ProdAndCustomer_AddRow);
							new WebDriverWait(BaseProject.driver, 60, 1000).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_Two_CustomerProperty))));
							if(BaseProject.driver.findElement(wrap.getExactAttributeBY(CoApplicant_One_CustomerProperty)).isDisplayed()){loopFlag=false;}
							else{logger.info("Select Customer DropDown is not displayed");}
						}        	    	 
						wrap.selectFromDropDown(BaseProject.driver, CoApplicant_Two_CustomerProperty, Customername_CoApp_Two,  "BYVISIBLETEXT");
						wrap.selectFromDropDown(BaseProject.driver, Relationship_Two_Property, Relationshiptypecode_CoApp_Two,  "BYVISIBLETEXT");

					}
					else
					{
						logger.info("COAPPLICANT TWO DETAILS NOT PROVIDED or CONTAINS ***NULL*** VALUE IN IT");
					}		 
				}
				else
				{
					logger.info("COAPPLICANT ONE DETAILS NOT PROVIDED or CONTAINS ***NULL*** VALUE IN IT");
				}	 
			}
			else
			{
				logger.info("Customer Relationship details Available");
				String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
				String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
				logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
			}	 


			logger.info("************************************Product and Customer Relation- ENDS*****************************************************");}


	}

	@Then("^Basic : Validate Field values '(.+)'$")
	public static void validateFieldValues(String FieldName) throws Throwable{

		JavascriptExecutor js = (JavascriptExecutor) BaseProject.driver;
		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BasicDataModel.csv");
		try{
			if(!(Fieldval[0]).equalsIgnoreCase(null)){
				//js.executeScript("arguments[0].scrollIntoView(true);",Fieldval[11]);
				//wrap.click(BaseProject.driver, com.getElementProperties("BasicData", Fieldval[11]));

				wrap.wait(2000);
				logger.info("Field validation starts"); 
				CommonUtils.validateField(Fieldval[2],Fieldval[0],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);

			}
		}

		catch(Exception E){

			System.out.println("Field : "+FieldName+" is not present in Datamodel");
		}            

	}
	
    @Then("^Basic : Validate Field with UATRef '(.+)' '(.+)'$")
    public static void validateFieldStepuatref(String fieldName,String uatref) throws IOException, InterruptedException {
    	
    	switchFrame();
    	
        try 
        {
			BasicData.validateFieldValues(fieldName);
			BaseProject.scenario.write("The field " +fieldName+ " is validated successfully and UAT Reference is " +uatref);
		} 
        catch (Throwable e) {

            System.out.println("Field : " + fieldName + " is not present in Datamodel");
        }

    }		


	@Then("^Basic: Data Filling in Product and Customer Relation for Primary$")
	public static void dataFillingInProductAndCustomerRelationForPrimary() throws IOException, InterruptedException {

		logger.info("*************************************Product and Customer Relation- STARTS***********************************************************");


		String AvailableCustomer=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomer");
		String ProdDetail_ProdCustRel_Heading=com.getElementProperties("BasicData", "BaiscData_ProdDetail_ProdCustRel_Heading");
		String ProdAndCustomer_AddRow=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AddRow");
		String PD_ActiveTabs=com.getElementProperties("BasicData", "PD_ActiveTabs");
		String CustomerName=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_AvailableCustomerName");
		String RelationType=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_RelationshipType");
		String PrimaryCustomerProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Cusname");
		String PrimaryRelationshipProperty=com.getElementProperties("BasicData", "BaiscData_ProdDetail_Reltype");
		String CoApplicant_One_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_COne_Name");
		String Relationship_One_Property=com.getElementProperties("BasicData", "Relationship_One_Type");
		String CoApplicant_Two_CustomerProperty=com.getElementProperties("BasicData", "ProdAndCustomerRelationship_CTwo_Name");
		String Relationship_Two_Property=com.getElementProperties("BasicData", "Relationship_Two_Type");
		String ProductCategoryActive=com.getElementProperties("BasicData", "BasicData_ProductCategory_ActiveTextAppears");
		String ProductDetails_header=com.getElementProperties("BasicData", "ProductDetails_header");


		String ProductCategoryText=null;

		JavascriptExecutor jse = ((JavascriptExecutor) BaseProject.driver);

		ProductCategoryText=BaseProject.driver.findElement(By.xpath(ProductCategoryActive)).getText();
		logger.info("ProductCategoryText : "+ ProductCategoryText);

		WebElement heading = BaseProject.driver.findElement(By.xpath(ProdDetail_ProdCustRel_Heading));
		jse.executeScript("arguments[0].scrollIntoView(true);", heading);

		boolean isCustomerPresent = BaseProject.driver.findElement(By.xpath(AvailableCustomer)).isDisplayed();
		if(isCustomerPresent)
		{
			logger.info("Customer Relationship details Available");
			String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
			String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
			logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);

		}
		else
		{
			logger.info("Customer Relationship details Available");
			String DerivedCustomer=BaseProject.driver.findElement(wrap.getExactAttributeBY(CustomerName)).getText();
			String DerivedRelation=BaseProject.driver.findElement(wrap.getExactAttributeBY(RelationType)).getText();
			logger.info("CUSTOMER : "+DerivedCustomer+" with RELATIONSHIP TYPE : "+ DerivedRelation);
		}	 


		logger.info("************************************Product and Customer Relation- ENDS*****************************************************");

	}
	@Then("^Basic: application details tab is clicked$")

	public static void into_applications_tab() throws InterruptedException, IOException{

		logger.info("**************************************Application Details Tab- STARTS*******************************************************");

		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("BasicData", "BasicData_ApplicationTab")));
		wrap.click(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_ApplicationTab"));
		wrap.wait(1000);
		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		wrap.wait(1000);        
	}

	@Then("^Basic: do the UI Validation part$")
	public static void do_the_UI_Validation(){


		List<WebElement> a=BaseProject.driver.findElements(By.xpath("//span[contains(text(),'AOF Date')] | //span[contains(text(),'Application Created Date')] | //span[contains(text(),'Sourcing ID')] | //span[contains(text(),'Referral ID')] | //span[contains(text(),'Country Of Account Opening')] | //span[contains(text(),'Channel Reference No')] | //span[contains(text(),'Source Reference')] |  //span[contains(text(),'Application Branch')] | //label[contains(text(),'Fast track Flag')] | //label[contains(text(),'Acquisition Channel')]"));

		Iterator<WebElement> itr2=a.iterator();

		while(itr2.hasNext())
		{
			String b=itr2.next().getText();
			System.out.println(b + "\n");
		}

	}

	@Then("^Basic: do the dropdown Validation of Application Branch$")
	public static void do_the_dropdown_Validation(){


		List<WebElement> c=BaseProject.driver.findElements(By.xpath("//select[@id='ApplicationBranch']/option"));

		//List<WebElement> e=BaseProject.driver.findElements(By.xpath("//select[@id='AcquisitionCode']/option"));

		//List<WebElement> f=BaseProject.driver.findElements(By.xpath("//select[@id='Priority']/option"));

		Iterator<WebElement> itr2=c.iterator();

		while(itr2.hasNext())
		{
			String d=itr2.next().getText();
			System.out.println(d + "\n");
		}}

	@Then("^Basic: Check for negative validation for product details tab$")
	public static void negativeValidationForProductsDetailsTab() throws IOException, InterruptedException 
	{

		//utils.convertExcelToMap(BasicData.excelPath, "Datamodel.xls", "Negative");

		//Products Details Section Fields:
		utils.negativeVals("Promotion / Campaign Code", com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode"));
		utils.negativeVals("Campaigncode", com.getElementProperties("BasicData", "BasicData_productdetails_CampaignCode"));
		utils.negativeVals("ProductCode", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Prdcd"));
		utils.negativeVals("Term", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
		utils.negativeVals("Tenure Type", com.getElementProperties("BasicData", "BD_TD_TD_TenureType"));

		//A/C Setup Section Fields:
		utils.negativeVals("Purpose of account opening", com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath"));
		utils.negativeVals("Account Request Type", com.getElementProperties("BasicData", "AcSetup_AcReqType"));
		utils.negativeVals("Account Currency Code", com.getElementProperties("BasicData", "AcSetup_AccountCurrency"));
		utils.negativeVals("Account Number", com.getElementProperties("BasicData", "AcSetup_AccountNumber"));
		utils.negativeVals("Service Type", com.getElementProperties("BasicData", "AcSetup_ServiceType"));

		//Term Deposite Section:
		utils.negativeVals("Deposit Amount", com.getElementProperties("BasicData", "DepositInfo_DepositAmount"));
		utils.negativeVals("Value Date", com.getElementProperties("BasicData", "DepositInfo_ValueDate"));
		utils.negativeVals("Fund Account Choice", com.getElementProperties("BasicData", "DepositInfo_FundAccountChoice"));
		utils.negativeVals("Cheque Number", com.getElementProperties("BasicData", "DepositInfo_ChequeNumber"));
		utils.negativeVals("Cheque Date", com.getElementProperties("BasicData", "DepositInfo_ChequeDate"));
		utils.negativeVals("Cheque Drawn on", com.getElementProperties("BasicData", "DepositInfo_ChequeDrawnOn"));
		utils.negativeVals("Cheque suspense Account", com.getElementProperties("BasicData", "DepositInfo_ChequeSuspenseAccount"));
		utils.negativeVals("Amount", com.getElementProperties("BasicData", "DepositInfo_Amount"));
		utils.negativeVals("Roll Over Choice", com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_Yes"));
		utils.negativeVals("Roll Over Choice", com.getElementProperties("BasicData", "DepositInfo_RollOverChoice_No"));
		utils.negativeVals("Roll Over Instruction", com.getElementProperties("BasicData", "DepositInfo_RollOverInstruction"));
		utils.negativeVals("Payment Mode", com.getElementProperties("BasicData", "BD_TD_TD_PaymentMode"));
		utils.negativeVals("Interest - Frequency", com.getElementProperties("BasicData", "DepositInfo_InterestFrequency"));
		utils.negativeVals("Interest Account No", com.getElementProperties("BasicData", "BD_TD_TD_InterestAccountNo"));
		utils.negativeVals("Interest Customer Name", com.getElementProperties("BasicData", "FD_AddressLine1"));
		utils.negativeVals("Interest Account Currency", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
		utils.negativeVals("Interest Account Relationship Number", com.getElementProperties("BasicData", "BD_TD_TD_TenureType"));
		utils.negativeVals("Interest Account Benefeciary Name", com.getElementProperties("BasicData", "FDC_CD_AddressSection_AddressType_suggestionBox"));
		utils.negativeVals("Interest Account Address Type", com.getElementProperties("BasicData", "FD_AddressLine1"));
		utils.negativeVals("Interest Account Disposal Code", com.getElementProperties("BasicData", "BD_TD_TD_TermPeriod"));
		utils.negativeVals("2-in-1", com.getElementProperties("BasicData", "DepositInfo_LienY"));
		utils.negativeVals("2-in-1", com.getElementProperties("BasicData", "DepositInfo_LienN"));
		utils.negativeVals("Maturity Date", com.getElementProperties("BasicData", "DepositInfo__MaturityDate"));
		utils.negativeVals("Type of 2-in-1", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne"));
		utils.negativeVals("2-in-1 Account No", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_AccountNumber"));
		utils.negativeVals("2-in-1 Currency", com.getElementProperties("BasicData", "DepositInfo_TypeOfTwoInOne_Currency"));
		utils.negativeVals("Lien", com.getElementProperties("BasicData", "DepositInfo_LienY"));
		utils.negativeVals("Lien", com.getElementProperties("BasicData", "DepositInfo_LienN"));
		utils.negativeVals("Lien Amount", com.getElementProperties("BasicData", "DepositInfo_LienAmount"));
		utils.negativeVals("Lien Expiry Date", com.getElementProperties("BasicData", "DepositInfo_LienExpiryDate"));
		utils.negativeVals("Lien Narration", com.getElementProperties("BasicData", "DepositInfo_LienNarration"));
		utils.negativeVals("No of Deposit", com.getElementProperties("BasicData", "DepositInfo_NumberOfDeposit"));

	}

	
	@Then("^Basic: Check for negative validation for customer details tab$")
	public static void negativeValidationCustomerDetails() throws IOException, InterruptedException 
	{
		utils.negativeVals("Title", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID"));
		utils.negativeVals("First name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID"));
		utils.negativeVals("Middle name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID"));
		utils.negativeVals("Last name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID"));
		utils.negativeVals("DOB", com.getElementProperties("BasicData", "BasicData_CustomerDetail_DateOfBirth1_DateText_ID"));
		utils.negativeVals("Country of birth", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID"));
		utils.negativeVals("Residence Country", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID"));
		utils.negativeVals("Nationality", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality_ListBox_ID"));
		utils.negativeVals("Are you from J&K, Meghalaya or Assam?", com.getElementProperties("BasicData", "CustomerDetailsTab_AadhaarExemptStates"));
		utils.negativeVals("Client Type", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ClientType_DropDown_ID"));
		utils.negativeVals("Authentication Mode", com.getElementProperties("BasicData", ""));
		utils.negativeVals("Contact Type", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID"));
		utils.negativeVals("Contact Details", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH"));
		utils.negativeVals("ISD Code", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID"));
		utils.negativeVals("Preferred Contact", com.getElementProperties("BasicData", "BasicData_PrefferedContact"));
		utils.negativeVals("Occupation", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID"));
		utils.negativeVals("ISIC", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH"));
		utils.negativeVals("Document Number", com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentNumber1"));
		utils.negativeVals("Document Signatory date", com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentSignatureDate1"));
		utils.negativeVals("Document Expiry Date", com.getElementProperties("BasicData", "BasicData_CustomerDetail_IDExpiryDate1"));

	}
	
	@Then("^Basic: Check for negative validation for application details tab$")
	public static void negativeValidationApplicationDetails() throws IOException, InterruptedException 
	{
		utils.negativeVals("Sourcing ID", com.getElementProperties("BasicData", "ApplicationDetailsTab_SourcingID"));
		utils.negativeVals("Referral ID", com.getElementProperties("BasicData", "ApplicationDetailsTab_ReferralID"));
		utils.negativeVals("Fast track Flag", com.getElementProperties("BasicData", "BasicData_app_details_app_details_FasttrackFlag"));
		utils.negativeVals("Application Branch", com.getElementProperties("BasicData", "ApplicationDetailsTab_ApplicationBranch"));
	}
	
	@Then("Basic: Check for lov validation in customer details tab")
	public void validate_lov_fields_customer_details() throws IOException
	{

		String SearchBy = com.getElementProperties("BasicData", "BasicData_CustomerDetail_SearchBy_DropDown_XPATH");
		String ExistingAccountCurrency = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AccountCurrency_ListBox_XPATH");
		String ProfileType = com.getElementProperties("BasicData", "BasicData_CustomerDetails_ProfileType");
		String ClientType	 = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ClientType_DropDown_ID");
		String Title = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Title_DropDown_ID");
		String ContactType = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactType_DropDown_ID");
		String ISDCode = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISDCode_DropDown_ID");
		String DocumentCategory = com.getElementProperties("BasicData", "BasicData_CustomerDetail_DocumentCategory_ID");
		String NameoftheDocument = com.getElementProperties("BasicData", "BasicData_CustomerDetail_NameoftheDocument_DropDown_ID");
		
		try {

			csvread.Read_values_from_CSV("Search By",SearchBy,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Existing Account Currency",ExistingAccountCurrency,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Profile Type",ProfileType,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Client Type",ClientType,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Title",Title,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Contact type",ContactType,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("ISD Code",ISDCode,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Document Category",DocumentCategory,"BasicDataCapture_LOVvalues.csv");
			csvread.Read_values_from_CSV("Name of the Document",NameoftheDocument,"BasicDataCapture_LOVvalues.csv");

		} catch (Throwable e) {
			e.printStackTrace();
			Assert.fail("Encountered error while validating LOV in customer details tab");
		}
	}
	
	
	@Then("Basic: Check for lov validation in product details tab")
	public void validate_lov_fields_product_details() throws IOException
	{

		String ProductCode = com.getElementProperties("BasicData", "BasicData_ProductDetails_ProductCode_ActiveDropDown_ID");
		String PurposeaccountopeningRequired = com.getElementProperties("BasicData", "BasicData_PD_PurposeofAccountOpening_Xpath");
		String AccountRequestType = com.getElementProperties("BasicData", "AcSetup_AcReqType");

		try {

			csvread.Read_values_from_CSV("ProductCode",ProductCode,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("PurposeofAccountopening",PurposeaccountopeningRequired,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("ServiceType",AccountRequestType,"BDC_CheckerLOVvalues.csv");

		} catch (Throwable e) {
			e.printStackTrace();
			Assert.fail("Encountered error while validating LOV in product details tab");
		}
	}

	@Then("Basic: Check for lov validation in application details tab")
	public void validate_lov_fields_application_details() throws IOException
	{

		String ApplicationBranch = com.getElementProperties("BasicData", "BasicData_app_details_app_details_AB");
		String AcquisitionChannel = com.getElementProperties("BasicData", "ApplicationDetailsTab_AcquisitionChannel");
		String CountryOfAccountOpening = com.getElementProperties("BasicData", "BasicData_AppDetail_CountryOfAccountOpening");
		String FasttrackFlag = com.getElementProperties("BasicData", "BasicData_app_details_app_details_FF");

		try {

			csvread.Read_values_from_CSV("ApplicationBranch",ApplicationBranch,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("AcquisitionChannel",AcquisitionChannel,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("Country Of Account Opening",CountryOfAccountOpening,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("Fast track Flag",FasttrackFlag,"BDC_CheckerLOVvalues.csv");

		} catch (Throwable e) {
			e.printStackTrace();
			Assert.fail("Encountered error while validating LOV in application details tab");
		}
	}
	
	@Then("^Basic: Check for negative validation for Account Currency Code$")
	public static void negativeValidationForAccountCurrencyCode() throws IOException, InterruptedException 
	{
		utils.negativeVals("Account Currency Code", com.getElementProperties("BasicData", "AcSetup_AccountCurrency"));
	}
	
	@Then("^Basic: Check for negative validation for First Name$")
	public static void negativeValidationForFirstName() throws IOException, InterruptedException 
	{
		utils.negativeVals("First Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_FirstName_TextBox_ID"));
	}
	
	@Then("^Basic: Check for negative validation for Middle Name$")
	public static void negativeValidationForMiddleName() throws IOException, InterruptedException 
	{
		utils.negativeVals("Middle Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_MiddleName_TextBox_ID"));
	}
	
	@Then("^Basic: Check for negative validation for Last Name$")
	public static void negativeValidationForLastName() throws IOException, InterruptedException 
	{
		utils.negativeVals("Last Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_LastName_TextBox_ID"));
	}
	
	@Then("^Basic: Check for negative validation for Alias First Name$")
	public static void negativeValidationForAliasFirstName() throws IOException, InterruptedException 
	{
		utils.negativeVals("Alias First Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1"));
	}
	
	@Then("^Basic: Check for negative validation for Alias Middle Name$")
	public static void negativeValidationForAliasMiddleName() throws IOException, InterruptedException 
	{
		utils.negativeVals("Alias Middle Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1"));
	}
	
	@Then("^Basic: Check for negative validation for Alias Last Name$")
	public static void negativeValidationForAliasLastName() throws IOException, InterruptedException 
	{
		utils.negativeVals("Alias Last Name", com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1"));
	}
	
	@Then("^Basic: Choose Alias Type$")
	public static void chooseAliasType() throws IOException, InterruptedException 
	{
		String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1");
		String AliasFirstName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasFirstName_TextBox_ID_1");
		String AliasMiddleName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasMiddleName_TextBox_ID_1");
		String AliasLastName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_AliasLastName_TextBox_ID_1");
		String Aliassection = com.getElementProperties("BasicData", "Aliassection");
		String AddAliasButton = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AddAlias_Button");
		String Aliases = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
		String AliasPreviousName = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Aliases_TextBox_ID_1");
		String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
		//String Aliases = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);
		wrap.scroll_to(BaseProject.driver, Aliassection);  
		String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
		if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

			String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
			if (AliasSection.equals("false")) {
				wrap.click(BaseProject.driver, Aliassection);

			}

			wrap.click(BaseProject.driver, AddAliasButton);
			logger.info("Alias Add Button Clicked");

			if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_1"))) {	
				wrap.wait(1000);
				wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
				String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
				logger.info("Selected Alias type is: " + AliasValue);		
				} else {
				logger.info("Alias Information Not Entered");
			}

		} else {
			logger.info("Alias Info Section Not Available");
		}

	}	
	
	@Then("^Basic: Check for negative validation for Nationality$")
	public static void negativeValidationForNationality() throws IOException, InterruptedException 
	{
		utils.negativeVals("Nationality Code1", com.getElementProperties("BasicData", "BasicData_CustomerDetail_Nationality_ListBox_ID"));
	}
			
	@Then("^Basic: Check for negative validation for Country Of Birth$")
	public static void negativeValidationForCountryOfBirth() throws IOException, InterruptedException 
	{
		utils.negativeVals("Nationality Code1", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfBirth_ListBox_ID"));
	}
		
	@Then("^Basic: Check for negative validation for Residence Country$")
	public static void negativeValidationForResidenceCountry() throws IOException, InterruptedException 
	{
		utils.negativeVals("Residence Country Code", com.getElementProperties("BasicData", "BasicData_CustomerDetail_CountryOfResidence_ListBox_ID"));
	}
	
	@Then("^Basic: Check for negative validation for Contact Details$")
	public static void negativeValidationForContactDetails() throws IOException, InterruptedException 
	{
		utils.negativeVals("Contact Details", com.getElementProperties("BasicData", "BasicData_CustomerDetail_ContactDetails_XPATH"));
	}
	
	@Then("^Basic: Choose Alias Type for coapplicant$")
	public static void chooseAliasTypeForCoapplicant() throws IOException, InterruptedException 
	{
		String AliasType = com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD_Coapp");	
		String Aliassection = com.getElementProperties("BasicData", "Aliassection");
				
		String Alias_Type = DBUtils.readColumnWithRowID("Coapplicant1 Alias Type2", BaseProject.scenarioID);

		wrap.scroll_to(BaseProject.driver, Aliassection);  
		String AliasInfoEnabled = com.getElementProperties("BasicData", "BasicData_CustomerDetails_AliasInfoEnabled");
		if(Wrapper.getTextValue(BaseProject.driver, AliasInfoEnabled).equalsIgnoreCase("Alias Info")) {

			String AliasSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Alias Info']/../..")).getAttribute("aria-expanded");
			if (AliasSection.equals("false")) {
				wrap.click(BaseProject.driver, Aliassection);

			}

			/*wrap.click(BaseProject.driver, AddAliasButton);
			logger.info("Alias Add Button Clicked");*/

			if (wrap.isElementPresent(BaseProject.driver, com.getElementProperties("BasicData", "BD_AliasInfoSect_AliasType_DD_Coapp"))) {	
				wrap.wait(2000);
				wrap.selectFromDropDown(BaseProject.driver, AliasType, Alias_Type, "BYVISIBLETEXT");
				String AliasValue = wrap.getExactAttribute(BaseProject.driver, AliasType).getAttribute("value");
				logger.info("Selected Alias type is: " + AliasValue);		
				} else {
				logger.info("Alias Information Not Entered");
			}

		} else {
			logger.info("Alias Info Section Not Available");
		}

	}	
		
	@When("^Basic: Check Default value for profile type$")
	public void checkDefaultValueProfile() throws Throwable {
		String value="CLT";
		wrap.verifyDefaultValue(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetails_ProfileType"), value );
	}
	
	@When("^Basic: Check Default value for Document category$")
	public void checkDefaultValueDocumentCategory() throws Throwable {
		String value="CLIENT ID DOCUMENTS";
		wrap.verifyDefaultDisplayText(BaseProject.driver, com.getElementProperties("BasicData", "BasicData_CustomerDetails_DocumentCategoryValue"), value );
	}

}  