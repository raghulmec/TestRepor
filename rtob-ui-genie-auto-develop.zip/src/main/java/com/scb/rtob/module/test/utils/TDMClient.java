package com.scb.rtob.module.test.utils;

//import com.standardchartered.techm.rtob.module.rtob.Commons;
//import com.standardchartered.techm.rtob.module.rtob.Wrapper;
import com.scb.rtob.module.test.config.TDMConfiguration;
import org.apache.http.client.methods.HttpGet;
//import org.apache.log4j.Logger;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient;

import org.json.JSONObject;
//import java.io.*;
//import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

//import java.io.File;
import java.io.IOException;
//import java.util.Map;

public class TDMClient {
	
//	private static Logger logger = Logger.getLogger(TDMClient.class);

    private static final String ENDPOINT_URL = TDMConfiguration.RESTFUL_ENDPOINT;

    private String RESTResponseInString;
    private String BearerAuthToken;
    private String TDM_JOBID;
    private String TDM_JOBSTATUS;
    private String TDM_GEN_ID;
    private String TDM_CONFIG_ID;
    private static String TDM_BASIC = "basic";
    private static String TDM_FULL = "full";
    public static void main(String args[]) throws Exception {


        // Send SOAP Message to SOAP Server
/*        String url = ENDPOINT_URL;

        URL endpoint = new URL(url);*/
        TDMClient tdmClient = new TDMClient();
        tdmClient.loginTDM();
        tdmClient.publishTDM(TDM_BASIC);
        tdmClient.publishTDM(TDM_FULL);

    }


//    private static String getXMLContent(String xmlFile) throws IOException {
//        String contents = new String(Files.readAllBytes(Paths.get(xmlFile)));
//
//        return contents;
//    }

    public static void runTDMPublish() throws Exception{
        TDMClient tdmClient = new TDMClient();
        tdmClient.loginTDM();
        tdmClient.publishTDM(TDM_BASIC);
        tdmClient.publishTDM(TDM_FULL);

    }
    public String getStatusTDM() throws IOException{
        String bearerAuthToken = "Bearer " + getBearerAuthTokenFromResponse();
        String jobID = getJobIDFromResponse();
        submitGet("/TDMJobService/api/ca/v1/job/" + jobID,bearerAuthToken);
        JSONObject jsonObj = new JSONObject(RESTResponseInString);
        String tmpJobStatus = jsonObj.getString("status");
            System.out.println("\n######## Job Status ########");
        System.out.println("\n" + tmpJobStatus);
        TDM_JOBSTATUS = tmpJobStatus;
        return tmpJobStatus;
    }

    public String publishTDM(String basicOrFull) throws Exception{
        if (basicOrFull == TDM_BASIC){
            TDM_GEN_ID = TDMConfiguration.GENERATOR_ID;
            TDM_CONFIG_ID = TDMConfiguration.CONFIGURATION_ID;
        } else if (basicOrFull == TDM_FULL) {
            TDM_GEN_ID = TDMConfiguration.FDC_GENERATOR_ID;
            TDM_CONFIG_ID = TDMConfiguration.FDC_CONFIGURATION_ID;
        }

        System.out.println("\n--------------TDM_GEN_ID IS" + TDM_GEN_ID + "--------------");
        System.out.println("\n--------------TDM_CONFIG_ID IS" + TDM_CONFIG_ID + "--------------");

        String bearerAuthToken = "Bearer " + getBearerAuthTokenFromResponse();
        String jsonBody = "{\n" +
                "   \"name\":\"" + TDMConfiguration.NAME + "\",\n" +
                "   \"description\":\"" + TDMConfiguration.DESCRIPTION + "\",\n" +
                "   \"projectId\":2781,\n" +
                "   \"versionId\":2782,\n" +
                "   \"type\":\"PUBLISHJOB\",\n" +
                "   \"origin\":\"generation\",\n" +
                "   \"scheduledTime\":1505887803355,\n" +
                "   \"jobs\":[\n" +
                "\n" +
                "   ],\n" +
                "   \"parameters\":{\n" +
                "      \"projectId\":2781,\n" +
                "      \"projectVersionId\":2782,\n" +
                "      \"generatorId\":" + TDM_GEN_ID + ",\n" +
                "      \"configurationId\":" + TDM_CONFIG_ID + "\n" +
                "   }\n" +
                "}";
        submitPOST("/TDMJobService/api/ca/v1/jobs",bearerAuthToken,jsonBody);
        JSONObject jsonObj = new JSONObject(RESTResponseInString);
        int tmpJobID = jsonObj.getInt("jobId");
        TDM_JOBID = String.valueOf(tmpJobID);
        System.out.println("\n######## Job ID ########");
        System.out.println("\n" + TDM_JOBID);
        String returnStatus = waitPublishTDM();
        if (!returnStatus.equalsIgnoreCase("Completed")){
            throw new Exception("TDM Status is still not [Completed] after retried for " + TDMConfiguration.REFRESH_WAIT_RETRY_LIMIT);
        }
        return returnStatus;

    }

    public String waitPublishTDM() throws Exception{
        int waitTimeInMs = TDMConfiguration.REFRESH_WAIT_MS;
        int retryLimit = TDMConfiguration.REFRESH_WAIT_RETRY_LIMIT;
        String refreshedStatus = "NA";
        for (int retry=0;retry<retryLimit;retry++){


            refreshedStatus = getStatusTDM();
            System.out.println("\n[Retry=" + retry + "] refreshedStatus:" + refreshedStatus);
            if (refreshedStatus.equalsIgnoreCase("Completed"))
            {
                break;
            }
            Thread.sleep(waitTimeInMs);
        }
        return refreshedStatus;
    }
    public void loginTDM() throws IOException{
        submitPOST("/TestDataManager/user/login",TDMConfiguration.BASICAUTH_KEY,"");
        JSONObject jsonObj = new JSONObject(RESTResponseInString);
        String tmpToken = jsonObj.getString("token");
        System.out.println("\n######## Token ########");
        System.out.println("\n" + tmpToken);
        BearerAuthToken = tmpToken;
    }

    public String getJobStatusFromResponse() {

        return TDM_JOBSTATUS;
    }

    public String getJobIDFromResponse() {

        return TDM_JOBID;
    }

    public String getBearerAuthTokenFromResponse() {

        return BearerAuthToken;
    }
    // HTTP POST request
    public void submitPOST(String urlResource,String AuthValue,String jsonString) throws IOException{

        //String strMsg = getXMLContent(XMLfile);
        HttpResponse response;
        String url = ENDPOINT_URL + urlResource;
        HttpClient httpClient = HttpClientBuilder.create().build(); // Use this instead

        HttpPost request = new HttpPost(url);
        StringEntity params = new StringEntity(jsonString);
        params.setContentType("application/json");
        request.setHeader("Authorization",AuthValue);
        request.setEntity(params);
        response = httpClient.execute(request);

        System.out.println("\n=== ######## POST ######## ===");
        System.out.println("\nSending 'POST' (" + request.getProtocolVersion() + ") request to URL : " + url);
        System.out.println("Response Code: " + response.getStatusLine().getStatusCode());

        HttpEntity entity = response.getEntity();
        RESTResponseInString = EntityUtils.toString(entity, "UTF-8");

        System.out.println("\n######## RESPONSE ########");
        System.out.println("\n" + RESTResponseInString);

        //  return response;
    }

    public void submitGet(String urlResource,String AuthValue) throws IOException{
        HttpResponse response;
        String url = ENDPOINT_URL + urlResource;
        HttpClient httpClient = HttpClientBuilder.create().build(); // Use this instead

        HttpGet request = new HttpGet(url);
        request.setHeader("Authorization",AuthValue);
        response = httpClient.execute(request);

        System.out.println("\n=== ######## GET ######## ===");
        System.out.println("\nSending 'GET' (" + request.getProtocolVersion() + ") request to URL : " + url);
        System.out.println("Response Code: " + response.getStatusLine().getStatusCode());

        HttpEntity entity = response.getEntity();
        RESTResponseInString = EntityUtils.toString(entity, "UTF-8");

        System.out.println("\n######## RESPONSE ########");
        System.out.println("\n" + RESTResponseInString);
    }


//    public boolean verify

}
