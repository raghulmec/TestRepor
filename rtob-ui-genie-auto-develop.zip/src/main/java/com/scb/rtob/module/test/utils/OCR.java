/*package com.scb.rtob.module.test.framework;

import java.util.HashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.jayway.jsonpath.JsonPath;
import com.scb.cs.client.*;
import com.scb.exception.CSException;
import com.scb.exception.DCException;
import com.scb.util.*;
import com.scb.dc.client.*;

import cucumber.api.java.en.Given;

public class OCR {
	
	public static JSONObject batchResponse = null;
	
	public static String URL= "http://10.23.210.32:9080/OCRServices22";
	public static String ConsumerKey = "rtobuser";
	public static String ConsumerSecret = "rtob#1234";
	public static String RequestorID = "1434669";
	public static String ObjectStore = "RBOS";
	public static String DocClass = "RTLDoc";
	public static String batchId = null;
	public static HashMap<String, String> tokens=null;
	
	public static JSONObject responseJSON = null;
	
	@Given("^Call the OCR service to get the Batch ID$")
	public static void getOCRBatch() throws Throwable {
		
			System.out.println("Start of OCR call");
			
			HashMap<String, String> sourceSysParams =  new HashMap<String, String>();
			
			*//***************
			 * 
			 * AppRefNo,DocType,DocID should be fetched from Database. 
			 *  
			 * ******************//*
			
			String AppRefNo = "IN20180212000077";
			String DocType ="T0235";
			String DocID ="{EF53222D-4C4D-4F4F-88FC-213F438A643C}";
			
            sourceSysParams.put("SrcSysRefID", AppRefNo);
            sourceSysParams.put("Country", "IN");
            sourceSysParams.put("ChannelType", "eOPS");
            sourceSysParams.put("CompanyCode", "9999");
            sourceSysParams.put("Version", "00");
            sourceSysParams.put("DocumentType", DocType);
            sourceSysParams.put("DocID", DocID);
			
			DC dcObj = new DC(URL);
			
			try 
			{ 
			  tokens = dcObj.requestToken(ConsumerKey,ConsumerSecret, RequestorID);
			}
			  
			catch(Exception ex) 
			{ 
			    ex.printStackTrace();
			}
			
			System.out.println(tokens);
			
			batchId = (dcObj.ocrDocumentFromFN(tokens.get("requestToken"), tokens.get("tokenSecret"), 
					ConsumerSecret, ObjectStore, DocClass, sourceSysParams));
			
			JSONParser parser = new JSONParser();
			batchResponse = (JSONObject) parser.parse(batchId);
			
			System.out.println("Batch : "+batchId);
			
			System.out.println(JsonPath.parse(batchResponse).read("$.BatchID"));			
			
	}
	
	@Given("^Call the OCR service to get the JSON response$")
	public static void getJSONResponse() throws Throwable {
		
		DC dcObj = new DC(URL);
		
		tokens = dcObj.requestToken("rtobuser","rtob#1234", "1434669");
		
		System.out.println(dcObj.getOCRResponse(tokens.get("requestToken"), tokens.get("tokenSecret"), ConsumerSecret, JsonPath.parse(batchResponse).read("$.BatchID").toString()));
		//System.out.println(dcObj.getOCRResponse(tokens.get("requestToken"), tokens.get("tokenSecret"), "rtob#1234", "dcap_icn_admin_hk-220218.000042"));	
		
	}

}
*/