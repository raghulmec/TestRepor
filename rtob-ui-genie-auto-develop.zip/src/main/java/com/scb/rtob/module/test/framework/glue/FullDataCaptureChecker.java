	package com.scb.rtob.module.test.framework.glue;


	import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Properties;

	import com.scb.rtob.module.test.utils.DBUtils;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

	import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;

	import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static com.scb.rtob.module.test.framework.XMLParser.envName;


	public class FullDataCaptureChecker {
		File file;
		Properties CONFIG ;
		static BusinessCommonUtils businesscommonutils= new BusinessCommonUtils();

		
		public static String screenShotPath = "C:/CaptureScreenshot";
		
		public FullDataCaptureChecker()
		{
			String envName = System.getProperty("env");
			URL resource = DBUtils.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
			File file = null;
			FileInputStream fis = null;
			try {
				file = new File(resource.toURI());
				fis = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
			CONFIG = new Properties();
			try {
				CONFIG.load(fis);
			} catch (IOException e) {

				e.printStackTrace();
			}

		}


		static CommonUtils utils= new CommonUtils();
		static BusinessCommonUtils businessutil= new BusinessCommonUtils();
		public static String excelPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"ExcelData";

		static Wrapper wrap = new Wrapper();
		// Wrapper wrap = new Wrapper();
		static Commons com = new Commons();
		public static WebDriver driver=BaseProject.driver;
		public static WebDriverWait wait = new WebDriverWait(driver, 30);
		public static Logger logger = Logger.getLogger(FullDataCaptureChecker.class);

		@Given("^Read customer Details tab values$")
		public void Read_customer_Personal_values() throws Throwable {
			fullDataCaptureCheckrCustomerDetails();
		}
		//And Read Product Personal values
		// And Read Application Personal values

		@Given("^Read Product Details tab values$")
		public void Read_Product_Personal_values() throws Throwable {
			fullDataCaptureCheckrProductDetails();
		}

		@Given("^Read Application Details values$")
		public void Read_Application_Personal_values() throws Throwable {
			fullDataCaptureCheckrApplicationdetails();
			Thread.sleep(3000);
		}
		
		@Given("^Read Document Details values$")
		public void Read_Document_values() throws Throwable {
			fullDataCaptureCheckerDocumnetdetails();
			Thread.sleep(3000);
		//    fullDataCaptureCheckerMultipleIncomeDocuments();
			
			

			
		}

		@Given("^FDC: Switch to frame$")
		public  void switchFrame() throws InterruptedException {
			int Last = 0;
			wrap.wait(500);
			BaseProject.driver.switchTo().defaultContent();
			wrap.wait(500);
			List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
			for (WebElement frame : frames) {

				logger.info(frame.getAttribute("Name"));
			}

			Last = frames.size() - 1;
			logger.info(Last);
			BaseProject.driver.switchTo().frame(Last);
			wrap.wait(500);
		}
		public void fullDataCaptureCheckrCustomerDetails() throws IOException, InterruptedException{

			//###############################Headers and Buttons ########################
			String CustomerDetails =com.getElementProperties("Fulldatacapturechecker","FDCC_CustomerDetails_Tab");
			String Customer_Personal_Details =com.getElementProperties("Fulldatacapturechecker","FDCC_PrimaryApplicant");
			String Customer_Alias_Details =com.getElementProperties("Fulldatacapturechecker","FDC_Customer_Alias_Details_Header");
		   // String DocumentCategory =com.getElementProperties("Fulldatacapturechecker","FDC_Customer_Personal_Details_Header");
			String customer_tab_relatedParty_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_relatedParty_header");
			String customer_tab_Addrss =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Addrss_header");
			String customer_tab_contact = com.getElementProperties("Fulldatacapturechecker", "FDC_customer_tab_Contact_header");
			String customer_tab_communication_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_communication_header");
			String customer_tab_Employment_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Employment_header");
			String customer_tab_GST_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_GST_header");
			String customer_tab_FATCA_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_FATCA_header");
			String customer_tab_Document_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Document_header");
			String customerDetails_CDD_info = com.getElementProperties("Fulldatacapturechecker", "FDC_customer_tab_CDD_header");
			String customer_tab_CDD_OAT_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_CDD_OAT_header");
			String customer_tab_Internal_header = com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Internal_header");
			String customer_tab_AOF_Signature_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_AOF_Signature_header");
			String customer_tab_MoreFinancial_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_MoreFinancial_header");
			String customer_tab_Banking_services_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Banking_services_header");
			String customer_tab_MarketingDetails_header =com.getElementProperties("Fulldatacapturechecker"," FDC_customer_tab_MarketingDetails_header");
		   

			//############################Each Sub details #########################
			String CustomerDetails_Fields=com.getElementProperties("Fulldatacapturechecker","FDC_CustomerDetails_Fields");
			String CustomerDetails_values =com.getElementProperties("Fulldatacapturechecker","FDC_CustomerDetails_values");
			String CustomerDetails_Alias_fields =com.getElementProperties("Fulldatacapturechecker", "FDC_CustomerDetails_Alias_Fields");
			String CustomerDetails_Alias_values =com.getElementProperties("Fulldatacapturechecker", "FDC_CustomerDetails_Alias_values");
			String RelatedParty_fields =com.getElementProperties("Fulldatacapturechecker","FDC_relatedParty_fields");
			String RelatedParty_values=com.getElementProperties("Fulldatacapturechecker","FDC_relatedParty_values");
			String Address_fields =com.getElementProperties("Fulldatacapturechecker","FDC_Address_fields");
			String Address_values =com.getElementProperties("Fulldatacapturechecker","FDC_Address_values");
			String Contact_fields =com.getElementProperties("Fulldatacapturechecker","FDC_Contact_fields");
			String Contact_values =com.getElementProperties("Fulldatacapturechecker","FDC_Contact_values");
			String Communication_fields =com.getElementProperties("Fulldatacapturechecker","FDC_Communication_fields");
			String Communication_values =com.getElementProperties("Fulldatacapturechecker","FDC_Communication_values");
			String EmployeeMent_fields =com.getElementProperties("Fulldatacapturechecker","FDC_EmployeeMent_fields");
			String EmployeeMent_values =com.getElementProperties("Fulldatacapturechecker","FDC_EmployeeMent_values");
			String GST_fields =com.getElementProperties("Fulldatacapturechecker","FDC_GST_fields");
			String GST_values =com.getElementProperties("Fulldatacapturechecker","FDC_GST_values");
			//String FatacaAndDocument_values =com.getElementProperties("Fulldatacapturechecker","FDC_FatacaAndDocument_values");
			//String DocumentDetails_values = com.getElementProperties("Fulldatacapturechecker", "FDC_DocumentDetails_values");
			String CDD_OAT_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_CDD(OAT)_fields");
			String CDD_OAT_values = com.getElementProperties("Fulldatacapturechecker", "FDC_CDD(OAT)_values");
			String CDDInformation_fields = com.getElementProperties("Fulldatacapturechecker","FDC_CDDINFO_fields");
			String CDDInformation_values = com.getElementProperties("Fulldatacapturechecker","FDC_CDDINFO_values");
			String InternalValues_fields =com.getElementProperties("Fulldatacapturechecker","FDC_InternalValues_fields");
			String InternalValues_values =com.getElementProperties("Fulldatacapturechecker","FDC_InternalValues_values");
			String AOF_Signature_fields =com.getElementProperties("Fulldatacapturechecker","FDC_AOF_Signature_fields");
			String AOF_Signature_Values =com.getElementProperties("Fulldatacapturechecker","FDC_AOF_Signature_values");
			String MoreFinancial_fields =com.getElementProperties("Fulldatacapturechecker","FDC_MoreFinancial_fields");
			String MoreFinancial_Values =com.getElementProperties("Fulldatacapturechecker","FDC_MoreFinancial_values");
			String Banking_services_fields =com.getElementProperties("Fulldatacapturechecker","FDC_Banking_services_fields");
			String Banking_services_values =com.getElementProperties("Fulldatacapturechecker","FDC_Banking_services_values");
			String MarketingDetails_fields =com.getElementProperties("Fulldatacapturechecker","FDC_MarketingDetails_fields");
			String MarketingDetails_values =com.getElementProperties("Fulldatacapturechecker","FDC_MarketingDetails_values");
			
			
			switchFrame();
			//wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
			System.out.println(CustomerDetails);
			String customerDetails = wrap.getElement(driver, CustomerDetails).getText();
			//wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, customerDetails)));
			logger.info(customerDetails);
			System.out.println(customerDetails);
			logger.info("###############################");
			System.out.println("###############################");
			//com.validateFiledVisible(driver, DocumentCategory);
			try{
				
				/******************Personal Details Section******************/
				if(wrap.validateFiledVisible1(driver, Customer_Personal_Details))
					//TO read the values under Personal Details section and check editable/non-editable
					logger.info("Customer_Personal_Details");
					wrap.validateEditable(driver, CustomerDetails_Fields,CustomerDetails_values,"Customer_Personal_Details");
		 

			
			/******************Customer Alias  Section******************/
			if(wrap.validateFiledVisible1(driver, Customer_Alias_Details)){
				wrap.scroll_to(driver, Customer_Alias_Details);
				logger.info("Customer_Alias_Details");
				wrap.validateEditable(driver, CustomerDetails_Alias_fields,CustomerDetails_Alias_values,"Customer_Alias_Details");
			}
			/******************RelatedParty Details Section******************/        
			if(wrap.validateFiledVisible1(driver, customer_tab_relatedParty_header)){
				wrap.scroll_to(driver, customer_tab_relatedParty_header);
				logger.info("Related Parties Details");
				wrap.validateEditable(driver, RelatedParty_fields,RelatedParty_values,"Related Parties Details");
			}
			else{
				logger.info("Related Parties Details is not present");
			}
			/******************Contact Details Section******************/   
			if(wrap.validateFiledVisible1(driver, customer_tab_contact)){
				wrap.scroll_to(driver, customer_tab_contact);
				logger.info("Contact Details Section");
				wrap.validateEditable(driver,Contact_fields,Contact_values,"Contact Details Section");
			}
			/******************Address Details Section******************/   
			if(wrap.validateFiledVisible1(driver, customer_tab_Addrss)){
				wrap.scroll_to(driver, customer_tab_Addrss);
				logger.info("Address Details Section");
				wrap.validateEditable(driver,Address_fields,Address_values,"Address Details Section");
				
			}
			/******************Communication Details Section******************/   
			if(wrap.validateFiledVisible1(driver, customer_tab_communication_header)){
				   wrap.scroll_to(driver, customer_tab_communication_header);
				   logger.info("Communication Details Section");
				   wrap.validateEditable(driver,Communication_fields,Communication_values,"Communication Details Section");
			}

			
			
			//        /******************FATCA Details Section******************/  
	//        if(wrap.validateFiledVisible1(driver, customer_tab_FATCA_header)){
	//        	logger.info("FATCA Details Section");
	//        	
	//        }
	//        else
	//        {
	//        	logger.info("FATCA Details Section is not present");
	//        }
		 
					/******************Employment Section******************/   
			if(wrap.validateFiledVisible1(driver, customer_tab_Employment_header)){
				   wrap.scroll_to(driver, customer_tab_Employment_header);
				   logger.info("Employment Section");
				   wrap.validateEditable(driver,EmployeeMent_fields,EmployeeMent_values,"Employment Details");
			}
		 
			/******************GST Details Section******************/  
		 if(wrap.validateFiledVisible1(driver, customer_tab_GST_header)){
			 wrap.scroll_to(driver, customer_tab_GST_header);
			 logger.info("GST Details Section");
			 wrap.validateEditable(driver,GST_fields,GST_values,"GST Details");
		 }
		 /******************CDD Details Section******************/  
		 if(wrap.validateFiledVisible1(driver, customerDetails_CDD_info)){
			 wrap.scroll_to(driver, customerDetails_CDD_info);
			 logger.info("CDD Details Section");
			 wrap.validateEditable(driver,CDDInformation_fields,CDDInformation_values,"CDD Details");
		 }     
		 /******************Internal Section******************/     
		 if(wrap.validateFiledVisible1(driver,customer_tab_Internal_header)){
			 wrap.scroll_to(driver,customer_tab_Internal_header);
			 logger.info("Internal Section");
			 wrap.validateEditable(driver,InternalValues_fields,InternalValues_values,"Internal  Details");
		 }
		 else{
			logger.info("Internal Section is not present");
		 }
		 /******************AOF Section******************/         
		 if(wrap.validateFiledVisible1(driver,customer_tab_AOF_Signature_header)){
			 wrap.scroll_to(driver,customer_tab_AOF_Signature_header);
			 logger.info("AOF Details");
			 wrap.validateEditable(driver, AOF_Signature_fields,AOF_Signature_Values,"AOF Details");
		 }
	 
			/******************More Financial Section******************/         
				try{
				 if(wrap.validateFiledVisible1(driver,MoreFinancial_Values)){
				
					   wrap.scroll_to(driver,MoreFinancial_Values);
					   logger.info("More Financial Details");
					   wrap.validateEditable(driver, MoreFinancial_fields,MoreFinancial_Values,"More Financial Details");
				   }
				   else{
					logger.info("More Financial Details Section Fields are not present");
				   }
	 
				 
				 
			   /******************CDD OAT Section******************/         
				 if(wrap.validateFiledVisible1(driver,customer_tab_CDD_OAT_header)){
					 wrap.scroll_to(driver,customer_tab_CDD_OAT_header);
					 logger.info("CDD OAT Details");
					 wrap.validateEditable(driver, CDD_OAT_fields,CDD_OAT_values,"CDD OAT Details");
				 }
				 /******************Banking Services Section******************/         
				 if(wrap.validateFiledVisible1(driver,customer_tab_Banking_services_header )){
					 wrap.scroll_to(driver,customer_tab_Banking_services_header );
					 logger.info("Banking Services");
					 wrap.validateEditable(driver,Banking_services_fields,Banking_services_values,"Banking Services");
				 }
				 else{
					 logger.info("Banking Services is not present");
				 }
				  /******************Marketing Preferences Section******************/         
				  if(wrap.validateFiledVisible1(driver,MarketingDetails_fields)){
					  wrap.scroll_to(driver,MarketingDetails_fields);
					  logger.info("Marketing Preferences_Details");
					  wrap.validateEditable(driver,MarketingDetails_fields,MarketingDetails_values,"Marketing Preferences Details");
				  }
				  else
				  {
					 logger.info("Marketing Preferences_Details not available");
				  }
				  

				 
				}catch(IndexOutOfBoundsException e)
				{
				 
				}
				
				
			logger.info("Customer Details are read and validated");
			}
			catch(Exception e){
				System.out.println("Unable to select"+e);
			}

		}

		public static void fullDataCaptureCheckrProductDetails() throws IOException, InterruptedException{

			String Product_tab_Product_header =com.getElementProperties("Fulldatacapturechecker","FDC_Product_tab_Product_header");
			String Product_tab_Nominee_header =com.getElementProperties("Fulldatacapturechecker","FDC_Product_tab_Nominee_header ");
			String Product_tab_AC_setup_header =com.getElementProperties("Fulldatacapturechecker","FDC_Product_tab_A/C_setup_header");
			String Product_tab_Product_Request = com.getElementProperties("Fulldatacapturechecker", "FDC_Product_tab_Product_Request");
			String customer_tab_Banking_services_header =com.getElementProperties("Fulldatacapturechecker","FDC_customer_tab_Banking_services_header");
			String Product_tab_BankUse = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_BankUse_header");
			String Product_tab_Repayment_header=com.getElementProperties("Fulldatacapturechecker", "FDC_Product_tab_Repayment_Details");
			String Product_tab_Disbursement_header=com.getElementProperties("Fulldatacapturechecker", "FDC_Product_tab_Disbursement_Details");
			
			String Product_tab_App_Relationship_header=com.getElementProperties("Fulldatacapturechecker", "FDC_Product_tab_App_Relationship_header");
			
			String ProductDetails =com.getElementProperties("Fulldatacapturechecker","FDCC_ProductDetails_Tab");
			
			String ProductDetails_fields=com.getElementProperties("Fulldatacapturechecker","FDC_Product_Details_fields");
			String ProductDetails_Values = com.getElementProperties("Fulldatacapturechecker","FDC_Product_Details_Values");
			String NomineeKey_Information_fields = com.getElementProperties("Fulldatacapturechecker","FDC_Nominee_Key_Information_fields");
			String NomineeKey_Information_values = com.getElementProperties("Fulldatacapturechecker","FDC_Nominee_Key_Information_values");     
			String ACSetup_fields = com.getElementProperties("Fulldatacapturechecker","FDC_A/C_Setup_Fields");
			String ACSetup_values = com.getElementProperties("Fulldatacapturechecker","FDC_A/C_Setup_values");
			String Product_Request_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Product_Request_fields");
			String Product_Request_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Product_Request_values");
			String RepaymentVal_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_RepaymentDetails_fields");
			String RepaymentVal_values = com.getElementProperties("Fulldatacapturechecker", "FDC_RepaymentDetails_values");
		   
			String DisbursementVal_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_DisbursementDetails_fields");
			String DisbursementVal_values = com.getElementProperties("Fulldatacapturechecker", "FDC_DisbursementDetails_values");
		   
			String BankingUse_fields =com.getElementProperties("Fulldatacapturechecker", "FDC_BankingUse_fields");
			String BankingUse_values =com.getElementProperties("Fulldatacapturechecker", "FDC_BankingUse_values");
			String App_Relationship_Details_fields =com.getElementProperties("Fulldatacapturechecker", "FDC_App_Relationship_Details_fields");
			String App_Relationship_Details_values =com.getElementProperties("Fulldatacapturechecker", "FDC_App_Relationship_Details_values");
			
			String BankingservicesDeatils_values = com.getElementProperties("Fulldatacapturechecker","FDC_BankingservicesDeatils_values");
	//		wrap.switch_to_Iframe(driver,"PegaGadget2Ifr");
			wrap.switch_to_default_Content(driver);
			Thread.sleep(2000);
			wrap.switch_to_Iframe(driver,"PegaGadget2Ifr");
			wrap.click(driver,com.getElementProperties("Fulldatacapturechecker","FDCC_ProductDetails_Tab"));
			String productDetails = wrap.getElement(driver, ProductDetails).getText();

			logger.info(productDetails);
			System.out.println(productDetails);
			logger.info("###############################");
			System.out.println("###############################");
			try{
				wrap.click(driver, ProductDetails);
				wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, Product_tab_Product_header)));
				
				/******************Product Details Section******************/  
				if(wrap.validateFiledVisible1(driver,Product_tab_Product_header)){
					wrap.scroll_to(driver,Product_tab_Product_header);
					logger.info("Product Details");
					wrap.validateEditable(driver, ProductDetails_fields,ProductDetails_Values,"Product Details");
				}
				
				/******************Product Nominee Details Section******************/  
				if(wrap.validateFiledVisible1(driver,Product_tab_Nominee_header)){
					wrap.scroll_to(driver,Product_tab_Nominee_header);
				logger.info("Product Nominee Details");
				wrap.validateEditable(driver,NomineeKey_Information_fields,NomineeKey_Information_values,"Product Nominee Details");
				}
				else{
					logger.info("Product Nominee Details is not present");
				}
			
				/******************Product AC_setup Details Section******************/  
				if(wrap.validateFiledVisible1(driver,Product_tab_AC_setup_header)){
					wrap.scroll_to(driver,Product_tab_AC_setup_header);
					logger.info("Product AC_setup Details");
					wrap.validateEditable(driver,ACSetup_fields,ACSetup_values,"Product AC_setup Details");
				}
			
				/******************App_Relationship_Details******************/  
			
				if(wrap.validateFiledVisible1(driver,Product_tab_App_Relationship_header)){
					wrap.scroll_to(driver,Product_tab_App_Relationship_header);
					logger.info("App_Relationship_Details Details");
					wrap.validateEditable(driver,App_Relationship_Details_fields,App_Relationship_Details_values,"App_Relationship_Details Details");
				}
				/******************Product_Request******************/ 
				if(wrap.validateFiledVisible1(driver,Product_tab_Product_Request)){
					wrap.scroll_to(driver,Product_tab_Product_Request);
					logger.info("Product_Request Details");
					wrap.validateEditable(driver,Product_Request_fields ,Product_Request_values,"Product_Request Details");
				}
				/******************Repayment Details******************/ 
				if(wrap.validateFiledVisible1(driver,Product_tab_Repayment_header)){
					wrap.scroll_to(driver,Product_tab_Repayment_header);
					logger.info("Repayment Details");
					wrap.validateEditable(driver,RepaymentVal_fields,RepaymentVal_values,"Repayment Details");
				}
				/******************Disbursement Details******************/ 
				if(wrap.validateFiledVisible1(driver,Product_tab_Disbursement_header)){
					wrap.scroll_to(driver,Product_tab_Disbursement_header);
					logger.info("Disburesment Details");
					wrap.validateEditable(driver,DisbursementVal_fields,DisbursementVal_values,"Repayment Details");
				}
				
				/******************Bank Use Details******************/ 
				if(wrap.validateFiledVisible1(driver,Product_tab_BankUse)){
					wrap.scroll_to(driver,Product_tab_BankUse);
					logger.info("Bank Use Details");
					wrap.validateEditable(driver,BankingUse_fields,BankingUse_values,"Bank Use Details");
				}
				logger.info("Product Details are read and validated");
			}
			catch(Exception e){
				System.out.println("Section unavailable"+e);
			}
	}
		//############################Application #########################


		public static void fullDataCaptureCheckrApplicationdetails() throws IOException, InterruptedException{
			//String Action_Drodown = com.getElementProperties("Fulldatacapturechecker", "FDC_Action_Drodown");
		  //  String submit_FullChecker = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button");

			
				String Application_tab_Debit_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_Debit_header");
				String Product_tab_Banking_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_BankUse_header");
				String Application_tab_Internal_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_Internal_header");
				String Application_tab_AC_Setup_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_A/C_Setup_header");
				String Application_tab_App_details_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Application_tab_Application_Details");
				
				String ApplicationDetails = com.getElementProperties("Fulldatacapturechecker", "FDCC_ApplicationDetails_Tab");
				
				String DebitCard_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_DebitCard_Values");
				String DebitCard_Values = com.getElementProperties("Fulldatacapturechecker", "FDC_DebitCard_Values");
				String BankUse_fields= com.getElementProperties("Fulldatacapturechecker", "FDC_BankingUse_fields");
				String BankUse_Values = com.getElementProperties("Fulldatacapturechecker", "FDC_BankUse_Values");
				String Internal_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Internal_fields");
				String Internal_Values = com.getElementProperties("Fulldatacapturechecker", "FDC_Internal_Values");
				String ACSetup_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_A/C_Setup_fields");
				String ACSetup_Values = com.getElementProperties("Fulldatacapturechecker", "FDC_A/C_Setup_Values");
				String App_details_fields=com.getElementProperties("Fulldatacapturechecker", "FDC_Application_details_fields");
				String App_details_values=com.getElementProperties("Fulldatacapturechecker", "FDC_Application_details_values");
				
				String Remarks_textBox = com.getElementProperties("Fulldatacapturechecker", "FDC_Remarks_textBox ");
				String submit_button = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button  ");
				String cancel_button = com.getElementProperties("Fulldatacapturechecker", "FDC_cancel_button ");
				String save_button = com.getElementProperties("Fulldatacapturechecker", "FDC_save_button  ");
				String close_button = com.getElementProperties("Fulldatacapturechecker", "FDC_close_button ");
				String application_button = com.getElementProperties("Fulldatacapturechecker", "FDC_application_button  ");
				String release_button = com.getElementProperties("Fulldatacapturechecker", "FDC_release_button ");

				wrap.wait(2000);
				wrap.switch_to_default_Content(driver);
				wrap.wait(2000);
				wrap.switch_to_Iframe(driver, "PegaGadget2Ifr");
				wrap.wait(2000);
				String applicationDetails = wrap.getElement(driver, ApplicationDetails).getText();
				wrap.click(driver, ApplicationDetails);
			try {
				logger.info(applicationDetails);
				///Thread.sleep(2000);
				System.out.println(applicationDetails);
				logger.info("###############################");
				System.out.println("###############################");


	//                            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, Application_tab_Debit_header)));
	//                            com.validateFiledVisible(driver, Application_tab_Debit_header);
	//                            
	//                            com.readTableValues(driver, DebitCard_Values);
				
			   
				/******************Bank Use Details******************/ 
				if(wrap.validateFiledVisible1(driver,Product_tab_Banking_header)){
					wrap.scroll_to(driver,Product_tab_Banking_header);
					logger.info("Bank Use Details");
					wrap.validateEditable(driver,BankUse_fields,BankUse_Values,"Bank Use Details");
				}
				/*****************Internal section Details******************/ 
				if(wrap.validateFiledVisible1(driver,Application_tab_Internal_header)){
					wrap.scroll_to(driver,Application_tab_Internal_header);
					logger.info("Internal section Details");
					wrap.validateEditable(driver,Internal_fields,Internal_Values,"Internal section Details");
				}
				wrap.wait(1000);
				/*****************AC_Setup Details******************/ 
				if(wrap.validateFiledVisible1(driver,Application_tab_AC_Setup_header)){
					wrap.scroll_to(driver,Application_tab_AC_Setup_header);
					logger.info("AC_Setup Details");
					wrap.validateEditable(driver,ACSetup_fields,ACSetup_Values,"AC_Setup Details");
				}
				/*****************Application Details******************/ 
				if(wrap.validateFiledVisible1(driver,Application_tab_App_details_header)){
					wrap.scroll_to(driver,Application_tab_App_details_header);
					logger.info("Application Details");
					wrap.validateEditable(driver,App_details_fields,App_details_values,"Application Details");
				}
				
				logger.info("Application Details read and validated successfully");
				
	//            com.validateFiledVisible(driver, Product_tab_Banking_header);
	//            wrap.scroll_to(driver, Product_tab_Banking_header);
	//            com.readTableValues(driver, BankUse_Values);
	//
	//            com.validateFiledVisible(driver, Application_tab_Internal_header);
	//            wrap.scroll_to(driver, Application_tab_Internal_header);
	//
	//            com.readTableValues(driver, Internal_Values);
	//
	//            com.validateFiledVisible(driver, Application_tab_AC_Setup_header);
	//            //wrap.scroll_to(driver, Application_tab_AC_Setup_header);
	//            com.readTableValues(driver, ACSetupValues);

	//            com.validateFiledVisible(driver, Remarks_textBox);
	//            com.validateFiledVisible(driver, submit_button);
	//            com.validateFiledVisible(driver, cancel_button);
	//            com.validateFiledVisible(driver, save_button);
	//            com.validateFiledVisible(driver, close_button);
	//            com.validateFiledVisible(driver, application_button);
	//            com.validateFiledVisible(driver, release_button);
	//            //com.readTableValues(driver, FDC_Action_Drodown);
	//            utils.convertExcelToMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	//            //wrap.convertExcelToMap("FullDataCapture");
	//            String action_dropDown = utils.readColumn("Action Drop down", 0);
	//            logger.info(action_dropDown);
	//            System.out.println(action_dropDown);
	//            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, Action_Drodown)));
	//            wrap.selectFromDropDown(driver, Action_Drodown, action_dropDown, "BYVISIBLETEXT");
	//            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, submit_FullChecker)));
	//            Thread.sleep(2000);
	//            wrap.click(driver, submit_FullChecker);
	//            //Thread.sleep(5000);
			}
			catch (Exception e){
	//            utils.convertExcelToMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	//            //wrap.convertExcelToMap("FullDataCapture");
	//            String action_dropDown = utils.readColumn("Action Drop down", 0);
	//            logger.info(action_dropDown);
	//            System.out.println(action_dropDown);
	//            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, Action_Drodown)));
	//            wrap.selectFromDropDown(driver, Action_Drodown, action_dropDown, "BYVISIBLETEXT");
	//            wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, submit_FullChecker)));
	//            Thread.sleep(2000);
	//            wrap.click(driver, submit_FullChecker);
				System.out.println("Section unavailable"+e);

			}
		}

		
		//#####################Document###############################
		public void fullDataCaptureCheckerDocumnetdetails() throws IOException, InterruptedException{
			
		
			String Document_Tab=com.getElementProperties("Fulldatacapturechecker", "FDCC_Documents_Tab");
			
			String IDDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_tab_IDDocument_header");
			String AddressDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_tab_AddressDocument_header");
			String IncomeDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_IncomeDocument_header");
			String OtherDocument_headers = com.getElementProperties("Fulldatacapturechecker", "FDC_OtherDocument_header");
			
			String IDDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IDDocuments_fields");
			String IDDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IDDocuments_values");
			String AddressDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_AddressDocuments_fields");
			String AddressDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_AddressDocuments_values");
			String IncomeDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_fields");
			String IncomeDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_values");
			String OtherDocument_fields= com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_OtherDocuments_fields");
			String OtherDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_OtherDocuments_values");
			
			String Action_Drodown = com.getElementProperties("Fulldatacapturechecker", "FDC_Action_Drodown");
			String submit_FullChecker = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button");
			String Remarks_textBox = com.getElementProperties("Fulldatacapturechecker", "FDC_Remarks_textBox ");
			String submit_button = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button  ");
			String cancel_button = com.getElementProperties("Fulldatacapturechecker", "FDC_cancel_button ");
			String save_button = com.getElementProperties("Fulldatacapturechecker", "FDC_save_button  ");
			String close_button = com.getElementProperties("Fulldatacapturechecker", "FDC_close_button ");
			String application_button = com.getElementProperties("Fulldatacapturechecker", "FDC_application_button  ");
			String release_button = com.getElementProperties("Fulldatacapturechecker", "FDC_release_button ");
			
			 try {
				 
				 wrap.wait(2000);
				 wrap.switch_to_default_Content(driver);
				 wrap.wait(2000);
				 wrap.switch_to_Iframe(driver, "PegaGadget2Ifr");
				 wrap.wait(2000);
				 String Documents = wrap.getElement(driver, Document_Tab).getText();
				 wrap.click(driver, Document_Tab);
				 logger.info(Documents);
				 ///Thread.sleep(2000);
				 System.out.println(Documents);
				 logger.info("###############################");
				 System.out.println("###############################");
				 
				 
				 
				 
				 /******************IDDocument Details******************/ 
				 if(wrap.validateFiledVisible1(driver,IDDocument_header)){
					wrap.scroll_to(driver,IDDocument_header);
					logger.info("Bank Use Details");
					wrap.validateEditable(driver,IDDocument_fields,IDDocument_values,"Bank Use Details");
				}
				 /*****************AddressDocument section Details******************/ 
				 if(wrap.validateFiledVisible1(driver,AddressDocument_header)){
					wrap.scroll_to(driver,AddressDocument_header);
					logger.info("AddressDocument Details");
					wrap.validateEditable(driver,AddressDocument_fields,AddressDocument_values,"AddressDocument Details");
				}
				 wrap.wait(1000);
				 /*****************OtherDocument Details******************/ 
				 if(wrap.validateFiledVisible1(driver,OtherDocument_headers)){
					wrap.scroll_to(driver,OtherDocument_headers);
					logger.info("OtherDocument Details");
					wrap.validateEditable(driver,OtherDocument_fields,OtherDocument_values,"OtherDocument Details");
				}
				 
	//             com.validateFiledVisible(driver, Remarks_textBox);
	//             com.validateFiledVisible(driver, submit_button);
	//             com.validateFiledVisible(driver, cancel_button);
	//             com.validateFiledVisible(driver, save_button);
	//             com.validateFiledVisible(driver, close_button);
	//             com.validateFiledVisible(driver, application_button);
	//             com.validateFiledVisible(driver, release_button);
	//             //com.readTableValues(driver, FDC_Action_Drodown);
	//             utils.convertExcelToMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	//             //wrap.convertExcelToMap("FullDataCapture");
	//             String action_dropDown = utils.readColumn("Action Drop down", 0);
	//             logger.info(action_dropDown);
	//             System.out.println(action_dropDown);
	//             wrap.selectFromDropDown(driver, Action_Drodown, action_dropDown, "BYVISIBLETEXT");
	//             wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, submit_FullChecker)));
	//             Thread.sleep(2000);
	//             wrap.click(driver, submit_FullChecker);
	//             //Thread.sleep(5000);
			 }
			 catch(Exception e){
				 
				 System.out.println("SEction Unavaible"+e);
	//        	 utils.convertExcelToMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	//             //wrap.convertExcelToMap("FullDataCapture");
	//             String action_dropDown = utils.readColumn("Action Drop down", 0);
	//             logger.info(action_dropDown);
	//             System.out.println(action_dropDown);
	//             wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, Action_Drodown)));
	//             wrap.selectFromDropDown(driver, Action_Drodown, action_dropDown, "BYVISIBLETEXT");
	//             wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, submit_FullChecker)));
	//             Thread.sleep(2000);
	//             wrap.click(driver, submit_FullChecker);
			 }

		}
			
			
		//#####################Document###############################
		
		
		
		public void fullDataCaptureCheckerMultipleIncomeDocuments() throws IOException, InterruptedException{
			
		
			String Document_Tab=com.getElementProperties("Fulldatacapturechecker", "FDCC_Documents_Tab");
			
			String IDDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_tab_IDDocument_header");
			String AddressDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_tab_AddressDocument_header");
			String IncomeDocument_header = com.getElementProperties("Fulldatacapturechecker", "FDC_Doument_IncomeDocument_header");
			String OtherDocument_headers = com.getElementProperties("Fulldatacapturechecker", "FDC_OtherDocument_header");
			
			String IDDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IDDocuments_fields");
			String IDDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IDDocuments_values");
			String AddressDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_AddressDocuments_fields");
			String AddressDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_AddressDocuments_values");
			String IncomeDocument_fields = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_fields");
			String IncomeDocument_values = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_values");
			
			
			String IncomeDocument_fields2 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_fields2");
			String IncomeDocument_values2 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_values2");
			
			
			String IncomeDocument_fields3 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_fields3");
			String IncomeDocument_values3 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_values3");
			
			
			String IncomeDocument_fields4 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_fields4");
			String IncomeDocument_values4 = com.getElementProperties("Fulldatacapturechecker", "FDC_Document_tab_IncomeDocuments_values4");
			
			
			String IncomeDoc_Tab2 = com.getElementProperties("Fulldatacapturechecker", "IncomeDoc_Tab2");
			String IncomeDoc_Tab3 = com.getElementProperties("Fulldatacapturechecker", "IncomeDoc_Tab3");
			String IncomeDoc_Tab4 = com.getElementProperties("Fulldatacapturechecker", "IncomeDoc_Tab4");
		
		 wrap.wait(2000);
		 wrap.switch_to_default_Content(driver);
		 wrap.wait(2000);
		 wrap.switch_to_Iframe(driver, "PegaGadget2Ifr");
		 wrap.wait(2000);
		 String Documents = wrap.getElement(driver, Document_Tab).getText();
		 wrap.click(driver, Document_Tab);
		 logger.info(Documents);
		 ///Thread.sleep(2000);
		 System.out.println(Documents);
		 logger.info("###############################");
		 System.out.println("###############################");

			
			try {
				 
				/*****************IncomeDocument Details1******************/
				 if(wrap.validateFiledVisible1(driver,IncomeDocument_header)){
					wrap.scroll_to(driver,IncomeDocument_header);
					logger.info("IncomeDocument Details1");
					
					
					wrap.validateEditable(driver,IncomeDocument_fields,IncomeDocument_values,"IncomeDocument Details");
				 }             
			
			 
				/*****************IncomeDocument Details2******************/ 
				 if(wrap.validateFiledVisible1(driver,IncomeDocument_header)){
					wrap.scroll_to(driver,IncomeDocument_header);
					logger.info("IncomeDocument Details2");
				
					wrap.click(BaseProject.driver, IncomeDoc_Tab2);
					wrap.wait(2000);
					wrap.validateEditable(driver,IncomeDocument_fields2,IncomeDocument_values2,"IncomeDocument Details");
				 }             
			
				 /*****************IncomeDocument Details3******************/ 
				 if(wrap.validateFiledVisible1(driver,IncomeDocument_header)){
					wrap.scroll_to(driver,IncomeDocument_header);
					logger.info("IncomeDocument Details3");
					
					wrap.click(BaseProject.driver, IncomeDoc_Tab3);
					wrap.wait(2000);
					wrap.validateEditable(driver,IncomeDocument_fields3,IncomeDocument_values3,"IncomeDocument Details");
				 }             
			
				 /*****************IncomeDocument Details4******************/ 
				 if(wrap.validateFiledVisible1(driver,IncomeDocument_header)){
					wrap.scroll_to(driver,IncomeDocument_header);
					logger.info("IncomeDocument Details4");
					wrap.click(BaseProject.driver, IncomeDoc_Tab4);
					wrap.wait(2000);
					wrap.validateEditable(driver,IncomeDocument_fields4,IncomeDocument_values4,"IncomeDocument Details");
				 }             
			
			 
			 
			 
			 }
			 catch(Exception e){
				 
				 System.out.println("Income Doc Section Unavailable"+e);
			 }

		}
			
			
		
		
		@When("^Release Worklist$")
		public void release_work_list() throws IOException, InterruptedException{
			String workList = com.getElementProperties("Fulldatacapturechecker", "myWorklist");
			wrap.switch_to_default_Content(driver);
			wrap.click(driver, workList);

		}

		@Then("^select an application number$")
		public static void select_an_application_number()
				throws IOException, InterruptedException {

			System.out.println("The Value going to select or Filter is ["+BaseProject.appId+"]");
			wrap.switch_to_Iframe(driver, "PegaGadget0Ifr");



			String filter = com.getElementProperties("Fulldatacapturemaker",
					"filter_link");
			String search = com.getElementProperties("Fulldatacapturemaker",
					"search_text");
			String apply_button = com.getElementProperties("Fulldatacapturemaker",
					"apply_button");
			try {

				driver.findElement(By.xpath("//span[text()='" +"IN20170505000153" + "']"))
						.click();

				/*	driver.findElement(By.xpath("//span[text()='" + BaseProject.appId + "']"))
					.click();*/
			} catch (org.openqa.selenium.NoSuchElementException e) {
				wrap.click(driver, filter);
				Thread.sleep(1000);
				wrap.typeToTextBox(driver, "IN20170505000153", search);
				//wrap.typeToTextBox(driver, appNumber, search);
				//wrap.typeToTextBox(driver, BaseProject.appId, search);
				Thread.sleep(1000);
				wrap.click(driver, apply_button);

				Thread.sleep(500);

				driver.findElement(By.xpath("//span[text()='" +"IN20170505000153" + "']"))
						.click();
				/*driver.findElement(By.xpath("//span[text()='" + BaseProject.appId + "']"))
					.click();*/

			}

			//Thread.sleep(1000);
			wrap.switch_to_default_Content(driver);

		}



		@When("^Check cleared and Submit the application$")
		public void check_cleared_and_Submit_the_application() throws IOException, InterruptedException{
			String Cheque_status_dropdown = com.getElementProperties("chequebook", "cheque_status_Dropdown");
			String submit = com.getElementProperties("chequebook", "submit");
			Thread.sleep(2000);
			wrap.switch_to_Iframe(driver, "PegaGadget1Ifr");
			wrap.selectFromDropDown(driver, Cheque_status_dropdown, "Cheque Cleared", "byvisibleText");
			Thread.sleep(2000);
			wrap.click(driver, submit);
			Thread.sleep(5000);
		}

		
		@Then("^Submit the application$")
		public void sumbit_application() throws IOException, InterruptedException{

			String Action_Header=com.getElementProperties("Fulldatacapturechecker", "FDC_Action_Header");
//			String Action_Drodown = com.getElementProperties("Fulldatacapturechecker", "FDC_Action_Drodown");
			String submit_FullChecker = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button");
//			String Remarks_textBox = com.getElementProperties("Fulldatacapturechecker", "FDC_Remarks_textBox");
//			String submit_button = com.getElementProperties("Fulldatacapturechecker", "FDC_submit_button  ");
//			String cancel_button = com.getElementProperties("Fulldatacapturechecker", "FDC_cancel_button ");
//			String save_button = com.getElementProperties("Fulldatacapturechecker", "FDC_save_button  ");
//			String close_button = com.getElementProperties("Fulldatacapturechecker", "FDC_close_button ");
//			String application_button = com.getElementProperties("Fulldatacapturechecker", "FDC_application_button  ");
//			String release_button = com.getElementProperties("Fulldatacapturechecker", "FDC_release_button ");
		
			try{
				
				switchFrame();
//				wrap.scroll_to(driver,Action_Header);
//			   utils.convertExcelToMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
//			   //wrap.convertExcelToMap("FullDataCapture");
//			   //String action_dropDown = utils.readColumn("Action Drop down", 0);
//			   String action_dropDown = utils.readColumnWithRowID("Action_dropdown", BaseProject.scenarioID);
//			   logger.info(action_dropDown);
//			   System.out.println(action_dropDown);
//			   wrap.click(driver, Action_Drodown);
//			   wrap.selectFromDropDown(driver, Action_Drodown, action_dropDown, "BYVISIBLETEXT");
//			   wrap.screenShot(BaseProject.driver, screenShotPath, "Action");
//
//			   String Remarks=utils.readColumnWithRowID("Remarks", BaseProject.scenarioID);
//			   wrap.click(driver, Remarks_textBox);
//			   wrap.typeToTextBox(driver, Remarks, Remarks_textBox);
//			   wrap.screenShot(BaseProject.driver, screenShotPath, "Remarks");
//
//
//			   wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, submit_FullChecker)));
//			   Thread.sleep(2000);
//			   wrap.click(driver, submit_FullChecker);

				//Written by DX
				String actionDropDown = com.getElementProperties("FullDataCaptureChecker", "FDC_Action_Drodown");
				wrap.scroll_to(driver,Action_Header);
				wrap.selectFromDropDown(BaseProject.driver,actionDropDown,"Approve","BYVISIBLETEXT");
				wrap.click(BaseProject.driver,submit_FullChecker);
				wrap.wait(5000);


			 }
			catch(Exception e){
				System.out.println("Application is not sumbitted");
				e.printStackTrace();
			}
		}
		
		@When("^FDC Checker: Release$")
		public void releaseFromChecker() throws InterruptedException{
			
			
			switchFrame();
			wrap.click(driver,"//button[@accesskey='R']");
			wrap.wait(2000);	
	}
		
		@Given("^Go to Full data Capture Checker home page$")
        public void go_to_Full_data_Capture_Checker_home_page() throws Throwable {

            wrap.switch_to_default_Content(BaseProject.driver);

            try {
                 wrap.waitForElementVisibility(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"), 4000);
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
                
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));
                wrap.wait(2000);
                wrap.getWorkbasketoption(BaseProject.driver, "Full Data Capture Checker");
                wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

		@Then("^FDM : Switch to CoApplicant1 tab$")
	    public static void switchToCoApplicants1Tab() throws InterruptedException, IOException {

	        wrap.switch_to_default_Content(BaseProject.driver);
	       
	        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
	        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
	        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails")));
	        
	        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails"));
	        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants1_tab"));

	    }


	@Then("^FDM : Switch to CoApplicant2 tab$")
	    public static void switchToCoApplicants2Tab() throws InterruptedException, IOException {

	        wrap.switch_to_default_Content(BaseProject.driver);
	       
	        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
	        JavascriptExecutor jse = (JavascriptExecutor)BaseProject.driver;
	        jse.executeScript("arguments[0].scrollIntoView(true);", wrap.getElement(BaseProject.driver,com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails")));
	        
	        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails"));
	        wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CoApplicants2_tab"));

	    }

	

	 public static void addresssection() throws InterruptedException, IOException
	 {
		  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCCheckerAddressType"), DBUtils.readColumnWithRowID("Address Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerAddressLine1"), DBUtils.readColumnWithRowID("Address Line 1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerAddressLine2"), DBUtils.readColumnWithRowID("Address Line 2", BaseProject.scenarioID));
	   //    wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerAddressLine3"), DBUtils.readColumnWithRowID("Address Line 3", BaseProject.scenarioID));
	       
	    //   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerState"), DBUtils.readColumnWithRowID("State", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerCity"), DBUtils.readColumnWithRowID("Area", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerCountry"), DBUtils.readColumnWithRowID("Country", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDcheckerZipCode"), DBUtils.readColumnWithRowID("Zip Code", BaseProject.scenarioID));
	       
	       
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Communication"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	       
	       
	       logger.info("Valdiation FD  Maker Fields");
	     
	 }
	 
	 
	 @When("^FullDataChecker: validate prefilled values Customer Section")
	    public void prefillvaluevalidate()
	            throws Throwable {
	       
	      switchFrame();
	       DBUtils.convertDBtoMap("bdquery");	
	       System.out.println(DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID));
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Client_Type"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
	       try {
			wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_First_name"), DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_MiddleName"), DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_LastName"), DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	       
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Full_name"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_DOB"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_COB"), DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Res_Country"), DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Nationality"), DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID));
	       
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerContactDetails"), DBUtils.readColumnWithRowID("Conatct Details", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerISDCode"), DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID));
	       
	       //Address Section
	       
	       DBUtils.convertDBtoMap("fdquery");
	       
	       addresssection();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerGender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMaritalStatus"), DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "Country"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerEduQualifications"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	       
	       //communication Section
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_PreferredLanguage_txt"), DBUtils.readColumnWithRowID("Preferred  Language", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"), DBUtils.readColumnWithRowID("Advice Detail Address Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_communicationSection_MarkettingPreference"), DBUtils.readColumnWithRowID("Marketing Preferences", BaseProject.scenarioID));
	       
	       
	       
	       //Employement Section
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_Occupation"), DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_ISIC"), DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), DBUtils.readColumnWithRowID("Work type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_DomicileCountryCode"), DBUtils.readColumnWithRowID("Domicile_Country1", BaseProject.scenarioID));
	       
	       
	       
	       //FATCA Section
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"), DBUtils.readColumnWithRowID("FATCA - Is Customer a US Resident?", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No"), DBUtils.readColumnWithRowID("Is_the_customer_a_US_citizen1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No"), DBUtils.readColumnWithRowID("FATCA - Is Customer a Green card holder?", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	       
	       //Internal 
	       
	    //   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "MIS code"), DBUtils.readColumnWithRowID("MIS CODE", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDcheckercdd_Source"), DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));
	       //wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDcheckercdd_type"), DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));
	       
	       //FamilyDetails
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMaidenFN"),  DBUtils.readColumnWithRowID("MaidenFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherPrefix"),  DBUtils.readColumnWithRowID("FatherPrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherFN"),  DBUtils.readColumnWithRowID("FatherFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherMN"),  DBUtils.readColumnWithRowID("FatherMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherLN"),  DBUtils.readColumnWithRowID("FatherLastName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherPrefix"),  DBUtils.readColumnWithRowID("MotherPrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherFN"),  DBUtils.readColumnWithRowID("MotherFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherMN"),  DBUtils.readColumnWithRowID("MotherMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherLN"),  DBUtils.readColumnWithRowID("MotherLastName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpousePrefix"),  DBUtils.readColumnWithRowID("SpousePrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseFN"),  DBUtils.readColumnWithRowID("SpouseFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseMN"),  DBUtils.readColumnWithRowID("SpouseMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseLN"),  DBUtils.readColumnWithRowID("SpouseLastName", BaseProject.scenarioID));
	       
	       //Banking Service
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerOnlineBanking"),  DBUtils.readColumnWithRowID("Online Banking", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerOnlineBanking"),  DBUtils.readColumnWithRowID("Mobile Banking", BaseProject.scenarioID));
	       
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerEduQualifications"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	   //    wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerEduQualifications"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	   //    wrap.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_First_name"));
	      /* FullDataMakerUtils.switchToProductDetailsTab();
	       
	    //   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Camapigncode"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
	       
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ProductCategory"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	   //    wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Deposittype"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Producttype"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ACqusition"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Term"), DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Tenuretype"), DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Depositamnt"), DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ValueDate"), DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Rollover"), DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_interestfreq"), DBUtils.readColumnWithRowID("TD_Interest_Frequency", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_2in1"), DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_BaseRate"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_MArginal"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_MAturityDate"), DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Lien"), DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_nodeposit"), DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID));
	       */
	}
	 
	 
	 
	 @When("^FullDataChecker: validate prefilled values Application Section")
	    public void prefillvaluevalidate_Application()
	            throws Throwable {
		 
DBUtils.convertDBtoMap("bdquery");	
		 
		 //Bank Use
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_SourcingID"), DBUtils.readColumnWithRowID("Sorucing ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ReferralID"), DBUtils.readColumnWithRowID("Referral ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_AcquisitionChannel_DropDown"), DBUtils.readColumnWithRowID("Acquisition Channel",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_FasttrackFlag"), DBUtils.readColumnWithRowID("Fast track Flag",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ApplicationBranch"), DBUtils.readColumnWithRowID("Application Branch",  BaseProject.scenarioID));
		 
		 DBUtils.convertDBtoMap("fdquery");
		 
		//Bank Use
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"), DBUtils.readColumnWithRowID("Home Branch",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ClosingID"), DBUtils.readColumnWithRowID("Closing ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_no"), DBUtils.readColumnWithRowID("Investment Account Request",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"), DBUtils.readColumnWithRowID("HR Date",  BaseProject.scenarioID));
		 
		 //A/C SETUP in applications tab
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ShortName"), DBUtils.readColumnWithRowID("Account Short Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"), DBUtils.readColumnWithRowID("Service Indicator Code",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), DBUtils.readColumnWithRowID("Institution Classification Code",  BaseProject.scenarioID));
		 
		 //debit card applications tab
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_DebitCardRequired_yes"), DBUtils.readColumnWithRowID("Debit Card Required",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_Customer"), DBUtils.readColumnWithRowID("Customer",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_PrimaryProduct_DropDown"), DBUtils.readColumnWithRowID("Primary Product",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_CardType_DropDown"), DBUtils.readColumnWithRowID("Card Type",  BaseProject.scenarioID));
		 
		 
		 //CKYC
		 
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Date_of_Declation"), DBUtils.readColumnWithRowID("KYC Date Of Declaration",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_place_of_Declation"), DBUtils.readColumnWithRowID("KYC Place Of Declaration",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Verification_Date"), DBUtils.readColumnWithRowID("KYC Verification Date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employer_name"), DBUtils.readColumnWithRowID("KYC Employee Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employer_Designation"), DBUtils.readColumnWithRowID("KYC Employee Designation",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Verification_Branch"), DBUtils.readColumnWithRowID("KYC Verification Branch",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employee_Code"), DBUtils.readColumnWithRowID("KYC Employee Code",  BaseProject.scenarioID));

	 
		 
	 }
	 
	 
	 
	 @When("^FullDatachecker: Validate prefilled values customer details co applicant$")
	 public void fulldatachecker_Validate_prefilled_values_customer_details_co_applicant() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 
		 FullDataMakerUtils.switchToNextCoapplicant();
	     
		 prefillvaluevalidate();
		 
	 }
	 
	 @Given("^FullDataChecker: validate prefilled values CC Customer$")
	 public void fulldatachecker_validate_prefilled_values_CC_Customer() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     //CC
		
		 DBUtils.convertDBtoMap("fdquery");
		 //FullDataMaker.scroll_to(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Describe_applicant"));

		 
		 
		 switchFrame();
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        WebElement ele = driver.findElement(By.xpath("//span[text()='Describe Applicant / Ownership Type']//following::span"));
	        js.executeScript("arguments[0].scrollIntoView();", ele);
	        
	        
	        
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Describe_applicant"), DBUtils.readColumnWithRowID("Describe Applicant/Ownership Type",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Company_Type"), DBUtils.readColumnWithRowID("Company Type",  BaseProject.scenarioID));
		 //wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Share_holding"), DBUtils.readColumnWithRowID("% of Share holding",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_Company_Name"), DBUtils.readColumnWithRowID("Company Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCchecker_Incorporation_Date"), DBUtils.readColumnWithRowID("Incorporation Date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCchecker_Incorporation_Country"), DBUtils.readColumnWithRowID("Incorporation Date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_No_of_Months_Current_YY"), DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_No_of_Months_Current_MM"), DBUtils.readColumnWithRowID("No of Months in Current business/Organization",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_No_of_Months_Previous_YY"), DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_No_of_Months_Previous_MM"), DBUtils.readColumnWithRowID("No of Months in Previous business/Organizatio",  BaseProject.scenarioID));
		 
		 
	 }
	 
	 
	 @When("^FullDataChecker: validate prefilled values in Products tab for CC product")
	    public void prefillvaluevalidateCCProduct()
	            throws Throwable {
		 FullDataMakerUtils.switchToProductDetailsTab();
		 
		 DBUtils.convertDBtoMap("fdquery");
		 //product details
		 try {
			wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerAssessmentType"), DBUtils.readColumnWithRowID("Assessment Type",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerPreferredLimit"), DBUtils.readColumnWithRowID("Preferred Limit",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerTermDepositOnSecuredCCValue"), DBUtils.readColumnWithRowID("Term deposit on secured CC value",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerProductAddressType"), DBUtils.readColumnWithRowID("Product address type",  BaseProject.scenarioID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Failed To validate Product details");
		}
		

	 
		 //Repayment details
		 try {
			wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerRepaymentMode"), DBUtils.readColumnWithRowID("Repayment mode",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerRepaymentAccType"), DBUtils.readColumnWithRowID("Repayment Account Type",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerAutoDebitAmount"), DBUtils.readColumnWithRowID("Auto Debit Amount",  BaseProject.scenarioID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Failed To validate Repayment details");
		}
		 
		 
		 //Bank use
		 try {
			wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerBillingCycle"), DBUtils.readColumnWithRowID("Billing_Cycle",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerCCEmbossName"), DBUtils.readColumnWithRowID("Embossed debit card name",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerUserCode2"), DBUtils.readColumnWithRowID("User_Code2",  BaseProject.scenarioID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Failed To validate Bank details");
		}
		 
		 
	  
	 } 


	 
	 
	 
	 
	 
	 
	 @Given("^FullDataChecker: Validate Prefilled values in product tab for PL product$")
	
public void fulldatachecker_Validate_Prefilled_values_in_product_tab_for_PL_product() throws Throwable {
	
		 FullDataMakerUtils.switchToProductDetailsTab();
		 
		 String RepaymentSection = null;
		 String DisbursementSection = null;
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Amount_Currency"), DBUtils.readColumnWithRowID("Requested Amount (with Currency)",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Requested_Tenure"), DBUtils.readColumnWithRowID("Requested Tenure",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Purpose_of_Loan"), DBUtils.readColumnWithRowID("Purpose of Loan",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Effective_Rate_"), DBUtils.readColumnWithRowID("Effective Rate %",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Customer_Req_Rate"), DBUtils.readColumnWithRowID("Customer_Requested_Rate",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Price_Esc_Rate"), DBUtils.readColumnWithRowID("Price_Escalation_Approved_Rate",  BaseProject.scenarioID));
		 
		 //Repaymentdetails
		 
		 RepaymentSection= wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Mode"));
		 
		
		
		 
		 
		 if (RepaymentSection.equalsIgnoreCase("PDC-Post Dated Cheque"))
				 {
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Mode"), DBUtils.readColumnWithRowID("Repayment mode",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_type"), DBUtils.readColumnWithRowID("Repayment Account Type",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Total_Cheque_No"), DBUtils.readColumnWithRowID("PDC-Total cheque No ",  BaseProject.scenarioID));
		 
		 
		 //PDCDetails
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Cheque_No"), DBUtils.readColumnWithRowID("PDC-Cheque No ",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Cheque_Value"), DBUtils.readColumnWithRowID("PDC-Cheque Value",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC_Cheque_Value_Currency"), DBUtils.readColumnWithRowID("PDC-Cheque Value Currency",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Expiry_Date"), DBUtils.readColumnWithRowID("PDC-Expiry Date ",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Effective_Date"), DBUtils.readColumnWithRowID("PDC-Effective Date ",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Total_Cheque_Value"), DBUtils.readColumnWithRowID("PDC-Total Cheque Value",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Total_Cheque_Value_Currency"), DBUtils.readColumnWithRowID("PDC-Total Cheque Value Currency",  BaseProject.scenarioID));
		 
				 }
		 
		 
		 
		 else if (RepaymentSection.equalsIgnoreCase("SI On SCB"))
			 
		 {
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Mode"), DBUtils.readColumnWithRowID("Repayment Mode",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_type"), DBUtils.readColumnWithRowID("Account Type",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_Number"), DBUtils.readColumnWithRowID("Account Number",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Frequency"), DBUtils.readColumnWithRowID("Frequency",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Effective_Date"), DBUtils.readColumnWithRowID("Effective Date",  BaseProject.scenarioID));
			 
			 
			 
		 }
		 
		 else if (RepaymentSection.equalsIgnoreCase("EDA On Other bank A/C"))
		 {
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Mode"), DBUtils.readColumnWithRowID("Repayment Mode",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_type"), DBUtils.readColumnWithRowID("Account Type",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_Number"), DBUtils.readColumnWithRowID("Account Number",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_EDA_Account"), DBUtils.readColumnWithRowID("EDA Account holder Name",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_IFSC_Code"), DBUtils.readColumnWithRowID("IFSC Code",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Bank/Utility"), DBUtils.readColumnWithRowID("Bank/Utility Name",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Bank_Sort"), DBUtils.readColumnWithRowID("Bank Sort Code",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Repayment_Branch_Code"), DBUtils.readColumnWithRowID("Repayment branch code",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Account_Number"), DBUtils.readColumnWithRowID("Account Number",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Monthly_Repayment_due"), DBUtils.readColumnWithRowID("Monthly Repayment Due Date",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Repayment_Frequency"), DBUtils.readColumnWithRowID("Frequency",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Effective_Date"), DBUtils.readColumnWithRowID("Effective Date ",  BaseProject.scenarioID));
			 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_PDC-Expiry_Date"), DBUtils.readColumnWithRowID("Expiry Date ",  BaseProject.scenarioID));
			 
		 }
		 
		 
		 else {
			 System.out.println("Cannot get text value of Repayment mmode");
		 }
		 
		 
		 DisbursementSection = wrap.getTextValue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Disbursement_Mode"));
		 
		 //Disbursement Details
		   if (DisbursementSection.equalsIgnoreCase("Pay Order"))
		   {
		 
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Disbursement_Mode"), DBUtils.readColumnWithRowID("Disbursement mode",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Name"), DBUtils.readColumnWithRowID("Beneficiary Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Bank"), DBUtils.readColumnWithRowID("Beneficiary's Bank",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiaryACNumber"), DBUtils.readColumnWithRowID("Beneficiary A/C Number",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Payorder"), DBUtils.readColumnWithRowID("Pay order date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Payorder_Handover"), DBUtils.readColumnWithRowID("Pay order hand over date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Payment_Ref"), DBUtils.readColumnWithRowID("Payment reference",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Pay_order_Amount"), DBUtils.readColumnWithRowID("Pay Order amount",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Debit_Account"), DBUtils.readColumnWithRowID("Debit Account",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Pick_Method"), DBUtils.readColumnWithRowID("Pick Up Method",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Pick_By"), DBUtils.readColumnWithRowID("Pick up by ",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Print_Loc"), DBUtils.readColumnWithRowID("Print Location ",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Clearing_Zone_Code"), DBUtils.readColumnWithRowID("Clearing Zone code",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Pincode"), DBUtils.readColumnWithRowID("Pincode",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_payable_loc_code"), DBUtils.readColumnWithRowID("Location Code",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Bank_Name"), DBUtils.readColumnWithRowID("Bank Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Advance_Emi"), DBUtils.readColumnWithRowID("Advance EMI",  BaseProject.scenarioID));
		 			 
		 
	 }
		   
		   else if (DisbursementSection.equalsIgnoreCase("Account Credit"))
		   {
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Disbursement_Mode"), DBUtils.readColumnWithRowID("Disbursement mode",  BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Name"), DBUtils.readColumnWithRowID("Beneficiary Name",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Bank"), DBUtils.readColumnWithRowID("Beneficiary's Bank",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiaryACNumber"), DBUtils.readColumnWithRowID("Beneficiary A/C Number",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiarybankMICRcode"), DBUtils.readColumnWithRowID("Beneficiary bank MICR code",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Advance_Emi"), DBUtils.readColumnWithRowID("Advance EMI",  BaseProject.scenarioID));
		   }
		   
		   else if(DisbursementSection.equalsIgnoreCase("RTGS")||DisbursementSection.equalsIgnoreCase("NEFT") )
		   {
			   
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Disbursement_Mode"), DBUtils.readColumnWithRowID("Disbursement mode",  BaseProject.scenarioID));
			   
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_IFSCCode-Disbursement"), DBUtils.readColumnWithRowID("IFSC code - Disbursement",  BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Name"), DBUtils.readColumnWithRowID("Beneficiary Name",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Beneficiary_Bank"), DBUtils.readColumnWithRowID("Beneficiary's Bank",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiaryACNumber"), DBUtils.readColumnWithRowID("Beneficiary A/C Number",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_BeneficiarybankMICRcode"), DBUtils.readColumnWithRowID("Beneficiary bank MICR code",  BaseProject.scenarioID));
				 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCChecker_PL_Product_Advance_Emi"), DBUtils.readColumnWithRowID("Advance EMI",  BaseProject.scenarioID));
			   
		   }
	 
	 
	 
	 
	 
	 
	 }
	 
	 
	 
	 @Given("^FullDataChecker: PreFilled Valdiation Customer Tab$")
	 public void fulldatachecker_PreFilled_Valdiation_Customer_Tab() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	   
FullDataMakerUtils.switchToProductDetailsTab();
		 
		 String Prod = wrap.getTextValue(driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PromotionCampaignCode"));
		 
		 FullDataMakerUtils.switchToCustomerDetailsTab();
		 
		 
		 
		  switchFrame();
	       DBUtils.convertDBtoMap("bdquery");	
	       System.out.println(DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID));
	     //  wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Client_Type"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Title"), DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID));
	       try {
			wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_First_name"), DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_MiddleName"), DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID));
			   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_BasicInfo_LastName"), DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	       
	      // wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Full_name"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_DOB"), DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_COB"), DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Res_Country"), DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Customer_Nationality"), DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID));
	       
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerContactDetails"), DBUtils.readColumnWithRowID("Conatct Details", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerISDCode"), DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID));
	       
	       //Address Section
	       
	       DBUtils.convertDBtoMap("fdquery");
	       
	       addresssection();
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerGender"), DBUtils.readColumnWithRowID("Gender", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMaritalStatus"), DBUtils.readColumnWithRowID("Marital Status", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerEduQualifications"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	     
	       
	       //communication Section
	       
	       /*wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_PreferredLanguage_txt"), DBUtils.readColumnWithRowID("Preferred  Language", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_CommunicationSection_AdviceDetailAddressType_suggessionBox"), DBUtils.readColumnWithRowID("Advice Detail Address Type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FD_CD_communicationSection_MarkettingPreference"), DBUtils.readColumnWithRowID("Marketing Preferences", BaseProject.scenarioID));
	       
	       
	       
	       //Employement Section
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_Occupation"), DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture1_CustomerDetail_ISIC"), DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), DBUtils.readColumnWithRowID("Work type", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CustomerDetails_DomicileCountryCode"), DBUtils.readColumnWithRowID("Domicile_Country1", BaseProject.scenarioID));*/
	       if (Prod.equalsIgnoreCase("Credit Card"))
	       {
	       fulldatachecker_validate_prefilled_values_CC_Customer();
	       }
	       
	       //FATCA Section
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.Resident?No"), DBUtils.readColumnWithRowID("FATCA - Is Customer a US Resident?", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IstheCustomeraU.S.citizen?No"), DBUtils.readColumnWithRowID("Is_the_customer_a_US_citizen1", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CD_FatcaSection_IsCustomeraGreencardholder?No"), DBUtils.readColumnWithRowID("FATCA - Is Customer a Green card holder?", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_CPD_EmploymentType"), DBUtils.readColumnWithRowID("Educational Qualification", BaseProject.scenarioID));
	       
	       //Internal 
	       
	    //   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "MIS code"), DBUtils.readColumnWithRowID("MIS CODE", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDcheckercdd_Source"), DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));
	       //wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDcheckercdd_type"), DBUtils.readColumnWithRowID("Source(s) of Initial Funding", BaseProject.scenarioID));
	       
	       //FamilyDetails
	       
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMaidenFN"),  DBUtils.readColumnWithRowID("MaidenFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherPrefix"),  DBUtils.readColumnWithRowID("FatherPrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherFN"),  DBUtils.readColumnWithRowID("FatherFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherMN"),  DBUtils.readColumnWithRowID("FatherMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerFatherLN"),  DBUtils.readColumnWithRowID("FatherLastName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherPrefix"),  DBUtils.readColumnWithRowID("MotherPrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherFN"),  DBUtils.readColumnWithRowID("MotherFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherMN"),  DBUtils.readColumnWithRowID("MotherMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMotherLN"),  DBUtils.readColumnWithRowID("MotherLastName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpousePrefix"),  DBUtils.readColumnWithRowID("SpousePrefix", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseFN"),  DBUtils.readColumnWithRowID("SpouseFirstName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseMN"),  DBUtils.readColumnWithRowID("SpouseMiddleName", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerSpouseLN"),  DBUtils.readColumnWithRowID("SpouseLastName", BaseProject.scenarioID));
	       
	       //Banking Service
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerOnlineBanking"),  DBUtils.readColumnWithRowID("Online Banking", BaseProject.scenarioID));
	       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerOnlineBanking"),  DBUtils.readColumnWithRowID("Mobile Banking", BaseProject.scenarioID));
	       
	     
	      
		 
	       
	       
		 
	 }
	 
	 
	 @Given("^FullDataChecker: Prefilled Validation ProductTab$")
	 public void fulldatachecker_Prefilled_Validation_ProductTab() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 FullDataMakerUtils.switchToProductDetailsTab();
		 
		 String Prod = wrap.getTextValue(driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_PromotionCampaignCode"));
		       
		       if (Prod.equalsIgnoreCase("PERSONAL LOAN"))
		       {
		    	   fulldatachecker_Validate_Prefilled_values_in_product_tab_for_PL_product();
		       }
		       
		       else if (Prod.equalsIgnoreCase("CREDIT CARD"))
		       {
		    	   prefillvaluevalidateCCProduct();
		       }
		       
		       else if (Prod.equalsIgnoreCase("Term Deposit"))
		       {
		    	   wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Term"), DBUtils.readColumnWithRowID("TD_Term", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Tenuretype"), DBUtils.readColumnWithRowID("TD_Tenure", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Depositamnt"), DBUtils.readColumnWithRowID("TD_Deposit_Amount", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ValueDate"), DBUtils.readColumnWithRowID("TD_Value_Date", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Rollover"), DBUtils.readColumnWithRowID("RollOverChoice", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_interestfreq"), DBUtils.readColumnWithRowID("TD_Interest_Frequency", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_2in1"), DBUtils.readColumnWithRowID("TD_TwoInOne", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_SpecialRate"), DBUtils.readColumnWithRowID("ProfileType", BaseProject.scenarioID));
			      wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_MAturityDate"), DBUtils.readColumnWithRowID("TD_Maturity_Date", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Lien"), DBUtils.readColumnWithRowID("Lien", BaseProject.scenarioID));
			       wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_nodeposit"), DBUtils.readColumnWithRowID("No_of_Deposit", BaseProject.scenarioID));
		       }
		       
		       
		       else 
		       {
		    	   DBUtils.convertDBtoMap("bdquery");		 
					 
					 //Product details
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_Camapigncode"), DBUtils.readColumnWithRowID("Campaigncode", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_Product_ProductCategory"), DBUtils.readColumnWithRowID("CampaigncodeDescription", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerProductCode"), DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID));
					 //wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerBundleIndicator"), DBUtils.readColumnWithRowID("ProductCode", BaseProject.scenarioID));		 
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Acquisition__txt"), DBUtils.readColumnWithRowID("AcquisitionUsage", BaseProject.scenarioID));
					 
					 //A/C setup
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_Purposeofaccountopening_txt"), DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_AccountRequestType_txt"), DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_AccountCurrency_txt"), DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID));
					 
					 DBUtils.convertDBtoMap("fdquery");
					 
					 //A/C setup
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerOperatingInstruction"), DBUtils.readColumnWithRowID("Operating Instruction", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_AccountShortName_txt "), DBUtils.readColumnWithRowID("Account Short Name", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_ProductDetailsSec_Charges"), DBUtils.readColumnWithRowID("Charges", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMISCode"), DBUtils.readColumnWithRowID("MIS Code (Prd)", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerMISValue"), DBUtils.readColumnWithRowID("MIS Value (Prd)", BaseProject.scenarioID));
					 //Fund account choice 
					 
					 //Nominee information
					 wrap.validatevalue(BaseProject.driver , com.getElementProperties("Fulldatacapturemaker", "FDCheckerNominationFacility"), DBUtils.readColumnWithRowID("Nomination Facility",  BaseProject.scenarioID));
					 
					 //Banking Service Details
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerChequeBookReq"), DBUtils.readColumnWithRowID("Cheque Book Required", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_PD_A/CSetupSec_StatementType_DD"), DBUtils.readColumnWithRowID("Statement Type", BaseProject.scenarioID));
					 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDCheckerConsolidatedFlag"), DBUtils.readColumnWithRowID("Consolidated Flag", BaseProject.scenarioID));
					 	 
		       }
		       
	 }



	 @Given("^FullDataChecker: Prefilled Validation Application Tab$")
	 public void fulldatachecker_Prefilled_Validation_Application_Tab() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 
		 
		 //Bank Use
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_SourcingID"), DBUtils.readColumnWithRowID("Sorucing ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ReferralID"), DBUtils.readColumnWithRowID("Referral ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_AcquisitionChannel_DropDown"), DBUtils.readColumnWithRowID("Acquisition Channel",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_FasttrackFlag"), DBUtils.readColumnWithRowID("Fast track Flag",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ApplicationBranch"), DBUtils.readColumnWithRowID("Application Branch",  BaseProject.scenarioID));
		 
		 DBUtils.convertDBtoMap("fdquery");
		 
		//Bank Use
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_BankUseSec_HmeBranchDD"), DBUtils.readColumnWithRowID("Home Branch",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_ClosingID"), DBUtils.readColumnWithRowID("Closing ID",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_InvAccReq_no"), DBUtils.readColumnWithRowID("Investment Account Request",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_AppDetailsTab_HRDate"), DBUtils.readColumnWithRowID("HR Date",  BaseProject.scenarioID));
		 
		 //A/C SETUP in applications tab
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ShortName"), DBUtils.readColumnWithRowID("Account Short Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_ServiceIndicatorcode_DropDown"), DBUtils.readColumnWithRowID("Service Indicator Code",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_InstitutionClassificationCode_ListBox"), DBUtils.readColumnWithRowID("Institution Classification Code",  BaseProject.scenarioID));
		 
		 //debit card applications tab
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_DebitCardRequired_yes"), DBUtils.readColumnWithRowID("Debit Card Required",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_ApplicationDetails_Customer"), DBUtils.readColumnWithRowID("Customer",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_PrimaryProduct_DropDown"), DBUtils.readColumnWithRowID("Primary Product",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FullDataCapture_ApplicationDetails_CardType_DropDown"), DBUtils.readColumnWithRowID("Card Type",  BaseProject.scenarioID));
		 
		 
		 //CKYC
		 
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Date_of_Declation"), DBUtils.readColumnWithRowID("KYC Date Of Declaration",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_place_of_Declation"), DBUtils.readColumnWithRowID("KYC Place Of Declaration",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Verification_Date"), DBUtils.readColumnWithRowID("KYC Verification Date",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employer_name"), DBUtils.readColumnWithRowID("KYC Employee Name",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employer_Designation"), DBUtils.readColumnWithRowID("KYC Employee Designation",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Verification_Branch"), DBUtils.readColumnWithRowID("KYC Verification Branch",  BaseProject.scenarioID));
		 wrap.validatevalue(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDChecker_KYC_Employee_Code"), DBUtils.readColumnWithRowID("KYC Employee Code",  BaseProject.scenarioID));

	 
	  
	 }


	}