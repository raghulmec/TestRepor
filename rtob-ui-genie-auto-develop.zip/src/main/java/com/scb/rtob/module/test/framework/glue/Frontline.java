package com.scb.rtob.module.test.framework.glue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Frontline {
	
	public static Logger logger = Logger.getLogger(Frontline.class);
	
	static CommonUtils utils= new CommonUtils(); 
	static Wrapper wrap= new Wrapper();
	static Commons com=new Commons();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static List<String> uploadDoc = new ArrayList<String>();
	public static List<String> primaryUploadDoc = new ArrayList<String>();
	public static List<String> coAppUploadDoc = new ArrayList<String>();
	
	public static String propertiesFilename = "Frontline";
	
	public static void switchFrame() throws InterruptedException {
		int Last = 0;
		BaseProject.driver.switchTo().defaultContent();
		// Thread.sleep(10000);
		List<WebElement> frames = BaseProject.driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {
			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1; 
		logger.info(Last);
		BaseProject.driver.switchTo().frame(Last);
	}
	
	@Given("^Go to Frontline Referral Home Page$")
    public void goToFrontlineReferralPage() throws Throwable {
		
		 wrap.switch_to_default_Content(BaseProject.driver);
        // wrap.wait(3000);
         wrap.waitForElement(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "work_basket_option"), 20,"visible");
                
                if(!wrap.isElementPresent(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"))){
                      wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "work_basket_option"));                  
                }              
                wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"));
                
                try{               
                      wrap.getWorkbasketoption(BaseProject.driver,"Frontline Referral WB");          
                }
                catch(Exception E){                   
                      //wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));
                      wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "seeall_option"));
                      wrap.getWorkbasketoption(BaseProject.driver,"Full Data Capture Maker");
                      
                }
                wrap.click(BaseProject.driver, com.getElementProperties("FullDatacaptureMaker", "modal_submit_button"));
	}
	
	@Given("^FrontlineRM: Go to FrontlineRM WB home page$")
    public void GotoFrontlineRMWBHomePage() throws Throwable {
     
    //     utils.convertExcelToMap(excelPath,"\\UATBasicData_Testdata_sheet.xls","Basic");
           
           wrap.switch_to_default_Content(BaseProject.driver);
           
           /*if(!wrap.isElementPresent(BaseProject.driver, com.getElementProperties("DI", "seeall_option"))){
                  wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
           
           }*/
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));
           
           
        wrap.getWorkbasketoption(BaseProject.driver," Frontline Referral WB");
    
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));
    
       
    }
	
	@Given("^Go to Frontline WB home page$")
    public void gotoFrontlineWBHomePage() throws Throwable {

        wrap.switch_to_default_Content(BaseProject.driver);

        try {
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "work_basket_option"));
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "seeall_option"));            
            wrap.getWorkbasketoption(BaseProject.driver, "Frontline Referral WB");
            wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "modal_submit_button"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

	@Given("^OperationsWB: Go to OperationsWB home page$")
    public void GotoOperationsWBHomePage() throws Throwable {
     
    //     utils.convertExcelToMap(excelPath,"\\UATBasicData_Testdata_sheet.xls","Basic");
           
           wrap.switch_to_default_Content(BaseProject.driver);
           
           /*if(!wrap.isElementPresent(BaseProject.driver, com.getElementProperties("DI", "seeall_option"))){
                  wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
           
           }*/
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "work_basket_option"));
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "seeall_option"));
           
           
        wrap.getWorkbasketoption(BaseProject.driver,"Operations Referral WB");
    
           wrap.click(BaseProject.driver, com.getElementProperties("DI", "modal_submit_button"));
    
       
    }
	
	 @Then("^Frontline Ref: select an application number$")
	    public static void selectAnApplicationNumber()
	            throws IOException, InterruptedException, ClassNotFoundException, SQLException {

		       /*DBUtils.convertDBtoMap(excelPath, "FullDataCapture.xls", "FullDataCapture");
	           String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);*/
	        wrap.wait(5000);
		  
            
	        String appId = DBUtils.readColumnWithRowID("ApplicationID_FDC", BaseProject.scenarioID);

	        BaseProject.appId = appId.trim();

	        logger.info("The Value going to select or Filter is [" + appId + "]");
	        wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
	        //wrap.wait(2000);
	        String filter = com.getElementProperties("Fulldatacapturemaker",
	                "filter_link");
	        String search = com.getElementProperties("Fulldatacapturemaker",
	                "search_text");
	        String apply_button = com.getElementProperties("Fulldatacapturemaker",
	                "apply_button");
	        //wrap.wait(2000);
	        wrap.click(BaseProject.driver, filter);
	        //wrap.wait(1000);
	        wrap.typeToTextBox(BaseProject.driver, appId, search);
	       // wrap.wait(1000);
	        wrap.click(BaseProject.driver, apply_button);
	 
	        //wrap.wait(3000);

		      /* WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
	           ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);*/
	        switchFrame();

	       // wrap.wait(3000);

	        try {
	            BaseProject.driver.findElement(By.xpath("//div[@id='HARNESS_CONTENT']//table/tbody/tr[1]/td/div/table/tbody/tr[2]/td/div/span[text()='" + appId + "']")).click();
	        } catch (Exception e) {
	            BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
	        }


	    }
//	@Then("^Frontline Ref : select an application number$")
//	public static void selectApplication() throws IOException, InterruptedException {
//		
//		   utils.convertExcelToMap(BaseProject.excelPath, "FullDataCapture.xls", "FullDataCapture");
//	       String appId = CommonUtils.readColumnWithRowID("ApplicationID_FrontlineRef", BaseProject.scenarioID);
//	       BaseProject.appId = appId;
//	       
//	       logger.info("The Value going to select or Filter is ["+appId+"]");
//	       wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget0Ifr");
//	       //wrap.wait(2000);
//	       String filter = com.getElementProperties("Fulldatacapturemaker","filter_link");
//	       String search = com.getElementProperties("Fulldatacapturemaker","search_text");
//	       String apply_button = com.getElementProperties("Fulldatacapturemaker","apply_button");
//	       //wrap.wait(2000);
//	       wrap.click(BaseProject.driver, filter);
//	       //wrap.wait(1000);
//	       wrap.typeToTextBox(BaseProject.driver, appId, search);
//	      // wrap.wait(1000);
//	       wrap.click(BaseProject.driver, apply_button);
//
//	       //wrap.wait(10000);
//
//	      /* WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']"));
//	       ((JavascriptExecutor) BaseProject.driver).executeScript("arguments[0].scrollIntoView(true);", element);*/
//	       BaseProject.driver.findElement(By.xpath("//span[text()='" + appId + "']")).click();
//	       
//	}
//	
	@Then("^Frontline Ref : Check if Referral '(.+)' is present or not$")
	public static void checkReferralPresent(String referral) throws Exception {

		System.out.println("Referral Key : "+referral);
		switchFrame();

		List<WebElement> referralRemarks = BaseProject.driver.findElements(By.xpath("//td[@data-attribute-name='Referral Remarks']"));
		//wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");

		
		for(int i=0; i<referralRemarks.size(); i++)
		{
			String retrievedRefRemark = referralRemarks.get(i).getText();
			logger.info("retrievedRefRemark : "+retrievedRefRemark);
			if(retrievedRefRemark.contains(referral))
			{
				logger.info("The Referral Remarks is : "+retrievedRefRemark);
				uploadDoc.add(referral);
				/*com.setExcelFile(excelPath+"\\BaseProject_Testdata_Sheet1.xls","MissingDoc");
				com.setCellData(referral, 1, 0);*/
				//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
			}
			else
			{
				logger.info("The Referral Reason is not available");
				//Assert.assertFalse(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
			}
		}
		
		/*Iterator itr = uploadDoc.iterator();
		while(itr.hasNext()){
			System.out.println("Doc Name in list : "+itr.next().toString());
		}*/
		//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, referralXpath));
		//button[contains(.,'Referral')]
	}
	
	@Then("^Frontline Ref : Add Referral Reason using Referral action$")
	public static void addingReferral() throws IOException, InterruptedException {
		switchFrame();
		
		wrap.click(BaseProject.driver, "//button[contains(.,'Referral')]");
		
		//wrap.wait(3000);
		wrap.click(BaseProject.driver, "//button[contains(@name,'CaptureReferralDetails')]");

		//wrap.wait(4000);
		Select sel1 = new Select(BaseProject.driver.findElement(By.xpath("//select[starts-with(@id,'ReworkCategoryDesc')]")));
		sel1.selectByIndex(1);
		//wrap.wait(4000);

		Select sel2 = new Select(BaseProject.driver.findElement(By.xpath("//select[starts-with(@id,'ReworkDescription')/option[6]]")));
		sel2.selectByIndex(1);
		
		//wrap.wait(2000);
		wrap.type(BaseProject.driver, "test", "//input[starts-with(@id,'RMReferralRemarks')]");
		//wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");

		//wrap.wait(2000);
		wrap.click(BaseProject.driver, "//button[@id='ModalButtonSubmit']");
		//wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");
		
		//wrap.wait(4000);
		wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
		//wrap.wait(4000);
	}
	
    @Then("^FrontlineRM: Selecting all checkbox in RM Referral$")
    public void selectingAllCheckboxInRMReferral() throws Throwable {
       
       //wrap.wait(1000);
       // List<WebElement> allcheckbox = BaseProject.driver.findElements(By.xpath("//li[@title='Referral Details' and @aria-selected='true' ]/ancestor::div[@class='scrlCntr']//following-sibling::div[contains(@class,'tabContent')]//h2[contains(text(),'RMFrontline')]/ancestor::div[@id='EXPAND-OUTERFRAME']//table[@class='gridTable ']//tbody//tr//td[@data-attribute-name='Completed'])"));
       // List<WebElement> allcheckbox = BaseProject.driver.findElements(By.xpath("//li[@title='Referral Details' and @aria-selected='true' ]/ancestor::div[@class='scrlCntr']//following-sibling::div[contains(@class,'tabContent')]//h2[contains(text(),'RMFrontline')]/ancestor::div[@id='EXPAND-OUTERFRAME']//table[@class='gridTable ']//tbody//tr//td[@data-attribute-name='Completed']//input[@type='checkbox'])"));
    	List<WebElement> allcheckbox = BaseProject.driver.findElements(By.xpath("//input[contains(@id,'IsReworkCompleted')]"));
        for (WebElement eachchecbox : allcheckbox) {
            if(eachchecbox.isDisplayed())
                eachchecbox.click();
              //wrap.wait(1000);
        }
    
    }
    
    @Given("^FrontlineRM: Fill RM Remarks in Frontline WB$")
    public void FillRMRemarksFrontlineWB() throws IOException, InterruptedException{
       
    //BaseProject.switchFrame();
    List<WebElement> allremarks = BaseProject.driver.findElements(By.xpath("//textarea[contains(@id,'ReferralRemarks')]"));
    
    for (WebElement eachremarks : allremarks) {
       if(eachremarks.isDisplayed()){
              
              eachremarks.sendKeys("Completed");
              //wrap.wait(1000);
       }
    }
    }
    //Hema Frontline UI

    @Then("^Frontline : Validate Field '(.+)'$")
    public static void validateFieldFrontline(String FieldName) throws IOException, InterruptedException {

        //wrap.wait(1000);

        logger.info("Going to switch into frame");

        switchFrame();
		logger.info("Frame switched successfully");

		CommonUtilsData.FieldNameData = FieldName;

        CommonUtilsData.convertExcelToMap(BaseProject.excelPath, "Datamodel.xls", "DataModel_1011");

        try {

            if (!CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData).equalsIgnoreCase(null)) {

                CommonUtils.validateField_frontline(
                        CommonUtilsData.readColumnWithRowID("Field Name", CommonUtilsData.FieldNameData),
                        //CommonUtilsData.readColumnWithRowID("Single/Multiple", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Field Locator", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Format", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Data Type", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Length", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("M/O/C", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("Display/Editable/Backend", CommonUtilsData.FieldNameData),
                        CommonUtilsData.readColumnWithRowID("UserInput/Derived", CommonUtilsData.FieldNameData));
//                      CommonUtilsData.readColumnWithRowID("Section", CommonUtilsData.FieldNameData),
//                      CommonUtilsData.readColumnWithRowID("Tab", CommonUtilsData.FieldNameData));

            }
        } catch (Exception E) {

            System.out.println("Field : " + FieldName + " is not present in Datamodel");
        }

    }

    
    @Then("^Frontline : Validate Field values '(.+)'$")
    public static void validateFieldStepFrontline(String FieldName) throws Throwable{

           //checkerHeadersvalue=wrap.getHeadersFromCsv(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\" +"Datamodel - Checker1.csv", ",");
           //CsvCompare.convertCsvMapOfMap(System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData\\"+"Datamodel - Checker1.csv",CheckerData,"\n");
    		
           logger.info("Going to switch into frame");

           switchFrame();

           logger.info("Frame switched successfully");
           
           System.out.println("FieldName-------"+FieldName);
           BaseProject.propertiesFilename = "Frontline";
           CommonUtilsData.FieldNameData = FieldName; 
           String filename = "C:\\Users\\1575778\\Documents\\Frontline\\src\\test\\resources\\ExcelData\\FrontlineUI.csv";
           String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,filename);              
           try{

                 CommonUtils.validateField_frontline(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7]);
                        

               }
           catch(Exception E){

                  System.out.println("Field : "+FieldName+" is not present ");
           }            

    }
    
    @Then("^Read and compare LOVs$")
    public static void ReadCompareLOVs() throws Throwable {
    
    	 logger.info("Going to switch into frame");

         switchFrame();
 		logger.info("Frame switched successfully");
    	
    	String Document_Category = com.getElementProperties("Frontline", "Document_Category");
    	//String Name_of_the_document = com.getElementProperties("Frontline", "Name_of_the_document");
    	
    	CommonUtils.Read_CSV("Document Category", Document_Category);
    	//CommonUtils.Read_values_from_CSV("Name of the document", Name_of_the_document); 	    	
    	
    	
    }
    @Then("^upload the document in Frontline WB$")
    public void UploadDocument() throws Throwable {
    	System.out.println("Inside Document upload");
    	switchFrame();
    	
    	
    	//Reading the data from excel for the document name
    	//utils.convertExcelToMap(excelPath,"BaseProject_Testdata_Sheet1.xls","MissingDoc");
    	
    	//String missingDoc = utils.readColumn("Missing Document",0);
    	//System.out.println("Missing Doc Name : "+missingDoc);
    	List docList = Arrays.asList("AADHAAR", "DRIVING LIC NO", "ELECTRICITY BILL", "GAS BILL", "MOBILE BILL", "NREGA JOB CARD", "OCI CARD", "PASSPORT",
				"PIO CARD", "RESIDENT PERMIT", "TELEPHONE BILL", "VOTERS ID", "WATER BILL", "FORIEGN PASSPORT", "PAN NO", "MID");
    	
    	List prodSuppList = Arrays.asList("ACCOUNT OPENING FORM", "MID", "APPOINTMENT LETTER", "FUNDING CHEQUE", "GPOA", "LOCKER ACCOUNT OPENING FORM", "LOCKER AGREEMENT",
    									  "LOCKER RENT & FEE", "NOMINATION FORM", "OFFER LETTER", "POA & DEBIT AUTHORISATION", "RECOVERY INSTRUCTION FOR LOCKER RENT", "REQUEST FOR LOCKER",
    									  "RESIDENT PERMIT", "RPI ANNEXURE STATEMENT", "SIGNATURE PROOF", "STAFF DECLARATION", "STATEMENT OF OTHER HOLDING", "TXN INFORMATION DOCUMENT( TID)",
    									  "VERNACULAR BOND", "VISA", "WORK PERMIT");
    	
    	List clientIDList = Arrays.asList("DRIVING LIC NO", "AADHAAR", "PAN NO", "FOREIGN PASSPORT", "NADRA", "NREGA JOB CARD", "PASSPORT", "VOTERS ID", "IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE");
    	
    	List clientVerificationList = Arrays.asList("ADDRESS CONFIRMATION THROUGH CIBIL DATA", "CENTRAL POPULATION REGISTER (SMART CARD)", "DRIVING LIC NO", "ELECTRICITY BILL",
    												"EMBASSY / UNO LETTERS", "OREIGN PASSPORT", "GAS BILL", "IDENTITY CARD (OTHER NATIONALITY)", "IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION", 
    												"IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT", "IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS", "IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS",
    												"IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS", "INTERNET BILL", "LETTER ISSUED BY A GAZETTED OFFICER",
    												"LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER", "MOBILE BILL", "MUNICIPAL TAX RECEIPT", "NADRA", "NATIONAL IDENTITY CARD", "NREGA JOB CARD",
    												"OCI CARD", "PASSPORT", "PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)", "PIO CARD", "POST OFFICE SAVINGS BANK ACCOUNT STATEMENT", "PREVIOUS AGREEMENT LODGED FOR REGISTRATION",
    												"PROPERTY TAX RECEIPT", "RENTAL AGREEMENT/SALE� DEED", "RESIDENCE PROOF", "RESIDENCE VERIFICATION REPORT", "RESIDENT PERMIT", "RESIDENT VERIFICATION REPORT",
    												"SUPPLEMENTARY - RESIDENCE PROOF", "TAX DEMAND LETTER OR STATEMENT", "TELEPHONE BILL", "VOTERS ID", "WATER BILL", "PAN VERIFICATION COPY");
    	
    	List internalDocList = Arrays.asList("ADVERSE MEDIA ASSESSMENT FORM", "CORROBORATION OF SOW", "SOI/SOW CHECKLIST");
    	
    	Iterator itr = uploadDoc.iterator();
        while(itr.hasNext())
        {
            
        //System.out.println("printing list : "+itr.next().toString());
        String docType = itr.next().toString().trim().toUpperCase();
        System.out.println("Inside of list");
        System.out.println("Doc type : "+docType);
        
    	//Uploading the particular document in OPS Work basket
    	wrap.wait(4000);
    	Select sel1 = new Select(BaseProject.driver.findElement(By.id("UploadToApplicant")));
		sel1.selectByIndex(1);
		wrap.wait(2000);
		
		if(clientIDList.contains(docType))
		{
			Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
			sel2.selectByVisibleText("CLIENT ID  DOCUMENTS");
		}
		if(clientVerificationList.contains(docType))
		{
			Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
			sel2.selectByVisibleText("CLIENT VERIFICATION DOCUMENTS");
		}
		if(prodSuppList.contains(docType))
		{
			Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
			sel2.selectByVisibleText("PRODUCT & SUPPORTING DOCUMENTS");
		}
		if(internalDocList.contains(docType))
		{
			Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
			sel2.selectByVisibleText("INTERNAL DOCUMENTS");
		}
		
		wrap.wait(5000);
		Select sel3 = new Select(BaseProject.driver.findElement(By.id("DocTypeToUpload")));
		sel3.selectByVisibleText(docType);
	    
	    wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("Frontline", "Choose_File"));
        wrap.wait(9000);
        Runtime.getRuntime().exec("C:\\Workspace\\latest\\Frontline\\src\\test\\resources\\Autoit\\AccountUploadModule.exe");
        //wrap.captureScreenShot(BaseProject.driver, "OPS WB");
        wrap.wait(7000);
        
        wrap.click(BaseProject.driver, com.getElementProperties("Frontline", "Upload_Document"));
       // wrap.captureScreenShot(BaseProject.driver, "OPS WB");
        wrap.wait(10000);
        }
        uploadDoc.clear();
      //  wrap.wait(2000);
       wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
    }
    
    @Then("^Read full name for Primary and CoApplicant$")
    public void readFirstNameLastName() throws Throwable {
    	switchFrame();
    	wrap.click(BaseProject.driver, "//label[text()='Application Details'][1]");
    	//List<WebElement> fullName = BaseProject.driver.findElements(By.xpath("//span[text()='Full name']/following-sibling::div//span"));
    	String primaryFullName = BaseProject.driver.findElement(By.xpath("//span[text()='Full name']/following-sibling::div//span")).getText();
    	
    	
    	System.out.println("primaryFullName : "+primaryFullName);
    	
    	com.setExcelFile(excelPath+"\\BaseProject_Testdata_Sheet1.xls","MissingDoc");
		com.setCellData(primaryFullName, 1, 1);
		
		//wrap.wait(2000);
    	wrap.click(BaseProject.driver, "//span[text()='Co-Applicant']");
    	String coAppFullName = BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block')]//span[text()='Full name']/following-sibling::div//span")).getText();
    
    	System.out.println("coAppFullName : "+coAppFullName);
    	
    	com.setExcelFile(excelPath+"\\BaseProject_Testdata_Sheet1.xls","MissingDoc");
		com.setCellData(coAppFullName, 1, 2);
    	wrap.wait(4000);

    }
    
    @Then("^Frontline Ref : Check if Referral '(.+)' is present or not for Primary$")
	public static void checkReferralPrimaryCoApp(String referral) throws Exception {

		System.out.println("Referral Key : "+referral);
		//switchFrame();

		utils.convertExcelToMap(excelPath,"BaseProject_Testdata_Sheet1.xls","MissingDoc");
		String primaryFirstName = utils.readColumn("Primary Fullname",0);
    	System.out.println("Primary Fullname from Excel : "+primaryFirstName);
    	
    	wrap.click(BaseProject.driver, "//label[text()='Referral Details']");
    	
		List<WebElement> referralRemarks = BaseProject.driver.findElements(By.xpath("//td[@data-attribute-name='Referral Remarks']"));
		wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");

		for(int i=0; i<referralRemarks.size(); i++)
		{
			String retrievedRefRemark = referralRemarks.get(i).getText();
			logger.info("retrievedRefRemark : "+retrievedRefRemark);
			if(retrievedRefRemark.contains(primaryFirstName)
					&& retrievedRefRemark.contains(referral))
			{
				logger.info("The Primary Referral Remarks is : "+retrievedRefRemark);
				primaryUploadDoc.add(referral);
				retrieveValuesFromListMethod(primaryUploadDoc);
				/*com.setExcelFile(excelPath+"\\BaseProject_Testdata_Sheet1.xls","MissingDoc");
				com.setCellData(referral, 1, 0);*/
				//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
				System.out.println("if primary retrievedRefRemark : "+retrievedRefRemark);
			}		
			else
			{
				logger.info("The Primary Referral Reason is not available");
				//Assert.assertFalse(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
				System.out.println("else primary retrievedRefRemark : "+retrievedRefRemark);
			}
		}
		//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, referralXpath));
		//button[contains(.,'Referral')]
	}
    
    @Then("^Frontline Ref : Check if Referral '(.+)' is present or not for CoApplicant$")
	public static void checkReferralCoApp(String referral) throws Exception {

		System.out.println("Co-App Referral Key : "+referral);
		//switchFrame();

		utils.convertExcelToMap(excelPath,"BaseProject_Testdata_Sheet1.xls","MissingDoc");
    	
    	String coAppFirstName = utils.readColumn("CoApp Fullname",0);
    	System.out.println("CoApp Fullname from Excel : "+coAppFirstName);
    	
    	wrap.click(BaseProject.driver, "//label[text()='Referral Details']");
    	
		List<WebElement> referralRemarks = BaseProject.driver.findElements(By.xpath("//td[@data-attribute-name='Referral Remarks']"));
		wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");
		
		for(int i=0; i<referralRemarks.size(); i++)
		{
			String retrievedRefRemark = referralRemarks.get(i).getText();
			logger.info("retrievedRefRemark : "+retrievedRefRemark);
			
			if(retrievedRefRemark.contains(coAppFirstName)
					&& retrievedRefRemark.contains(referral))
			{
				logger.info("The CoApp Referral Remarks is : "+retrievedRefRemark);
				coAppUploadDoc.add(referral);
				retrieveValuesFromListMethod(coAppUploadDoc);
				/*com.setExcelFile(excelPath+"\\BaseProject_Testdata_Sheet1.xls","MissingDoc");
				com.setCellData(referral, 1, 3);*/
				//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
				System.out.println("if coapp retrievedRefRemark : "+retrievedRefRemark);
			}		
			else
			{
				logger.info("The CoApp Referral Reason is not available");
				//Assert.assertFalse(wrap.isElementPresent(BaseProject.driver, retrievedRefRemark));
				System.out.println("else coapp retrievedRefRemark : "+retrievedRefRemark);
			}
		}
		//Assert.assertTrue(wrap.isElementPresent(BaseProject.driver, referralXpath));
		//button[contains(.,'Referral')]
	}
    
    @Then("^reading data from the excel for the document name for primary and coApp$")
    public void iteratingListforUpload() throws Throwable {
    	switchFrame();
    	
    	List prodSuppList = Arrays.asList("ACCOUNT OPENING FORM", "MID", "APPOINTMENT LETTER", "FUNDING CHEQUE", "GPOA", "LOCKER ACCOUNT OPENING FORM", "LOCKER AGREEMENT",
				  "LOCKER RENT & FEE", "NOMINATION FORM", "OFFER LETTER", "POA & DEBIT AUTHORISATION", "RECOVERY INSTRUCTION FOR LOCKER RENT", "REQUEST FOR LOCKER",
				  "RESIDENT PERMIT", "RPI ANNEXURE STATEMENT", "SIGNATURE PROOF", "STAFF DECLARATION", "STATEMENT OF OTHER HOLDING", "TXN INFORMATION DOCUMENT( TID)",
				  "VERNACULAR BOND", "VISA", "WORK PERMIT");

    	List clientIDList = Arrays.asList("DRIVING LIC NO", "AADHAAR", "PAN NO", "FOREIGN PASSPORT", "NADRA", "NREGA JOB CARD", "PASSPORT", "VOTERS ID", "IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE");

    	List clientVerificationList = Arrays.asList("ADDRESS CONFIRMATION THROUGH CIBIL DATA", "CENTRAL POPULATION REGISTER (SMART CARD)", "DRIVING LIC NO", "ELECTRICITY BILL",
							"EMBASSY / UNO LETTERS", "OREIGN PASSPORT", "GAS BILL", "IDENTITY CARD (OTHER NATIONALITY)", "IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION", 
							"IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT", "IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS", "IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS",
							"IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS", "INTERNET BILL", "LETTER ISSUED BY A GAZETTED OFFICER",
							"LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER", "MOBILE BILL", "MUNICIPAL TAX RECEIPT", "NADRA", "NATIONAL IDENTITY CARD", "NREGA JOB CARD",
							"OCI CARD", "PASSPORT", "PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)", "PIO CARD", "POST OFFICE SAVINGS BANK ACCOUNT STATEMENT", "PREVIOUS AGREEMENT LODGED FOR REGISTRATION",
							"PROPERTY TAX RECEIPT", "RENTAL AGREEMENT/SALE� DEED", "RESIDENCE PROOF", "RESIDENCE VERIFICATION REPORT", "RESIDENT PERMIT", "RESIDENT VERIFICATION REPORT",
							"SUPPLEMENTARY - RESIDENCE PROOF", "TAX DEMAND LETTER OR STATEMENT", "TELEPHONE BILL", "VOTERS ID", "WATER BILL", "PAN VERIFICATION COPY");

    	List internalDocList = Arrays.asList("ADVERSE MEDIA ASSESSMENT FORM", "CORROBORATION OF SOW", "SOI/SOW CHECKLIST");

    	Iterator itr1 = primaryUploadDoc.iterator();
        while(itr1.hasNext())
        {
            
        //System.out.println("printing list : "+itr.next().toString());
        String docType1 = itr1.next().toString().trim().toUpperCase();
        System.out.println("Inside of list");
        System.out.println("CoApp Doc type 1: "+docType1);
        
    	//Uploading the particular document in OPS Work basket
    	//wrap.wait(4000);
    	Select sel1 = new Select(BaseProject.driver.findElement(By.id("UploadToApplicant")));
		sel1.selectByIndex(1);
		//wrap.wait(2000);
		Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
		sel2.selectByVisibleText("PRODUCT & SUPPORTING DOCUMENTS");
		//wrap.wait(5000);
		Select sel3 = new Select(BaseProject.driver.findElement(By.id("DocTypeToUpload")));
		sel3.selectByVisibleText(docType1);
	    
	    //wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("OPSWork", "OPS_UploadDocument_ChooseFile_Input_XPATH"));
        //wrap.wait(9000);
        Runtime.getRuntime().exec("C:\\Drop1MergeCode\\R1_R1.1_AutomationPack\\src\\test\\resources\\autoit\\OPSUpload.exe");
        wrap.captureScreenShot(BaseProject.driver, "OPS WB");
        //wrap.wait(7000);
        
        wrap.click(BaseProject.driver, com.getElementProperties("OPSWork", "OPS_UploadDocument_Upload_Button_XPATH"));
        wrap.captureScreenShot(BaseProject.driver, "OPS WB");
       // wrap.wait(10000);
        }
        primaryUploadDoc.clear();
       // wrap.wait(2000);
        
    	Iterator itr2 = coAppUploadDoc.iterator();
        while(itr2.hasNext())
        {
            
        //System.out.println("printing list : "+itr.next().toString());
        String docType2 = itr2.next().toString().trim().toUpperCase();
        System.out.println("Inside of list");
        System.out.println("CoApp Doc type 2: "+docType2);
        
    	//Uploading the particular document in OPS Work basket
    	//wrap.wait(4000);
    	Select sel1 = new Select(BaseProject.driver.findElement(By.id("UploadToApplicant")));
		sel1.selectByIndex(1);
		//wrap.wait(2000);
		Select sel2 = new Select(BaseProject.driver.findElement(By.id("DocCategoryToUpload")));
		sel2.selectByVisibleText("PRODUCT & SUPPORTING DOCUMENTS");
		//wrap.wait(5000);
		Select sel3 = new Select(BaseProject.driver.findElement(By.id("DocTypeToUpload")));
		sel3.selectByVisibleText(docType2);
	    
	   // wrap.wait(4000);
        wrap.click(BaseProject.driver, com.getElementProperties("OPSWork", "OPS_UploadDocument_ChooseFile_Input_XPATH"));
      //  wrap.wait(9000);
        Runtime.getRuntime().exec("C:\\Drop1MergeCode\\R1_R1.1_AutomationPack\\src\\test\\resources\\autoit\\OPSUpload.exe");
        wrap.captureScreenShot(BaseProject.driver, "OPS WB");
      //  wrap.wait(7000);
        
        wrap.click(BaseProject.driver, com.getElementProperties("OPSWork", "OPS_UploadDocument_Upload_Button_XPATH"));
        wrap.captureScreenShot(BaseProject.driver, "OPS WB");
       // wrap.wait(10000);
        }
        coAppUploadDoc.clear();
       // wrap.wait(2000);
        wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
    }
    
    @Then("^Take Screenshot for Frontline Referral Workbasket$")
	public void takeScreenshotForFrontlineWB() throws Throwable {

    	wrap.captureScreenShot(BaseProject.driver, "Frontline Referral");

	}
    
    public static void retrieveValuesFromListMethod(List list)
    {
        Iterator itr = list.iterator();
        while(itr.hasNext())
        {
            System.out.println("List Values :"+itr.next());
        }
    }
}

