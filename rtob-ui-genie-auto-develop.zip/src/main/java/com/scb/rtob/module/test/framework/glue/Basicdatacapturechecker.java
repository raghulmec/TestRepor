package com.scb.rtob.module.test.framework.glue;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.ibm.icu.util.StringTokenizer;
import com.opencsv.CSVReader;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.Wrapper;
import com.scb.rtob.module.test.utils.BusinessCommonUtils;
import com.scb.rtob.module.test.utils.CommonUtils;
import com.scb.rtob.module.test.utils.CommonUtilsData;
import com.scb.rtob.module.test.utils.CsvCompare;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.CsvReaderutil;
import com.scb.rtob.module.test.utils.DBUtils;




//import com.scb.rtob.module.test.utils.Field;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Basicdatacapturechecker {


	int i=0;
	static Wrapper wrap = new Wrapper();
	static Commons com=new Commons();
	//public static WebDriver driver;

	public static WebDriver driver=BaseProject.driver;
	private static Logger logger = Logger.getLogger(Basicdatacapturechecker.class);
	static BusinessCommonUtils businesscommonutils= new BusinessCommonUtils();
	public static SeleniumService service;
	private GenieScenario genieScenario;
	static FluentWait<WebDriver> wait = null;

	static WebElement basicEle; 
	static WebElement blindEle; 
	static WebElement checkerEle; 
	static int jscrol=0;
	static CommonUtils utils= new CommonUtils(); 
	static CsvReaderutil csvread = new CsvReaderutil();
	public static String excelPath=System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData";
	public static String screenShotPath = "C:/R2/Basic Screen shot";
	public static String propertiesFilename2 = "Checker";
	static Properties CONFIG ;
	public static int BDC_Multiple_Product = 0;
	public static String MultipleProducts_xpath = null;

	@Given("^Checker: Switch to frame$")
	public static  void switchFrame() throws InterruptedException {
		int Last = 0;
		driver.switchTo().defaultContent();
		List<WebElement> frames = driver.findElements(By.tagName("iframe"));
		for (WebElement frame : frames) {

			logger.info(frame.getAttribute("Name"));
		}

		Last = frames.size() - 1;
		logger.info(Last);
		driver.switchTo().frame(Last); 
	}


	@Then("^Checker: release the application$")
	public void releaseTheApplication1() throws Throwable {
		switchFrame();
		logger.info("Frame switched successfully");

		wrap.scroll_to(driver,"//button[text()=' Release ']");
		driver.findElement(By.xpath("//button[text()=' Release ']")).click();
		//handle_alert_popup_for_cancel_instapack_debit();

		try{
			driver.findElement(By.xpath("//span[text()='Confirm close']//preceding::table//following-sibling::div//u[contains(text(),'D')]")).click();
		}
		catch(Exception e)
		{

		} 
	}

	/////////////////////////////////////////////////////////////genaral-for reports/////////////////////////////////////////////////////////////
	//static List<HashMap<String,String>> CheckerData = new ArrayList<HashMap<String,String>>();
	//static Map<String,Object> CheckerData= new HashMap<String,Object>();
	List<String> dataSheetheaders= new ArrayList<String>();
	List<String> report= new ArrayList<String>();
	List <String> reportHeaders= new ArrayList<String>();


	List <String> checkerHeaders= new ArrayList<String>();//headers from the data sheet
	static List <String> checkerHeadersvalue= new ArrayList<String>();
	static Map<String,Object> CheckerData= new HashMap<String,Object>();//result is taken from csv and converted into mapOfMap

	@Given("^Checker: close the application$")
	public static void quitDriver(){
		//driver=service.getWebDriver();
		driver.quit();
	}



	@Given("^Checker: Go to Basic Data Capture Checker home page$")
	public void gotoBasicDataCaptureCheckerHomePage() throws Throwable {


		wrap.switch_to_default_Content(driver);

		wrap.click( driver, com.getElementProperties("DI", "work_basket_option"));
		wrap.click( driver, com.getElementProperties("DI", "seeall_option"));


		wrap.getWorkbasketoption( driver,"Basic Data Capture Checker");

		wrap.click(driver, com.getElementProperties("DI", "modal_submit_button"));


	}

	@Then("^cancel checker application$")
	public void clickCancelCheckerScreen()
	{

		List<WebElement>cancelButtons=wrap.getElements(driver,"//div[text()='Cancel']");
		cancelButtons.get(cancelButtons.size()-1).click();
	}


	@Then("^Take Screenshot for Checker$")
	public void takeScreenshotForChecker() throws Throwable {

		wrap.captureScreenShot(BaseProject.driver, "Data Capture Checker");

	}

	@Then("^Checker: Selecting Basic values in Customer tab$")
	public void selectCheckboxesCustomerBasicSection() throws InterruptedException, IOException{
		String basic_Values = com.getElementProperties("Checker", "Checker_PrimaryforBasicCustomertab");
		selectcheckboxes(basic_Values); 
	}


	@Then("^select blind data checkboxes in checker$")
	public void selectCheckboxesCustomerBlindSection() throws InterruptedException, IOException{
		String basic_Values = com.getElementProperties("Checker", "Checker_PrimaryforBlindCustomertab");
		selectcheckboxes(basic_Values);


	}


	public boolean isTextEnabled(WebElement ele) throws InterruptedException{


		//ele.click();
		if(ele.isEnabled()){
			logger.info("ifff");
			return true;
		}else{

			logger.info("elseee");
			return true;
		}
	}

	@Then("^Enter data in Checker section '(.*)'$")
	public void enterDataInChecker(String scenarioId) throws InterruptedException, IOException{
		Map<String,String> CheckerDataTable= (Map<String, String>) CheckerData.get(scenarioId);

		switchFrame();
		wrap.fluentWait(driver, com.getElementProperties("Checker","Checker_PrimaryApplicant_Tab_XPATH"));//waits till the label'Primary applicant is displayed'

		String Titles = DBUtils.readColumnWithRowID("Title", BaseProject.scenarioID);
		String First_Name = DBUtils.readColumnWithRowID("First Name", BaseProject.scenarioID);
		String Middle_Name = DBUtils.readColumnWithRowID("Middle Name", BaseProject.scenarioID);
		String Last_Name = DBUtils.readColumnWithRowID("Last Name", BaseProject.scenarioID);
		String DOB = DBUtils.readColumnWithRowID("DOB", BaseProject.scenarioID);
		String Nationality_Code1 = DBUtils.readColumnWithRowID("Nationality Code1", BaseProject.scenarioID);
		String Nationality_Description1 = DBUtils.readColumnWithRowID("Nationality Description1", BaseProject.scenarioID);

		String Country_Of_Birth = DBUtils.readColumnWithRowID("Country Of Birth Description", BaseProject.scenarioID);
		String Residence_Country = DBUtils.readColumnWithRowID("Residence Country Description", BaseProject.scenarioID);
		String Alias_Type = DBUtils.readColumnWithRowID("Alias Type", BaseProject.scenarioID);
		String Alias = DBUtils.readColumnWithRowID("Alias(es)", BaseProject.scenarioID);

		String Country_Of_Birth_Code = DBUtils.readColumnWithRowID("Country Of Birth Code", BaseProject.scenarioID);
		String Residence_Country_Code = DBUtils.readColumnWithRowID("Residence Country Code", BaseProject.scenarioID);
		String Alias_First_Name = DBUtils.readColumnWithRowID("Alias First Name", BaseProject.scenarioID);
		String Alias_Middle_Name = DBUtils.readColumnWithRowID("Alias Middle Name", BaseProject.scenarioID);
		String Alias_Last_Name = DBUtils.readColumnWithRowID("Alias Last Name", BaseProject.scenarioID);
		String Client_Type = DBUtils.readColumnWithRowID("Client Type", BaseProject.scenarioID);

		String Contact_type_Code = DBUtils.readColumnWithRowID("Contact type Code", BaseProject.scenarioID);
		String Contact_type_Description = DBUtils.readColumnWithRowID("Contact type Description", BaseProject.scenarioID);
		String Contact_Details = DBUtils.readColumnWithRowID("Contact Details", BaseProject.scenarioID);
		String ISD_Code = DBUtils.readColumnWithRowID("ISD Code", BaseProject.scenarioID);
		String Extension_No = DBUtils.readColumnWithRowID("Extension", BaseProject.scenarioID);

		String Occupationcode = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
		String OccupationDescription = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);
		String Document_Category = DBUtils.readColumnWithRowID("Document Category", BaseProject.scenarioID);
		String Name_of_the_Document = DBUtils.readColumnWithRowID("Name of the Document", BaseProject.scenarioID);
		String Document_Number = DBUtils.readColumnWithRowID("Document Number", BaseProject.scenarioID);
		String Document_Expiry_Date = DBUtils.readColumnWithRowID("Document Expiry Date", BaseProject.scenarioID);
		String Document_Signature_Date = DBUtils.readColumnWithRowID("Document Signature Date", BaseProject.scenarioID);

		String Product_Category = DBUtils.readColumnWithRowID("Product Category", BaseProject.scenarioID);
		String Product_Code = DBUtils.readColumnWithRowID("Product Code", BaseProject.scenarioID);

		String Purpose_of_account_opening = DBUtils.readColumnWithRowID("Purpose of account opening", BaseProject.scenarioID);
		String Account_Request_Type = DBUtils.readColumnWithRowID("Account Request Type", BaseProject.scenarioID);
		String Service_Type = DBUtils.readColumnWithRowID("Service Type", BaseProject.scenarioID);
		String Account_Number = DBUtils.readColumnWithRowID("Account Number", BaseProject.scenarioID);
		String Account_Currency = DBUtils.readColumnWithRowID("Account Currency Description", BaseProject.scenarioID);
		String Account_Currency_Code = DBUtils.readColumnWithRowID("Account Currency Code", BaseProject.scenarioID);

		String Sourcing_ID = DBUtils.readColumnWithRowID("Sorucing ID", BaseProject.scenarioID);
		String Referral_ID = DBUtils.readColumnWithRowID("Referral ID", BaseProject.scenarioID);
		String Acquisition_Channel = DBUtils.readColumnWithRowID("Acquisition Channel", BaseProject.scenarioID);
		String Fast_track_Flag = DBUtils.readColumnWithRowID("Fast track Flag", BaseProject.scenarioID);
		String Application_Branch = DBUtils.readColumnWithRowID("Application Branch", BaseProject.scenarioID);

		JavascriptExecutor js3 = ((JavascriptExecutor) driver); 
		js3.executeScript("window.scrollBy(0,-15000)", "");


		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Title_XPATH")).isDisplayed()){

			logger.info(Titles + "Title gonna enter");

			Select product = new Select(driver.findElement(By.xpath("//select[@id='CheckerValue']")));//Title
			product.selectByVisibleText(Titles); //Title

			logger.info("Title Entered");

			wrap.wait(2000);
		}

		else {

			logger.info("Title field not present");
		}


		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Firstname_XPATH")).isDisplayed())	{

			wrap.type(driver, First_Name, com.getElementProperties("Checker", "Checker_Firstname_XPATH"));//FN
			wrap.wait(2000);
		}

		else
		{
			logger.info("FirstName not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Middlename_XPATH")).isDisplayed())	{

			wrap.type(driver, Middle_Name, com.getElementProperties("Checker", "Checker_Middlename_XPATH"));
			wrap.wait(2000);
		}

		else
		{
			logger.info("MiddleName not present");
		}


		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Lastname_XPATH")).isDisplayed())	{

			wrap.type(driver, Last_Name, com.getElementProperties("Checker", "Checker_Lastname_XPATH"));
			wrap.wait(2000);
		}

		else
		{
			logger.info("LastName not present");
		}

		wrap.wait(3000);


		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DOB_XPATH")).isDisplayed())
		{

			wrap.type(driver, DOB, com.getElementProperties("Checker", "Checker_DOB_XPATH"));

			wrap.wait(2000);
		}
		else
		{
			logger.info("Date of birth not present");
		}

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_COB_XPATH")).isDisplayed())
		{

			wrap.type(driver, Country_Of_Birth, com.getElementProperties("Checker", "Checker_COB_XPATH"));
			wrap.wait(2000);
		}
		else
		{
			logger.info("Country of birth not present");
		}

		wrap.wait(2000);


		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_ClientType_XPATH")).isDisplayed())
		{

			//wrap.type(driver, Client_Type, com.getElementProperties("Checker", "Checker_ClientType_XPATH"));
			Select product = new Select(driver.findElement(By.xpath("//select[@id='CheckerValue']")));//Title
			product.selectByVisibleText(Client_Type);
			wrap.wait(2000);
		}
		else
		{
			logger.info("Client type not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_EDC_XPATH")).isDisplayed())

		{
			wrap.type(driver, "TEST", com.getElementProperties("Checker", "Checker_EDC_XPATH"));
		}
		else
		{
			logger.info("Embossed Debit card Name not present");
		}



		JavascriptExecutor js = ((JavascriptExecutor) driver); 
		js.executeScript("window.scrollBy(0,352)", "");

		wrap.wait(2000);		

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AFN_XPATH")).isDisplayed())

		{
			wrap.type(driver,Alias_First_Name , com.getElementProperties("Checker", "Checker_AFN_XPATH"));
		}
		else
		{
			logger.info("Alias first Name not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AMN_XPATH")).isDisplayed())

		{
			wrap.type(driver,Alias_Middle_Name , com.getElementProperties("Checker", "Checker_AMN_XPATH"));
		}
		else
		{
			logger.info("Alias middle Name not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_ALN_XPATH")).isDisplayed())

		{
			wrap.type(driver,Alias_Last_Name , com.getElementProperties("Checker", "Checker_ALN_XPATH"));
		}
		else
		{
			logger.info("Alias last Name not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_CD_XPATH")).isDisplayed())

		{
			wrap.type(driver,Contact_Details , com.getElementProperties("Checker", "Checker_CD_XPATH"));
		}
		else
		{
			logger.info("Contact details not present");
		}

		wrap.wait(3000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_ISDCode_XPATH")).isDisplayed())

		{
			Select product = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_ISDCode_XPATH")));

			product.selectByVisibleText(ISD_Code);
		}
		else
		{
			logger.info("ISD code not present");
		}

		wrap.wait(3000);

		String Occupation = com.getElementProperties("BasicData", "BasicData_CustomerDetail_Occupation_ListBox_ID");
		String ISIC = com.getElementProperties("BasicData", "BasicData_CustomerDetail_ISIC_ListBox_XPATH");

		String Occupationcode1 = DBUtils.readColumnWithRowID("Occupation Code", BaseProject.scenarioID);
		String OccupationDescription1 = DBUtils.readColumnWithRowID("Occupation Description", BaseProject.scenarioID);
		String ISICcode = DBUtils.readColumnWithRowID("ISIC Code", BaseProject.scenarioID);
		String ISICDescription = DBUtils.readColumnWithRowID("ISIC Description", BaseProject.scenarioID);
		String Employmentsection = com.getElementProperties("BasicData", "Employmentsection");

		wrap.scroll_to(BaseProject.driver,Employmentsection );
		String EmploymentSection = BaseProject.driver.findElement(By.xpath("//h2[text()='Employment']/../..")).getAttribute("aria-expanded");
		if (EmploymentSection.equals("false")) {
			wrap.click(BaseProject.driver, Employmentsection);

		}

		com.suggestionTextBox_CodeDesc(BaseProject.driver, Occupation, Occupationcode, OccupationDescription);
		logger.info("Occupation Selected");

		com.suggestionTextBox_CodeDesc(BaseProject.driver, ISIC, ISICcode, ISICDescription);
		logger.info("ISIC Slected");

		wrap.wait(3000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DocName_TextBox_XPATH")).isDisplayed())

		{

			Select product = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DocName_TextBox_XPATH")));

			product.selectByVisibleText(Name_of_the_Document);

		}
		else
		{
			logger.info("Name of the Document not present");
		}

		wrap.wait(3000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DocNumb_TextBox_XPATH")).isDisplayed())

		{
			driver.findElement(By.xpath("(//span[text()='Document Number'])[1]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DN

			wrap.wait(2000);

			driver.findElement(By.xpath("(//span[text()='Document Number'])[1]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("1234567890");//DN

			wrap.wait(2000);
		}
		else
		{
			logger.info("Document Number not present");
		}
		wrap.wait(3000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DocSignDate_TextBox_XPATH")).isDisplayed())

		{

			driver.findElement(By.xpath("(//span[text()='Document Signature Date'])[1]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DSD

			wrap.wait(2000);

			driver.findElement(By.xpath("(//span[text()='Document Signature Date'])[1]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("10/10/2010");//DSD

			wrap.wait(2000);
		}
		else
		{
			logger.info("Document Signature Date not present");
		}

		wrap.wait(2000);


		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_DocExprDate_TextBox_XPATH")).isDisplayed())

		{
			driver.findElement(By.xpath("(//span[text()='Document Expiry Date'])[1]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DED

			wrap.wait(4000);

			driver.findElement(By.xpath("(//span[text()='Document Expiry Date'])[1]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("10/10/2001");//DED
		}
		else
		{
			logger.info("Document Expiry date not present");
		}

		wrap.wait(2000);

		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_IsDocAvail_XPATH")).isDisplayed())

		{
			driver.findElement(By.xpath("(//span[text()='Is Document Available?'])[1]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//IDA

			wrap.wait(3000);

			Select product4 = new Select(driver.findElement(By.xpath("(//span[text()='Is Document Available?'])[1]/parent::div/parent::td/following-sibling::td[3]//select")));//IDA
			wrap.wait(4000);
			//product1.selectByIndex(3);
			product4.selectByVisibleText("Yes");//IDA
		}
		else
		{
			logger.info("Is Document Available? not present");
		}

		wrap.wait(2000);

		JavascriptExecutor js2 = ((JavascriptExecutor) driver); 
		js2.executeScript("window.scrollBy(0,352)", "");

		wrap.wait(3000);

		String NOD1 = driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]")).getText();

		if(NOD1.equalsIgnoreCase("Name of the Document"))

		{
			driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//Name of Doc2
			//driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//Name of Doc2

			wrap.wait(3000);

			Select product5 = new Select(driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]/parent::div/parent::td/following-sibling::td[3]//select")));//IDA
			wrap.wait(3000);
			//product1.selectByIndex(3);
			product5.selectByVisibleText("GAS BILL");//Name of Doc2
		}
		else
		{
			logger.info("Name of the Document not present");
		}

		//driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//Name of Doc2

		wrap.wait(2000);

		//Select product5 = new Select(driver.findElement(By.xpath("(//span[text()='Name of the Document'])[2]/parent::div/parent::td/following-sibling::td[3]//select")));//IDA
		wrap.wait(3000);
		//product1.selectByIndex(3);
		//product5.selectByVisibleText("GAS BILL");//Name of Doc2

		wrap.wait(3000);

		String DN1 = driver.findElement(By.xpath("(//span[text()='Document Number'])[2]")).getText();

		if(DN1.equalsIgnoreCase("Document Number"))

		{
			driver.findElement(By.xpath("(//span[text()='Document Number'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DN2

			wrap.wait(2000);

			driver.findElement(By.xpath("(//span[text()='Document Number'])[2]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("123456");//DN2
		}
		else
		{
			logger.info("Document Number not present");
		}

		wrap.wait(2000);

		String DSD1 = driver.findElement(By.xpath("(//span[text()='Document Signature Date'])[2]")).getText();

		if(DSD1.equalsIgnoreCase("Document Signature Date"))
		{
			driver.findElement(By.xpath("(//span[text()='Document Signature Date'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DSD2

			wrap.wait(2000);

			driver.findElement(By.xpath("(//span[text()='Document Signature Date'])[2]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("10/10/2015");//DSD2
		}
		else
		{
			logger.info("Document Signature Date not present");
		}


		wrap.wait(2000);


		String DED1 = driver.findElement(By.xpath("(//span[text()='Document Expiry Date'])[2]")).getText();

		if(DED1.equalsIgnoreCase("Document Expiry Date"))

		{
			driver.findElement(By.xpath("(//span[text()='Document Expiry Date'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//DED2

			wrap.wait(4000);

			driver.findElement(By.xpath("(//span[text()='Document Expiry Date'])[2]/parent::div/parent::td/following-sibling::td[3]//span/input")).sendKeys("10/10/2015");//DED2
		}
		else
		{
			logger.info("Document expiry Date not present");
		}
		wrap.wait(2000);

		String IDA1 = driver.findElement(By.xpath("(//span[text()='Is Document Available?'])[2]")).getText();

		if(IDA1.equalsIgnoreCase("Is Document Available?"))
		{
			driver.findElement(By.xpath("(//span[text()='Is Document Available?'])[2]/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();//IDA2

			wrap.wait(2000);

			Select product6 = new Select(driver.findElement(By.xpath("(//span[text()='Is Document Available?'])[2]/parent::div/parent::td/following-sibling::td[3]//select")));//IDA2
			wrap.wait(2000);
			//product1.selectByIndex(3);
			product6.selectByVisibleText("Yes");//IDA2
		}
		else
		{
			logger.info("Is Document Available is not present");
		}
		wrap.wait(2000);
		
		
		JavascriptExecutor js4 = ((JavascriptExecutor) driver); //Product details tab
        js4.executeScript("window.scrollBy(0,-15000)", "");
        
        driver.findElement(By.xpath("//label[text()='Product Details']")).click();
        
        wrap.wait(2000);
        
        if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Purposeofacct_XPATH")).isDisplayed())

		{
	
			Select Purofacct = new Select(wrap.getElement(driver,com.getElementProperties("Checker", "Checker_Purposeofacct_XPATH")));
			wrap.wait(4000);
			//product1.selectByIndex(3);
			Purofacct.selectByVisibleText(Purpose_of_account_opening);
		}
		else
		{
			logger.info("Purpose of acct opening not present");
		}

wrap.wait(2000);
        
        if(wrap.getElement(driver, com.getElementProperties("Checker", "Account Request type")).isDisplayed())

		{
	
			Select Purofacct = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Account Request type")));//IDA
			wrap.wait(4000);
			//product1.selectByIndex(3);
			Purofacct.selectByVisibleText(Account_Request_Type);
		}
		else
		{
			logger.info("Account Request type not present");
		}
        
wrap.wait(2000);
        
        if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AcctCur_XPATH")).isDisplayed())

		{
	
        	com.suggestionTextBox_CodeDesc(BaseProject.driver, com.getElementProperties("Checker", "Checker_AcctCur_XPATH"), Account_Currency_Code, Account_Currency);
		}
		else
		{
			logger.info("Account currency not present");
		}
        
wrap.wait(2000);
        
        if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AcctNo_XPATH")).isDisplayed())

		{
	
        	wrap.typeToTextBox(BaseProject.driver, Account_Number, com.getElementProperties("Checker", "Checker_AcctNo_XPATH"));
		}
		else
		{
			logger.info("Account number not present");
		}
        
wrap.wait(2000);
        
        if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Servicetype_XPATH")).isDisplayed())

		{
	
			Select Purofacct = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Servicetype_XPATH")));
			wrap.wait(4000);
			//product1.selectByIndex(3);
			Purofacct.selectByVisibleText(Service_Type);
		}
		else
		{
			logger.info("Service type not present");
		}
        
        wrap.wait(2000);
        
      if(driver.findElement(By.xpath("//span[text()='Customer Name']/parent::div/parent::td/following-sibling::td[2]//input[2]")).isDisplayed()){
    	 
    	  driver.findElement(By.xpath("//span[text()='Customer Name']/parent::div/parent::td/following-sibling::td[2]//input[2]")).click();//Cust Name
    	  
      }
      
      else
		{
			logger.info("Customer name not present");
		}
		
      wrap.wait(2000);
      
      if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Relatedparty_XPATH")).isDisplayed()){
    	 
    	  driver.findElement(By.xpath("//span[text()='Related Party Type']/parent::div/parent::td/following-sibling::td[3]//input[2]")).click();
      	wrap.wait(2000);
          
          Select RelParty = new Select(driver.findElement(By.xpath("//span[text()='Related Party Type']/parent::div/parent::td/following-sibling::td[3]//select")));//
  		wrap.wait(2000);
  		//product1.selectByIndex(3);
  		RelParty.selectByVisibleText("Co-Borrower (Client)");//Rel Party Type
    	  
      }
      
      else
		{
			logger.info("Rel Type not present");
		}
      
      driver.findElement(By.xpath("//label[text()='Application Details']")).click();
		
      wrap.wait(2000);
		
		if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Fasttrackflag_XPATH")).isDisplayed())
		{
			
			Select Fastrackflag = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_Fasttrackflag_XPATH")));
			wrap.wait(2000);
			//product1.selectByIndex(3);
			Fastrackflag.selectByVisibleText(Fast_track_Flag);//
		}
		else
		{
			logger.info("Fast track flag is not present");
		}
		
		 wrap.wait(2000);
			
			if(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AppBnch_XPATH")).isDisplayed())
			{
				
				Select AppBrnch = new Select(wrap.getElement(driver, com.getElementProperties("Checker", "Checker_AppBnch_XPATH")));
				wrap.wait(2000);
				//product1.selectByIndex(3);
				AppBrnch.selectByVisibleText(Application_Branch);//
			}
			else
			{
				logger.info("Application_Branch is not present");
			}
		
		driver.findElement(By.xpath("(//div[text()='ave'])[2]")).click();
        

	}

	
	public void enterDataInChecker(String chkBox,String textBox,String value) throws InterruptedException{
		verifyCheckBoxThnClick(driver, chkBox);
		verifyTextBoxThnClick(driver,textBox);
		wrap.type(driver,value, textBox);
		verifyvalueafterentry(textBox,value);

	}

	public void selectCheckboxesAndVerify(String xpath,String xpathforverify) throws InterruptedException, IOException{ 
		WebDriverWait wait= new WebDriverWait(driver,5);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");
		int i = 10,j=10, g = 0;
		//-1; 
		try{

			List<WebElement> basicChkBoxes=wrap.getElements(driver,xpath);
			List<WebElement> verifychkBoxes=wrap.getElements(driver,xpathforverify);
			for(WebElement chkBox:basicChkBoxes){  
				try{
					++g;
					wait.until(ExpectedConditions.visibilityOf(chkBox)); 
					if(chkBox.isDisplayed())
					{
						if(!chkBox.isSelected()){ 
							//                          wait.until(ExpectedConditions.elementToBeClickable(chkBox)); 
							chkBox.click();  
							wrap.wait(5000); 
							//                          logger.info("Checkbox checked"); 

						} 

						//                          for(WebElement verifychkBox:verifychkBoxes){
						for(;g<=verifychkBoxes.size();){
							wrap.wait(5000); 
							String val1 = xpathforverify+"["+g+"]//td[4]//div[2]";
							//                                        WebElement verifychkBox =driver.findElement(By.xpath("//div[@id='INNERDIV-SubSectionCheckerCustomerDetailBTR1']//table[@class='gridTable '][1]//tr[not(@class='cellCont')]["+g+"]//td[4]//div[2]"));
							WebElement verifychkBox =driver.findElement(By.xpath(val1));            
							//verifychkBoxes.get(g);
							//                                        for(int is=0;is<5;is++)
							//                                        wait.until(ExpectedConditions.visibilityOf(verifychkBox));
							try{

								//                                        WebElement chkval1 = driver.findElement(By.xpath("//div[@id='INNERDIV-SubSectionCheckerCustomerDetailBTR1']//table[@class='gridTable '][1]//tr[not(@class='cellCont')][1]//td[4]//div[2]/span/input")); 
								//                                        String newg = chkval1.getAttribute("value");
								WebElement chkval = verifychkBox.findElement(By.tagName("span")); 
								WebElement chkval1 = chkval.findElement(By.tagName("input"));
								String valuechk = chkval1.getAttribute("value");
								logger.info("The value available in the field is: "+valuechk);
								//                                        logger.info(valuechk); 
								break;
							} 
							catch( Exception e){ 
								try{ 
									WebElement chkval1 = verifychkBox.findElement(By.tagName("input"));
									String valuechk = chkval1.getAttribute("value");
									logger.info("The value available in the field is: "+valuechk);
									//                                               logger.info(valuechk); 
									break;
								} 
								catch( Exception e1){ 
									try{
										//                                               WebElement chkval2 = verifychkBox.findElement(By.tagName("div"));
										WebElement chkval2 = verifychkBox.findElement(By.tagName("select")); 
										Select chkval4 = new Select(verifychkBox.findElement(By.tagName("select"))); 
										WebElement defaultItem = chkval4.getFirstSelectedOption();
										String valuechk2 = defaultItem.getAttribute("selected value");
										String val3 = defaultItem.getText();
										logger.info("The value available in the field is: "+defaultItem);
										//                                               logger.info(defaultItem);
										break;
									}
									catch( Exception val){ 
										try{ 
											WebElement chkval2 = verifychkBox.findElement(By.tagName("div"));
											WebElement chkval3 = chkval2.findElement(By.tagName("div"));
											Select chkval4 = new Select(chkval3.findElement(By.tagName("select")));
											WebElement option = chkval4.getFirstSelectedOption();
											String defaultItem = option.getText();
											//                                               String valuechk2 = chkval4.getAttribute("selected value");
											logger.info("The value available in the dropdown is: "+defaultItem);
											//                                               logger.info(defaultItem);
											break;
										}
										catch( Exception noele){
											logger.info(noele);
											break;
										} 
									}}}

						}
					}

					else
					{    
						js.executeScript("javascript:window.scrollBy(350,450)"); 
						if(!chkBox.isDisplayed())
						{
							logger.info(chkBox.getAttribute("checked"));
						} 
					} 
					js.executeScript("javascript:window.scrollBy("+i+","+j+")");
					j+=i; 
					js.executeScript("arguments[0].scrollIntoView(true);",chkBox);
					if(j>120){i=3;}
				}

				catch( Exception e){
					logger.info(e);
					continue;
				}
			}}
		catch( Exception e){
			logger.info(e); 
		}
	}

	public void verifyvalueafterentry(String field,String value)throws InterruptedException
	{  
		try{
			wrap.fluentWait(driver, field).sendKeys(Keys.TAB);
			//wrap.click(driver, xpath);
			if(wrap.getElement(driver, field).isDisplayed()){
				String nameval=wrap.getElement(BaseProject.driver, field).getAttribute("value");
				if(nameval.equalsIgnoreCase(value))
				{
					logger.info(value+" is available in the field: " +field);
				}
			}
		}
		catch(StaleElementReferenceException e){
			logger.info(e);
			logger.info(value+" is not available in the field");
		}
	}

	@Then("^put Invalid data in checker'(.*)'$")
	public void putInvalidDataInChecker(String scenarioId) throws InterruptedException, IOException{
		//utils.convertExcelToMap(excelPath,"DataCaptureCheckerUATMapping.xls","Sheet1");
		Map<String,String> CheckerDataTable= (Map<String, String>) CheckerData.get(scenarioId);
		//driver=driver;
		WebDriverWait wait= new WebDriverWait(driver,20);

		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");
		//

		wrap.fluentWait(driver, com.getElementProperties("Checker","Checker_PrimaryApplicant_Tab_XPATH"));//waits till the label'Primary applicant is displayed'

		//wrap.fluentWait(driver, "//span[text()='Primary Applicant']");//waits till the label'Primary applicant is displayed'

		try{
			/*enterDataInChecker(com.getElementProperties("Checker","Checker_FirstName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_FirstName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_First name"));
			enterDataInChecker(com.getElementProperties("Checker","Checker_MiddleName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_MiddleName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Middle Name"));
			enterDataInChecker(com.getElementProperties("Checker","Checker_LastName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_LastName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Last name"));
			enterDataInChecker(com.getElementProperties("Checker","Checker_DOB_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DOB_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Date of birth"));
			enterDataInChecker(com.getElementProperties("Checker","Checker_CountryOfBirth_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_CountryOfBirth_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Country of birth"));
			enterDataInChecker(com.getElementProperties("Checker","Checker_EmbossedDebitCardName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_EmbossedDebitCardName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Embossed Debit Card Name"));*/
			//enterDataInChecker(com.getElementProperties("Checker","Checker_PrimaryApplicant_Tab_XPATH"), com.getElementProperties("Checker","Checker_PrimaryApplicant_Tab_XPATH"),CheckerDataTable.get("Customer Details_Document Number"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_FirstName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_FirstName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_First name"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_MiddleName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_MiddleName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Middle name"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_LastName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_LastName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Last name"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DOB_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DOB_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Date of birth"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_EmbossedDebitCardName_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_EmbossedDebitCardName_TextBox_XPATH"),CheckerDataTable.get("CustomerPersonalDetails_Embossed Debit Card Name"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_ContactDetails_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_ContactDetails_TextBox_XPATH"),CheckerDataTable.get("CustomerContactDetails_ContactDetails"));

			//			enterDataInChecker(com.getElementProperties("Checker","Checker_ContactDetails2_TextBox_XPATH"), com.getElementProperties("Checker","Checker_ContactDetails2_TextBox_XPATH"),CheckerDataTable.get("CustomerContactDetails_ContactDetails"));
			//
			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentNumber1_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentNumber1_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_DocumentNumber"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentNumber2_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentNumber2_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_DocumentNumber"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentDetails_SignatureDate1_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentDetails_SignatureDate1_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_SignatureDate"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentDetails_SignatureDate2_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentDetails_SignatureDate2_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_SignatureDate"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentDetails_ExpiryDate1_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentDetails_ExpiryDate1_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_ExpiryDate"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_DocumentDetails_ExpiryDate2_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_DocumentDetails_ExpiryDate2_TextBox_XPATH"),CheckerDataTable.get("DocumentDetails_ExpiryDate"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_AccountNo_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_AccountNo_TextBox_XPATH"),CheckerDataTable.get("ProductDetails_AccountNo"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_AccountCurrency_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_AccountCurrency_TextBox_XPATH"),CheckerDataTable.get("ProductDetails_AccountCurrency"));

			enterDataInChecker(com.getElementProperties("Checker","Checker_ARMCode_CheckBox_XPATH"), com.getElementProperties("Checker","Checker_ARMCode_TextBox_XPATH"),CheckerDataTable.get("ApplicationDetails_ARMCode"));





			//wrap.type(driver, "done", "//textarea[@id='Comments']");
			//wrap.click(driver, "//div[text()='Submit']");
			//	releaseFromChecker();
		}
		catch(Exception e){
			logger.info(e);
			//		releaseFromChecker();
		}
		//	releaseFromChecker();

	}



	@When("^Checker: Release$")
	public void releaseFromChecker() throws InterruptedException{

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		switchFrame();
		WebElement mytable = BaseProject.driver.findElement(By.xpath("(//div[text()='ave'])[2]"));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		mytable.click();	
		//		switchFrame();

		//	wrap.scroll_to(driver, "//button[text()=' Release ']");
		wrap.click(driver,"//button[@accesskey='R']");
		//wrap.click(driver, "//*[@id="RULE_KEY"]/div/div/div/div[2]/div/div/div/div/div[1]/div[8]/div/div/span/button");

		try{
			switchFrame();

			wrap.fluentWait(driver,"//div[@id='modaldialog_hd']/span[text()='save']");
			wrap.click(driver,"//u[text()='D']");	
		}
		catch(Exception e)
		{
			logger.info(e);
		}
	}

	@Then("^Checker: Save & Select Action and Submit application$")
	public void selectActionDropdownAndEnterRemarks() throws Throwable {
		switchFrame();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		WebElement mytable = BaseProject.driver.findElement(By.xpath("(//div[text()='ave'])[2]"));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		mytable.click();
		switchFrame();
		js.executeScript("javascript:window.scrollBy(120,150)"); 
		Select sel1 = new Select(BaseProject.driver.findElement(By.xpath("//*[@id='ActionBasicDatacapture']")));
		js.executeScript("arguments[0].scrollIntoView(true);",sel1);
		wrap.fluentWait(driver,"//*[@id='ActionBasicDatacapture']");
		sel1.selectByIndex(1);

		List<WebElement> allremarks1 = BaseProject.driver.findElements(By.xpath(" //*[@id='Comments']"));
		for (WebElement eachremarks : allremarks1) {
			if(eachremarks.isDisplayed()){

				eachremarks.sendKeys("Completed");                       
			}
		}
		//       wrap.click(BaseProject.driver, "//button[contains(.,'Submit')]");
		js.executeScript("arguments[0].scrollIntoView(true);",sel1);
	}


	public static void waitunlitVisiblityOfWebElement(String attribute){
		wait.until(ExpectedConditions.visibilityOf(wrap.getElement(driver, attribute)));

	}


	public void explicitWait(String xpathExpression,int timeout){

		new WebDriverWait(driver, timeout).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(By.xpath(xpathExpression)));
		//driver.findElement(By.xpath(xpathExpression)).click();
	}

	public void explicitWait(WebElement elem){

		new WebDriverWait(driver, 20).until(ExpectedConditions.stalenessOf(elem));
		//driver.findElement(By.xpath(xpathExpression)).click();
	}


	public boolean verifyCheckBoxThnClick(WebDriver driver,String xpath) throws InterruptedException{
		try{
			wrap.fluentWait(driver, xpath);
			//wrap.click(driver, xpath);

			while(!wrap.getElement(driver, xpath).isSelected()){

				if(!wrap.getElement(driver, xpath).isSelected()){
					wrap.getElement(driver, xpath).click();
					logger.info("Checkerbox selected");
					//wrap.wait(2000);
				}
			}
			return true;
		}
		catch(StaleElementReferenceException e){
			logger.info(xpath);
			logger.info(e);
			verifyCheckBoxThnClick(driver,xpath);
			return true;
		}
	}	



	public boolean verifyTextBoxThnClick(WebDriver driver,String xpath) throws InterruptedException{
		try{
			//wrap.fluentWait(driver, xpath);
			wrap.click(driver, xpath);


			while(!wrap.getElement(driver, xpath).isEnabled()){
				//
				if(!wrap.getElement(driver, xpath).isEnabled()){
					wrap.getElement(driver, xpath).click();
					wrap.wait(2000);
					logger.info("Textbox selected");
				}
			}
			return true;
		}

		catch(InvalidElementStateException e){
			logger.info(e);
			logger.info(xpath);
			verifyCheckBoxThnClick(driver,xpath);
			return true;
		}
	}


	public void waitTillTextBoxRefreshed(WebElement ele,String uId) throws InterruptedException{
		while(ele.getAttribute("uniqueid").equalsIgnoreCase(uId)){

		}
	}	

	public List<WebElement> getTableRow(WebDriver driver,String gpropindex,String trId){
		List<WebElement> rows=wrap.getElements(driver,"//div[@section_index='1']/div/div[@gpropindex='"+gpropindex+"']/table//table//tr[contains(@id,'"+trId+"')]");//partial tr id
		for(WebElement ele:rows){
			logger.info(ele.getAttribute("id"));
		}
		return rows;
	}


	@Then("^verify Basic Data Capture Checker screen displays only the difference between Basic and Blind Data capture'(.*)'$")
	public  void performDataCaptureReview(String scenarioId) throws InterruptedException{
		//driver=service.getWebDriver();

		String sectionHeader;
		String fieldHeader;
		String basicData;
		String blindData;
		String productCode;
		Map<String,String> CheckerOneRow= (Map<String, String>) CheckerData.get(scenarioId);//get the row related to the scenario id
		Map<String,String>CustomerDetails=new HashMap<String,String>();
		Map<String,String>ContactDetails=new HashMap<String,String>();
		Map<String,String>ProductDetails=new HashMap<String,String>();



		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");

		for(Map.Entry<String, String> entry : CheckerOneRow.entrySet()){
			String key = entry.getKey();
			String val = entry.getValue();
			//span[text()='Document Number']/parent::div/parent::td/parent::tr/td[2]//span[text()='213123123123'] 



			if(key.contains("Customer Details")&!key.contains("Contact")&val.contains("|")){

				CustomerDetails.put(key, CheckerOneRow.get(key));

			}
			if(key.contains("Contact")&val.contains("|")){//only contact details
				ContactDetails.put(key, CheckerOneRow.get(key));

			}
			if(key.contains("Product")&!key.equalsIgnoreCase("Product Details_Product Code")&val.contains("|")){
				//logger.info(key+"="+val);
				ProductDetails.put(key, CheckerOneRow.get(key));

			}
		}

		//highlight customer details
		logger.info("test"+CheckerOneRow.get("Primary_Customer Details_Name of the Document"));
		//		String cusDet=CheckerOneRow.get("Primary_Customer Details_Name of the Document");
		//		String[] fieldHead = null;
		//		if(cusDet.contains("|")){
		//			fieldHead=cusDet.split("\\|");
		//		}
		//		
		//		if(fieldHead.length==1){
		//			
		for(Entry<String,String> fields:CustomerDetails.entrySet()){
			String data[]=fields.getValue().split("\\|");

			try{
				//	wrap.highLightElement(driver,"//span[text()='"+fieldHead[0]+"']/parent::div/parent::td/parent::tr//span[text()='"+data[0]+"']");
				wrap.highLightElement(driver,"//span[text()='"+data[0].trim().toUpperCase()+"']");
				wrap.highLightElement(driver,"//span[text()='"+data[1].trim().toUpperCase()+"']");
				//wrap.highLightElement(driver,"//span[text()='"+fieldHead[0]+"']/parent::div/parent::td/parent::tr//span[text()='"+data[1]+"']");
			}
			catch(NoSuchElementException e){
				wrap.highLightElement(driver,"//span[text()='"+data[0].trim().toLowerCase()+"']");
			}


		}

		String prodCode=CheckerOneRow.get("Product Details_Product Code");
		String[] code=prodCode.split("\\|");
		wrap.click(driver, "//label[text()='Product Details']");

		for(Entry<String,String> fields:ProductDetails.entrySet()){
			String data[]=fields.getValue().split("\\|");

			wrap.highLightElement(driver,"//h3[text()='"+code[0].trim()+"']/parent::div/parent::div/following-sibling::div//label[text()='Basic']/following-sibling::div//span[text()='"+data[0].trim()+"']");
			wrap.highLightElement(driver,"//h3[text()='"+code[1].trim()+"']/parent::div/parent::div/following-sibling::div//label[text()='Blind']/following-sibling::div//span[text()='"+data[1].trim()+"']");



		}



	}	


	public void seperateSectionsAsMap(String scenarioId,String sectionName ){
		Map<String,String> CheckerOneRow= (Map<String, String>) CheckerData.get(scenarioId);
		Map<String,String> tmpMap=new HashMap<String,String>();
		for(Map.Entry<String, String> entry : CheckerOneRow.entrySet()){
			String key = entry.getKey();
			String val = entry.getValue();


			if(key.contains(sectionName)&!key.contains("Contact")&val.contains("|")){

				tmpMap.put(key, CheckerOneRow.get(key));

			}
		}
	}	


	@Then("^verify Basic Data Capture Checker screen displays only the difference single applicant$")
	public  void verifyCheckerScreenDisplaysOnlyDifference(String scenarioId ) throws InterruptedException, IOException{

		String sectionHeader;
		String fieldHeader;
		String basicData;
		String blindData;
		String productCode;
		Map<String,String> CheckerOneRow= (Map<String, String>) CheckerData.get(scenarioId);//get the row related to the scenario id
		Map<String,String>CustomerDetails=new HashMap<String,String>();



		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");

		for(Map.Entry<String, String> entry : CheckerOneRow.entrySet()){
			String key = entry.getKey();
			String val = entry.getValue();

			if(key.contains("CustomerPersonalDetails")&val.contains("|")&!val.isEmpty()){

				CustomerDetails.put(key, CheckerOneRow.get(key));

			}

		}

		for(Entry<String,String> fields:CustomerDetails.entrySet()){

			String data[]=fields.getValue().split("\\|");


			String basic= data[0].trim();
			String blind=data[1].trim();

			String baData=data[0];
			String blData=data[1];
			if(!basic.isEmpty()){
				try{

					wrap.moushover(driver,"//span[text()='"+basic.toUpperCase()+"']"+"|"+"//span[text()='"+basic.toLowerCase()+"']");
					wrap.highLightElement(driver,"//span[text()='"+basic.toUpperCase()+"']"+"|"+"//span[text()='"+basic.toLowerCase()+"']");
				}

				catch(NoSuchElementException e){
					char firstLetter=basic.toUpperCase().trim().charAt(0);
					String rest=basic.substring(1,basic.length()+1).trim().toLowerCase();
					wrap.highLightElement(driver,"//span[text()='"+firstLetter+rest+"']");
				}
			}

			if(!blind.isEmpty()){
				try{

					wrap.moushover(driver, "//span[text()='"+blind.toUpperCase()+"']"+"|"+"//span[text()='"+blind.toLowerCase()+"']");
					wrap.highLightElement(driver, "//span[text()='"+blind.toUpperCase()+"']"+"|"+"//span[text()='"+blind.toLowerCase()+"']");

				}
				catch(NoSuchElementException e){
					char firstLetter=blind.toUpperCase().trim().charAt(0);
					String rest=blData.substring(1, blind.length()+1).trim().toLowerCase();
					wrap.highLightElement(driver,"//span[text()='"+firstLetter+rest+"']");
				}
			}


		}
	}


	public void mouseHoverJScript(WebElement HoverElement) {
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		((JavascriptExecutor) driver).executeScript(mouseOverScript,HoverElement);
	}


	@Given("Checker: Click on Customer Details tab")
	public void clickOnCustomerDetailsTab() throws InterruptedException, IOException{

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		logger.info("Customer details tab to be clicked");
		//		switchFrame();

		String CustomerDetails=com.getElementProperties("Checker", "BasicData_CustomerDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(CustomerDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, CustomerDetails);
		wrap.wait(3000);

	}



	@Given("Checker: Click on Product Details tab")
	public void clickOnProductDetailsTab() throws InterruptedException, IOException{

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		logger.info("Product details tab to be clicked");
		//		switchFrame();

		String ProductDetails=com.getElementProperties("Checker", "BasicData_ProductDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(ProductDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, ProductDetails);
		wrap.wait(3000);

	}

	@Given("Fieldval: Click on Customer Details tab")
	public void gotoCustomerDetailstab() throws InterruptedException, IOException{

		switchFrame();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		logger.info("Customer details tab to be clicked");		

		String CustomerDetails=com.getElementProperties("Checker", "BasicData_CustomerDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(CustomerDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, CustomerDetails);
		wrap.wait(3000);

	}
	
	@Given("Fieldval: Click on Product Details tab")
	public void gotoProductDetailstab() throws InterruptedException, IOException{

		switchFrame();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		logger.info("Product details tab to be clicked");		

		String ProductDetails=com.getElementProperties("Checker", "BasicData_ProductDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(ProductDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, ProductDetails);
		wrap.wait(3000);

	}

	@Given("Checker: Click on Application Details tab")
	public void clickOnApplicationDetailsTab() throws InterruptedException, IOException{

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		switchFrame();
		String ApplnDetails = com.getElementProperties("Checker", "Checker_ApplicationDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(ApplnDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, ApplnDetails);


	}


	@Given("Fieldval: Click on Application Details tab")
	public void goToApplicationDetailsTab() throws InterruptedException, IOException{

		switchFrame();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)"); 
		logger.info("Application details tab to be clicked");		

		String ApplnDetails=com.getElementProperties("Checker", "Checker_ApplicationDetails_Button_XPATH");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(ApplnDetails));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		wrap.click(BaseProject.driver, ApplnDetails);
		wrap.wait(3000);

	}


	@Given("Checker: Select basic values in Checker Product screen")
	public void selectBasicCheckboxesProductTab() throws InterruptedException, IOException{
		String val = com.getElementProperties("Checker","Checker_CheckboxforBasicProducttab");
		selectcheckboxes(val); 
	} 

	@Given("Checker: Select Basic checkboxes in the Checker screen for Co-Applicant")
	public void coApp1ValAdd() throws InterruptedException, IOException{ 
		//		switchFrame();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,10)");   
		//		switchFrame();
		String val = com.getElementProperties("Checker","Checker_CoappclktabforBasicCustomertab");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(val));
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		js.executeScript("arguments[0].click();", mytable);
		//		wrap.click(BaseProject.driver, val);
		String chkvalue = com.getElementProperties("Checker","Checker_CoappforBasicCustomertab");
		selectcheckboxes(chkvalue); 
	} 

	@Given("Checker: Select Basic checkboxes in the Checker screen for second Co-Applicant")
	public void coApp2BasicValAdd() throws InterruptedException, IOException{  
		String chkvalue = com.getElementProperties("Checker","Checker_Coapp2forBasicCustomertab");
		selectcheckboxes(chkvalue); 
	} 


	@Given("Checker: Select Blind checkboxes in the Checker screen for Co-Applicant")
	public void coApp1BlindValAdd() throws InterruptedException, IOException{ 
		String chkvalue = com.getElementProperties("Checker","Checker_CoappforBlindCustomertab");
		selectcheckboxes(chkvalue); 
	} 

	@Given("Checker: Select Blind checkboxes in the Checker screen for second Co-Applicant")
	public void coApp2BlindValFeed() throws InterruptedException, IOException{  
		String chkvalue = com.getElementProperties("Checker","Checker_Coapp2forBlindCustomertab");
		selectcheckboxes(chkvalue); 
	} 

	@Then("^select tab in checker for Co-applicant '(.*)'$")
	public void checkAndViewCoapplicants(int i) throws InterruptedException, IOException{  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		wrap.wait(3000);
		js.executeScript("javascript:window.scrollBy(0,10)");   
		//		switchFrame();
		String val = com.getElementProperties("Checker","Checker_CoappclktabforBasicCustomertab");
		List <WebElement> tabs = BaseProject.driver.findElements(By.xpath(val));
		if(!(tabs.size()>1))
		{
			WebElement mytable = BaseProject.driver.findElement(By.xpath(val)); 
			js.executeScript("arguments[0].scrollIntoView(true);",mytable);
			js.executeScript("arguments[0].click();", mytable);
		}
		else
		{ 
			js.executeScript("arguments[0].scrollIntoView(true);",tabs.get(i-1));
			js.executeScript("arguments[0].click();", tabs.get(i-1));
		}

		//		wrap.click(BaseProject.driver, val);
	}

	@Given("Checker: Select Blind checkboxes in the Checker Product screen")
	public void putDataInBlindtabChecker() throws InterruptedException, IOException{
		wrap.wait(4000);
		WebDriverWait wait= new WebDriverWait(driver,10);
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		String val = com.getElementProperties("Checker","Checker_SelectBlindtabinProduct");
		WebElement mytable = BaseProject.driver.findElement(By.xpath(val));
		wait.until(ExpectedConditions.visibilityOf(mytable));
		wait.until(ExpectedConditions.elementToBeClickable(mytable)); 
		js.executeScript("arguments[0].scrollIntoView(true);",mytable);
		js.executeScript("arguments[0].click();", mytable); 
		String val1 = com.getElementProperties("Checker","Checker_CheckboxforBlindProducttab");
		String val2 = com.getElementProperties("Checker","Checker_CheckboxforBlindProducttabinMain");
		try{
			List<WebElement> blindValues = wrap.getElements(driver, val1);
			if(blindValues.size()>1){
				selectcheckboxes(val1);}
			else
			{
				selectcheckboxes(val2); 
			}
		}
		catch( Exception e){
			logger.info(e); 
			selectcheckboxes(val2);
		} 
	} 

	public void selectcheckboxes(String xpath) throws InterruptedException, IOException{ 
		wrap.wait(2000);
		WebDriverWait wait= new WebDriverWait(driver,5);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.switchTo().defaultContent();
		driver.switchTo().frame("PegaGadget1Ifr");
		int i = 5,j=7; 
		try{
			wrap.wait(2000);
			List<WebElement> basicChkBoxes=wrap.getElements(driver,xpath);

			for(WebElement chkBox:basicChkBoxes){  
				try{
					wait.until(ExpectedConditions.visibilityOf(chkBox)); 
					if(chkBox.isDisplayed())
					{
						if(!chkBox.isSelected()){ 

							chkBox.click();  
							logger.info("Checkbox checked"); 
							wrap.wait(3000);  
						}  
					}
					else
					{    
						js.executeScript("javascript:window.scrollBy(350,450)"); 
						if(!chkBox.isDisplayed())
						{
							logger.info(chkBox.getAttribute("checked"));
						} 
					} 

					js.executeScript("javascript:window.scrollBy("+i+","+j+")");
					j+=i; 
					js.executeScript("arguments[0].scrollIntoView(true);",chkBox);
					if(j>120){i=3;}
				}

				catch( Exception e){
					logger.info(e);
					continue;

				}}}
		catch( Exception e){
			logger.info(e); 
		}
	}


	@Given("Checker: Selecting Basic values in Application tab")
	public void selectingBasicValuesInApplicationTab() throws IOException, InterruptedException{ 
		String basic_Values = com.getElementProperties("Checker", "Checker_CheckboxforBasicApplicationtab");
		selectcheckboxes(basic_Values); 
	} 

	@Given("Checker: Selecting Blind values in Application tab")
	public void selectingBlindValuesInApplicationTab() throws IOException, InterruptedException{ 
		String basic_Values = com.getElementProperties("Checker", "Checker_CheckboxforBlindApplicationtab");
		selectcheckboxes(basic_Values); 
	} 


	@Then("^Checker : Validate Field values '(.+)'$")
	public static void validateFieldStepChecker(String FieldName) throws Throwable{

		logger.info("Going to switch into frame");

		switchFrame();

		logger.info("Frame switched successfully");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		/*String S = wrap.getElement(driver, com.getElementProperties("Checker", "Checker_PrimaryApplicant_Tab_XPATH")).getText();

		logger.info("The String is" + S);*/

		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BDC_CheckerFieldVal.csv");
		try{
			int i=5;
			if(!(Fieldval[0]).equalsIgnoreCase(null)){
				//				js.executeScript("arguments[0].scrollIntoView(true);",Fieldval[11]);
				wrap.click(driver, com.getElementProperties("Checker", Fieldval[11]));

				wrap.wait(2000);
				logger.info("Field validation starts"); 
				CommonUtils.validateField(Fieldval[0],Fieldval[1],Fieldval[2],Fieldval[3],Fieldval[4],Fieldval[5],Fieldval[6],Fieldval[7],Fieldval[8],Fieldval[9],Fieldval[10]);
				js.executeScript("javascript:window.scrollBy("+i+","+jscrol+")");
				jscrol+=i; 
				//						js.executeScript("arguments[0].scrollIntoView(true);",Fieldval[11]);
				if(jscrol>120){i=3;}
			}
		}

		catch(Exception E){

			logger.info("Field : "+FieldName+" is not present in Datamodel");
		}            

	}


	@Then("^Checker: Selecting Checker values in Customer tab$")
	public void selectCheckboxesCustomerCheckerSection() throws InterruptedException, IOException{
		String checker_Values1 = com.getElementProperties("Checker", "Checker_PrimaryforCheckerCustomertab");
		selectcheckboxes(checker_Values1); 
	}


	@Given("Checker: Selecting Checker values in Checker Product screen")
	public void selectCheckerCheckboxesProductTab() throws InterruptedException, IOException{
		String checker_Values2 = com.getElementProperties("Checker","Checker_CheckboxforCheckerProducttab");
		selectcheckboxes(checker_Values2); 
	} 

	@Given("Checker: Selecting Checker values in Application tab")
	public void selectingCheckerValuesInApplicationTab() throws IOException, InterruptedException{ 
		String checker_Values3 = com.getElementProperties("Checker", "Checker_CheckboxforCheckerApplicationtab");
		selectcheckboxes(checker_Values3); 
	} 


	@Given("Checker: Select Checker checkboxes in the Checker screen for Co-Applicant")
	public void coapp1checkervalueadd() throws InterruptedException, IOException{ 
		String checker_Values4 = com.getElementProperties("Checker","Checker_CoappforCheckerCustomertab");
		selectcheckboxes(checker_Values4); 
	} 

	@Given("Checker: Select Checker checkboxes in the Checker screen for second Co-Applicant")
	public void coapp2checkervalueadd() throws InterruptedException, IOException{  
		String checker_Values5 = com.getElementProperties("Checker","Checker_Coapp2forCheckerCustomertab");
		selectcheckboxes(checker_Values5); 
	} 


	@Then("Checker: Read LOV value under Checker section for Customer tab")
	public void validateCheckerfieldUsingCSVCustomerTab() throws IOException
	{
		String Title = com.getElementProperties("Checker", "Checker_Titl_DropDown_XPATH");
		String ClientType = com.getElementProperties("Checker", "Checker_ClientType_DropDown_XPATH");
		String ISD = com.getElementProperties("Checker", "Checker_ISDCode_XPATH");
		String AreaCode = com.getElementProperties("Checker", "Checker_Areacode_XPATH");
		String Nameofthedocument = com.getElementProperties("Checker", "Checker_NodDoc_XPATH");


		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			csvread.Read_values_from_CSV("Title",Title,"BDC_CheckerLOVvalues.csv");
			js.executeScript("javascript:window.scrollBy(50,80)");
			csvread.Read_values_from_CSV("ISDCode",ISD,"BDC_CheckerLOVvalues.csv");
			//                 scrolltoele(AreaCode);
			js.executeScript("javascript:window.scrollBy(100,120)");
			//               csvread.Read_values_from_CSV("Area Code",AreaCode,"BDC_CheckerLOVvalues.csv");
			//               scrolltoele(ISD);
			csvread.Read_valueattribute("NameofDocument",Nameofthedocument,"BDC_CheckerLOVvalues.csv");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Then("Checker: Read LOV value under Checker section for Product tab")
	public void validateCheckerFieldUsingCSVProductsTab() throws IOException
	{

		String PurposeaccountopeningRequired = com.getElementProperties("Checker", "Checker_Purposeofacct_XPATH");
		String AccountRequestType = com.getElementProperties("Checker", "Checker_AcctReqType_XPATH");
		String AccountCurrency = com.getElementProperties("Checker", "Checker_AcctCur_XPATH");
		String ServiceType = com.getElementProperties("Checker", "Checker_Servicetype_XPATH");
		String RelatedParty = com.getElementProperties("Checker", "Checker_Relatedparty_XPATH");


		try {

			csvread.Read_values_from_CSV("PurposeofAccountopening",PurposeaccountopeningRequired,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("AccountRequestType",AccountRequestType,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("Currency",AccountCurrency,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("ServiceType",ServiceType,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("RelatedParty",RelatedParty,"BDC_CheckerLOVvalues.csv");


		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("Checker: Read LOV value under Checker section for Application tab")
	public void validateCheckerFieldusingCSVApplicationTab() throws IOException
	{
		String AcquisitionChannel = com.getElementProperties("Checker", "Checker_AcqChannel_XPATH");
		String FasttrackFlag = com.getElementProperties("Checker", "Checker_Fasttrackflag_XPATH");
		String ApplicationBranch = com.getElementProperties("Checker", "Checker_AppBnch_XPATH");


		try {

			// csvread.Read_values_from_CSV("AcquisitionChannel",AcquisitionChannel,"BDC_CheckerLOVvalues.csv");
			//  csvread.Read_values_from_CSV("Fast track Flag",FasttrackFlag,"BDC_CheckerLOVvalues.csv");
			csvread.Read_values_from_CSV("ApplicationBranch",ApplicationBranch,"BDC_CheckerLOVvalues.csv");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void scrolltoele(String ele)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(50,150)"); 
		//	js.executeScript("arguments[0].scrollIntoView(true);",ele);
	}



	@Then("^Checker: Verify Checker data is same as basic/blind data '(.+)' and '(.+)'$")
	public void verifyCheckerSection(String FieldName,String datatype) throws Throwable{

		JavascriptExecutor js3 = ((JavascriptExecutor) driver);
		js3.executeScript("window.scrollBy(0,-15000)", "");

		JavascriptExecutor js = ((JavascriptExecutor) driver);
		CommonUtilsData.FieldNameData = FieldName; 
		String[] Fieldval = CsvReaderutil.Validate_field_using_CSV(FieldName,"BDC_CheckerFieldVal.csv");

		try{
			logger.info("Entered try block");
			int i =7;
			switch (datatype){

			case "Dropdown":

				if(!(Fieldval[0]).equalsIgnoreCase(null)){
					logger.info("Going to get data from dropdown");
					wrap.click(driver, com.getElementProperties("Checker", Fieldval[11]));
					wrap.wait(2000);
					wrap.SelectedValueDropDown(driver, com.getElementProperties("Checker", Fieldval[2]));
					wrap.wait(2000);
					js.executeScript("javascript:window.scrollBy("+i+","+jscrol+")");
					jscrol+=i; 
					if(jscrol>120){i=3;}
				}
				break;

			case "TextInput":

				if(!(Fieldval[0]).equalsIgnoreCase(null)){
					logger.info("Going to get data from Text field");
					wrap.click(driver, com.getElementProperties("Checker", Fieldval[11]));
					wrap.wait(2000);
					String fieldvalue1 = wrap.getElement(driver, com.getElementProperties("Checker", Fieldval[2])).getAttribute("value");
					logger.info("The field value under Textfield is " + fieldvalue1);
					wrap.wait(2000);
					js.executeScript("javascript:window.scrollBy("+i+","+jscrol+")");
					jscrol+=i; 
					if(jscrol>120){i=3;}
				}
				break;

			}

			js.executeScript("javascript:window.scrollBy("+i+","+jscrol+")");
			jscrol+=i; 
			if(jscrol>120){i=3;}


		}

		catch(Exception E){

			logger.info("Field : "+FieldName+" is not present in Datamodel");
		}     

	}	
	@Then("^Checker : Check All Product details$")
	public static void checkAllProductDetails1() throws IOException, InterruptedException {

		while (BDC_Multiple_Product <= Basicdatacapturechecker.noOfProductsInChecker()) {

			Basicdatacapturechecker.switchToNextProduct();



		}

	}

	@Then("^Checker : Check All Basic Product details$")
	public void checkAllBasicProductDetails() throws IOException, InterruptedException {

		while (BDC_Multiple_Product <= Basicdatacapturechecker.noOfProductsInChecker()) {
			Boolean basiccheck = false;
			Basicdatacapturechecker.switchToNextProduct();

			String Basicproducts = Wrapper.getTextValue(BaseProject.driver,MultipleProducts_xpath );
			if(!Basicproducts.contains("Blind"))
			{

				logger.info("Basic");
				//   			 wrap.click(BaseProject.driver, com.getElementProperties("Basicdatacapturechecker", "MultipleProducts_xpath"));
				wrap.click(BaseProject.driver, MultipleProducts_xpath);

				if(BDC_Multiple_Product==1)
				{
					logger.info(BDC_Multiple_Product);
					String basicchecker_Values1 = com.getElementProperties("Checker", "Checker_CheckboxforBasicProducttab1");
					selectcheckboxes(basicchecker_Values1); 

				}
				else
					if(BDC_Multiple_Product==2)
					{
						String basicchecker_Values2 = com.getElementProperties("Checker", "Checker_CheckboxforBasicProducttab2");
						selectcheckboxes(basicchecker_Values2); 
						basiccheck=true;

					}

				if(basiccheck==true)
				{
					BDC_Multiple_Product=0;
					break;
				}
				logger.info(Basicproducts);



			}
			else{

				logger.info("No Basic Data Product");
			}
		}	


	}



	@Then("^Checker : Check All Blind Product details$")
	public void checkAllBlindProductDetails() throws IOException, InterruptedException {

		while (BDC_Multiple_Product <= Basicdatacapturechecker.noOfProductsInChecker()) {
			Boolean blindcheck = false;
			Basicdatacapturechecker.switchToNextProduct();

			String Blindproducts = Wrapper.getTextValue(BaseProject.driver,MultipleProducts_xpath );
			if(Blindproducts.contains("Blind"))
			{
				logger.info("Blind");
				//        			 wrap.click(BaseProject.driver, com.getElementProperties("Basicdatacapturechecker", "MultipleProducts_xpath"));
				wrap.click(BaseProject.driver, MultipleProducts_xpath);

				if(BDC_Multiple_Product==3)
				{
					String basicchecker_Values3 = com.getElementProperties("Checker", "Checker_CheckboxforBlindProducttab1");
					selectcheckboxes(basicchecker_Values3); 

				}
				else
					if(BDC_Multiple_Product==4)
					{
						String basicchecker_Values4 = com.getElementProperties("Checker", "Checker_CheckboxforBlindProducttab2");
						selectcheckboxes(basicchecker_Values4); 
						blindcheck=true;
					}


				if(blindcheck==true)
				{
					BDC_Multiple_Product=0;
					break;
				}
				logger.info(Blindproducts);



			}
			else{

				logger.info("No Blind Data Product");
			}
		}	

	}

	public static int noOfProductsInChecker() throws InterruptedException, IOException {

		List<WebElement> Total_Link = wrap.getExactAttributes(BaseProject.driver, com.getElementProperties("Checker", "Checker_PD_MultipleProduct_link"));

		logger.info(Total_Link.size());

		return Total_Link.size();


	}

	public static void switchToNextProduct() throws InterruptedException, IOException {

		wrap.switch_to_default_Content(BaseProject.driver);
		wrap.wait(1000);

		wrap.switch_to_Iframe(BaseProject.driver, "PegaGadget1Ifr");
		wrap.wait(2000);

		Basicdatacapturechecker.BDC_Multiple_Product++;

		MultipleProducts_xpath = "("+com.getElementProperties("Checker", "Checker_PD_MultipleProduct_link") + ")[" + Basicdatacapturechecker.BDC_Multiple_Product + "]"+"//td//nobr";

		logger.info(MultipleProducts_xpath);

		//    wrap.click(BaseProject.driver, MultipleProducts_xpath);


	}

}