package com.scb.rtob.module.test.framework;

import com.standardchartered.genie.GenieRuntime;
import com.standardchartered.genie.module.BaseGenieListener;

public class GenieUiModuleListener extends BaseGenieListener {

    private final GenieRuntime runtime;

    public GenieUiModuleListener(GenieRuntime runtime) {
        this.runtime = runtime;
    }

}
