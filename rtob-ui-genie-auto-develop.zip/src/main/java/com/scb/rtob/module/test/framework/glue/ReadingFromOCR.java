/*package com.scb.rtob.module.test.framework.glue;

import java.io.FileReader;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.scb.rtob.module.test.framework.glue.BaseProject;
import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.Commons;
import com.scb.rtob.module.test.framework.OCR;
import com.scb.rtob.module.test.framework.Wrapper;

import cucumber.api.java.en.When;


public class ReadingFromOCR {
	
	static Wrapper wrap = new Wrapper();
	static Commons com = new Commons();
	public static Logger logger = Logger.getLogger(ReadingFromOCR.class);
	public static JSONObject jsonReq;
		
	
	@When("^Basic: Read OCR Values For PanNo$")
	public void ReadingOCRValuesPan() throws Throwable {
		
		
		JSONParser parser = new JSONParser();
		FileReader reader = new FileReader("C:\\Users\\1567266\\Desktop\\id_docs\\Basic_SA.json");
		jsonReq = (JSONObject) parser.parse(reader);
		
		jsonReq = OCR.responseJSON;
		logger.info(jsonReq);
	
		
		
		String Doc_type= JsonPath.parse(jsonReq).read("$.DocumentType");
		String Doc_number= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[1].OCRValue");
		WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='T0227']"));
	    element.click();
	    String documentType= element.getText();
		WebElement e= BaseProject.driver.findElement(By.xpath("//span[text()='T0227']/following::input[@id='DocumentNumber']"));	
		e.click();
		String documentNumber= e.getAttribute("value");
		
		if(Doc_type.equals(documentType) && Doc_number.equals(documentNumber))
			logger.info("Pan No and Document Number Matched");
			
			else {
				logger.info("NO Match");
			}
			
	
		}

	
	@When("^Basic: Read OCR Values For PaySlip$")
		public void ReadingOCRValuesPayslip() throws Throwable {
			
			
//			JSONParser parser = new JSONParser();
//			FileReader reader = new FileReader("C:\\Users\\1567266\\Desktop\\id_docs\\Payslip.json");
//			jsonReq = (JSONObject) parser.parse(reader);
			
			jsonReq = OCR.responseJSON;
			logger.info(jsonReq);
			
			
			String Doc_type= JsonPath.parse(jsonReq).read("$.DocumentType");
			logger.info(Doc_type);
			String doc_custfullname=JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[0].OCRValue");
			logger.info(doc_custfullname);
			String doc_grosspay=JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[6].OCRValue");
			logger.info(doc_grosspay);
			String doc_netpay=JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[7].OCRValue");
			logger.info(doc_netpay);
			String doc_grosstotal=JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[8].OCRValue");
			logger.info(doc_grosstotal);
			String doc_basicmonthly=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[0].DocumentDataFields[0].OCRValue");
			logger.info(doc_basicmonthly);
			String doc_basicmonthlytotal=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[0].DocumentDataFields[8].OCRValue");
			logger.info(doc_basicmonthlytotal);
			String doc_allowancefield1=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[0].OCRValue");
			logger.info(doc_allowancefield1);
			String doc_allowancefield2=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[1].OCRValue");
			logger.info(doc_allowancefield2);
			String doc_allowancefield3=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[2].OCRValue");
			logger.info(doc_allowancefield3);
			String doc_allowancefield4=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[3].OCRValue");
			logger.info(doc_allowancefield4);
			String doc_allowancefield5=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[4].OCRValue");
			logger.info(doc_allowancefield5);
			String doc_allowancetotal=JsonPath.parse(jsonReq).read("$.DocumentData[1].DocDataFieldsGroup[1].DocumentDataFields[8].OCRValue");
			logger.info(doc_allowancetotal);
		
		   wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Payslips"));
		   logger.info(wrap.getElement(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Payslips")).getText());
		   String payslip = com.readText(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Payslips"));
		   logger.info(payslip);
		   String CustomerName =  BaseProject.driver.findElement(By.xpath("//span[text()='Payslip']/following::input[@id='CustomerFullNameOcr']")).getAttribute("value");
		   logger.info(CustomerName);
		   wrap.click(BaseProject.driver, com.getElementProperties("Fulldatacapturemaker", "FDC_IncomeDocs_Month1"));
		   String Month1GrossPay = BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[contains(@id,'GrossPay')]")).getAttribute("value");
		   logger.info(Month1GrossPay);
		   String Month1NetPay = BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[contains(@id,'NetPay')]")).getAttribute("value");
		   logger.info(Month1NetPay);
		   String Month1BasicSalF1 =  BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[@id='Field1BasicMonthlySalary']")).getAttribute("value");
		   logger.info(Month1BasicSalF1);
		   String Month1MonthlyBonusF1 =  BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[@id='Field1MonthlyBonus']")).getAttribute("value");
		   logger.info(Month1MonthlyBonusF1);
		   String Month1MonthlyAllowanceF1 =  BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[@id='Field1MonthlyAllowance']")).getAttribute("value");
		   logger.info(Month1MonthlyAllowanceF1);
		   String Month1MonthlyCommissionF1 =  BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[@id='Field1MonthlyCommission']")).getAttribute("value");
		   logger.info(Month1MonthlyCommissionF1);
		   String Month1MonthlyVariableBonusF1 =  BaseProject.driver.findElement(By.xpath("//div[@class='tabpanelnofocus' and contains(@style,'block') and contains(@id,'SubSectionPayslip')]//input[@id='Field1MonthlyVariableBonus']")).getAttribute("value");
		   logger.info(Month1MonthlyVariableBonusF1);
		 
	
		   if(doc_custfullname.equals(CustomerName) && doc_grosspay.equals(Month1GrossPay)  && doc_netpay.equals(Month1NetPay)) 
			   
			   
				logger.info("OCR to UI matches");
		   else 
				logger.info("No Match for OCR to UI");

	}

	@When("Basic: Read OCR values for Aadhar")
	public void ReadAadharOCRValues() throws Throwable{
		
		
//		JSONParser parser = new JSONParser();
//		
//		FileReader reader = new FileReader("C:\\Users\\1567977\\Desktop\\Aadhar.json");
//		jsonReq = (JSONObject) parser.parse(reader);
		

		
		jsonReq = OCR.responseJSON;
		logger.info(jsonReq);
		
		String Doc_type= JsonPath.parse(jsonReq).read("$.DocumentType");
		String Doc_num= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[3].OCRValue");
		logger.info("\n"+ Doc_type + "\n" + Doc_num);
		
		
		WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='T0002']"));
	    element.click();
	    String documentType= element.getText();
	    
	    WebElement e= BaseProject.driver.findElement(By.xpath("//span[text()='T0002']/following::input[@id='DocumentNumber']"));	
		e.click();
		String documentNumber= e.getAttribute("value");
	    
		logger.info("\n"+ documentType + "\n"+ documentNumber);
		
		if(Doc_type.equals(documentType) && Doc_num.equals(documentNumber))
			logger.info("Document details matched");
		
		else
			logger.info("Document details mismatch");
	}
	
	@When("Basic: Read OCR value for PASSPORT")
	public void ReadPassOCRValues() throws Throwable{
		
		
//		JSONParser parser = new JSONParser();
//		
//		FileReader reader = new FileReader("C:\\Users\\1567977\\Desktop\\T0231_Passport.json");
//		jsonReq = (JSONObject) parser.parse(reader);
		
		jsonReq = OCR.responseJSON;
		logger.info(jsonReq);
		
	
		String Doc_type= JsonPath.parse(jsonReq).read("$.DocumentType");
		String Date_expiry= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[2].OCRValue");
		String Doc_num = JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[3].OCRValue");
		logger.info("\n"+ Doc_type + "\n" + Date_expiry + "\n"+ Doc_num);
		
		WebElement element = BaseProject.driver.findElement(By.xpath("//span[text()='T0231']"));
	    element.click();
	    String documentType= element.getText();
		//logger.info(documentType);
	    
	    WebElement date= BaseProject.driver.findElement(By.xpath("//span[text()='T0231']/following::input[@id='DocumentExpiryDate1']"));	
		date.click();
		String docExpiry= date.getAttribute("value");
		
	    WebElement e= BaseProject.driver.findElement(By.xpath("//span[text()='T0231']/following::input[@id='DocumentNumber']"));	
		e.click();
		String documentNumber= e.getAttribute("value");
		
		
		logger.info( "\n"+ documentType + "\n"+ docExpiry +  "\n"+ documentNumber);
		
		if(Doc_type.equals(documentType) && Date_expiry.equals(docExpiry) && Doc_num.equals(documentNumber))
				logger.info("Document Details Matched");
		else
			logger.info("Document mismatch");
				
		
		
	}


@When("FDM: Read OCR values for Form16")
public void ReadOCRValuesForm16() throws Throwable {

//JSONParser parser = new JSONParser();
//
//FileReader reader = new FileReader("C:\\Users\\1567266\\Desktop\\id_docs\\Form.json");
//
//
//
//jsonReq = (JSONObject) parser.parse(reader);

jsonReq = OCR.responseJSON;
logger.info(jsonReq);
		

String doc_custfullname=JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[0].OCRValue");
String doc_date= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[5].OCRValue");
String name_organisation=  JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[2].OCRValue");		
String IncomeperTax= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[6].OCRValue");

logger.info(doc_custfullname + doc_date + name_organisation + IncomeperTax);



BaseProject.driver.findElement(By.xpath("//span[text()='FORM16']")).click();
logger.info("FORM16 DOCUMENT");
WebElement fn = BaseProject.driver.findElement(By.xpath("//span[text()='FORM16']/following::input[@id='CustomerFullNameOcr']"));
String FullName = fn.getAttribute("value");
logger.info(FullName);
WebElement dd=  BaseProject.driver.findElement(By.xpath("//span[text()='FORM16']/following::span[text()='Year1']/following::input[@id='DocumentDate1']"));
dd.click();
String documentDate= dd.getAttribute("value");
logger.info(documentDate);
WebElement inc= BaseProject.driver.findElement(By.xpath("//span[text()='FORM16']/following::input[@id='IncomeAsPerTax']"));
String Income= inc.getAttribute("value");
logger.info(Income);




if(doc_custfullname.equals(FullName) && doc_date.equals(documentDate)  && IncomeperTax.equals(Income)) 
	logger.info("Match");

else 
	logger.info("No Match");


}


@When("FDM: Read OCR values for CC statement")
public void ReadOCRCCValues() throws Throwable {
	 
//	 JSONParser parser = new JSONParser();
//		
//		FileReader reader = new FileReader("C:\\Users\\1567977\\Desktop\\T0069_Credit_Debit.json");
////		FileReader reader = new FileReader("C:\\apipro\\rtob-api-genie-auto\\src\\test\\resources\\jsontemplates\\BDC\\Basic_SA.json");
//		
//		
//		
//		jsonReq = (JSONObject) parser.parse(reader);
		
		jsonReq = OCR.responseJSON;
		logger.info(jsonReq);
				
		//String doc_type= JsonPath.parse(jsonReq).read("$.DocumentType");
		
		String Statement_Type= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[0].OCRValue");
		String Card_Limit= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[1].OCRValue");
		String Lastmonth_out= JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[5].OCRValue");
		String cust_fullname = JsonPath.parse(jsonReq).read("$.DocumentData[0].DocumentDataFields[6].OCRValue");
		logger.info("\n" + Statement_Type + "\n" + Card_Limit + "\n" + Lastmonth_out + "\n" + cust_fullname) ;
		
		BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']")).click();	
		logger.info("CC/DB STATEMENT");
		
		WebElement fn=  BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']/following::input[@id='CustomerFullNameOcr']"));
		fn.click();				
		String FullName = fn.getAttribute("value");
		
		WebElement sd1 =  BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']/following::input[@id='StatementDtFrom1']"));
		sd1.click();			
		String statementDate1= sd1.getAttribute("value");
		
		WebElement cl1 =  BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']/following::input[@id='CardLimit']"));
		cl1.click();
		String cardLimit1= cl1.getAttribute("value");
		
		WebElement out=  BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']/following::input[@id='LastMonthOutstanding']"));
		out.click();
		String lastMonthOutstanding1 = out.getAttribute("value");
       logger.info("/n" + FullName + "/n" + statementDate1 + "/n" + cardLimit1 + "/n" + lastMonthOutstanding1);
       
       if(cust_fullname.equals(FullName) && Statement_Type.equals(statementDate1) && Card_Limit.equals(cardLimit1) && Lastmonth_out.equals(lastMonthOutstanding1))
		logger.info("CC statement details matched");
       
       else
       	logger.info("Details not matched");
       
		///////////////////////////////////////////Month2/////////////////////////////////////////////
       
       String Statement_Type2= JsonPath.parse(jsonReq).read("$.DocumentData[1].DocumentDataFields[0].OCRValue");
		String Card_Limit2= JsonPath.parse(jsonReq).read("$.DocumentData[1].DocumentDataFields[1].OCRValue");
		String Lastmonth_out2= JsonPath.parse(jsonReq).read("$.DocumentData[1].DocumentDataFields[5].OCRValue");
		logger.info("\n" + Statement_Type2 + "\n" + Card_Limit2 + "\n" + Lastmonth_out2 ) ;
		
		BaseProject.driver.findElement(By.xpath("//span[text()='Month2']")).click();
		WebElement sd2 =  BaseProject.driver.findElement(By.xpath("//span[text()='CreditCard']/following::input[@id='StatementDtFrom2']"));
		sd2.click();
		String statementDate2= sd2.getAttribute("value");
		
		WebElement cl2 =  BaseProject.driver.findElement(By.xpath("//span[text()='Month2']/following::input[@id='CardLimit'][2]"));
		cl2.click();
		String cardLimit2= cl2.getAttribute("value");
		
		WebElement out2 =  BaseProject.driver.findElement(By.xpath("//span[text()='Month2']/following::input[@id='LastMonthOutstanding'][2]"));
		out2.click();
		String lastMonthOutstanding2= out2.getAttribute("value");
		
		logger.info("/n" + statementDate2 + "/n" + cardLimit2 + "/n" + lastMonthOutstanding2 );
		
		 
       if(Statement_Type.equals(statementDate2) && Card_Limit2.equals(cardLimit2) && Lastmonth_out2.equals(lastMonthOutstanding2))
		logger.info("CC statement details matched 2");
       
       else
       	logger.info("Details not matched 2"); 
	 
	 
}
}

*/