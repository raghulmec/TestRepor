package com.scb.rtob.module.test.framework.glue;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static org.junit.Assert.assertEquals;

public class JavaSample {
    private String who;
    private String greeting;

    @Given("^java module is installed$")
    public void java_module_is_installed() throws Throwable {

    }

    @When("^java module says (.*)$")
    public void greeting_is_called(String greeting) throws Throwable {
        this.who = "Java";
        this.greeting = greeting;
    }

    @Then("^the greeting to java should be '(.*)'$")
    public void the_greeting_should_be(String expectedGreeting) throws Throwable {
        assertEquals(expectedGreeting, greeting + " Java");
    }

    @Given("^what is your name\\? '(.+)'$")
    public void what_is_your_name(String name) throws Throwable {
        System.out.println("Hello " + name);
    }

}
