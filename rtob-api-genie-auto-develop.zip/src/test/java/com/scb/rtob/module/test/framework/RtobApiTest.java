package com.scb.rtob.module.test.framework;

import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;
import com.standardchartered.genie.junit.Genie;

@RunWith(Genie.class)
@CucumberOptions(
		glue = {"classpath:snippets"},
        features = {"classpath:features"},
		tags = {"@BatchRunExecutiontillFDCMaker"}
)
public class RtobApiTest 
{

}