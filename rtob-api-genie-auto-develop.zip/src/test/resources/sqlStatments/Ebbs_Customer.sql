

select 
T1.RELATIONSHIPNO,t8.masterno,MARITALST,SEX,SALUTATIONCODE,FIRSTNAME,LASTNAME,MIDDLENAME,FULLNAME,DATEOFBIRTH,BIRTHPLACE,T1.NATIONALITYCODE,T1.CONSTITUTIONCODE,T1.WORKTYPE,T1.QUALIFICATIONCODE,DOCTYPE,SIGNATORYDT,GREENCRD,USCITI,USRES,reason,comments,ADDTYPECODE,FLATNO,STREET,ADDRESS1,ADDRESS2,CITYCODE,STATE,POSTALCODE,ISMAILADDRESS,t5.countrycode,CONTACTTYPECODE,CONTACT,PRIMARYCONTACT,infocode,infovalue,primaryflag,t9.branchcode,t9.armcode,t9.shortname,t9.segmentcode,t9.isiccode 
from db2inst1.rel as t1 
inner join db2inst1.fatinfo as t2 on t1.relationshipno=t2.relationshipno 
inner join db2inst1.fatflginfo as t3 on t2.relationshipno=t3.relationshipno 
inner join db2inst1.oninfo as t4 on t3.relationshipno=t4.relationshipno and t4.countrycode='IN' 
inner join db2inst1.reladdr as t5 on t4.relationshipno=t5.relationshipno and t5.addtypecode='RES' 
inner join db2inst1.relcont as t6 on t5.relationshipno=t6.relationshipno 
inner join db2inst1.relinfo as t7 on t6.relationshipno=t7.relationshipno and t7.seqno='01' 
inner join db2inst1.mastrel as t8 on t7.relationshipno=t8.relationshipno and t7.relationshipno='<RELNO>' 
inner join db2inst1.mast as t9 on t8.masterno=t9.masterno