package com.scb.rtob.module.test.framework.glue;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class EBBSFieldDataValidation {
	
	public static Logger logger = Logger.getLogger(EBBSFieldDataValidation.class);
	
	private static HashMap<String, String> ebbsmapper = new HashMap<String, String>();
	
	
	@Given("^connect with RTOB and EBBS database for '(.+)' with RelNo '(.+)'$")
	public void connect_with_EBBS_database_dry_run(String type, String rel) throws Throwable {
		logger.info("Am into ebbs db dry run step def");
		DBUtils.convertDBtoMap("fulldatatablename"); //RTOB map
		DBUtils.convertEBBSDBtoMap(type,rel); //EBBS map
	}
	
	@Then("^compare both RTOB Vs EBBS field values$")
	public static void compare_both_RTOB_Vs_EBBS_field_values() throws Throwable {

		String result=null;
		int count =0, j=0;
		boolean flagFinal = true;
		boolean flag = false;
		int l = ebbsmapper.entrySet().size();
		
		HashMap<String,String> hme = new HashMap<String,String>();

        for (Entry<String, String> entry : ebbsmapper.entrySet()) {
        	count++;
        	logger.info("**************");
        	logger.info("Field : "+entry.getKey());
        	
        	try{
        		
        		logger.info("Test Data  : "+DBUtils.testdatamap.get(0).get(entry.getKey()));
        		logger.info("Ebbs value : "+DBUtils.eBBstestdatamap.get(0).get(entry.getValue()));
        		flag = DBUtils.testdatamap.get(0).get(entry.getKey()).toString()
  		         	  .equalsIgnoreCase(DBUtils.eBBstestdatamap.get(0).get(entry.getValue()).toString());
        		logger.info("Result : "+flag);      	
        		if(flag==false)
        		{
        			hme.put(entry.getKey(), "There is a data mismatch between RTOB field Vs EBBS field");
        			logger.info("There is a data mismatch between RTOB field Vs EBBS field");
        		}
        	}
        	
        	catch(NullPointerException NPE){
        		
        		if(DBUtils.eBBstestdatamap.get(0).containsKey(entry.getValue())){	
        			hme.put(entry.getKey(), "No data in EBBS respective field");
        			logger.info("Field values are NULL");
        		}
        		else
        		{
        			hme.put(entry.getKey(), "Field is not present in EBBS");
        			logger.info("Field is not present in EBBS");        		
        		}
        	}
        	
        	flagFinal = flagFinal && flag;
        }        	
        	
        	logger.info("**************"); 	
        	
        	logger.info("total coulum count: "+ count);
        	logger.info("Final flag status: "+ flagFinal);
        	
        	logger.info("Size of error map: "+hme.size());
        	logger.info("The list of error fields are given below:");
        	logger.info("----------------------------------------");
        	
        	for(Map.Entry<String,String> each:hme.entrySet())
        	{
        		logger.info("The error field "+each.getKey()+"          and its reason is : "+ each.getValue());
        	}       	
        	
        	Assert.assertTrue("There is a mismatch between RTOB Vs Ebbs field values", flagFinal);
        	
        	/*if(flagFinal)
        	{
        		logger.info("All the fields in RTOB & Ebbs are equivalent and verified successfully");
        	}
        	else
        	{
        		logger.info("There is a mismatch between RTOB Vs Ebbs field values");
        	}*/

        
	}
	
	@Then("^read EBBS mapper for customer$")
	public static void read_EBBS_mapper_for_customer() throws Throwable {
		ebbsmapper.clear();
		ebbsmapper.put("Nationality_Code1", "NATIONALITYCODE");
		ebbsmapper.put("Constitution_Code", "CONSTITUTIONCODE");
		ebbsmapper.put("Work_Type", "WORKTYPE");
		ebbsmapper.put("Gender", "SEX");
		ebbsmapper.put("FATCA_Is_Customer_a_Green_card_holder", "GREENCRD");
		ebbsmapper.put("Is_Customer_a_US_Citizen","USCITI");
		ebbsmapper.put("FATCA_Is_Customer_a_US_Resident","USRES");
		ebbsmapper.put("Address1_Address_Type","ADDTYPECODE");
		ebbsmapper.put("Marital_Status", "MARITALST");
		ebbsmapper.put("Title", "SALUTATIONCODE");
		ebbsmapper.put("First_Name", "FIRSTNAME");
		ebbsmapper.put("Middle_Name", "MIDDLENAME");
		ebbsmapper.put("Last_Name", "LASTNAME");
		ebbsmapper.put("Full_name", "FULLNAME");
		ebbsmapper.put("DOB", "DATEOFBIRTH");	  
		ebbsmapper.put("Country_Of_Birth_Code", "DOMICILECOUNTRY");
		ebbsmapper.put("Residence_Country_Code", "RESIDENTCOUNTRY");
		ebbsmapper.put("ARM_Code", "ARMCODE");	
		ebbsmapper.put("Nature_of_Business", "NATUREOFBUSINESS");	
		ebbsmapper.put("Place_of_Birth", "BIRTHPLACE");
		ebbsmapper.put("Educational_Qualification", "QUALIFICATIONCODE");
		ebbsmapper.put("Name_of_the_Document", "DOCTYPE");
		ebbsmapper.put("CRS_Reason_Code","REASON");
		ebbsmapper.put("CRS_Comments","COMMENTS");
		ebbsmapper.put("Address1_Address_Line_1","ADDRESS1");
		ebbsmapper.put("Address1_Address_Line_2","ADDRESS2");
		ebbsmapper.put("Address1_City","CITYCODE");
		ebbsmapper.put("Address1_State","STATE");
		ebbsmapper.put("Address1_Zip_Code","POSTALCODE");
		ebbsmapper.put("Address1_Mailing_Address_Indicator","ISMAILADDRESS");
		ebbsmapper.put("Address1_Country","countrycode");
		ebbsmapper.put("Contact_type_Code1","CONTACTTYPECODE");
		ebbsmapper.put("Contact_Details1","CONTACT");
		ebbsmapper.put("Preferred_Contact1","PRIMARYCONTACT");
		ebbsmapper.put("MIS_Code","infocode");
		ebbsmapper.put("MIS_Value","infovalue");
		ebbsmapper.put("Home_Branch","BRANCHCODE");
		ebbsmapper.put("ARM_Code","armcode");
		ebbsmapper.put("Account_Short_Name","shortname");
		ebbsmapper.put("ISIC_Code","isiccode");
	}

	
	@Then("^read EBBS mapper for Account$")
	public static void setEbbsMapper_Account() {
		ebbsmapper.clear();
        ebbsmapper.put("Relationship_type", "RELTYPECODE");
        ebbsmapper.put("Account_Currency_Code", "CURRENCYCODE");
        ebbsmapper.put("ProductCode", "PRODUCTCODE");
        ebbsmapper.put("Account_Short_Name", "ACCTITLE");
        ebbsmapper.put("Home_Branch", "ACCOUNTBRANCH");
        ebbsmapper.put("Consolidated_Flag", "CONSOLSTMT");
        ebbsmapper.put("Closing_ID", "DSRCLOSINGID");
        ebbsmapper.put("Referral_ID", "DSRREFERRALID");
        ebbsmapper.put("Sorucing_ID", "DSRSOURCINGID");
        ebbsmapper.put("Operating_Instruction", "OPERATINGINS");
        ebbsmapper.put("GST_Registration_Number", "GSTREGNNO");
        ebbsmapper.put("Specific_status", "GSTSPECIALSTATUS");
        ebbsmapper.put("Customer_Type", "GSTCUSTTYPE");
        ebbsmapper.put("Charges", "CHARGECODE");
        ebbsmapper.put("MIS_Code", "INFODETCODE");
        ebbsmapper.put("Roll_Over_Instruction", "CAPITALISEFLAG");
        ebbsmapper.put("Fund_Account_No", "FUNDSACCTNO");
        ebbsmapper.put("Fund_Account_Currency", "FUNDSCURRCD");
        ebbsmapper.put("Interest_Account_No", "INTACCTNO");
        ebbsmapper.put("Interest_Account_Currency", "INTCURRCD");
        ebbsmapper.put("Interest_Frequency", "INTPAYFREQ");
        ebbsmapper.put("Maturity_Date", "FINALMATURITYDT");
        ebbsmapper.put("Maturity_Account_Currency", "SWEEPCURRCD");
        ebbsmapper.put("Maturity_Account_No", "SWEEPACCTNO");
        ebbsmapper.put("Roll_Over_Choice", "ROLLOVERFLAG");
        ebbsmapper.put("Deposit_Type", "ROLLOVERMMKDEALTYPE");
        ebbsmapper.put("Tenure_Type", "TERMTYPE");
        ebbsmapper.put("Term", "TERMVAL");
        ebbsmapper.put("Twoinone_Account_No", "TWOINONEACCOUNT");
        ebbsmapper.put("Twoinone_Currency", "TWOINONECURRENCY");
        ebbsmapper.put("Type_of_Twoinone", "TWOINONEFLAG");
        ebbsmapper.put("Base_Rate", "BASERATE");
        ebbsmapper.put("Margin_Interest_Rate", "CUSTOMERMARGIN");
        ebbsmapper.put("MIS_Value", "INFORMATIONCODE");
 }

	public static String retrieveFromMapper(String columnName){
						return ebbsmapper.get(columnName);
			}


}
