package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class InternalVerificationSetValue {
	
	public static Logger logger = Logger.getLogger(InternalVerificationSetValue.class);
	private static JSONObject json = InternalVerificationRequestGen.jsonReq;
	
	static String fullName = null;
	static String employerName = null;
	static String contactType = null;
	static String contactDetails = null;
	static String isdCode = null;
	static String areaCode = null;
	
	static String fullNameCoapp = null;
	static String employerNameCoapp = null;
	static String contactTypeCoapp = null;
	static String contactDetailsCoapp = null;
	static String isdCodeCoapp = null;
	static String areaCodeCoapp = null;
	
	
	public static void main(String[] args) 
	{

	}
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void setPrimaryData(){
		
		fullName = DBUtils.readColumnWithRowID("IV Full Name", GetCase.scenarioID);
		employerName = DBUtils.readColumnWithRowID("IV Employer Name", GetCase.scenarioID);
		contactType= DBUtils.readColumnWithRowID("IV Contact Type", GetCase.scenarioID);
		contactDetails= DBUtils.readColumnWithRowID("IV Contact Details", GetCase.scenarioID);
		isdCode= DBUtils.readColumnWithRowID("IV ISD Code", GetCase.scenarioID);
		areaCode= DBUtils.readColumnWithRowID("IV Area Code", GetCase.scenarioID);
		
		
		if(fullName!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",fullName);}
		else{logger.info("Database contains null value IV Full Name");}
		
		if(employerName!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",employerName);}
		else{logger.info("Database contains null value Employer Name");}
		
		if(contactType!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",contactType);}
		else{logger.info("Database contains null value Contact Type");}
		
		if(contactDetails!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",contactDetails);}
		else{logger.info("Database contains null value Contact Details");}
		
		if(isdCode!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",isdCode);}
		else{logger.info("Database contains null value ISD Code");}
		
		if(areaCode!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",areaCode);}
		else{logger.info("Database contains null value Area Code");}
		
	}
	
		public static void setCoapplicantData(int coapplicantsequence){
		
		fullNameCoapp = DBUtils.readColumnWithRowID("IV Full Name Coapp"+coapplicantsequence, GetCase.scenarioID);
		employerNameCoapp = DBUtils.readColumnWithRowID("IV Employer Name Coapp"+coapplicantsequence, GetCase.scenarioID);
		contactTypeCoapp = DBUtils.readColumnWithRowID("IV Contact Type Coapp"+coapplicantsequence, GetCase.scenarioID);
		contactDetailsCoapp = DBUtils.readColumnWithRowID("IV Contact Details Coapp"+coapplicantsequence, GetCase.scenarioID);
		isdCodeCoapp = DBUtils.readColumnWithRowID("IV ISD Code Coapp"+coapplicantsequence, GetCase.scenarioID);
		areaCodeCoapp = DBUtils.readColumnWithRowID("IV Area Code Coapp"+coapplicantsequence, GetCase.scenarioID);
		
		
		if(fullNameCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",fullNameCoapp);}
		else{logger.info("Database contains null value IV Full Name Coapp"+coapplicantsequence);}
		
		if(employerNameCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",employerNameCoapp);}
		else{logger.info("Database contains null value Employer Name Coapp"+coapplicantsequence);}
		
		if(contactTypeCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",contactTypeCoapp);}
		else{logger.info("Database contains null value Contact Type Coapp"+coapplicantsequence);}
		
		if(contactDetailsCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",contactDetailsCoapp);}
		else{logger.info("Database contains null value Contact Details Coapp"+coapplicantsequence);}
		
		if(isdCodeCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",isdCodeCoapp);}
		else{logger.info("Database contains null value ISD Code Coapp"+coapplicantsequence);}
		
		if(areaCodeCoapp!=null)
		{JsonPath.parse(json).set("$.content.CustFullName",areaCodeCoapp);}
		else{logger.info("Database contains null value Area Code Coapp"+coapplicantsequence);}
		
	}

	
	
		
}
