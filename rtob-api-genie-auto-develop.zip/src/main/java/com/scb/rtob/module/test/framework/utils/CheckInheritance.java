package com.scb.rtob.module.test.framework.utils;
import java.util.Scanner;


class CheckInheritance {

public void printValue(){

Scanner sc = new Scanner(System.in);

System.out.println("Enter the number:");

int a =sc.nextInt();

}

}

