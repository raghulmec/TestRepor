package com.scb.rtob.module.test.framework.utils;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class FullDataSetValue {
	
	public static Logger logger = Logger.getLogger(FullDataSetValue.class);
	
	private static JSONObject json = FDMRequestGen.jsonReq;
	
	static String FullName = null;
	static String coApplicantFullName = null;
	static String ShortName = null;
	
	public static void main(String[] args)  throws ClassNotFoundException, SQLException, IOException{
	
	}
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void setContent(){
		
			}
	
	public static void setBasicDataCaptureFields_CustomerTab() throws ClassNotFoundException, SQLException, IOException{
	
		DBUtils.convertDBtoMap("bdquery");
		
		
		//Customer Tab
		
		FullName = DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.CustFullName",FullName);
		
		ShortName = DBUtils.readColumnWithRowID("Title", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);

		
		JsonPath.parse(json).set("$.content.Customers[0].Title",DBUtils.readColumnWithRowID("Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DateOfBirth",DBUtils.readColumnWithRowID("DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].EmbossedName", FullName);
		JsonPath.parse(json).set("$.content.Customers[0].FirstName",DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].LastName",DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].MiddleName",DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Country Of Birth Description", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirth",DBUtils.readColumnWithRowID("Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidence",DBUtils.readColumnWithRowID("Residence Country Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].DomicileCountryCode",DBUtils.readColumnWithRowID("Country Of Birth Code", GetCase.scenarioID));
		
		setMultipleCustomerContactDetails();
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Industry",DBUtils.readColumnWithRowID("ISIC Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryDescription",DBUtils.readColumnWithRowID("ISIC Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Occupation Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Occupation Description", GetCase.scenarioID));
	
//		setDocumentDetails();
		
		
	
		Eops();
		
		
		
		
	}
	public static void setCustomerAliasType(){
		
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Alias(es)", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("AliasMiddleName", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant1 Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant1 Aliases", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant1 Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Middle Name", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant2 Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant2 Aliases", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant2 Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Middle Name", GetCase.scenarioID));
		
	}
	
	public static void setBasicDataCaptureFields_ProductandApplicationTab() throws ClassNotFoundException, SQLException, IOException{
	
		setApplicantProductRelationship();
		
		JsonPath.parse(json).set("$.content.SrcID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourceID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SalesID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ReferralID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.AcquisitionCode",DBUtils.readColumnWithRowID("Acquisition Channel", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ApplicationBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchCode",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID));
		
	}
	
	
	public static void setCustomerDetails() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("fdquery");
		
		JsonPath.parse(json).set("$.content.Customers[0].Gender",DBUtils.readColumnWithRowID("Gender", GetCase.scenarioID));
		
		
		
	//	JsonPath.parse(json).set("$.content.Customers[0].ConstitutionCode",DBUtils.readColumnWithRowID("Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].InitialFundSrc",DBUtils.readColumnWithRowID("Source(s) of Initial Funding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MaritalStatus",DBUtils.readColumnWithRowID("Marital Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].PlaceOfBirth",DBUtils.readColumnWithRowID("Place of Birth", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Qualification",DBUtils.readColumnWithRowID("Educational Qualification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MarketingPreferences",DBUtils.readColumnWithRowID("Marketing Preferences", GetCase.scenarioID));
		
		//JsonPath.parse(json).set("$.content.Customers[0].RelationWithBank",DBUtils.readColumnWithRowID("Educational Qualification", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].TypeOfInitialFund",DBUtils.readColumnWithRowID("TypeOfInitialFunding", GetCase.scenarioID));
	
		
	
		
		JsonPath.parse(json).set("$.content.Customers[0].ConstitutionCode",DBUtils.readColumnWithRowID("Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NumberOfDependants",DBUtils.readColumnWithRowID("No. of Dependants", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ResidenceStatus",DBUtils.readColumnWithRowID("Residential Status", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].GSTCustomerType",DBUtils.readColumnWithRowID("Customer Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].GSTRegistrationNumber",DBUtils.readColumnWithRowID("GST Registration Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpecificStatus",DBUtils.readColumnWithRowID("Specific status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].AdviceDetailsAddressType",DBUtils.readColumnWithRowID("Advice Detail Address Type", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].InternetBanking",DBUtils.readColumnWithRowID("Online Banking", GetCase.scenarioID));
		
		
		//***************************Vijay02082018***************************//
		
	
		//JsonPath.parse(json).set("$.content.Customers[0].EmbossedName",DBUtils.readColumnWithRowID("Embossed debit card name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MobileBanking",DBUtils.readColumnWithRowID("Mobile Banking", GetCase.scenarioID));
		//CC
		JsonPath.parse(json).set("$.content.Customers[0].NumberOfDependants",DBUtils.readColumnWithRowID("No. of Dependants", GetCase.scenarioID));
		
		//***************************Ends**********************************//
		

	
	}
	
	public static void FamilyDetails(){
		
		
		JsonPath.parse(json).set("$.content.Customers[0].MaidenFirstName",DBUtils.readColumnWithRowID("MaidenFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherFirstName",DBUtils.readColumnWithRowID("FatherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherLastName",DBUtils.readColumnWithRowID("FatherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherMiddleName",DBUtils.readColumnWithRowID("FatherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherPrefix",DBUtils.readColumnWithRowID("FatherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherFirstName",DBUtils.readColumnWithRowID("MotherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherLastName",DBUtils.readColumnWithRowID("MotherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherMaidenName",DBUtils.readColumnWithRowID("MotherMaidenName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherMiddleName",DBUtils.readColumnWithRowID("MotherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherPrefix",DBUtils.readColumnWithRowID("MotherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseFirstName",DBUtils.readColumnWithRowID("SpouseFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseLastName",DBUtils.readColumnWithRowID("SpouseLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseMiddleName",DBUtils.readColumnWithRowID("SpouseMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpousePrefix",DBUtils.readColumnWithRowID("SpousePrefix", GetCase.scenarioID));
		
		
		//***************************Vijay02082018***************************//
		
		/*JsonPath.parse(json).set("$.content.Customers[0].NumberOfChildren",DBUtils.readColumnWithRowID("Number of children", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].AgeOfChild",DBUtils.readColumnWithRowID("Age of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].GenderOfChild",DBUtils.readColumnWithRowID("Gender of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].NameOfChild",DBUtils.readColumnWithRowID("Name of the Child", GetCase.scenarioID));*/
		
		//******************************************************************//
		
		
	}
	
	public static void setMultipleCustomerContactDetails(){
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));
		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Contact type Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Contact Details1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
	
	}
	

	public static void setCustomerContactsDetails(){
		JsonPath.parse(json).set("$.content.Customers[0].CustomerContacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CustomerContacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
	}
	
	public static void setApplicantProductRelationship(){
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
	}
	
	public static void setEmployeementDetails(){
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmployerRelationshipName",DBUtils.readColumnWithRowID("Employer Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmploymentType",DBUtils.readColumnWithRowID("Work Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmpReltnID",DBUtils.readColumnWithRowID("Employee ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.StaffCategory",DBUtils.readColumnWithRowID("Staff Category", GetCase.scenarioID));
	
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IsPayrollCust",DBUtils.readColumnWithRowID("Payroll Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NatureOfBusiness",DBUtils.readColumnWithRowID("Nature of Business", GetCase.scenarioID));
	
		
		//***************************Vijay02082018***************************//
		
		//cc
		JsonPath.parse(json).set("$.content.Customers[0].Employment.AnnualDeclaredIncome",DBUtils.readColumnWithRowID("AnnualDeclaredIncome", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.BusinessEstablishmentDate",DBUtils.readColumnWithRowID("Business Establishment Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Company_Type",DBUtils.readColumnWithRowID("Company Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CompanyName",DBUtils.readColumnWithRowID("Company Name", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].Employment.CompanyType",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CurrentOrgMM",DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CurrentOrgYY",DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Department",DBUtils.readColumnWithRowID("Department", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Designation",DBUtils.readColumnWithRowID("Designation", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IncorporationCountry",DBUtils.readColumnWithRowID("Incorporation Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IncorporationDate",DBUtils.readColumnWithRowID("Incorporation Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryGroup",DBUtils.readColumnWithRowID("Industry Group Sector", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ModeOfSalary",DBUtils.readColumnWithRowID("Salary Mode", GetCase.scenarioID));
		
		int a = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID))*12;
		int b = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID))*12;
		
		int c = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID)));
		int d = Integer.parseInt(DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID)));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NoOfMonthsInCurrentBusinessOrganization",a);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NoOfMonthsInPreviousBusinessOrganization",b);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.OwnershipType",DBUtils.readColumnWithRowID("Describe Applicant/Ownership Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousEmployerName",DBUtils.readColumnWithRowID("Previous employer name ", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousOrgMM",DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousOrgYY",DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.SharePercentage",DBUtils.readColumnWithRowID("% of Share holding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TaxResidencyStatus",DBUtils.readColumnWithRowID("Tax Residency status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TotalExpMM",c);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TotalExpYY",d);
		

		
		
	
		
	}
	
	public static void setDocumentDetails(){		
		
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[4].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[7].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[15].DocumentSignatureDate", DBUtils.readColumnWithRowID("Document Signature Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[15].DocumentSignatureDate1", DBUtils.readColumnWithRowID("Document Signature Date1", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number1", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date1", GetCase.scenarioID));
		
		
	}
	
	
	public static void setApplicationDetailsTab(){
		
	
				
		JsonPath.parse(json).set("$.content.ApplicationInfo.ShortName",ShortName);
	
		//**************************************Vijay-02082018**********************************\
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.ApplicationInfo.DebitCardRequired",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
	}
	
	public static void setProductDetailsTab(){
		
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AccountShortNm",ShortName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeAmount",DBUtils.readColumnWithRowID("Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeDate",DBUtils.readColumnWithRowID("Cheque Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeDrawnOn",DBUtils.readColumnWithRowID("Cheque Drawn On", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeNumber",DBUtils.readColumnWithRowID("Cheque Number", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice", GetCase.scenarioID));

		//*****************************************Vijay-02082018***********************
		//TD
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeSuspenseAccount",DBUtils.readColumnWithRowID("Cheque suspense Account", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TenureType",DBUtils.readColumnWithRowID("Tenure Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TermPeriod",DBUtils.readColumnWithRowID("TD_Term", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
	//  JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountCurrency",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MinimumClearingBalance",DBUtils.readColumnWithRowID("Minimum Clearing Balance", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Lien",DBUtils.readColumnWithRowID("Lien", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ValueDate",DBUtils.readColumnWithRowID("Value Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOne",DBUtils.readColumnWithRowID("2-in-1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("2-in-1 Currency", GetCase.scenarioID));		
		//CASA
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("AcquisitionUsage", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignUsage",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeBookRequired",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EmployeeBanking",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].InterestFrqcy",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].StatementTypeCASA",DBUtils.readColumnWithRowID("Statement Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
		//CC PL
		//PL
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AdvanceEMI",DBUtils.readColumnWithRowID("Advance EMI", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AmountForDisbursement",DBUtils.readColumnWithRowID("Amount for Disbursement", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApprovedEffectiveRate",DBUtils.readColumnWithRowID("ApprovedEffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AssessmentType",DBUtils.readColumnWithRowID("Assessment Type", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementIFSC",DBUtils.readColumnWithRowID("DisbursementIFSC", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EffectiveRate",DBUtils.readColumnWithRowID("EffectiveRate", GetCase.scenarioID));
//		// JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EmployeeBanking",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCTotalChequeNo",DBUtils.readColumnWithRowID("PDC-Total cheque No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCTotalChequeValueCurrency",DBUtils.readColumnWithRowID("PDC-Total Cheque Value Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedAmount",DBUtils.readColumnWithRowID("RequestedAmount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedEffectiveRate",DBUtils.readColumnWithRowID("RequestedEffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedTenor",DBUtils.readColumnWithRowID("Requested Tenure", GetCase.scenarioID));
//		// JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));	
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BenificiaryBank",DBUtils.readColumnWithRowID("Beneficiary's Bank", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name", GetCase.scenarioID));
		//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementIFSC",DBUtils.readColumnWithRowID("IFSC_code_Disbursement", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DrawDownDate",DBUtils.readColumnWithRowID("Drawdown Date", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode", GetCase.scenarioID));
		//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EffectiveRate",DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].IFSCCode",DBUtils.readColumnWithRowID("IFSC code", GetCase.scenarioID));		
		//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedName",DBUtils.readColumnWithRowID("Embossed debit card name", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BillingCycle",DBUtils.readColumnWithRowID("Billing_Cycle", GetCase.scenarioID));
			//CC
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddrType",DBUtils.readColumnWithRowID("Address1_Residence type", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Lez_Code",DBUtils.readColumnWithRowID("Lez Code", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedName",DBUtils.readColumnWithRowID("CC Emboss Name", GetCase.scenarioID));
			
	}
	
	public static void setSecondaryProductDetailsTab(int productsequence){
		
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AccountShortNm",ShortName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeAmount",DBUtils.readColumnWithRowID("Amount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeDate",DBUtils.readColumnWithRowID("Cheque Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeDrawnOn",DBUtils.readColumnWithRowID("Cheque Drawn On"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeNumber",DBUtils.readColumnWithRowID("Cheque Number"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeSuspenseAccount",DBUtils.readColumnWithRowID("Cheque suspense Account"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TenureType",DBUtils.readColumnWithRowID("Tenure Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TermPeriod",DBUtils.readColumnWithRowID("TD_Term"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RefAccountCurrency",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		//  JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountCurrency",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].MinimumClearingBalance",DBUtils.readColumnWithRowID("Minimum Clearing Balance"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lien",DBUtils.readColumnWithRowID("Lien"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ValueDate",DBUtils.readColumnWithRowID("Value Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOne",DBUtils.readColumnWithRowID("2-in-1"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOneCurrency",DBUtils.readColumnWithRowID("2-in-1 Currency"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("AcquisitionUsage"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CampaignUsage",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeBookRequired",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EmployeeBanking",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].InterestFrqcy",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductBranch",DBUtils.readColumnWithRowID("Application Branch"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].StatementTypeCASA",DBUtils.readColumnWithRowID("Statement Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AdvanceEMI",DBUtils.readColumnWithRowID("Advance EMI"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AmountForDisbursement",DBUtils.readColumnWithRowID("Amount for Disbursement"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApprovedEffectiveRate",DBUtils.readColumnWithRowID("ApprovedEffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AssessmentType",DBUtils.readColumnWithRowID("Assessment Type"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementIFSC",DBUtils.readColumnWithRowID("DisbursementIFSC"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EffectiveRate",DBUtils.readColumnWithRowID("EffectiveRate"+productsequence, GetCase.scenarioID));
		// JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EmployeeBanking",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCTotalChequeNo",DBUtils.readColumnWithRowID("PDC-Total cheque No"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCTotalChequeValueCurrency",DBUtils.readColumnWithRowID("PDC-Total Cheque Value Currency"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedAmount",DBUtils.readColumnWithRowID("RequestedAmount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedEffectiveRate",DBUtils.readColumnWithRowID("RequestedEffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedTenor",DBUtils.readColumnWithRowID("Requested Tenure"+productsequence, GetCase.scenarioID));
		// JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BenificiaryBank",DBUtils.readColumnWithRowID("Beneficiary's Bank"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementIFSC",DBUtils.readColumnWithRowID("IFSC_code_Disbursement"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DrawDownDate",DBUtils.readColumnWithRowID("Drawdown Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EffectiveRate",DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].IFSCCode",DBUtils.readColumnWithRowID("IFSC code"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CCEmbossedName",DBUtils.readColumnWithRowID("Embossed debit card name"+productsequence, GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BillingCycle",DBUtils.readColumnWithRowID("Billing_Cycle"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddrType",DBUtils.readColumnWithRowID("Address1_Residence type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lez_Code",DBUtils.readColumnWithRowID("Lez Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CCEmbossedName",DBUtils.readColumnWithRowID("CC Emboss Name"+productsequence, GetCase.scenarioID));

		}
	
	
	public static void setProductMISPAge(){
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MISPage[0].MISCode",DBUtils.readColumnWithRowID("MIS Code (Prd)", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MISPage[0].MISValue",DBUtils.readColumnWithRowID("MIS Value (Prd)", GetCase.scenarioID));
	}
	
	





	public static void setAddress(){
		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine1",DBUtils.readColumnWithRowID("Address Line 1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine2",DBUtils.readColumnWithRowID("Address Line 2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine3",DBUtils.readColumnWithRowID("Address Line 3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].CityName",DBUtils.readColumnWithRowID("City", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Country",DBUtils.readColumnWithRowID("Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].PostalCode",DBUtils.readColumnWithRowID("Zip Code", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Address1_Mailing Address Indicator", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Address1_Permanent Address same as Residential Address", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Type",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
	
	
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Address1_Mailing Address Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Address1_Permanent Address same as Residential Address", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthInYY",DBUtils.readColumnWithRowID("Address1_Length at Current Address", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthInMM",DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_MM", GetCase.scenarioID));
		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Residence_Type",DBUtils.readColumnWithRowID("Address1_Residence type", GetCase.scenarioID));
		
		//**********************************Vijay-02082018*******************************************
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine4",DBUtils.readColumnWithRowID("AddressLine4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Country",DBUtils.readColumnWithRowID("Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Type",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Area",DBUtils.readColumnWithRowID("Area", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthAtCurrentAddressInMonths",DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_MM", GetCase.scenarioID));
		//*******************************************************************************************

		
	}
	
	public static void setBankuse(){
		
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Closing ID", GetCase.scenarioID));
	}
	
	public static void setFatcaInfoDetails(){
		
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSCitizen",DBUtils.readColumnWithRowID("Is Customer a US Citizen?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSGreenCardHolder",DBUtils.readColumnWithRowID("FATCA - Is Customer a US Resident?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSResident",DBUtils.readColumnWithRowID("FATCA - Is Customer a Green card holder?", GetCase.scenarioID));
		
	
	}
	

	public static void Eops(){
	
		//***************************Vijay02082018***************************//
		JsonPath.parse(json).set("$.content.Customers[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FullName",DBUtils.readColumnWithRowID(FullName, GetCase.scenarioID));
		
		
		
	}
	
	public static void moreFinancialSection(){
		
		//***************************Vijay02082018***************************//
		
		
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Account Number/App Ref No.", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AccountType",DBUtils.readColumnWithRowID("Account Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].ActualMonthlyCommitment",DBUtils.readColumnWithRowID("Actual Monthly Commitment", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].ApplicantType",DBUtils.readColumnWithRowID("Applicant Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AppliedAmountCurrency",DBUtils.readColumnWithRowID("Applied Amount Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].CommitmentCurrency",DBUtils.readColumnWithRowID("Commitment Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OriginalApprovedLimit",DBUtils.readColumnWithRowID("Original approved limit", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OriginalApprovedLimitCurrency",DBUtils.readColumnWithRowID("Original approved limit currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OtherCardRepaymentRatio",DBUtils.readColumnWithRowID("other Card Repayment Ratio", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OustandingAmountCurrency",DBUtils.readColumnWithRowID("Oustanding amount currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OutstandingAmount",DBUtils.readColumnWithRowID("Outstanding amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].Source",DBUtils.readColumnWithRowID("Source", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].Status",DBUtils.readColumnWithRowID("Status", GetCase.scenarioID));

	
	
	}
	
	public static void setInfoCodeDetails(){
		JsonPath.parse(json).set("$.content.Customers[0].InfoCode[0].Code",DBUtils.readColumnWithRowID("MIS Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].InfoCode[0].Value",DBUtils.readColumnWithRowID("MIS Value", GetCase.scenarioID));	
	}
	
	
	public static void setCoapplicantBasicDataCaptureFields_CustomerTab(int coapplicantsequence) throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		
		coApplicantFullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",coApplicantFullName);

		//Customer Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Title",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DateOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].First_Name",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LastName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MiddleName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidence",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
		


		//Contact Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISD Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details1", GetCase.scenarioID));


				
				//Employment Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Industry",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Description", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Description", GetCase.scenarioID));
				
				
						//Document Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[4].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[7].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].IDDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].VerfDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));


				
						//Eops Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",DBUtils.readColumnWithRowID(FullName, GetCase.scenarioID));

	}
	
	public static void setCoapplicantDetails(int coapplicantsequence){
		
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Gender",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Gender", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ConstitutionCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InitialFundSrc",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Source(s) of Initial Funding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MaritalStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Marital Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].PlaceOfBirth",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Place of Birth", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Qualification",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Educational Qualification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MarketingPreferences",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Marketing Preferences", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].RelationWithBank",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Educational Qualification", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].TypeOfInitialFund",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" TypeOfInitialFunding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ConstitutionCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfDependants",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No. of Dependants", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ResidenceStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Residential Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].GSTCustomerType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Customer Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].GSTRegistrationNumber",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" GST Registration Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpecificStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Specific status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].AdviceDetailsAddressType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Advice Detail Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InternetBanking",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Online Banking", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DomicileCountryCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MobileBanking",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Mobile Banking", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfDependants",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No. of Dependants", GetCase.scenarioID));

		// FamilyDetails

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MaidenFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MaidenFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherPrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherMaidenName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherMaidenName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherPrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpousePrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpousePrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfChildren",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Number of children", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].AgeOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Age of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].GenderOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Gender of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].NameOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Name of the Child", GetCase.scenarioID));


		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmployerRelationshipName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Employer Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmploymentType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Work Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmpReltnID",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Employee ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.StaffCategory",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Staff Category", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IsPayrollCust",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Payroll Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NatureOfBusiness",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Nature of Business", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.AnnualDeclaredIncome",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" AnnualDeclaredIncome", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.BusinessEstablishmentDate",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Business Establishment Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Company_Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Company Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CompanyName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Company Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CompanyType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CurrentOrgMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CurrentOrgYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Department",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Department", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Designation",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Designation", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IncorporationCountry",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Incorporation Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IncorporationDate",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Incorporation Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryGroup",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Industry Group Sector", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ModeOfSalary",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Salary Mode", GetCase.scenarioID));

		int a = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID))*12; 
		int b = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID))*12; 

		int c = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID)));
		int d = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID)));


		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NoOfMonthsInCurrentBusinessOrganization",a);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NoOfMonthsInPreviousBusinessOrganization",b); 
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.OwnershipType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Describe Applicant/Ownership Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousEmployerName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Previous employer name ", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousOrgMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousOrgYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.SharePercentage",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" % of Share holding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TaxResidencyStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Tax Residency status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TotalExpMM",c);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TotalExpYY",d);



		//Address Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine1",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine2",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine3",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].CityName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" City", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Country",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].PostalCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Zip Code", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Mailing Address Indicator", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Type", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Permanent Address same as Residential Address", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Mailing Address Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Permanent Address same as Residential Address", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthInYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length at Current Address", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthInMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length_at_Current_Address_MM", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Residence_Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Residence type", GetCase.scenarioID));


		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine4",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" AddressLine4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Country",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Area",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Area", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthAtCurrentAddressInMonths",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length_at_Current_Address_MM", GetCase.scenarioID));

		//FATCA Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSCitizen",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Is Customer a US Citizen?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSGreenCardHolder",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FATCA - Is Customer a US Resident?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSResident",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FATCA - Is Customer a Green card holder?", GetCase.scenarioID));


		//More Financial Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Account Number/App Ref No.", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AccountType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Account Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].ActualMonthlyCommitment",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Actual Monthly Commitment", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].ApplicantType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Applicant Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AppliedAmountCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Applied Amount Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].CommitmentCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Commitment Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OriginalApprovedLimit",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Original approved limit", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OriginalApprovedLimitCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Original approved limit currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OtherCardRepaymentRatio",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" other Card Repayment Ratio", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OustandingAmountCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Oustanding amount currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OutstandingAmount",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Outstanding amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].Source",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Source", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].Status",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Status", GetCase.scenarioID));

		//Internal Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InfoCode[0].Code",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MIS Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InfoCode[0].Value",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MIS Value", GetCase.scenarioID));


	

}
	
	/**************************************************************************************************
	 * @author 1575731
	 * MethodName: setCustomerIncomeDocumentDetailsInFDCMaker
	 * Objective: Provide Income details in Json for Primary & CoApp1, CoApp2 ...
	 * Arguments: CustomerIndex ,incomeDocArrayIndex,PrimaryOrCoApp
	 * * * CustomerIndex: Takes integer as Argument(If primary- provide 0, CoApp1 - provide 1..)
	 * * * incomeDocArrayIndex: Takes integer as argument, Used for Creating Json Path
	 * * * PrimaryOrCoApp: if primary then provide :"Primary" else CoApp1,CoApp2,.. based on how you created in DB
	 * @return: void 
	 **************************************************************************************************/
	public static void setCustomerIncomeDocumentDetailsInFDCMaker(int CustomerIndex , String PrimaryOrCoApp ,int IncomeDocCount,int incomeDocArrayIndex)
		{
			String pxObjClass="SCB-Data-FinancialDetails";
			String timeZone="T18:30:00.000Z";
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
		
		if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID).contains("FORM 16"))
		{
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			/**********************************************Form 16 Details***************************************************************/
			String pxObjectClassForm16="SCB-Data-FinancialDetails-FORM16";
			
			//Year1
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Income_As_Per_Tax_File_1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].pxObjClass",pxObjectClassForm16);
			
			//Year2
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfIssueDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].pxObjClass",pxObjectClassForm16);
			
			//Year3
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfIssueDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].pxObjClass",pxObjectClassForm16);
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID).contains("CREDIT CARD /DEBIT CARD STATEMENT"))
		{
			String pxObjClassCC="SCB-Data-FinancialDetails-CreditCardStatement";
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			//################################################Credit Statements #########################################
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardLimit",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfIssueDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardRepayRatio",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfExpiryDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].IssuerName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].LastMonthOutstanding",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].ProductName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDt",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtFrom",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtTo",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1StatementDtTo", GetCase.scenarioID));
			
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardLimit",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfIssueDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardRepayRatio",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfExpiryDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].IssuerName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].LastMonthOutstanding",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].ProductName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDt",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtFrom",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtTo",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2StatementDtTo", GetCase.scenarioID));
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID).contains("PAYSLIP"))
		{
			String pxObjClassPaySlip="SCB-Data-FinancialDetails-Payslip";
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			//######################PaySlip Details####################
			
			//Month1
			int bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field1", GetCase.scenarioID));
			int bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field2", GetCase.scenarioID));
			int bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field3", GetCase.scenarioID));
			int bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field4", GetCase.scenarioID));
			int bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field5", GetCase.scenarioID));
			int bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field6", GetCase.scenarioID));
			int bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field7", GetCase.scenarioID));
			int bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 Basic Monthly Salary Field8", GetCase.scenarioID));
			
			int mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field1", GetCase.scenarioID));
			int mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field2", GetCase.scenarioID));
			int mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field3", GetCase.scenarioID));
			int mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field4", GetCase.scenarioID));
			int mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field5", GetCase.scenarioID));
			int mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field6", GetCase.scenarioID));
			int mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field7", GetCase.scenarioID));
			int mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyAllowance Field8", GetCase.scenarioID));
			
			int mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			
			int mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field2", GetCase.scenarioID));
			int mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field3", GetCase.scenarioID));
			int mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field4", GetCase.scenarioID));
			int mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field5", GetCase.scenarioID));
			int mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field6", GetCase.scenarioID));
			int mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field7", GetCase.scenarioID));
			int mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyBonus Field8", GetCase.scenarioID));
			
			int mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field1", GetCase.scenarioID));
			int mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field2", GetCase.scenarioID));
			int mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field3", GetCase.scenarioID));
			int mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field4", GetCase.scenarioID));
			int mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field5", GetCase.scenarioID));
			int mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field6", GetCase.scenarioID));
			int mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field7", GetCase.scenarioID));
			int mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M1 MonthlyVariableBonus Field8", GetCase.scenarioID));
			
			int basicSalarytotal = bfield1+bfield2+bfield3+bfield4+bfield5+bfield6+bfield7+bfield8;
			int MonthlyAllowancetotal = mafield1+mafield2+mafield3+mafield4+mafield5+mafield6+mafield7+mafield8;
			int MonthlyBonustotal = mbfield1+mbfield2+mbfield3+mbfield4+mbfield5+mbfield6+mbfield7+mbfield8;
			int MonthlyCommissiontotal = mcfield1+mcfield2+mcfield3+mcfield4+mcfield5+mcfield6+mcfield7+mcfield8;
			int MonthlyVariableBonus = mvfield1+mvfield2+mvfield3+mvfield4+mvfield5+mvfield6+mvfield7+mvfield8;
			
			int grandTotal= basicSalarytotal+MonthlyAllowancetotal+MonthlyBonustotal+MonthlyCommissiontotal+MonthlyVariableBonus;
			
			//Month1 Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrandTotal",grandTotal);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Gross Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Net Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field1",bfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field2",bfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field3",bfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field4",bfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field5",bfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field6",bfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field7",bfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field8",bfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Total",basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field1",mafield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field2",mafield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field3",mafield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field4",mafield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field5",mafield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field6",mafield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field7",mafield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field8",mafield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Total",MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field1",mcfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field2",mcfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field3",mcfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field4",mcfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field5",mcfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field6",mcfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field7",mcfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field8",mcfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Total",MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field1",mvfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field2",mvfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field3",mvfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field4",mvfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field5",mvfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field6",mvfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field7",mvfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field8",mvfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Total",MonthlyVariableBonus);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",mvfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",mvfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",mvfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",mvfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",mvfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",mvfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",mvfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",mvfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Total",MonthlyVariableBonus);

			/* Month 2*/
			int m2bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field1", GetCase.scenarioID));
			int m2bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field2", GetCase.scenarioID));
			int m2bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field3", GetCase.scenarioID));
			int m2bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field4", GetCase.scenarioID));
			int m2bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field5", GetCase.scenarioID));
			int m2bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field6", GetCase.scenarioID));
			int m2bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field7", GetCase.scenarioID));
			int m2bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 Basic Monthly Salary Field8", GetCase.scenarioID));
			
			int m2mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field1", GetCase.scenarioID));
			int m2mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field2", GetCase.scenarioID));
			int m2mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field3", GetCase.scenarioID));
			int m2mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field4", GetCase.scenarioID));
			int m2mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field5", GetCase.scenarioID));
			int m2mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field6", GetCase.scenarioID));
			int m2mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field7", GetCase.scenarioID));
			int m2mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyAllowance Field8", GetCase.scenarioID));
			
			int m2mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			
			int m2mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field2", GetCase.scenarioID));
			int m2mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field3", GetCase.scenarioID));
			int m2mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field4", GetCase.scenarioID));
			int m2mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field5", GetCase.scenarioID));
			int m2mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field6", GetCase.scenarioID));
			int m2mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field7", GetCase.scenarioID));
			int m2mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyBonus Field8", GetCase.scenarioID));
			
			int m2mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field1", GetCase.scenarioID));
			int m2mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field2", GetCase.scenarioID));
			int m2mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field3", GetCase.scenarioID));
			int m2mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field4", GetCase.scenarioID));
			int m2mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field5", GetCase.scenarioID));
			int m2mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field6", GetCase.scenarioID));
			int m2mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field7", GetCase.scenarioID));
			int m2mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_M2 MonthlyVariableBonus Field8", GetCase.scenarioID));
			
			int m2basicSalarytotal = m2bfield1+m2bfield2+m2bfield3+m2bfield4+m2bfield5+m2bfield6+m2bfield7+m2bfield8;
			int m2MonthlyAllowancetotal = m2mafield1+m2mafield2+m2mafield3+m2mafield4+m2mafield5+m2mafield6+m2mafield7+m2mafield8;
			int m2MonthlyBonustotal = m2mbfield1+m2mbfield2+m2mbfield3+m2mbfield4+m2mbfield5+m2mbfield6+m2mbfield7+m2mbfield8;
			int m2MonthlyCommissiontotal = m2mcfield1+m2mcfield2+m2mcfield3+m2mcfield4+m2mcfield5+m2mcfield6+m2mcfield7+m2mcfield8;
			int m2MonthlyVariableBonus = m2mvfield1+m2mvfield2+m2mvfield3+m2mvfield4+m2mvfield5+m2mvfield6+m2mvfield7+m2mvfield8;
			
			int m2grandTotal= m2basicSalarytotal+m2MonthlyAllowancetotal+m2MonthlyBonustotal+m2MonthlyCommissiontotal+m2MonthlyVariableBonus;
			
			//Month2 Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrandTotal",m2grandTotal);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Gross Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Net Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field1",m2bfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field2",m2bfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field3",m2bfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field4",m2bfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field5",m2bfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field6",m2bfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field7",m2bfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field8",m2bfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Total",m2basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field1",m2mafield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field2",m2mafield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field3",m2mafield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field4",m2mafield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field5",m2mafield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field6",m2mafield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field7",m2mafield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field8",m2mafield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Total",m2MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field1",m2mbfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field2",m2mbfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field3",m2mbfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field4",m2mbfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field5",m2mbfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field6",m2mbfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field7",m2mbfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field8",m2mbfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Total", m2MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field1",m2mcfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field2",m2mcfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field3",m2mcfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field4",m2mcfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field5",m2mcfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field6",m2mcfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field7",m2mcfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field8",m2mcfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Total", m2MonthlyVariableBonus);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",m2mvfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",m2mvfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",m2mvfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",m2mvfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",m2mvfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",m2mvfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",m2mvfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",m2mvfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Total", m2MonthlyVariableBonus);
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID).contains("BONUS"))
		{
			/*******************************************Bonus Letters*******************************************************/
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","O");
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID).contains("BANK STATEMENT"))
		{
			/***************************************Bank Statements*********************************************************/			
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_CardGrandTotal", GetCase.scenarioID));
			
		}
		
		else{System.out.println(""+DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc+"+IncomeDocCount+"+_DocumentName", GetCase.scenarioID)+"Does Not matches with any of the Income docs");}
		
}
	


	public static void SetCustomerIncomeDocumentDetails() 
	{
		System.out.println("-----------------       *********       SetCustomerIncomeDocumentDetails -Starts    **********          ---------------------------");
		int CustomerIndex=0;
		String PrimaryOrCoApp="Primary";
		int incomeDocArrayIndex=0;
		
		for(int IncomeDocCount=1;IncomeDocCount<=3;IncomeDocCount++)
		{
			setCustomerIncomeDocumentDetailsInFDCMaker(CustomerIndex, PrimaryOrCoApp, IncomeDocCount, incomeDocArrayIndex);
		}
		
		System.out.println("-----------------        **********         SetCustomerIncomeDocumentDetails -Ends        **********      ---------------------------");
		
	}
	
	/************************************* Without Parameterization **************************/
	
	public static void setCustomerDocumentDetailsInFDCMaker()
	{
		String pxObjClass="SCB-Data-FinancialDetails";
		String timeZone="T18:30:00.000Z";

		
		if(DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID).contains("FORM 16"))
		{
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentCategory",DBUtils.readColumnWithRowID("DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentRemarks",DBUtils.readColumnWithRowID("DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentType",DBUtils.readColumnWithRowID("DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Mandatory","M");
			
			/**********************************************Form 16 Details***************************************************************/
			String pxObjectClassForm16="SCB-Data-FinancialDetails-FORM16";
			
			//Year1
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].AssessmentYearFromYear",DBUtils.readColumnWithRowID("DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].AssessmentYearToYear",DBUtils.readColumnWithRowID("DateOfExpiryDoc", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].IncomeAsPerTax",DBUtils.readColumnWithRowID("Income_As_Per_Tax_File_1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].DocumentDate",DBUtils.readColumnWithRowID("DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[0].pxObjClass",pxObjectClassForm16);
			
			//Year2
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].AssessmentYearFromYear",DBUtils.readColumnWithRowID("DateOfIssueDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].AssessmentYearToYear",DBUtils.readColumnWithRowID("DateOfExpiryDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].IncomeAsPerTax",DBUtils.readColumnWithRowID("Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].DocumentDate",DBUtils.readColumnWithRowID("DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].pxObjClass",pxObjectClassForm16);
			
			//Year3
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].AssessmentYearFromYear",DBUtils.readColumnWithRowID("DateOfIssueDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].AssessmentYearToYear",DBUtils.readColumnWithRowID("DateOfExpiryDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].IncomeAsPerTax",DBUtils.readColumnWithRowID("Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].DocumentDate",DBUtils.readColumnWithRowID("DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Form16Details[1].pxObjClass",pxObjectClassForm16);
			
		}
		
		else if(DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID).contains("CREDIT CARD /DEBIT CARD STATEMENT"))
		{
			String pxObjClassCC="SCB-Data-FinancialDetails-CreditCardStatement";
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentCategory",DBUtils.readColumnWithRowID("DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentType",DBUtils.readColumnWithRowID("DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Mandatory","M");
			
			//################################################Credit Statements #########################################
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].CardLimit",DBUtils.readColumnWithRowID("M1CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DateOfIssueDoc",DBUtils.readColumnWithRowID("M1DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].CardRepayRatio",DBUtils.readColumnWithRowID("M1CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DateOfExpiryDoc",DBUtils.readColumnWithRowID("M1DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DocumentStatus",DBUtils.readColumnWithRowID("M1DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].GrandTotal",DBUtils.readColumnWithRowID("M1CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].IssuerName",DBUtils.readColumnWithRowID("M1IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].LastMonthOutstanding",DBUtils.readColumnWithRowID("M1LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].ProductName",DBUtils.readColumnWithRowID("M1ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDt",DBUtils.readColumnWithRowID("M1StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDtFrom",DBUtils.readColumnWithRowID("M1StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDtTo",DBUtils.readColumnWithRowID("M1StatementDtTo", GetCase.scenarioID));
			
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].CardLimit",DBUtils.readColumnWithRowID("M2CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DateOfIssueDoc",DBUtils.readColumnWithRowID("M2DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].CardRepayRatio",DBUtils.readColumnWithRowID("M2CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DateOfExpiryDoc",DBUtils.readColumnWithRowID("M2DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].DocumentStatus",DBUtils.readColumnWithRowID("M2DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].GrandTotal",DBUtils.readColumnWithRowID("M2CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].IssuerName",DBUtils.readColumnWithRowID("M2IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].LastMonthOutstanding",DBUtils.readColumnWithRowID("M2LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].ProductName",DBUtils.readColumnWithRowID("M2ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDt",DBUtils.readColumnWithRowID("M2StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDtFrom",DBUtils.readColumnWithRowID("M2StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CreditCardStatement[0].StatementDtTo",DBUtils.readColumnWithRowID("M2StatementDtTo", GetCase.scenarioID));
		}
		
		else if(DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID).contains("PAYSLIP"))
		{
			String pxObjClassPaySlip="SCB-Data-FinancialDetails-Payslip";
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentCategory",DBUtils.readColumnWithRowID("DocumentCategory", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentType",DBUtils.readColumnWithRowID("DocumentType", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentStatus",DBUtils.readColumnWithRowID("DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Mandatory","M");
			
			//######################PaySlip Details####################
			
			//Month1
			int bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field1", GetCase.scenarioID));
			int bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field2", GetCase.scenarioID));
			int bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field3", GetCase.scenarioID));
			int bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field4", GetCase.scenarioID));
			int bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field5", GetCase.scenarioID));
			int bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field6", GetCase.scenarioID));
			int bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field7", GetCase.scenarioID));
			int bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 Basic Monthly Salary Field8", GetCase.scenarioID));
			
			int mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field1", GetCase.scenarioID));
			int mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field2", GetCase.scenarioID));
			int mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field3", GetCase.scenarioID));
			int mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field4", GetCase.scenarioID));
			int mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field5", GetCase.scenarioID));
			int mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field6", GetCase.scenarioID));
			int mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field7", GetCase.scenarioID));
			int mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyAllowance Field8", GetCase.scenarioID));
			
			int mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			
			int mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field1", GetCase.scenarioID));
			int mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field2", GetCase.scenarioID));
			int mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field3", GetCase.scenarioID));
			int mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field4", GetCase.scenarioID));
			int mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field5", GetCase.scenarioID));
			int mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field6", GetCase.scenarioID));
			int mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field7", GetCase.scenarioID));
			int mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyBonus Field8", GetCase.scenarioID));
			
			int mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field1", GetCase.scenarioID));
			int mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field2", GetCase.scenarioID));
			int mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field3", GetCase.scenarioID));
			int mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field4", GetCase.scenarioID));
			int mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field5", GetCase.scenarioID));
			int mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field6", GetCase.scenarioID));
			int mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field7", GetCase.scenarioID));
			int mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M1 MonthlyVariableBonus Field8", GetCase.scenarioID));
			
			int basicSalarytotal = bfield1+bfield2+bfield3+bfield4+bfield5+bfield6+bfield7+bfield8;
			int MonthlyAllowancetotal = mafield1+mafield2+mafield3+mafield4+mafield5+mafield6+mafield7+mafield8;
			int MonthlyBonustotal = mbfield1+mbfield2+mbfield3+mbfield4+mbfield5+mbfield6+mbfield7+mbfield8;
			int MonthlyCommissiontotal = mcfield1+mcfield2+mcfield3+mcfield4+mcfield5+mcfield6+mcfield7+mcfield8;
			int MonthlyVariableBonus = mvfield1+mvfield2+mvfield3+mvfield4+mvfield5+mvfield6+mvfield7+mvfield8;
			
			int grandTotal= basicSalarytotal+MonthlyAllowancetotal+MonthlyBonustotal+MonthlyCommissiontotal+MonthlyVariableBonus;
			
			//Month1 Mandatory
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].GrandTotal",grandTotal);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID("Gross Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID("Net Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field1",bfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field2",bfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field3",bfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field4",bfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field5",bfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field6",bfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field7",bfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field8",bfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Total",basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field1",mafield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field2",mafield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field3",mafield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field4",mafield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field5",mafield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field6",mafield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field7",mafield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field8",mafield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Total",MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field1",mcfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field2",mcfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field3",mcfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field4",mcfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field5",mcfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field6",mcfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field7",mcfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field8",mcfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Total",MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field1",mvfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field2",mvfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field3",mvfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field4",mvfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field5",mvfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field6",mvfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field7",mvfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field8",mvfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Total",MonthlyVariableBonus);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",mvfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",mvfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",mvfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",mvfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",mvfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",mvfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",mvfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",mvfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Total",MonthlyVariableBonus);

			/* Month 2*/
			int m2bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field1", GetCase.scenarioID));
			int m2bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field2", GetCase.scenarioID));
			int m2bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field3", GetCase.scenarioID));
			int m2bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field4", GetCase.scenarioID));
			int m2bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field5", GetCase.scenarioID));
			int m2bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field6", GetCase.scenarioID));
			int m2bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field7", GetCase.scenarioID));
			int m2bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 Basic Monthly Salary Field8", GetCase.scenarioID));
			
			int m2mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field1", GetCase.scenarioID));
			int m2mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field2", GetCase.scenarioID));
			int m2mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field3", GetCase.scenarioID));
			int m2mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field4", GetCase.scenarioID));
			int m2mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field5", GetCase.scenarioID));
			int m2mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field6", GetCase.scenarioID));
			int m2mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field7", GetCase.scenarioID));
			int m2mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyAllowance Field8", GetCase.scenarioID));
			
			int m2mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			
			int m2mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field1", GetCase.scenarioID));
			int m2mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field2", GetCase.scenarioID));
			int m2mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field3", GetCase.scenarioID));
			int m2mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field4", GetCase.scenarioID));
			int m2mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field5", GetCase.scenarioID));
			int m2mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field6", GetCase.scenarioID));
			int m2mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field7", GetCase.scenarioID));
			int m2mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyBonus Field8", GetCase.scenarioID));
			
			int m2mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field1", GetCase.scenarioID));
			int m2mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field2", GetCase.scenarioID));
			int m2mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field3", GetCase.scenarioID));
			int m2mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field4", GetCase.scenarioID));
			int m2mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field5", GetCase.scenarioID));
			int m2mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field6", GetCase.scenarioID));
			int m2mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field7", GetCase.scenarioID));
			int m2mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID("M2 MonthlyVariableBonus Field8", GetCase.scenarioID));
			
			int m2basicSalarytotal = m2bfield1+m2bfield2+m2bfield3+m2bfield4+m2bfield5+m2bfield6+m2bfield7+m2bfield8;
			int m2MonthlyAllowancetotal = m2mafield1+m2mafield2+m2mafield3+m2mafield4+m2mafield5+m2mafield6+m2mafield7+m2mafield8;
			int m2MonthlyBonustotal = m2mbfield1+m2mbfield2+m2mbfield3+m2mbfield4+m2mbfield5+m2mbfield6+m2mbfield7+m2mbfield8;
			int m2MonthlyCommissiontotal = m2mcfield1+m2mcfield2+m2mcfield3+m2mcfield4+m2mcfield5+m2mcfield6+m2mcfield7+m2mcfield8;
			int m2MonthlyVariableBonus = m2mvfield1+m2mvfield2+m2mvfield3+m2mvfield4+m2mvfield5+m2mvfield6+m2mvfield7+m2mvfield8;
			
			int m2grandTotal= m2basicSalarytotal+m2MonthlyAllowancetotal+m2MonthlyBonustotal+m2MonthlyCommissiontotal+m2MonthlyVariableBonus;
			
			//Month2 Mandatory
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].GrandTotal",m2grandTotal);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID("Gross Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID("Net Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field1",m2bfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field2",m2bfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field3",m2bfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field4",m2bfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field5",m2bfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field6",m2bfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field7",m2bfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Field8",m2bfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.BasicMonthlySalary.Total",m2basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field1",m2mafield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field2",m2mafield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field3",m2mafield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field4",m2mafield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field5",m2mafield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field6",m2mafield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field7",m2mafield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Field8",m2mafield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyAllowance.Total",m2MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field1",m2mbfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field2",m2mbfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field3",m2mbfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field4",m2mbfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field5",m2mbfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field6",m2mbfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field7",m2mbfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Field8",m2mbfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyBonus.Total", m2MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field1",m2mcfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field2",m2mcfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field3",m2mcfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field4",m2mcfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field5",m2mcfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field6",m2mcfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field7",m2mcfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Field8",m2mcfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyCommission.Total", m2MonthlyVariableBonus);
			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",m2mvfield1);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",m2mvfield2);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",m2mvfield3);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",m2mvfield4);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",m2mvfield5);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",m2mvfield6);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",m2mvfield7);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",m2mvfield8);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].PayslipDetails[0].Component.MonthlyVariableBonus.Total", m2MonthlyVariableBonus);
			
		}
		
		else if(DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID).contains("BONUS"))
		{
			/*******************************************Bonus Letters*******************************************************/
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentDate",DBUtils.readColumnWithRowID("DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].Mandatory","O");
			
		}
		
		else if(DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID).contains("BANK STATEMENT"))
		{
			/***************************************Bank Statements*********************************************************/			
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[0].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[0].GrandTotal",DBUtils.readColumnWithRowID("CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[1].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[1].GrandTotal",DBUtils.readColumnWithRowID("CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[2].DocumentStatus",DBUtils.readColumnWithRowID("Document Status", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers[0].IncomeDocumentList[0].BankStatement[2].GrandTotal",DBUtils.readColumnWithRowID("CardGrandTotal", GetCase.scenarioID));
			
		}
		
		else{System.out.println(""+DBUtils.readColumnWithRowID("Primary - Name of IncomeDocument1", GetCase.scenarioID)+"Does Not matches with any of the Income docs");}
		
}
	


}