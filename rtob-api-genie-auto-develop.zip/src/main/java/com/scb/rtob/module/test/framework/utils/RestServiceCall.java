package com.scb.rtob.module.test.framework.utils;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RestServiceCall {
	public static Logger logger = Logger.getLogger(RestServiceCall.class);
	/**************************************************************************************************
	 * Function to parse json file and Modify it.
	 * As parameters it accepts 
	 **** JSON Request template File Path (filePath) e.g. /src/test/resources/jsontemplates/BDC/Basic_SA.json
	 **** Input Parameters key-values pair as part JSON request (xmlReqParams) e.g. ("BarCode", "0042"), (Branch", "325"), ("ProductCategory", "PL"), ("ProductCode", "6025"), ("IsBundle", "N")  
	 * And Returns Modified JSON Request (JSONObject)
	 * @throws ParseException 
	 * @throws IOException 
	 **************************************************************************************************/
	@SuppressWarnings("unchecked")
	public JSONObject parseUpdateJson(String filePath, Map<String, String> jsonReqParams) throws IOException, ParseException{
		JSONObject jsonReq;
		JSONParser parser = new JSONParser();
		FileReader reader = new FileReader(filePath);
		jsonReq = (JSONObject) parser.parse(reader);
		
		//logger.info(jsonReq);
		//ObjectMapper mapper = new ObjectMapper();
		//logger.info("Json Request Body Before Update: "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonReq));
		/*****************Modify Request elements into JSON request**************/
		for(Map.Entry<String, String> m: jsonReqParams.entrySet()){
			jsonReq.put(m.getKey().toString(), m.getValue().toString());
			logger.info(m.getKey()+" updated to "+jsonReq.get(m.getKey()));
		}
		/*********************************************************************************/
		//logger.info("Json Request Body After Update: "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonReq));
		return jsonReq;
	}
	
	/**************************************************************************************************
	 * Function to consume Rest service with Get method.
	 * As parameters it accepts 
	 **** End point url(urlResource) e.g. https://10.23.212.45:8443/prweb/PRRestService/TestAutomation/v1/GetCase,
	 **** Authorization headers (authdrs) used to define username and password as map object, 
	 **** HTTP headers (httphdrs) used to define all headers.using map object, 
	 * And Returns the json response as JSONObject
	 * @throws ParseException 
	 **************************************************************************************************/
	public JSONObject submitGet(String urlResource,Map<String, String> authhdrs, Map<String, String> httphdrs) throws ParseException {
		useRelaxedHTTPSValidation();
		Response response = given().auth().preemptive().basic(authhdrs.get("username"), authhdrs.get("password"))
				.request().headers(httphdrs)
				.when().get( urlResource );
		logger.info("Status Code: "+ response.getStatusCode());
		JSONParser parser = new JSONParser();
		JSONObject responseBody = (JSONObject) parser.parse(response.andReturn().asString());
		return responseBody;
	}
	
	/**************************************************************************************************
	 * Function to consume Rest service with Put method.
	 * As parameters it accepts 
	 **** End point url(urlResource) e.g. https://10.23.212.45:8443/prweb/PRRestService/TestAutomation/v1/PromoteCase,
	 **** Authorization headers (authdrs) used to define username and password as map object, 
	 **** HTTP headers (httphdrs) used to define all headers.using map object, 
	 **** Json request body (jsonReqBody) used to send as part of rest request, 
	 * And Returns the json response as JSONObject
	 * @throws ParseException 
	 **************************************************************************************************/
	public JSONObject submitPut(String urlResource,Map<String, String> authhdrs, Map<String, String> httphdrs,JSONObject jsonReqBody) throws ParseException {
		useRelaxedHTTPSValidation();
		Response response = given().auth().preemptive().basic(authhdrs.get("username"), authhdrs.get("password"))
				.request().headers(httphdrs)
				.body( jsonReqBody )
				.when().put( urlResource );
		logger.info("Status Code: "+ response.getStatusCode());
		JSONParser parser = new JSONParser();
		JSONObject responseBody = (JSONObject) parser.parse(response.andReturn().asString());
		return responseBody;
	}
	/**************************************************************************************************/
	
	public static void main(String[] agrs) throws JsonProcessingException{
		RestServiceCall restClient = new RestServiceCall();
		/*******************Calling Get Case***********************************************************************************/
		String urlResource = "https://10.23.212.45:8443/prweb/PRRestService/TestAutomation/v1/GetCase";
		Map<String, String> authhdrs = new HashMap<String, String>();
		authhdrs.put("username", "TestAutomationUser");
		authhdrs.put("password", "rules");
		Map<String, String> httphdrs = new HashMap<String, String>();
		httphdrs.put("ApplicationRefNo", "IN20180308000311");
		httphdrs.put("CurrentWorkBasket", "BlindDataCapture");
		JSONObject jsonResponse = null;
		try {
			jsonResponse = restClient.submitGet(urlResource, authhdrs, httphdrs);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ObjectMapper mapper = new ObjectMapper();
		System.out.println("Get Case Json Response Body: "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonResponse));
		System.out.println("HttpResponse: "+ jsonResponse);
		/**********************************************************************************************************************/
		/*******************Calling Promote Case***********************************************************************************/
		urlResource = "https://10.23.212.45:8443/prweb/PRRestService/TestAutomation/v1/PromoteCase";
		
		try {
			JSONObject response = restClient.submitPut(urlResource, authhdrs, httphdrs, jsonResponse);
			mapper = new ObjectMapper();
			System.out.println("Promote Case Json Response Body: "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response));
			System.out.println("HttpResponse: "+ response);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/**********************************************************************************************************************/
		
		/***********Sample code to modify json file****************************************************************************/
		Map<String, String> jsonReqParams = new HashMap<String, String>();
		jsonReqParams.put("Title", "MRs");
		jsonReqParams.put("DateOfBirth", "25/09/1977");
		jsonReqParams.put("EmbossedName", "RTOB Dummy");
		jsonReqParams.put("FirstName", "Dummy Name");
		JSONObject jsonReq=null;
		try {
				jsonReq= restClient.parseUpdateJson("src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"BDC"+File.separator+"Basic_SA.json", jsonReqParams);
				mapper = new ObjectMapper();
				System.out.println("Json Request Body: "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonReq));
				
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/**********************************************************************************************************************/
		
	}

}
