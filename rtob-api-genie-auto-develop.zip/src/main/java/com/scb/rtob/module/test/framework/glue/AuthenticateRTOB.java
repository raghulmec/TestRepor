package com.scb.rtob.module.test.framework.glue;

import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.log4j.Logger;
import org.junit.Assert;

import cucumber.api.java.en.Given;

public class AuthenticateRTOB {
	
	public static Logger logger = Logger.getLogger(AuthenticateRTOB.class);
	
	public static void main(String[] args) throws Throwable{
		try {
			//authenticateUser();
			logger.info("Authenticate");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	@Given("^Authenticate the user$")
	public static void authenticateUser() throws Throwable {
	
	RestAssured.baseURI ="https://10.20.234.174:8453/prweb/api/v1";
	
	RestAssured.useRelaxedHTTPSValidation();
	
	RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic("TestAutomationUser", "rules");
	
	Response response = httpRequest.request(Method.GET,"/authenticate");
	
	logger.info(response.getStatusCode());
	
	logger.info(response.headers());
	
	logger.info("Status Code ok : "+validateStatusCode(response.getStatusCode()));
	
	}
	
	public static boolean validateStatusCode(int code){
		
		if (code==200){
			Assert.assertTrue("Response code: "+code, true);
			return true;
		}
		else if(code==201){
			Assert.assertTrue("Response code: "+code, true);
			return true;
		}
		else
			Assert.fail("Response code: "+code);
			return false;
		
		
	}
	
}
