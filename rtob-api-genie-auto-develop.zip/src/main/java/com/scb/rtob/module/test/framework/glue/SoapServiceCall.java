package com.scb.rtob.module.test.framework.glue;

import static io.restassured.RestAssured.*;
import static io.restassured.path.xml.XmlPath.*;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class SoapServiceCall {

	public static Logger logger = Logger.getLogger(SoapServiceCall.class);
	
	/**************************************************************************************************
	 * Function to consume Soap service with Post method without authorization(login).
	 * As parameters it accepts 
	 **** Input parameter SOAP service end point url(urlResource) e.g. "http://10.23.216.48:12104/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"
	 **** Input parameter http headers (reqhdrs) e.g. for this case it's null since we are not passing any header, 
	 **** Input parameter Content Type(strContentType) e.g.  "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";"
	 **** Input parameter Soap Request(soapEnvelope) e.g. content of /src/test/resources/xmltemplates/eopsAppRefRequest.xml
	 * And Returns the new generated ApplicationNo as part of response
	 **************************************************************************************************/
	public String submitPost(String urlResource,Map<String, String> reqhdrs,String strContentType, String soapEnvelope) throws ParserConfigurationException, SAXException, IOException{
		Response response = given().request().headers(reqhdrs)
		  	      .contentType(strContentType).body( soapEnvelope )
		  	      .when().post( urlResource );
		logger.info("Status Code: "+ response.getStatusCode());
		String xmlResponse = response.andReturn().asString();
		String prettyXMLResponse = with(xmlResponse).prettyPrint();	    
	    logger.info("\nResponse: "+prettyXMLResponse);
	    return xmlResponse;
	}
	
	/**************************************************************************************************
	 * Function to consume Soap service with Post method with Authorization (username, password).
	 * As parameters it accepts 
	 **** Input parameter End point url(urlResource) e.g. http://10.23.216.48:12104/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services,
	 **** Input parameter Authorization headers (authHeaders) used to define username and password as map object,
	 **** Input parameter http headers (reqHeaders) e.g. for this case it's null since we are not passing any header, 
	 **** Input parameter Content Type(strContentType) e.g.  "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";"
	 **** Input parameter Soap Request(myEnvelope) e.g. content of /src/test/resources/xmltemplates/eopsAppRefRequest.xml
	 * And Returns the new generated ApplicationNo as part of response
	 **************************************************************************************************/
	public String submitPostAuth(String urlResource, Map<String, String> authHeaders, Map<String, String> reqHeaders,String strContentType, String soapEnvelope) throws ParserConfigurationException, SAXException, IOException{
		useRelaxedHTTPSValidation();
		Response response = given().auth().preemptive().basic(authHeaders.get("username"),authHeaders.get("password") )
				.request().headers(reqHeaders)
				.contentType(strContentType).body( soapEnvelope )
				.when().post( urlResource );
		logger.info("Status Code: "+ response.getStatusCode());
		String xmlResponse = response.andReturn().asString();
		String prettyXMLResponse = with(xmlResponse).prettyPrint();	    
	    logger.info("\nResponse: "+prettyXMLResponse);
	    return xmlResponse;
	}
	
	/**************************************************************************************************
	 * Function to parse xml file to read contents.
	 * As parameters it accepts 
	 **** Input parameter SOAP Response(xmlResponse) into String format e.g response from SOAP Service call. 
	 **** Input List of Parameters(resArrParams) to read from xml response  
	 **** And Returns Key-Value(Map<String, String>) pair of Input parameters(restParams)
	 **************************************************************************************************/
	public Map<String, String> readXmlResponse(String xmlResponse, String[] resArrParams) throws ParserConfigurationException, SAXException, IOException{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		InputSource isXmlResponse = new InputSource(new StringReader(xmlResponse));
		Document doc = docBuilder.parse(isXmlResponse);
		doc.getDocumentElement().normalize();
		Map<String, String> resParams = new HashMap<String, String>();
		for(int i=0; i< resArrParams.length; i++){
			NodeList ndList = doc.getElementsByTagName(resArrParams[i]);
			Node nodeName = ndList.item(0);
			resParams.put(resArrParams[i], nodeName.getTextContent());
			logger.info("Value of the node >> "+resArrParams[i] +" : "+ resParams.get(resArrParams[i]));
		}
		return resParams;
	}
	
	
	/**************************************************************************************************
	 * Function to parse xml file and Modify it.
	 * As parameters it accepts 
	 **** SOAP Request template File Path (filePath) e.g. /src/test/resources/xmltemplates/eopsAppRefRequest.xml 
	 **** Input Parameters key-values pair as part SOAP request (xmlReqParams) e.g. ("BarCode", "0042"), (Branch", "325"), ("ProductCategory", "PL"), ("ProductCode", "6025"), ("IsBundle", "N")  
	 * And Returns Modified SOAP Request (SOAP envelop)
	 **************************************************************************************************/
	public String updateXmlRequest(String filePath, Map<String, String> xmlReqParams) throws SAXException, IOException, ParserConfigurationException, TransformerException{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filePath);
		doc.getDocumentElement().normalize();

		/*****************Modify Request elements into soap request envelop**************/
		for(Map.Entry<String, String> m: xmlReqParams.entrySet()){
			NodeList ndList = doc.getElementsByTagName(m.getKey());
			Node nodeName = ndList.item(0);
			nodeName.setTextContent(m.getValue());
			logger.info(m.getKey()+" updated to "+nodeName.getTextContent());
		}
		/*********************************************************************************/

		/****Convert xml document into string*********************************************/
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		String soapEnvelop = writer.toString();
		/**********************************************************************************/
		return soapEnvelop;

	}
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException{
		
		SoapServiceCall soapClient = new SoapServiceCall();
        /************Soap Service Call without login with SOAP Request Body(SOAP Envelop) Modification and reading response Start********************************************************/
		String urlResource = "http://10.23.216.48:12104/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"; //Unified URL
        //String urlResource = "http://10.23.212.44:6900/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"; //SIT URL
        Map<String, String> reqhdrs = new HashMap<String, String>();
        String strContentType = "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";";
        Map<String, String> xmlReqParams = new HashMap<String, String>();
        xmlReqParams.put("BarCode", "0042");
        xmlReqParams.put("Branch", "325");
        xmlReqParams.put("ProductCategory", "PL");
        xmlReqParams.put("ProductCode", "6025");
        xmlReqParams.put("IsBundle", "N");
        String soapEnvelope = null;
        try {
        	soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"eopsAppRefRequest.xml", xmlReqParams);
         System.out.println(soapEnvelope);
        } catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }
        String xmlResponse = soapClient.submitPost(urlResource, reqhdrs, strContentType, soapEnvelope);
        String[] resArrParams ={"ApplicationRefNo"};
        Map<String, String> xmlRespParams;
        xmlRespParams = soapClient.readXmlResponse(xmlResponse, resArrParams);
        for(Map.Entry<String, String> m: xmlRespParams.entrySet()){
			System.out.println(m.getKey()+" : "+m.getValue());
		}
        /************Soap Service Call without login with SOAP Request Body(SOAP Envelop) Modification and reading response Ends********************************************************/
        
        
        /************Soap Service Call with login with SOAP Request Body(SOAP Envelop) Modification and reading response Start********************************************************/
		urlResource = "https://hklvatedm02.hk.standardchartered.com:6601/coreBanking/creditCard/v1/ws/services/v1/creditCardEnquiry"; //Unified URL
        //String urlResource = "http://10.23.212.44:6900/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"; //SIT URL
		Map<String, String> authHeaders = new HashMap<String, String>();
		authHeaders.put("username", "appwfuser");
		authHeaders.put("password", "abc12345");
		reqhdrs = new HashMap<String, String>();
        strContentType = "text/xml;charset=UTF-8";
        xmlReqParams = new HashMap<String, String>();
        xmlReqParams.put("ns2:CardNum", "4129037090873902");
		xmlReqParams.put("ns1:countryCode", "IN");
		xmlReqParams.put("ns2:SCB_EntityType", "05");
		xmlReqParams.put("ns2:SCB_SourceFlag", "RTO");
		xmlReqParams.put("ns2:SCB_FuncCode", "16");	
		soapEnvelope = null;
        try {
        	soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetDetails.xml", xmlReqParams);
         System.out.println(soapEnvelope);
        } catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }
        xmlResponse = soapClient.submitPostAuth(urlResource, authHeaders, reqhdrs, strContentType, soapEnvelope);
        String[] resArrParams2 ={"crdenq:SCB_CustOrg", "crdenq:SCB_CustNum", "crdenq:CardCategory", "crdenq:Name", "crdenq:SCB_EmbosserName"};
        xmlRespParams = new HashMap<String, String>();
        xmlRespParams = soapClient.readXmlResponse(xmlResponse, resArrParams2);
        for(Map.Entry<String, String> m: xmlRespParams.entrySet()){
			System.out.println(m.getKey()+" : "+m.getValue());
		}
        /************Soap Service Call with login with SOAP Request Body(SOAP Envelop) Modification and reading response Ends********************************************************/
    //System.out.println("Generated Application Ref ID: "+ AppRefNo);
	}
}
