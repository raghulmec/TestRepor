package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.FDMRequestGen;
import com.scb.rtob.module.test.framework.glue.GetCase;

public class FraudRiskCheckerSetValue {
	
public static Logger logger = Logger.getLogger(FraudRiskCheckerSetValue.class);
	
	private static JSONObject json = FDMRequestGen.jsonReq;
	
	static String FullName = null;
	static String coApplicantFullName = null;
	static String ShortName = null;
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void fraudRiskVerificationList(){
		
		
	
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[0].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[0].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod1", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[1].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[1].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod2", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[2].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[2].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod3", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[3].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[3].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod4", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[4].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus5", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[4].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod5", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[5].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus6", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[5].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod6", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[6].ScreenedStatus",DBUtils.readColumnWithRowID("ScreenedStatus7", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[6].VerifyMethod",DBUtils.readColumnWithRowID("VerifyMethod7", GetCase.scenarioID));
		
	}
	
	
}
