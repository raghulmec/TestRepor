package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import java.io.FileReader;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;
import com.scb.rtob.module.test.framework.utils.*;
import cucumber.api.java.en.Given;

public class DocumentIndexing {
	
	public static Logger logger = Logger.getLogger(DocumentIndexing.class);
	public static JSONParser parser = new JSONParser();
	
	static String fdcScenarioID = "1";
	
	
	/********To be used in DocumentIndexingSetValue class***********************/
	
	public static JSONObject jsonReq;

	public static void main(String[] args) throws Throwable {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		promoteDI("Y");
		
		validateWorkbasketDI();
		
		
	
	}
		
	
	@Given("^Call the PromoteCase api for Document Indexing from SoapUI '(.*)'$")
	public static void promoteDI(String soapui) throws Throwable {
		
/****************************Set eClassifer*************************************/		
		
		if(soapui.equals("Y"))
		{	
			EopsSoapClient.appidGeneration();
		}
		
		EClassifier.eClassify();
		
		
			
		
	/*	GetCase.loadProps();
		Mapper.setMapper();
		DBUtils.convertDBtoMap("diquery");
	*/		

/*******************************************************************************/
		
		
		FileReader reader = CommonUtils.readFilefromDirectory("DI", "DI_Template");
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		
		//****************************Start - API call part**********************************************//*
		
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));

		DBUtils.convertDBtoMap("diquery");
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		
	//	httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_DocumentIndexing"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Application Ref Number: "+DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	@SuppressWarnings("unchecked")
	public static void promoteDocumentIndexing(String soapui) throws Throwable {
		
		/****************************Set eClassifer*************************************/		
		logger.info(" --------------------------------Document Indexing Starts-------------------------------------------- ");	
		
		if(soapui.equals("Y"))
		{EopsSoapClient.appidGeneration();}
		EClassifier.eClassify();
		
		FileReader reader = CommonUtils.readFilefromDirectory("Globaltemplate", "DocumentIndexing.json");
		jsonReq = (JSONObject) parser.parse(reader);
		/*******************************************************************************/
		RTOBAPISetValues.setDocumentCompanyName(jsonReq);
		logger.info("JSON for Scenario ID: "+GetCase.scenarioID+" : "+jsonReq);
		
		GetCase.appAppID.add(DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		GetCase.individualRunDetails.put("ApplicationRefNo ", DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		GetCase.individualRunDetails.put("Scenario ID ", GetCase.scenarioID);
		
		/****************************Start - API call part**********************************************/	
		GetCase.callPromoteCaseApi("ApplicationRefNo", "CurrentWorkBasket_DI","NotRequired", jsonReq, false);		
		logger.info(" --------------------------------Document Indexing Ends-------------------------------------------- ");
        
	}
	
	
	@Given("^validate if the application moved from DI to Basic Data Capture$")
	public static void validateWorkbasketDI() throws Throwable {
		
		GetCase.currentWB=GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+ GetCase.currentWB);
		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Basic")+", Actual : "+GetCase.currentWB);
		Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_Basic"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
		logger.info(" --------------------------------Document Indexing Ends-------------------------------------------- ");
	}
	

}