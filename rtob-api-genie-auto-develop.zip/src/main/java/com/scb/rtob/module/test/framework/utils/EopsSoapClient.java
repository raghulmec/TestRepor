package com.scb.rtob.module.test.framework.utils;

import static io.restassured.RestAssured.*;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.scb.rtob.module.test.framework.glue.GetCase;

public class EopsSoapClient {
	
	public static Logger logger = Logger.getLogger(EopsSoapClient.class);
	
	/**************************************************************************************************
	 * Function to consume Soap service with Post method.
	 * As parameters it accepts 
	 **** http headers (authdrs) e.g. for this case it's null since we are not passing any header, 
	 **** Content Type(strContentType) e.g.  "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";"
	 **** and Soap Request(myEnvelope) e.g. content of /src/test/resources/xmltemplates/eopsAppRefRequest.xml
	 * And Returns the new generated ApplicationNo as part of response
	 **************************************************************************************************/
	public String submitPost(String urlResource,Map<String, String> authhdrs,String strContentType, String myEnvelope) throws ParserConfigurationException, SAXException, IOException{
		String xmlResponse = given().request().headers(authhdrs)
		  	      .contentType(strContentType).body( myEnvelope )
		  	      .when().post( urlResource ).andReturn().asString();
		//String prettyXMLResponse = with(xmlResponse).prettyPrint();	    
	    //System.out.println(prettyXMLResponse);
	    /****************Reading Xml Response *********************************************************/
	    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		InputSource isXmlResponse = new InputSource(new StringReader(xmlResponse));
		Document doc = docBuilder.parse(isXmlResponse);
		doc.getDocumentElement().normalize();
		NodeList ndList = doc.getElementsByTagName("ApplicationRefNo");
		Node nodeName = ndList.item(0);
		logger.info("Application created: "+ nodeName.getTextContent());
		return nodeName.getTextContent();
		/**********************************************************************************************/
	}
	
	
	/**************************************************************************************************
	 * Function to parse xml file and Modify it.
	 * As parameters it accepts 
	 **** SOAP Request template File Path (filePath) e.g. /src/test/resources/xmltemplates/eopsAppRefRequest.xml 
	 **** Input Parameters key-values pair as part SOAP request (xmlReqParams) e.g. ("BarCode", "0042"), (Branch", "325"), ("ProductCategory", "PL"), ("ProductCode", "6025"), ("IsBundle", "N")  
	 * And Returns Modified SOAP Request (SOAP envelop)
	 **************************************************************************************************/
	public String parseUpdateXml(String filePath, Map<String, String> xmlReqParams) throws SAXException, IOException, ParserConfigurationException, TransformerException{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filePath);
		doc.getDocumentElement().normalize();
		
		/*****************Modify Request elements into soap request envelop**************/
		for(Map.Entry<String, String> m: xmlReqParams.entrySet()){
			NodeList ndList = doc.getElementsByTagName(m.getKey());
			Node nodeName = ndList.item(0);
			nodeName.setTextContent(m.getValue());
			logger.info(m.getKey()+" updated to "+nodeName.getTextContent());
		}
		/*********************************************************************************/
		
		/****Convert xml document into string*********************************************/
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		String soapEnvelop = writer.toString();
		/**********************************************************************************/
		return soapEnvelop;

	}
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException{
        EopsSoapClient soapClient = new EopsSoapClient();
        String urlResource = "http://10.23.216.48:12104/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"; //Unified URL
        //String urlResource = "http://10.23.212.44:6900/prweb/PRSOAPServlet/SOAP/AppWorkFlowFWEOPSOBServices/Services"; //SIT URL
        Map<String, String> authhdrs = new HashMap<String, String>();
        String strContentType = "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";";
        Map<String, String> xmlReqParams = new HashMap<String, String>();
        xmlReqParams.put("BarCode", "0042");
        xmlReqParams.put("Branch", "325");
        xmlReqParams.put("ProductCategory", "PL");
        xmlReqParams.put("ProductCode", "6025");
        xmlReqParams.put("IsBundle", "N");
        String myEnvelope = null;
        try {
         myEnvelope = soapClient.parseUpdateXml("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"eopsAppRefRequest.xml", xmlReqParams);
         System.out.println(myEnvelope);
        } catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }
        for(int i=0; i<1; i++){
               String AppRefNo = soapClient.submitPost(urlResource, authhdrs, strContentType, myEnvelope);
            System.out.println("Generated Application Ref ID: "+ AppRefNo);
        }
      

  }

	public static void appidGeneration() throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, SQLException  {	
		
		System.out.println("-------------------- appidGeneration STARTS----------------------------");
		GetCase.loadProps();
		Mapper.setMapper();
		DBUtils.convertDBtoMap("diquery");
		
		 String BarCode = DBUtils.readColumnWithRowID("BarCode", GetCase.scenarioID);
         String Branch = DBUtils.readColumnWithRowID("Branch", GetCase.scenarioID); 
         String ProductCategory = DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID);
         String ProductCode = DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID);
         String IsBundle = DBUtils.readColumnWithRowID("IsBundle", GetCase.scenarioID);
		
		
	EopsSoapClient soapClient = new EopsSoapClient();
		String urlResource = GetCase.envmap.get("URL");
		
		Map<String, String> authhdrs = new HashMap<String, String>();
		String strContentType = "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";";
		Map<String, String> xmlReqParams = new HashMap<String, String>();
		
		
		xmlReqParams.put("BarCode", BarCode);
		xmlReqParams.put("Branch", Branch);
		xmlReqParams.put("ProductCategory", ProductCategory);
		xmlReqParams.put("ProductCode", ProductCode);
		xmlReqParams.put("IsBundle", IsBundle);
		String myEnvelope = null;
		try {
	    	myEnvelope = soapClient.parseUpdateXml("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"eopsAppRefRequest.xml", xmlReqParams);
	    	System.out.println(myEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    String AppRefNo = soapClient.submitPost(urlResource, authhdrs, strContentType, myEnvelope);
	    System.out.println("Generated Application Ref ID: "+ AppRefNo);
	    
	    updateAppId("UpdateAppRefNoDI",AppRefNo,GetCase.scenarioID);
	    updateAppId("UpdateAppRefNoBDC",AppRefNo,GetCase.scenarioID);
	    updateAppId("UpdateAppRefNoFDC",AppRefNo,GetCase.scenarioID);
	    
	    System.out.println("-------------------- appidGeneration ENDS----------------------------");
	    
 
	}
	
public static void updateAppId(String table, String appID,String scenario_Id) throws ClassNotFoundException, SQLException, IOException{
		
		String query = GetCase.envmap.get(table);
		query = query.replace("appID", appID);
		query = query.replace("scenario_Id", scenario_Id);
		System.out.println("Updated Query: "+query);
		DBUtils.updateQuery(query);
	}

public static void appidGenerationWithScenarioId(String scenarioID) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, SQLException  {	
	
	System.out.println("-------------------- appidGeneration STARTS----------------------------");
	GetCase.loadProps();
	Mapper.setMapper();
	DBUtils.convertDBtoMap("diquery");
	
	 String BarCode = DBUtils.readColumnWithRowID("BarCode", scenarioID);
     String Branch = DBUtils.readColumnWithRowID("Branch", scenarioID); 
     String ProductCategory = DBUtils.readColumnWithRowID("ProductCategory", scenarioID);
     String ProductCode = DBUtils.readColumnWithRowID("ProductCode", scenarioID);
     String IsBundle = DBUtils.readColumnWithRowID("IsBundle", scenarioID);
	
	
    EopsSoapClient soapClient = new EopsSoapClient();
	String urlResource = GetCase.envmap.get("URL");
	
	Map<String, String> authhdrs = new HashMap<String, String>();
	String strContentType = "application/soap+xml; charset=UTF-8; action=\"urn:PegaRULES:SOAP:AppWorkFlowFWEOPSOBServices:Services#ImageNotification\";";
	Map<String, String> xmlReqParams = new HashMap<String, String>();
	
	
	xmlReqParams.put("BarCode", BarCode);
	xmlReqParams.put("Branch", Branch);
	xmlReqParams.put("ProductCategory", ProductCategory);
	xmlReqParams.put("ProductCode", ProductCode);
	xmlReqParams.put("IsBundle", IsBundle);
	String myEnvelope = null;
	try {
    	myEnvelope = soapClient.parseUpdateXml("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"eopsAppRefRequest.xml", xmlReqParams);
    	System.out.println(myEnvelope);
	} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    String AppRefNo = soapClient.submitPost(urlResource, authhdrs, strContentType, myEnvelope);
    System.out.println("Generated Application Ref ID: "+ AppRefNo);
    
    updateAppId("UpdateAppRefNoDI",AppRefNo,scenarioID);
    updateAppId("UpdateAppRefNoBDC",AppRefNo,scenarioID);
    updateAppId("UpdateAppRefNoFDC",AppRefNo,scenarioID);
    
    System.out.println("-------------------- appidGeneration ENDS----------------------------");
    

}
}
