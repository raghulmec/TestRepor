package com.scb.rtob.module.test.framework.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import net.minidev.json.parser.ParseException;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class DedupSetValue {

	public static Logger logger = Logger.getLogger(DedupSetValue.class);

	private static JSONObject json = DedupRequestGen.jsonReq;

	static String FullName = null;

	public static void main(String[] args) {


	}

	public static void setContent(){

	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}

	public static void checkBoxSelect(){
		logger.info("setting");

		for(int i=0;i<10;i++){

			String RelNo = DBUtils.readColumnWithRowID("RelationshipNo", GetCase.scenarioID);
			logger.info("The RelNo in DB is " + RelNo);

			String JsonRelNo = JsonPath.parse(json).read("$.content.CustomersForDuplicateCheck[0].DuplicateRelationships["+i+"].RelationshipNumber");

			logger.info(JsonRelNo);

			if(RelNo.equals(JsonRelNo)){
				JsonPath.parse(json).set("$.content.CustomersForDuplicateCheck[0].DuplicateRelationships["+i+"].Cuco","true");
				String cucovalue = JsonPath.parse(json).read("$.content.CustomersForDuplicateCheck[0].DuplicateRelationships["+i+"].Cuco");
				logger.info(cucovalue);
				JsonPath.parse(json).set("$.content.CustomersForDuplicateCheck[0].DuplicateRelationships["+i+"].pySelected","true");
				String pyselectedvalue = JsonPath.parse(json).read("$.content.CustomersForDuplicateCheck[0].DuplicateRelationships["+i+"].pySelected");
				logger.info(pyselectedvalue);
				logger.info("Relationship number is same and json is updated");
				break;
			}

			else {
				logger.info("Relationship number is not same");
			}

		}	


	}




}
