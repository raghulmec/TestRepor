package com.scb.rtob.module.test.framework.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import  java.sql.Connection;
import java.sql.ResultSetMetaData;
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;		
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.scb.rtob.module.test.framework.glue.*;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.Given;

public class  DBUtils {
	
	public static Logger logger = Logger.getLogger(DBUtils.class);
	
	public static int rowCount = 0, ebbsRowCount=0;
	public static String Scenarioid;
	public static Properties CONFIG ;
	
	public static List<HashMap<String, Object>> testdatamap = new ArrayList<HashMap<String, Object>>();
	
	public static List<HashMap<String, Object>> eBBstestdatamap = new ArrayList<HashMap<String, Object>>();
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException, IOException
	{
		String[] arg = {"",""};
		
		GetCase.loadProps();
		Mapper.setMapper();
		
		String appID = "IN201710101010101";
		String id="API-01";
		
		String query = GetCase.envmap.get("updateapp");
		
		System.out.println(query);
		
		query = query.replace("appID", appID);
		query = query.replace("Sc_id", id);
		
		System.out.println(query);
		
		/*convertDBtoMap("diquery");
		convertDBtoMap("updateapp");*/
		
		//convertEBBSDBtoMap("ebbsquery");
		
		//EbbsMapper.main(arg);
	}
	
	
	
	@Then("^Convert Database into Map$")
	public static void convertDBtoMap(String tablename) throws ClassNotFoundException, SQLException, IOException{
		
		rowCount = 0;
		testdatamap.clear();
		
		String dbUrl = GetCase.envmap.get("DataBaseURL");
		System.out.println(dbUrl);
		String username = GetCase.envmap.get("Username").trim();
		System.out.println(username);
		String password = GetCase.envmap.get("password").trim();
		System.out.println(password);
		//String query = "select * from "+tablename;
		
		
		String query = GetCase.envmap.get(tablename).trim();
		System.out.println("Query Results :"+query);
			
		Class.forName(getClassName(dbUrl.substring(5, 8)));
   	
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	System.out.println("Connnected with DB");
  	
	    Statement stmt = con.createStatement();


 		if(query.toLowerCase().contains("select")){
 			
 			ResultSet rs= stmt.executeQuery(query);			 		
 	 		ResultSetMetaData metadata = rs.getMetaData();
 	 		int columnCount = metadata.getColumnCount();
 	 		
		while (rs.next()){
			rowCount++;
			HashMap<String, Object> row = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++){
				//System.out.println(rs.getString(i));
				row.put(metadata.getColumnName(i), rs.getObject(i));
				}
			testdatamap.add(row);
			}
 		}
 		
 		else if(query.toLowerCase().contains("update")){
 			
 			stmt.executeUpdate(query); 
 		}
		con.close();
		
		System.out.println(testdatamap);
		
		//Mapper.setMapper();
		}
	
	private static String readColumn(String column1,int row){
		
		String column = Mapper.retrieveFromMapper(column1.toLowerCase());
	
		//System.out.println("column : "+column);
		
		HashMap<String, Object> map = testdatamap.get(row);
		String result=null;
        for (Entry<String, Object> entry : map.entrySet()) {
        	//System.out.println(entry.getKey());
        	if(entry.getKey().equalsIgnoreCase(column)){
        		//System.out.println("value : "+entry.getValue());
        		result = entry.getValue().toString();
        	}

        }
       return result;
	}

	
	public static String readColumnWithRowID(String column,String rowID){
		
		String result="test";
		try{
			for(int i=0;i<rowCount;i++){
				
				if(readColumn("Scenarioid", i).equalsIgnoreCase(rowID)){
					//System.out.println("Match Success");
					//logger.info("matched with "+readColumn("Scenarioid", i));
					result = readColumn(column, i);
					break;
				}
			}
		}
		catch(IndexOutOfBoundsException I){
			logger.info("Row ID didn't match");
			I.printStackTrace();
		}
		catch(Exception E){
			logger.info("Reading from Database has failed");
			E.printStackTrace();
		}
//		logger.info("result : "+result);
		return result;
	}
	
	private static String getClassName(String DB){
		
		String dbDriver = null;
		
		try{
		if(DB.equalsIgnoreCase("DB2")){
			dbDriver="com.ibm.db2.jcc.DB2Driver";
		}
		else if(DB.equalsIgnoreCase("sql")){
			dbDriver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		}
		else
			dbDriver=null;
		}catch(NullPointerException e)
		{
			e.printStackTrace();
			System.out.println("dbDriver is not find from getClassName method");
		}
		
		return dbDriver;
	}
	
	@Then("^Convert EBBSDatabase into Map$")
	public static void convertEBBSDBtoMap(String queryType, String rel) throws ClassNotFoundException, SQLException, IOException{
		
		ebbsRowCount =0;
		eBBstestdatamap.clear();
		
		String dbUrl = GetCase.envmap.get("EBBS_DB_URL");
		System.out.println(dbUrl);
		String username = GetCase.envmap.get("EBBS_Username").trim();
		System.out.println(username);
		String password = GetCase.envmap.get("EBBS_password").trim();
		System.out.println(password);
		String Query=null;
		
		if(queryType.equalsIgnoreCase("Customer"))
		{
			 Query = System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"sqlStatments"+File.separator+"Ebbs_Customer.sql";
		}
		else
		{
			 Query = System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"sqlStatments"+File.separator+"Ebbs_Account.sql";
		}
		// "C:\\Automation_project\\Rtob-API-auto\\rtob-api-genie-auto\\src\\test\\resources\\sql\\customer.sql";

		FileReader EBBSQuery = new FileReader(Query);
		BufferedReader bufferedReader = new BufferedReader(EBBSQuery);

		String CurrentLine=new String();
		StringBuilder sb = new StringBuilder(); 

		while((CurrentLine = bufferedReader.readLine()) != null) {
		sb.append(CurrentLine);
		System.out.println(CurrentLine);
		} 
		
		bufferedReader.close();
		String query = sb.toString();
		
		query = query.replace("<RELNO>", rel);
		
		//String query = GetCase.envmap.get(tablename).trim(); 
		//query = query.replace("<RELNO>", "0199385224856103"); //Customer
		//query = query.replace("<RELNO>", "0199385224451385"); //Account
		System.out.println("Query Results :"+query);
			
		Class.forName(getClassName(dbUrl.substring(5, 8)));
   	
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	System.out.println("Connnected with EBBS DB");
  	
	    Statement stmt = con.createStatement();					
	
 		ResultSet rs= stmt.executeQuery(query);			 		
 		ResultSetMetaData metadata = rs.getMetaData();
 		int columnCount = metadata.getColumnCount();

 		if(query.toLowerCase().contains("select")){
		while (rs.next()){
			ebbsRowCount++;
			HashMap<String, Object> row = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++){
				//System.out.println(rs.getString(i));
				row.put(metadata.getColumnName(i), rs.getObject(i));
				}
			eBBstestdatamap.add(row);
			}
 		}
		con.close();
		
		System.out.println(eBBstestdatamap);
		
		//Mapper.setMapper();
		}
	
	
	
	
	
	
public static void updateQuery(String query) throws ClassNotFoundException, SQLException, IOException{
		
		
		testdatamap.clear();
		String dbUrl = GetCase.envmap.get("DataBaseURL");
		System.out.println(dbUrl);
		String username = GetCase.envmap.get("Username").trim();
		System.out.println(username);
		String password = GetCase.envmap.get("password").trim();
		System.out.println(password);
		Class.forName(getClassName(dbUrl.substring(5, 8)));
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	System.out.println("Connnected with DB");
    	Statement stmt = con.createStatement();
	    stmt.executeUpdate(query); 
		con.close();
		}
	
@SuppressWarnings("null")
public static String getqueryforinsert(List<LinkedHashMap<String, String>> xceldata,int rownum) throws ClassNotFoundException, SQLException, IOException{
       String value = null;
       final String SEPARATOR = ",";
       LinkedHashMap<String, String> map = xceldata.get(rownum);
       String result=null;
       for (Entry<String, String> entry : map.entrySet()) {
              //System.out.println(entry.getKey()); 
    	   		if(entry.getValue().toString().equals(null))
    	   			result = "'"+"null"+"'";
    	   		else
    	   			result = "'"+entry.getValue().toString()+"'";
              String resultval = entry.getKey().toString();
              logger.info(resultval);
              
              
              result+=",";
//                         Long temp= Long.parseLong(result);
              value= value+result;
                              

              
       } 
       logger.info(value.length());
       if(value.endsWith(SEPARATOR)){
              value = value.substring(0, value.length() - SEPARATOR.length());
              value = value.substring(4,value.length());
              logger.info(value);
       }
       return value;
}


@SuppressWarnings("null")
public static String getheaders(List<LinkedHashMap<String, String>> xceldata,int rownum) throws ClassNotFoundException, SQLException, IOException{
    String value = null;
    final String SEPARATOR = ",";
    LinkedHashMap<String, String> map = xceldata.get(rownum);
    String result=null;
    for (Entry<String, String> entry : map.entrySet()) {
           //System.out.println(entry.getKey()); 
           result = entry.getKey().toString();
           String resultval = entry.getKey().toString();
           logger.info(resultval);
           result+=",";
//                      Long temp= Long.parseLong(result);
           value= value+result;
           
    } 
    logger.info(value.length());
    if(value.endsWith(SEPARATOR)){
           value = value.substring(0, value.length() - SEPARATOR.length());
           value = value.substring(4,value.length());
           logger.info(value);
    }
    return value;
}

@SuppressWarnings("null")
public static String getqueryforupdate(List<LinkedHashMap<String, String>> xceldata,int rownum) throws ClassNotFoundException, SQLException, IOException{
       String value = null;
       final String SEPARATOR = ",";
       LinkedHashMap<String, String> map = xceldata.get(rownum);
       String result=null;
       for (Entry<String, String> entry : map.entrySet()) {
              //System.out.println(entry.getKey()); 
              result = entry.getValue().toString();
              String resultkey = entry.getKey().toString(); 
              String recordval = ""+resultkey+"='"+result+"'";
              recordval+=",";
              value= value+recordval;
       } 
       logger.info(value.length());
       if(value.endsWith(SEPARATOR)){
              value = value.substring(0, value.length() - SEPARATOR.length());
              value = value.substring(4,value.length());
              logger.info(value);
       }return value;
}





@Then("^Bulk insert or update of data into db$")
public static void bulk_Insert_Update(List<LinkedHashMap<String, String>> mapdata) throws ClassNotFoundException, SQLException, IOException{

	rowCount = 0;

	String dbUrl = GetCase.envmap.get("DataBaseURL");
	System.out.println(GetCase.envmap.get("DataBaseURL"));
	System.out.println(GetCase.envmap.get("Username").trim());
	String username = GetCase.envmap.get("Username").trim();
	
	
	
	System.out.println(username);
	String password = GetCase.envmap.get("password").trim();
	System.out.println(password);
	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

	Connection con = DriverManager.getConnection(dbUrl,username,password);
	System.out.println("Connnected with DB");

	Statement stmt = con.createStatement();

//	try {
		for(int i=0;i<=mapdata.size()-1;i++){

		//	if(CommonUtils.readColumnUpdate("UpdateCheck",i).equalsIgnoreCase("YES")){
				Scenarioid=CommonUtils.readColumnUpdate("Scenarioid",i);
				//logger.info(Scenarioid);
				String query = "Select COUNT(Scenarioid) from BasicDataCapture where Scenarioid ='"+Scenarioid+"'";
				logger.info(query);
				ResultSet rs= stmt.executeQuery(query);	
				while(rs.next()){
					logger.info(rs.getInt(1));
					int scenariocount = rs.getInt(1); 
					if(scenariocount>0){				

						String update = getqueryforupdate(mapdata,i);
						String updatequery = "UPDATE BasicDataCapture SET "+update+" where Scenarioid = '"+Scenarioid+"'";
						logger.info(updatequery);
						 stmt.execute(updatequery); 
						logger.info("Row updated in db for the scenario id"+ Scenarioid);
						break;
						
					}
						else if(scenariocount==0){
							String insertvalue = getqueryforinsert(mapdata,i);
							String headerValue = getheaders(mapdata,0);
					//		logger.info("headers :"+headerValue);
							String insertquery = "INSERT INTO BasicDataCapture ("+headerValue+") VALUES("+insertvalue+")";
							//String insertquery = "INSERT INTO BasicDataCapture ("+GetCase.envmap.get("Basicdata")+") VALUES("+insertvalue+")";
							logger.info(insertquery);
							stmt.execute(insertquery);
							logger.info("Row inserted in db for the scenario id"+ Scenarioid);
							break;
						}
					

				}
			//}
		}
//	}

//		catch(Exception e){
//			logger.info(e);
//		}
		
	con.close();
	
	}

	public static ResultSet connectDBAndSendQuery(String query) throws Throwable
	{
		String dbUrl = GetCase.envmap.get("DataBaseURL");
		logger.info(dbUrl);
		String username = GetCase.envmap.get("Username").trim();
		logger.info(username);
		String password = GetCase.envmap.get("password").trim();
		logger.info(password);

		
		logger.info("Query :"+query);
			
		Class.forName(getClassName(dbUrl.substring(5, 8)));
		
		Connection con = DriverManager.getConnection(dbUrl,username,password);
		logger.info("Connnected with DB");
		
	    Statement stmt = con.createStatement();					
	    ResultSet rs= stmt.executeQuery(query);
		
	    return rs;
	}
	
	
	/*--------------------------------------Swapnil Changes---------------------------------------------*/
	
	public static String readColumnWithRowIDNew(String column,String rowID){
		String result="";
		try{
			for(int i=0;i<rowCount;i++){
				
				if(readColumnNew("Scenarioid", i).equalsIgnoreCase(rowID)){
					result = readColumnNew(column, i);
					break;
				}
			}
		}
		catch(IndexOutOfBoundsException I){
			logger.info("Row ID didn't match");
			I.printStackTrace();
		}
		catch(Exception E){
			logger.info("Reading from Database has failed");
			E.printStackTrace();
		}
		return result;
	}
	
	private static String readColumnNew(String column1,int row){
		
		HashMap<String, Object> map = testdatamap.get(row);
		String result=null;
        for (Entry<String, Object> entry : map.entrySet()) {
        	if(entry.getKey().equalsIgnoreCase(column1)){
        		result = entry.getValue().toString();
        	}

        }
       return result;
	}
	
	
}