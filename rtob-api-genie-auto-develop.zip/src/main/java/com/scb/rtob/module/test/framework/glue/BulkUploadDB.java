package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import org.apache.log4j.Logger;
import com.scb.rtob.module.test.framework.utils.CommonUtils;
import com.scb.rtob.module.test.framework.utils.DBUtils;
import cucumber.api.java.en.Given;

public class BulkUploadDB  {
	
	public static Logger logger = Logger.getLogger(BulkUploadDB.class);

	public static String excelPath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates";

	
	static String FullName = null;

	public static void main(String[] args) throws Throwable {
	
		bulkupload();

	}
	
	@Given("^Call Bulk Upload$")
	public static void bulkupload() throws Throwable {
		
		CommonUtils.convertExcelToMap(excelPath, "API_Template_DI_Basic_Blind_FDC_31May_PL_TopUp_rev.xlsx", "Basic_Blind");
		DBUtils.bulk_Insert_Update(CommonUtils.mydata);
	
	}
		
}