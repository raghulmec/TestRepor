package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.FraudRiskCheckerSetValue;
import com.scb.rtob.module.test.framework.utils.FullDataSetValue;

import cucumber.api.java.en.Given;


	/************************************@Author: Vaka Ramakrishna***************************************/		
public class FraudRiskCheckerWBGen {
	
public static Logger logger = Logger.getLogger(FraudRiskCheckerWBGen.class);
	
	static String FRaudRiskCheckeerScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	
	/**************************************************************************************************
	 * Function to read,parse json file and authenticate.
	 * And Returns Authenticated application by logging in.
	 * @throws Throwable 
	 **************************************************************************************************/	
	@Given("^Call the PromoteCase api for FraudRiskChecker$")
	public static void promoteFraudRiskChecker() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("FraudRiskChecker_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueFraudRiskChecker();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		/****************************Authentication Part Starts****************************************/		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	
	/**************************************************************************************************
	 * Function to check if application has moved to Fulfilment.
	 * And Returns if application has moved to Fulfilment
	 * @throws Throwable
	 **************************************************************************************************/	
	@Given("^validate if the application moved from Fraud Risk Checker to Fulfilment$")
	public static void validateWorkbasket() throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		
		logger.info("Current Workbasket : "+currentWorkBasket);
				
		if(currentWorkBasket.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_CDDException")))
		{
			//**********'SCREEND- Fulfillment WB'
			logger.info("Selected 'SCREEND' and moved to SYSTEM WAIT");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_CDDException")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to Fulfillment", currentWorkBasket.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_CDDException")));
			
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_FraudRiskVerification")))
		{	
			//**********'SAMPLED- Fraud Risk Verification'
			logger.info("Selected 'SAMPLED' and moved to FraudRiskVerification");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_FraudRiskVerification")+", Actual : "+currentWorkBasket);
			Assert.assertEquals("Application did'nt moved to FraudRiskVerification", GetCase.envmap.get("CurrentWorkBasket_FraudRiskVerification"), currentWorkBasket);
		}
		else
		{
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+": Does Not Matches with Expected Workbasket");
			Assert.assertFalse("Current Workbasket : Does Not Matches with Expected Workbasket", false);
		}
	
	}

	
    /**************************************************************************************************
	 * Function to modify details by promoting via json file.
	 * And Returns application with updated data in Fraud Risk Checker WorkBasket.
	 * @throws ClassNotFoundException, SQLException, IOException 
	 **************************************************************************************************/
	public static void setValueFraudRiskChecker() throws ClassNotFoundException, SQLException, IOException{
		
		
		DBUtils.convertDBtoMap("acdquery");
		
		FraudRiskCheckerSetValue.setJSON(jsonReq);
		FraudRiskCheckerSetValue.fraudRiskVerificationList();

		
}

}
