package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.SoapServiceCall;

import cucumber.api.java.en.Given;


public class RLS_GetDetails {
	SoapServiceCall soapClient = new SoapServiceCall();
	public static Logger logger = Logger.getLogger(RLS_GetDetails.class);
	
	String sceID = GetCase.scenarioID; 
	
	String userName= GetCase.envmap.get("soapUserName");
	String password =GetCase.envmap.get("soapPassWord"); 
	
	
	@Given("^Call RLS Unsecured Loan Memo Create Memo Request api for Fullfilment$")
	public void rlsCreateMemoReq() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSUnsecuredLoanMemo_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanMemoV1_ws_provider_v1_UnsecuredLoanMemo_Binder_createMemo"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_CreateMemoReq.xml", xmlReqParams);
			
			/*
			RLS_getQuotationDetailsReq.xml
			RLS_LoanListInquiry_request.xml
			RLS_PostTransactionReq.xml
			RLS_PreclosureReq.xml
			RLS_SecuredLoanCollateralManagement_GetDetails_request.xml
			RLS_SecuredLoanGetAmortizationSchedule_1_request.xml
			RLS_SecuredLoanInquirygetDelinquencyDetails_1_request.xml
			RLS_SecuredLoanInquirygetDetails_1_request.xml
			RLS_UnsecuredLoanGetAmortization_1_request.xml
			RLS_UnsecuredLoanGetDelinquency_1_request.xml
			RLS_UnsecuredLoanGetDetails_1_request.xml
			*/
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		
		compareRTOBTestDataVsXMLResponse_rlsCreateMemoReq(resParams);
		
	}
	
	 private void compareRTOBTestDataVsXMLResponse_rlsCreateMemoReq(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
		
	}

	@Given("^Call RLS Unsecured Loan in Query Request api for Fullfilment$")
	public void rlsgetQuotationDetailsReq() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSunsecuredLoanInquiry_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansSecuredLoanInquiryV1_ws_provider_v1_SecuredLoanInquiry_Binder_getQuotationDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_getQuotationDetailsReq.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			e.printStackTrace();
		}
		
		compareRTOBTestDataVsXMLResponse_rlsgetQuotationDetailsReq(resParams);
	}
		
	private void compareRTOBTestDataVsXMLResponse_rlsgetQuotationDetailsReq(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
		
	}
		@Given("^Call RLS Loan Profile Request api for Fullfilment$")
	public void rlsLoanListInquiry() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSloanProfile_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansLoanProfileV1_ws_provider_v1_LoanProfile_Binder_getLoanListInquiry"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_LoanListInquiry_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		
		compareRTOBTestDataVsXMLResponse_rlsLoanListInquiry(resParams);
	}
		
		private void compareRTOBTestDataVsXMLResponse_rlsLoanListInquiry(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
			DBUtils.convertDBtoMap("fulldatatablename");
			boolean t1,t2 = false;
			boolean finalflag = true;
			 
				 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
				 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
			 finalflag = t1 && t2;
			 
			 if(finalflag)
			 {
				 System.out.println("XML responses are compared with RTOB test data");
			 }
			
		}
		
		@Given("^Call RLS Post and Unsecured Transaction Request api for Fullfilment$")
	public void rlsPostTransactionReq() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSunsecuredLoanTransaction_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanTransactionV1_ws_provider_v1_UnsecuredLoanTransaction_Binder_postTransaction"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_PostTransactionReq.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_rlsPostTransactionReq(resParams);
	}
		
		private void compareRTOBTestDataVsXMLResponse_rlsPostTransactionReq(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
			DBUtils.convertDBtoMap("fulldatatablename");
			boolean t1,t2 = false;
			boolean finalflag = true;
			 
				 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
				 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
			 finalflag = t1 && t2;
			 
			 if(finalflag)
			 {
				 System.out.println("XML responses are compared with RTOB test data");
			 }
			
		}
		
@Given("^Call RLS PreClosure and Unsecured Transaction Request api for Fullfilment$")
	public void rlsPreclosureReq() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSPreClosureunsecuredLoanTransaction_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanTransactionV1_ws_provider_v1_UnsecuredLoanTransaction_Binder_initiatePreClosure"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_PreclosureReq.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_rlsPreclosureReq(resParams);
	}

private void compareRTOBTestDataVsXMLResponse_rlsPreclosureReq(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
	DBUtils.convertDBtoMap("fulldatatablename");
	boolean t1,t2 = false;
	boolean finalflag = true;
	 
		 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
		 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
	 finalflag = t1 && t2;
	 
	 if(finalflag)
	 {
		 System.out.println("XML responses are compared with RTOB test data");
	 }
	
}
	
	@Given("^Call RLS Secured Loan Collateral Management Get Detail Request api for Fullfilment$")
	public void SecuredLoanCollateralManagementGetDetailsrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSsecuredLoanCollateralManagement_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansSecuredLoanCollateralManagementV1_ws_provider_v1_SecuredLoanCollateralManagement_Binder_getDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_SecuredLoanCollateralManagement_GetDetails_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_SecuredLoanCollateralManagementGetDetailsrequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_SecuredLoanCollateralManagementGetDetailsrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
		
	}
	
	@Given("^Call RLS Secured Loan Get Amortization Schedule Request api for Fullfilment$")
	public void SecuredLoanGetAmortizationSchedulerequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSsecuredLoanCollateralManagement_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansSecuredLoanInquiryV1_ws_provider_v1_SecuredLoanInquiry_Binder_getAmortizationSchedule"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_SecuredLoanGetAmortizationSchedule_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_SecuredLoanGetAmortizationSchedulerequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_SecuredLoanGetAmortizationSchedulerequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
		
	}
	@Given("^Call RLS Secured Loan Inquiry get Delinquency Details Request api for Fullfilment$")
	public void SecuredLoanInquirygetDelinquencyDetailsrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSsecuredLoanCollateralManagement_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansSecuredLoanInquiryV1_ws_provider_v1_SecuredLoanInquiry_Binder_getDelinquencyDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_SecuredLoanInquirygetDelinquencyDetails_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_SecuredLoanInquirygetDelinquencyDetailsrequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_SecuredLoanInquirygetDelinquencyDetailsrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
	}
	
	
	@Given("^Call RLS Secured Loan Inquiry get Details Request api for Fullfilment$")
	public void SecuredLoanInquirygetDetailsrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSsecuredLoanCollateralManagement_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansSecuredLoanInquiryV1_ws_provider_v1_SecuredLoanInquiry_Binder_getDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_SecuredLoanInquirygetDetails_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		
		compareRTOBTestDataVsXMLResponse_SecuredLoanInquirygetDetailsrequest(resParams);
		
	}
	
	
	private void compareRTOBTestDataVsXMLResponse_SecuredLoanInquirygetDetailsrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
	}
	
	@Given("^Call RLS Unsecured Loan Get Amortization Request api for Fullfilment$")
	public void UnsecuredLoanGetAmortizationrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSunsecuredLoanGetAmortization_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanInquiryV1_ws_provider_v1_UnsecuredLoanInquiry_Binder_getAmortizationSchedule"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_UnsecuredLoanGetAmortization_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		
		compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetAmortizationrequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetAmortizationrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
	}
	
	@Given("^Call RLS Unsecured Loan Get Delinquency Request api for Fullfilment$")
	public void UnsecuredLoanGetDelinquencyrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSunsecuredLoanGetAmortization_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanInquiryV1_ws_provider_v1_UnsecuredLoanInquiry_Binder_getDelinquencyDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_UnsecuredLoanGetDelinquency_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		
		compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetDelinquencyrequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetDelinquencyrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
	}
	
	@Given("^Call RLS Unsecured Loan Get Details Request api for Fullfilment$")
	public void UnsecuredLoanGetDetailsrequest() throws IOException, ClassNotFoundException, SQLException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("RLSunsecuredLoanGetAmortization_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingLoansUnsecuredLoanInquiryV1_ws_provider_v1_UnsecuredLoanInquiry_Binder_getDetails"); 
		String strContentType = "text/xml;charset=UTF-8;";
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"}; //Needed input
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"RLS_UnsecuredLoanGetDetails_1_request.xml", xmlReqParams);
			
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"}; //Needed input
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			
			e.printStackTrace();

		}
		compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetDetailsrequest(resParams);
	}
	
	private void compareRTOBTestDataVsXMLResponse_UnsecuredLoanGetDetailsrequest(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException {
		DBUtils.convertDBtoMap("fulldatatablename");
		boolean t1,t2 = false;
		boolean finalflag = true;
		 
			 t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
			 t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
		 finalflag = t1 && t2;
		 
		 if(finalflag)
		 {
			 System.out.println("XML responses are compared with RTOB test data");
		 }
	}
}


