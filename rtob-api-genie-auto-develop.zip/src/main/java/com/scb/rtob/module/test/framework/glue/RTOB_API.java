package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.xml.sax.SAXException;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.EopsSoapClient;
import com.scb.rtob.module.test.framework.utils.RMSupervisorSetValue;
import com.scb.rtob.module.test.framework.utils.RTOBAPISetValues;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

/************************************@Author: Vaka Ramakrishna***************************************/	
public class RTOB_API {

//static String fdcScenarioID = "1";
	
	public static Logger logger = Logger.getLogger(RTOB_API.class);
	public static JSONObject jsonReq;
	
	/**************************************************************************************************
	 * Function to read,parse json file and authenticate.
	 * And Returns Authenticated application by logging in.
	 * @throws Throwable 
	 **************************************************************************************************/
	@Given("^Call the PromoteCase api for Onboarding$")
	public static void promoteDI() throws Throwable {
				
	
		JSONParser parser = new JSONParser();
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"CreateOnboarding"+File.separator+""+GetCase.envmap.get("CreateApp_Template"));
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		httpRequest.body(jsonReq);
		GetCase.response = httpRequest.request(Method.POST,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());
	//	GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);
	//	GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
    
		String AppRefNo=(String) GetCase.responseJSON.get("ID");
		logger.info("Generated Application Ref No : "+AppRefNo);
		
		logger.info("Scenario id"+ GetCase.scenarioID);
		
		   EopsSoapClient.updateAppId("UpdateAppRefNoBDC",AppRefNo,GetCase.scenarioID);
		   EopsSoapClient.updateAppId("UpdateAppRefNoFDC",AppRefNo,GetCase.scenarioID);
		    
		
		
		   	parser = new JSONParser();
		   	reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"CreateOnboarding"+File.separator+""+GetCase.envmap.get("CreateOnboarding_Template"));
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		DBUtils.convertDBtoMap("bdquery");
		//setValueProductSelection();
		logger.info("updated json: "+jsonReq);
		
		
		
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		
		 httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_DataCapture"));
		httpRequest.body(jsonReq);
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
			obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());
		GetCase.scenarioCurrent.write("Application Ref Number: "+DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
		
	}
	
		
	
	@Given("^Genarate the Application Referance No from SoapUI '(.*)'$")
	public void genarateTheApplicationRefNoFromSoapUI(String soapui) throws ClassNotFoundException, ParserConfigurationException, SAXException, IOException, SQLException{
/****************************Set eClassifer*************************************/		
		
		if(soapui.equals("Y"))
		{	
			EopsSoapClient.appidGeneration();
		}

		EClassifier.eClassify();
/*******************************************************************************/
	}
	
	@When("^Call the PromoteCase api for '(.+)'$")
	public static void promoteRMSupervisor(String workbasketName) throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"Globaltemplate"+File.separator+""+GetCase.envmap.get(workbasketName));
		
		jsonReq = (JSONObject)parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		if(workbasketName.equalsIgnoreCase("Document_Indexing")){
			workbasketName = workbasketName.replace("_", " ");
			System.out.println(workbasketName);
					
			RTOBAPISetValues.setDocumentCompanyName(jsonReq);
		}
		
				
		if(workbasketName.equalsIgnoreCase("BasicDataCapture")||workbasketName.equalsIgnoreCase("BlindDataCapture")){
			RTOBAPISetValues.setValueBasic(jsonReq);		
		}
		
		if(workbasketName.equalsIgnoreCase("DeDupe")){
			DBUtils.convertDBtoMap("bdquery");		
		}
		if(workbasketName.equalsIgnoreCase("FullDataCapture")){
			RTOBAPISetValues.setValueFDCMaker(jsonReq);		
		}
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		/****************************Authentication Part Starts****************************************/	
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		
		httpRequest.header("CurrentWorkBasket",workbasketName);
		
		if (workbasketName.equalsIgnoreCase("BasicDataCapture")||workbasketName.equalsIgnoreCase("BlindDataCapture")) {

			httpRequest.header("ScenarioID", DBUtils.readColumnWithRowID(
					"BDCTemplateRefNo", GetCase.scenarioID));
			
		}else if(workbasketName.equalsIgnoreCase("FullDataCapture")){
			httpRequest.header("ScenarioID", DBUtils.readColumnWithRowID(
					"FDCTemplateRefNo", GetCase.scenarioID));
		}
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Application Ref Number: "+DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		logger.info(GetCase.response.headers());
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
        GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
        logger.info("Status Code ok: "+GetCase.response.getStatusCode());
        logger.info(GetCase.responseJSON);
		
		
	}
	
	
	
	

	/**************************************************************************************************
	 * And Returns if application has moved to Next WorkBasket
	 * @throws Throwable
	 **************************************************************************************************/
	@Given("^validate the application is moved from '(.+)' to '(.+)'$")
	public static void validateWorkbasketDedup(String currentWB, String expectedWB) throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		Assert.assertEquals(expectedWB,GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	}

	

}
