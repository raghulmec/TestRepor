package com.scb.rtob.module.test.framework.UpdatedCodes;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.GetCase;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;

public class GlobalClass {

	public static Logger logger = Logger.getLogger(GlobalClass.class);


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void InsertInMap(LinkedHashMap Map,String Key,String Values,boolean flag)
	{
		if(flag==true)
		{
			String DbValue = ""+DBUtils.readColumnWithRowIDNew(Values, GetCase.scenarioID);
			if(DbValue==null || DbValue.contains("null") ){DbValue="";}
			logger.info(Values+"="+DbValue);
			Map.put(Key,DbValue);
		}
		else if(flag==false)
		{
			logger.info(Key+"="+Values);
			Map.put(Key, Values);
		}
	}


	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList FullDataCustomer() throws ClassNotFoundException, SQLException, IOException, ParseException
	{
		ArrayList List =new ArrayList();


		String isPrimaryOrCoApp="";
		for(int i=0;i<1;i++)
		{
			if(i!=0){isPrimaryOrCoApp="Coapplicant"+i+"_";}
			LinkedHashMap customerMap =new LinkedHashMap();

			String firstName= ""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"First_Name", GetCase.scenarioID);
			String fullName = FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name");
			logger.info(isPrimaryOrCoApp+"First_Name : "+firstName);
			logger.info("Iteration is :"+i);

			if(firstName.length()>2)
			{


				InsertInMap(customerMap,"Title",isPrimaryOrCoApp+"Title",true);
				InsertInMap(customerMap,"DateOfBirth",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"DOB", GetCase.scenarioID)),false);
				InsertInMap(customerMap,"EmbossedName",fullName,false);
				InsertInMap(customerMap,"FirstName",isPrimaryOrCoApp+"First_Name",true);
				InsertInMap(customerMap,"FullName",fullName,false);
				InsertInMap(customerMap,"LastName",isPrimaryOrCoApp+"Last_Name",true);
				InsertInMap(customerMap,"LegalName",fullName,false);
				InsertInMap(customerMap,"MiddleName",isPrimaryOrCoApp+"Middle_Name",true);
				InsertInMap(customerMap,"Nationality",isPrimaryOrCoApp+"Nationality_Code1",true);
				InsertInMap(customerMap,"CountryOfBirthDescription",isPrimaryOrCoApp+"Country_Of_Birth_Description",true);
				InsertInMap(customerMap,"CountryOfResidenceDescription",isPrimaryOrCoApp+"Residence_Country_Description",true);
				InsertInMap(customerMap,"CountryOfBirth",isPrimaryOrCoApp+"Country_Of_Birth_Code",true);
				InsertInMap(customerMap,"CountryOfResidence",isPrimaryOrCoApp+"Residence_Country_Code",true);
				InsertInMap(customerMap,"ContactNumber",isPrimaryOrCoApp+"Contact_Details",true);
				InsertInMap(customerMap,"DomicileCountryCode",isPrimaryOrCoApp+"Country_Of_Birth_Code",true);

				String Occupation_Description= ""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Occupation_Description", GetCase.scenarioID);
				String Occupation_Code= LOV_Codes.ProfessionCode(isPrimaryOrCoApp+"Occupation_Description");
				String ISIC_Code=LOV_Codes.getISICDesc(isPrimaryOrCoApp+"ISIC_Description");
				String ISIC_Description=""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"ISIC_Description", GetCase.scenarioID);
				String ProductCategory=""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"ProductCategory", GetCase.scenarioID);

				System.out.println("Occupation_Code is---->"+Occupation_Code+" & ISIC_Code---->"+ISIC_Code+" ISIC_Description"+ISIC_Description);


				customerMap.put("IDDocumentList",IDDocumentList(isPrimaryOrCoApp));
				customerMap.put("VerfDocumentList",VerfDocumentList(isPrimaryOrCoApp));
				customerMap.put("AssessmentDocumentList",AssessmentDocumentList(isPrimaryOrCoApp));
				customerMap.put("Contacts",setCustomerContact(isPrimaryOrCoApp));
				customerMap.put("CustomerContacts",CustomerContacts());
				customerMap.put("NationalityList",NationalityList(isPrimaryOrCoApp));
				customerMap.put("TaxInformation",TaxInformation());
				customerMap.put("AliasNameInfo",AliasNameInfo(isPrimaryOrCoApp));

				//---------------------------------------------------------------------------->>>
				//FDC Table Query starts
				customerMap.put("DocumentList",getFDCDocumentList(isPrimaryOrCoApp,ProductCategory));

				DBUtils.convertDBtoMap("fdquery");

				InsertInMap(customerMap,"NumberOfDependants",isPrimaryOrCoApp+"No_of_Dependants",true);

				customerMap.put("ProdDocumentList",ProdDocumentList(isPrimaryOrCoApp));

				if(i!=0){isPrimaryOrCoApp="Coapp"+i+"_";}

				String workType=LOV_Codes.WorkTypeCode(isPrimaryOrCoApp+"Work_Type");
				System.out.println("workType is "+workType);

				//CDD(OAT)
				logger.info("--------------------------- CDD(OAT) starts-------------------------------------------------------");
				InsertInMap(customerMap,"Qualification",isPrimaryOrCoApp+"Educational_Qualification",true);
				InsertInMap(customerMap,"AnonymityRequired",isPrimaryOrCoApp+"Client_wishes_anonymity_numbered_accountPrepassbook",true);
				InsertInMap(customerMap,"OtherRiskFactors",isPrimaryOrCoApp+"Other_risk_factorsPre_Local_RegulationsPre_Stringent_rules_applied_in_country",true);//"OtherRiskFactors": "MEDD",

				//AOF Signature
				logger.info("--------------------------- AOF Signature starts-------------------------------------------------------");
				InsertInMap(customerMap,"AvailabilityOfCustomerSignature",isPrimaryOrCoApp+"Availability_of_Customer_Signature",true);
				InsertInMap(customerMap,"AOFSignedDate", "2018-05-15",false);

				//GST Details
				logger.info("--------------------------- GST Details starts-------------------------------------------------------");
				InsertInMap(customerMap,"GSTCustomerType", isPrimaryOrCoApp+"Customer_Type",true);
				InsertInMap(customerMap,"GSTRegistrationNumber", isPrimaryOrCoApp+"GST_Registration_Number",true);
				InsertInMap(customerMap,"SpecificStatus", isPrimaryOrCoApp+"Specific_status",true);
				InsertInMap(customerMap,"State", LOV_Codes.getStateCode(isPrimaryOrCoApp+"State"), false);

				//Banking Services
				logger.info("--------------------------- Banking Services starts-------------------------------------------------------");
				InsertInMap(customerMap,"MobileBanking", isPrimaryOrCoApp+"Mobile_Banking",true);
				InsertInMap(customerMap,"InternetBanking", isPrimaryOrCoApp+"Online_Banking",true);

				//Communication:
				logger.info("--------------------------- Communication starts-------------------------------------------------------");
				InsertInMap(customerMap,"AdviceDetailsAddressType", LOV_Codes.getAddressesType("Advice_Detail_Address_Type"),false);//in db for coapplicant not available+
				InsertInMap(customerMap,"MarketingPreferences", LOV_Codes.getMarketingPreferencesCode("Marketing_Preferences"),false);


				//FamilyDetails (Not Manatory)
				logger.info("--------------------------- FamilyDetails starts-------------------------------------------------------");
				InsertInMap(customerMap,"MaidenFirstName",isPrimaryOrCoApp+"MaidenFirstName",true);
				InsertInMap(customerMap,"FatherPrefix",isPrimaryOrCoApp+"FatherPrefix",true);//lov
				InsertInMap(customerMap,"FatherFirstName",isPrimaryOrCoApp+"FatherFirstName",true);
				InsertInMap(customerMap,"FatherLastName",isPrimaryOrCoApp+"FatherLastName",true);
				InsertInMap(customerMap,"FatherMiddleName",isPrimaryOrCoApp+"FatherMiddleName",true);
				InsertInMap(customerMap,"MotherPrefix",isPrimaryOrCoApp+"MotherPrefix",true);//lov
				InsertInMap(customerMap,"MotherFirstName",isPrimaryOrCoApp+"MotherFirstName",true);
				InsertInMap(customerMap,"MotherLastName",isPrimaryOrCoApp+"MotherLastName",true);
				InsertInMap(customerMap,"MotherMiddleName",isPrimaryOrCoApp+"MotherMiddleName",true);
				InsertInMap(customerMap,"SpousePrefix",isPrimaryOrCoApp+"SpousePrefix",true);//lov
				InsertInMap(customerMap,"SpouseFirstName",isPrimaryOrCoApp+"SpouseFirstName",true);
				InsertInMap(customerMap,"SpouseLastName",isPrimaryOrCoApp+"SpouseLastName",true);
				InsertInMap(customerMap,"SpouseMiddleName",isPrimaryOrCoApp+"SpouseMiddleName",true);
				InsertInMap(customerMap,"SpouseOccupation",isPrimaryOrCoApp+"Spouse_Occupation",true);
				InsertInMap(customerMap,"MotherMaidenName",isPrimaryOrCoApp+"MotherMaidenName",true);//DB colmn not there
				InsertInMap(customerMap,"NumberOfChildren",isPrimaryOrCoApp+"Number_of_children",true);
				InsertInMap(customerMap,"Gender",LOV_Codes.GenderCode(isPrimaryOrCoApp+"Gender"),false);
				InsertInMap(customerMap,"MaritalStatus",LOV_Codes.MaritalStatusCode(isPrimaryOrCoApp+"Marital_Status"),false);
				InsertInMap(customerMap,"ResidenceStatus",LOV_Codes.getResidentialStatusCode(isPrimaryOrCoApp+"Residential_Status"),false);
				InsertInMap(customerMap,"ConstitutionCode",LOV_Codes.ConstitutionCode(isPrimaryOrCoApp+"Constitution_Code"),false);
				InsertInMap(customerMap,"ConnectedLendingRelationship",LOV_Codes.ConnectedLendingRelationshipCode(isPrimaryOrCoApp+"connected_Lending_Relationship"),false);


				customerMap.put("Addresses",Address(isPrimaryOrCoApp));
				customerMap.put("Employment",Employment_FDC(isPrimaryOrCoApp,workType,Occupation_Code,Occupation_Description,ISIC_Code,ISIC_Description));
				customerMap.put("FATCAInfo",FATCAInfo(isPrimaryOrCoApp));
				customerMap.put("MoreFinancialDetails",MoreFinancialDetails(isPrimaryOrCoApp));
//				customerMap.put("InternalDocumentList",InternalDocumentList(isPrimaryOrCoApp));
//				customerMap.put("CollateralDocumentList",CollateralDocumentList(isPrimaryOrCoApp));
//				customerMap.put("ServiceDocumentList",ServiceDocumentList(isPrimaryOrCoApp));
				customerMap.put("ChildrenDetails",ChildrenDetails(isPrimaryOrCoApp));
				customerMap.put("InfoCode",InfoCode(isPrimaryOrCoApp));

				//FDC Income Table Query
//			    customerMap.put("IncomeDocumentList",IncomeDocumentList(isPrimaryOrCoApp,workType));

				List.add(customerMap);
			}}
		return List;

	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList InfoCode(String isPrimaryOrCoApp) {

		ArrayList InfoCodeList =new ArrayList();
		LinkedHashMap InfoCodeMap =new LinkedHashMap();

		InsertInMap(InfoCodeMap,"Code",isPrimaryOrCoApp+"MIS_Code",true);
		InsertInMap(InfoCodeMap,"Value",isPrimaryOrCoApp+"MIS_Value",true);
		InsertInMap(InfoCodeMap,"pxObjClass","SCB-Data-Info",false);

		InfoCodeList.add(InfoCodeMap);
		return InfoCodeList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static ArrayList setCustomerContact(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		ArrayList setCustomerContactList =new ArrayList();
		logger.info("--------------------------- Contacts Starts for "+isPrimaryOrCoApp+"-------------------------------------------------------");

		String j="";
		String PRContact="true";
		int count=0;

		for(int i=0;i<=2;i++)
		{
			if (i!=0){ j=""+i;}


			String DBValue=""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Contact_type_Code"+j, GetCase.scenarioID);

			if(DBValue.length()>1)
			{
				if(count==0){PRContact="true";logger.info("if(count==0)---->"+PRContact);}
				else if(count!=0){PRContact="false";logger.info("else if(count!=0)---->"+PRContact);}

				LinkedHashMap contactsMap =new LinkedHashMap();
				InsertInMap(contactsMap,"AddedBeforeFullDataCap","true",false);
				InsertInMap(contactsMap,"AreaCode",isPrimaryOrCoApp+"Area_Code"+j,true);
				InsertInMap(contactsMap,"ISDCode",isPrimaryOrCoApp+"ISD_Code"+j,true);
				InsertInMap(contactsMap,"ContactNumber",isPrimaryOrCoApp+"Contact_Details"+j,true);
				InsertInMap(contactsMap,"ContactType",isPrimaryOrCoApp+"Contact_type_Code"+j,true);
				InsertInMap(contactsMap,"PRContact",PRContact,false);
				InsertInMap(contactsMap,"ContactTypeClassification",LOV_Codes.ContactTypeClassification(isPrimaryOrCoApp+"Contact_type_Code"+j,isPrimaryOrCoApp+"Contact_type_Description"+j),false);
				InsertInMap(contactsMap,"OperationMode", "I",false);
				InsertInMap(contactsMap,"pxObjClass", "SCB-Data-Contact",false);

				setCustomerContactList.add(contactsMap);

				count=count+1;
			}

		}

		logger.info("--------------------------- Contacts Ends for "+isPrimaryOrCoApp+"-------------------------------------------------------");
		return setCustomerContactList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static ArrayList CollateralDocumentList()
	{
		logger.info("--------------------------- CollateralDocumentList Starts-------------------------------------------------------");
		ArrayList CollateralDocumentList =new ArrayList();

		for(int i=1;i<=3;i++)
		{	String DocName=LOV_Codes.retriveDocumentNameCode("Primary_CollateralDoc"+i+"_DocumentName");

			if(DocName.length()>3)
			{
				LinkedHashMap CollateralDocumentListMap =new LinkedHashMap();
				InsertInMap(CollateralDocumentListMap,"DocumentCategory","R0008",false);
				InsertInMap(CollateralDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode("Primary_CollateralDoc"+i+"_DocumentName"),false);
				InsertInMap(CollateralDocumentListMap,"DocumentNumber","Primary_CollateralDoc"+i+"_DocumentNumber",true);
				InsertInMap(CollateralDocumentListMap,"DocumentSignatureDate","Primary_CollateralDoc"+i+"_DocumentSignatureDate",true);
				InsertInMap(CollateralDocumentListMap,"IsDocumentAvailable","Y",false);
				InsertInMap(CollateralDocumentListMap,"IsExistingDocument","N",false);
				InsertInMap(CollateralDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
				CollateralDocumentList.add(CollateralDocumentListMap);
			}
		}


		return CollateralDocumentList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList ServiceDocumentList()
	{
		logger.info("--------------------------- ServiceDocumentList Starts-------------------------------------------------------");
		ArrayList ServiceDocumentList =new ArrayList();


		for(int i=1;i<=3;i++)
		{	String DocName=LOV_Codes.retriveDocumentNameCode("Primary_ServiceDoc"+i+"_DocumentName");
			if(DocName.length()>3)
			{
				LinkedHashMap ServiceDocumentListMap =new LinkedHashMap();
				InsertInMap(ServiceDocumentListMap,"DocumentCategory","R0007",false);
				InsertInMap(ServiceDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode("Primary_ServiceDoc"+i+"_DocumentName"),false);
				InsertInMap(ServiceDocumentListMap,"DocumentNumber","Primary_ServiceDoc"+i+"_DocumentNumber",true);
				InsertInMap(ServiceDocumentListMap,"DocumentSignatureDate","Primary_ServiceDoc"+i+"_DocumentSignatureDate",true);
				InsertInMap(ServiceDocumentListMap,"IsDocumentAvailable","Y",false);
				InsertInMap(ServiceDocumentListMap,"IsExistingDocument","N",false);
				InsertInMap(ServiceDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
				ServiceDocumentList.add(ServiceDocumentListMap);
			}
		}


		return ServiceDocumentList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList InternalDocumentList(String isPriCoApp)
	{
		logger.info("--------------------------- InternalDocumentList Starts-------------------------------------------------------");
		ArrayList InternalDocumentList =new ArrayList();

		String PriOrCoApp="";
		if(isPriCoApp.equalsIgnoreCase("")){PriOrCoApp="Primary_";}

		for(int i=1;i<=3;i++)
		{
			String DocName=LOV_Codes.retriveDocumentNameCode(PriOrCoApp+"InternalDoc"+i+"_DocumentName");//"Primary_InternalDoc"+i+"_DocumentName"
			if(DocName.length()>3)
			{
				LinkedHashMap InternalDocumentListMap =new LinkedHashMap();
				InsertInMap(InternalDocumentListMap,"DocumentCategory","R0009",false);
				InsertInMap(InternalDocumentListMap,"DocumentName",DocName,true);
				InsertInMap(InternalDocumentListMap,"DocumentNumber",PriOrCoApp+"InternalDoc"+i+"DocumentNumber",true);
				InsertInMap(InternalDocumentListMap,"DocumentSignatureDate",PriOrCoApp+"InternalDoc"+i+"DocumentSignatureDate",true);
				InsertInMap(InternalDocumentListMap,"IsDocumentAvailable","Y",false);
				InsertInMap(InternalDocumentListMap,"IsExistingDocument","N",false);
				InsertInMap(InternalDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

				InternalDocumentList.add(InternalDocumentListMap);
			}
		}


		return InternalDocumentList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList ChildrenDetails(String isPrimaryOrCoApp)
	{
		logger.info("--------------------------- ChildrenDetails Starts-------------------------------------------------------");
		ArrayList ChildrenDetailsList =new ArrayList();
		String NumberOfChildren=DBUtils.readColumnWithRowIDNew("Number_of_children", GetCase.scenarioID);

		logger.info("NumberOfChildren is :"+NumberOfChildren);
		if(!NumberOfChildren.contains("") && !(NumberOfChildren==null) && !NumberOfChildren.isEmpty())
		{

			int totalChild= Integer.parseInt(NumberOfChildren);
			for(int i=0;i<=totalChild;i++)
			{
				LinkedHashMap ChildrenDetailsMap =new LinkedHashMap();
				InsertInMap(ChildrenDetailsMap,"AgeOfChild","Age_of_Child",true);
				InsertInMap(ChildrenDetailsMap,"GenderOfChild","Gender_of_Child",true);
				InsertInMap(ChildrenDetailsMap,"NameOfChild","Name_of_the_Child",true);
				InsertInMap(ChildrenDetailsMap,"pxObjClass","SCB-Data",false);

				ChildrenDetailsList.add(ChildrenDetailsMap);

			}
		}

		return ChildrenDetailsList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static ArrayList TaxInformation()
	{
		logger.info("----------------------------------------------TaxInformation Starts---------------------------------------------------------------------------------------");
		ArrayList AddressList =new ArrayList();
		LinkedHashMap AddressMap =new LinkedHashMap();

		String docNumber="";
		InsertInMap(AddressMap,"Code", "^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{10}+)$",false);
		InsertInMap(AddressMap,"CountryofTaxResidence", "IN",false);

		for(int i=1;i<=4;i++)
		{if(DBUtils.readColumnWithRowIDNew("Name_of_the_Document"+i, GetCase.scenarioID).contains("PAN")){docNumber= DBUtils.readColumnWithRowIDNew("Document_Number"+i, GetCase.scenarioID);}}
		InsertInMap(AddressMap,"DocumentNumber", docNumber,false);
		InsertInMap(AddressMap,"pxObjClass", "SCB-Data-TaxInfo",false);

		AddressList.add(AddressMap);

		return AddressList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList NationalityList(String isPrimaryOrCoApp)
	{
		logger.info("----------------------------------------------NationalityList Starts---------------------------------------------------------------------------------------");
		ArrayList AddressList =new ArrayList();

		for(int i=1;i<=2;i++)
		{

			String DbValue = ""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Nationality_Description"+i, GetCase.scenarioID);

			if(DbValue.length()>1)
			{
				LinkedHashMap AddressMap =new LinkedHashMap();
				InsertInMap(AddressMap,"Nationality",LOV_Codes.getNationalityCodeNew(isPrimaryOrCoApp+"Nationality_Description"+i),false);
				InsertInMap(AddressMap,"NationalityDescription",isPrimaryOrCoApp+"Nationality_Description"+i,true);
				InsertInMap(AddressMap,"pxObjClass","SCB-Data-Nationality",false);
				AddressList.add(AddressMap);
			}else{logger.info(" >>>>>>>>>>>>>>>>>ERROR: "+isPrimaryOrCoApp+"Nationality_Description"+i+" ("+DbValue+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		}

		return AddressList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList Address(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- Address Starts-------------------------------------------------------");
//		 String primaryOrCo="";
//		 if(!primaryOrCoApp.contains("Primary")){ primaryOrCo=primaryOrCoApp;}
		ArrayList AddressList =new ArrayList();
		LinkedHashMap AddressMap =new LinkedHashMap();

		int YY = Integer.parseInt(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Address1_Length_at_Current_Address_YY", GetCase.scenarioID));
		int MM = Integer.parseInt(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Address1_Length_at_Current_Address_MM", GetCase.scenarioID));
		InsertInMap(AddressMap,"LengthAtCurrentAddressInMonths",""+(YY*12+MM),false);
		InsertInMap(AddressMap,"Residence_Type",LOV_Codes.getResidenceTypeCode(isPrimaryOrCoApp+"Address1_Address_Type"),false);
		InsertInMap(AddressMap,"AddressLine1",isPrimaryOrCoApp+"Address1_Address_Line_1",true);
		InsertInMap(AddressMap,"AddressLine2",isPrimaryOrCoApp+"Address1_Address_Line_2",true);
		InsertInMap(AddressMap,"AddressLine3",isPrimaryOrCoApp+"Address1_Address_Line_3",true);
		InsertInMap(AddressMap,"AddressLine4",isPrimaryOrCoApp+"Address1_Address_Line_3",true);
		InsertInMap(AddressMap,"CityName",isPrimaryOrCoApp+"Address1_City",true);
		InsertInMap(AddressMap,"PostalCode",isPrimaryOrCoApp+"Address1_Zip_Code",true);
		InsertInMap(AddressMap,"Type",LOV_Codes.getAddressesType(isPrimaryOrCoApp+"Address1_Address_Type"),false);
		InsertInMap(AddressMap,"State",LOV_Codes.getStateCode(isPrimaryOrCoApp+"Address1_State"),false);
		InsertInMap(AddressMap,"IsMailingAddress",isPrimaryOrCoApp+"Address1_Mailing_Address_Indicator",true);
		InsertInMap(AddressMap,"IsPermanentandMailingAddressSame",isPrimaryOrCoApp+"Address1_Permanent_Address_same_as_Residential_Address",true);
		InsertInMap(AddressMap,"LengthInYY",isPrimaryOrCoApp+"Address1_Length_at_Current_Address_YY",true);
		InsertInMap(AddressMap,"LengthInMM",isPrimaryOrCoApp+"Address1_Length_at_Current_Address_MM",true);
		InsertInMap(AddressMap,"ResidenceType",LOV_Codes.getResidenceTypeCode(isPrimaryOrCoApp+"Address1_Residence_type"),false);
		InsertInMap(AddressMap,"Country",LOV_Codes.CountryCode(isPrimaryOrCoApp+"Address1_Country"),false);
		InsertInMap(AddressMap,"Area",isPrimaryOrCoApp+"Address1_Area",true);
		InsertInMap(AddressMap,"pxObjClass", "SCB-Data-Address",false);

		AddressList.add(AddressMap);
		return AddressList;

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList Address_BDC(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- Address BDC Starts-------------------------------------------------------");
		ArrayList AddressList =new ArrayList();
		LinkedHashMap AddressMap =new LinkedHashMap();

		InsertInMap(AddressMap,"Country",LOV_Codes.CountryCode(isPrimaryOrCoApp+"Residence_Country_Description"),false);
		InsertInMap(AddressMap,"pxObjClass", "SCB-Data-Address",false);

		AddressList.add(AddressMap);
		return AddressList;

	}




	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList AliasNameInfo(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- AliasNameInfo Starts-------------------------------------------------------");
		ArrayList AliasNameInfolist =new ArrayList();

		logger.info("Full name is : "+FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name"));
		logger.info("Length of Full name is : "+FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name").length());

		if (FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Last_Name",isPrimaryOrCoApp+"Middle_Name").length()>=30)
		{
			LinkedHashMap AliasNameInfoMap =new LinkedHashMap();

			InsertInMap(AliasNameInfoMap,"AliasFirstName",isPrimaryOrCoApp+"Alias_First_Name",true);
			InsertInMap(AliasNameInfoMap,"AliasLastName",isPrimaryOrCoApp+"Alias_Last_Name",true);
			InsertInMap(AliasNameInfoMap,"AliasMiddleName",isPrimaryOrCoApp+"Alias_Middle_Name",true);
			InsertInMap(AliasNameInfoMap,"AliasNames",isPrimaryOrCoApp+"Aliases",true);
			InsertInMap(AliasNameInfoMap,"AliasType",LOV_Codes.getAliasTypeCode(isPrimaryOrCoApp+"Alias_Type"),false);
			InsertInMap(AliasNameInfoMap,"pxObjClass","SCB-Data-AliasName",false);

			AliasNameInfolist.add(AliasNameInfoMap);
		}
		return AliasNameInfolist;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList CustomerContacts() throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- CustomerContacts Starts-------------------------------------------------------");
		ArrayList CustomerContactslist =new ArrayList();
		LinkedHashMap CustomerContactsMap =new LinkedHashMap();

		InsertInMap(CustomerContactsMap,"AddedBeforeFullDataCap","true",false);
		InsertInMap(CustomerContactsMap,"ContactNumber","Contact_type_Code",true);
		InsertInMap(CustomerContactsMap,"ContactType","Contact_Details",true);
		InsertInMap(CustomerContactsMap,"pxObjClass","SCB-Data-AliasName",false);

		CustomerContactslist.add(CustomerContactsMap);
		return CustomerContactslist;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList DocumentList(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- DocumentList(String isPrimaryOrCoApp) starts-------------------------------------------------------");
		ArrayList DocumentList =new ArrayList();

		for(int i=0;i<=3;i++)
		{
			String s="";

			if(i!=0){s=""+i;}else {s="";}

			LinkedHashMap DocumentListMap =new LinkedHashMap();

			String DocName =""+LOV_Codes.retriveDocumentNameCode("Name_of_the_Document"+s);
			if(DocName.length()>4)
			{
				InsertInMap(DocumentListMap,"DocumentCategDesc",isPrimaryOrCoApp+"Document_Category"+s,true);
				InsertInMap(DocumentListMap,"DocumentCategory",LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+s),false);
				InsertInMap(DocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode("Name_of_the_Document"+s),false);
				InsertInMap(DocumentListMap,"DocumentNumber",DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Number"+s, GetCase.scenarioID),false);
				InsertInMap(DocumentListMap,"DocumentExpiryDate",isPrimaryOrCoApp+"Document_Expiry_Date"+s,true);
				InsertInMap(DocumentListMap,"DocumentSignatureDate",isPrimaryOrCoApp+"Document_Signature_Date"+s,true);
				InsertInMap(DocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
				InsertInMap(DocumentListMap,"AddedBeforeFullDataCap","true",false);
				InsertInMap(DocumentListMap,"IsDocumentAvailable","Y",false);
				DocumentList.add(DocumentListMap);
			}
		}


		return DocumentList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getFDCDocumentList(String isPrimaryOrCoApp,String ProductCategory) throws ClassNotFoundException, SQLException, IOException, ParseException
	{
		logger.info("--------------------------- DocumentList(String isPrimaryOrCoApp) starts-------------------------------------------------------");
		ArrayList DocumentList =new ArrayList();

		String customeIndex="";
		if(isPrimaryOrCoApp.equalsIgnoreCase("")){customeIndex="1";}
		else if(isPrimaryOrCoApp.equals("Coapplicant1")){customeIndex="2";}
		else if(isPrimaryOrCoApp.equals("Coapplicant2")){customeIndex="3";}
		else if(isPrimaryOrCoApp.equals("Coapplicant3")){customeIndex="3";}

		for(int i=0;i<=3;i++)
		{
			String s="";

			if(i!=0){s=""+i;}else {s="";}



			String DocName =""+LOV_Codes.retriveDocumentNameCode("Name_of_the_Document"+s);
			if(DocName.length()>4)
			{
				LinkedHashMap DocumentListMap =new LinkedHashMap();


				System.out.println(isPrimaryOrCoApp+"Document_Expiry_Date"+s+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+s, GetCase.scenarioID));

				InsertInMap(DocumentListMap,"CustomerIndex",customeIndex ,false);
				InsertInMap(DocumentListMap,"DocumentCategDesc",isPrimaryOrCoApp+"Document_Category"+s,true);
				InsertInMap(DocumentListMap,"DocumentCategory",LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+s),false);
				InsertInMap(DocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode("Name_of_the_Document"+s),false);
				InsertInMap(DocumentListMap,"DocumentNumber",DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Number"+s, GetCase.scenarioID),false);
				InsertInMap(DocumentListMap,"DocumentExpiryDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(DocumentListMap,"DocumentSignatureDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Signature_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(DocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
				InsertInMap(DocumentListMap,"AddedBeforeFullDataCap","true",false);
				InsertInMap(DocumentListMap,"IsDocumentAvailable","Y",false);
				DocumentList.add(DocumentListMap);
			}
		}

		DBUtils.convertDBtoMap("fdquery");


		System.out.println(isPrimaryOrCoApp+"ProductCategory : "+ProductCategory);

		String i="";
		for(int j=1;j<=4;j++)
		{
			if(j!=0){i="_"+j;}
			System.out.println(isPrimaryOrCoApp+"Document_Category"+i);
			String DocCat=""+LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+i);

			LinkedHashMap ProdDocumentListMap =new LinkedHashMap();

			InsertInMap(ProdDocumentListMap,"CustomerIndex",customeIndex ,false);
			InsertInMap(ProdDocumentListMap,"DocumentCategDesc",isPrimaryOrCoApp+"Document_Category"+i,true);
			InsertInMap(ProdDocumentListMap,"DocumentCategory",DocCat,false);
			InsertInMap(ProdDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(isPrimaryOrCoApp+"Name_of_the_Document"+i),false);
			InsertInMap(ProdDocumentListMap,"IsDocumentAvailable","Y",false);
			InsertInMap(ProdDocumentListMap,"DocumentNumber",DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Number"+i, GetCase.scenarioID),false);
			InsertInMap(ProdDocumentListMap,"DocumentExpiryDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+i, GetCase.scenarioID)),false);
			InsertInMap(ProdDocumentListMap,"DocumentSignatureDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Signatory_Date"+i, GetCase.scenarioID)),false);
			InsertInMap(ProdDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

			DocumentList.add(ProdDocumentListMap);

		}



		if(ProductCategory.equalsIgnoreCase("CC") || ProductCategory.equalsIgnoreCase("PL"))
		{
			DBUtils.convertDBtoMap("fdqueryIncome");
			String porC="";
			if(isPrimaryOrCoApp.equals("")){porC="Primary";}
			else if(isPrimaryOrCoApp.equals("Coapplicant1")){porC="CoApp1";}
			else if(isPrimaryOrCoApp.equals("Coapplicant2")){porC="CoApp2";}
			else if(isPrimaryOrCoApp.equals("Coapplicant3")){porC="CoApp3";}

			LinkedHashMap incomeMap =new LinkedHashMap();

//					InsertInMap(incomeMap,"DocumentCategDesc","CLIENT CREDIT ASSESSMENT DOCUMENTS",false);
			InsertInMap(incomeMap,"DocumentCategory","R0005",false);
			InsertInMap(incomeMap,"DocumentName","CLIENT CREDIT ASSESSMENT DOCUMENTS",false);
			InsertInMap(incomeMap,"IsDocumentAvailable","Y",false);
//					InsertInMap(incomeMap,"DocumentNumber","XXPDKKSA",false);
//					InsertInMap(incomeMap,"DocumentExpiryDate","20190909",false);
//					InsertInMap(incomeMap,"DocumentSignatureDate","20180109",false);
			InsertInMap(incomeMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

			DocumentList.add(incomeMap);



			for(int j=1;j<=3;j++)
			{
				System.out.println(porC+"_IncomeDoc"+j+"_DocumentName");

				LinkedHashMap ProdDocumentListMap =new LinkedHashMap();

				InsertInMap(ProdDocumentListMap,"CustomerIndex",customeIndex ,false);
//						InsertInMap(ProdDocumentListMap,"DocumentCategDesc","CLIENT CREDIT ASSESSMENT DOCUMENTS",false);
				InsertInMap(ProdDocumentListMap,"DocumentCategory","R0005",false);
				InsertInMap(ProdDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(porC+"_IncomeDoc"+j+"_DocumentName"),false);
				InsertInMap(ProdDocumentListMap,"IsDocumentAvailable","Y",false);
//						InsertInMap(ProdDocumentListMap,"DocumentNumber","1233444"+j,false);
//						InsertInMap(ProdDocumentListMap,"DocumentExpiryDate","2020090"+j,false);
//						InsertInMap(ProdDocumentListMap,"DocumentSignatureDate","20180109",false);
				InsertInMap(ProdDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

				DocumentList.add(ProdDocumentListMap);
			}
		}



		return DocumentList;
	}

	@SuppressWarnings({ "rawtypes" })
	public static LinkedHashMap Employment_FDC(String isPrimaryOrCoApp,String workType,String Occupation_Code,String Occupation_Description,String ISIC_Code, String ISIC_Description) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- Employment Starts-------------------------------------------------------");
		LinkedHashMap EmploymentMap =new LinkedHashMap();


		int currentBusinessOrg_YY = Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID))*12;
		int previousBusinessOrg_YY = Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID))*12;
		int currentBusinessOrg_totalMonths = currentBusinessOrg_YY+Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Current_businessPreOrganization_MM", GetCase.scenarioID));
		int previousBusinessOrg_totalMonths= previousBusinessOrg_YY+Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Previous_businessPreOrganization_MM", GetCase.scenarioID));
		int totalExp_YY=Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID))+Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID));
		int totalExp_MM=Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Current_businessPreOrganization_MM", GetCase.scenarioID))+Integer.parseInt(DBUtils.readColumnWithRowIDNew("No_of_Months_in_Previous_businessPreOrganization_MM", GetCase.scenarioID));

		if(totalExp_MM>=12)
		{
			totalExp_YY=totalExp_YY+1;
			totalExp_MM=totalExp_MM-12;
		}

		//Basic

		InsertInMap(EmploymentMap,"ProfessionCode",Occupation_Code,false);
		InsertInMap(EmploymentMap,"ProfessionDescription", Occupation_Description,false);
		InsertInMap(EmploymentMap,"Industry", ISIC_Code,false);
		InsertInMap(EmploymentMap,"IndustryDescription", ISIC_Description,false);


		//FDC
		InsertInMap(EmploymentMap,"EmploymentType", workType,false);

		if(workType.contains("Salaried") || workType.contains("Self") || workType.contains("E") || workType.contains("S"))
		{
			InsertInMap(EmploymentMap,"AnnualDeclaredIncome", "Annual_Declared_Income",true);
			InsertInMap(EmploymentMap,"CompanyCategory", "Company_Category",true);
			InsertInMap(EmploymentMap,"EmployerCategory", "Company_Category",true);
			InsertInMap(EmploymentMap,"Department","Department",true);
			InsertInMap(EmploymentMap,"NoOfMonthsInCurrentBusinessOrganization", ""+currentBusinessOrg_totalMonths,false);
			InsertInMap(EmploymentMap,"NoOfMonthsInPreviousBusinessOrganization", ""+previousBusinessOrg_totalMonths,false);
			InsertInMap(EmploymentMap,"TotalExpMM", ""+totalExp_MM,false);
			InsertInMap(EmploymentMap,"TotalExpYY", ""+totalExp_YY,false);
			InsertInMap(EmploymentMap,"TotalWorkExperienceInMonths", ""+totalExp_YY*12,false);
			InsertInMap(EmploymentMap,"EmployerCode", "AA001",false);
			InsertInMap(EmploymentMap,"OwnershipType","Describe_ApplicantOwnership_Type",true);
			InsertInMap(EmploymentMap,"EmployerName", LOV_Codes.EmployerNameCode("Employer_Name"),false);
			InsertInMap(EmploymentMap,"ClientType", "Client_Type",true);
			InsertInMap(EmploymentMap,"CurrentOrgMM", "No_of_Months_in_Current_businessPreOrganization_MM",true);
			InsertInMap(EmploymentMap,"CurrentOrgYY", "No_of_Months_in_Current_businessPreOrganization_YY",true);
			InsertInMap(EmploymentMap,"Designation", LOV_Codes.DesignationCode("Designation"),false);
			InsertInMap(EmploymentMap,"PreviousOrgMM", "No_of_Months_in_Previous_businessPreOrganization_MM",true);
			InsertInMap(EmploymentMap,"PreviousOrgYY", "No_of_Months_in_Previous_businessPreOrganization_YY",true);
			InsertInMap(EmploymentMap,"TaxResidencyStatus", "Tax_Residency_status",true);
			InsertInMap(EmploymentMap,"pxObjClass", "SCB-Data-EmploymentInfo",false);
			InsertInMap(EmploymentMap,"ModeOfSalary","Salary_Mode",true);
			InsertInMap(EmploymentMap,"PreviousEmployerName","Previous_employer_name",true);

			if(workType.contains("Self") || workType.contains("E"))
			{
				InsertInMap(EmploymentMap,"BusinessEstablishmentDate","Business_Establishment_Date",true);
				InsertInMap(EmploymentMap,"Company_Type",LOV_Codes.CompanyTypeCode("Company_Type"),false);
				InsertInMap(EmploymentMap,"CompanyType",LOV_Codes.CompanyTypeCode("Company_Type"),false);
				InsertInMap(EmploymentMap,"CompanyName","Company_Name",true);
				InsertInMap(EmploymentMap,"IncorporationCountry",LOV_Codes.CountryCode("Incorporation_Country"),false);
				InsertInMap(EmploymentMap,"IncorporationDate",LOV_Codes.getSysDate("YYYY-MM-dd"),false);
				InsertInMap(EmploymentMap,"IndustryGroup",LOV_Codes.IndustryGroupSectorCode("Industry_Group_Sector"),false);
				InsertInMap(EmploymentMap,"SharePercentage","Share_holding",true);

			}
			else if(workType.contains("Salaried") || workType.contains("S"))
			{
				InsertInMap(EmploymentMap,"IsPayrollCust", "Payroll_Indicator",true);

			}
		}

		InsertInMap(EmploymentMap,"NatureOfBusiness",LOV_Codes.NatureofBusinessCodeNew("Nature_of_Business"),false);

		return EmploymentMap;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList MoreFinancialDetails(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- MoreFinancialDetails Starts-------------------------------------------------------");
		ArrayList MoreFinancialDetailsList =new ArrayList();
		isPrimaryOrCoApp="";
		String DbValue = ""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Account_NumberPreApp_Ref_No", GetCase.scenarioID);
		if(DbValue.length()>3)
		{
			LinkedHashMap MoreFinancialDetailsMap =new LinkedHashMap();
			InsertInMap(MoreFinancialDetailsMap,"AccountNumber","Account_NumberPreApp_Ref_No",true);
			InsertInMap(MoreFinancialDetailsMap,"AccountOpenDate","2018-05-31T18:30:00.000Z",false);
			InsertInMap(MoreFinancialDetailsMap,"AccountType","Account_Type",true);
			InsertInMap(MoreFinancialDetailsMap,"ActualMonthlyCommitment","Actual_Monthly_Commitment",true);
			InsertInMap(MoreFinancialDetailsMap,"ApplicantType","Applicant_Type",true);
			InsertInMap(MoreFinancialDetailsMap,"appliedamount","",false);
			InsertInMap(MoreFinancialDetailsMap,"AppliedAmountCurrency","Applied_Amount_Currency",true);
			InsertInMap(MoreFinancialDetailsMap,"appliedtenor","",false);
			InsertInMap(MoreFinancialDetailsMap,"CommitmentCurrency","Commitment_Currency",true);
			InsertInMap(MoreFinancialDetailsMap,"InterestRate1","",false);
			InsertInMap(MoreFinancialDetailsMap,"InterestType","",false);
			InsertInMap(MoreFinancialDetailsMap,"OriginalApprovedLimit","Original_approved_limit",true);
			InsertInMap(MoreFinancialDetailsMap,"OriginalApprovedLimitCurrency","Original_approved_limit_currency",true);
			InsertInMap(MoreFinancialDetailsMap,"OustandingAmountCurrency","Oustanding_amount_currency",true);
			InsertInMap(MoreFinancialDetailsMap,"OutstandingAmount","Outstanding_amount",true);
			InsertInMap(MoreFinancialDetailsMap,"RemainingTenorInMonths","",false);
			InsertInMap(MoreFinancialDetailsMap,"Source","Source",true);
			InsertInMap(MoreFinancialDetailsMap,"Status","Status",true);
			InsertInMap(MoreFinancialDetailsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-MoreFinancialDetails",true);
			MoreFinancialDetailsList.add(MoreFinancialDetailsMap);
		}
		return MoreFinancialDetailsList;
	}



	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList AssessmentDocumentList(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- AssessmentDocumentList Starts-------------------------------------------------------");
		ArrayList AssessmentDocumentList =new ArrayList();

		for(int i=0;i<=2;i++)
		{
			String s="";

			if(i!=0){s=""+i;}
			else {s="";}
			LinkedHashMap AssessmentDocumentMap =new LinkedHashMap();

			InsertInMap(AssessmentDocumentMap,"DocumentCategory",LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+s),false);
			InsertInMap(AssessmentDocumentMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(isPrimaryOrCoApp+"Name_of_the_Document"+s),false);
			InsertInMap(AssessmentDocumentMap,"DocumentNumber",isPrimaryOrCoApp+"Document_Number"+s,true);
			InsertInMap(AssessmentDocumentMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
			InsertInMap(AssessmentDocumentMap,"IsDocumentAvailable","Y",false);

			AssessmentDocumentList.add(AssessmentDocumentMap);
		}


		return AssessmentDocumentList;
	}

	@SuppressWarnings({ "rawtypes"})
	public static LinkedHashMap FATCAInfo(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- FATCAInfo Starts-------------------------------------------------------");
		LinkedHashMap FATCAInfoMap =new LinkedHashMap();

		InsertInMap(FATCAInfoMap,"IsUSCitizen",LOV_Codes.RadioButtonCode(isPrimaryOrCoApp+"Is_Customer_a_US_Citizen"),false);
		InsertInMap(FATCAInfoMap,"IsUSGreenCardHolder",LOV_Codes.RadioButtonCode(isPrimaryOrCoApp+"FATCA_Is_Customer_a_Green_card_holder"),false);
		InsertInMap(FATCAInfoMap,"IsUSResident",LOV_Codes.RadioButtonCode(isPrimaryOrCoApp+"FATCA_Is_Customer_a_US_Resident"),false);
		InsertInMap(FATCAInfoMap,"pxObjClass","SCB-Data-FATCAInd",false);

		return FATCAInfoMap;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList IDDocumentList(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException, ParseException
	{
		logger.info("--------------------------- IDDocumentList Starts-------------------------------------------------------");
		ArrayList IDDocumentList =new ArrayList();

		for(int i=0;i<=1;i++)
		{
			String s="";

			if(i!=0){s=""+i;}
			else {s="";}
			LinkedHashMap IDDocumentListMap =new LinkedHashMap();

			String idDoc=""+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Category"+s, GetCase.scenarioID).replaceAll("null", "");
			if(idDoc.contains("CLIENT ID"))
			{
				logger.info("Document_Category"+s+" is ---->"+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Category"+s, GetCase.scenarioID));

				InsertInMap(IDDocumentListMap,"DocumentCategory",LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+s),false);
				InsertInMap(IDDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(isPrimaryOrCoApp+"Name_of_the_Document"+s),false);
				InsertInMap(IDDocumentListMap,"DocumentExpiryDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(IDDocumentListMap,"DocumentSignatureDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Signature_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(IDDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);
				InsertInMap(IDDocumentListMap,"DocumentNumber","Document_Number"+s,true);
				InsertInMap(IDDocumentListMap,"IsDocumentAvailable","Y",false);

				IDDocumentList.add(IDDocumentListMap);
			}

		}


		return IDDocumentList;
	}



	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList VerfDocumentList(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException, ParseException
	{
		logger.info("--------------------------- VerfDocumentList Starts-------------------------------------------------------");
		ArrayList VerfDocumentList =new ArrayList();

		for(int i=0;i<=3;i++)
		{
			String s="";

			if(i!=0){s=""+i;}
			else {s="";}
			LinkedHashMap VerfDocumentListMap =new LinkedHashMap();

			if(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Category"+s, GetCase.scenarioID).contains("VERIFICATION"))
			{
				logger.info("Document_Category"+s+" is ---->"+DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Category"+s, GetCase.scenarioID));

				InsertInMap(VerfDocumentListMap,"DocumentCategory",LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+s),false);
				InsertInMap(VerfDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(isPrimaryOrCoApp+"Name_of_the_Document"+s),false);
				InsertInMap(VerfDocumentListMap,"DocumentNumber",isPrimaryOrCoApp+"Document_Number"+s,true);
				InsertInMap(VerfDocumentListMap,"DocumentExpiryDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(VerfDocumentListMap,"DocumentSignatureDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Signature_Date"+s, GetCase.scenarioID)),false);
				InsertInMap(VerfDocumentListMap,"IsDocumentAvailable","Y",false);
				InsertInMap(VerfDocumentListMap,"DocExpiryFlag","false",false);
				InsertInMap(VerfDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

				VerfDocumentList.add(VerfDocumentListMap);
			}
		}
		return VerfDocumentList;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList IncomeDocumentList(String isPrimaryOrCoApp, String workType) throws ClassNotFoundException, SQLException, IOException
	{

		logger.info("--------------------------- Income Documents Starts-------------------------------------------------------");
		String PrimaryOrCoApp="";
		if(isPrimaryOrCoApp.equals("") || isPrimaryOrCoApp.equals("Primary")){PrimaryOrCoApp="Primary";}

		ArrayList IncomeDocumentList =new ArrayList();


		if(workType.contains("Salaried")|| workType.contains("S") || workType.contains("E") || workType.contains("Self"))
		{
			String pxObjClass="SCB-Data-FinancialDetails";
			String timeZone="T18:30:00.000Z";
			DBUtils.convertDBtoMap("fdqueryIncome");

			for(int j=1;j<=3;j++)
			{
				LinkedHashMap IncomeDocumentListMap =new LinkedHashMap();
				System.out.println("Income Doc Itteration  :"+j);
				System.out.println("PrimaryOrCoApp :"+PrimaryOrCoApp);

				logger.info(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID));
				if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("FORM 16"))
				{
					InsertInMap(IncomeDocumentListMap,"CustomerFullNameOcr","FORM16",false);
					InsertInMap(IncomeDocumentListMap,"DocumentCategory","R0005",false);
					InsertInMap(IncomeDocumentListMap,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentType","T0373",false);
					InsertInMap(IncomeDocumentListMap,"DocumentGroup","CC_9",false);
					InsertInMap(IncomeDocumentListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"OcrFlag","Y",false);
					InsertInMap(IncomeDocumentListMap,"PeriodLength","1",false);
					InsertInMap(IncomeDocumentListMap,"pxObjClass",pxObjClass,false);
					InsertInMap(IncomeDocumentListMap,"UserFlag","true",false);

					InsertInMap(IncomeDocumentListMap,"Mandatory","M",false);


					ArrayList Form16List =new ArrayList();
					String pxObjectClassForm16="SCB-Data-FinancialDetails-FORM16";

					for (int i=1;i<=1;i++)
					{
						LinkedHashMap Form16ListMap =new LinkedHashMap();
						InsertInMap(Form16ListMap,"AssessmentYearFromYear",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone,true);

						//InsertInMap(Form16ListMap,"AssessmentYearToYear",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DateOfExpiryDoc", GetCase.scenarioID),true);
						InsertInMap(Form16ListMap,"IncomeAsPerTax",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_Income_As_Per_Tax_File_"+i, GetCase.scenarioID),true);
						InsertInMap(Form16ListMap,"DocumentDate",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DateOfExpiryDoc", GetCase.scenarioID)+timeZone,true);
						InsertInMap(Form16ListMap,"GrandTotal","0",false);
						InsertInMap(Form16ListMap,"IncomeListIndex","2",false);
						InsertInMap(Form16ListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DocumentStatus", GetCase.scenarioID),false);
						InsertInMap(Form16ListMap,"Barcode", "Year"+i,false);
						InsertInMap(Form16ListMap,"Comments", "Form16",false);
						InsertInMap(Form16ListMap,"Period", "1",false);
						InsertInMap(Form16ListMap,"UserFlag", "true",false);
						InsertInMap(Form16ListMap,"pxObjClass", pxObjectClassForm16,false);

						LinkedHashMap Component =new LinkedHashMap();
						LinkedHashMap BasicMonthlySalary =new LinkedHashMap();

						InsertInMap(BasicMonthlySalary,"ComponentName","Basic Monthly Salary",false);
						InsertInMap(BasicMonthlySalary,"pxObjClass","SCB-Data-FinancialDetails",false);

						Component.put("BasicMonthlySalary", BasicMonthlySalary);

						Form16ListMap.put("Component", Component);

						Form16List.add(Form16ListMap);
					}
					IncomeDocumentListMap.put("Form16Details",Form16List);
					IncomeDocumentList.add(IncomeDocumentListMap);

				}

				/****CREDIT CARD /DEBIT CARD STATEMENT***/
				else if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("CREDIT CARD /DEBIT CARD STATEMENT"))
				{
					InsertInMap(IncomeDocumentListMap,"CustomerFullNameOcr","CreditCardStatement",false);
					InsertInMap(IncomeDocumentListMap,"DocumentCategory","R0005",false);
					InsertInMap(IncomeDocumentListMap,"DocAccuracy","90",false);
					InsertInMap(IncomeDocumentListMap,"DocumentGroup","CC_9",false);
					InsertInMap(IncomeDocumentListMap,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentType","T0069",false);
					InsertInMap(IncomeDocumentListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"OcrFlag","Y",false);
					InsertInMap(IncomeDocumentListMap,"PeriodLength","1",false);
					InsertInMap(IncomeDocumentListMap,"pxObjClass",pxObjClass,false);
					InsertInMap(IncomeDocumentListMap,"UserFlag","true",false);
					InsertInMap(IncomeDocumentListMap,"DocumentDate","",false);
					InsertInMap(IncomeDocumentListMap,"Mandatory","M",false);


					ArrayList CreditCardList =new ArrayList();
					String pxObjectClassCreditCardStatement="SCB-Data-FinancialDetails-CreditCardStatement";

					for (int i=1;i<2;i++)
					{
						LinkedHashMap CardListMap =new LinkedHashMap();
						InsertInMap(CardListMap,"CardLimit",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1CardLimit", GetCase.scenarioID)+timeZone,true);
						InsertInMap(CardListMap,"Barcode","Month"+i,false);
						InsertInMap(CardListMap,"DateOfIssueDoc",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1DateOfIssueDoc", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"CardRepayRatio",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1CardRepayRatio", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"DateOfExpiryDoc",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1DateOfExpiryDoc", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"GrandTotal","0",false);
						InsertInMap(CardListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DocumentStatus", GetCase.scenarioID),false);
						InsertInMap(CardListMap,"IssuerName", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1IssuerName", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"IncomeListIndex","3",false);
						InsertInMap(CardListMap,"LastMonthOutstanding", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1LastMonthOutstanding", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"ProductName", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1ProductName", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"StatementDt", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1StatementDt", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"StatementDtFrom", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1StatementDtFrom", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"StatementDtTo", DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1StatementDtTo", GetCase.scenarioID),true);
						InsertInMap(CardListMap,"pxObjClass", pxObjectClassCreditCardStatement,false);
						InsertInMap(CardListMap,"UserFlag","true",false);

						LinkedHashMap Component =new LinkedHashMap();
						LinkedHashMap CardStatementLimit =new LinkedHashMap();
						InsertInMap(CardStatementLimit,"ComponentName","Card Statement Limit",false);
						InsertInMap(CardStatementLimit,"pxObjClass",pxObjClass,false);
						Component.put("CardStatementLimit",CardStatementLimit);

						LinkedHashMap OtherCardRepayment_Ratio =new LinkedHashMap();
						InsertInMap(OtherCardRepayment_Ratio,"ComponentName","Other Card Repayment Ratio",false);
						InsertInMap(OtherCardRepayment_Ratio,"pxObjClass",pxObjClass,false);
						Component.put("OtherCardRepayment_Ratio",OtherCardRepayment_Ratio);

						LinkedHashMap ThreeMonthAvgBalance =new LinkedHashMap();
						InsertInMap(ThreeMonthAvgBalance,"ComponentName","Three Month Avg Balance",false);
						InsertInMap(ThreeMonthAvgBalance,"pxObjClass",pxObjClass,false);
						Component.put("ThreeMonthAvgBalance",ThreeMonthAvgBalance);

						CardListMap.put("Component",Component);
						CreditCardList.add(CardListMap);
					}
					IncomeDocumentListMap.put("CreditCardStatement",CreditCardList);
					IncomeDocumentList.add(IncomeDocumentListMap);

				}
				/****PAYSLIP***/
				else if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("PAYSLIP"))
				{
					InsertInMap(IncomeDocumentListMap,"CustomerFullNameOcr","PAYSLIP",false);
					InsertInMap(IncomeDocumentListMap,"DocumentCategory","R0005",false);
					InsertInMap(IncomeDocumentListMap,"DocAccuracy","90",false);
					InsertInMap(IncomeDocumentListMap,"DocumentGroup","CC_9",false);
					InsertInMap(IncomeDocumentListMap,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentType","T0235",false);
					InsertInMap(IncomeDocumentListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"OcrFlag","Y",false);
					InsertInMap(IncomeDocumentListMap,"PeriodLength","1",false);
					InsertInMap(IncomeDocumentListMap,"pxObjClass",pxObjClass,false);
					InsertInMap(IncomeDocumentListMap,"UserFlag","true",false);
					InsertInMap(IncomeDocumentListMap,"Mandatory","Any One",false);

					ArrayList PayslipList =new ArrayList();
					String pxObjectClassPayslip="SCB-Data-FinancialDetails-Payslip";

					for (int i=1;i<2;i++)
					{
						LinkedHashMap payslipListMap =new LinkedHashMap();

						//Month1

						if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field1", GetCase.scenarioID).length()>1)
						{
							logger.info(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field1-->"+DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field1", GetCase.scenarioID));
							int bfield1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field1", GetCase.scenarioID));
							int bfield2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field2", GetCase.scenarioID));
							int bfield3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field3", GetCase.scenarioID));
							int bfield4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field4", GetCase.scenarioID));
							int bfield5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field5", GetCase.scenarioID));
							int bfield6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field6", GetCase.scenarioID));
							int bfield7 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field7", GetCase.scenarioID));
							int bfield8 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_Basic_Monthly_Salary_Field8", GetCase.scenarioID));

							int mafield1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field1", GetCase.scenarioID));
							int mafield2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field2", GetCase.scenarioID));
							int mafield3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field3", GetCase.scenarioID));
							int mafield4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field4", GetCase.scenarioID));
							int mafield5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field5", GetCase.scenarioID));
							int mafield6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field6", GetCase.scenarioID));
							int mafield7 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field7", GetCase.scenarioID));
							int mafield8 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyAllowance_Field8", GetCase.scenarioID));

							int mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
							int mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));

							int mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field1", GetCase.scenarioID));
							int mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field2", GetCase.scenarioID));
							int mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field3", GetCase.scenarioID));
							int mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field4", GetCase.scenarioID));
							int mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field5", GetCase.scenarioID));
							int mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field6", GetCase.scenarioID));
							int mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field7", GetCase.scenarioID));
							int mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyCommission_Field8", GetCase.scenarioID));

							int mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field1", GetCase.scenarioID));
							int mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field2", GetCase.scenarioID));
							int mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field3", GetCase.scenarioID));
							int mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field4", GetCase.scenarioID));
							int mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field5", GetCase.scenarioID));
							int mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field6", GetCase.scenarioID));
							int mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field7", GetCase.scenarioID));
							int mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_M1_MonthlyVariableBonus_Field8", GetCase.scenarioID));

							int basicSalarytotal = bfield1+bfield2+bfield3+bfield4+bfield5+bfield6+bfield7+bfield8;
							int MonthlyAllowancetotal = mafield1+mafield2+mafield3+mafield4+mafield5+mafield6+mafield7+mafield8;
							int MonthlyBonustotal = mbfield1+mbfield2+mbfield3+mbfield4+mbfield5+mbfield6+mbfield7+mbfield8;
							int MonthlyCommissiontotal = mcfield1+mcfield2+mcfield3+mcfield4+mcfield5+mcfield6+mcfield7+mcfield8;
							int MonthlyVariableBonus1 = mvfield1+mvfield2+mvfield3+mvfield4+mvfield5+mvfield6+mvfield7+mvfield8;

							int grandTotal= basicSalarytotal+MonthlyAllowancetotal+MonthlyBonustotal+MonthlyCommissiontotal+MonthlyVariableBonus1;

							//Month1 Mandatory
							InsertInMap(payslipListMap,"DocumentStatus",PrimaryOrCoApp+"_IncomeDoc"+i+"_DocumentStatus",true);
							InsertInMap(payslipListMap,"GrandTotal",""+(float)grandTotal,false);
							InsertInMap(payslipListMap,"GrossPay",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_Gross_Pay", GetCase.scenarioID),true);
							InsertInMap(payslipListMap,"NetPay",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_Net_Pay", GetCase.scenarioID),true);
							InsertInMap(payslipListMap,"pxObjClass",pxObjectClassPayslip,false);
							InsertInMap(payslipListMap,"DocumentDate",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone, true);

							//optional

							LinkedHashMap Component =new LinkedHashMap();
							LinkedHashMap BasicMonthlySalary =new LinkedHashMap();
							InsertInMap(BasicMonthlySalary,"ComponentName","Basic Monthly Salary",false);
							InsertInMap(BasicMonthlySalary,"Field1",""+(float)bfield1,false);
							InsertInMap(BasicMonthlySalary,"Field1Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field2",""+(float)bfield2,false);
							InsertInMap(BasicMonthlySalary,"Field2Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field3",""+(float)bfield3,false);
							InsertInMap(BasicMonthlySalary,"Field3Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field4",""+(float)bfield4,false);
							InsertInMap(BasicMonthlySalary,"Field4Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field5",""+(float)bfield5,false);
							InsertInMap(BasicMonthlySalary,"Field5Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field6",""+(float)bfield6,false);
							InsertInMap(BasicMonthlySalary,"Field6Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field7",""+(float)bfield7,false);
							InsertInMap(BasicMonthlySalary,"Field7Actual","0",false);
							InsertInMap(BasicMonthlySalary,"Field8",""+(float)bfield8,false);
							InsertInMap(BasicMonthlySalary,"Field8Actual","0",false);
							InsertInMap(BasicMonthlySalary,"pxObjClass",pxObjClass,false);
							InsertInMap(BasicMonthlySalary,"Total",""+(float)basicSalarytotal,false);

							Component.put("BasicMonthlySalary", BasicMonthlySalary);


							LinkedHashMap MonthlyAllowance =new LinkedHashMap();
							InsertInMap(MonthlyAllowance,"ComponentName","Monthly Allowance",false);
							InsertInMap(MonthlyAllowance,"Field1",""+(float)mafield1,false);
							InsertInMap(BasicMonthlySalary,"Field1Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field2",""+(float)mafield2,false);
							InsertInMap(BasicMonthlySalary,"Field2Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field3",""+(float)mafield3,false);
							InsertInMap(BasicMonthlySalary,"Field3Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field4",""+(float)mafield4,false);
							InsertInMap(BasicMonthlySalary,"Field4Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field5",""+(float)mafield5,false);
							InsertInMap(BasicMonthlySalary,"Field5Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field6",""+(float)mafield6,false);
							InsertInMap(BasicMonthlySalary,"Field6Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field7",""+(float)mafield7,false);
							InsertInMap(BasicMonthlySalary,"Field7Actual","0",false);
							InsertInMap(MonthlyAllowance,"Field8",""+(float)mafield8,false);
							InsertInMap(BasicMonthlySalary,"Field18Actual","0",false);
							InsertInMap(MonthlyAllowance,"pxObjClass",pxObjClass,false);
							InsertInMap(MonthlyAllowance,"Total",""+(float)MonthlyAllowancetotal,false);

							Component.put("MonthlyAllowance", MonthlyAllowance);

							LinkedHashMap MonthlyBonus =new LinkedHashMap();
							InsertInMap(MonthlyBonus,"ComponentName","Monthly Bonus",false);
							InsertInMap(MonthlyBonus,"Field1",""+(float)mbfield1,false);
							InsertInMap(BasicMonthlySalary,"Field1Actual","0",false);
							InsertInMap(MonthlyBonus,"Field2",""+(float)mbfield2,false);
							InsertInMap(BasicMonthlySalary,"Field2Actual","0",false);
							InsertInMap(MonthlyBonus,"Field3",""+(float)mbfield3,false);
							InsertInMap(BasicMonthlySalary,"Field3Actual","0",false);
							InsertInMap(MonthlyBonus,"Field4",""+(float)mbfield4,false);
							InsertInMap(BasicMonthlySalary,"Field4Actual","0",false);
							InsertInMap(MonthlyBonus,"Field5",""+(float)mbfield5,false);
							InsertInMap(BasicMonthlySalary,"Field5Actual","0",false);
							InsertInMap(MonthlyBonus,"Field6",""+(float)mbfield6,false);
							InsertInMap(BasicMonthlySalary,"Field6Actual","0",false);
							InsertInMap(MonthlyBonus,"Field7",""+(float)mbfield7,false);
							InsertInMap(BasicMonthlySalary,"Field7Actual","0",false);
							InsertInMap(MonthlyBonus,"Field8",""+(float)mbfield8,false);
							InsertInMap(BasicMonthlySalary,"Field8Actual","0",false);
							InsertInMap(MonthlyBonus,"pxObjClass",pxObjClass,false);
							InsertInMap(MonthlyBonus,"Total",""+(float)MonthlyBonustotal,false);

							Component.put("MonthlyBonus", MonthlyBonus);


							LinkedHashMap MonthlyCommission =new LinkedHashMap();
							InsertInMap(MonthlyCommission,"ComponentName","Monthly Commission",false);
							InsertInMap(MonthlyCommission,"Field1",""+(float)mcfield1,false);
							InsertInMap(BasicMonthlySalary,"Field1Actual","0",false);
							InsertInMap(MonthlyCommission,"Field2",""+(float)mcfield2,false);
							InsertInMap(BasicMonthlySalary,"Field2Actual","0",false);
							InsertInMap(MonthlyCommission,"Field3",""+(float)mcfield3,false);
							InsertInMap(BasicMonthlySalary,"Field3Actual","0",false);
							InsertInMap(MonthlyCommission,"Field4",""+(float)mcfield4,false);
							InsertInMap(BasicMonthlySalary,"Field4Actual","0",false);
							InsertInMap(MonthlyCommission,"Field5",""+(float)mcfield5,false);
							InsertInMap(BasicMonthlySalary,"Field5Actual","0",false);
							InsertInMap(MonthlyCommission,"Field6",""+(float)mcfield6,false);
							InsertInMap(BasicMonthlySalary,"Field6Actual","0",false);
							InsertInMap(MonthlyCommission,"Field7",""+(float)mcfield7,false);
							InsertInMap(BasicMonthlySalary,"Field6Actual","0",false);
							InsertInMap(MonthlyCommission,"Field8",""+(float)mcfield8,false);
							InsertInMap(BasicMonthlySalary,"Field8Actual","0",false);
							InsertInMap(MonthlyCommission,"pxObjClass",pxObjClass,false);
							InsertInMap(payslipListMap,"Total",""+(float)MonthlyCommissiontotal,false);

							Component.put("MonthlyCommission", MonthlyCommission);

							LinkedHashMap MonthlyVariableBonus =new LinkedHashMap();

							InsertInMap(MonthlyVariableBonus,"ComponentName","Monthly Variable Bonus",false);
							InsertInMap(MonthlyVariableBonus,"Field1",""+(float)mvfield1,false);
							InsertInMap(MonthlyVariableBonus,"Field2",""+(float)mvfield2,false);
							InsertInMap(MonthlyVariableBonus,"Field3",""+(float)mvfield3,false);
							InsertInMap(MonthlyVariableBonus,"Field4",""+(float)mvfield4,false);
							InsertInMap(MonthlyVariableBonus,"Field5",""+(float)mvfield5,false);
							InsertInMap(MonthlyVariableBonus,"Field6",""+(float)mvfield6,false);
							InsertInMap(MonthlyVariableBonus,"Field7",""+(float)mvfield7,false);
							InsertInMap(MonthlyVariableBonus,"Field8",""+(float)mvfield8,false);
							InsertInMap(MonthlyVariableBonus,"pxObjClass",pxObjClass,false);
							InsertInMap(MonthlyVariableBonus,"Total",""+(float)MonthlyVariableBonus1,false);
							Component.put("MonthlyVariableBonus", MonthlyVariableBonus);

							payslipListMap.put("Component", Component);
							PayslipList.add(payslipListMap);
						}
					}
					IncomeDocumentListMap.put("PayslipDetails",PayslipList);
					IncomeDocumentList.add(IncomeDocumentListMap);

				}
				/**************ITR Documents****************/
				else if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("ITR DOCUMENT")){


					InsertInMap(IncomeDocumentListMap,"DocumentCategory","R0005",false);
					InsertInMap(IncomeDocumentListMap,"DocAccuracy","90",false);
					InsertInMap(IncomeDocumentListMap,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentType","T0356",false);
					InsertInMap(IncomeDocumentListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"OcrFlag","Y",false);
					InsertInMap(IncomeDocumentListMap,"PeriodLength","3",false);
					InsertInMap(IncomeDocumentListMap,"pxObjClass",pxObjClass,false);
					InsertInMap(IncomeDocumentListMap,"DocumentGroup","CC_9",false);
					InsertInMap(IncomeDocumentListMap,"Mandatory","M",false);


					ArrayList ITRDocList =new ArrayList();
					String pxObjectClassITR="SCB-Data-FinancialDetails-ITR";

					for (int i=1;i<2;i++)
					{
						LinkedHashMap iTRListMap =new LinkedHashMap();



						int total1 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total1", GetCase.scenarioID));
						int total2 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total2", GetCase.scenarioID));
						int total3 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total3", GetCase.scenarioID));
						int total4 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total4", GetCase.scenarioID));
						int total5 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total5", GetCase.scenarioID));
						int total6 = Integer.parseInt(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"total6", GetCase.scenarioID));


						int TotalIncome = total1+total2+total3+total4+total5+total6;
						LinkedHashMap Component =new LinkedHashMap();

						InsertInMap(iTRListMap,"IncomeListIndex","3",false);
						InsertInMap(iTRListMap,"GrandTotal",""+TotalIncome,false);
						InsertInMap(iTRListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DocumentStatus", GetCase.scenarioID),false);
						InsertInMap(iTRListMap,"Barcode", "Year"+i,false);
						InsertInMap(iTRListMap,"AuditedFlag", "Y",false);
						InsertInMap(iTRListMap,"Period", "1",false);
						InsertInMap(iTRListMap,"UserFlag", "true",false);
						InsertInMap(iTRListMap,"pxObjClass", pxObjectClassITR,false);


						LinkedHashMap BusinessIncome =new LinkedHashMap();

						InsertInMap(BusinessIncome,"ComponentName","Business Income",false);
						InsertInMap(BusinessIncome,"Field1","0",false);
						InsertInMap(BusinessIncome,"pxObjClass",pxObjClass,false);
						InsertInMap(BusinessIncome,"Total",""+(float)total1,false);
						Component.put("BusinessIncome", BusinessIncome);

						LinkedHashMap Depreciation =new LinkedHashMap();

						InsertInMap(Depreciation,"ComponentName","Depreciation",false);
						InsertInMap(Depreciation,"Field1","0",false);
						InsertInMap(Depreciation,"pxObjClass",pxObjClass,false);
						InsertInMap(Depreciation,"Total",""+(float)total2,false);
						Component.put("Depreciation", Depreciation);

						LinkedHashMap DirectorRemuneration =new LinkedHashMap();

						InsertInMap(DirectorRemuneration,"ComponentName","Director Remuneration",false);
						InsertInMap(DirectorRemuneration,"Field1","0",false);
						InsertInMap(DirectorRemuneration,"pxObjClass",pxObjClass,false);
						InsertInMap(DirectorRemuneration,"Total",""+(float)total3,false);

						Component.put("DirectorRemuneration", DirectorRemuneration);

						LinkedHashMap IncomeasperTaxFile =new LinkedHashMap();

						InsertInMap(IncomeasperTaxFile,"ComponentName","Income as per Tax File",false);
						InsertInMap(IncomeasperTaxFile,"Field1",""+(float)total4,false);
						InsertInMap(IncomeasperTaxFile,"pxObjClass",pxObjClass,false);
						InsertInMap(IncomeasperTaxFile,"Total",""+(float)total4,false);

						Component.put("IncomeasperTaxFile", IncomeasperTaxFile);

						LinkedHashMap OtherIncome =new LinkedHashMap();

						InsertInMap(OtherIncome,"ComponentName","OtherIncome",false);
						InsertInMap(OtherIncome,"Field1","0",false);
						InsertInMap(OtherIncome,"pxObjClass",pxObjClass,false);
						InsertInMap(OtherIncome,"Total",""+(float)total5,false);

						Component.put("OtherIncome", OtherIncome);

						LinkedHashMap ProfessionalIncome =new LinkedHashMap();

						InsertInMap(ProfessionalIncome,"ComponentName","Professional Income",false);
						InsertInMap(ProfessionalIncome,"Field1","0",false);
						InsertInMap(ProfessionalIncome,"pxObjClass",pxObjClass,false);
						InsertInMap(ProfessionalIncome,"Total",""+(float)total6,false);
						Component.put("ProfessionalIncome", ProfessionalIncome);
						iTRListMap.put("Component", Component);
						ITRDocList.add(iTRListMap);
					}
					IncomeDocumentListMap.put("ITR",ITRDocList);
					IncomeDocumentList.add(IncomeDocumentListMap);
				}
				/***************************************Bank Statements*********************************************************/
				else if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("BANK STATEMENT"))
				{
					InsertInMap(IncomeDocumentListMap,"DocumentCategory","R0005",false);
					InsertInMap(IncomeDocumentListMap,"DocAccuracy","90",false);
					InsertInMap(IncomeDocumentListMap,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"DocumentType","T0036",false);
					InsertInMap(IncomeDocumentListMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(IncomeDocumentListMap,"OcrFlag","Y",false);
					InsertInMap(IncomeDocumentListMap,"PeriodLength","3",false);
					InsertInMap(IncomeDocumentListMap,"pxObjClass",pxObjClass,false);
					InsertInMap(IncomeDocumentListMap,"DocumentGroup","CC_9",false);
					InsertInMap(IncomeDocumentListMap,"Mandatory","M",false);

					ArrayList BankStsList =new ArrayList();
					String pxObjectClassBankstatement="SCB-Data-FinancialDetails-BankStatement";

					for (int i=1;i<3;i++)
					{
						LinkedHashMap bankMap =new LinkedHashMap();
						//InsertInMap(IncomeDocumentListMap,"CustomerFullNameOcr",FullName);

						InsertInMap(bankMap,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_DocumentStatus", GetCase.scenarioID),true);
						InsertInMap(bankMap,"GrandTotal",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+i+"_CardGrandTotal", GetCase.scenarioID),true);
						InsertInMap(bankMap,"Barcode","Months"+i,false);
						InsertInMap(bankMap,"pxObjClass",pxObjectClassBankstatement,false);
						LinkedHashMap Component =new LinkedHashMap();

						LinkedHashMap MonthlySalesTurnover =new LinkedHashMap();
						InsertInMap(MonthlySalesTurnover,"ComponentName","Monthly Sales Turnover",false);
						InsertInMap(MonthlySalesTurnover,"pxObjClass",pxObjClass,false);
						Component.put("MonthlySalesTurnover",MonthlySalesTurnover);

						LinkedHashMap OnUSCash =new LinkedHashMap();
						InsertInMap(OnUSCash,"ComponentName","On-US Cash",false);
						InsertInMap(OnUSCash,"pxObjClass",pxObjClass,false);
						Component.put("OnUSCash",OnUSCash);

						LinkedHashMap OnUSGlobal =new LinkedHashMap();
						InsertInMap(OnUSGlobal,"ComponentName","On-US Global",false);
						InsertInMap(OnUSGlobal,"pxObjClass",pxObjClass,false);
						Component.put("OnUSGlobal",OnUSGlobal);

						LinkedHashMap OnUSOther =new LinkedHashMap();
						InsertInMap(OnUSGlobal,"ComponentName","On-US Other",false);
						InsertInMap(OnUSGlobal,"pxObjClass",pxObjClass,false);
						Component.put("OnUSOther",OnUSOther);

						LinkedHashMap SalaryCredit =new LinkedHashMap();
						InsertInMap(SalaryCredit,"ComponentName","Salary Credit",false);
						InsertInMap(SalaryCredit,"pxObjClass",pxObjClass,false);
						Component.put("SalaryCredit",SalaryCredit);
						bankMap.put("Component",Component);

						BankStsList.add(bankMap);
					}
					IncomeDocumentListMap.put("BankStatement",BankStsList);
					IncomeDocumentList.add(IncomeDocumentListMap);

				}
				/*******************************************Bonus Letters*******************************************************/
				else if(DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID).contains("BONUS"))
				{

					LinkedHashMap BonusLeeter =new LinkedHashMap();
					InsertInMap(BonusLeeter,"IncomeDocumentListMapjson","R0005",false);
					InsertInMap(BonusLeeter,"DocAccuracy","90",false);
					InsertInMap(BonusLeeter,"DocumentName",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(BonusLeeter,"DocumentRemarks",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentName", GetCase.scenarioID),false);
					InsertInMap(BonusLeeter,"DocumentType","T0023",false);
					InsertInMap(BonusLeeter,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),false);
					InsertInMap(BonusLeeter,"OcrFlag","Y",false);
					InsertInMap(BonusLeeter,"PeriodLength","1",false);
					InsertInMap(BonusLeeter,"pxObjClass",pxObjClass,false);
					InsertInMap(BonusLeeter,"DocumentGroup","CC_9",false);

					InsertInMap(BonusLeeter,"DocumentStatus",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DocumentStatus", GetCase.scenarioID),true);
					InsertInMap(BonusLeeter,"DocumentDate",DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"_IncomeDoc"+j+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone,true);
					InsertInMap(BonusLeeter,"Mandatory","O",false);
					IncomeDocumentList.add(BonusLeeter);
				}
			}
		}
		return IncomeDocumentList;
	}


	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList ProdDocumentList(String isPrimaryOrCoApp) throws ParseException
	{
		logger.info("--------------------------- ProdDocumentList Starts-------------------------------------------------------");
		ArrayList ProdDocumentList =new ArrayList();


		String i="";
		for(int j=1;j<=3;j++)
		{
			if(j!=0){i="_"+j;}
			System.out.println(isPrimaryOrCoApp+"Document_Category"+i);
			String DocCat=""+LOV_Codes.retriveDocumentCategoryCode(isPrimaryOrCoApp+"Document_Category"+i);

			LinkedHashMap ProdDocumentListMap =new LinkedHashMap();

			InsertInMap(ProdDocumentListMap,"DocumentCategDesc",isPrimaryOrCoApp+"Document_Category"+i,true);
			InsertInMap(ProdDocumentListMap,"DocumentCategory",DocCat,false);
			InsertInMap(ProdDocumentListMap,"DocumentName",LOV_Codes.retriveDocumentNameCode(isPrimaryOrCoApp+"Name_of_the_Document"+i),false);
			InsertInMap(ProdDocumentListMap,"IsDocumentAvailable","Y",false);
			InsertInMap(ProdDocumentListMap,"DocumentNumber",DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Number"+i, GetCase.scenarioID),false);
			InsertInMap(ProdDocumentListMap,"DocumentExpiryDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Expiry_Date"+i, GetCase.scenarioID)),false);
			InsertInMap(ProdDocumentListMap,"DocumentSignatureDate",LOV_Codes.changeGivenDateFormat(DBUtils.readColumnWithRowIDNew(isPrimaryOrCoApp+"Document_Signatory_Date"+i, GetCase.scenarioID)),false);
			InsertInMap(ProdDocumentListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

			ProdDocumentList.add(ProdDocumentListMap);

		}


		return ProdDocumentList;
	}

	@SuppressWarnings({"rawtypes" })
	public static ArrayList Names()
	{
		logger.info("--------------------------- NamesList Starts-------------------------------------------------------");
		ArrayList NamesList =new ArrayList();
		LinkedHashMap NamesListMap =new LinkedHashMap();

		String fullname=FullName("First_Name","Last_Name","Middle_Name");

		InsertInMap(NamesListMap,"FieldLength",""+fullname.length(),false);
		InsertInMap(NamesListMap,"FirstName","First_Name",true);
		InsertInMap(NamesListMap,"FullName",fullname,false);
		InsertInMap(NamesListMap,"LastName","Last_Name",true);
		InsertInMap(NamesListMap,"MiddleName","Middle_Name",true);
		InsertInMap(NamesListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data",false);

		return NamesList;

	}

	public static void main(String [] args)
	{
		logger.info(FullName("Swapnil","","Gour"));
	}

	public static String FullName(String dbcolumn_fn,String dbcolumn_mn,String dbcolumn_ln)
	{
		String fullname="";

		String FirstName = DBUtils.readColumnWithRowIDNew(dbcolumn_fn, GetCase.scenarioID);
		String MiddleName = ""+DBUtils.readColumnWithRowIDNew(dbcolumn_mn, GetCase.scenarioID);
		String LastName = DBUtils.readColumnWithRowIDNew(dbcolumn_ln, GetCase.scenarioID);

		if(MiddleName.contains("null") || MiddleName.equalsIgnoreCase("")){MiddleName=" ";}
		else{MiddleName=" "+MiddleName+" ";}
		fullname=FirstName+MiddleName+LastName;

		return fullname.replace("null", "");
	}

/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////// Basic/Blind Data Capture Maker //////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// */


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void createBasicBlindJson(JSONObject json) throws ClassNotFoundException, SQLException, IOException{
		DBUtils.convertDBtoMap("bdquery");

		LinkedHashMap BDCContentMap =new LinkedHashMap();

		String date2= LOV_Codes.getSysDate("YYYY-MM-dd");
		String fullname=FullName("First_Name","Last_Name","Middle_Name");

		InsertInMap(BDCContentMap,"AdditionalFulfilmentRequired","false",false);
		InsertInMap(BDCContentMap,"AllProductCategory","CC",false);
		InsertInMap(BDCContentMap,"AppCrtDt",date2,false);
		InsertInMap(BDCContentMap,"AppBrnch","Application_Branch",true);
		InsertInMap(BDCContentMap,"BarCode","0042",false);
		InsertInMap(BDCContentMap,"BundleIndicator","NA",false);
		InsertInMap(BDCContentMap,"ChannelRefNo","163731908-2",false);
		InsertInMap(BDCContentMap,"City","Chennai",false);
		InsertInMap(BDCContentMap,"ComputedProductValue","8",false);
		InsertInMap(BDCContentMap,"Currency","INR",false);
		InsertInMap(BDCContentMap,"CustFullName",fullname,false);
		InsertInMap(BDCContentMap,"FileNetDocURL","http://10.23.216.63:9080/ContentServices/JavaViewer.jsp?osName=RBOS&docId={DE0F58C9-0F92-408C-8816-479A08AF2F52}&bankId=1555616&requestToken=b5dc03fb2033fdea45b2e3b617ab1715&tokenSecret=0144ea905dfd06d6c77b0ba0cd1e7bea&indexValue=0",false);
		InsertInMap(BDCContentMap,"FileNetViewerURL","viewone",false);
		InsertInMap(BDCContentMap,"HighlighterRequired","true",false);
		InsertInMap(BDCContentMap,"PrimProdCateg","CC",false);
		InsertInMap(BDCContentMap,"ScanMaker","1556926",false);
		InsertInMap(BDCContentMap,"SearchBy","CASA",false);
		InsertInMap(BDCContentMap,"SegmentRpt","71",false);
		InsertInMap(BDCContentMap,"SignatureCaptureRequired","false",false);
		InsertInMap(BDCContentMap,"SourceRefNo","AOIN-1544080-201217-000023-01",false);
		InsertInMap(BDCContentMap,"SrcID","Sorucing_ID",true);

		BDCContentMap.put("Customers",BasicDataCustomer());
//			BDCContentMap.put("Documents",DocumentList(""));
		BDCContentMap.put("ApplicationInfo",BDCApplication());
		BDCContentMap.put("OfferInitial",OfferInitialBDC());

		JsonPath.parse(json).set("$.content",BDCContentMap);

	}

	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList BasicDataCustomer() throws ClassNotFoundException, SQLException, IOException
	{
		ArrayList CustomerList =new ArrayList();

		String isPrimaryOrCoApp="";
		for(int i=0;i<4;i++)
		{
			if(i!=0){isPrimaryOrCoApp="Coapplicant"+i+"_";}
			LinkedHashMap customerMap =new LinkedHashMap();


			String DbValue = FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name");
			logger.info(isPrimaryOrCoApp+"FullName : "+DbValue);
			logger.info("Iteration is :"+i);

			if(DbValue.length()>3)
			{
				InsertInMap(customerMap,"ProfileType",LOV_Codes.getProfileTypeCode("CLIENT"),false);
				InsertInMap(customerMap,"Title",LOV_Codes.TitleCode(isPrimaryOrCoApp+"Title"),false);
				InsertInMap(customerMap,"FirstName",isPrimaryOrCoApp+"First_Name",true);
				InsertInMap(customerMap,"MiddleName",isPrimaryOrCoApp+"Middle_Name",true);
				InsertInMap(customerMap,"LastName",isPrimaryOrCoApp+"Last_Name",true);
				InsertInMap(customerMap,"FullName",FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name"),false);
				InsertInMap(customerMap,"DateOfBirth","19910925",false);//isPrimaryOrCoApp+"DOB"
				InsertInMap(customerMap,"CountryOfBirth",LOV_Codes.CountryCode(isPrimaryOrCoApp+"Country_Of_Birth_Description"),false);
				InsertInMap(customerMap,"CountryOfBirthDescription",isPrimaryOrCoApp+"Country_Of_Birth_Description",true);
				InsertInMap(customerMap,"CountryOfResidence",LOV_Codes.CountryCode(isPrimaryOrCoApp+"Residence_Country_Description"),false);
				InsertInMap(customerMap,"CountryOfResidenceDescription",isPrimaryOrCoApp+"Residence_Country_Description",true);
				InsertInMap(customerMap,"CountryOfBirth",LOV_Codes.CountryCode(isPrimaryOrCoApp+"Country_Of_Birth_Description"),false);
				InsertInMap(customerMap,"Nationality",LOV_Codes.getNationalityCodeNew(isPrimaryOrCoApp+"Nationality_Description1"),false);

				InsertInMap(customerMap,"ClientType","P",false);//LOV-- unable to open confluece link
				InsertInMap(customerMap,"EmbossedName",FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name"),false);
				InsertInMap(customerMap,"LegalName",FullName(isPrimaryOrCoApp+"First_Name",isPrimaryOrCoApp+"Middle_Name",isPrimaryOrCoApp+"Last_Name"),false);
				InsertInMap(customerMap,"AadhaarExemptStates","Y",false);
				InsertInMap(customerMap,"AnonymityRequired","N", false);
				InsertInMap(customerMap,"BureauConsentFlag","Y",false);
				InsertInMap(customerMap,"MobileBanking","N",false);
				InsertInMap(customerMap,"OcrFlag","Y", false);
				InsertInMap(customerMap,"OtherRiskFactors","None", false);
				InsertInMap(customerMap,"pxObjClass","SCB-IN-AppWorkFlow-Data-Customer",false);


//				if(i==0)
//				{
//					//ETB Fields:
//					InsertInMap(customerMap,"Qualification",LOV_Codes.EducationalQualificationCode("ETBQualification"),false);
//					InsertInMap(customerMap,"RelationshipNumber","RelationshipNo",true);
//					InsertInMap(customerMap,"EducationStatus",LOV_Codes.EducationalQualificationCode("ETBQualification"),false);
//					InsertInMap(customerMap,"ETBRegMobNo","",false);
//				}

				customerMap.put("AliasNameInfo",AliasNameInfo(isPrimaryOrCoApp));
				customerMap.put("Employment",Employment_BDC(isPrimaryOrCoApp));
				customerMap.put("DocumentList",DocumentList(isPrimaryOrCoApp));
				customerMap.put("Contacts",setCustomerContact(isPrimaryOrCoApp));
//				customerMap.put("IDDocumentList",IDDocumentList(isPrimaryOrCoApp));
//				customerMap.put("VerfDocumentList",VerfDocumentList(isPrimaryOrCoApp));
				customerMap.put("NationalityList",NationalityList(isPrimaryOrCoApp));
//				customerMap.put("Addresses",Address_BDC(isPrimaryOrCoApp));

				logger.info("customerMap: "+customerMap);
				CustomerList.add(customerMap);

			}}
		return CustomerList;
	}


	@SuppressWarnings({ "rawtypes" })
	public static LinkedHashMap Employment_BDC(String isPrimaryOrCoApp) throws ClassNotFoundException, SQLException, IOException
	{
		logger.info("--------------------------- Employment_BDC Starts-------------------------------------------------------");
		LinkedHashMap EmploymentMap =new LinkedHashMap();

		InsertInMap(EmploymentMap,"ProfessionCode", LOV_Codes.ProfessionCodeNew(isPrimaryOrCoApp+"Occupation_Description"),false);
		InsertInMap(EmploymentMap,"pxObjClass", "SCB-Data-EmploymentInfo",false);
		InsertInMap(EmploymentMap,"ProfessionDescription", isPrimaryOrCoApp+"Occupation_Description",true);
		InsertInMap(EmploymentMap,"Industry", LOV_Codes.getISICDesc(isPrimaryOrCoApp+"ISIC_Description"),false);
		InsertInMap(EmploymentMap,"IndustryDescription", isPrimaryOrCoApp+"ISIC_Description",true);

		return EmploymentMap;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static LinkedHashMap OfferInitialBDC()
	{
		LinkedHashMap OfferInitialMap =new LinkedHashMap();

		InsertInMap(OfferInitialMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Offer",false);
		OfferInitialMap.put("Products",setBDCProductDetails());

		return OfferInitialMap;

	}

	@SuppressWarnings({"unchecked","rawtypes"})
	public static ArrayList setBDCProductDetails()
	{


		ArrayList List =new ArrayList();
		logger.info("---------------------------------------- Offer Initial- Products-------------------------------------------------------");

		String j="";
		for(int i=0;i<=4;i++)
		{
			if (i!=0){ j=""+i;}

			String Campaigncode = ""+DBUtils.readColumnWithRowIDNew("Campaigncode"+j, GetCase.scenarioID);
			logger.info("Campaigncode"+j+" is :"+Campaigncode+" & Length is "+Campaigncode.length());
			if(Campaigncode.length()>0)
			{
				LinkedHashMap ProductsMap =new LinkedHashMap();

				InsertInMap(ProductsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Product-",false);
				InsertInMap(ProductsMap,"BundleType","IsBundle",true);
				InsertInMap(ProductsMap,"CampaignCode","Campaigncode"+j,true);
				InsertInMap(ProductsMap,"CampaignUsage","A",false);
				InsertInMap(ProductsMap,"ConsolidatedFlag","N",false);
				InsertInMap(ProductsMap,"Currency","Account_Currency_Code"+j,true);
				InsertInMap(ProductsMap,"CustomerE2ETATmet","1",false);
				InsertInMap(ProductsMap,"EmployeeBanking","N",false);
				InsertInMap(ProductsMap,"InterestFrqcy","Q",false);
				InsertInMap(ProductsMap,"IsAccountType","Account_Request_Type",true);
				InsertInMap(ProductsMap,"LienExpiryDate","2099-03-31",false);
				InsertInMap(ProductsMap,"LienNarration","LIEN MARKED FOR FUTURE LOCKER RENTALS",false);
				InsertInMap(ProductsMap,"LinkageYN","N",false);
				InsertInMap(ProductsMap,"MoneyMasterLink","N",false);
				InsertInMap(ProductsMap,"NumberOfDeposit","1",false);
				InsertInMap(ProductsMap,"ProductCategory","ProductCategory"+j,true);
				InsertInMap(ProductsMap,"ProductCode","ProductCode"+j,true);
				InsertInMap(ProductsMap,"ProductDescription","ProductDescription",true);
				InsertInMap(ProductsMap,"AccOpeningDate","2018-05-30T18:10:17.478Z",false);
				InsertInMap(ProductsMap,"Purpose","Purpose_of_account_opening",true);
				InsertInMap(ProductsMap,"RefAccountCurrency","INR",false);
				InsertInMap(ProductsMap,"TwoInOneCurrency","INR",false);
				InsertInMap(ProductsMap,"UserCode1","BP",false);
				InsertInMap(ProductsMap,"UserCode2","CB",false);
				InsertInMap(ProductsMap,"ValueDate", LOV_Codes.getSysDate("YYYYMMdd"),false);

				String CampaignCode = DBUtils.readColumnWithRowIDNew("Campaigncode"+j,GetCase.scenarioID);
				String AcctReqType = DBUtils.readColumnWithRowIDNew("Account_Request_Type"+j, GetCase.scenarioID);
				String Producttype= DBUtils.readColumnWithRowIDNew("ProductCategory"+j, GetCase.scenarioID);

				switch(Producttype)
				{
					case"CA":
						logger.info("---------------------------Product Type is CA-------------------------------------------------------");
						break;
					case"SA":

						logger.info("---------------------------Product Type is SA-------------------------------------------------------");
						InsertInMap(ProductsMap,"AcquisitionOrUsageIndicator","A",false);
						InsertInMap(ProductsMap,"DupAllowed","Y",false);
						InsertInMap(ProductsMap,"IsResident","Y",false);

						if(CampaignCode.contains("NRO")){
							InsertInMap(ProductsMap,"SubCategory","NRO",false);
							InsertInMap(ProductsMap,"IsResident","N",false);}
						else if(CampaignCode.contains("NRE")) {
							InsertInMap(ProductsMap,"SubCategory","NRE",false);
							InsertInMap(ProductsMap,"IsResident","N",false);}

						if(AcctReqType.equalsIgnoreCase("Existing")) {
							InsertInMap(ProductsMap,"AccountNumber","ETBAccountNumber",true);
							InsertInMap(ProductsMap,"NatureOfServices","Service_Type",true);
							//	InsertInMap(ProductsMap,"AccountStatus","",true);----> (derived based on account no.)
						}else if(AcctReqType.equalsIgnoreCase("Insta")) {InsertInMap(ProductsMap,"AccountNumber","Account_Number",true);}

						break;


					case"CC":
						logger.info("---------------------------Product Type is CC-------------------------------------------------------");
						if(AcctReqType.equalsIgnoreCase("Existing")) {
							InsertInMap(ProductsMap,"AccountNumber","ETBAccountNumber",true);
							InsertInMap(ProductsMap,"NatureOfServices","Service_Type",true);}
						else if(AcctReqType.equalsIgnoreCase("Insta")) {InsertInMap(ProductsMap,"AccountNumber","Account_Number",true);}
						break;

					case"PL":
						logger.info("---------------------------Product Type is PL-------------------------------------------------------");
						if(CampaignCode.contains("TOPUP")){
							InsertInMap(ProductsMap,"AcquisitionOrUsageIndicator","U",false);
							InsertInMap(ProductsMap,"CampaignUsage","U",false);
							InsertInMap(ProductsMap,"UsageType","TPL",false);}
						else{InsertInMap(ProductsMap,"AcquisitionOrUsageIndicator","A",false);}
						InsertInMap(ProductsMap,"IsAccountType","Existing",false);
						InsertInMap(ProductsMap,"TopUpType","A",false);
						break;

					case"TD":
						logger.info("---------------------------Product Type is TD-------------------------------------------------------");
						break;

					default:
						logger.info("---------------------------Invalid Product Type --> "+Producttype+"-------------------------------------------------------");
						break;

				}

				ProductsMap.put("ApplicantProductRelationship",ApplicantProductRelationship());
				//ProductsMap.put("CCEmbossedList",CCEmbossedList());
				List.add(ProductsMap);
			}else{logger.info("Campaigncode"+j+" --->"+Campaigncode+" is not available in DB");}
		}

		return List;
	}



	@SuppressWarnings({"rawtypes","unchecked"})
	public static ArrayList ApplicantProductRelationship()
	{
		ArrayList ApplicantRelationshipList =new ArrayList();
		logger.info("--------------------------- Applicant Product Relationship Starts ------------------------------------------------");

		int count=1;String PrimaryOrCoApp="";String RelatedPartyTypeDB="";String RelatedPartyType=PrimaryOrCoApp+"Relationship_Type";

		for(int i=0;i<=4;i++)
		{

			LinkedHashMap ApplicantProductRelationshipMap =new LinkedHashMap();
			if(!(i==0)){PrimaryOrCoApp="Coapplicant"+i+"_";RelatedPartyType=PrimaryOrCoApp+"RelatedPartyType";}

			if(i==0){RelatedPartyTypeDB="Primary(Client)";}
			else{RelatedPartyTypeDB = ""+DBUtils.readColumnWithRowIDNew(RelatedPartyType, GetCase.scenarioID);}

			String fullname=""+FullName(PrimaryOrCoApp+"First_Name",PrimaryOrCoApp+"Last_Name",PrimaryOrCoApp+"Middle_Name").replace("null", "");

			String firstName = ""+DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"First_Name", GetCase.scenarioID);

			logger.info("ApplicantProductRelationship full name is "+fullname);
			logger.info("RelatedPartyTypeDB is "+RelatedPartyTypeDB);

			if(firstName.replace("null", "").length()>1)
			{
				InsertInMap(ApplicantProductRelationshipMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Customer",false);
				InsertInMap(ApplicantProductRelationshipMap,"FullName",fullname, false);
				InsertInMap(ApplicantProductRelationshipMap,"RelatedPartyType",LOV_Codes.getRelatedParty(RelatedPartyTypeDB), false);
				InsertInMap(ApplicantProductRelationshipMap,"CustomerIndex",""+count, false);count++;
				ApplicantRelationshipList.add(ApplicantProductRelationshipMap);}
			else {logger.info("No ApplicantProductRelationship present in DB for "+PrimaryOrCoApp);}
		}
		return ApplicantRelationshipList;
	}



	@SuppressWarnings({"rawtypes","unchecked"})
	public static ArrayList CCEmbossedList()
	{
		ArrayList CCEmbossedList =new ArrayList();
		logger.info("--------------------------- Applicant Product Relationship Starts ------------------------------------------------");

		String PrimaryOrCoApp="";
		String RelatedPartyType=PrimaryOrCoApp+"Relationship_Type";
		String RelatedPartyTypeDB="";
		for(int i=0;i<=4;i++)
		{

			LinkedHashMap CCEmbossedMap =new LinkedHashMap();
			if(!(i==0)){PrimaryOrCoApp="Coapplicant"+i+"_";RelatedPartyType=PrimaryOrCoApp+"RelatedPartyType";}

			if(i==0){RelatedPartyTypeDB="Primary(Client)";}
			else{RelatedPartyTypeDB = ""+DBUtils.readColumnWithRowIDNew(RelatedPartyType, GetCase.scenarioID);}

			String fullname=FullName(PrimaryOrCoApp+"First_Name",PrimaryOrCoApp+"Last_Name",PrimaryOrCoApp+"Middle_Name");
			String firstName = ""+DBUtils.readColumnWithRowIDNew(PrimaryOrCoApp+"First_Name", GetCase.scenarioID);

			logger.info("CCEmbossedMap full name is "+fullname);
			logger.info("RelatedPartyTypeDB is "+RelatedPartyTypeDB);

			if(firstName.replace("null", "").length()>3)
			{
				InsertInMap(CCEmbossedMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Customer",false);
				InsertInMap(CCEmbossedMap,"FullName",fullname, false);
				InsertInMap(CCEmbossedMap,"RelatedPartyType",LOV_Codes.getRelatedParty(RelatedPartyTypeDB), false);
				CCEmbossedList.add(CCEmbossedMap);
			}
			else {logger.info("No CCEmbossedMap present in DB for "+PrimaryOrCoApp);}
		}
		return CCEmbossedList;
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////---- Applications Tab----////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@SuppressWarnings({ "rawtypes"})
	public static LinkedHashMap BDCApplication() throws ClassNotFoundException, SQLException, IOException{

		LinkedHashMap ApplicationMap =new LinkedHashMap();

		InsertInMap(ApplicationMap,"AcquisitionCode",LOV_Codes.getAcquisitionCode("Acquisition_Channel"),false);
		InsertInMap(ApplicationMap,"AOFDate",LOV_Codes.getSysDate("YYYY-MM-dd"),false);
//		InsertInMap(ApplicationMap,"AppCreationDate",LOV_Codes.appCreationDateFormat(),false);
		InsertInMap(ApplicationMap,"ApplicationBranch","Application_Branch",true);
		InsertInMap(ApplicationMap,"BranchCode","Application_Branch",true);
		InsertInMap(ApplicationMap,"BranchName","Application_Branch_Description",true);
		InsertInMap(ApplicationMap,"CountryOfAccountOpening","IN",false);
		InsertInMap(ApplicationMap,"OperatingInst","001",false);
		InsertInMap(ApplicationMap,"Priority","Y",false);
		InsertInMap(ApplicationMap,"pxObjClass","SCB-Data-BankUse",false);
		InsertInMap(ApplicationMap,"ReferralID","Referral_ID",true);
		InsertInMap(ApplicationMap,"SalesID","Sorucing_ID",true);
		InsertInMap(ApplicationMap,"Segment","71",false);
		InsertInMap(ApplicationMap,"SourceChannel","eOPS",false);
		InsertInMap(ApplicationMap,"SourceID","Sorucing_ID",true);
		InsertInMap(ApplicationMap,"SourcingCity","Application_Branch",true);

		return ApplicationMap;

	}

	////////////////////////////////////////// Products Details//////////////////////////////////////////////////////


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static LinkedHashMap OfferInitialFDC() throws ClassNotFoundException, SQLException, IOException
	{

		LinkedHashMap OfferInitialMap =new LinkedHashMap();
		InsertInMap(OfferInitialMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Offer",false);
		OfferInitialMap.put("Products",setProductDetailsFDC());

		return OfferInitialMap;

	}

	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList setProductDetailsFDC() throws ClassNotFoundException, SQLException, IOException {

		ArrayList List =new ArrayList();
		String j = "";
		for (int i = 0; i<1; i++) {
			if (i!=0){j=""+i;}

			LinkedHashMap productMap =new LinkedHashMap();

			DBUtils.convertDBtoMap("bdquery");
			String Campaigncode=""+DBUtils.readColumnWithRowIDNew("Campaigncode"+j, GetCase.scenarioID);
			String Account_Request_Type=""+DBUtils.readColumnWithRowIDNew("Account_Request_Type"+j, GetCase.scenarioID);
			String ProductCode=""+DBUtils.readColumnWithRowIDNew("ProductCode"+j, GetCase.scenarioID);
			String ProductDescription=""+DBUtils.readColumnWithRowIDNew("ProductDescription"+j, GetCase.scenarioID);
			String Lien_Expiry_Date =""+DBUtils.readColumnWithRowIDNew("Lien_Expiry_Date", GetCase.scenarioID);
			String Purpose_of_account_opening =""+DBUtils.readColumnWithRowIDNew("Purpose_of_account_opening "+j, GetCase.scenarioID);
			String ProductCategory= ""+DBUtils.readColumnWithRowIDNew("ProductCategory"+j, GetCase.scenarioID);
			String IsBundle= ""+DBUtils.readColumnWithRowIDNew("IsBundle", GetCase.scenarioID);
			String Branch_Description = "" + DBUtils.readColumnWithRowIDNew("Application_Branch_Description", GetCase.scenarioID);
			String Branch_Code = "" + DBUtils.readColumnWithRowIDNew("Application_Branch", GetCase.scenarioID);

			System.out.println("-------------------------------------&&&&&&&------------------------------------------------------------------------");
			System.out.println("Campaigncode is "+Campaigncode);
			System.out.println("Account_Request_Type is "+Account_Request_Type);
			System.out.println("ProductCode is "+ProductCode);
			System.out.println("ProductDescription is "+ProductDescription);
			System.out.println("Lien_Expiry_Date is "+Lien_Expiry_Date);
			System.out.println("Purpose_of_account_opening is "+Purpose_of_account_opening);
			System.out.println("ProductCategory is "+ProductCategory);


			productMap.put("ApplicantProductRelationship",ApplicantProductRelationship());
			InsertInMap(productMap,"CampaignCode",Campaigncode,false);


			System.out.println("-------------------------------------&&&&&&&------------------------------------------------------------------------");

			DBUtils.convertDBtoMap("fdquery");

			InsertInMap(productMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Product-",false);
			InsertInMap(productMap,"ProductCode",ProductCode, false);
			InsertInMap(productMap,"ProductDescription",ProductDescription, false);
			InsertInMap(productMap,"ProductCategory",ProductCategory, false);
			InsertInMap(productMap,"BundleType",IsBundle,false);
			InsertInMap(productMap,"AcquisitionOrUsageIndicator","AcquisitionUsage", true);
			InsertInMap(productMap,"PLODSpecialRate","Special_Rate",true);
			InsertInMap(productMap,"AssessmentType","Assessment_Type",true);
			InsertInMap(productMap,"RefAccountCurrency","INR",false);
			InsertInMap(productMap,"ProductAddrType",LOV_Codes.getAddressesType("Address1_Address_Type"),false);
//        	productMap.put("ProductAddressInfo", productAddress());

			//Account Setup Section:
			InsertInMap(productMap,"Purpose",Purpose_of_account_opening,false);
			InsertInMap(productMap,"RefAccountCurrency","INR",false);
			InsertInMap(productMap,"RefAccountCurrency","Account_Request_Type"+j,true);
			InsertInMap(productMap,"Currency","INR",false);


			String RepaymentMode = LOV_Codes.getRepaymentModeCode("Repayment_mode");
			System.out.println("RepaymentMode :"+RepaymentMode);

			switch(ProductCategory){

				case "CC" :
					productMap.put("CCEmbossedList",CCEmbossedList());

					InsertInMap(productMap,"BillingCycle","Billing_Cycle", true);
					InsertInMap(productMap,"CardFaceCode","VI", false);
					InsertInMap(productMap,"CCMSProductCode",ProductCode, false);
					InsertInMap(productMap,"Lez_Code","Lez_Code", true);
					InsertInMap(productMap,"RepaymentAccountNumber","Repayment_Account_Number", true);//LOV-POST DATED CHEQUE
					InsertInMap(productMap,"RepaymentMode","Repayment_mode", true);
					InsertInMap(productMap,"PreferredLimit","Preferred_Limit", true);
					InsertInMap(productMap,"TermDepositSecuredCC","Term_deposit_on_secured_CC_value", true);

					productMap.put("FeeInfo",setFeeInfoList(Campaigncode,ProductCode));

					System.out.println("--------------------------RepaymentInfo------------------------------------------------");

					InsertInMap(productMap, "AccountNumber ", "Repayment_Account_Number", true);
					InsertInMap(productMap, "AccountType ",  LOV_Codes.getRepaymentAccountType("Repayment_Account_Type"),false);
					if(RepaymentMode.contains("EDA") || RepaymentMode.contains("SI")){
						InsertInMap(productMap, "BankSortCode ", "Bank_Sort_Code", true);
						InsertInMap(productMap, "BranchDescription", "Application_Branch_Description", true);
						InsertInMap(productMap, "DebitType ", "Debit_Type", true);
						InsertInMap(productMap,"AutoDebitAmt","Auto_Debit_Amount", true);
					}
					if(RepaymentMode.contains("EDA")) {
						InsertInMap(productMap, "EDAName ", "EDA_Account_holder_Name", true);
						InsertInMap(productMap, "IFSCCode ", "IFSC_code", true);
						InsertInMap(productMap, "BankUtilityName ", "BankPreUtility_Name", true);
						InsertInMap(productMap, "BeneficiaryBankRegionName", "Address1_City", true);
						InsertInMap(productMap, "MonthlyRepaymentDueDt", "Monthly_Repayment_Due_Date", true);
					}
					if(RepaymentMode.contains("PDC")) {
						System.out.println("-------------------Repayment Mode=PDC-POST DATA CHEQUE--------------------------------");
						InsertInMap(productMap, "autodebitamount ", "Auto_Debit_Amount", true);
					}

					break;

				case "PL":
					InsertInMap(productMap, "CampaignCode ", Campaigncode, true);
					InsertInMap(productMap, "ProductCategory ", ProductCategory, true);
					InsertInMap(productMap, "ProductCode ", ProductCode, true);
					InsertInMap(productMap, "BundleIndicator ", "NA", false);
					InsertInMap(productMap, "AcquisitionOrUsageIndicator ", "AcquisitionUsage", true);
					InsertInMap(productMap, "AssessmentType", LOV_Codes.getAssessmentType("Assessment_Type"), false);
					InsertInMap(productMap, "RequestedAmount", "Requested_Amount", true);
					InsertInMap(productMap, "RequestedTenor ", "Requested_Tenure ", true);
					InsertInMap(productMap, "PurposeOfLoan ",LOV_Codes.getPurposeOfLoanCode("Purpose_of_Loan"), true);
					InsertInMap(productMap, "RequestedEffectiveRate ", "Requested_EffectiveRate ", true);
					InsertInMap(productMap, "ApprovedEffectiveRate ", "Approved_EffectiveRate ", true);
					InsertInMap(productMap, "PLODSpecialRate", "Special_Rate", true);
					System.out.println("--------------------------Fee Details------------------------------------------------");
					productMap.put("FeeInfo", setFeeDetails());
					System.out.println("--------------------------Repayment Details------------------------------------------------");
					if(RepaymentMode == "EDA" || RepaymentMode == "PDC" || RepaymentMode.contains("SI")){
						InsertInMap(productMap,"RepaymentMode","Repayment_mode", true);
						InsertInMap(productMap, "Frequency ", LOV_Codes.getFrequency("Frequency"), false);
						InsertInMap(productMap, "EffectiveDate ", "Effective_Date", true);
					}
					if(RepaymentMode == "EDA" || RepaymentMode == "SI"){
						InsertInMap(productMap, "BankSortCode ", "Bank_Sort_Code", true);
						InsertInMap(productMap, "BranchDescription", Branch_Description, true);
						InsertInMap(productMap, "DebitType ", "Debit_Type", true);
					}
					if(RepaymentMode == "EDA"){
						InsertInMap(productMap, "RepaymentAccountNumber ", "Repayment_Account_Number", true);
						InsertInMap(productMap, "EDAName ", "EDA_Account_holder_Name", true);
						InsertInMap(productMap, "BankUtilityName ", "BankPreUtility_Name", true);
						InsertInMap(productMap, "BeneficiaryBankRegionName", "Address1_City", true);
						InsertInMap(productMap, "MonthlyRepaymentDueDt", "Monthly_Repayment_Due_Date", true);
						InsertInMap(productMap, "ExpiryDate ", "Expiry_Date", true);
						productMap.put("RepaymentDetails", setRepaymentDetails(Branch_Code));
					}
					if(RepaymentMode=="PDC"){
						InsertInMap(productMap, "RepaymentAccountNumber ", "Repayment_Account_Number", true);
						InsertInMap(productMap, "PDCTotalChequeNo", "PDCTotal_cheque_No", true);
						productMap.put("PDCChequeDetails", getPDCChequeDetails());
					}
					if(RepaymentMode == "SI" || RepaymentMode == "PDC"){
						InsertInMap(productMap, "AccountType ", LOV_Codes.getAccountType("Repayment_Account_Type"), false);
					}
					System.out.println("--------------------------Disbursement Details------------------------------------------------");
					String Disbursementmode =  LOV_Codes.getDisbursementmode("Disbursement_mode");
					if(Disbursementmode == "01" || Disbursementmode == "02" || Disbursementmode == "03" || Disbursementmode == "04"){
						InsertInMap(productMap, "DrawDownMode ","Disbursement_mode" , true);
						InsertInMap(productMap, "BenificiaryName ", "Beneficiary_Name ", true);
						InsertInMap(productMap, "BenificiaryBank ", "Beneficiarys_Bank ", true);
						InsertInMap(productMap, "BeneficiaryACNumber ", "Beneficiary_APreC_Number ", true);
						if(Disbursementmode == "01"){
							InsertInMap(productMap, "DisbursementIFSC ", "Disbursement_IFSC", true);
							InsertInMap(productMap, "PayOrderDate ", "Pay_Order_Date", true);
							InsertInMap(productMap, "PayOrderHandOverDt ", "Pay_order_hand_over_date", true);
							InsertInMap(productMap, "PayOrderAmount ", "Pay_Order_amount", true);
							InsertInMap(productMap, "DebitAccount ", "Debit_Account", true);
							InsertInMap(productMap, "PickUpMethod ", LOV_Codes.getPickUpMethod("Pick_Up_Method"), false);
							InsertInMap(productMap, "PickUpBy ", LOV_Codes.getPickUpBy("Pick_up_by"), false);
							InsertInMap(productMap, "PrintLocation ", "Address1_City", true);
							InsertInMap(productMap, "ClearingZoneCode ", LOV_Codes.getClearingZonecode("Clearing_Zone_code"), false);
							InsertInMap(productMap, "Pincode", "Address1_Zip_Code", true);
							//InsertInMap(productMap, "PayableLocationCode", "", false); no DB column
							InsertInMap(productMap, "Bank_Name", "BankPreUtility_Name", true);
						}
						if(Disbursementmode == "02" || Disbursementmode == "03" || Disbursementmode == "04"){
							InsertInMap(productMap, "AdvanceEMI ", "Advance_EMI ", true);
						}
						if(Disbursementmode == "02"){
							InsertInMap(productMap, "BeneficiarybankMICRcode ", "Beneficiary_bank_MICR_code", true);
						}
						if(Disbursementmode == "03" || Disbursementmode == "04" ){

							InsertInMap(productMap, "DisbursementIFSC ", "Disbursement_IFSC ", true);
						}
					}
					InsertInMap(productMap, "LoanNotes", "Loan_Notes", true);
					break;

			}

			InsertInMap(productMap,"AccOpeningDate","2018-06-04T07:31:19.954Z",false);
			InsertInMap(productMap,"AssessmentType","Assessment_Type", true); //---> CC/PL
			InsertInMap(productMap,"BeneficiaryBankRegionName","Address1_City",true);
			InsertInMap(productMap,"LienNarration","LIEN MARKED FOR FUTURE LOCKER RENTALS",false);
			InsertInMap(productMap,"CampaignUsage","A",false);
			InsertInMap(productMap,"ConsolidatedFlag","Consolidated_Flag",true);//LOV
			InsertInMap(productMap,"EmployeeBanking","N",false);
			InsertInMap(productMap,"InterestFrqcy","Q",false);
			InsertInMap(productMap,"IsAccountType",Account_Request_Type,false);
			InsertInMap(productMap,"IsChequeBookRequiredFlag","Cheque_Book_Required", true);
			InsertInMap(productMap,"LienExpiryDate","Lien_Expiry_Date", true);
			InsertInMap(productMap,"LiableOrLending","Lending",false);
			InsertInMap(productMap,"ProductBranch","Application_Branch", true);
			InsertInMap(productMap,"ProductAddrType",LOV_Codes.getAddressesType("Product_address_type"),false);
			InsertInMap(productMap,"ProductStep","Data Capture",false);
			InsertInMap(productMap,"ProductTaskName","FullDataCapture",false);

//            productMap.put("ProductAddressInfo",productAddress());
//            productMap.put("MISPage",setProductMISPAge());
			List.add(productMap);

		}
		return List;
	}

	@SuppressWarnings({ "rawtypes" })
	public static ArrayList setFeeDetails(){
		ArrayList FeeDetailsList =new ArrayList();
		LinkedHashMap FeeDetailsMap =new LinkedHashMap();
		InsertInMap(FeeDetailsMap,"FeeCode ",LOV_Codes.getFeeCode("Fee_Code"),false);
		InsertInMap(FeeDetailsMap,"FeeType ","Fee_Type",true);
		InsertInMap(FeeDetailsMap,"Description ","Fee_Code",true);
		InsertInMap(FeeDetailsMap,"OriginalFeeAmount","Original_Fee_Amount",true);
		InsertInMap(FeeDetailsMap,"RequestedFeeAmount","Requested_Fee_Amount",true);
		InsertInMap(FeeDetailsMap,"ApprovedFeeAmount","Final_Fee_Amount",true);
		FeeDetailsList.add(FeeDetailsMap);
		return FeeDetailsList;
	}

	@SuppressWarnings({ "rawtypes" })
	public static ArrayList setRepaymentDetails(String Branch_Code){
		ArrayList RepaymentDetailsList =new ArrayList();
		LinkedHashMap RepaymentDetailsMap =new LinkedHashMap();
		InsertInMap(RepaymentDetailsMap, "BankORUtilityName ", "BankPreUtility_Name", true);
		InsertInMap(RepaymentDetailsMap, "AccountNumber ", "Repayment_Account_Number", true);
		InsertInMap(RepaymentDetailsMap, "AccountType ",  LOV_Codes.getRepaymentAccountType("Repayment_Account_Type"), false);
		InsertInMap(RepaymentDetailsMap, "IFSCCode ", "IFSC_code", true);
		InsertInMap(RepaymentDetailsMap, "pxObjClass ", "SCB-Data-Repayment", false);
		InsertInMap(RepaymentDetailsMap, "CityName ", "Address1_City", true);
		InsertInMap(RepaymentDetailsMap,"BranchCode",Branch_Code,true);
		InsertInMap(RepaymentDetailsMap, "Frequency ", LOV_Codes.getFrequency("Frequency"), false);
		InsertInMap(RepaymentDetailsMap, "EffectiveDate ", "Effective_Date", true);
		InsertInMap(RepaymentDetailsMap, "DebitType ", "Debit_Type", true);
		InsertInMap(RepaymentDetailsMap, "EDAName ", "EDA_Account_holder_Name", true);
		InsertInMap(RepaymentDetailsMap, "ExpiryDate ", "Expiry_Date", true);
		InsertInMap(RepaymentDetailsMap, "RepaymentMode ", LOV_Codes.getRepaymentModeCode("Repayment_mode"), false);
		RepaymentDetailsList.add(RepaymentDetailsMap);
		return RepaymentDetailsList;
	}
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList getPDCChequeDetails(){
		ArrayList PDCChequeList = new ArrayList();
		LinkedHashMap PDCChequeMap = new LinkedHashMap();
		InsertInMap(PDCChequeMap, "PDCChequeNo", "PDCCheque_No", true);
		InsertInMap(PDCChequeMap, "PDCChequeValue ", "PDCCheque_Value", true);
		InsertInMap(PDCChequeMap, "PDCChequeValueCurrency ", "PDCTotal_Cheque_Value_Currency", true);
		InsertInMap(PDCChequeMap, "PDCEffectiveDate ", "PDCEffective_Date", true);
		InsertInMap(PDCChequeMap, "PDCExpiryDate ", "PDCExpiry_Date", true);
		InsertInMap(PDCChequeMap, "pxObjClass ", "SCB-Data", false);
		PDCChequeList.add(PDCChequeMap);
		return PDCChequeList;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList productAddress() throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("----------------------- Product Address Starts-------------------------------------------------------");
		ArrayList AddressList =new ArrayList();
		LinkedHashMap ProductAddressMap =new LinkedHashMap();
		InsertInMap(ProductAddressMap,"AddressLine1","Address1_Address_Line_1",true);
		InsertInMap(ProductAddressMap,"AddressLine2","Address1_Address_Line_2",true);
		InsertInMap(ProductAddressMap,"AddressLine3","Address1_Address_Line_3",true);
		InsertInMap(ProductAddressMap,"AddressLine4","",false);
		InsertInMap(ProductAddressMap,"CityName","Address1_City",true);
		InsertInMap(ProductAddressMap,"PostalCode","Address1_Zip_Code",true);
		InsertInMap(ProductAddressMap,"Type",LOV_Codes.getAddressesType("Address1_Address_Type"),true);
		InsertInMap(ProductAddressMap,"State",LOV_Codes.getStateCode("Address1_State"),false);
		InsertInMap(ProductAddressMap,"ResidenceType",LOV_Codes.getAddressesType("Address1_Address_Type"),false);
		InsertInMap(ProductAddressMap,"Country",LOV_Codes.CountryCode("Address1_Country"),false);
		InsertInMap(ProductAddressMap,"Area","Address1_Area",true);
		InsertInMap(ProductAddressMap,"pxObjClass", "SCB-Data-Address",false);
		AddressList.add(ProductAddressMap);
		return AddressList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList setProductMISPAge(){
		System.out.println("----------------------------MISPage-----------------------------------------");
		ArrayList ProductMISPageList =new ArrayList();
		LinkedHashMap ProductMISPagetListMap =new LinkedHashMap();
		InsertInMap(ProductMISPagetListMap,"MISCode","MIS_Code",true);
		InsertInMap(ProductMISPagetListMap,"MISValue","MIS_Value",true);
		InsertInMap(ProductMISPagetListMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Product",false);
		ProductMISPageList.add(ProductMISPagetListMap);
		return ProductMISPageList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList setFeeInfoList(String CampaignCode,String ProductCode){
		System.out.println("----------------------------FeeInfo Starts-----------------------------------------");
		ArrayList FeeInfoList =new ArrayList();
		LinkedHashMap FeeInfoMap =new LinkedHashMap();
		InsertInMap(FeeInfoMap,"CampaignCode",CampaignCode,false);
		InsertInMap(FeeInfoMap,"ProductCode",ProductCode,false);
		InsertInMap(FeeInfoMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Fee",false);
		FeeInfoList.add(FeeInfoMap);
		return FeeInfoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList setApplicantProductRelationship(){
		System.out.println("------------- Applicant Product Relationship Starts------------------------------");
		ArrayList ApplicantProductRelationshipList =new ArrayList();
		LinkedHashMap ApplicantProductRelationshipMap =new LinkedHashMap();
		InsertInMap(ApplicantProductRelationshipMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Customer",false);
		InsertInMap(ApplicantProductRelationshipMap,"RelatedPartyType","Relationship_type",true);
		InsertInMap(ApplicantProductRelationshipMap,"FullName","",false);
		ApplicantProductRelationshipList.add(ApplicantProductRelationshipMap);
		return ApplicantProductRelationshipList;
	}

	//////////////////////////////////////////////////////FDC Applications Tab///////////////////////////////////////////////////////////
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Given("^Set Applications Tab$")
	public static LinkedHashMap setApplicationsTab() throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("--------------------------- Applications Tab -------------------------------------------------------");
		DBUtils.convertDBtoMap("bdquery");
		String ProductCode=DBUtils.readColumnWithRowIDNew("ProductCategory", GetCase.scenarioID);

		ArrayList ApplicationsTabList =new ArrayList();
		LinkedHashMap ApplicationsTabMap =new LinkedHashMap();

		InsertInMap(ApplicationsTabMap,"AcquisitionCode","Acquisition_Channel",true);
		InsertInMap(ApplicationsTabMap,"CountryOfAccountOpening",LOV_Codes.CountryCode("Country_Code"),false);
		InsertInMap(ApplicationsTabMap,"ARMCode","ARM_Code",true);
		InsertInMap(ApplicationsTabMap,"Segment",LOV_Codes.SegmentCode("ARM_Code"),false);
		InsertInMap(ApplicationsTabMap,"ApplicationBranch","Application_Branch",true);
		InsertInMap(ApplicationsTabMap,"BranchCode","Application_Branch",true);
		InsertInMap(ApplicationsTabMap,"BranchName","Application_Branch_Description",true);
		InsertInMap(ApplicationsTabMap,"ShortName","shortname",false);
		InsertInMap(ApplicationsTabMap,"SourceID","Sorucing_ID",true);
		InsertInMap(ApplicationsTabMap,"SourcingCity","Application_Branch_Description",true);

		if(DBUtils.readColumnWithRowIDNew("ProductCategory1", GetCase.scenarioID)!=null)
		{
			InsertInMap(ApplicationsTabMap,"PrimaryProductCategory","ProductCategory",true);
			InsertInMap(ApplicationsTabMap,"SecondaryProductCategory","ProductCategory1",true);
			InsertInMap(ApplicationsTabMap,"AllProductCategory",AllProductCategory("ProductCategory","ProductCategory1"),false);
		}
		else InsertInMap(ApplicationsTabMap,"AllProductCategory","ProductCategory",true);


		DBUtils.convertDBtoMap("fdquery");

		InsertInMap(ApplicationsTabMap,"ClassificationCode","Institution_Classification_Code",true);
		InsertInMap(ApplicationsTabMap,"ClosingID","Closing_ID",true);
		InsertInMap(ApplicationsTabMap,"SalesID","Closing_ID",true);
		InsertInMap(ApplicationsTabMap,"IsOperatingInstDerived","true",false);
		InsertInMap(ApplicationsTabMap,"OperatingInst","Operating_Instruction",true);
		InsertInMap(ApplicationsTabMap,"Priority","Y",false);
		InsertInMap(ApplicationsTabMap,"pxObjClass","SCB-Data-BankUse",false);
		InsertInMap(ApplicationsTabMap,"pzIndexOwnerKey","SCB-IN-APPWORKFLOW-WORK O-35242",false);
		InsertInMap(ApplicationsTabMap,"SourceChannel","eOPS",false);
		InsertInMap(ApplicationsTabMap,"KYCEmployeeDesignation","KYC_Employee_Designation",true);
		InsertInMap(ApplicationsTabMap,"KYCVerificationBranch","KYC_Verification_Branch",true);
		InsertInMap(ApplicationsTabMap,"KYCPlaceOfDeclaration","KYC_Place_Of_Declaration",true);
		InsertInMap(ApplicationsTabMap,"CKYCID","CKYC_ID",true);
		InsertInMap(ApplicationsTabMap,"KYCDateOfDeclaration","KYC_Date_Of_Declaration",true);
		InsertInMap(ApplicationsTabMap,"KYCEmployeeCode","KYC_Employee_Code",true);
		InsertInMap(ApplicationsTabMap,"KYCEmployeeName","KYC_Employee_Name",true);
		InsertInMap(ApplicationsTabMap,"KYCVerificationDate","KYC_Verification_Date",true);


		if(ProductCode=="CA"||ProductCode=="SA"||ProductCode=="TD")
		{
			InsertInMap(ApplicationsTabMap,"CardType",LOV_Codes.Cardtype("Debit_Type"),false);
			InsertInMap(ApplicationsTabMap,"RefRelationship","Referee_Relationship",true);
			InsertInMap(ApplicationsTabMap,"MasterNumber","Master_Number",true);
			InsertInMap(ApplicationsTabMap,"HRDate","HR_Date",true);
			InsertInMap(ApplicationsTabMap,"InvesmntAccntReq","Investment_Account_Request",true);
			InsertInMap(ApplicationsTabMap,"ServiceIndicator",LOV_Codes.Serviceindicator("Service_Indicator_Code"),false);
			InsertInMap(ApplicationsTabMap,"DebitCardRequired","Debit_Card_Required",true);
		}

		ApplicationsTabList.add(ApplicationsTabMap);
		return ApplicationsTabMap;
	}

	public static String AllProductCategory(String PrimaryProduct,String SecondaryProduct)
	{
		String AllProductCategory=DBUtils.readColumnWithRowIDNew(PrimaryProduct, GetCase.scenarioID)+","+DBUtils.readColumnWithRowIDNew(SecondaryProduct, GetCase.scenarioID);
		return AllProductCategory;
	}
	public static String ShortName(String title,String firstName,String middleName,String lastName)
	{
		String shortname="";

		String surname=DBUtils.readColumnWithRowIDNew(title, GetCase.scenarioID);
		String fullname=FullName(firstName,middleName,lastName);
		shortname= surname +" "+ fullname;

		return shortname;
	}

	public static String ETBFlag()
	{
		String Flag=""+DBUtils.readColumnWithRowIDNew("ETBAccountNumber", GetCase.scenarioID);
		if(!Flag.contains("null") || Flag.length()>1){return "Y";}else{return "N";}
	}


}
