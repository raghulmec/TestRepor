package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.DedupRequestGen;
import com.scb.rtob.module.test.framework.glue.GetCase;

public class RMSupervisorSetValue {
	
public static Logger logger = Logger.getLogger(RMSupervisorSetValue.class);
	
	private static JSONObject json = DedupRequestGen.jsonReq;
	
	static String FullName = null;

	public static void main(String[] args) {
		

	}
	
	public static void setContent(){
		
		JsonPath.parse(json).set("$.content.OfferAction",DBUtils.readColumnWithRowID("OfferAction", GetCase.scenarioID));
		
	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	

}
