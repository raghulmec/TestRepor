package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.Mapper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class GetCase {
	
	public static Logger logger = Logger.getLogger(GetCase.class);
	
	public static String envName = System.getProperty("env");
	
	public static HashMap<String, String> envmap= new HashMap<String, String>();
	
	public static String scenarioID = null;
	public static String currentWB=null;
	public static boolean isCoApp = false;
	public static boolean isMultipleProduct = false;
	public static Scenario scenarioCurrent = null;
	public static String afterPromoteWB;
	
	public static ArrayList<String> ListworkBasket = new ArrayList<String>();
	public static List<LinkedHashMap<String, String>> BatchDetailsList=new ArrayList<LinkedHashMap<String, String>>();
	@SuppressWarnings("rawtypes")
	public static LinkedHashMap individualRunDetails= new LinkedHashMap();
	public static LinkedHashMap<String,JSONObject> individualWBResponse = new LinkedHashMap<String, JSONObject>();
	@SuppressWarnings("rawtypes")
	public static List appAppID = new ArrayList();

	@SuppressWarnings("rawtypes")
	public static LinkedHashMap eachWBRequest= new LinkedHashMap();
	
	
		public static Response response;
		public static JSONObject responseJSON;
		
		/***************Load the properties file***********************/
		
		public static void loadProps(){
			
			logger.info("Loading properties...");
			URL resource = BasicRequestGen.class.getClassLoader().getResource("config" + File.separator + envName + "Config.properties");
			File file = null;
			FileInputStream fis = null;
			try {
				file = new File(resource.toURI());
				fis = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Properties ENVCONFIG = new Properties();
			try {
				ENVCONFIG.load(fis);
			} catch (IOException e) {

				e.printStackTrace();
			}
			
			for (String key : ENVCONFIG.stringPropertyNames()) {
				String value = ENVCONFIG.getProperty(key);
				envmap.put(key, value);
			}
			
		}
		
		@Before("@load")
		public void before(Scenario scenario) throws Exception {
		
		 GetCase.loadProps();
		 logger.info("env"+GetCase.envmap);
		 Mapper.setMapper();
		}
		
		@Before("@PreApiPack")
		public void beforeAPI(Scenario scenario) throws Exception {
		
		 scenarioCurrent=scenario;
		 String scen[]=scenario.getName().split("_");
		 scenarioID = scen[1];
		 System.out.println("scenarioID : "+scenarioID);
		}
		
	
		public static void main(String[] args) throws Throwable{
			
			loadProps();
			
			logger.info(envmap);
			
			callGetCaseApi();
		}
		
		@SuppressWarnings("unused")
		@Given("^Call the GetCase api and validate the workbasket$")
		public static void callGetCaseApi() throws Throwable {
			
			RestAssured.baseURI = GetCase.envmap.get("URI");
			
			RestAssured.useRelaxedHTTPSValidation();
			
			RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
			
			
			httpRequest.header("ApplicationRefNo","IN20180103100072");
			httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_Basic"));
			
			//httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
			//httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_CDDReviewer"));
			
			response = httpRequest.request(Method.GET,"/GetCase");
			
			JsonPath jsonPath = new JsonPath(response.getBody().asString());
					
			logger.info(response.headers());
			logger.info(response.getStatusCode());
			
			logger.info("Status Code ok : "+AuthenticateRTOB.validateStatusCode(response.getStatusCode()));
			
			Object obj=JSONValue.parse(response.getBody().asString());
			
			responseJSON=(JSONObject)obj;
			
			logger.info(responseJSON);		
		}
		

		
		/**************************************************************************************************
		 * @author 1575731
		 * MehtodName:callPromoteCaseApi
		 * 
		 * property: MehtodName:callPromoteCaseApi is a common method for Http-Method PUT case
		 * 
		 * It accepts 5 parameters (String ApplicationID,String CurrentWorkBasket,String templateScenarioID,JSONObject jsonReq, boolean scenarioIdrequired)
		 **** 1. ApplicationID
		 **** 2.String CurrentWorkBasket,
		 **** 5.boolean scenarioIdrequired - If required then provide- true,which will pass templateScenarioID as header while sending request
		 **** 3.String templateScenarioID,
		 **** 4.JSONObject jsonReq
		 *
		 *Objective: It will send the request(Mthod.PUT) to server and get the response, Response will be stored in global variables
		 * 
		 * @return void 
		 **************************************************************************************************/
		@SuppressWarnings("unchecked")
		public static void callPromoteCaseApi(String ApplicationID,String CurrentWorkBasket,String templateScenarioID,JSONObject jsonReq, boolean scenarioIdrequired) throws Throwable
		{ 
    		logger.info("---------------------------------------- Promote Starts for "+GetCase.envmap.get(CurrentWorkBasket)+"--------------------------------------");
    		
    		RestAssured.baseURI = GetCase.envmap.get("URI");
    		RestAssured.useRelaxedHTTPSValidation();
    		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));		
    		
			httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID(ApplicationID, GetCase.scenarioID));
            httpRequest.header("CurrentWorkBasket",GetCase.envmap.get(CurrentWorkBasket));     
    		if(scenarioIdrequired){httpRequest.header("ScenarioID",DBUtils.readColumnWithRowID(templateScenarioID, GetCase.scenarioID));}
    		httpRequest.body(jsonReq);
    		
    		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
    		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
    		GetCase.responseJSON=(JSONObject)obj;
            
            if(GetCase.response.getStatusCode() != 200)
            {  logger.info("---------------------------------------- STATUS CODE 400(BAD REQUEST): Application is in : "+GetCase.envmap.get(CurrentWorkBasket)+"--------------------------------------"); 
    			GetCase.eachWBRequest.put(GetCase.envmap.get(CurrentWorkBasket), jsonReq);
            }
            else
            {   
            	GetCase.eachWBRequest.put(GetCase.envmap.get(CurrentWorkBasket), jsonReq);
            	GetCase.currentWB=GetCase.responseJSON.get("CurrentWorkBasket").toString();
            	GetCase.ListworkBasket.add(GetCase.currentWB);
            	logger.info("---------------------------------------- STATUS CODE 200(SUCCESS): Application moved to  "+GetCase.currentWB+"--------------------------------------");
    		}

    		
    		GetCase.individualWBResponse.put(GetCase.envmap.get(CurrentWorkBasket)+" Response ", GetCase.responseJSON);         
            logger.info(GetCase.response.getStatusCode());
    		logger.info(GetCase.response.headers());
    		logger.info(GetCase.responseJSON);
    		logger.info("Status Code: "+ GetCase.response.getStatusCode());
    		
    		logger.info("---------------------------------------- Promote Ends for "+GetCase.envmap.get(CurrentWorkBasket)+"--------------------------------------");

		}
		
		
		
	}
