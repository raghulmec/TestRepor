package com.scb.rtob.module.test.framework.glue;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException; 
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Then;

public class BatchRun {
	
	public static Logger logger = Logger.getLogger(BasicRequestGen.class);	
	public static JSONObject jsonReq;
	public static List<String> dBscenarioList = new ArrayList<String>();
	public static List<String> wbyes = new ArrayList<String>();
	public static List<String> wbno = new ArrayList<String>();
	public static String scenarioid1;
	public static int rowCount1 = 0;
	public static int columnCount1 = 0;

	
	/**************************************************************************************************
	 * @author 1575731
	 * MethodName: batchScenarioExecution
	 ****Objective: Create Multiple Applications in a single run
	 ****Functionality: Method will execute Multiple Scenarios available from the DB starting from Doc Indexing till FDC checker
	 ****ReportFormat :-> Application Details : [App No, Scenario ID, WorkBasket, WorkBasket's Request, WorkBasket's Response]
	 * @return: void 
	 **************************************************************************************************/
	
	@SuppressWarnings("unchecked")
	@Then("^Run all Scenarios from Document Indexing$")
	public static void batchScenarioExecution() throws Throwable{

		String query = "select scenarioID from documentIndexing where scenarioid in ('refresh_flow28');";
		totalScenarioAvailabe(query);
		logger.info("------------------------------------Execution Starts ------------------------------------------------------");

        logger.info("Database Scenario Ids: "+dBscenarioList);
		
 		for(int i =0 ;i<dBscenarioList.size();i++)
 		{
 			
 			GetCase.scenarioID= dBscenarioList.get(i);
 			logger.info("The value inside for loop is " + GetCase.scenarioID);
 			
	 		try{
	 			
	    		GetCase.currentWB=GetCase.envmap.get("CurrentWorkBasket_Basic");
	    		GetCase.ListworkBasket.add(GetCase.currentWB);
//	 			
//	    		/*DocumentIndexing*/
//	    		DocumentIndexing.promoteDocumentIndexing("Y");
	 			
	 			/*BASIC DATA CAPTURE*/
	 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Basic")))
	 			{
	 				logger.info("Application moved to BASIC DATA CAPTURE");
	 				BasicRequestGen.promoteBasicData();
		 			
	 				/*BLIND DATA CAPTURE*/
		 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Blind")))
		 			{
		 				logger.info("Application moved to BLIND DATA CAPTURE");
		 				BlindRequestGen.promoteBlindData(jsonReq);
		 				
		 				/*DEDUPE*/
		 				if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Dedupe")))
		 				{
		 					logger.info("Application moved to DEDUPE");
		 					DedupRequestGen.promoteDedupAPI();
		 					
		 				}else{logger.info("Application Did'nt moved to DEDUPE, Checking FDC Maker WB");}
		 				if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_FDM")))
		 				{
		 					logger.info("Application moved to FDC Maker ");
		 					FDMRequestGen.promoteFDCMakerAPI();
		 					
		 					if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_FDCChecker")))
			 				{
			 					logger.info("Application moved to FDC Checker ");
			 					FDCRequestGen.promoteFDCCheckerAPI();
			 					
			 				}else{logger.info("Application Did'nt moved to FDC Checker ");}
		 				}else{logger.info("Application Did'nt moved to FDC Maker WB");}
		 				
		 			}else{logger.info("Application FAILURE, Did'nt moved to BLIND");}
	 			}else{logger.info("Application FAILURE, Did'nt moved to BASIC");}
	 			
	 			updateWBNameInToDB();

	 			
	 			GetCase.individualRunDetails.put("WorkBasket", GetCase.ListworkBasket);
	 			GetCase.individualRunDetails.put("WorkBasket's Request", GetCase.eachWBRequest);
	 			GetCase.individualRunDetails.put("WorkBasket's Responses", GetCase.individualWBResponse);
	 			GetCase.scenarioCurrent.write("Application Details : "+GetCase.individualRunDetails);
	 			
	 			GetCase.ListworkBasket.clear();
	 			GetCase.eachWBRequest.clear();
	 			GetCase.individualWBResponse.clear();
	 			GetCase.individualRunDetails.clear();			
	 		}catch(Exception e){
	 			
	 			e.printStackTrace();
	 			logger.info(e);
	 			
	 		}
	 		}
 		
 		logger.info("All App IDs: "+GetCase.appAppID);
 		GetCase.scenarioCurrent.write("Application ID's : "+GetCase.appAppID);
 		
           
 		logger.info("------------------------------------Execution Ends ------------------------------------------------------");
		
	}
	
	/**************************************************************************************************
	 * @author 1575731
	 **** MethodName: totalScenarioAvailabe
	 **** Functionality: Takes all the scenarios from DB and storing inside list<String> ...eg [BDC-01,BDC-02,....] stored in global variable
	 * @return: void 
	 **************************************************************************************************/
	
	public static void totalScenarioAvailabe(String query) throws Throwable
	{
	
	logger.info("SQL Query is :"+query);
	ResultSet rs= DBUtils.connectDBAndSendQuery(query);
		
	while (rs.next()){
			rowCount1++;
		scenarioid1 = rs.getString(1);	
        logger.info("Scenarioid is " + scenarioid1);
        dBscenarioList.add(scenarioid1);
        
        }
	}

	/**************************************************************************************************
	 * @author RAM
	 **** MethodName: updateWBNameInToDB & updateAppId
	 * @return: void 
	 **************************************************************************************************/
	
	  public static void  updateWBNameInToDB() throws ClassNotFoundException, SQLException, IOException
	  {
              
           String WBName = GetCase.responseJSON.get("CurrentWorkBasket").toString();
           System.out.println("Current WB Name is : "+ WBName);
           
           updateAppId("UpdateCurrentWBDI",WBName,GetCase.scenarioID);
           updateAppId("UpdateCurrentWBBDC",WBName,GetCase.scenarioID);
           updateAppId("UpdateCurrentWBFDC",WBName,GetCase.scenarioID);
              
      }
              
	  public static void updateAppId(String table, String WBName,String scenario_Id) throws ClassNotFoundException, SQLException, IOException{
	  
	  String query = GetCase.envmap.get(table);
	  query = query.replace("WorkBasket", WBName);
	  query = query.replace("scenario_Id", scenario_Id);
	  System.out.println("Updated Query: "+query);
	  DBUtils.updateQuery(query);
       }
              
              
  	@SuppressWarnings("unchecked")
	@Then("^Run all Scenarios from Document Indexing till FDCMaker$")
	public static void batchScenarioExecutiontillFDCMaker() throws Throwable{
		
		String envCond = System.getProperty("condition");
		String envScenarioId = System.getProperty("scenarioId");
		String scenarioQuery = GetCase.envmap.get("scenarioQuery");
		String query="";
		
		if(envCond.equalsIgnoreCase("like")){query = scenarioQuery+" like '"+envScenarioId+"' ;";}
		else if(envCond.equalsIgnoreCase("in")){query = scenarioQuery+" in ("+envScenarioId+") ;";}
		else if(envCond.equalsIgnoreCase("=")){query = scenarioQuery+" = '"+envScenarioId+"' ;";}
		
		logger.info("Query is :"+query);
		//"select scenarioid from basicdatacapture where scenarioid in ('E2E-API-PEG-USER-CC');";
		
		totalScenarioAvailabe(query);
		logger.info("------------------------------------Execution Starts ------------------------------------------------------");

        logger.info("Database Scenario Ids: "+dBscenarioList);
		
 		for(int i =0 ;i<dBscenarioList.size();i++)
 		{
 			
 			GetCase.scenarioID= dBscenarioList.get(i);
 			logger.info("The value inside for loop is " + GetCase.scenarioID);
 			
	 		try{
	 			
	    		GetCase.currentWB=GetCase.envmap.get("CurrentWorkBasket_DI");
	    		GetCase.ListworkBasket.add(GetCase.currentWB);
	 			
	    		/*DocumentIndexing*/
	    		DocumentIndexing.promoteDocumentIndexing("Y");
	 			
	 			/*BASIC DATA CAPTURE*/
	 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Basic")))
	 			{
	 				logger.info("Application moved to BASIC DATA CAPTURE");
	 				BasicRequestGen.promoteBasicData();
		 			
	 				/*BLIND DATA CAPTURE*/
		 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Blind")))
		 			{
		 				logger.info("Application moved to BLIND DATA CAPTURE");
		 				BlindRequestGen.promoteBlindData(jsonReq);
		 				
		 			}else{logger.info("Application FAILURE, Did'nt moved to BLIND");}
	 			}else{logger.info("Application FAILURE, Did'nt moved to BASIC");}
	 			
	 			updateWBNameInToDB();
	 			
	 			GetCase.individualRunDetails.put("WorkBasket", GetCase.ListworkBasket);
	 			GetCase.individualRunDetails.put("WorkBasket's Request", GetCase.eachWBRequest);
	 			GetCase.individualRunDetails.put("WorkBasket's Responses", GetCase.individualWBResponse);
	 			GetCase.scenarioCurrent.write("Application Details : "+GetCase.individualRunDetails);
	 			
	 			GetCase.ListworkBasket.clear();
	 			GetCase.eachWBRequest.clear();
	 			GetCase.individualWBResponse.clear();
	 			GetCase.individualRunDetails.clear();			
	 		}catch(Exception e){
	 			
	 			e.printStackTrace();
	 			logger.info(e);
	 			
	 		}
	 		}
 		
 		logger.info("All App IDs: "+GetCase.appAppID);
 		GetCase.scenarioCurrent.write("Application ID's : "+GetCase.appAppID);
 		
           
 		logger.info("------------------------------------Execution Ends ------------------------------------------------------");
        		
        	}
  	
  	
  	@SuppressWarnings("unchecked")
	@Then("^Run all Scenarios from Document Indexing till FDCChecker$")
	public static void batchScenarioExecutiontillFDCChecker() throws Throwable{
		
		String envCond = System.getProperty("condition");
		String envScenarioId = System.getProperty("scenarioId");
		String scenarioQuery = GetCase.envmap.get("scenarioQuery");
		String query="";
		
		if(envCond.equalsIgnoreCase("like")){query = scenarioQuery+" like '"+envScenarioId+"' ;";}
		else if(envCond.equalsIgnoreCase("in")){query = scenarioQuery+" in ("+envScenarioId+") ;";}
		else if(envCond.equalsIgnoreCase("=")){query = scenarioQuery+" = '"+envScenarioId+"' ;";}
		
		logger.info("Query is :"+query);
		//"select scenarioid from basicdatacapture where scenarioid in ('E2E-API-PEG-USER-CC');";
		
		totalScenarioAvailabe(query);
		logger.info("------------------------------------Execution Starts ------------------------------------------------------");

        logger.info("Database Scenario Ids: "+dBscenarioList);
		
 		for(int i =0 ;i<dBscenarioList.size();i++)
 		{
 			
 			GetCase.scenarioID= dBscenarioList.get(i);
 			logger.info("The value inside for loop is " + GetCase.scenarioID);
 			
	 		try{
	 			
	    		GetCase.currentWB=GetCase.envmap.get("CurrentWorkBasket_DI");
	    		GetCase.ListworkBasket.add(GetCase.currentWB);
	 			
	    		/*DocumentIndexing*/
	    		DocumentIndexing.promoteDocumentIndexing("Y");
	 			
	 			/*BASIC DATA CAPTURE*/
	 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Basic")))
	 			{
	 				logger.info("Application moved to BASIC DATA CAPTURE");
	 				BasicRequestGen.promoteBasicData();
		 			
	 				/*BLIND DATA CAPTURE*/
		 			if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Blind")))
		 			{
		 				logger.info("Application moved to BLIND DATA CAPTURE");
		 				BlindRequestGen.promoteBlindData(jsonReq);
		 				
		 				/*DEDUPE*/
		 				if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_Dedupe")))
		 				{
		 					logger.info("Application moved to DEDUPE");
		 					DedupRequestGen.promoteDedupAPI();
		 					
		 				}else{logger.info("Application Did'nt moved to DEDUPE, Checking FDC Maker WB");}
		 				if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_FDM")))
		 				{
		 					logger.info("Application moved to FDC Maker ");
		 					FDMRequestGen.promoteFDCMakerAPI();
		 					
		 					if(GetCase.currentWB.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_FDCChecker")))
			 				{
			 					logger.info("Application moved to FDC Checker ");
			 					FDCRequestGen.promoteFDCCheckerAPI();
			 					
			 				}else{logger.info("Application Did'nt moved to FDC Checker ");}
		 				}else{logger.info("Application Did'nt moved to FDC Maker WB");}
		 				
		 			}else{logger.info("Application FAILURE, Did'nt moved to BLIND");}
	 			}else{logger.info("Application FAILURE, Did'nt moved to BASIC");}
	 			
	 			updateWBNameInToDB();
	 			
	 			GetCase.individualRunDetails.put("WorkBasket", GetCase.ListworkBasket);
	 			GetCase.individualRunDetails.put("WorkBasket's Request", GetCase.eachWBRequest);
	 			GetCase.individualRunDetails.put("WorkBasket's Responses", GetCase.individualWBResponse);
	 			GetCase.scenarioCurrent.write("Application Details : "+GetCase.individualRunDetails);
	 			
	 			GetCase.ListworkBasket.clear();
	 			GetCase.eachWBRequest.clear();
	 			GetCase.individualWBResponse.clear();
	 			GetCase.individualRunDetails.clear();			
	 		}catch(Exception e){
	 			
	 			e.printStackTrace();
	 			logger.info(e);
	 			
	 		}
	 		}
 		
 		logger.info("All App IDs: "+GetCase.appAppID);
 		GetCase.scenarioCurrent.write("Application ID's : "+GetCase.appAppID);
 		
           
 		logger.info("------------------------------------Execution Ends ------------------------------------------------------");
        		
        	}

	
}