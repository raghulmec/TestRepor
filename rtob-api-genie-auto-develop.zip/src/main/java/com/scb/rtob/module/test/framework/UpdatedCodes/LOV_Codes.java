package com.scb.rtob.module.test.framework.UpdatedCodes;

import com.scb.rtob.module.test.framework.glue.GetCase;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.apache.log4j.Logger;

public class LOV_Codes
{
	public static Logger logger = Logger.getLogger(GlobalClass.class);

	public static void main(String [] args) throws ParseException
	{
		changeGivenDateFormat("2018-09-09");
	}


	public static String getSysDateTime()
	{
		String DateTime="";

		DateFormat df = new SimpleDateFormat("YYYY-MM-dd");
		Date dateobj = new Date();
		String Date=df.format(dateobj);

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS");
		format.setTimeZone(TimeZone.getTimeZone("GMT"));

		DateTime=Date+"T"+format.format(new Date())+"Z";
		logger.info(DateTime);
		return DateTime;
	}

	public static String changeGivenDateFormat(String Date) throws ParseException
	{
		String newDate="";
		if(Date.contains("-"))
		{
			SimpleDateFormat dt = new SimpleDateFormat("yyyy-mm-dd");
			Date date = dt.parse(Date);
			SimpleDateFormat dt1 = new SimpleDateFormat("yyyymmdd");

			newDate=dt1.format(date);
			System.out.println(newDate);
		}
		else{newDate=Date;}

		return newDate;
	}

	public static String getSysDate(String format)
	{
		DateFormat df = new SimpleDateFormat(format);
		Date dateobj = new Date();
		String Date=df.format(dateobj);
		return Date;
	}

	public static String appCreationDateFormat()
	{
		String DateTime="";

		DateFormat df = new SimpleDateFormat("YYYYMMdd");
		Date dateobj = new Date();
		String Date=df.format(dateobj);

		SimpleDateFormat format = new SimpleDateFormat("HHmmss.SSS");
		format.setTimeZone(TimeZone.getTimeZone("GMT"));

		DateTime=Date+"T"+format.format(new Date())+"GMT";
		logger.info(DateTime);
		return DateTime;
	}


	public static String retriveDocumentNameCode(String DBDocName)

	{
		String DocName=""+DBUtils.readColumnWithRowIDNew(DBDocName, GetCase.scenarioID);
		logger.info("DocName:"+DocName);

		String DocType="";

		if(DocName.equalsIgnoreCase("7/12EXTRACT")){DocType="T0001";}
		else if(DocName.equalsIgnoreCase("AADHAAR ENROLLMENT PROOF")){DocType="T0392";}
		else if(DocName.equalsIgnoreCase("AADHAAR")){DocType="T0002";}
		else if(DocName.equalsIgnoreCase("ACCOUNT OPENING FORM")){DocType="T0003";}
		else if(DocName.equalsIgnoreCase("ACKNOWLEDGED LETTER")){DocType="T0004";}
		else if(DocName.equalsIgnoreCase("ACKNOWLEDGED NOTICE OF INTIMATION  ORIGINAL")){DocType="T0005";}
		else if(DocName.equalsIgnoreCase("ACKNOWLEDGMENT OF RECEIPT OF LETTER,")){DocType="T0006";}
		else if(DocName.equalsIgnoreCase("ADDITIONAL COST LETTER")){DocType="T0007";}
		else if(DocName.equalsIgnoreCase("ADDRESS CONFIRMATION THROUGH CIBIL DATA")){DocType="T0008";}
		else if(DocName.equalsIgnoreCase("ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="T0009";}
		else if(DocName.equalsIgnoreCase("ADVERSE MEDIA ASSESSMENT FORM")){DocType="T0010";}
		else if(DocName.equalsIgnoreCase("AFFIDAVIT CERTIFICATE")){DocType="T0011";}
		else if(DocName.equalsIgnoreCase("AFFIDAVIT FROM APPLICANT")){DocType="T0012";}
		else if(DocName.equalsIgnoreCase("AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT")){DocType="T0013";}
		else if(DocName.equalsIgnoreCase("AFTER COMPLETION ARCHITECTS CERTIFICATE")){DocType="T0014";}
		else if(DocName.equalsIgnoreCase("AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY")){DocType="T0015";}
		else if(DocName.equalsIgnoreCase("AGREEMENT LODGED FOR REGN")){DocType="T0016";}
		else if(DocName.equalsIgnoreCase("ALLOTMENT LETTER")){DocType="T0017";}
		else if(DocName.equalsIgnoreCase("AMENITIES AGREEMENT")){DocType="T0018";}
		else if(DocName.equalsIgnoreCase("ANNEXURE - 18 (3IN1 PRODUCT)")){DocType="T0019";}
		else if(DocName.equalsIgnoreCase("ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)")){DocType="T0020";}
		else if(DocName.equalsIgnoreCase("ANNEXURE X - SIGNATURE DIFFER")){DocType="T0021";}
		else if(DocName.equalsIgnoreCase("ANNEXURE Z")){DocType="T0022";}
		else if(DocName.equalsIgnoreCase("ANNUAL BONUS LETTER")){DocType="T0023";}
		else if(DocName.equalsIgnoreCase("APPLICATION FOR NAME TRANSFER")){DocType="T0024";}
		else if(DocName.equalsIgnoreCase("APPOINTMENT LETTER")){DocType="T0025";}
		else if(DocName.equalsIgnoreCase("APPROVED LAYOUT PLAN")){DocType="T0026";}
		else if(DocName.equalsIgnoreCase("APPROVED SANCTION PLANS")){DocType="T0027";}
		else if(DocName.equalsIgnoreCase("APPROVED TCP LAYOUT")){DocType="T0028";}
		else if(DocName.equalsIgnoreCase("ARCHITECTS ESTIMATE")){DocType="T0029";}
		else if(DocName.equalsIgnoreCase("AUTHORISATION LETTER FROM BORROWER ADDRESSED T")){DocType="T0030";}
		else if(DocName.equalsIgnoreCase("AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA")){DocType="T0031";}
		else if(DocName.equalsIgnoreCase("AUTO INSURANCE")){DocType="T0032";}
		else if(DocName.equalsIgnoreCase("BACK DEED")){DocType="T0033";}
		else if(DocName.equalsIgnoreCase("BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR")){DocType="T0034";}
		else if(DocName.equalsIgnoreCase("BANK LH AUM")){DocType="T0035";}
		else if(DocName.equalsIgnoreCase("BANK STATEMENT  ( SALARIED /SELF EMPLOYED)")){DocType="T0036";}
		else if(DocName.equalsIgnoreCase("BIRTH CERTIFICATE")){DocType="T0037";}
		else if(DocName.equalsIgnoreCase("BLACKLIST CHECK")){DocType="T0038";}
		else if(DocName.equalsIgnoreCase("BOARD RESOLUTION")){DocType="T0039";}
		else if(DocName.equalsIgnoreCase("BUILDER DECLARATION")){DocType="T0040";}
		else if(DocName.equalsIgnoreCase("BUSINESS LETTERHEAD")){DocType="T0041";}
		else if(DocName.equalsIgnoreCase("BYE LAWS OF SOCIETY")){DocType="T0042";}
		else if(DocName.equalsIgnoreCase("CA CERTIFICATE FOR DISBURSAL")){DocType="T0043";}
		else if(DocName.equalsIgnoreCase("CANADIAN TAX IDENTIFICATION")){DocType="T0044";}
		else if(DocName.equalsIgnoreCase("CASH COVERED LETTER")){DocType="T0045";}
		else if(DocName.equalsIgnoreCase("CC WORKSHEET")){DocType="T0046";}
		else if(DocName.equalsIgnoreCase("CENTRAL POPULATION REGISTER (SMART CARD)")){DocType="T0047";}
		else if(DocName.equalsIgnoreCase("CERTI (BY TEHSIL OFFICE ) OF INTEKHAB KHATUNI")){DocType="T0048";}
		else if(DocName.equalsIgnoreCase("CERTIFICATE")){DocType="T0049";}
		else if(DocName.equalsIgnoreCase("CERTIFICATE OF LOSS OF US NATIONALITY")){DocType="T0050";}
		else if(DocName.equalsIgnoreCase("CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL")){DocType="T0051";}
		else if(DocName.equalsIgnoreCase("CHAIN DOCUMENTS OF THE PROPERTY.")){DocType="T0052";}
		else if(DocName.equalsIgnoreCase("CHAIN OF TITLE DOCUMENTS")){DocType="T0053";}
		else if(DocName.equalsIgnoreCase("CHALLANS -  RECEIPTS OF PAYMENTS MADE")){DocType="T0054";}
		else if(DocName.equalsIgnoreCase("CKYC FORM")){DocType="T0055";}
		else if(DocName.equalsIgnoreCase("CLIENT AUTHORIZATION")){DocType="T0056";}
		else if(DocName.equalsIgnoreCase("CLIENT DECLARATION")){DocType="T0057";}
		else if(DocName.equalsIgnoreCase("CLOSE RELATIVE DECLARATION")){DocType="T0058";}
		else if(DocName.equalsIgnoreCase("CLOSURE INSTRUCTION")){DocType="T0059";}
		else if(DocName.equalsIgnoreCase("COMMENCEMENT CERTIFICATE")){DocType="T0060";}
		else if(DocName.equalsIgnoreCase("CONFIRMATION LETTER FROM PURCHASER")){DocType="T0061";}
		else if(DocName.equalsIgnoreCase("CONSTRUCTION AGREEMENT")){DocType="T0062";}
		else if(DocName.equalsIgnoreCase("CONSTRUCTION PERMISSION")){DocType="T0063";}
		else if(DocName.equalsIgnoreCase("CONSTRUCTION SCHEDULE")){DocType="T0064";}
		else if(DocName.equalsIgnoreCase("CONTINOUS DISCHARGE CERTIFICATE")){DocType="T0065";}
		else if(DocName.equalsIgnoreCase("CONVERSION CERTIFICATE")){DocType="T0066";}
		else if(DocName.equalsIgnoreCase("CONVEYANCE DEED")){DocType="T0067";}
		else if(DocName.equalsIgnoreCase("CORROBORATION OF SOW")){DocType="T0068";}
		else if(DocName.equalsIgnoreCase("CREDIT CARD /DEBIT CARD STATEMENT")){DocType="T0069";}
		else if(DocName.equalsIgnoreCase("CROSS COLLATERAL")){DocType="T0070";}
		else if(DocName.equalsIgnoreCase("CROSS DEFAULT AGREEMENT")){DocType="T0071";}
		else if(DocName.equalsIgnoreCase("CRS DOCUMENT")){DocType="T0072";}
		else if(DocName.equalsIgnoreCase("CRS VALIDATION CHECKLIST")){DocType="T0073";}
		else if(DocName.contains("CRS/ FATCA AOF")){DocType="T0074";}
		else if(DocName.equalsIgnoreCase("CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE")){DocType="T0075";}
		else if(DocName.equalsIgnoreCase("CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID")){DocType="T0076";}
		else if(DocName.equalsIgnoreCase("CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA")){DocType="T0077";}
		else if(DocName.equalsIgnoreCase("CUSTOMER SERVICE LETTER.")){DocType="T0078";}
		else if(DocName.equalsIgnoreCase("DDA MORTGAGE -ACK")){DocType="T0079";}
		else if(DocName.equalsIgnoreCase("DEATH CERTIFICATES")){DocType="T0080";}
		else if(DocName.equalsIgnoreCase("DECLARATION")){DocType="T0081";}
		else if(DocName.equalsIgnoreCase("DECLARATION FROM OVERSEAS RM")){DocType="T0082";}
		else if(DocName.equalsIgnoreCase("DECLARATION FROM PURCHASER")){DocType="T0083";}
		else if(DocName.equalsIgnoreCase("DEED OF APARTMENT")){DocType="T0084";}
		else if(DocName.equalsIgnoreCase("DEED OF ASSIGNMENT")){DocType="T0085";}
		else if(DocName.equalsIgnoreCase("DEMAND LETTER FOR CURR DISB")){DocType="T0086";}
		else if(DocName.equalsIgnoreCase("DEMAND LETTER FROM DDA")){DocType="T0087";}
		else if(DocName.equalsIgnoreCase("DEPONENT ID PROOF")){DocType="T0088";}
		else if(DocName.equalsIgnoreCase("DEVELOPMENT AGREEMENT")){DocType="T0089";}
		else if(DocName.equalsIgnoreCase("DIPLOMAT DECLARATION")){DocType="T0090";}
		else if(DocName.equalsIgnoreCase("DISBURSAL SCHEDULE")){DocType="T0091";}
		else if(DocName.equalsIgnoreCase("DIVERSION RENT RECEIPT")){DocType="T0092";}
		else if(DocName.equalsIgnoreCase("DIVORCE CERTIFICATE/COURT ORDER")){DocType="T0093";}
		else if(DocName.equalsIgnoreCase("DOB MISMATCH DECLARATION")){DocType="T0094";}
		else if(DocName.equalsIgnoreCase("DOC ENSURING OWNERSHIP")){DocType="T0095";}
		else if(DocName.equalsIgnoreCase("DOCUMENTS OF THE BUILDER")){DocType="T0096";}
		else if(DocName.equalsIgnoreCase("DRCS APPROVAL")){DocType="T0097";}
		else if(DocName.equalsIgnoreCase("DRIVING LIC NO")){DocType="T0098";}
		else if(DocName.equalsIgnoreCase("EARLIER DOCS OF THE BUILDER")){DocType="T0099";}
		else if(DocName.equalsIgnoreCase("EARLIER DOCS OF THE SOCIETY")){DocType="T0100";}
		else if(DocName.equalsIgnoreCase("ECIB/DATA CHECK")){DocType="T0101";}
		else if(DocName.equalsIgnoreCase("ELECTRICITY BILL")){DocType="T0102";}
		else if(DocName.equalsIgnoreCase("ELIGIBILITY CALCULATION PRINTOUT")){DocType="T0103";}
		else if(DocName.equalsIgnoreCase("EMBASSY / UNO LETTERS")){DocType="T0104";}
		else if(DocName.equalsIgnoreCase("EMIRATES ID")){DocType="T0105";}
		else if(DocName.equalsIgnoreCase("EMPLOYER /HR CERTIFICATE OF ADDRESS")){DocType="T0106";}
		else if(DocName.equalsIgnoreCase("EMPLOYMENT CONTRACT LETTER")){DocType="T0107";}
		else if(DocName.equalsIgnoreCase("EMPLOYMENT PROOF")){DocType="T0108";}
		else if(DocName.equalsIgnoreCase("ENCUMBRANCE CERTIFICATE")){DocType="T0109";}
		else if(DocName.equalsIgnoreCase("EXPAT DECLARATION")){DocType="T0110";}
		else if(DocName.equalsIgnoreCase("FINANCIAL COVENANTS")){DocType="T0111";}
		else if(DocName.equalsIgnoreCase("FLAT BUYERS AGR")){DocType="T0112";}
		else if(DocName.equalsIgnoreCase("FOREIGN PASSPORT")){DocType="T0113";}
		else if(DocName.equalsIgnoreCase("FOREIGN TIN")){DocType="T0114";}
		else if(DocName.equalsIgnoreCase("FORM 60")){DocType="T0115";}
		else if(DocName.equalsIgnoreCase("FORM 8 & 13")){DocType="T0116";}
		else if(DocName.equalsIgnoreCase("FORM A + B + REGULARISED PLAN")){DocType="T0117";}
		else if(DocName.equalsIgnoreCase("FORM W8-BEN")){DocType="T0118";}
		else if(DocName.equalsIgnoreCase("FORM W9")){DocType="T0119";}
		else if(DocName.equalsIgnoreCase("FUNDING CHEQUE")){DocType="T0120";}
		else if(DocName.equalsIgnoreCase("GAS BILL")){DocType="T0121";}
		else if(DocName.equalsIgnoreCase("GAZZETTE NOTIFICATION")){DocType="T0122";}
		else if(DocName.equalsIgnoreCase("GIFT DEED")){DocType="T0123";}
		else if(DocName.equalsIgnoreCase("GPA BY THE SELLER IN FAVOR OF THE BUYER")){DocType="T0124";}
		else if(DocName.equalsIgnoreCase("GPA SPA AND WILL")){DocType="T0125";}
		else if(DocName.equalsIgnoreCase("GPOA")){DocType="T0126";}
		else if(DocName.equalsIgnoreCase("GST/VAT DOCUMENT")){DocType="T0127";}
		else if(DocName.equalsIgnoreCase("GUARDIAN DECLARATION FOR PAN NO UPDATION")){DocType="T0128";}
		else if(DocName.equalsIgnoreCase("HANDING OVER POSSESSION LETTER TO THE BORROWER")){DocType="T0129";}
		else if(DocName.equalsIgnoreCase("HEALTH INSURANCE")){DocType="T0130";}
		else if(DocName.equalsIgnoreCase("HIRE PURCHASE AGREEMENT")){DocType="T0131";}
		else if(DocName.equalsIgnoreCase("HR LETTER")){DocType="T0132";}
		else if(DocName.equalsIgnoreCase("ID CARD ISSUED BY ELECTORAL OFFICE")){DocType="T0134";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD (OTHER NATIONALITY)")){DocType="T0135";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION")){DocType="T0136";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT")){DocType="T0137";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS")){DocType="T0138";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS")){DocType="T0139";}
		else if(DocName.equalsIgnoreCase("IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS")){DocType="T0140";}
		else if(DocName.equalsIgnoreCase("IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="T0141";}
		else if(DocName.equalsIgnoreCase("IID")){DocType="T0142";}
		else if(DocName.equalsIgnoreCase("INCOME ASSESSMENT")){DocType="T0143";}
		else if(DocName.equalsIgnoreCase("INDEMNITY")){DocType="T0144";}
		else if(DocName.equalsIgnoreCase("INDEMNITY BOND")){DocType="T0145";}
		else if(DocName.equalsIgnoreCase("INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER")){DocType="T0146";}
		else if(DocName.equalsIgnoreCase("INDEMNITY SIGNED BY SELLER")){DocType="T0147";}
		else if(DocName.equalsIgnoreCase("INDENTURE OF SALE")){DocType="T0148";}
		else if(DocName.equalsIgnoreCase("INDEX 2")){DocType="T0149";}
		else if(DocName.equalsIgnoreCase("INSTRUMENT OF TRANSFER OF LAND")){DocType="T0150";}
		else if(DocName.equalsIgnoreCase("INT/DIVND LETTER")){DocType="T0151";}
		else if(DocName.equalsIgnoreCase("INTERNET BILL")){DocType="T0152";}
		else if(DocName.equalsIgnoreCase("INTIMATION TO JDA OF MORTGAGE DULY ACK")){DocType="T0153";}
		else if(DocName.equalsIgnoreCase("INTIMATION TO RIICO OF MORTGAGE")){DocType="T0154";}
		else if(DocName.equalsIgnoreCase("IRANIAN ADDENDUM")){DocType="T0155";}
		else if(DocName.equalsIgnoreCase("IRS FORM 2848")){DocType="T0156";}
		else if(DocName.equalsIgnoreCase("KHATAUNI FOR THE FASLI YEAR")){DocType="T0157";}
		else if(DocName.equalsIgnoreCase("KHATHA DOCUMENT")){DocType="T0158";}
		else if(DocName.equalsIgnoreCase("LABOUR INSURANCE")){DocType="T0159";}
		else if(DocName.equalsIgnoreCase("LAND OWNERS DEED")){DocType="T0160";}
		else if(DocName.equalsIgnoreCase("LATEST OUTSTANDING LETTER FROM FINANCIER")){DocType="T0161";}
		else if(DocName.equalsIgnoreCase("LEASE DEED")){DocType="T0162";}
		else if(DocName.equalsIgnoreCase("LEGAL DOCUMENT")){DocType="T0163";}
		else if(DocName.equalsIgnoreCase("LEGAL DOCUMENT OF EXPIRED OWNER")){DocType="T0164";}
		else if(DocName.equalsIgnoreCase("LEGAL OPINION")){DocType="T0165";}
		else if(DocName.equalsIgnoreCase("LEGAL REPORT")){DocType="T0166";}
		else if(DocName.equalsIgnoreCase("LETTER FROM BANK TO THE DEVELOPER / BUILDER")){DocType="T0167";}
		else if(DocName.equalsIgnoreCase("LETTER FROM BORROWER TO THE DEVELOPER / BLDG")){DocType="T0168";}
		else if(DocName.equalsIgnoreCase("LETTER FROM SOCIETY")){DocType="T0169";}
		else if(DocName.equalsIgnoreCase("LETTER ISSUED BY A GAZETTED OFFICER")){DocType="T0170";}
		else if(DocName.equalsIgnoreCase("LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER")){DocType="T0171";}
		else if(DocName.equalsIgnoreCase("LETTER OF OFFER")){DocType="T0172";}
		else if(DocName.equalsIgnoreCase("LETTER OF UNDERTAKING")){DocType="T0173";}
		else if(DocName.equalsIgnoreCase("LIEN MARKING LETTER")){DocType="T0174";}
		else if(DocName.equalsIgnoreCase("LIEN NOTED CERTIFICATE FROM SOCIETY")){DocType="T0175";}
		else if(DocName.equalsIgnoreCase("LIFE INSURANCE")){DocType="T0176";}
		else if(DocName.equalsIgnoreCase("LIST OF DOCUMENTS HELD WITH HFC")){DocType="T0177";}
		else if(DocName.equalsIgnoreCase("LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY")){DocType="T0178";}
		else if(DocName.equalsIgnoreCase("LOAN AGREEMENT ACROSS LOCATIONS")){DocType="T0179";}
		else if(DocName.equalsIgnoreCase("LOAN CLOSURE LETTER")){DocType="T0180";}
		else if(DocName.equalsIgnoreCase("LOCATION CERTIFICATE")){DocType="T0181";}
		else if(DocName.equalsIgnoreCase("LOCKER ACCOUNT OPENING FORM")){DocType="T0182";}
		else if(DocName.equalsIgnoreCase("LOCKER AGREEMENT")){DocType="T0183";}
		else if(DocName.equalsIgnoreCase("LOCKER RENT & FEE")){DocType="T0184";}
		else if(DocName.equalsIgnoreCase("LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION")){DocType="T0185";}
		else if(DocName.equalsIgnoreCase("MAINTENANCE BILL")){DocType="T0186";}
		else if(DocName.equalsIgnoreCase("MARGIN MONEY RECEIPTS")){DocType="T0187";}
		else if(DocName.equalsIgnoreCase("MARINER DECLARATION")){DocType="T0188";}
		else if(DocName.equalsIgnoreCase("MARK SHEET")){DocType="T0189";}
		else if(DocName.equalsIgnoreCase("MARRIAGE CERTIFICATE")){DocType="T0190";}
		else if(DocName.equalsIgnoreCase("MEMORANDUM OF DEPOSIT OF TITLE DEED  ORIGINAL")){DocType="T0191";}
		else if(DocName.equalsIgnoreCase("MEMORANDUM OF ENTRY")){DocType="T0192";}
		else if(DocName.equalsIgnoreCase("MEMORANDUM OF GENERAL PLEDGE")){DocType="T0193";}
		else if(DocName.equalsIgnoreCase("MEMORANDUM OF UNDERTAKING")){DocType="T0194";}
		else if(DocName.equalsIgnoreCase("MID")){DocType="T0195";}
		else if(DocName.equalsIgnoreCase("MOBILE BILL")){DocType="T0196";}
		else if(DocName.equalsIgnoreCase("MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT")){DocType="T0197";}
		else if(DocName.equalsIgnoreCase("MORTGAGE PERMISSION FROM RHB")){DocType="T0198";}
		else if(DocName.equalsIgnoreCase("MP PRAKOSHTHA ADHINIYAM")){DocType="T0199";}
		else if(DocName.equalsIgnoreCase("MULTIPLE PRODUCT DECLARATION")){DocType="T0200";}
		else if(DocName.equalsIgnoreCase("MUNICIPAL TAX RECEIPT")){DocType="T0201";}
		else if(DocName.equalsIgnoreCase("NA ORDER")){DocType="T0202";}
		else if(DocName.equalsIgnoreCase("NADRA")){DocType="T0203";}
		else if(DocName.equalsIgnoreCase("NAME TRANSFER FAV BORROWER")){DocType="T0204";}
		else if(DocName.equalsIgnoreCase("NATIONAL IDENTITY CARD")){DocType="T0205";}
		else if(DocName.equalsIgnoreCase("NATIONALITY PROOF")){DocType="T0206";}
		else if(DocName.equalsIgnoreCase("NEW ENGINEERING CONTRACT")){DocType="T0207";}
		else if(DocName.equalsIgnoreCase("NO DUES CERTIFICATE")){DocType="T0208";}
		else if(DocName.equalsIgnoreCase("NOC FROM BDA")){DocType="T0209";}
		else if(DocName.equalsIgnoreCase("NOC FROM BUILDER / SOCIETY")){DocType="T0210";}
		else if(DocName.equalsIgnoreCase("NOC FROM LAND ACQUISITION OFF ( KHASRA PLOT)")){DocType="T0211";}
		else if(DocName.equalsIgnoreCase("NOC TO MORTGAGE")){DocType="T0212";}
		else if(DocName.equalsIgnoreCase("NOC TO TRANSFER")){DocType="T0213";}
		else if(DocName.equalsIgnoreCase("NOMINATION FORM")){DocType="T0214";}
		else if(DocName.equalsIgnoreCase("NORKOM")){DocType="T0215";}
		else if(DocName.equalsIgnoreCase("NOTARIZED AFFIDAVIT FOR NAME CHANGE")){DocType="T0216";}
		else if(DocName.equalsIgnoreCase("NR DECLARATION")){DocType="T0217";}
		else if(DocName.equalsIgnoreCase("NREGA JOB CARD")){DocType="T0218";}
		else if(DocName.equalsIgnoreCase("NRI ANNEXURE STATEMENT")){DocType="T0219";}
		else if(DocName.equalsIgnoreCase("OCCUPATION CERTIFICATE")){DocType="T0220";}
		else if(DocName.equalsIgnoreCase("OCI CARD")){DocType="T0221";}
		else if(DocName.equalsIgnoreCase("OFFER LETTER")){DocType="T0222";}
		else if(DocName.equalsIgnoreCase("ORIGINAL COMP CERTIFICATE")){DocType="T0223";}
		else if(DocName.equalsIgnoreCase("ORIGINAL INSURANCE CERTIFICATE")){DocType="T0224";}
		else if(DocName.equalsIgnoreCase("ORIGINAL NOMINATION AGREEMENT")){DocType="T0225";}
		else if(DocName.equalsIgnoreCase("OTHER BANK'S STATEMENT")){DocType="T0226";}
		else if(DocName.contains("PAN")){DocType="T0227";}
		else if(DocName.equalsIgnoreCase("PARTITION DEED")){DocType="T0228";}
		else if(DocName.equalsIgnoreCase("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocType="T0229";}
		else if(DocName.equalsIgnoreCase("PASSING CERTIFICATE")){DocType="T0230";}
		else if(DocName.equalsIgnoreCase("PASSPORT")){DocType="T0231";}
		else if(DocName.equalsIgnoreCase("PATTA")){DocType="T0232";}
		else if(DocName.equalsIgnoreCase("PAYMENT RECEIPTS FOR LAND")){DocType="T0233";}
		else if(DocName.equalsIgnoreCase("PAYMENT SCHEDULE")){DocType="T0234";}
		else if(DocName.equalsIgnoreCase("PAYSLIP")){DocType="T0235";}
		else if(DocName.equalsIgnoreCase("PDPA")){DocType="T0236";}
		else if(DocName.equalsIgnoreCase("PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)")){DocType="T0237";}
		else if(DocName.equalsIgnoreCase("PEP")){DocType="T0238";}
		else if(DocName.equalsIgnoreCase("PEP ASSESSMENT FORM")){DocType="T0239";}
		else if(DocName.equalsIgnoreCase("PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS")){DocType="T0240";}
		else if(DocName.equalsIgnoreCase("PERMISSION FOR ADMITTING BORROWER AS MEMBER")){DocType="T0241";}
		else if(DocName.equalsIgnoreCase("PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO")){DocType="T0242";}
		else if(DocName.equalsIgnoreCase("PERMISSION FOR TRANSFER FROM SOCIETY")){DocType="T0243";}
		else if(DocName.equalsIgnoreCase("PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY")){DocType="T0244";}
		else if(DocName.equalsIgnoreCase("PIO CARD")){DocType="T0245";}
		else if(DocName.equalsIgnoreCase("PISE SEARCH")){DocType="T0246";}
		else if(DocName.equalsIgnoreCase("PLAN DOCUMENT")){DocType="T0247";}
		else if(DocName.equalsIgnoreCase("PLANNING PERMIT AND CONSTRUCTION PERMIT")){DocType="T0248";}
		else if(DocName.equalsIgnoreCase("PLOTS ALLOTTED AT CONCESSIONAL RATES")){DocType="T0249";}
		else if(DocName.equalsIgnoreCase("POA")){DocType="T0250";}
		else if(DocName.equalsIgnoreCase("POA & DEBIT AUTHORISATION")){DocType="T0251";}
		else if(DocName.equalsIgnoreCase("POA DOCS FAV SELLER / BUILDER OR DEVELOPER")){DocType="T0252";}
		else if(DocName.equalsIgnoreCase("PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA")){DocType="T0253";}
		else if(DocName.equalsIgnoreCase("POSSESSION CERTIFICATE")){DocType="T0254";}
		else if(DocName.equalsIgnoreCase("POSSESSION LETTER FROM RHB")){DocType="T0255";}
		else if(DocName.equalsIgnoreCase("POST OFFICE SAVINGS BANK ACCOUNT STATEMENT")){DocType="T0256";}
		else if(DocName.equalsIgnoreCase("PREVIOUS AGREEMENT LODGED FOR REGISTRATION")){DocType="T0257";}
		else if(DocName.equalsIgnoreCase("PREVIOUS PARTY SHARE CERTIFICATE")){DocType="T0258";}
		else if(DocName.equalsIgnoreCase("PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN")){DocType="T0259";}
		else if(DocName.equalsIgnoreCase("PROOF OD AGRICULTURAL LAND")){DocType="T0260";}
		else if(DocName.equalsIgnoreCase("PROOF OF BASIS OF OWNERSHIP")){DocType="T0261";}
		else if(DocName.equalsIgnoreCase("PROOF OF CUSTOMER EQUITY")){DocType="T0262";}
		else if(DocName.equalsIgnoreCase("PROOF OF DISCHARGE OF MORTGAGE")){DocType="T0263";}
		else if(DocName.equalsIgnoreCase("PROOF OF PROPERTY UNDER JURISDICTION")){DocType="T0264";}
		else if(DocName.equalsIgnoreCase("PROPERTY CARD")){DocType="T0265";}
		else if(DocName.equalsIgnoreCase("PROPERTY INSURANCE")){DocType="T0266";}
		else if(DocName.equalsIgnoreCase("PROPERTY TAX RECEIPT")){DocType="T0267";}
		else if(DocName.equalsIgnoreCase("RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC")){DocType="T0268";}
		else if(DocName.equalsIgnoreCase("RECOVERY INSTRUCTION FOR LOCKER RENT")){DocType="T0269";}
		else if(DocName.equalsIgnoreCase("RECTIFICATION DEED")){DocType="T0270";}
		else if(DocName.equalsIgnoreCase("REFERENCE")){DocType="T0271";}
		else if(DocName.equalsIgnoreCase("REGISTERED AGREEMENT TO SELL")){DocType="T0272";}
		else if(DocName.equalsIgnoreCase("REGISTERED MORTGAGE DEED")){DocType="T0273";}
		else if(DocName.equalsIgnoreCase("REGISTERED SALE DEED")){DocType="T0274";}
		else if(DocName.equalsIgnoreCase("REGISTERED TRANSFER DEED")){DocType="T0275";}
		else if(DocName.equalsIgnoreCase("REGISTRATION RECEIPT")){DocType="T0276";}
		else if(DocName.equalsIgnoreCase("REIMBURSEMENT FORM – AOF")){DocType="T0277";}
		else if(DocName.equalsIgnoreCase("RENT RECEIPT FOR LEASEHOLD PLOT")){DocType="T0278";}
		else if(DocName.equalsIgnoreCase("RENTAL AGREEMENT/SALE  DEED")){DocType="T0279";}
		else if(DocName.equalsIgnoreCase("REQUEST FOR FIXED DEPOSIT/LIEN")){DocType="T0280";}
		else if(DocName.equalsIgnoreCase("REQUEST FOR LOCKER")){DocType="T0281";}
		else if(DocName.equalsIgnoreCase("RESIDENCE FOREIGN CURRENCY DECLARATION")){DocType="T0282";}
		else if(DocName.equalsIgnoreCase("RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION")){DocType="T0283";}
		else if(DocName.equalsIgnoreCase("RESIDENCE PROOF")){DocType="T0284";}
		else if(DocName.equalsIgnoreCase("RESIDENCE VERIFICATION REPORT")){DocType="T0285";}
		else if(DocName.equalsIgnoreCase("RESIDENT PERMIT")){DocType="T0286";}
		else if(DocName.equalsIgnoreCase("RESIDENT VERIFICATION REPORT")){DocType="T0287";}
		else if(DocName.equalsIgnoreCase("RESOLUTION FOR A MORTGAGE PROPERTY")){DocType="T0288";}
		else if(DocName.equalsIgnoreCase("RPI ANNEXURE STATEMENT")){DocType="T0289";}
		else if(DocName.equalsIgnoreCase("SALE & PUR AGREEMENT EXEC BY BUYER")){DocType="T0290";}
		else if(DocName.equalsIgnoreCase("SALE & PUR AGREEMENT EXEC BY SELLER")){DocType="T0291";}
		else if(DocName.equalsIgnoreCase("SALE AGREEMENT")){DocType="T0292";}
		else if(DocName.equalsIgnoreCase("SALE DEED EXECUTED BY BUYER/BORROWER")){DocType="T0293";}
		else if(DocName.equalsIgnoreCase("SALE DEED EXECUTED BY SELLER")){DocType="T0294";}
		else if(DocName.equalsIgnoreCase("SANCTION LETTER")){DocType="T0295";}
		else if(DocName.equalsIgnoreCase("SANCTION PLANS")){DocType="T0296";}
		else if(DocName.equalsIgnoreCase("SANCTIONS ADVICE FORM")){DocType="T0297";}
		else if(DocName.equalsIgnoreCase("SAR")){DocType="T0298";}
		else if(DocName.equalsIgnoreCase("SCHEDULED BANK STATISTICS")){DocType="T0299";}
		else if(DocName.equalsIgnoreCase("SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT")){DocType="T0300";}
		else if(DocName.equalsIgnoreCase("SCHOOL LEAVING CERTIFCATE")){DocType="T0301";}
		else if(DocName.equalsIgnoreCase("SEARCH REPORT")){DocType="T0302";}
		else if(DocName.equalsIgnoreCase("SECONDARY - ID")){DocType="T0303";}
		else if(DocName.equalsIgnoreCase("SET-OFF LETTER")){DocType="T0304";}
		else if(DocName.equalsIgnoreCase("SHARE CERTIFICATE BUYER")){DocType="T0305";}
		else if(DocName.equalsIgnoreCase("SHARE CERTIFICATE SELLER")){DocType="T0306";}
		else if(DocName.equalsIgnoreCase("SHAREHOLDING DOC")){DocType="T0307";}
		else if(DocName.equalsIgnoreCase("SIGNATURE CARD")){DocType="T0308";}
		else if(DocName.equalsIgnoreCase("SIGNATURE PROOF")){DocType="T0309";}
		else if(DocName.equalsIgnoreCase("SOI/SOW CHECKLIST")){DocType="T0310";}
		else if(DocName.equalsIgnoreCase("SOW")){DocType="T0311";}
		else if(DocName.equalsIgnoreCase("STAFF DECLARATION")){DocType="T0312";}
		else if(DocName.equalsIgnoreCase("STAMP DUTY RECEIPT")){DocType="T0313";}
		else if(DocName.equalsIgnoreCase("STAMPED MOE")){DocType="T0314";}
		else if(DocName.equalsIgnoreCase("STATEMENT OF OTHER HOLDING")){DocType="T0315";}
		else if(DocName.equalsIgnoreCase("STATEMENT OF WORK")){DocType="T0316";}
		else if(DocName.equalsIgnoreCase("SUB-LEASE DEED")){DocType="T0317";}
		else if(DocName.equalsIgnoreCase("SUPPLEMENTAL H/S AGR")){DocType="T0318";}
		else if(DocName.equalsIgnoreCase("SUPPLEMENTARY - ID")){DocType="T0319";}
		else if(DocName.equalsIgnoreCase("SUPPLEMENTARY - RESIDENCE PROOF")){DocType="T0320";}
		else if(DocName.equalsIgnoreCase("SUPPLEMENTARY DECLARTION")){DocType="T0321";}
		else if(DocName.equalsIgnoreCase("SURRENDER DEED FROM SOCIETY")){DocType="T0322";}
		else if(DocName.equalsIgnoreCase("SURROGATE SPECIFIC PRODUCT ST/LETTER")){DocType="T0323";}
		else if(DocName.equalsIgnoreCase("TAX DEMAND LETTER OR STATEMENT")){DocType="T0324";}
		else if(DocName.equalsIgnoreCase("TAX IDENTIFICATION NUMBER")){DocType="T0325";}
		else if(DocName.equalsIgnoreCase("Tax PAID  receipts")){DocType="T0326";}
		else if(DocName.equalsIgnoreCase("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocType="T0327";}
		else if(DocName.equalsIgnoreCase("TECHNICAL CUM LEGAL UNDERTAKING")){DocType="T0328";}
		else if(DocName.equalsIgnoreCase("TELEPHONE BILL")){DocType="T0329";}
		else if(DocName.equalsIgnoreCase("TITLE DEED")){DocType="T0330";}
		else if(DocName.equalsIgnoreCase("TRANSACTION INFORMATION")){DocType="T0331";}
		else if(DocName.equalsIgnoreCase("TRANSFER CERTIFICATE")){DocType="T0332";}
		else if(DocName.equalsIgnoreCase("TRANSFER FORM FOR SHARE CERT")){DocType="T0333";}
		else if(DocName.equalsIgnoreCase("TRANSFER LETTER FAV SELLER")){DocType="T0334";}
		else if(DocName.equalsIgnoreCase("TRANSFER LETTER FROM PCNTDA")){DocType="T0335";}
		else if(DocName.equalsIgnoreCase("TRANSFER MEMORANDUM IN FAVOR OF PURCHASER")){DocType="T0336";}
		else if(DocName.equalsIgnoreCase("TRIPATRIATE AGR")){DocType="T0337";}
		else if(DocName.equalsIgnoreCase("TXN INFORMATION DOCUMENT( TID)")){DocType="T0338";}
		else if(DocName.equalsIgnoreCase("UNDERTAKING FROM SELLER TO HANDOVER DOCS")){DocType="T0339";}
		else if(DocName.equalsIgnoreCase("UTILITY BILL")){DocType="T0340";}
		else if(DocName.equalsIgnoreCase("VALUATION REPORT")){DocType="T0341";}
		else if(DocName.equalsIgnoreCase("VERNACULAR BOND")){DocType="T0342";}
		else if(DocName.equalsIgnoreCase("VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH")){DocType="T0343";}
		else if(DocName.equalsIgnoreCase("VERNACULAR DECLARATION - UNDERSTAND ENGLISH")){DocType="T0344";}
		else if(DocName.equalsIgnoreCase("VISA")){DocType="T0345";}
		else if(DocName.equalsIgnoreCase("VOTERS ID")){DocType="T0346";}
		else if(DocName.equalsIgnoreCase("W9 VALIDATION CHECKLIST")){DocType="T0347";}
		else if(DocName.equalsIgnoreCase("WATER BILL")){DocType="T0348";}
		else if(DocName.equalsIgnoreCase("WILL SIGNED BY THE SELLER")){DocType="T0349";}
		else if(DocName.equalsIgnoreCase("WORK PERMIT")){DocType="T0350";}
		else if(DocName.equalsIgnoreCase("BACK VALUE DATE APPROVAL")){DocType="T0351";}
		else if(DocName.equalsIgnoreCase("NAME SCREENING RESOLUTION EVIDENCE")){DocType="T0352";}
		else if(DocName.equalsIgnoreCase("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocType="T0353";}
		else if(DocName.equalsIgnoreCase("INTERNET SEARCH EVIDENCE")){DocType="T0354";}
		else if(DocName.equalsIgnoreCase("CDD APPROVAL EMAIL(S)")){DocType="T0355";}
		else if(DocName.equalsIgnoreCase("ITR DOCUMENT")){DocType="T0356";}
		else if(DocName.equalsIgnoreCase("PROFIT & LOSS STATEMENT")){DocType="T0357";}
		else if(DocName.equalsIgnoreCase("BALANCE SHEET")){DocType="T0358";}
		else if(DocName.equalsIgnoreCase("PROFESSIONAL DEGREE CERTIFICATE")){DocType="T0359";}
		else if(DocName.equalsIgnoreCase("MCA SITE PRINTOUT")){DocType="T0360";}
		else if(DocName.equalsIgnoreCase("LOAN REPAYMENT TRACK")){DocType="T0361";}
		else if(DocName.equalsIgnoreCase("LOAN REPAYMENT SCHEDULE")){DocType="T0362";}
		else if(DocName.equalsIgnoreCase("LOAN CLOSURE PROOF")){DocType="T0363";}
		else if(DocName.equalsIgnoreCase("WORK EXPERIENCE PROOF")){DocType="T0364";}
		else if(DocName.equalsIgnoreCase("PROOF OF BUSINESS CONTINUITY FOR 3YEARS")){DocType="T0365";}
		else if(DocName.equalsIgnoreCase("PROOF OF PROPRIETORSHIP")){DocType="T0366";}
		else if(DocName.equalsIgnoreCase("PARTNERSHIP DEED")){DocType="T0367";}
		else if(DocName.equalsIgnoreCase("SERVICE TAX REGISTRATION CERTIFICATE")){DocType="T0368";}
		else if(DocName.equalsIgnoreCase("SHOP AND ESTABLISHMENT CERTIFICATE")){DocType="T0369";}
		else if(DocName.equalsIgnoreCase("TRADE LICENSE")){DocType="T0370";}
		else if(DocName.equalsIgnoreCase("SALES TAX REGISTRATION CERTIFICATE")){DocType="T0371";}
		else if(DocName.equalsIgnoreCase("LOGIN CHECKLIST")){DocType="T0372";}
		else if(DocName.equalsIgnoreCase("FORM 16")){DocType="T0373";}
		else if(DocName.equalsIgnoreCase("CA REPORT ON INCOME DOCUMENT")){DocType="T0374";}
		else if(DocName.equalsIgnoreCase("INCREMENT LETTER")){DocType="T0375";}
		else if(DocName.equalsIgnoreCase("DIARY NOTE")){DocType="T0376";}
		else if(DocName.equalsIgnoreCase("PAN VERIFICATION COPY")){DocType="T0377";}
		else if(DocName.equalsIgnoreCase("CUSTOMER CLARIFICATION E-MAIL")){DocType="T0378";}
		else if(DocName.equalsIgnoreCase("INTERNAL CLARIFICATION E-MAIL")){DocType="T0379";}
		else if(DocName.equalsIgnoreCase("CUSTOMER PHOTO")){DocType="T0380";}
		else if(DocName.equalsIgnoreCase("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocType="T0381";}
		else if(DocName.equalsIgnoreCase("2IN1 LINKING FORM")){DocType="T0382";}
		else if(DocName.equalsIgnoreCase("CREDIT CARD COPY")){DocType="T0383";}
		else if(DocName.equalsIgnoreCase("PARTNER’S AUTHORITY LETTER")){DocType="T0384";}
		else if(DocName.equalsIgnoreCase("RATION CARD")){DocType="T0385";}
		else if(DocName.equalsIgnoreCase("RETIREMENT PROOF")){DocType="T0386";}
		else if(DocName.equalsIgnoreCase("UNCLEAR DOCUMENT")){DocType="T0387";}
		else if(DocName.equalsIgnoreCase("LETTER ISSUED BY NATIONAL POPULATION REGISTER")){DocType="T0388";}
		else if(DocName.equalsIgnoreCase("CHEQUE LEAF")){DocType="T0389";}
		else if(DocName.equalsIgnoreCase("FIR COPY")){DocType="T0390";}
		else if(DocName.equalsIgnoreCase("CENTRAL BANK AUTHORIZATION LETTER")){DocType="T0391";}
		else if(DocName.equalsIgnoreCase("DOCUMENT FRAUD VERIFICATION REPORT")){DocType="T0393";}
		else if(DocName.equalsIgnoreCase("1 WAY SMS VERIFICATION REPORT")){DocType="T0394";}
		else if(DocName.equalsIgnoreCase("2 WAY SMS VERIFICATION REPORT")){DocType="T0395";}
		else if(DocName.equalsIgnoreCase("PERSONAL DISCUSSION VERIFICATION REPORT")){DocType="T0396";}
		else if(DocName.equalsIgnoreCase("OFFICE VERIFICATION REPORT")){DocType="T0397";}
		else if(DocName.equalsIgnoreCase("EMAIL APPROVAL - LEVEL 1")){DocType="T0398";}
		else if(DocName.equalsIgnoreCase("POA FORM")){DocType="T0399";}
		else if(DocName.equalsIgnoreCase("SWEEP TRANSFER FORM")){DocType="T0400";}
		else if(DocName.equalsIgnoreCase("SIGNATURE ( AOF)")){DocType="T0401";}
		else if(DocName.equalsIgnoreCase("CANCELLED CHEQUE")){DocType="T0402";}
		else if(DocName.equalsIgnoreCase("INVESTMENT SERVICES ENROLLMENT FORM")){DocType="T0403";}
		else if(DocName.equalsIgnoreCase("ID")){DocType="T0133";}
		else if(DocName.equalsIgnoreCase("null")){logger.info("Please provide Value in DB for DocName");}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ("+DocName+") DocName does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return DocType;

	}


	public static String retriveDocumentCategoryCode(String DBDocumentCategory)
	{
		String DocCatCode="";
		String DocumentCategory=""+DBUtils.readColumnWithRowIDNew(DBDocumentCategory, GetCase.scenarioID);
		if(DocumentCategory.contains("CLIENT ID")){DocCatCode="R0001";}
		else if(DocumentCategory.contains("CLIENT TAX DOCUMENTS")){DocCatCode="R0002";}
		else if(DocumentCategory.contains("FATCA DOCUMENTS")){DocCatCode="R0003";}
		else if(DocumentCategory.contains("CLIENT VERIFICATION DOCUMENTS")){DocCatCode="R0004";}
		else if(DocumentCategory.contains("CLIENT CREDIT ASSESSMENT DOCUMENTS")){DocCatCode="R0005";}
		else if(DocumentCategory.contains("PRODUCT")){DocCatCode="R0006";}
		else if(DocumentCategory.contains("CLIENT SERVICING DOCUMENTS")){DocCatCode="R0007";}
		else if(DocumentCategory.contains("COLLATERAL DOCUMENTS")){DocCatCode="R0008";}
		else if(DocumentCategory.contains("INTERNAL DOCUMENTS")){DocCatCode="R0009";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: DocumentCategory ("+DocumentCategory+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");DocCatCode=DocumentCategory;}

		logger.info("DocumentCategory Code for "+ DocumentCategory+" is :"+DocCatCode);
		return DocCatCode;
	}

	public static String ContactTypeClassification(String DBcontactTypeCode,String DBcontactTypeDesc)
	{
		String contactTypeCode=DBUtils.readColumnWithRowIDNew(DBcontactTypeCode, GetCase.scenarioID);
		String contactTypeDesc=DBUtils.readColumnWithRowIDNew(DBcontactTypeDesc, GetCase.scenarioID);
		String ContactTypeClassificationCode="";

		if(contactTypeCode.contains("EM") || contactTypeDesc.contains("EMAIL")){ ContactTypeClassificationCode="E";}
		else if(contactTypeCode.contains("OF") || contactTypeDesc.contains("FAX")){ ContactTypeClassificationCode="F";}
		else if(contactTypeCode.contains("SW") || contactTypeDesc.contains("SWIFT")){ ContactTypeClassificationCode="S";}
		else if(contactTypeCode.contains("WAD") || contactTypeDesc.contains("WEB ADDRESS")){ ContactTypeClassificationCode="W";}
		else if(contactTypeCode.contains("PG") || contactTypeDesc.contains("PAGER")){ ContactTypeClassificationCode="P";}
		else if(contactTypeCode.contains("LT") || contactTypeDesc.contains("TELEPHONE")){ ContactTypeClassificationCode="T";}
		else if(contactTypeCode.contains("OT") || contactTypeDesc.contains("OFFICE TELEPHONE")){ ContactTypeClassificationCode="T";}
		else if(contactTypeCode.contains("MO") || contactTypeDesc.contains("MOBILE")){ ContactTypeClassificationCode="M";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ContactTypeClassification (DBcontactTypeCode :"+DBcontactTypeCode+"& DBcontactTypeDesc"+DBcontactTypeDesc+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return ContactTypeClassificationCode;
	}

	public static String ResidenceStatusCode(String DBResidenceStatus)
	{
		String ResidenceStatus=DBUtils.readColumnWithRowIDNew(DBResidenceStatus, GetCase.scenarioID);

		String ResidenceStatusCode="";
		if(ResidenceStatus.contains("Citizen")){ResidenceStatusCode="CT";}
		else if(ResidenceStatus.contains("Foreigner")){ResidenceStatusCode="FR";}
		else if(ResidenceStatus.contains("Permanent Resident")){ResidenceStatusCode="PR";}
		else if(ResidenceStatus.contains("Migrant worker")){ResidenceStatusCode="MW";}
		else if(ResidenceStatus.contains("Refugee/Stateless")){ResidenceStatusCode="RE";}
		else if(ResidenceStatus.contains("Tourist")){ResidenceStatusCode="TO";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ResidenceStatus does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return ResidenceStatusCode;
	}

	public static String getResidenceTypeCode(String DBResidenceType)
	{
		String ResidenceType=DBUtils.readColumnWithRowIDNew(DBResidenceType, GetCase.scenarioID);

		String ResidenceTypeCode="";
		if(ResidenceType.contains("Self Owned") || ResidenceType.contains("SO") ){ResidenceTypeCode="SO";}
		else if(ResidenceType.contains("Rented") || ResidenceType.contains("RE")){ResidenceTypeCode="RE";}
		else if(ResidenceType.contains("Company / Employer Quarter")|| ResidenceType.contains("CO")){ResidenceTypeCode="CO";}
		else if(ResidenceType.contains("Government Public house")|| ResidenceType.contains("GO")){ResidenceTypeCode="GO";}
		else if(ResidenceType.contains("Living with Relative / Parents")|| ResidenceType.contains("LR")){ResidenceTypeCode="LR";}
		else if(ResidenceType.contains("Lodge")|| ResidenceType.contains("LO")){ResidenceTypeCode="LO";}
		else if(ResidenceType.contains("Bachelor accommodation")|| ResidenceType.contains("BA")){ResidenceTypeCode="BA";}
		else if(ResidenceType.contains("Others")|| ResidenceType.contains("OT")){ResidenceTypeCode="OT";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ResidenceType = ("+ResidenceType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return ResidenceTypeCode;
	}

	public static String GenderCode(String DB_Gender)
	{
		String Gender=DBUtils.readColumnWithRowIDNew(DB_Gender, GetCase.scenarioID);
		String GenderCode="";

		if(Gender.contains("MALE")){GenderCode="M";}
		else if(Gender.contains("FEMALE")){GenderCode="F";}
		else if(Gender.contains("OTHERS")){GenderCode="O";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Gender does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return GenderCode;

	}

	public static String MaritalStatusCode(String DB_MaritalStatus)
	{
		String MaritalStatus=DBUtils.readColumnWithRowIDNew(DB_MaritalStatus, GetCase.scenarioID);

		String MaritalStatusCode="";
		if(MaritalStatus.equalsIgnoreCase("Married")){MaritalStatusCode="M";}
		else if(MaritalStatus.equalsIgnoreCase("Single")){MaritalStatusCode="S";}
		else if(MaritalStatus.equalsIgnoreCase("Divorced")){MaritalStatusCode="D";}
		else if(MaritalStatus.equalsIgnoreCase("Others")){MaritalStatusCode="O";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ("+MaritalStatus+") MaritalStatus does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return MaritalStatusCode;

	}

	public static String EducationalQualificationCode(String DBEducationalQualification)
	{
//		String EducationalQualification=DBUtils.readColumnWithRowIDNew(DBEducationalQualification, GetCase.scenarioID);
		String EducationalQualification=DBEducationalQualification;

		String EducationalQualificationCode="";
		if(EducationalQualification.contains("Primary school")){EducationalQualificationCode="PSC";}
		else if(EducationalQualification.contains("SSC/HSC")){EducationalQualificationCode="SEC";}
		else if(EducationalQualification.contains("Under graduate")){EducationalQualificationCode="UND";}
		else if(EducationalQualification.contains("Graduate")){EducationalQualificationCode="GRD";}
		else if(EducationalQualification.contains("Post-graduate")){EducationalQualificationCode="PGD";}
		else if(EducationalQualification.contains("Professional Qualification")){EducationalQualificationCode="PRF";}
		else if(EducationalQualification.contains("MBA")){EducationalQualificationCode="MBA";}
		else if(EducationalQualification.contains("Diploma Holder")){EducationalQualificationCode="DIP";}
		else if(EducationalQualification.contains("Others")){EducationalQualificationCode="OTH";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: EducationalQualification = ("+EducationalQualification+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return EducationalQualificationCode;

	}

	public static String ConstitutionCode(String DBConstitutionCode)
	{

		String ConstitutionCode=DBUtils.readColumnWithRowIDNew(DBConstitutionCode, GetCase.scenarioID);
		String retrieveConstitutionCode="";
		if(ConstitutionCode.contains("Limited Liability Partnership")){retrieveConstitutionCode="051";}
		else if(ConstitutionCode.contains("Personal Investment Company")){retrieveConstitutionCode="PIC";}
		else if(ConstitutionCode.contains("Personal Investment Limited Vehicle")){retrieveConstitutionCode="PLV";}
		else if(ConstitutionCode.contains("IDFC DEPOSITS")){retrieveConstitutionCode="090";}
		else if(ConstitutionCode.contains("Society - Company")){retrieveConstitutionCode="040";}
		else if(ConstitutionCode.contains("Society - AOP")){retrieveConstitutionCode="041";}
		else if(ConstitutionCode.contains("Society - Trust")){retrieveConstitutionCode="042";}
		else if(ConstitutionCode.contains("Club - Company")){retrieveConstitutionCode="043";}
		else if(ConstitutionCode.contains("Club - AOP")){retrieveConstitutionCode="044";}
		else if(ConstitutionCode.contains("Club - Trust")){retrieveConstitutionCode="045";}
		else if(ConstitutionCode.contains("Joint Venture - Public LTD Co")){retrieveConstitutionCode="046";}
		else if(ConstitutionCode.contains("Joint Venture - Pvt LTD Co")){retrieveConstitutionCode="047";}
		else if(ConstitutionCode.contains("Joint Venture - Paternship")){retrieveConstitutionCode="048";}
		else if(ConstitutionCode.contains("Conversion Default")){retrieveConstitutionCode="049";}
		else if(ConstitutionCode.contains("Association of Persons")){retrieveConstitutionCode="052";}
		else if(ConstitutionCode.contains("Overseas branch of SCB- Group")){retrieveConstitutionCode="074";}
		else if(ConstitutionCode.contains("Non resident corporates")){retrieveConstitutionCode="076";}
		else if(ConstitutionCode.contains("Overseas bank - GROUP")){retrieveConstitutionCode="078";}
		else if(ConstitutionCode.contains("Private Limited Company")){retrieveConstitutionCode="005";}
		else if(ConstitutionCode.contains("Public Limited Company")){retrieveConstitutionCode="006";}
		else if(ConstitutionCode.contains("Govt-Cent,State,Loc,Pub Sec entity,Govt ctrld corp")){retrieveConstitutionCode="071";}
		else if(ConstitutionCode.contains("Sole Proprietorship")){retrieveConstitutionCode="002";}
		else if(ConstitutionCode.contains("Partnership")){retrieveConstitutionCode="003";}
		else if(ConstitutionCode.contains("Trust")){retrieveConstitutionCode="011";}
		else if(ConstitutionCode.contains("Embassy, Consultate, High Commission")){retrieveConstitutionCode="016";}
		else if(ConstitutionCode.contains("Overseas Bank- Non Group")){retrieveConstitutionCode="030";}
		else if(ConstitutionCode.contains("Local Bank")){retrieveConstitutionCode="034";}
		else if(ConstitutionCode.contains("individual")){retrieveConstitutionCode="031";}
		else if(ConstitutionCode.contains("Hindu Undivided Family")){retrieveConstitutionCode="035";}
		else if(ConstitutionCode.contains("Limited Co. - Conversion")){retrieveConstitutionCode="039";}
		else if(ConstitutionCode.contains("Internal Accounts")){retrieveConstitutionCode="099";}
		else if(ConstitutionCode.contains("Diplomat")){retrieveConstitutionCode="004";}
		else if(ConstitutionCode.contains("Conversion Default - Individual")){retrieveConstitutionCode="050";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ConstitutionCode = ("+ConstitutionCode+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			retrieveConstitutionCode=ConstitutionCode;
		}

		return retrieveConstitutionCode;

	}

	public static String ConnectedLendingRelationshipCode(String DBConnectedLendingRelationship)
	{

		String ConnectedLendingRelationship=""+DBUtils.readColumnWithRowIDNew(DBConnectedLendingRelationship, GetCase.scenarioID);
		String ConnectedLendingRelationshipCode="";
		if(ConnectedLendingRelationship.contains("Spouse")){ConnectedLendingRelationshipCode="SPO";}
		else if(ConnectedLendingRelationship.contains("Father")){ConnectedLendingRelationshipCode="FAT";}
		else if(ConnectedLendingRelationship.contains("Mother")){ConnectedLendingRelationshipCode="MOT";}
		else if(ConnectedLendingRelationship.contains("Son")){ConnectedLendingRelationshipCode="SON";}
		else if(ConnectedLendingRelationship.contains("Daughter")){ConnectedLendingRelationshipCode="DAU";}
		else if(ConnectedLendingRelationship.contains("Brother")){ConnectedLendingRelationshipCode="BRO";}
		else if(ConnectedLendingRelationship.contains("Sister")){ConnectedLendingRelationshipCode="SIS";}
		else if(ConnectedLendingRelationship.contains("Mother In Law")){ConnectedLendingRelationshipCode="MIL";}
		else if(ConnectedLendingRelationship.contains("Father In Law")){ConnectedLendingRelationshipCode="FIL";}
		else if(ConnectedLendingRelationship.contains("Grand Mother")){ConnectedLendingRelationshipCode="GRM";}
		else if(ConnectedLendingRelationship.contains("Grand Father")){ConnectedLendingRelationshipCode="GRF";}
		else if(ConnectedLendingRelationship.contains("Daughter In Law")){ConnectedLendingRelationshipCode="DIL";}
		else if(ConnectedLendingRelationship.contains("Son In Law")){ConnectedLendingRelationshipCode="SIL";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ConnectedLendingRelationship = ("+ConnectedLendingRelationship+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			ConnectedLendingRelationshipCode=ConnectedLendingRelationship;}

		return ConnectedLendingRelationshipCode;

	}


	public static String WorkTypeCode(String DBWorkType)
	{

		String WorkType=DBUtils.readColumnWithRowIDNew(DBWorkType, GetCase.scenarioID);
		WorkType=""+WorkType;
		String WorkTypeCode="";
		if(!WorkType.contains("null"))
		{
			if(WorkType.contains("Salaried") || WorkType.contains("S")){WorkTypeCode="S";}
			else if(WorkType.contains("Self-Employed/Business Owner") || WorkType.contains("E")){WorkTypeCode="E";}
			else if(WorkType.contains("Student") || WorkType.contains("D")){WorkTypeCode="D";}
			else if(WorkType.contains("Homemaker") || WorkType.contains("H")){WorkTypeCode="H";}
			else if(WorkType.contains("Unemployed") || WorkType.contains("U")){WorkTypeCode="U";}
			else if(WorkType.contains("Retired") || WorkType.contains("R")){WorkTypeCode="R";}
			else{logger.info(">>>>>>>>>>>>>>>>>ERROR: WorkType = ("+WorkType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: WorkType = ("+WorkType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return WorkTypeCode;

	}

	public static String SalaryModeCode(String DBSalaryMode)
	{

		String SalaryMode=DBUtils.readColumnWithRowIDNew(DBSalaryMode, GetCase.scenarioID);
		String SalaryModeCode="";
		if(SalaryMode.contains("Cash")){SalaryModeCode="CS";}
		else if(SalaryMode.contains("Cheque")){SalaryModeCode="CH";}
		else if(SalaryMode.contains("Funds Transfer")){SalaryModeCode="FT";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: SalaryModeCode = ("+SalaryMode+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return SalaryModeCode;

	}


	public static String TaxResidencyStatusCode(String DB_TaxResidencyStatus)
	{

		String TaxResidencyStatus=DBUtils.readColumnWithRowIDNew(DB_TaxResidencyStatus, GetCase.scenarioID);
		String TaxResidencyStatusCode="";
		if(TaxResidencyStatus.contains("Resident")){TaxResidencyStatusCode="R";}
		else if(TaxResidencyStatus.contains("Non Resident")){TaxResidencyStatusCode="NR";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: TaxResidencyStatusCode = ("+TaxResidencyStatus+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return TaxResidencyStatusCode;

	}

	public static String getResidentialStatusCode(String DBResidentialStatus)
	{

		String ResidentialStatus=DBUtils.readColumnWithRowIDNew(DBResidentialStatus, GetCase.scenarioID);
		String ResidentialStatusCode="";
		if(ResidentialStatus.contains("Citizen")){ResidentialStatusCode="CT";}
		else if(ResidentialStatus.contains("Foreigner")){ResidentialStatusCode="FR";}
		else if(ResidentialStatus.contains("Permanent Resident")){ResidentialStatusCode="PR";}
		else if(ResidentialStatus.contains("Migrant worker")){ResidentialStatusCode="MW";}
		else if(ResidentialStatus.contains("Refugee/Stateless")){ResidentialStatusCode="RE";}
		else if(ResidentialStatus.contains("Tourist")){ResidentialStatusCode="TO";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ResidentialStatus = ("+ResidentialStatus+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return ResidentialStatusCode;
	}

	public static String getPurposeOfLoanCode(String DBPurposeOfLoan) {
		String PurposeOfLoan=""+DBUtils.readColumnWithRowIDNew(DBPurposeOfLoan, GetCase.scenarioID);
		String PurposeOfLoanCode="";
		if(PurposeOfLoan.contains("Down Payment on Mortgage or Auto Loan")){PurposeOfLoanCode="01";}
		else if(PurposeOfLoan.contains("Home improvement or other major purchases")){PurposeOfLoanCode="02";}
		else if(PurposeOfLoan.contains("Spending on holiday or special occasion")){PurposeOfLoanCode="03";}
		else if(PurposeOfLoan.contains("Self or children Education")){PurposeOfLoanCode="04";}
		else if(PurposeOfLoan.contains("Health Care")){PurposeOfLoanCode="06";}
		else if(PurposeOfLoan.contains("Obtain Credit history")){PurposeOfLoanCode="07";}
		else if(PurposeOfLoan.contains("Paying off other debts")){PurposeOfLoanCode="09";}
		else if(PurposeOfLoan.contains("Unexpected Expense")){PurposeOfLoanCode="10";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: PurposeOfLoan = ("+PurposeOfLoan+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");PurposeOfLoanCode=PurposeOfLoan;}
		return PurposeOfLoanCode;
	}

	public static String getAcquisitionCode(String DBAcquisitionChannel) {
		String AcquisitionChannel=DBUtils.readColumnWithRowIDNew(DBAcquisitionChannel, GetCase.scenarioID);
		String AcquisitionCode="";
		if(AcquisitionChannel.contains("Branches")){AcquisitionCode="B";}
		else if(AcquisitionChannel.contains("DirectSales")){AcquisitionCode="D";}
		else if(AcquisitionChannel.contains("Others")){AcquisitionCode="O";}
		else if(AcquisitionChannel.contains("Digital (Online/Mobile) (F2F)")){AcquisitionCode="DFF";}
		else if(AcquisitionChannel.contains("Digital (Online/Mobile) (NF2F)")){AcquisitionCode="DNF";}
		else if(AcquisitionChannel.contains("Telesales (F2F)")){AcquisitionCode="TFF";}
		else if(AcquisitionChannel.contains("Telesales (NF2F)")){AcquisitionCode="TNF";}
		else if(AcquisitionChannel.contains("Relationship Manager (F2F)")){AcquisitionCode="RMF";}
		else if(AcquisitionChannel.contains("Acquisition Team (F2F)")){AcquisitionCode="AFF";}
		else if(AcquisitionChannel.contains("Cross border Rel Opening (Other SCB Office)")){AcquisitionCode="OSO";}
		else if(AcquisitionChannel.contains("Third Party Sales (Company Service Providers)")){AcquisitionCode="CSP";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: AcquisitionChannel = ("+AcquisitionChannel+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");AcquisitionCode=AcquisitionChannel;}
		return AcquisitionCode;
	}

	public static String getAccountType(String DB_AccountType) {
		String AccountType=DBUtils.readColumnWithRowIDNew(DB_AccountType, GetCase.scenarioID);
		String AccountTypeValue="";
		if(AccountType.contains("Savings Account")){AccountTypeValue="1";}
		else if(AccountType.contains("Current Account")){AccountTypeValue="2";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Repayment Account Type= ("+AccountType+") not matches with any Options<<<<<<<<<<<<<<<<<<<");
			AccountTypeValue=AccountType;}
		return AccountTypeValue;
	}

	public static String getRepaymentModeCode(String DBRepaymentMode) {
		String RepaymentMode=DBUtils.readColumnWithRowIDNew(DBRepaymentMode, GetCase.scenarioID);
		String RepaymentModeCode="";
		if(RepaymentMode.contains("Electronic Debit Authorization")){RepaymentModeCode="EDA";}
		else if(RepaymentMode.contains("Standing Instruction")){RepaymentModeCode="SI";}
		else if(RepaymentMode.contains("Post Dated Cheque")){RepaymentModeCode="PDC";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: RepaymentMode = ("+RepaymentMode+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");RepaymentModeCode=RepaymentMode;}
		return RepaymentModeCode;
	}


	public static String retrieveNatureOfBusiness(String DBNatureofBusiness) {
		String NatureofBusiness=DBUtils.readColumnWithRowIDNew(DBNatureofBusiness, GetCase.scenarioID);
		String NatureofBusinessCode="";
		if(NatureofBusiness.contains("Production/Manufacturer")){NatureofBusinessCode="02";}
		else if(NatureofBusiness.contains("Marketing/Sales")){NatureofBusinessCode="03";}
		else if(NatureofBusiness.contains("Accounting/Finance")){NatureofBusinessCode="04";}
		else if(NatureofBusiness.contains("Administration/Human Resources")){NatureofBusinessCode="06";}
		else if(NatureofBusiness.contains("IT/Software")){NatureofBusinessCode="07";}
		else if(NatureofBusiness.contains("Customer Service")){NatureofBusinessCode="08";}
		else if(NatureofBusiness.contains("Operations")){NatureofBusinessCode="09";}
		else if(NatureofBusiness.contains("R &amp; D")){NatureofBusinessCode="10";}
		else if(NatureofBusiness.contains("Audit")){NatureofBusinessCode="11";}
		else if(NatureofBusiness.contains("NMC's (No Dept mentioned)")){NatureofBusinessCode="12";}
		else if(NatureofBusiness.contains("Doctor")){NatureofBusinessCode="13";}
		else if(NatureofBusiness.contains("Engineer")){NatureofBusinessCode="14";}
		else if(NatureofBusiness.contains("Architect")){NatureofBusinessCode="15";}
		else if(NatureofBusiness.contains("Lawyer")){NatureofBusinessCode="16";}
		else if(NatureofBusiness.contains("Consultant")){NatureofBusinessCode="17";}
		else if(NatureofBusiness.contains("Chartered/Cost Accountant")){NatureofBusinessCode="18";}
		else if(NatureofBusiness.contains("Manufacturer")){NatureofBusinessCode="19";}
		else if(NatureofBusiness.contains("Trader/Distributor")){NatureofBusinessCode="20";}
		else if(NatureofBusiness.contains("Commission Agent/Broker")){NatureofBusinessCode="21";}
		else if(NatureofBusiness.contains("Exporter/Importer")){NatureofBusinessCode="22";}
		else if(NatureofBusiness.contains("Retailer/Grocer/Chemist")){NatureofBusinessCode="23";}
		else if(NatureofBusiness.contains("IT/Software related services")){NatureofBusinessCode="24";}
		else if(NatureofBusiness.contains("Construction/Real Estate/Contractor")){NatureofBusinessCode="25";}
		else if(NatureofBusiness.contains("Others (Please specify)")){NatureofBusinessCode="26";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: NatureofBusiness = ("+NatureofBusiness+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return NatureofBusinessCode;

	}


	public static String NatureofBusinessCodeNew(String DBNatureofBusiness)
	{

		String NatureofBusiness=DBUtils.readColumnWithRowIDNew(DBNatureofBusiness, GetCase.scenarioID);
		String NatureofBusinessCode="";
		if(NatureofBusiness.contains("ARTS / SPORT")){NatureofBusinessCode="NB01";}
		else if(NatureofBusiness.contains("ENTERTAINMENT")){NatureofBusinessCode="NB02";}
		else if(NatureofBusiness.contains("DESIGN")){NatureofBusinessCode="NB03";}
		else if(NatureofBusiness.contains("DECORATION")){NatureofBusinessCode="NB04";}
		else if(NatureofBusiness.contains("GAME CENTRE")){NatureofBusinessCode="NB05";}
		else if(NatureofBusiness.contains("NIGHT CLUB / SAUNA /MAJONG")){NatureofBusinessCode="NB06";}
		else if(NatureofBusiness.contains("GAMING AND GAMBLING RELATED ACTIVITIES")){NatureofBusinessCode="NB07";}
		else if(NatureofBusiness.contains("INVESTMENT / SECURITIES AND BROKERS")){NatureofBusinessCode="NB08";}
		else if(NatureofBusiness.contains("INSURANCE")){NatureofBusinessCode="NB09";}
		else if(NatureofBusiness.contains("INSURANCE AGENTS AND BROKERS")){NatureofBusinessCode="NB10";}
		else if(NatureofBusiness.contains("MONEY SERVICE BUSINESS INCLUDING VIRTUAL CURRENCIES AND INTERNET PAYMENT")){NatureofBusinessCode="NB11";}
		else if(NatureofBusiness.contains("INSURANCE AGENTS AND BROKERS")){NatureofBusinessCode="NB12";}
		else if(NatureofBusiness.contains("AUDIT / ACCOUNTING")){NatureofBusinessCode="NB13";}
		else if(NatureofBusiness.contains("FINANCE / BANKING")){NatureofBusinessCode="NB14";}
		else if(NatureofBusiness.contains("SHELL BANKS, OFFSHORE BANKS, UNLICENSED BANKS, HIGH RISK CENTRAL BANKS")){NatureofBusinessCode="NB15";}
		else if(NatureofBusiness.contains("FINANCE, FX AND HOLDING COMPANIES")){NatureofBusinessCode="NB16";}
		else if(NatureofBusiness.contains("ARCHITECTURE")){NatureofBusinessCode="NB17";}
		else if(NatureofBusiness.contains("CONSTRUCTION")){NatureofBusinessCode="NB18";}
		else if(NatureofBusiness.contains("SURVEYOR / VALUER")){NatureofBusinessCode="NB19";}
		else if(NatureofBusiness.contains("TOURISM")){NatureofBusinessCode="NB20";}
		else if(NatureofBusiness.contains("HOTEL / HOSTEL")){NatureofBusinessCode="NB21";}
		else if(NatureofBusiness.contains("CAMPING GROUND AND OTHER ACCOMODATION")){NatureofBusinessCode="NB22";}
		else if(NatureofBusiness.contains("TOUR OPERATORS")){NatureofBusinessCode="NB23";}
		else if(NatureofBusiness.contains("TRAVEL AGENTS")){NatureofBusinessCode="NB24";}
		else if(NatureofBusiness.contains("EDUCATION")){NatureofBusinessCode="NB25";}
		else if(NatureofBusiness.contains("CATERING / RESTAURANT / BAR")){NatureofBusinessCode="NB26";}
		else if(NatureofBusiness.contains("HAWKERS & STALLHOLDERS SELLING COOKED FOOD & PREPARED DRINKS")){NatureofBusinessCode="NB27";}
		else if(NatureofBusiness.contains("EVENT CATERING")){NatureofBusinessCode="NB28";}
		else if(NatureofBusiness.contains("OTHER FOOD SERVICES")){NatureofBusinessCode="NB29";}
		else if(NatureofBusiness.contains("CHARITY (NON PROFIT MAKING) / SOCIAL WELFARE ASSOCIATION")){NatureofBusinessCode="NB30";}
		else if(NatureofBusiness.contains("SOCIAL WELFARE")){NatureofBusinessCode="NB31";}
		else if(NatureofBusiness.contains("FOREIGN GOVERNMENTS AND INTERNATIONAL  ORGANISATIONS")){NatureofBusinessCode="NB32";}
		else if(NatureofBusiness.contains("POLITICAL AND RELIGIOUS ORGANISATIONS")){NatureofBusinessCode="NB33";}
		else if(NatureofBusiness.contains("CHARITY (NON PROFIT MAKING)IN HIGH RISK COUNTRIES")){NatureofBusinessCode="NB34";}
		else if(NatureofBusiness.contains("Police/Fire/Correctional Services/Customs & Excise/Immigration")){NatureofBusinessCode="NB35";}
		else if(NatureofBusiness.contains("Health/Social/Education")){NatureofBusinessCode="NB36";}
		else if(NatureofBusiness.contains("Central & State Ministry")){NatureofBusinessCode="NB37";}
		else if(NatureofBusiness.contains("Public Utility")){NatureofBusinessCode="NB38";}
		else if(NatureofBusiness.contains("COMPUTER / INTERNET COMPANY / IT BUSINESS / ISP PROVIDER / SOFTWARE DEVELOPMENT COMPANY")){NatureofBusinessCode="NB39";}
		else if(NatureofBusiness.contains("TELECOMMUNICATION")){NatureofBusinessCode="NB40";}
		else if(NatureofBusiness.contains("LEGAL SERVICE")){NatureofBusinessCode="NB41";}
		else if(NatureofBusiness.contains("GATEKEEPERS (LAWYERS, NOTARIES, OTHER INDEPENDENT LEGAL ALS AND ACCOUNTANTS AND TRUST AND COMPANY SERVICE PROVIDERS)")){NatureofBusinessCode="NB42";}
		else if(NatureofBusiness.contains("ENGINEERING / MECHANIC")){NatureofBusinessCode="NB43";}
		else if(NatureofBusiness.contains("MANUFACTURING / INDUSTRIAL")){NatureofBusinessCode="NB44";}
		else if(NatureofBusiness.contains("MANUFACTURING TOBACCO PRODUCTS/ WEARING APPAREL/LEATHER/CHEMICAL PRODUCTS")){NatureofBusinessCode="NB45";}
		else if(NatureofBusiness.contains("DEFENCE, MILITARY AND WEAPONS SALE/MANUFACTURING")){NatureofBusinessCode="NB46";}
		else if(NatureofBusiness.contains("MARKETING /PUBLIC RELATION")){NatureofBusinessCode="NB47";}
		else if(NatureofBusiness.contains("ADVERTISING")){NatureofBusinessCode="NB48";}
		else if(NatureofBusiness.contains("MEDIA / PUBLISHING")){NatureofBusinessCode="NB49";}
		else if(NatureofBusiness.contains("PRINTING")){NatureofBusinessCode="NB50";}
		else if(NatureofBusiness.contains("MEDICAL/ CLINIC / LAB")){NatureofBusinessCode="NB51";}
		else if(NatureofBusiness.contains("HOSPITAL")){NatureofBusinessCode="NB52";}
		else if(NatureofBusiness.contains("RETAIL SALES")){NatureofBusinessCode="NB53";}
		else if(NatureofBusiness.contains("DEPARTMENT STORE / SUPER MARKET / CHAIN STORE")){NatureofBusinessCode="NB54";}
		else if(NatureofBusiness.contains("PERSONAL SERVICE")){NatureofBusinessCode="NB55";}
		else if(NatureofBusiness.contains("WHOLESALES")){NatureofBusinessCode="NB56";}
		else if(NatureofBusiness.contains("FITNESS / BEAUTY / HAIR SALON")){NatureofBusinessCode="NB57";}
		else if(NatureofBusiness.contains("RETAIL SALES ANTIQUES")){NatureofBusinessCode="NB58";}
		else if(NatureofBusiness.contains("RETAIL SALES VIA STALLS TEXTILES, CLOTHING, FOOTWEAR")){NatureofBusinessCode="NB59";}
		else if(NatureofBusiness.contains("RETAIL TRADE/SALES")){NatureofBusinessCode="NB60";}
		else if(NatureofBusiness.contains("TRADING /IMPORT /EXPORT")){NatureofBusinessCode="NB61";}
		else if(NatureofBusiness.contains("RETAIL/WHOLESELLER OF WINE ABD LIQUOR")){NatureofBusinessCode="NB62";}
		else if(NatureofBusiness.contains("GOLD, (ROUGH) DIAMONDS,  JEWELLERY, OTHER PRECIOUS METALS AND MINERALS")){NatureofBusinessCode="NB63";}
		else if(NatureofBusiness.contains("PROPERTY MANAGEMENT")){NatureofBusinessCode="NB64";}
		else if(NatureofBusiness.contains("REAL ESTATE AGENT")){NatureofBusinessCode="NB65";}
		else if(NatureofBusiness.contains("TRANSPORTATION")){NatureofBusinessCode="NB66";}
		else if(NatureofBusiness.contains("AIR")){NatureofBusinessCode="NB67";}
		else if(NatureofBusiness.contains("FREIGHT FORWARD / WAREHOUSE / EXPRESS")){NatureofBusinessCode="NB68";}
		else if(NatureofBusiness.contains("LOGGING")){NatureofBusinessCode="NB69";}
		else if(NatureofBusiness.contains("EMPLOYMENT & LABOUR CONTRACTING SERVICES")){NatureofBusinessCode="NB70";}
		else if(NatureofBusiness.contains("TEMPORARY EMPLOYMENT AGENCY ACTIVITIES")){NatureofBusinessCode="NB71";}
		else if(NatureofBusiness.contains("GROWING OF SPICES, CIOTTON, RUBBER, GRAPES")){NatureofBusinessCode="NB72";}
		else if(NatureofBusiness.contains("MARINE AND FRESHWATER AQUACULTURE")){NatureofBusinessCode="NB73";}
		else if(NatureofBusiness.contains("FORESTRY")){NatureofBusinessCode="NB74";}
		else if(NatureofBusiness.contains("PETROLEUM / NATURAL GASES")){NatureofBusinessCode="NB75";}
		else if(NatureofBusiness.contains("MINING OF METALS / STONES")){NatureofBusinessCode="NB76";}

		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: NatureofBusiness = ("+NatureofBusiness+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return NatureofBusinessCode;

	}

	public static String IndustryGroupSectorCode(String DB_IndustryGroupSector)
	{

		String IndustryGroupSector=DBUtils.readColumnWithRowIDNew(DB_IndustryGroupSector, GetCase.scenarioID);
		String IndustryGroupSectorCode="";
		if(IndustryGroupSector.contains("Manufacturing")){IndustryGroupSectorCode="01";}
		else if(IndustryGroupSector.contains("Retail")){IndustryGroupSectorCode="02";}
		else if(IndustryGroupSector.contains("Wholesale")){IndustryGroupSectorCode="03";}
		else if(IndustryGroupSector.contains("Services")){IndustryGroupSectorCode="04";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: IndustryGroupSector = ("+IndustryGroupSector+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return IndustryGroupSectorCode;

	}

	public static String DesignationCode(String DB_Designation)
	{
		String Designation=DBUtils.readColumnWithRowIDNew(DB_Designation, GetCase.scenarioID);

		String DesignationCode="";
		if(Designation.contains("Senior Management")){DesignationCode="SM";}
		else if(Designation.contains("Middle Management")){DesignationCode="MM";}
		else if(Designation.contains("Junior Management")){DesignationCode="JM";}
		else if(Designation.contains("Non-Management") || Designation.contains("Clerical") || Designation.contains("Admin")){DesignationCode="NM";}
		else if(Designation.contains("Others")){DesignationCode="OT";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Designation = ("+Designation+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			DesignationCode=Designation;}

		return DesignationCode;

	}

	public static String DescribeApplicantOwnershipTypeCode(String DBDescribeApplicantOwnershipType)
	{
		String DescribeApplicantOwnershipType=DBUtils.readColumnWithRowIDNew(DBDescribeApplicantOwnershipType, GetCase.scenarioID);

		String DescribeApplicantOwnershipTypeCode="";
		if(DescribeApplicantOwnershipType.contains("Sole Proprietor")){DescribeApplicantOwnershipTypeCode="S";}
		else if(DescribeApplicantOwnershipType.contains("Partnership")){DescribeApplicantOwnershipTypeCode="P";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: DescribeApplicantOwnershipType = ("+DescribeApplicantOwnershipType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return DescribeApplicantOwnershipTypeCode;

	}

	public static String CountryCode(String DBColom_Country)
	{

		String Country=""+DBUtils.readColumnWithRowIDNew(DBColom_Country, GetCase.scenarioID);

		String CountryCode="";
		if(Country.toUpperCase().contains("ANDORRA")){CountryCode="AD";}
		else if(Country.toUpperCase().contains("UNITED ARAB EMIRATES")){CountryCode="AE";}
		else if(Country.toUpperCase().contains("AFGHANISTAN")){CountryCode="AF";}
		else if(Country.toUpperCase().contains("ANTIGUA AND BARBUDA")){CountryCode="AG";}
		else if(Country.toUpperCase().contains("ANGUILLA")){CountryCode="AI";}
		else if(Country.toUpperCase().contains("ALBANIA")){CountryCode="AL";}
		else if(Country.toUpperCase().contains("ARMENIA")){CountryCode="AM";}
		else if(Country.toUpperCase().contains("ANGOLA")){CountryCode="AO";}
		else if(Country.toUpperCase().contains("ANTARCTICA")){CountryCode="AQ";}
		else if(Country.toUpperCase().contains("ARGENTINA")){CountryCode="AR";}
		else if(Country.toUpperCase().contains("AMERICAN SAMOA")){CountryCode="AS";}
		else if(Country.toUpperCase().contains("AUSTRIA")){CountryCode="AT";}
		else if(Country.toUpperCase().contains("AUSTRALIA")){CountryCode="AU";}
		else if(Country.toUpperCase().contains("ARUBA")){CountryCode="AW";}
		else if(Country.toUpperCase().contains("ALAND ISLANDS")){CountryCode="AX";}
		else if(Country.toUpperCase().contains("AZERBAIJAN")){CountryCode="AZ";}
		else if(Country.toUpperCase().contains("BOSNIA AND HERZEGOVINA")){CountryCode="BA";}
		else if(Country.toUpperCase().contains("BARBADOS")){CountryCode="BB";}
		else if(Country.toUpperCase().contains("BANGLADESH")){CountryCode="BD";}
		else if(Country.toUpperCase().contains("BELGIUM")){CountryCode="BE";}
		else if(Country.toUpperCase().contains("BURKINA FASO")){CountryCode="BF";}
		else if(Country.toUpperCase().contains("BULGARIA")){CountryCode="BG";}
		else if(Country.toUpperCase().contains("BAHRAIN")){CountryCode="BH";}
		else if(Country.toUpperCase().contains("BURUNDI")){CountryCode="BI";}
		else if(Country.toUpperCase().contains("BENIN")){CountryCode="BJ";}
		else if(Country.toUpperCase().contains("SAINT BARTHELEMY")){CountryCode="BL";}
		else if(Country.toUpperCase().contains("BERMUDA")){CountryCode="BM";}
		else if(Country.toUpperCase().contains("BRUNEI DARUSSALAM")){CountryCode="BN";}
		else if(Country.toUpperCase().contains("BOLIVIA,PLURINATIONAL STATEOF")){CountryCode="BO";}
		else if(Country.toUpperCase().contains("BONAIRE, SINT EUSTATIUS, SABA")){CountryCode="BQ";}
		else if(Country.toUpperCase().contains("BRAZIL")){CountryCode="BR";}
		else if(Country.toUpperCase().contains("BAHAMAS")){CountryCode="BS";}
		else if(Country.toUpperCase().contains("BHUTAN")){CountryCode="BT";}
		else if(Country.toUpperCase().contains("BOUVET ISLAND")){CountryCode="BV";}
		else if(Country.toUpperCase().contains("BOTSWANA")){CountryCode="BW";}
		else if(Country.toUpperCase().contains("BELARUS")){CountryCode="BY";}
		else if(Country.toUpperCase().contains("BELIZE")){CountryCode="BZ";}
		else if(Country.toUpperCase().contains("CANADA")){CountryCode="CA";}
		else if(Country.toUpperCase().contains("COCOS (KEELING) ISLANDS")){CountryCode="CC";}
		else if(Country.toUpperCase().contains("CONGO, DEMOCRATIC REPUBLIC OF")){CountryCode="CD";}
		else if(Country.toUpperCase().contains("CENTRAL AFRICAN REPUBLIC")){CountryCode="CF";}
		else if(Country.toUpperCase().contains("CONGO")){CountryCode="CG";}
		else if(Country.toUpperCase().contains("SWITZERLAND")){CountryCode="CH";}
		else if(Country.toUpperCase().contains("COTE D'IVOIRE")){CountryCode="CI";}
		else if(Country.toUpperCase().contains("COOK ISLANDS")){CountryCode="CK";}
		else if(Country.toUpperCase().contains("CHILE")){CountryCode="CL";}
		else if(Country.toUpperCase().contains("CAMEROON")){CountryCode="CM";}
		else if(Country.toUpperCase().contains("CHINA")){CountryCode="CN";}
		else if(Country.toUpperCase().contains("COLOMBIA")){CountryCode="CO";}
		else if(Country.toUpperCase().contains("COSTA RICA")){CountryCode="CR";}
		else if(Country.toUpperCase().contains("CUBA")){CountryCode="CU";}
		else if(Country.toUpperCase().contains("CABO VERDE")){CountryCode="CV";}
		else if(Country.toUpperCase().contains("CURACAO")){CountryCode="CW";}
		else if(Country.toUpperCase().contains("CHRISTMAS ISLAND")){CountryCode="CX";}
		else if(Country.toUpperCase().contains("CYPRUS")){CountryCode="CY";}
		else if(Country.toUpperCase().contains("CZECH REPUBLIC")){CountryCode="CZ";}
		else if(Country.toUpperCase().contains("GERMANY")){CountryCode="DE";}
		else if(Country.toUpperCase().contains("DUBAI INT FIN CENTRE (DIFC)")){CountryCode="DF";}
		else if(Country.toUpperCase().contains("DJIBOUTI")){CountryCode="DJ";}
		else if(Country.toUpperCase().contains("DENMARK")){CountryCode="DK";}
		else if(Country.toUpperCase().contains("DOMINICA")){CountryCode="DM";}
		else if(Country.toUpperCase().contains("DOMINICAN REPUBLIC")){CountryCode="DO";}
		else if(Country.toUpperCase().contains("ALGERIA")){CountryCode="DZ";}
		else if(Country.toUpperCase().contains("ECUADOR")){CountryCode="EC";}
		else if(Country.toUpperCase().contains("ESTONIA")){CountryCode="EE";}
		else if(Country.toUpperCase().contains("EGYPT")){CountryCode="EG";}
		else if(Country.toUpperCase().contains("WESTERN SAHARA")){CountryCode="EH";}
		else if(Country.toUpperCase().contains("ERITREA")){CountryCode="ER";}
		else if(Country.toUpperCase().contains("SPAIN")){CountryCode="ES";}
		else if(Country.toUpperCase().contains("ETHIOPIA")){CountryCode="ET";}
		else if(Country.toUpperCase().contains("FINLAND")){CountryCode="FI";}
		else if(Country.toUpperCase().contains("FIJI")){CountryCode="FJ";}
		else if(Country.toUpperCase().contains("FALKLAND ISLANDS FLK")){CountryCode="FK";}
		else if(Country.toUpperCase().contains("MICRONESIA,FEDERATED STATE OF")){CountryCode="FM";}
		else if(Country.toUpperCase().contains("FAROE ISLANDS")){CountryCode="FO";}
		else if(Country.toUpperCase().contains("FRANCE")){CountryCode="FR";}
		else if(Country.toUpperCase().contains("GABON")){CountryCode="GA";}
		else if(Country.toUpperCase().contains("UNITED KINGDOM")){CountryCode="GB";}
		else if(Country.toUpperCase().contains("GRENADA")){CountryCode="GD";}
		else if(Country.toUpperCase().contains("GEORGIA")){CountryCode="GE";}
		else if(Country.toUpperCase().contains("FRENCH GUIANA")){CountryCode="GF";}
		else if(Country.toUpperCase().contains("GUERNSEY")){CountryCode="GG";}
		else if(Country.toUpperCase().contains("GHANA")){CountryCode="GH";}
		else if(Country.toUpperCase().contains("GIBRALTAR")){CountryCode="GI";}
		else if(Country.toUpperCase().contains("GREENLAND")){CountryCode="GL";}
		else if(Country.toUpperCase().contains("GAMBIA")){CountryCode="GM";}
		else if(Country.toUpperCase().contains("GUINEA")){CountryCode="GN";}
		else if(Country.toUpperCase().contains("GUADELOUPE")){CountryCode="GP";}
		else if(Country.toUpperCase().contains("EQUATORIAL GUINEA")){CountryCode="GQ";}
		else if(Country.toUpperCase().contains("GREECE")){CountryCode="GR";}
		else if(Country.toUpperCase().contains("SOUTH GEORGIA,SANDWICH ISLAND")){CountryCode="GS";}
		else if(Country.toUpperCase().contains("GUATEMALA")){CountryCode="GT";}
		else if(Country.toUpperCase().contains("GUAM")){CountryCode="GU";}
		else if(Country.toUpperCase().contains("GUINEA")){CountryCode="GW";}
		else if(Country.toUpperCase().contains("GUYANA")){CountryCode="GY";}
		else if(Country.toUpperCase().contains("HONG KONG")){CountryCode="HK";}
		else if(Country.toUpperCase().contains("HEARD ISLAND,MCDONALD ISLANDS")){CountryCode="HM";}
		else if(Country.toUpperCase().contains("HONDURAS")){CountryCode="HN";}
		else if(Country.toUpperCase().contains("CROATIA")){CountryCode="HR";}
		else if(Country.toUpperCase().contains("HAITI")){CountryCode="HT";}
		else if(Country.toUpperCase().contains("HUNGARY")){CountryCode="HU";}
		else if(Country.toUpperCase().contains("INDONESIA")){CountryCode="IDI";}
		else if(Country.toUpperCase().contains("IRELAND")){CountryCode="IE";}
		else if(Country.toUpperCase().contains("ISRAEL")){CountryCode="IL";}
		else if(Country.toUpperCase().contains("INDIA")){CountryCode="IN";}
		else if(Country.toUpperCase().contains("BRITISH INDIAN OCEANTERRITORY")){CountryCode="IO";}
		else if(Country.toUpperCase().contains("IRAQ")){CountryCode="IQ";}
		else if(Country.toUpperCase().contains("IRAN, ISLAMIC REPUBLIC OF")){CountryCode="IR";}
		else if(Country.toUpperCase().contains("ICELAND")){CountryCode="IS";}
		else if(Country.toUpperCase().contains("ITALY")){CountryCode="IT";}
		else if(Country.toUpperCase().contains("JERSEY")){CountryCode="JE";}
		else if(Country.toUpperCase().contains("JAMAICA")){CountryCode="JM";}
		else if(Country.toUpperCase().contains("JORDAN")){CountryCode="JO";}
		else if(Country.toUpperCase().contains("JAPAN")){CountryCode="JP";}
		else if(Country.toUpperCase().contains("KENYA")){CountryCode="KE";}
		else if(Country.toUpperCase().contains("KYRGYZSTAN")){CountryCode="KG";}
		else if(Country.toUpperCase().contains("CAMBODIA")){CountryCode="KH";}
		else if(Country.toUpperCase().contains("KIRIBATI")){CountryCode="KI";}
		else if(Country.toUpperCase().contains("COMOROS")){CountryCode="KM";}
		else if(Country.toUpperCase().contains("SAINT KITTS AND NEVIS")){CountryCode="KN";}
		else if(Country.toUpperCase().contains("KOREADEMOCRATIC PEOPLES REP")){CountryCode="KP";}
		else if(Country.toUpperCase().contains("KOREA, REPUBLIC OF")){CountryCode="KR";}
		else if(Country.toUpperCase().contains("KUWAIT")){CountryCode="KW";}
		else if(Country.toUpperCase().contains("CAYMAN ISLANDS")){CountryCode="KY";}
		else if(Country.toUpperCase().contains("KAZAKHSTAN")){CountryCode="KZ";}
		else if(Country.toUpperCase().contains("LAO PEOPLES DEMOCRATIC REP")){CountryCode="LA";}
		else if(Country.toUpperCase().contains("LEBANON")){CountryCode="LB";}
		else if(Country.toUpperCase().contains("SAINT LUCIA")){CountryCode="LC";}
		else if(Country.toUpperCase().contains("IECHTENSTEIN")){CountryCode="LI L";}
		else if(Country.toUpperCase().contains("SRI LANKA")){CountryCode="LK";}
		else if(Country.toUpperCase().contains("LABUAN")){CountryCode="LN";}
		else if(Country.toUpperCase().contains("LIBERIA")){CountryCode="LR";}
		else if(Country.toUpperCase().contains("LESOTHO")){CountryCode="LS";}
		else if(Country.toUpperCase().contains("LITHUANIA")){CountryCode="LT";}
		else if(Country.toUpperCase().contains("LUXEMBOURG")){CountryCode="LU";}
		else if(Country.toUpperCase().contains("LATVIA")){CountryCode="LV";}
		else if(Country.toUpperCase().contains("LIBYA")){CountryCode="LY";}
		else if(Country.toUpperCase().contains("MOROCCO")){CountryCode="MA";}
		else if(Country.toUpperCase().contains("MONACO")){CountryCode="MC";}
		else if(Country.toUpperCase().contains("MOLDOVA, REPUBLIC OF")){CountryCode="MD";}
		else if(Country.toUpperCase().contains("MONTENEGRO")){CountryCode="ME";}
		else if(Country.toUpperCase().contains("SAINT MARTIN (FRENCH PART)")){CountryCode="MF";}
		else if(Country.toUpperCase().contains("MADAGASCAR")){CountryCode="MG";}
		else if(Country.toUpperCase().contains("MARSHALL ISLANDS")){CountryCode="MH";}
		else if(Country.toUpperCase().contains("MACEDONIA, REPUBLIC OF")){CountryCode="MK";}
		else if(Country.toUpperCase().contains("MALI")){CountryCode="ML";}
		else if(Country.toUpperCase().contains("MYANMAR")){CountryCode="MM";}
		else if(Country.toUpperCase().contains("MONGOLIA")){CountryCode="MN";}
		else if(Country.toUpperCase().contains("MACAO")){CountryCode="MO";}
		else if(Country.toUpperCase().contains("NORTHERN MARIANA ISLANDS")){CountryCode="MP";}
		else if(Country.toUpperCase().contains("MARTINIQUE")){CountryCode="MQ";}
		else if(Country.toUpperCase().contains("MAURITANIA")){CountryCode="MR";}
		else if(Country.toUpperCase().contains("MONTSERRAT")){CountryCode="MS";}
		else if(Country.toUpperCase().contains("MALTA")){CountryCode="MT";}
		else if(Country.toUpperCase().contains("MAURITIUS")){CountryCode="MU";}
		else if(Country.toUpperCase().contains("MALDIVES")){CountryCode="MV";}
		else if(Country.toUpperCase().contains("MALAWI")){CountryCode="MW";}
		else if(Country.toUpperCase().contains("MEXICO")){CountryCode="MX";}
		else if(Country.toUpperCase().contains("MALAYSIA")){CountryCode="MY";}
		else if(Country.toUpperCase().contains("MOZAMBIQUE")){CountryCode="MZ";}
		else if(Country.toUpperCase().contains("NAMIBIA")){CountryCode="NA";}
		else if(Country.toUpperCase().contains("GLOBAL DNB (DATA NOT IN BCRS)")){CountryCode="NB";}
		else if(Country.toUpperCase().contains("NEW CALEDONIA")){CountryCode="NC";}
		else if(Country.toUpperCase().contains("NIGER")){CountryCode="NE";}
		else if(Country.toUpperCase().contains("NORFOLK ISLAND")){CountryCode="NF";}
		else if(Country.toUpperCase().contains("NIGERIA")){CountryCode="NG";}
		else if(Country.toUpperCase().contains("NICARAGUA")){CountryCode="NI";}
		else if(Country.toUpperCase().contains("NETHERLANDS")){CountryCode="NL";}
		else if(Country.toUpperCase().contains("NORWAY")){CountryCode="NO";}
		else if(Country.toUpperCase().contains("NEPAL")){CountryCode="NP";}
		else if(Country.toUpperCase().contains("NAURU")){CountryCode="NR";}
		else if(Country.toUpperCase().contains("NIUE")){CountryCode="NU";}
		else if(Country.toUpperCase().contains("NEW ZEALAND")){CountryCode="NZ";}
		else if(Country.toUpperCase().contains("OMAN")){CountryCode="OM";}
		else if(Country.toUpperCase().contains("GLOBAL PRODUCTS")){CountryCode="OT";}
		else if(Country.toUpperCase().contains("PANAMA")){CountryCode="PA";}
		else if(Country.toUpperCase().contains("PERU")){CountryCode="PE";}
		else if(Country.toUpperCase().contains("FRENCH POLYNESIA")){CountryCode="PF";}
		else if(Country.toUpperCase().contains("PAPUA NEW GUINEA")){CountryCode="PG";}
		else if(Country.toUpperCase().contains("PHILIPPINES")){CountryCode="PH";}
		else if(Country.toUpperCase().contains("PAKISTAN")){CountryCode="PK";}
		else if(Country.toUpperCase().contains("POLAND")){CountryCode="PL";}
		else if(Country.toUpperCase().contains("SAINT PIERRE AND MIQUELON")){CountryCode="PM";}
		else if(Country.toUpperCase().contains("PITCAIRN")){CountryCode="PN";}
		else if(Country.toUpperCase().contains("PUERTO RICO")){CountryCode="PR";}
		else if(Country.toUpperCase().contains("PALESTINE, STATE OF")){CountryCode="PS";}
		else if(Country.toUpperCase().contains("PORTUGAL")){CountryCode="PT";}
		else if(Country.toUpperCase().contains("PALAU")){CountryCode="PW";}
		else if(Country.toUpperCase().contains("PARAGUAY")){CountryCode="PY";}
		else if(Country.toUpperCase().contains("QATAR")){CountryCode="QA";}
		else if(Country.toUpperCase().contains("AFRICA REGION OTHERS (ARO)")){CountryCode="RA";}
		else if(Country.toUpperCase().contains("REUNION")){CountryCode="RE";}
		else if(Country.toUpperCase().contains("ROMANIA")){CountryCode="RO";}
		else if(Country.toUpperCase().contains("SERBIA")){CountryCode="RS";}
		else if(Country.toUpperCase().contains("RUSSIAN FEDERATION")){CountryCode="RU";}
		else if(Country.toUpperCase().contains("RWANDA")){CountryCode="RW";}
		else if(Country.toUpperCase().contains("SAUDI ARABIA")){CountryCode="SA";}
		else if(Country.toUpperCase().contains("SOLOMON ISLANDS")){CountryCode="SB";}
		else if(Country.toUpperCase().contains("SEYCHELLES")){CountryCode="SC";}
		else if(Country.toUpperCase().contains("SUDAN")){CountryCode="SD";}
		else if(Country.toUpperCase().contains("SWEDEN")){CountryCode="SE";}
		else if(Country.toUpperCase().contains("SINGAPORE")){CountryCode="SG";}
		else if(Country.toUpperCase().contains("STHELENA ASCENSN TRISTANCUNHA")){CountryCode="SH";}
		else if(Country.toUpperCase().contains("SLOVENIA")){CountryCode="SI";}
		else if(Country.toUpperCase().contains("SVALBARD AND JAN MAYEN")){CountryCode="SJ";}
		else if(Country.toUpperCase().contains("SLOVAKIA")){CountryCode="SK";}
		else if(Country.toUpperCase().contains("SIERRA LEONE")){CountryCode="SL";}
		else if(Country.toUpperCase().contains("SAN MARINO")){CountryCode="SM";}
		else if(Country.toUpperCase().contains("SENEGAL")){CountryCode="SN";}
		else if(Country.toUpperCase().contains("SOMALIA")){CountryCode="SO";}
		else if(Country.toUpperCase().contains("SNPC ")){CountryCode="SP";}
		else if(Country.toUpperCase().contains("SURINAME")){CountryCode="SR";}
		else if(Country.toUpperCase().contains("SOUTH SUDAN")){CountryCode="SS";}
		else if(Country.toUpperCase().contains("SAO TOME AND PRINCIPE")){CountryCode="ST";}
		else if(Country.toUpperCase().contains("EL SALVADOR")){CountryCode="SV";}
		else if(Country.toUpperCase().contains("SINT MAARTEN (DUTCH PART)")){CountryCode="SX";}
		else if(Country.toUpperCase().contains("SYRIAN ARAB REPUBLIC")){CountryCode="SY";}
		else if(Country.toUpperCase().contains("SWAZILAND")){CountryCode="SZ";}
		else if(Country.toUpperCase().contains("TURKS AND CAICOS ISLANDS")){CountryCode="TC";}
		else if(Country.toUpperCase().contains("CHAD")){CountryCode="TD";}
		else if(Country.toUpperCase().contains("FRENCH SOUTHERN TERRITORIES")){CountryCode="TF";}
		else if(Country.toUpperCase().contains("TOGO")){CountryCode="TG";}
		else if(Country.toUpperCase().contains("THAILAND")){CountryCode="TH";}
		else if(Country.toUpperCase().contains("TAJIKISTAN")){CountryCode="TJ";}
		else if(Country.toUpperCase().contains("TOKELAU")){CountryCode="TK";}
		else if(Country.toUpperCase().contains("TIMOR")){CountryCode="TL";}
		else if(Country.toUpperCase().contains("TURKMENISTAN")){CountryCode="TM";}
		else if(Country.toUpperCase().contains("TUNISIA")){CountryCode="TN";}
		else if(Country.toUpperCase().contains("TONGA")){CountryCode="TO";}
		else if(Country.toUpperCase().contains("TURKEY")){CountryCode="TR";}
		else if(Country.toUpperCase().contains("TRINIDAD AND TOBAGO")){CountryCode="TT";}
		else if(Country.toUpperCase().contains("TUVALU")){CountryCode="TV";}
		else if(Country.toUpperCase().contains("TAIWAN")){CountryCode="TW";}
		else if(Country.toUpperCase().contains("TANZANIA, UNITED REPUBLIC OF")){CountryCode="TZ";}
		else if(Country.toUpperCase().contains("UKRAINE")){CountryCode="UA";}
		else if(Country.toUpperCase().contains("UGANDA")){CountryCode="UG";}
		else if(Country.toUpperCase().contains("UNITED STATES OUTLYING ISLAND")){CountryCode="UM";}
		else if(Country.toUpperCase().contains("UNITED STATES OF AMERICA")){CountryCode="US";}
		else if(Country.toUpperCase().contains("URUGUAY")){CountryCode="UY";}
		else if(Country.toUpperCase().contains("UZBEKISTAN")){CountryCode="UZ";}
		else if(Country.toUpperCase().contains("HOLY SEE")){CountryCode="VA";}
		else if(Country.toUpperCase().contains("SAINT VINCENT, THE GRENADINES")){CountryCode="VC";}
		else if(Country.toUpperCase().contains("VENEZUELA, BOLIVARIAN REP OF")){CountryCode="VE";}
		else if(Country.toUpperCase().contains("VIRGIN ISLANDS, BRITISH")){CountryCode="VG";}
		else if(Country.toUpperCase().contains("VIRGIN ISLANDS, U.S.")){CountryCode="VI";}
		else if(Country.toUpperCase().contains("VIETNAM")){CountryCode="VN";}
		else if(Country.toUpperCase().contains("VANUATU")){CountryCode="VU";}
		else if(Country.toUpperCase().contains("WALLIS AND FUTUNA")){CountryCode="WF";}
		else if(Country.toUpperCase().contains("")){CountryCode="WS SAMOA";}
		else if(Country.toUpperCase().contains("Saudi offshore")){CountryCode="XA";}
		else if(Country.toUpperCase().contains("KOSOVO")){CountryCode="XK";}
		else if(Country.toUpperCase().contains("All Countries / Global")){CountryCode="XX";}
		else if(Country.toUpperCase().contains("YEMEN")){CountryCode="YE";}
		else if(Country.toUpperCase().contains("MAYOTTE")){CountryCode="YT";}
		else if(Country.toUpperCase().contains("SOUTH AFRICA")){CountryCode="ZA";}
		else if(Country.toUpperCase().contains("ZAMBIA")){CountryCode="ZM";}
		else if(Country.toUpperCase().contains("ZIMBABWE")){CountryCode="ZW";}
		else if(Country.toUpperCase().contains("Others")){CountryCode="ZZ";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Country = ("+Country+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");CountryCode=Country;}

		return CountryCode;

	}

	public static String CompanyTypeCode(String CDColom_CompanyType)
	{

		String CompanyType=DBUtils.readColumnWithRowIDNew(CDColom_CompanyType, GetCase.scenarioID);
		String CompanyTypeCode="";
		if(CompanyType.contains("Multi National Company")){CompanyTypeCode="01";}
		else if(CompanyType.contains("Public Limited")){CompanyTypeCode="02";}
		else if(CompanyType.contains("Private Limited")){CompanyTypeCode="03";}
		else if(CompanyType.contains("Partnership Firm")){CompanyTypeCode="04";}
		else if(CompanyType.contains("Govt Sector/PSU")){CompanyTypeCode="05";}
		else if(CompanyType.contains("Proprietorship Firm")){CompanyTypeCode="06";}
		else if(CompanyType.contains("Others")){CompanyTypeCode="07";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: CompanyTypeCode = ("+CompanyType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return CompanyTypeCode;
	}

	public static String RadioButtonCode(String DBColom_RadioButton) {
		String RadioButton=DBUtils.readColumnWithRowIDNew(DBColom_RadioButton, GetCase.scenarioID);
		String RadioButtonCode="";
		if(RadioButton.contains("Y") || RadioButton.equalsIgnoreCase("YES")){RadioButtonCode="Y";}
		else if(RadioButton.contains("N") || RadioButton.equalsIgnoreCase("No")){RadioButtonCode="N";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: RadioButtonCode = ("+RadioButton+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return RadioButtonCode;
	}


	public static String EmployerNameCode(String DBColom_EmployerName) {
		String EmployerName=DBUtils.readColumnWithRowIDNew(DBColom_EmployerName, GetCase.scenarioID);
		String EmployerCode="";
		if(EmployerName.contains("ACCENTURE SERVICES")){EmployerCode="AA001";}
		else if(EmployerName.contains("MAX HYPERMARKET INDIA")){EmployerCode="AA002";}
		else if(EmployerName.contains("HEXAWARE TECH")){EmployerCode="AA003";}
		else if(EmployerName.contains("AAI (AIRPORTS AUTHORITY OF INDIA)")){EmployerCode="AA004";}
		else if(EmployerName.contains("ALLAHABAD BANK")){EmployerCode="AA005";}
		else if(EmployerName.contains("ALLEGIS SERVICE (INDIA)")){EmployerCode="AA006";}
		else if(EmployerName.contains("WIPRO LIMITED")){EmployerCode="AA007";}
		else if(EmployerName.contains("UNITED INDIA INSURANCE CO LIMITED")){EmployerCode="AA008";}
		else if(EmployerName.contains("ITC INFOTECH INDIA LIMITED")){EmployerCode="AA009";}
		else if(EmployerName.contains("ATOS INDIA")){EmployerCode="AA010";}
		else if(EmployerName.contains("AUROBINDO PHARMA LIMITED")){EmployerCode="AA011";}
		else if(EmployerName.contains("ARICENT TECHNOLOGIES (HOLDINGS) LIMITED")){EmployerCode="AA012";}
		else if(EmployerName.contains("BA CONTINUUM INDIA")){EmployerCode="AA013";}
		else if(EmployerName.contains("BANK OF BARODA")){EmployerCode="AA014";}
		else if(EmployerName.contains("HSBC BANK")){EmployerCode="AA015";}
		else if(EmployerName.contains("BHARAT ELECTRONICS LIMITED( CATEGORY IS FOR NON CLERICAL AND OTHER THAN BLUE COLLAR EMPLOYEES)")){EmployerCode="AA016";}
		else if(EmployerName.contains("BHARAT HEAVY ELECTRICALS LIMITED")){EmployerCode="AA017";}
		else if(EmployerName.contains("BHARAT PETROLEUM CORPORATION LIMITED")){EmployerCode="AA018";}
		else if(EmployerName.contains("BHARAT SANCHAR NIGAM LIMITED (BSNL)")){EmployerCode="AA019";}
		else if(EmployerName.contains("BHARTI AIRTEL LIMITED")){EmployerCode="AA020";}
		else if(EmployerName.contains("BOSCH LIMITED")){EmployerCode="AA021";}
		else if(EmployerName.contains("CANARA BANK")){EmployerCode="AA022";}
		else if(EmployerName.contains("CAPGEMINI INDIA")){EmployerCode="AA023";}
		else if(EmployerName.contains("CAPGEMINI TECHNOLOGY SERVICES INDIA LIMITED")){EmployerCode="AA024";}
		else if(EmployerName.contains("CAPGENT TECHNOLOGY")){EmployerCode="AA025";}
		else if(EmployerName.contains("CENTRAL INDUSTRIAL SECURITY FO")){EmployerCode="AA026";}
		else if(EmployerName.contains("CGI INFORMATION SYSTEMS & MANAGEMENT CONSULTANTS")){EmployerCode="AA027";}
		else if(EmployerName.contains("CIPLA LIMITED")){EmployerCode="AA028";}
		else if(EmployerName.contains("CISCO SYSTEMS (INDIA)")){EmployerCode="AA029";}
		else if(EmployerName.contains("AIR FORCE CENTRAL ACCOUNTS OFF")){EmployerCode="AA030";}
		else if(EmployerName.contains("COGNIZANT TECHNOLOGY SOLUTIONS INDIA")){EmployerCode="AA031";}
		else if(EmployerName.contains("AMDOCS DEVELOPMENT CENTRE INDIA PRIVATE.LIMITED")){EmployerCode="AA032";}
		else if(EmployerName.contains("DABUR INDIA LIMITED")){EmployerCode="AA033";}
		else if(EmployerName.contains("DAMODAR VALLEY CORPORATION")){EmployerCode="AA034";}
		else if(EmployerName.contains("DBOI GLOBAL SERVICES")){EmployerCode="AA035";}
		else if(EmployerName.contains("DELHI METRO RAIL CORPORATION")){EmployerCode="AA036";}
		else if(EmployerName.contains("DELL INTERNATIONAL SERVICE LIMITED")){EmployerCode="AA037";}
		else if(EmployerName.contains("DELOITTE CONSULTING INDIA")){EmployerCode="AA038";}
		else if(EmployerName.contains("DR REDDY'S LABORATORIES LIMITED")){EmployerCode="AA039";}
		else if(EmployerName.contains("EIT SERVICES INDIA PRIVATE. LIMITED")){EmployerCode="AA041";}
		else if(EmployerName.contains("ERICSSON INDIA GLOBAL SERVICES")){EmployerCode="AA042";}
		else if(EmployerName.contains("ERNST & YOUNG LLP")){EmployerCode="AA043";}
		else if(EmployerName.contains("EXL SERVICES.COM (I)")){EmployerCode="AA045";}
		else if(EmployerName.contains("FIDELITY INFORMATION SYS CO INDIA")){EmployerCode="AA046";}
		else if(EmployerName.contains("FIS GLOBAL BUSINESS SOLUTION INDIA (EARLIER KNOWN AS EFUNDS INTERNATIONAL INDIA)")){EmployerCode="AA047";}
		else if(EmployerName.contains("FORD INDIA LIMITED")){EmployerCode="AA048";}
		else if(EmployerName.contains("GODREJ AND BOYCE MFG CO LTD")){EmployerCode="AA049";}
		else if(EmployerName.contains("HCL TECHNOLOGIES LIMITED")){EmployerCode="AA050";}
		else if(EmployerName.contains("HP")){EmployerCode="AA052";}
		else if(EmployerName.contains("HINDUSTAN PETROLEUM CORPORATION LIMITED ( HPCL)")){EmployerCode="AA054";}
		else if(EmployerName.contains("HONEYWELL TECHNOLOGY SOLUTIONS LAB")){EmployerCode="AA055";}
		else if(EmployerName.contains("HSBC ELECTRONIC")){EmployerCode="AA058";}
		else if(EmployerName.contains("ICICI BANK")){EmployerCode="AA060";}
		else if(EmployerName.contains("ICICI LOMBARD GENERAL INSURANCE")){EmployerCode="AA061";}
		else if(EmployerName.contains("ICICI PRUDENTIAL LIFE INSURANCE")){EmployerCode="AA062";}
		else if(EmployerName.contains("IDBI BANK LIMITED")){EmployerCode="AA063";}
		else if(EmployerName.contains("IKYA HUMAN CAPITAL SOLUTIONS")){EmployerCode="AA065";}
		else if(EmployerName.contains("INAUTIX TECHNOLOGIES INDIA (P) LIMITED")){EmployerCode="AA066";}
		else if(EmployerName.contains("INDIAN AIR FORCE")){EmployerCode="AA067";}
		else if(EmployerName.contains("INDIAN ARMY")){EmployerCode="AA068";}
		else if(EmployerName.contains("INDIAN NAVY")){EmployerCode="AA069";}
		else if(EmployerName.contains("INDIAN OIL CORPORATION LIMITED")){EmployerCode="AA070";}
		else if(EmployerName.contains("INDUSIND BANK")){EmployerCode="AA071";}
		else if(EmployerName.contains("INTELENET GLOBAL SERVICES")){EmployerCode="AA073";}
		else if(EmployerName.contains("ITC LIMITED")){EmployerCode="AA075";}
		else if(EmployerName.contains("JP MANAGEMENT SERVICES")){EmployerCode="AA076";}
		else if(EmployerName.contains("JET AIRWAYS")){EmployerCode="AA077";}
		else if(EmployerName.contains("KOTAK MAHINDRA BANK")){EmployerCode="AA078";}
		else if(EmployerName.contains("KPMG")){EmployerCode="AA079";}
		else if(EmployerName.contains("LARSEN & TOUBRO LIMITED")){EmployerCode="AA081";}
		else if(EmployerName.contains("LIFE INSURANCE CORPORATION OF INDIA")){EmployerCode="AA082";}
		else if(EmployerName.contains("LIFESTYLE INTERNATIONAL")){EmployerCode="AA083";}
		else if(EmployerName.contains("MAERSK GLOBAL SERVICE CENTRES (INDIA)")){EmployerCode="AA084";}
		else if(EmployerName.contains("MAGNA INFOTECH")){EmployerCode="AA085";}
		else if(EmployerName.contains("MAHINDRA & MAHINDRA LIMITED")){EmployerCode="AA086";}
		else if(EmployerName.contains("MARUTI SUZUKI AUTOMOBILES INDIA LIMITED")){EmployerCode="AA087";}
		else if(EmployerName.contains("MIND TREE LIMITED ( EARLIER KNOWN AS  MINDTREE CONSULTING)")){EmployerCode="AA089";}
		else if(EmployerName.contains("MINSTRY OF DEFENCE")){EmployerCode="AA090";}
		else if(EmployerName.contains("MPHASIS LIMITED")){EmployerCode="AA091";}
		else if(EmployerName.contains("NAVAL PAY OFFICE")){EmployerCode="AA092";}
		else if(EmployerName.contains("NOMURA SERVICES INDIA")){EmployerCode="AA094";}
		else if(EmployerName.contains("NTT DATA GLOBAL DELIVERY SERVICES LIMITED")){EmployerCode="AA096";}
		else if(EmployerName.contains("OIL & NATURAL GAS CORPORATION LIMITED")){EmployerCode="AA097";}
		else if(EmployerName.contains("ORACLE FINANCIAL SERVICES SOFTWARE LIMITED( FORMERLY I-FLEX SOLUTIONS)")){EmployerCode="AA098";}
		else if(EmployerName.contains("ORACLE INDIA")){EmployerCode="AA099";}
		else if(EmployerName.contains("ORIENTAL BANK OF COMMERCE")){EmployerCode="AA100";}
		else if(EmployerName.contains("POWER GRID CORPORATION OF INDIA LIMITED")){EmployerCode="AA101";}
		else if(EmployerName.contains("PRICE WATER HOUSE COOPERS (P) LIMITED")){EmployerCode="AA102";}
		else if(EmployerName.contains("PUNJAB NATIONAL BANK")){EmployerCode="AA103";}
		else if(EmployerName.contains("QUALCOMM")){EmployerCode="AA104";}
		else if(EmployerName.contains("QUINTILES RESEARCH INDIA")){EmployerCode="AA105";}
		else if(EmployerName.contains("RBS SERVICES INDIA")){EmployerCode="AA106";}
		else if(EmployerName.contains("RELIANCE RETAIL LIMITED")){EmployerCode="AA108";}
		else if(EmployerName.contains("RESERVE BANK OF INDIA")){EmployerCode="AA110";}
		else if(EmployerName.contains("ROBERT BOSCH ENG & BUSINESS SOLUTIONS LIMITED")){EmployerCode="AA111";}
		else if(EmployerName.contains("RR DONNELLEY INDIA OUTSOURCE")){EmployerCode="AA112";}
		else if(EmployerName.contains("SAMSUNG R&D INSTITUTE INDIA - BANGALORE")){EmployerCode="AA113";}
		else if(EmployerName.contains("SAMSUNG INDIA ELECTRONICS")){EmployerCode="AA114";}
		else if(EmployerName.contains("SAP LABS INDIA PRIVATE. LIMITED")){EmployerCode="AA115";}
		else if(EmployerName.contains("SAPIENT CONSULTING")){EmployerCode="AA116";}
		else if(EmployerName.contains("SCHNEIDER ELECTRIC INDIA")){EmployerCode="AA117";}
		else if(EmployerName.contains("SIEMENS LIMITED")){EmployerCode="AA118";}
		else if(EmployerName.contains("SIMPLEX INFRASTRUCTURES LIMITED")){EmployerCode="AA119";}
		else if(EmployerName.contains("SG SOFTWARE ASIA (NOW KNOWN AS SOCIETE GENERALE GLOBAL SOLUTION CENTRE PRIVATE. LIMITED)")){EmployerCode="AA120";}
		else if(EmployerName.contains("SONATA SOFTWARE LIMITED")){EmployerCode="AA121";}
		else if(EmployerName.contains("SPENCER' S RETAIL LIMITED")){EmployerCode="AA122";}
		else if(EmployerName.contains("STANDARD CHARTERED BANK")){EmployerCode="AA123";}
		else if(EmployerName.contains("STATE BANK OF INDIA")){EmployerCode="AA124";}
		else if(EmployerName.contains("STEEL AUTHORITY OF INDIA LIMITED (SAIL)")){EmployerCode="AA125";}
		else if(EmployerName.contains("SUTHERLAND GLOBAL SERVICES")){EmployerCode="AA126";}
		else if(EmployerName.contains("SYNECHRON TECHNOLOGIES")){EmployerCode="AA127";}
		else if(EmployerName.contains("TATA TECHNOLOGIES")){EmployerCode="AA130";}
		else if(EmployerName.contains("TECH MAHINDRA LIMITED")){EmployerCode="AA131";}
		else if(EmployerName.contains("NEW INDIA ASSURANCE CO LIMITED")){EmployerCode="AA132";}
		else if(EmployerName.contains("UCO BANK")){EmployerCode="AA133";}
		else if(EmployerName.contains("UNION BANK OF INDIA")){EmployerCode="AA134";}
		else if(EmployerName.contains("UNITED BANK OF INDIA")){EmployerCode="AA135";}
		else if(EmployerName.contains("UNITED HEALTHGROUP")){EmployerCode="AA136";}
		else if(EmployerName.contains("UST GLOBAL")){EmployerCode="AA138";}
		else if(EmployerName.contains("VODAFONE INDIA SERVICES")){EmployerCode="AA139";}
		else if(EmployerName.contains("WELLS FARGO")){EmployerCode="AA140";}
		else if(EmployerName.contains("WNS GLOBAL SERVICES")){EmployerCode="AA142";}
		else if(EmployerName.contains("YASH TECHNOLOGIES")){EmployerCode="AA144";}
		else if(EmployerName.contains("YES BANK LIMITED")){EmployerCode="AA145";}
		else if(EmployerName.contains("SOUTHERN RAILWAY")){EmployerCode="AA147";}
		else if(EmployerName.contains("VERIZON DATA SERVICES INDIA")){EmployerCode="AA148";}
		else if(EmployerName.contains("INTEL TECHNOLOGY INDIA")){EmployerCode="AA149";}
		else if(EmployerName.contains("FEDERAL BANK LIMITED")){EmployerCode="AA150";}
		else if(EmployerName.contains("CYBAGE SOFTWARE")){EmployerCode="AA159";}
		else if(EmployerName.contains("EMC SOFTWARE AND SERVICES INDIA")){EmployerCode="AA164";}
		else if(EmployerName.contains("ADECCO INDIA")){EmployerCode="AA165";}
		else if(EmployerName.contains("DELOITTE HASKINS & SELLS")){EmployerCode="AA166";}
		else if(EmployerName.contains("HDB FINANCIAL SERVICES LIMITED")){EmployerCode="AA168";}
		else if(EmployerName.contains("INCOME TAX DEPARTMENT")){EmployerCode="AA170";}
		else if(EmployerName.contains("ALL INDIA INSTITUTE OF MEDICAL SCIENCE")){EmployerCode="AA172";}
		else if(EmployerName.contains("AMERICAN EXPRESS I LIMITED")){EmployerCode="AA175";}
		else if(EmployerName.contains("FOOD CORPORATION OF INDIA")){EmployerCode="AA177";}
		else if(EmployerName.contains("KARUR VYSYA BANK")){EmployerCode="AA179";}
		else if(EmployerName.contains("BNY MELLON INTERNATIONAL OPERATIONS INDIA")){EmployerCode="AA184";}
		else if(EmployerName.contains("ALTISOURCE BUSINESS SOLUTIONS")){EmployerCode="AA187";}
		else if(EmployerName.contains("CERNER HEALTHCARE SOLUTIONS")){EmployerCode="AA188";}
		else if(EmployerName.contains("LUPIN LIMITED")){EmployerCode="AA189";}
		else if(EmployerName.contains("RELIANCE INFRASTRUCTURE LIMITED")){EmployerCode="AA190";}
		else if(EmployerName.contains("ALLEN CAREER INSTITUTE")){EmployerCode="AA191";}
		else if(EmployerName.contains("NATIONAL INSURANCE CO LIMITED")){EmployerCode="AA192";}
		else if(EmployerName.contains("INDIAN OVERSEAS BANK")){EmployerCode="AA193";}
		else if(EmployerName.contains("JASPER INFOTECH")){EmployerCode="AA194";}
		else if(EmployerName.contains("GGSSS DIRECTORATE OF EDUCATION")){EmployerCode="AA195";}
		else if(EmployerName.contains("EMPLOYEE STATE INSURANCE CORPORATION")){EmployerCode="AA196";}
		else if(EmployerName.contains("FLEXTRONIC TECHNOLOGIES INDIA")){EmployerCode="AA197";}
		else if(EmployerName.contains("BANK OF INDIA")){EmployerCode="AA198";}
		else if(EmployerName.contains("ALCATEL LUCENT INDIA LIMITED")){EmployerCode="AA199";}
		else if(EmployerName.contains("KPIT TECHNOLOGIES LIMITED")){EmployerCode="AA200";}
		else if(EmployerName.contains("NIIT TECHNOLOGIES LIMITED")){EmployerCode="AA201";}
		else if(EmployerName.contains("CORPORATION BANK")){EmployerCode="AA202";}
		else if(EmployerName.contains("BT E SERV")){EmployerCode="AA203";}
		else if(EmployerName.contains("MINISTRY OF HOME AFFAIRS")){EmployerCode="AA204";}
		else if(EmployerName.contains("RANDSTAD INDIA LIMITED")){EmployerCode="AA206";}
		else if(EmployerName.contains("INDIAN BANK")){EmployerCode="AA207";}
		else if(EmployerName.contains("INFOSYS BPO")){EmployerCode="AA208";}
		else if(EmployerName.contains("AXA BUSINESS SERVICES")){EmployerCode="AA209";}
		else if(EmployerName.contains("FISERV INDIA")){EmployerCode="AA210";}
		else if(EmployerName.contains("PROKARMA SOFTECH PVT LTD")){EmployerCode="AA211";}
		else if(EmployerName.contains("INTERGLOBE AVIATION LIMITED")){EmployerCode="AA212";}
		else if(EmployerName.contains("HSBC SOFTWARE DEVELOPMENT INDIA PRIVATE. LIMITED")){EmployerCode="AA213";}
		else if(EmployerName.contains("BHABHA ATOMIC RESEARCH CENTRE")){EmployerCode="AA214";}
		else if(EmployerName.contains("ENGINEERS INDIA")){EmployerCode="AA215";}
		else if(EmployerName.contains("BRIDGESTONE INDIA")){EmployerCode="AA216";}
		else if(EmployerName.contains("AIRCEL LIMITED")){EmployerCode="AA217";}
		else if(EmployerName.contains("SYNDICATE BANK")){EmployerCode="AA218";}
		else if(EmployerName.contains("HYUNDAI MOTOR INDIA LIMITED")){EmployerCode="AA219";}
		else if(EmployerName.contains("COMPUTER SCIENCE CORP I")){EmployerCode="AA220";}
		else if(EmployerName.contains("BANK OF MAHARASHTRA")){EmployerCode="AA223";}
		else if(EmployerName.contains("TITAN COMPANY LIMITED")){EmployerCode="AA225";}
		else if(EmployerName.contains("CITIBANK")){EmployerCode="AA227";}
		else if(EmployerName.contains("ORIENT CRAFT LIMITED")){EmployerCode="AA231";}
		else if(EmployerName.contains("GENIUS CONSULTANTS LIMITED")){EmployerCode="AA233";}
		else if(EmployerName.contains("BENNETT COLEMAN & CO. LIMITED (TOI)")){EmployerCode="AA234";}
		else if(EmployerName.contains("GE INDIA INDUSTRIAL")){EmployerCode="AA235";}
		else if(EmployerName.contains("RURAL ELECTRIFICATION CORPORATION LIMITED")){EmployerCode="AA236";}
		else if(EmployerName.contains("BECHTEL INDIA")){EmployerCode="AA237";}
		else if(EmployerName.contains("GLENMARK PHARMACEUTICALS LIMITED")){EmployerCode="AA238";}
		else if(EmployerName.contains("NORTH WESTERN RAILWAY")){EmployerCode="AA240";}
		else if(EmployerName.contains("TATA COMMUNICATIONS LIMITED")){EmployerCode="AA241";}
		else if(EmployerName.contains("UFLEX")){EmployerCode="AA242";}
		else if(EmployerName.contains("HDFC STANDARD LIFE INSURANCE COMPANY LIMITED")){EmployerCode="AA243";}
		else if(EmployerName.contains("ADANI ENTERPRISES(FORMERLY ADANI EXPORTS)")){EmployerCode="AA250";}
		else if(EmployerName.contains("LARSEN & TOUBRO INFOTECH LIMITED")){EmployerCode="AA251";}
		else if(EmployerName.contains("RELIANCE JIO INFOCOMM LIMITED")){EmployerCode="AA252";}
		else if(EmployerName.contains("TATA CONSULTANCY LIMITED")){EmployerCode="AA253";}
		else if(EmployerName.contains("RENAULT NISSAN TECHNOLOGY & BUSINESS CENTRE INDIA")){EmployerCode="AA254";}
		else if(EmployerName.contains("AMAZON DEVELOPMENT CENTRE(INDIA) PRIVATE LIMTED")){EmployerCode="AA255";}
		else if(EmployerName.contains("AXIS BANK LIMITED")){EmployerCode="AA256";}
		else if(EmployerName.contains("BARCLAYS SHARED SERVICES")){EmployerCode="AA257";}
		else if(EmployerName.contains("CYIENT LIMITED")){EmployerCode="AA258";}
		else if(EmployerName.contains("IBM INDIA")){EmployerCode="AA259";}
		else if(EmployerName.contains("INFOSYS LIMITED")){EmployerCode="AA260";}
		else if(EmployerName.contains("OTHERS")){EmployerCode="9999";}
		else if(EmployerName.contains("ACCENTURE SERVICES PRIVATE. LIMITED")){EmployerCode="AA001";}
		else if(EmployerName.contains("MAX HYPERMARKET INDIA")){EmployerCode="AA002";}
		else if(EmployerName.contains("HEXAWARE TECH")){EmployerCode="AA003";}
		else if(EmployerName.contains("AAI (AIRPORTS AUTHORITY OF INDIA)")){EmployerCode="AA004";}
		else if(EmployerName.contains("ALLAHABAD BANK")){EmployerCode="AA005";}
		else if(EmployerName.contains("ALLEGIS SERVICE (INDIA)")){EmployerCode="AA006";}
		else if(EmployerName.contains("WIPRO LIMITED")){EmployerCode="AA007";}
		else if(EmployerName.contains("UNITED INDIA INSURANCE CO LIMITED")){EmployerCode="AA008";}
		else if(EmployerName.contains("ITC INFOTECH INDIA LIMITED")){EmployerCode="AA009";}
		else if(EmployerName.contains("ATOS INDIA")){EmployerCode="AA010";}
		else if(EmployerName.contains("AUROBINDO PHARMA LIMITED")){EmployerCode="AA011";}
		else if(EmployerName.contains("ARICENT TECHNOLOGIES (HOLDINGS) LIMITED")){EmployerCode="AA012";}
		else if(EmployerName.contains("BA CONTINUUM INDIA")){EmployerCode="AA013";}
		else if(EmployerName.contains("BANK OF BARODA")){EmployerCode="AA014";}
		else if(EmployerName.contains("HSBC BANK")){EmployerCode="AA015";}
		else if(EmployerName.contains("BHARAT ELECTRONICS LIMITED( CATEGORY IS FOR NON CLERICAL AND OTHER THAN BLUE COLLAR EMPLOYEES)")){EmployerCode="AA016";}
		else if(EmployerName.contains("BHARAT HEAVY ELECTRICALS LIMITED")){EmployerCode="AA017";}
		else if(EmployerName.contains("BHARAT PETROLEUM CORPORATION LIMITED")){EmployerCode="AA018";}
		else if(EmployerName.contains("BHARAT SANCHAR NIGAM LIMITED (BSNL)")){EmployerCode="AA019";}
		else if(EmployerName.contains("BHARTI AIRTEL LIMITED")){EmployerCode="AA020";}
		else if(EmployerName.contains("BOSCH LIMITED")){EmployerCode="AA021";}
		else if(EmployerName.contains("CANARA BANK")){EmployerCode="AA022";}
		else if(EmployerName.contains("CAPGEMINI INDIA")){EmployerCode="AA023";}
		else if(EmployerName.contains("CAPGEMINI TECHNOLOGY SERVICES INDIA LIMITED")){EmployerCode="AA024";}
		else if(EmployerName.contains("CAPGENT TECHNOLOGY")){EmployerCode="AA025";}
		else if(EmployerName.contains("CENTRAL INDUSTRIAL SECURITY FO")){EmployerCode="AA026";}
		else if(EmployerName.contains("CGI INFORMATION SYSTEMS & MANAGEMENT CONSULTANTS")){EmployerCode="AA027";}
		else if(EmployerName.contains("CIPLA LIMITED")){EmployerCode="AA028";}
		else if(EmployerName.contains("CISCO SYSTEMS (INDIA)")){EmployerCode="AA029";}
		else if(EmployerName.contains("AIR FORCE CENTRAL ACCOUNTS OFF")){EmployerCode="AA030";}
		else if(EmployerName.contains("COGNIZANT TECHNOLOGY SOLUTIONS INDIA")){EmployerCode="AA031";}
		else if(EmployerName.contains("AMDOCS DEVELOPMENT CENTRE INDIA PRIVATE.LIMITED")){EmployerCode="AA032";}
		else if(EmployerName.contains("DABUR INDIA LIMITED")){EmployerCode="AA033";}
		else if(EmployerName.contains("DAMODAR VALLEY CORPORATION")){EmployerCode="AA034";}
		else if(EmployerName.contains("DBOI GLOBAL SERVICES")){EmployerCode="AA035";}
		else if(EmployerName.contains("DELHI METRO RAIL CORPORATION")){EmployerCode="AA036";}
		else if(EmployerName.contains("DELL INTERNATIONAL SERVICE LIMITED")){EmployerCode="AA037";}
		else if(EmployerName.contains("DELOITTE CONSULTING INDIA")){EmployerCode="AA038";}
		else if(EmployerName.contains("DR REDDY'S LABORATORIES LIMITED")){EmployerCode="AA039";}
		else if(EmployerName.contains("EIT SERVICES INDIA PRIVATE. LIMITED")){EmployerCode="AA041";}
		else if(EmployerName.contains("ERICSSON INDIA GLOBAL SERVICES")){EmployerCode="AA042";}
		else if(EmployerName.contains("ERNST & YOUNG LLP")){EmployerCode="AA043";}
		else if(EmployerName.contains("EXL SERVICES.COM")){EmployerCode="AA045";}
		else if(EmployerName.contains("FIDELITY INFORMATION SYS CO INDIA")){EmployerCode="AA046";}
		else if(EmployerName.contains("FIS GLOBAL BUSINESS SOLUTION INDIA (EARLIER KNOWN AS EFUNDS INTERNATIONAL INDIA)")){EmployerCode="AA047";}
		else if(EmployerName.contains("FORD INDIA LIMITED")){EmployerCode="AA048";}
		else if(EmployerName.contains("GODREJ AND BOYCE MFG CO LTD")){EmployerCode="AA049";}
		else if(EmployerName.contains("HCL TECHNOLOGIES LIMITED")){EmployerCode="AA050";}
		else if(EmployerName.contains("HP")){EmployerCode="AA052";}
		else if(EmployerName.contains("HINDUSTAN PETROLEUM CORPORATION LIMITED ( HPCL)")){EmployerCode="AA054";}
		else if(EmployerName.contains("HONEYWELL TECHNOLOGY SOLUTIONS LAB")){EmployerCode="AA055";}
		else if(EmployerName.contains("HSBC ELECTRONIC")){EmployerCode="AA058";}
		else if(EmployerName.contains("ICICI BANK")){EmployerCode="AA060";}
		else if(EmployerName.contains("ICICI LOMBARD GENERAL INSURANCE")){EmployerCode="AA061";}
		else if(EmployerName.contains("ICICI PRUDENTIAL LIFE INSURANCE")){EmployerCode="AA062";}
		else if(EmployerName.contains("IDBI BANK LIMITED")){EmployerCode="AA063";}
		else if(EmployerName.contains("IKYA HUMAN CAPITAL SOLUTIONS")){EmployerCode="AA065";}
		else if(EmployerName.contains("INAUTIX TECHNOLOGIES INDIA (P) LIMITED")){EmployerCode="AA066";}
		else if(EmployerName.contains("INDIAN AIR FORCE")){EmployerCode="AA067";}
		else if(EmployerName.contains("INDIAN ARMY")){EmployerCode="AA068";}
		else if(EmployerName.contains("INDIAN NAVY")){EmployerCode="AA069";}
		else if(EmployerName.contains("INDIAN OIL CORPORATION LIMITED")){EmployerCode="AA070";}
		else if(EmployerName.contains("INDUSIND BANK")){EmployerCode="AA071";}
		else if(EmployerName.contains("INTELENET GLOBAL SERVICES")){EmployerCode="AA073";}
		else if(EmployerName.contains("ITC LIMITED")){EmployerCode="AA075";}
		else if(EmployerName.contains("JP MANAGEMENT SERVICES")){EmployerCode="AA076";}
		else if(EmployerName.contains("JET AIRWAYS (I)")){EmployerCode="AA077";}
		else if(EmployerName.contains("KOTAK MAHINDRA BANK")){EmployerCode="AA078";}
		else if(EmployerName.contains("KPMG")){EmployerCode="AA079";}
		else if(EmployerName.contains("LARSEN & TOUBRO LIMITED")){EmployerCode="AA081";}
		else if(EmployerName.contains("LIFE INSURANCE CORPORATION OF INDIA")){EmployerCode="AA082";}
		else if(EmployerName.contains("LIFESTYLE INTERNATIONAL")){EmployerCode="AA083";}
		else if(EmployerName.contains("MAERSK GLOBAL SERVICE CENTRES (INDIA)")){EmployerCode="AA084";}
		else if(EmployerName.contains("MAGNA INFOTECH")){EmployerCode="AA085";}
		else if(EmployerName.contains("MAHINDRA & MAHINDRA LIMITED")){EmployerCode="AA086";}
		else if(EmployerName.contains("MARUTI SUZUKI AUTOMOBILES INDIA LIMITED")){EmployerCode="AA087";}
		else if(EmployerName.contains("MIND TREE LIMITED ( EARLIER KNOWN AS  MINDTREE CONSULTING)")){EmployerCode="AA089";}
		else if(EmployerName.contains("MINSTRY OF DEFENCE")){EmployerCode="AA090";}
		else if(EmployerName.contains("MPHASIS LIMITED")){EmployerCode="AA091";}
		else if(EmployerName.contains("NAVAL PAY OFFICE")){EmployerCode="AA092";}
		else if(EmployerName.contains("NOMURA SERVICES INDIA")){EmployerCode="AA094";}
		else if(EmployerName.contains("NTT DATA GLOBAL DELIVERY SERVICES LIMITED")){EmployerCode="AA096";}
		else if(EmployerName.contains("OIL & NATURAL GAS CORPORATION LIMITED")){EmployerCode="AA097";}
		else if(EmployerName.contains("ORACLE FINANCIAL SERVICES SOFTWARE LIMITED( FORMERLY I-FLEX SOLUTIONS)")){EmployerCode="AA098";}
		else if(EmployerName.contains("ORACLE INDIA")){EmployerCode="AA099";}
		else if(EmployerName.contains("ORIENTAL BANK OF COMMERCE")){EmployerCode="AA100";}
		else if(EmployerName.contains("POWER GRID CORPORATION OF INDIA LIMITED")){EmployerCode="AA101";}
		else if(EmployerName.contains("PRICE WATER HOUSE COOPERS (P) LIMITED")){EmployerCode="AA102";}
		else if(EmployerName.contains("PUNJAB NATIONAL BANK")){EmployerCode="AA103";}
		else if(EmployerName.contains("QUALCOMM")){EmployerCode="AA104";}
		else if(EmployerName.contains("QUINTILES RESEARCH INDIA")){EmployerCode="AA105";}
		else if(EmployerName.contains("RBS SERVICES INDIA")){EmployerCode="AA106";}
		else if(EmployerName.contains("RELIANCE RETAIL LIMITED")){EmployerCode="AA108";}
		else if(EmployerName.contains("RESERVE BANK OF INDIA")){EmployerCode="AA110";}
		else if(EmployerName.contains("ROBERT BOSCH ENG & BUSINESS SOLUTIONS LIMITED")){EmployerCode="AA111";}
		else if(EmployerName.contains("RR DONNELLEY INDIA OUTSOURCE")){EmployerCode="AA112";}
		else if(EmployerName.contains("SAMSUNG R&D INSTITUTE INDIA - BANGALORE")){EmployerCode="AA113";}
		else if(EmployerName.contains("SAMSUNG INDIA ELECTRONICS")){EmployerCode="AA114";}
		else if(EmployerName.contains("SAP LABS INDIA PRIVATE. LIMITED")){EmployerCode="AA115";}
		else if(EmployerName.contains("SAPIENT CONSULTING")){EmployerCode="AA116";}
		else if(EmployerName.contains("SCHNEIDER ELECTRIC INDIA")){EmployerCode="AA117";}
		else if(EmployerName.contains("SIEMENS LIMITED")){EmployerCode="AA118";}
		else if(EmployerName.contains("SIMPLEX INFRASTRUCTURES LIMITED")){EmployerCode="AA119";}
		else if(EmployerName.contains("SG SOFTWARE ASIA (NOW KNOWN AS SOCIETE GENERALE GLOBAL SOLUTION CENTRE PRIVATE. LIMITED)")){EmployerCode="AA120";}
		else if(EmployerName.contains("SONATA SOFTWARE LIMITED")){EmployerCode="AA121";}
		else if(EmployerName.contains("SPENCER' S RETAIL LIMITED")){EmployerCode="AA122";}
		else if(EmployerName.contains("STANDARD CHARTERED BANK")){EmployerCode="AA123";}
		else if(EmployerName.contains("STATE BANK OF INDIA")){EmployerCode="AA124";}
		else if(EmployerName.contains("STEEL AUTHORITY OF INDIA LIMITED (SAIL)")){EmployerCode="AA125";}
		else if(EmployerName.contains("SUTHERLAND GLOBAL SERVICES")){EmployerCode="AA126";}
		else if(EmployerName.contains("SYNECHRON TECHNOLOGIES")){EmployerCode="AA127";}
		else if(EmployerName.contains("TATA TECHNOLOGIES")){EmployerCode="AA130";}
		else if(EmployerName.contains("TECH MAHINDRA LIMITED")){EmployerCode="AA131";}
		else if(EmployerName.contains("NEW INDIA ASSURANCE CO LIMITED")){EmployerCode="AA132";}
		else if(EmployerName.contains("UCO BANK")){EmployerCode="AA133";}
		else if(EmployerName.contains("UNION BANK OF INDIA")){EmployerCode="AA134";}
		else if(EmployerName.contains("UNITED BANK OF INDIA")){EmployerCode="AA135";}
		else if(EmployerName.contains("UNITED HEALTHGROUP")){EmployerCode="AA136";}
		else if(EmployerName.contains("UST GLOBAL")){EmployerCode="AA138";}
		else if(EmployerName.contains("VODAFONE INDIA SERVICES")){EmployerCode="AA139";}
		else if(EmployerName.contains("WELLS FARGO")){EmployerCode="AA140";}
		else if(EmployerName.contains("WNS GLOBAL SERVICES")){EmployerCode="AA142";}
		else if(EmployerName.contains("YASH TECHNOLOGIES")){EmployerCode="AA144";}
		else if(EmployerName.contains("YES BANK LIMITED")){EmployerCode="AA145";}
		else if(EmployerName.contains("SOUTHERN RAILWAY")){EmployerCode="AA147";}
		else if(EmployerName.contains("VERIZON DATA SERVICES INDIA")){EmployerCode="AA148";}
		else if(EmployerName.contains("INTEL TECHNOLOGY INDIA")){EmployerCode="AA149";}
		else if(EmployerName.contains("FEDERAL BANK LIMITED")){EmployerCode="AA150";}
		else if(EmployerName.contains("CYBAGE SOFTWARE")){EmployerCode="AA159";}
		else if(EmployerName.contains("EMC SOFTWARE AND SERVICES INDIA")){EmployerCode="AA164";}
		else if(EmployerName.contains("ADECCO INDIA")){EmployerCode="AA165";}
		else if(EmployerName.contains("DELOITTE HASKINS & SELLS")){EmployerCode="AA166";}
		else if(EmployerName.contains("HDB FINANCIAL SERVICES LIMITED")){EmployerCode="AA168";}
		else if(EmployerName.contains("INCOME TAX DEPARTMENT")){EmployerCode="AA170";}
		else if(EmployerName.contains("ALL INDIA INSTITUTE OF MEDICAL SCIENCE")){EmployerCode="AA172";}
		else if(EmployerName.contains("AMERICAN EXPRESS I LIMITED")){EmployerCode="AA175";}
		else if(EmployerName.contains("FOOD CORPORATION OF INDIA")){EmployerCode="AA177";}
		else if(EmployerName.contains("KARUR VYSYA BANK")){EmployerCode="AA179";}
		else if(EmployerName.contains("BNY MELLON INTERNATIONAL OPERATIONS INDIA")){EmployerCode="AA184";}
		else if(EmployerName.contains("ALTISOURCE BUSINESS SOLUTIONS")){EmployerCode="AA187";}
		else if(EmployerName.contains("CERNER HEALTHCARE SOLUTIONS")){EmployerCode="AA188";}
		else if(EmployerName.contains("LUPIN LIMITED")){EmployerCode="AA189";}
		else if(EmployerName.contains("RELIANCE INFRASTRUCTURE LIMITED")){EmployerCode="AA190";}
		else if(EmployerName.contains("ALLEN CAREER INSTITUTE")){EmployerCode="AA191";}
		else if(EmployerName.contains("NATIONAL INSURANCE CO LIMITED")){EmployerCode="AA192";}
		else if(EmployerName.contains("INDIAN OVERSEAS BANK")){EmployerCode="AA193";}
		else if(EmployerName.contains("JASPER INFOTECH")){EmployerCode="AA194";}
		else if(EmployerName.contains("GGSSS DIRECTORATE OF EDUCATION")){EmployerCode="AA195";}
		else if(EmployerName.contains("EMPLOYEE STATE INSURANCE CORPORATION")){EmployerCode="AA196";}
		else if(EmployerName.contains("FLEXTRONIC TECHNOLOGIES INDIA")){EmployerCode="AA197";}
		else if(EmployerName.contains("BANK OF INDIA")){EmployerCode="AA198";}
		else if(EmployerName.contains("ALCATEL LUCENT INDIA LIMITED")){EmployerCode="AA199";}
		else if(EmployerName.contains("KPIT TECHNOLOGIES LIMITED")){EmployerCode="AA200";}
		else if(EmployerName.contains("NIIT TECHNOLOGIES LIMITED")){EmployerCode="AA201";}
		else if(EmployerName.contains("CORPORATION BANK")){EmployerCode="AA202";}
		else if(EmployerName.contains("BT E SERV")){EmployerCode="AA203";}
		else if(EmployerName.contains("MINISTRY OF HOME AFFAIRS( MHA)")){EmployerCode="AA204";}
		else if(EmployerName.contains("RANDSTAD INDIA LIMITED")){EmployerCode="AA206";}
		else if(EmployerName.contains("INDIAN BANK")){EmployerCode="AA207";}
		else if(EmployerName.contains("INFOSYS BPO")){EmployerCode="AA208";}
		else if(EmployerName.contains("AXA BUSINESS SERVICES")){EmployerCode="AA209";}
		else if(EmployerName.contains("FISERV INDIA")){EmployerCode="AA210";}
		else if(EmployerName.contains("PROKARMA SOFTECH PVT LTD")){EmployerCode="AA211";}
		else if(EmployerName.contains("INTERGLOBE AVIATION LIMITED")){EmployerCode="AA212";}
		else if(EmployerName.contains("HSBC SOFTWARE DEVELOPMENT INDIA PRIVATE. LIMITED")){EmployerCode="AA213";}
		else if(EmployerName.contains("BHABHA ATOMIC RESEARCH CENTRE")){EmployerCode="AA214";}
		else if(EmployerName.contains("ENGINEERS INDIA")){EmployerCode="AA215";}
		else if(EmployerName.contains("BRIDGESTONE INDIA")){EmployerCode="AA216";}
		else if(EmployerName.contains("AIRCEL LIMITED")){EmployerCode="AA217";}
		else if(EmployerName.contains("SYNDICATE BANK")){EmployerCode="AA218";}
		else if(EmployerName.contains("HYUNDAI MOTOR INDIA LIMITED")){EmployerCode="AA219";}
		else if(EmployerName.contains("COMPUTER SCIENCE CORP I")){EmployerCode="AA220";}
		else if(EmployerName.contains("BANK OF MAHARASHTRA")){EmployerCode="AA223";}
		else if(EmployerName.contains("TITAN COMPANY LIMITED")){EmployerCode="AA225";}
		else if(EmployerName.contains("CITIBANK")){EmployerCode="AA227";}
		else if(EmployerName.contains("ORIENT CRAFT LIMITED")){EmployerCode="AA231";}
		else if(EmployerName.contains("GENIUS CONSULTANTS LIMITED")){EmployerCode="AA233";}
		else if(EmployerName.contains("BENNETT COLEMAN & CO. LIMITED (TOI)")){EmployerCode="AA234";}
		else if(EmployerName.contains("GE INDIA INDUSTRIAL")){EmployerCode="AA235";}
		else if(EmployerName.contains("RURAL ELECTRIFICATION CORPORATION LIMITED")){EmployerCode="AA236";}
		else if(EmployerName.contains("BECHTEL INDIA")){EmployerCode="AA237";}
		else if(EmployerName.contains("GLENMARK PHARMACEUTICALS LIMITED")){EmployerCode="AA238";}
		else if(EmployerName.contains("NORTH WESTERN RAILWAY")){EmployerCode="AA240";}
		else if(EmployerName.contains("TATA COMMUNICATIONS LIMITED")){EmployerCode="AA241";}
		else if(EmployerName.contains("UFLEX")){EmployerCode="AA242";}
		else if(EmployerName.contains("HDFC STANDARD LIFE INSURANCE COMPANY LIMITED")){EmployerCode="AA243";}
		else if(EmployerName.contains("ADANI ENTERPRISES(FORMERLY ADANI EXPORTS)")){EmployerCode="AA250";}
		else if(EmployerName.contains("LARSEN & TOUBRO INFOTECH LIMITED")){EmployerCode="AA251";}
		else if(EmployerName.contains("RELIANCE JIO INFOCOMM LIMITED")){EmployerCode="AA252";}
		else if(EmployerName.contains("TATA CONSULTANCY LIMITED")){EmployerCode="AA253";}
		else if(EmployerName.contains("RENAULT NISSAN TECHNOLOGY & BUSINESS CENTRE INDIA")){EmployerCode="AA254";}
		else if(EmployerName.contains("AMAZON DEVELOPMENT CENTRE(INDIA) PRIVATE LIMTED")){EmployerCode="AA255";}
		else if(EmployerName.contains("AXIS BANK LIMITED")){EmployerCode="AA256";}
		else if(EmployerName.contains("BARCLAYS SHARED SERVICES")){EmployerCode="AA257";}
		else if(EmployerName.contains("CYIENT LIMITED")){EmployerCode="AA258";}
		else if(EmployerName.contains("IBM INDIA")){EmployerCode="AA259";}
		else if(EmployerName.contains("INFOSYS LIMITED")){EmployerCode="AA260";}
		else if(EmployerName.contains("OTHERS")){EmployerCode="9999";}
		else if(EmployerName.contains("Hewlett Packard Enterprise Globalsoft")){EmployerCode="AA052";}
		else if(EmployerName.contains("Hewlett Packard Enterprise Globalsoft")){EmployerCode="AA052";}
		else if(EmployerName.contains("TATA CONSULTANCY SERVICES LIMITED")){EmployerCode="AA261";}
		else if(EmployerName.contains("TATA CONSULTANCY SERVICES LIMITED")){EmployerCode="AA261";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: TaxResidencyStatusCode = ("+EmployerName+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return EmployerCode;
	}


	public static String ProfessionCode(String DBProfessionCode) {
		String Profession=""+DBUtils.readColumnWithRowIDNew(DBProfessionCode, GetCase.scenarioID);
		String ProfessionCode="";
		if(Profession.contains("CAR,BOAT,PLANE DEALER-DIR/D HD")){ProfessionCode="673";}
		else if(Profession.contains("PAWN BROKERS-STAFF")){ProfessionCode="672";}
		else if(Profession.contains("PAWN BROKERS-MGR/SUPERVISOR")){ProfessionCode="671";}
		else if(Profession.contains("PAWN BROKERS-DIR/DEPT HEAD")){ProfessionCode="670";}
		else if(Profession.contains("AUCTIONEERS-STAFF")){ProfessionCode="669";}
		else if(Profession.contains("AUCTIONEERS-MGR/SUPERVISOR")){ProfessionCode="668";}
		else if(Profession.contains("AUCTIONEERS-DIRECTOR/DEPT HEAD")){ProfessionCode="667";}
		else if(Profession.contains("ART/DESIGN-STAFF")){ProfessionCode="666";}
		else if(Profession.contains("ART/DESIGN-MGR/SUPERVISOR")){ProfessionCode="665";}
		else if(Profession.contains("MANUFACTURING-MGR/SUPERVISOR")){ProfessionCode="636";}
		else if(Profession.contains("MANUFACTURING-DIR/DEPT HEAD")){ProfessionCode="635";}
		else if(Profession.contains("CONSTRUCTION-STAFF")){ProfessionCode="634";}
		else if(Profession.contains("CONSTRUCTION-MGR/SUPERVISOR")){ProfessionCode="633";}
		else if(Profession.contains("CONSTRUCTION-DIR/DEPT HEAD")){ProfessionCode="632";}
		else if(Profession.contains("SECRETARIAL FIRM-STAFF")){ProfessionCode="631";}
		else if(Profession.contains("SECRETARIAL FIRM-MGR/SUPVSR")){ProfessionCode="630";}
		else if(Profession.contains("SECRETARIAL FIRM-DIR/DEPT HEAD")){ProfessionCode="629";}
		else if(Profession.contains("BROKERS/DEALERS-STAFF")){ProfessionCode="628";}
		else if(Profession.contains("BROKERS/DEALERS-MGR/SUPERVISOR")){ProfessionCode="627";}
		else if(Profession.contains("BROKERS/DEALERS-DIR/DEPT HEAD")){ProfessionCode="626";}
		else if(Profession.contains("FINANCIAL INST-STAFF")){ProfessionCode="625";}
		else if(Profession.contains("FINANCIAL INST-MGR/SUPERVISOR")){ProfessionCode="624";}
		else if(Profession.contains("FINANCIAL INST-DIR/DEPT HEAD")){ProfessionCode="623";}
		else if(Profession.contains("FINANCIAL INST-OWNER")){ProfessionCode="622";}
		else if(Profession.contains("MEDICAL/HEALTH-STAFF")){ProfessionCode="621";}
		else if(Profession.contains("MEDICAL/HEALTH-NURSE")){ProfessionCode="620";}
		else if(Profession.contains("MEDICAL/HEALTH-DR, DENTIST")){ProfessionCode="619";}
		else if(Profession.contains("MEDICAL/HEALTH-OWNER")){ProfessionCode="618";}
		else if(Profession.contains("ART/DESIGN-DIR/DEPT HEAD")){ProfessionCode="664";}
		else if(Profession.contains("ART/DESIGN-OWNER")){ProfessionCode="663";}
		else if(Profession.contains("PUBLIC UTILITY-STAFF")){ProfessionCode="662";}
		else if(Profession.contains("PUBLIC UTILITY-MGR/SUPERVISOR")){ProfessionCode="661";}
		else if(Profession.contains("PUBLIC UTILITY-DIR/DEPT HEAD")){ProfessionCode="660";}
		else if(Profession.contains("COMPUTER-STAFF")){ProfessionCode="659";}
		else if(Profession.contains("NOT CLASSIFIED")){ProfessionCode="707";}
		else if(Profession.contains("UNEMPLOYED")){ProfessionCode="706";}
		else if(Profession.contains("HOUSEWIFE")){ProfessionCode="705";}
		else if(Profession.contains("STUDENT")){ProfessionCode="704";}
		else if(Profession.contains("RETIRED")){ProfessionCode="703";}
		else if(Profession.contains("SELF-EMPLOYED SHOP OWNER , PROPRIETOR")){ProfessionCode="702";}
		else if(Profession.contains("DISCIPLINARY / PROTECTIVE SERVICES")){ProfessionCode="701";}
		else if(Profession.contains("SKILLED BLUE COLLAR")){ProfessionCode="700";}
		else if(Profession.contains("SKILLED WHITE COLLAR / SUPERVISORY LEVEL")){ProfessionCode="699";}
		else if(Profession.contains("ADMINISTRATIVE / MANAGERIAL")){ProfessionCode="698";}
		else if(Profession.contains("OTHS/UNCLASSIFIED-STF/LOW INCM")){ProfessionCode="697";}
		else if(Profession.contains("OTHS/UNCLASSIFIED-MGR/SUPVSR")){ProfessionCode="696";}
		else if(Profession.contains("OTHS/UNCLASSIFIED-DIR/DEPT HD")){ProfessionCode="695";}
		else if(Profession.contains("OTHS/UNCLASSIFIED-OWNER")){ProfessionCode="694";}
		else if(Profession.contains("NON-PROFIT ORG-STAFF")){ProfessionCode="693";}
		else if(Profession.contains("NON-PROFIT ORG-SECRETARY")){ProfessionCode="692";}
		else if(Profession.contains("NON-PROFIT ORG-TREASURER")){ProfessionCode="691";}
		else if(Profession.contains("NON-PROFIT ORG-CHAIRMAN")){ProfessionCode="690";}
		else if(Profession.contains("EMBASSY-STAFF")){ProfessionCode="689";}
		else if(Profession.contains("EMBASSY-MGR/SUPERVISOR")){ProfessionCode="688";}
		else if(Profession.contains("EMBASSY-DIRECTOR/DEPT HEAD")){ProfessionCode="687";}
		else if(Profession.contains("ANTIQUE/ART DEALER-STAFF")){ProfessionCode="686";}
		else if(Profession.contains("ANTIQUE/ART DEALER-MGR/SUPVR")){ProfessionCode="685";}
		else if(Profession.contains("ANTIQUE/ART DEALER-DIR/DEPT HD")){ProfessionCode="684";}
		else if(Profession.contains("ANTIQUE/ART DEALER-OWNER")){ProfessionCode="683";}
		else if(Profession.contains("JEWEL,PRECIOUS MTL DEALERS-STF")){ProfessionCode="682";}
		else if(Profession.contains("JEWEL,PRECIOUS MTL DEALERS-SUP")){ProfessionCode="681";}
		else if(Profession.contains("JEWEL,PRECIOUS MTL DEALERS-DIR")){ProfessionCode="680";}
		else if(Profession.contains("JEWEL,PRECIOUS MTL DEALERS-OWN")){ProfessionCode="679";}
		else if(Profession.contains("USED AUTOMOBILE DEALERS-STAFF")){ProfessionCode="678";}
		else if(Profession.contains("USED AUTOMOBILE DEALERS-MGR/SP")){ProfessionCode="677";}
		else if(Profession.contains("USED AUTOMOBILE DEALERS-DIR")){ProfessionCode="676";}
		else if(Profession.contains("CAR,BOAT,PLANE DEALER-STAFF")){ProfessionCode="675";}
		else if(Profession.contains("CAR,BOAT,PLANE DEALER-MGR/SPVR")){ProfessionCode="674";}
		else if(Profession.contains("Minor")){ProfessionCode="MIN";}
		else if(Profession.contains("OCCUPATIONS IN RELIGION AND THEOLOGY")){ProfessionCode="544";}
		else if(Profession.contains("SALES OCCUPATION, CONSUMABLE COMMODITIES")){ProfessionCode="545";}
		else if(Profession.contains("MONEY CHANGER-MGR/SUPERVISOR")){ProfessionCode="547";}
		else if(Profession.contains("MONEY CHANGER-STAFF")){ProfessionCode="548";}
		else if(Profession.contains("REMITTANCE AGENT-DIR/DEPT HEAD")){ProfessionCode="549";}
		else if(Profession.contains("REMITTANCE AGENT-MGR/SUPVR")){ProfessionCode="550";}
		else if(Profession.contains("REMITTANCE AGENT-STAFF")){ProfessionCode="551";}
		else if(Profession.contains("CASINO/GAMBLING-OWNER")){ProfessionCode="552";}
		else if(Profession.contains("CASINO/GAMBLING-DIR/DEPT HEAD")){ProfessionCode="553";}
		else if(Profession.contains("CASINO/GAMBLING-MGR/SUPERVISOR")){ProfessionCode="554";}
		else if(Profession.contains("CASINO/GAMBLING-STAFF")){ProfessionCode="555";}
		else if(Profession.contains("MANU OF ARMAMENT-DIR/DEPT HEAD")){ProfessionCode="556";}
		else if(Profession.contains("COMPUTER-MGR/SUPERVISOR")){ProfessionCode="658";}
		else if(Profession.contains("MANU OF ARMAMENT-MGR/SUPVR")){ProfessionCode="557";}
		else if(Profession.contains("MANU OF ARMAMENT-STAFF")){ProfessionCode="558";}
		else if(Profession.contains("DEALING OF ARMAMENT-DIR/DPT HD")){ProfessionCode="559";}
		else if(Profession.contains("DEALING OF ARMAMENT-MGR/SUPVR")){ProfessionCode="560";}
		else if(Profession.contains("DEALING OF ARMAMENT-STAFF")){ProfessionCode="561";}
		else if(Profession.contains("NON-INCOME EARNER-HOUSEWIFE")){ProfessionCode="562";}
		else if(Profession.contains("NON-INCOME EARNER-STUDENT")){ProfessionCode="563";}
		else if(Profession.contains("NON-INCOME EARNER-UNEMPLOYED")){ProfessionCode="564";}
		else if(Profession.contains("CIVIL SER-DISCIP-PLCY BUREAU S")){ProfessionCode="565";}
		else if(Profession.contains("CIVIL SER-DISCIP-INSPECTOR")){ProfessionCode="566";}
		else if(Profession.contains("CIVIL SER-DISCIP-OFFICER")){ProfessionCode="567";}
		else if(Profession.contains("CIVIL SER-DISCIP-STAFF")){ProfessionCode="568";}
		else if(Profession.contains("CIVIL SER-NON DISC-CF EX,PER S")){ProfessionCode="569";}
		else if(Profession.contains("CIVIL SER-NON DISC-DIR/DPT HD")){ProfessionCode="570";}
		else if(Profession.contains("CIVIL SER-NON DISC-MGR/SUPVR")){ProfessionCode="571";}
		else if(Profession.contains("CIVIL SER-NON DISC-STAFF")){ProfessionCode="572";}
		else if(Profession.contains("REAL ESTATE AGENT-DIR/DEPT HD")){ProfessionCode="573";}
		else if(Profession.contains("REAL ESTATE AGENT-MGR/SUPVR")){ProfessionCode="574";}
		else if(Profession.contains("Non-income earner-Retired")){ProfessionCode="110";}
		else if(Profession.contains("Real estate agent-Owner")){ProfessionCode="140";}
		else if(Profession.contains("Travel agencies-Owner")){ProfessionCode="150";}
		else if(Profession.contains("Import/export co-Owner")){ProfessionCode="160";}
		else if(Profession.contains("Restaurants-Owner")){ProfessionCode="170";}
		else if(Profession.contains("Retail Stores-Owner")){ProfessionCode="180";}
		else if(Profession.contains("Accounting-Owner, Partner")){ProfessionCode="230";}
		else if(Profession.contains("REAL ESTATE AGENT-STAFF")){ProfessionCode="575";}
		else if(Profession.contains("Transportation-Owner")){ProfessionCode="250";}
		else if(Profession.contains("Insurance-Owner")){ProfessionCode="260";}
		else if(Profession.contains("Education-Owner")){ProfessionCode="270";}
		else if(Profession.contains("TRAVEL AGENCIES-DIR/DEPT HEAD")){ProfessionCode="576";}
		else if(Profession.contains("TRAVEL AGENCIES-MGR/SUPERVISOR")){ProfessionCode="577";}
		else if(Profession.contains("Brokers/dealers-Owner")){ProfessionCode="300";}
		else if(Profession.contains("Parking Garages-Owner")){ProfessionCode="190";}
		else if(Profession.contains("TRAVEL AGENCIES-STAFF")){ProfessionCode="578";}
		else if(Profession.contains("Security guard -Owner")){ProfessionCode="210";}
		else if(Profession.contains("Manufacturing-Owner")){ProfessionCode="330";}
		else if(Profession.contains("IMPORT/EXPORT CO-DIR/DEPT HEAD")){ProfessionCode="579";}
		else if(Profession.contains("IMPORT/EXPORT CO-MGR/SUPVSR")){ProfessionCode="580";}
		else if(Profession.contains("Telecommunication-Owner")){ProfessionCode="370";}
		else if(Profession.contains("IMPORT/EXPORT CO-STAFF")){ProfessionCode="581";}
		else if(Profession.contains("Computer-Owner")){ProfessionCode="390";}
		else if(Profession.contains("Public utility-Owner")){ProfessionCode="400";}
		else if(Profession.contains("RESTAURANTS-DIRECTOR/DEPT HEAD")){ProfessionCode="582";}
		else if(Profession.contains("Secretarial firm-Owner")){ProfessionCode="310";}
		else if(Profession.contains("Construction-Owner")){ProfessionCode="320";}
		else if(Profession.contains("Auctioneers-Owner")){ProfessionCode="420";}
		else if(Profession.contains("Pawn brokers-Owner")){ProfessionCode="430";}
		else if(Profession.contains("Car,boat,plane dealer-Owner")){ProfessionCode="440";}
		else if(Profession.contains("Used automobile dealers-Owner")){ProfessionCode="450";}
		else if(Profession.contains("RESTAURANTS-MGR/SUPERVISOR")){ProfessionCode="583";}
		else if(Profession.contains("RESTAURANTS-STAFF")){ProfessionCode="584";}
		else if(Profession.contains("Embassy-Consulate")){ProfessionCode="480";}
		else if(Profession.contains("RETAIL STORES-DIR/DEPT HEAD")){ProfessionCode="585";}
		else if(Profession.contains("OCCUPATIONS IN MUSEUM, LIBRARY, ARCH. SC")){ProfessionCode="504";}
		else if(Profession.contains("OCCUPATIONS IN WRITING")){ProfessionCode="505";}
		else if(Profession.contains("STENOGRAPHY, TYPING, FILING, REL. OCCUP.")){ProfessionCode="506";}
		else if(Profession.contains("PRODUCTION AND STOCK CLERKS/REL. OCCUPAT")){ProfessionCode="507";}
		else if(Profession.contains("LODGING AND RELATED SVC OCCUPATION")){ProfessionCode="509";}
		else if(Profession.contains("MISC AGRICULTURAL AND RELATED OCCUPATION")){ProfessionCode="510";}
		else if(Profession.contains("OCCUPATIONS IN PROCESSING OF METAL")){ProfessionCode="511";}
		else if(Profession.contains("OCCUP. IN PROCESS. OF PAPER AND REL/PROD")){ProfessionCode="512";}
		else if(Profession.contains("PROCESS. OF PETRO.,COAL,NAT/MFG GAS")){ProfessionCode="513";}
		else if(Profession.contains("OCCUPATIONS IN GRAPHIC ART WORK")){ProfessionCode="520";}
		else if(Profession.contains("UNSKILLED WHITE COLLAR")){ProfessionCode="522";}
		else if(Profession.contains("UNSKILLED BLUE COLLAR")){ProfessionCode="523";}
		else if(Profession.contains("SERVICE INDUSTRIES")){ProfessionCode="524";}
		else if(Profession.contains("AGRICULTURE / FISHERMAN / FORESTRY")){ProfessionCode="525";}
		else if(Profession.contains("FOOD AND BEV.  PREP AND SVC. OCCUPATION")){ProfessionCode="530";}
		else if(Profession.contains("PROFESSIONAL")){ProfessionCode="543";}
		else if(Profession.contains("PROCESS. OF CHEM.PLASTIC,SYN.,RUB,PAINT")){ProfessionCode="514";}
		else if(Profession.contains("OC.IN PROCESS.OF STONE,CLAY,GLASS R/PROD")){ProfessionCode="515";}
		else if(Profession.contains("OC.IN PROCESS.OF LEATHER,TEXTILE R/PROD")){ProfessionCode="516";}
		else if(Profession.contains("PRINTING OCCUPATIONS")){ProfessionCode="517";}
		else if(Profession.contains("TEXTILE OCCUPATIONS")){ProfessionCode="518";}
		else if(Profession.contains("PACKAGING AND MATERIALS HANDLING OCCUPAT")){ProfessionCode="519";}
		else if(Profession.contains("Money changer-Owner")){ProfessionCode="10";}
		else if(Profession.contains("Remittance agent-Owner")){ProfessionCode="20";}
		else if(Profession.contains("LEGAL SERVICE-LAWYER,LGL CONST")){ProfessionCode="600";}
		else if(Profession.contains("Manu of armament-Owner")){ProfessionCode="40";}
		else if(Profession.contains("Dealing of armament-Owner")){ProfessionCode="50";}
		else if(Profession.contains("Unwilling to disclose")){ProfessionCode="60";}
		else if(Profession.contains("LEGAL SERVICE-STAFF")){ProfessionCode="601";}
		else if(Profession.contains("ACCOUNTING-SENIOR MANAGER")){ProfessionCode="602";}
		else if(Profession.contains("ACCOUNTING-ACCOUNTANT")){ProfessionCode="603";}
		else if(Profession.contains("ACCOUNTING-STAFF")){ProfessionCode="604";}
		else if(Profession.contains("ENTERTAINMENT-OWNER")){ProfessionCode="605";}
		else if(Profession.contains("ENTERTAINMENT-ENTERTAINER")){ProfessionCode="606";}
		else if(Profession.contains("ENTERTAINMENT-PB RELATIONS")){ProfessionCode="607";}
		else if(Profession.contains("ENTERTAINMENT-STAFF")){ProfessionCode="608";}
		else if(Profession.contains("TRANSPORTATION-DIR/DEPT HEAD")){ProfessionCode="609";}
		else if(Profession.contains("TRANSPORTATION-MGR/SUPERVISOR")){ProfessionCode="610";}
		else if(Profession.contains("TRANSPORTATION-STAFF")){ProfessionCode="611";}
		else if(Profession.contains("INSURANCE-DIRECTOR/DEPT HEAD")){ProfessionCode="612";}
		else if(Profession.contains("INSURANCE-MGR/SUPERVISOR")){ProfessionCode="613";}
		else if(Profession.contains("INSURANCE-STAFF")){ProfessionCode="614";}
		else if(Profession.contains("EDUCATION-PROFESSOR, LECTURER")){ProfessionCode="615";}
		else if(Profession.contains("EDUCATION-PRINCIPAL, TEACHER")){ProfessionCode="616";}
		else if(Profession.contains("EDUCATION-STAFF")){ProfessionCode="617";}
		else if(Profession.contains("RETAIL STORES-MGR/SUPERVISOR")){ProfessionCode="586";}
		else if(Profession.contains("RETAIL STORES-STAFF")){ProfessionCode="587";}
		else if(Profession.contains("PARKING GARAGES-DIR/DEPT HEAD")){ProfessionCode="588";}
		else if(Profession.contains("PARKING GARAGES-MGR/SUPERVISOR")){ProfessionCode="589";}
		else if(Profession.contains("PARKING GARAGES-STAFF")){ProfessionCode="590";}
		else if(Profession.contains("SALON/BEAUTY-OWNER")){ProfessionCode="591";}
		else if(Profession.contains("SALON/BEAUTY-DIR/DEPT HEAD")){ProfessionCode="592";}
		else if(Profession.contains("SALON/BEAUTY-MGR/SUPERVISOR")){ProfessionCode="593";}
		else if(Profession.contains("SALON/BEAUTY-STAFF")){ProfessionCode="594";}
		else if(Profession.contains("SECURITY GUARD -DIR/DEPT HEAD")){ProfessionCode="595";}
		else if(Profession.contains("SECURITY GUARD -MGR/SUPERVISOR")){ProfessionCode="596";}
		else if(Profession.contains("SECURITY GUARD -STAFF")){ProfessionCode="597";}
		else if(Profession.contains("LEGAL SERVICE-OWNER, PARTNER")){ProfessionCode="598";}
		else if(Profession.contains("LEGAL SERVICE-JUDGE,PROSECUTOR")){ProfessionCode="599";}
		else if(Profession.contains("MANUFACTURING-STAFF")){ProfessionCode="637";}
		else if(Profession.contains("ENGINEERING/CRAFTMAN-OWNER")){ProfessionCode="638";}
		else if(Profession.contains("ENGINEERING/CRAFTMAN-DIR/DP HD")){ProfessionCode="639";}
		else if(Profession.contains("ENGINEERING/CRAFTMAN-MGR/SUPVR")){ProfessionCode="640";}
		else if(Profession.contains("ENGINEERING/CRAFTMAN-STAFF")){ProfessionCode="641";}
		else if(Profession.contains("ARCHITECTURAL/SURVEYING-OWNER")){ProfessionCode="642";}
		else if(Profession.contains("ARCHITECTURAL/SURVEYING-ARCH")){ProfessionCode="643";}
		else if(Profession.contains("ARCHITECTURAL/SURVEYING-SURVYR")){ProfessionCode="644";}
		else if(Profession.contains("ARCHITECTURAL/SURVEYING-STAFF")){ProfessionCode="645";}
		else if(Profession.contains("HOTEL-OWNER")){ProfessionCode="646";}
		else if(Profession.contains("HOTEL-DIRECTOR/DEPT HEAD")){ProfessionCode="647";}
		else if(Profession.contains("HOTEL-MGR/SUPERVISOR")){ProfessionCode="648";}
		else if(Profession.contains("HOTEL-STAFF")){ProfessionCode="649";}
		else if(Profession.contains("TELECOMMUNICATION-DIR/DEPT HD")){ProfessionCode="650";}
		else if(Profession.contains("TELECOMMUNICATION-MGR/SUPVSR")){ProfessionCode="651";}
		else if(Profession.contains("TELECOMMUNICATION-STAFF")){ProfessionCode="652";}
		else if(Profession.contains("MEDIA/PUBLISHING-OWNER")){ProfessionCode="653";}
		else if(Profession.contains("MEDIA/PUBLISHING-DIR/DEPT HD")){ProfessionCode="654";}
		else if(Profession.contains("MEDIA/PUBLISHING-MGR/SUPVSR")){ProfessionCode="655";}
		else if(Profession.contains("MEDIA/PUBLISHING-STAFF")){ProfessionCode="656";}
		else if(Profession.contains("COMPUTER-DIRECTOR/DEPT HEAD")){ProfessionCode="657";}
		else if(Profession.contains("DIRECTOR/OWNER OF HIGH RISK BUSINESS")){ProfessionCode="HR1";}
		else if(Profession.contains("DIRECTOR/OWNER OF A GAMBLING-RELATED BUSINESS")){ProfessionCode="HR2";}
		else if(Profession.contains("DIRECTOR/OWNER OF AN ARMS-RELATED BUSINESS")){ProfessionCode="HR3";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Profession = ("+Profession+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");ProfessionCode=Profession;}

		return ProfessionCode;
	}

	public static String ProfessionCodeNew(String DBProfessionCode)
	{

		String Profession=DBUtils.readColumnWithRowIDNew(DBProfessionCode, GetCase.scenarioID);
		String ProfessionCode="";

		if(Profession.equalsIgnoreCase("Medical Officer") || Profession.contains("Medical Officer")){ProfessionCode="001";}
		else if(Profession.equalsIgnoreCase("Judge/Lawyer/Barrister/Solicitor") || Profession.contains("Judge/Lawyer/Barrister/Solicitor")){ProfessionCode="002";}
		else if(Profession.equalsIgnoreCase("Chartered Architect") || Profession.contains("Chartered Architect")){ProfessionCode="003";}
		else if(Profession.equalsIgnoreCase("Pilot/ Aircraft Captain/ Ship Captain") || Profession.contains("Pilot/ Aircraft Captain/ Ship Captain")){ProfessionCode="005";}
		else if(Profession.equalsIgnoreCase("SCB Staff") || Profession.contains("SCB Staff")){ProfessionCode="007";}
		else if(Profession.equalsIgnoreCase("Chartered Surveyor/Surveyor/Valuer") || Profession.contains("Chartered Surveyor/Surveyor/Valuer")){ProfessionCode="008";}
		else if(Profession.equalsIgnoreCase("CONSULATE/COUNCIL MEMBER") || Profession.contains("CONSULATE/COUNCIL MEMBER")){ProfessionCode="009";}
		else if(Profession.equalsIgnoreCase("CONSULATE/COUNCIL MEMBER") || Profession.contains("CONSULATE/COUNCIL MEMBER")){ProfessionCode="009";}
		else if(Profession.equalsIgnoreCase("CONSULATE/COUNCIL MEMBER") || Profession.contains("CONSULATE/COUNCIL MEMBER")){ProfessionCode="009";}
		else if(Profession.equalsIgnoreCase("CONSULATE/COUNCIL MEMBER") || Profession.contains("CONSULATE/COUNCIL MEMBER")){ProfessionCode="009";}
		else if(Profession.equalsIgnoreCase("Doctor/Dentist/Medical & Healthcare Specialist") || Profession.contains("Doctor/Dentist/Medical & Healthcare Specialist")){ProfessionCode="010";}
		else if(Profession.equalsIgnoreCase("Chartered Accountant") || Profession.contains("Chartered Accountant")){ProfessionCode="011";}
		else if(Profession.equalsIgnoreCase("Chartered Engineer/Engineer") || Profession.contains("Chartered Engineer/Engineer")){ProfessionCode="013";}
		else if(Profession.equalsIgnoreCase("Director/President/ Chairman/ Chief Executive Officer") || Profession.contains("Director/President/ Chairman/ Chief Executive Officer")){ProfessionCode="015";}
		else if(Profession.equalsIgnoreCase("Nurse") || Profession.contains("Nurse")){ProfessionCode="016";}
		else if(Profession.equalsIgnoreCase("Telephone Operater") || Profession.contains("Telephone Operater")){ProfessionCode="017";}
		else if(Profession.equalsIgnoreCase("Lecturer/Professor/Headmaster/Principal") || Profession.contains("Lecturer/Professor/Headmaster/Principal")){ProfessionCode="019";}
		else if(Profession.equalsIgnoreCase("Electrician/ Technician/ Mechanic/Artison") || Profession.contains("Electrician/ Technician/ Mechanic/Artison")){ProfessionCode="021";}
		else if(Profession.equalsIgnoreCase("Computer PROGRAMMER/System ANALYST/System ENGINEER") || Profession.contains("Computer PROGRAMMER/System ANALYST/System ENGINEER")){ProfessionCode="022";}
		else if(Profession.equalsIgnoreCase("Optician/Pharmacist/Laboratory Operator/Radiographier/Chemist") || Profession.contains("Optician/Pharmacist/Laboratory Operator/Radiographier/Chemist")){ProfessionCode="023";}
		else if(Profession.equalsIgnoreCase("Reportor/ Editor/ Journalist/ Translator") || Profession.contains("Reportor/ Editor/ Journalist/ Translator")){ProfessionCode="024";}
		else if(Profession.equalsIgnoreCase("Social Worker") || Profession.contains("Social Worker")){ProfessionCode="026";}
		else if(Profession.equalsIgnoreCase("Domestic Helper") || Profession.contains("Domestic Helper")){ProfessionCode="027";}
		else if(Profession.equalsIgnoreCase("BUYER/PURCHASER/MERCHANDISER") || Profession.contains("BUYER/PURCHASER/MERCHANDISER")){ProfessionCode="029";}
		else if(Profession.equalsIgnoreCase("Computer Operater") || Profession.contains("Computer Operater")){ProfessionCode="030";}
		else if(Profession.equalsIgnoreCase("Retail Sales Person/Promoter") || Profession.contains("Retail Sales Person/Promoter")){ProfessionCode="032";}
		else if(Profession.equalsIgnoreCase("Outdoor Worker/Site Foreman/ Site Worker") || Profession.contains("Outdoor Worker/Site Foreman/ Site Worker")){ProfessionCode="033";}
		else if(Profession.equalsIgnoreCase("Teacher Kindergarden/Primary & Secondary School/Tutorial Class") || Profession.contains("Teacher Kindergarden/Primary & Secondary School/Tutorial Class")){ProfessionCode="034";}
		else if(Profession.equalsIgnoreCase("Life Guard") || Profession.contains("Life Guard")){ProfessionCode="035";}
		else if(Profession.equalsIgnoreCase("Leverler/ Construction Worker/ Contractor / Sub Contractor") || Profession.contains("Leverler/ Construction Worker/ Contractor / Sub Contractor")){ProfessionCode="036";}
		else if(Profession.equalsIgnoreCase("Security Guard/ Building Attendent/ Watchman") || Profession.contains("Security Guard/ Building Attendent/ Watchman")){ProfessionCode="037";}
		else if(Profession.equalsIgnoreCase("Beauty Consultant/ Hair Stylist") || Profession.contains("Beauty Consultant/ Hair Stylist")){ProfessionCode="038";}
		else if(Profession.equalsIgnoreCase("Industrial Quality Control Staff/ Warehouse Worker/ Industrial Worker") || Profession.contains("Industrial Quality Control Staff/ Warehouse Worker/ Industrial Worker")){ProfessionCode="043";}
		else if(Profession.equalsIgnoreCase("Industrial Foreman/Line Leader") || Profession.contains("Industrial Foreman/Line Leader")){ProfessionCode="044";}
		else if(Profession.equalsIgnoreCase("CIVIL SERVANT (Non Civil Service/Contract)") || Profession.contains("CIVIL SERVANT (Non Civil Service/Contract)")){ProfessionCode="045";}
		else if(Profession.equalsIgnoreCase("Designer/Draftman") || Profession.contains("Designer/Draftman")){ProfessionCode="047";}
		else if(Profession.equalsIgnoreCase("Artist/Actor/Entertainer/Model") || Profession.contains("Artist/Actor/Entertainer/Model")){ProfessionCode="048";}
		else if(Profession.equalsIgnoreCase("Film Producer/ Film Director/Camera Man/ Light Board Operator/Backstage Staff/Photographer") || Profession.contains("Film Producer/ Film Director/Camera Man/ Light Board Operator/Backstage Staff/Photographer")){ProfessionCode="049";}
		else if(Profession.equalsIgnoreCase("Cabin Crew/Gound Staff") || Profession.contains("Cabin Crew/Gound Staff")){ProfessionCode="051";}
		else if(Profession.equalsIgnoreCase("Marketing Executive") || Profession.contains("Marketing Executive")){ProfessionCode="060";}
		else if(Profession.equalsIgnoreCase("Taxi Driver/ Minibus Driver") || Profession.contains("Taxi Driver/ Minibus Driver")){ProfessionCode="061";}
		else if(Profession.equalsIgnoreCase("Cashier") || Profession.contains("Cashier")){ProfessionCode="064";}
		else if(Profession.equalsIgnoreCase("Money Transmition Agent/ Foreign Currency Exchange Agent/ Cheque Chashing Agent") || Profession.contains("Money Transmition Agent/ Foreign Currency Exchange Agent/ Cheque Chashing Agent")){ProfessionCode="071";}
		else if(Profession.equalsIgnoreCase("Insurance Agent/ Insurance Broker/ Insurance Sales") || Profession.contains("Insurance Agent/ Insurance Broker/ Insurance Sales")){ProfessionCode="072";}
		else if(Profession.equalsIgnoreCase("CIVIL SERVANT (Civil Service Gov't Disciplinary)") || Profession.contains("CIVIL SERVANT (Civil Service Gov't Disciplinary)")){ProfessionCode="073";}
		else if(Profession.equalsIgnoreCase("CIVIL SERVANT (Civil Service Non Gov't Disciplinary)") || Profession.contains("CIVIL SERVANT (Civil Service Non Gov't Disciplinary)")){ProfessionCode="074";}
		else if(Profession.equalsIgnoreCase("Stock Broker/ Stock Dealer") || Profession.contains("Stock Broker/ Stock Dealer")){ProfessionCode="075";}
		else if(Profession.equalsIgnoreCase("Delivery Worker/Courier/Driver/Transportation Worker") || Profession.contains("Delivery Worker/Courier/Driver/Transportation Worker")){ProfessionCode="076";}
		else if(Profession.equalsIgnoreCase("Property Negotiator/Real Estate Agent") || Profession.contains("Property Negotiator/Real Estate Agent")){ProfessionCode="077";}
		else if(Profession.equalsIgnoreCase("Waiter/Waitress/Captian/Bartender") || Profession.contains("Waiter/Waitress/Captian/Bartender")){ProfessionCode="079";}
		else if(Profession.equalsIgnoreCase("Personal Financial Consultant/ Investment Consultant/Relationship Officer/Sales Representative") || Profession.contains("Personal Financial Consultant/ Investment Consultant/Relationship Officer/Sales Representative")){ProfessionCode="080";}
		else if(Profession.equalsIgnoreCase("Litigation Cleck/Legal Clerk") || Profession.contains("Litigation Cleck/Legal Clerk")){ProfessionCode="081";}
		else if(Profession.equalsIgnoreCase("Private Tutorial") || Profession.contains("Private Tutorial")){ProfessionCode="084";}
		else if(Profession.equalsIgnoreCase("Tourist Guide/Travel Agent") || Profession.contains("Tourist Guide/Travel Agent")){ProfessionCode="087";}
		else if(Profession.equalsIgnoreCase("Indoor Worker") || Profession.contains("Indoor Worker")){ProfessionCode="088";}
		else if(Profession.equalsIgnoreCase("Coaching Staff/ Athlete / Trainer") || Profession.contains("Coaching Staff/ Athlete / Trainer")){ProfessionCode="089";}
		else if(Profession.equalsIgnoreCase("Chinese Physician / Chinese Medical Dcotor") || Profession.contains("Chinese Physician / Chinese Medical Dcotor")){ProfessionCode="090";}
		else if(Profession.equalsIgnoreCase("AIRFORCE/ Navy") || Profession.contains("AIRFORCE/ Navy")){ProfessionCode="091";}
		else if(Profession.equalsIgnoreCase("Company Secretary") || Profession.contains("Company Secretary")){ProfessionCode="093";}
		else if(Profession.equalsIgnoreCase("Manager/Executive") || Profession.contains("Manager/Executive")){ProfessionCode="094";}
		else if(Profession.equalsIgnoreCase("Officer/ Supervisor/ Administrator") || Profession.contains("Officer/ Supervisor/ Administrator")){ProfessionCode="095";}
		else if(Profession.equalsIgnoreCase("Clerical/Secretarial") || Profession.contains("Clerical/Secretarial")){ProfessionCode="096";}
		else if(Profession.equalsIgnoreCase("Cook/Chef/Chef Assistant") || Profession.contains("Cook/Chef/Chef Assistant")){ProfessionCode="098";}
		else if(Profession.equalsIgnoreCase("Night Club/ Sauna / Mahjong House/Game Centre Staff") || Profession.contains("Night Club/ Sauna / Mahjong House/Game Centre Staff")){ProfessionCode="099";}
		else if(Profession.equalsIgnoreCase("Retired") || Profession.contains("Retired")){ProfessionCode="703";}
		else if(Profession.equalsIgnoreCase("Student") || Profession.contains("Student")){ProfessionCode="704";}
		else if(Profession.equalsIgnoreCase("House wife") || Profession.contains("House wife")){ProfessionCode="705";}
		else if(Profession.equalsIgnoreCase("Unemployed") || Profession.contains("Unemployed")){ProfessionCode="706";}
		else if(Profession.equalsIgnoreCase("Mariner") || Profession.contains("Mariner")){ProfessionCode="708";}
		else if(Profession.equalsIgnoreCase("Minor") || Profession.contains("Minor")){ProfessionCode="MIN";}
		else if(Profession.equalsIgnoreCase("Minor") || Profession.contains("Minor")){ProfessionCode="MIN";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Profession = ("+Profession+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return ProfessionCode;
	}

	public static String TitleCode(String DB_Title) {
		String Title=DBUtils.readColumnWithRowIDNew(DB_Title, GetCase.scenarioID);
		String TitleCode="";
		if(Title.contains("Doctor") || Title.equalsIgnoreCase("DR")){TitleCode="DR";}
		else if(Title.contains("His Highness") || Title.equalsIgnoreCase("HE")){TitleCode="HE";}
		else if(Title.contains("Her Highness") || Title.equalsIgnoreCase("HH")){TitleCode="HH";}
		else if(Title.contains("His Majesty") || Title.equalsIgnoreCase("HM")){TitleCode="HM";}
		else if(Title.contains("Honorable") || Title.equalsIgnoreCase("HON")){TitleCode="HON";}
		else if(Title.contains("Master") || Title.equalsIgnoreCase("MAS")){TitleCode="MAS";}
		else if(Title.contains("Mister") || Title.equalsIgnoreCase("MR")){TitleCode="MR";}
		else if(Title.contains("Missus") || Title.equalsIgnoreCase("MRS")){TitleCode="MRS";}
		else if(Title.contains("Ms") || Title.equalsIgnoreCase("MS")){TitleCode="MS";}
		else if(Title.contains("Reverend") || Title.equalsIgnoreCase("REV")){TitleCode="REV";}
		else if(Title.contains("Shiekh") || Title.equalsIgnoreCase("SH")){TitleCode="SH";}
		else if(Title.contains("Sheikha") || Title.equalsIgnoreCase("SHA")){TitleCode="SHA";}
		else if(Title.contains("Sir") || Title.equalsIgnoreCase("SIR")){TitleCode="SIR";}
		else if(Title.contains("Ambassador") || Title.equalsIgnoreCase("AMB")){TitleCode="AMB";}
		else if(Title.contains("Senator") || Title.equalsIgnoreCase("SEN")){TitleCode="SEN";}
		else if(Title.contains("His Excellency") || Title.equalsIgnoreCase("EX")){TitleCode="EX";}
		else if(Title.contains("Colonel") || Title.equalsIgnoreCase("COL")){TitleCode="COL";}
		else if(Title.contains("General") || Title.equalsIgnoreCase("GEN")){TitleCode="GEN";}
		else if(Title.contains("Attorney") || Title.equalsIgnoreCase("ATT")){TitleCode="ATT";}
		else if(Title.contains("Lieutenant General") || Title.equalsIgnoreCase("LTG")){TitleCode="LTG";}
		else if(Title.contains("Major General") || Title.equalsIgnoreCase("MJG")){TitleCode="MJG";}
		else if(Title.contains("Brigadier") || Title.equalsIgnoreCase("BRG")){TitleCode="BRG";}
		else if(Title.contains("Lieutenant Colonel") || Title.equalsIgnoreCase("LTC")){TitleCode="LTC";}
		else if(Title.contains("Major") || Title.equalsIgnoreCase("MAJ")){TitleCode="MAJ";}
		else if(Title.contains("Captain") || Title.equalsIgnoreCase("CAP")){TitleCode="CAP";}
		else if(Title.contains("Lieutenant") || Title.equalsIgnoreCase("LTT")){TitleCode="LTT";}
		else if(Title.contains("Air Chief Marshal") || Title.equalsIgnoreCase("ACM")){TitleCode="ACM";}
		else if(Title.contains("Air Marshal") || Title.equalsIgnoreCase("AMA")){TitleCode="AMA";}
		else if(Title.contains("Air Vice Marshal") || Title.equalsIgnoreCase("AVM")){TitleCode="AVM";}
		else if(Title.contains("Air Commodore") || Title.equalsIgnoreCase("AIC")){TitleCode="AIC";}
		else if(Title.contains("Group Captain") || Title.equalsIgnoreCase("GRC")){TitleCode="GRC";}
		else if(Title.contains("Wing Commander") || Title.equalsIgnoreCase("WGC")){TitleCode="WGC";}
		else if(Title.contains("Squadron Leader") || Title.equalsIgnoreCase("SQD")){TitleCode="SQD";}
		else if(Title.contains("Flight Lieutenant") || Title.equalsIgnoreCase("FLL")){TitleCode="FLL";}
		else if(Title.contains("Admiral") || Title.equalsIgnoreCase("ADL")){TitleCode="ADL";}
		else if(Title.contains("Vice Admiral") || Title.equalsIgnoreCase("VAD")){TitleCode="VAD";}
		else if(Title.contains("Commodore") || Title.equalsIgnoreCase("CDR")){TitleCode="CDR";}
		else if(Title.contains("Commander") || Title.equalsIgnoreCase("COM")){TitleCode="COM";}
		else if(Title.contains("Lieutenant Commander") || Title.equalsIgnoreCase("LCR")){TitleCode="LCR";}
		else if(Title.contains("Sub Lieutenant") || Title.equalsIgnoreCase("SLT")){TitleCode="SLT";}
		else if(Title.contains("Pastor") || Title.equalsIgnoreCase("PAS")){TitleCode="PAS";}
		else if(Title.contains("Prof") || Title.equalsIgnoreCase("PRF")){TitleCode="PRF";}
		else if(Title.contains("Miss") || Title.equalsIgnoreCase("MIS")){TitleCode="MIS";}
		else if(Title.contains("LORD") || Title.equalsIgnoreCase("LOR")){TitleCode="LOR";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Title = ("+Title+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return TitleCode;
	}

	public static String getNationalityCode(String DB_Nationality) {
		String Nationality=DBUtils.readColumnWithRowIDNew(DB_Nationality, GetCase.scenarioID);
		String NationalityCode="";
		if(Nationality.contains("SLOVENIA")){NationalityCode="SVN";}
		else if(Nationality.contains("SLOVAKIA")){NationalityCode="SVK";}
		else if(Nationality.contains("SINGAPORE")){NationalityCode="SGP";}
		else if(Nationality.contains("SIERRA LEONE")){NationalityCode="SLE";}
		else if(Nationality.contains("SEYCHELLES")){NationalityCode="SYC";}
		else if(Nationality.contains("SERBIA AND MONTENEGRO")){NationalityCode="SCG";}
		else if(Nationality.contains("TUVALU")){NationalityCode="TUV";}
		else if(Nationality.contains("TURKS AND CAICOS ISLANDS")){NationalityCode="TCA";}
		else if(Nationality.contains("TURKMENISTAN")){NationalityCode="TKM";}
		else if(Nationality.contains("TURKEY")){NationalityCode="TUR";}
		else if(Nationality.contains("TUNISIA")){NationalityCode="TUN";}
		else if(Nationality.contains("TRINIDAD AND TOBAGO")){NationalityCode="TTO";}
		else if(Nationality.contains("TONGA")){NationalityCode="TON";}
		else if(Nationality.contains("TOKELAU")){NationalityCode="TKL";}
		else if(Nationality.contains("TOGO")){NationalityCode="TGO";}
		else if(Nationality.contains("TIMOR-LESTE")){NationalityCode="TLS";}
		else if(Nationality.contains("THAILAND")){NationalityCode="THA";}
		else if(Nationality.contains("TANZANIA, UNITED REPUBLIC OF")){NationalityCode="TZA";}
		else if(Nationality.contains("TAJIKISTAN")){NationalityCode="TJK";}
		else if(Nationality.contains("TAIWAN")){NationalityCode="TWN";}
		else if(Nationality.contains("SYRIAN ARAB REPUBLIC")){NationalityCode="SYR";}
		else if(Nationality.contains("SWITZERLAND")){NationalityCode="CHE";}
		else if(Nationality.contains("SWEDEN")){NationalityCode="SWE";}
		else if(Nationality.contains("Others")){NationalityCode="OTH";}
		else if(Nationality.contains("ZIMBABWE")){NationalityCode="ZWE";}
		else if(Nationality.contains("ZAMBIA")){NationalityCode="ZMB";}
		else if(Nationality.contains("YUGOSLAVIA")){NationalityCode="YUG";}
		else if(Nationality.contains("YEMEN")){NationalityCode="YEM";}
		else if(Nationality.contains("WESTERN SAHARA")){NationalityCode="ESH";}
		else if(Nationality.contains("WALLIS AND FUTUNA")){NationalityCode="WLF";}
		else if(Nationality.contains("VIRGIN ISLANDS, U.S.")){NationalityCode="VIR";}
		else if(Nationality.contains("VIRGIN ISLANDS, BRITISH")){NationalityCode="VGB";}
		else if(Nationality.contains("VIETNAM")){NationalityCode="VNM";}
		else if(Nationality.contains("VENEZUELA, BOLIVARIAN REP OF")){NationalityCode="VEN";}
		else if(Nationality.contains("HOLY SEE")){NationalityCode="VAT";}
		else if(Nationality.contains("VANUATU")){NationalityCode="VUT";}
		else if(Nationality.contains("UZBEKISTAN")){NationalityCode="UZB";}
		else if(Nationality.contains("URUGUAY")){NationalityCode="URY";}
		else if(Nationality.contains("UNITED STATES OUTLYING ISLAND")){NationalityCode="UMI";}
		else if(Nationality.contains("UNITED STATES OF AMERICA")){NationalityCode="USA";}
		else if(Nationality.contains("UNITED KINGDOM")){NationalityCode="GBR";}
		else if(Nationality.contains("UNITED ARAB EMIRATES")){NationalityCode="ARE";}
		else if(Nationality.contains("UKRAINE")){NationalityCode="UKR";}
		else if(Nationality.contains("UGANDA")){NationalityCode="UGA";}
		else if(Nationality.contains("SOMALIA")){NationalityCode="SOM";}
		else if(Nationality.contains("SOLOMON ISLANDS")){NationalityCode="SLB";}
		else if(Nationality.contains("ALAND ISLANDS")){NationalityCode="ALA";}
		else if(Nationality.contains("AFGHANISTAN")){NationalityCode="AFG";}
		else if(Nationality.contains("ALBANIA")){NationalityCode="ALB";}
		else if(Nationality.contains("ALGERIA")){NationalityCode="DZA";}
		else if(Nationality.contains("AMERICAN SAMOA")){NationalityCode="ASM";}
		else if(Nationality.contains("ANDORRA")){NationalityCode="AND";}
		else if(Nationality.contains("ANGOLA")){NationalityCode="AGO";}
		else if(Nationality.contains("ANGUILLA")){NationalityCode="AIA";}
		else if(Nationality.contains("ANTARCTICA")){NationalityCode="ATA";}
		else if(Nationality.contains("ANTIGUA AND BARBUDA")){NationalityCode="ATG";}
		else if(Nationality.contains("ARGENTINA")){NationalityCode="ARG";}
		else if(Nationality.contains("ARMENIA")){NationalityCode="ARM";}
		else if(Nationality.contains("ARUBA")){NationalityCode="ABW";}
		else if(Nationality.contains("AUSTRALIA")){NationalityCode="AUS";}
		else if(Nationality.contains("AUSTRIA")){NationalityCode="AUT";}
		else if(Nationality.contains("AZERBAIJAN")){NationalityCode="AZE";}
		else if(Nationality.contains("BAHAMAS")){NationalityCode="BHS";}
		else if(Nationality.contains("BAHRAIN")){NationalityCode="BHR";}
		else if(Nationality.contains("BANGLADESH")){NationalityCode="BGD";}
		else if(Nationality.contains("BARBADOS")){NationalityCode="BRB";}
		else if(Nationality.contains("BELARUS")){NationalityCode="BLR";}
		else if(Nationality.contains("BELGIUM")){NationalityCode="BEL";}
		else if(Nationality.contains("BELIZE")){NationalityCode="BLZ";}
		else if(Nationality.contains("BENIN")){NationalityCode="BEN";}
		else if(Nationality.contains("BRAZIL")){NationalityCode="BRA";}
		else if(Nationality.contains("BRITISH INDIAN OCEANTERRITORY")){NationalityCode="IOT";}
		else if(Nationality.contains("BRUNEI DARUSSALAM")){NationalityCode="BRN";}
		else if(Nationality.contains("BULGARIA")){NationalityCode="BGR";}
		else if(Nationality.contains("BURKINA FASO")){NationalityCode="BFA";}
		else if(Nationality.contains("BURUNDI")){NationalityCode="BDI";}
		else if(Nationality.contains("CAMBODIA")){NationalityCode="KHM";}
		else if(Nationality.contains("CAMEROON")){NationalityCode="CMR";}
		else if(Nationality.contains("CANADA")){NationalityCode="CAN";}
		else if(Nationality.contains("CABO VERDE")){NationalityCode="CPV";}
		else if(Nationality.contains("CAYMAN ISLANDS")){NationalityCode="CYM";}
		else if(Nationality.contains("CENTRAL AFRICAN REPUBLIC")){NationalityCode="CAF";}
		else if(Nationality.contains("CHAD")){NationalityCode="TCD";}
		else if(Nationality.contains("CHILE")){NationalityCode="CHL";}
		else if(Nationality.contains("CHINA")){NationalityCode="CHN";}
		else if(Nationality.contains("CHRISTMAS ISLAND")){NationalityCode="CXR";}
		else if(Nationality.contains("COCOS (KEELING) ISLANDS")){NationalityCode="CCK";}
		else if(Nationality.contains("COLOMBIA")){NationalityCode="COL";}
		else if(Nationality.contains("COMOROS")){NationalityCode="COM";}
		else if(Nationality.contains("CONGO, DEMOCRATIC REPUBLIC OF")){NationalityCode="COD";}
		else if(Nationality.contains("CONGO")){NationalityCode="COG";}
		else if(Nationality.contains("COOK ISLANDS")){NationalityCode="COK";}
		else if(Nationality.contains("COSTA RICA")){NationalityCode="CRI";}
		else if(Nationality.contains("COTE D'IVOIRE")){NationalityCode="CIV";}
		else if(Nationality.contains("CROATIA")){NationalityCode="HRV";}
		else if(Nationality.contains("CUBA")){NationalityCode="CUB";}
		else if(Nationality.contains("CYPRUS")){NationalityCode="CYP";}
		else if(Nationality.contains("BERMUDA")){NationalityCode="BMU";}
		else if(Nationality.contains("BHUTAN")){NationalityCode="BTN";}
		else if(Nationality.contains("BOLIVIA,PLURINATIONAL STATEOF")){NationalityCode="BOL";}
		else if(Nationality.contains("BOSNIA AND HERZEGOVINA")){NationalityCode="BIH";}
		else if(Nationality.contains("BOTSWANA")){NationalityCode="BWA";}
		else if(Nationality.contains("BOUVET ISLAND")){NationalityCode="BVT";}
		else if(Nationality.contains("EL SALVADOR")){NationalityCode="SLV";}
		else if(Nationality.contains("EQUATORIAL GUINEA")){NationalityCode="GNQ";}
		else if(Nationality.contains("ERITREA")){NationalityCode="ERI";}
		else if(Nationality.contains("ESTONIA")){NationalityCode="EST";}
		else if(Nationality.contains("ETHIOPIA")){NationalityCode="ETH";}
		else if(Nationality.contains("FALKLAND ISLANDS FLK")){NationalityCode="FLK";}
		else if(Nationality.contains("FAROE ISLANDS")){NationalityCode="FRO";}
		else if(Nationality.contains("FIJI")){NationalityCode="FJI";}
		else if(Nationality.contains("FINLAND")){NationalityCode="FIN";}
		else if(Nationality.contains("FRANCE")){NationalityCode="FRA";}
		else if(Nationality.contains("FRANCE, METROPOLITAN")){NationalityCode="FXX";}
		else if(Nationality.contains("FRENCH GUIANA")){NationalityCode="GUF";}
		else if(Nationality.contains("FRENCH POLYNESIA")){NationalityCode="PYF";}
		else if(Nationality.contains("FRENCH SOUTHERN TERRITORIES")){NationalityCode="ATF";}
		else if(Nationality.contains("GABON")){NationalityCode="GAB";}
		else if(Nationality.contains("GAMBIA")){NationalityCode="GMB";}
		else if(Nationality.contains("GEORGIA")){NationalityCode="GEO";}
		else if(Nationality.contains("GERMANY")){NationalityCode="DEU";}
		else if(Nationality.contains("GHANA")){NationalityCode="GHA";}
		else if(Nationality.contains("GIBRALTAR")){NationalityCode="GIB";}
		else if(Nationality.contains("GREECE")){NationalityCode="GRC";}
		else if(Nationality.contains("DUBAI INT FIN CENTRE (Rebased)")){NationalityCode="XDC";}
		else if(Nationality.contains("GREENLAND")){NationalityCode="GRL";}
		else if(Nationality.contains("GRENADA")){NationalityCode="GRD";}
		else if(Nationality.contains("GUADELOUPE")){NationalityCode="GLP";}
		else if(Nationality.contains("GUAM")){NationalityCode="GUM";}
		else if(Nationality.contains("GUATEMALA")){NationalityCode="GTM";}
		else if(Nationality.contains("GUERNSEY")){NationalityCode="GGY";}
		else if(Nationality.contains("CZECH REPUBLIC")){NationalityCode="CZE";}
		else if(Nationality.contains("DENMARK")){NationalityCode="DNK";}
		else if(Nationality.contains("DJIBOUTI")){NationalityCode="DJI";}
		else if(Nationality.contains("DOMINICA")){NationalityCode="DMA";}
		else if(Nationality.contains("DOMINICAN REPUBLIC")){NationalityCode="DOM";}
		else if(Nationality.contains("ECUADOR")){NationalityCode="ECU";}
		else if(Nationality.contains("EGYPT")){NationalityCode="EGY";}
		else if(Nationality.contains("HUNGARY")){NationalityCode="HUN";}
		else if(Nationality.contains("ICELAND")){NationalityCode="ISL";}
		else if(Nationality.contains("INDIA")){NationalityCode="IND";}
		else if(Nationality.contains("INDONESIA")){NationalityCode="IDN";}
		else if(Nationality.contains("IRAN, ISLAMIC REPUBLIC OF")){NationalityCode="IRN";}
		else if(Nationality.contains("IRAQ")){NationalityCode="IRQ";}
		else if(Nationality.contains("IRELAND")){NationalityCode="IRL";}
		else if(Nationality.contains("ISLE OF MAN")){NationalityCode="IMN";}
		else if(Nationality.contains("ISRAEL")){NationalityCode="ISR";}
		else if(Nationality.contains("ITALY")){NationalityCode="ITA";}
		else if(Nationality.contains("JAMAICA")){NationalityCode="JAM";}
		else if(Nationality.contains("JAPAN")){NationalityCode="JPN";}
		else if(Nationality.contains("JERSEY")){NationalityCode="JEY";}
		else if(Nationality.contains("JORDAN")){NationalityCode="JOR";}
		else if(Nationality.contains("KAZAKHSTAN")){NationalityCode="KAZ";}
		else if(Nationality.contains("KENYA")){NationalityCode="KEN";}
		else if(Nationality.contains("KIRIBATI")){NationalityCode="KIR";}
		else if(Nationality.contains("KOREADEMOCRATIC PEOPLES REP")){NationalityCode="PRK";}
		else if(Nationality.contains("KOREA, REPUBLIC OF")){NationalityCode="KOR";}
		else if(Nationality.contains("KUWAIT")){NationalityCode="KWT";}
		else if(Nationality.contains("KYRGYZSTAN")){NationalityCode="KGZ";}
		else if(Nationality.contains("LAO PEOPLES DEMOCRATIC REP")){NationalityCode="LAO";}
		else if(Nationality.contains("LATVIA")){NationalityCode="LVA";}
		else if(Nationality.contains("LEBANON")){NationalityCode="LBN";}
		else if(Nationality.contains("LESOTHO")){NationalityCode="LSO";}
		else if(Nationality.contains("LIBERIA")){NationalityCode="LBR";}
		else if(Nationality.contains("LIBYA")){NationalityCode="LBY";}
		else if(Nationality.contains("GUINEA")){NationalityCode="GIN";}
		else if(Nationality.contains("GUINEA-BISSAU")){NationalityCode="GNB";}
		else if(Nationality.contains("GUYANA")){NationalityCode="GUY";}
		else if(Nationality.contains("HAITI")){NationalityCode="HTI";}
		else if(Nationality.contains("HEARD ISLAND,MCDONALD ISLANDS")){NationalityCode="HMD";}
		else if(Nationality.contains("HONDURAS")){NationalityCode="HND";}
		else if(Nationality.contains("HONG KONG")){NationalityCode="HKG";}
		else if(Nationality.contains("MALAYSIA")){NationalityCode="MYS";}
		else if(Nationality.contains("MALDIVES")){NationalityCode="MDV";}
		else if(Nationality.contains("MALI")){NationalityCode="MLI";}
		else if(Nationality.contains("MALTA")){NationalityCode="MLT";}
		else if(Nationality.contains("MARSHALL ISLANDS")){NationalityCode="MHL";}
		else if(Nationality.contains("MARTINIQUE")){NationalityCode="MTQ";}
		else if(Nationality.contains("MAURITANIA")){NationalityCode="MRT";}
		else if(Nationality.contains("MAURITIUS")){NationalityCode="MUS";}
		else if(Nationality.contains("MAYOTTE")){NationalityCode="MYT";}
		else if(Nationality.contains("MEXICO")){NationalityCode="MEX";}
		else if(Nationality.contains("MICRONESIA,FEDERATED STATE OF")){NationalityCode="FSM";}
		else if(Nationality.contains("MOLDOVA, REPUBLIC OF")){NationalityCode="MDA";}
		else if(Nationality.contains("MONACO")){NationalityCode="MCO";}
		else if(Nationality.contains("MONGOLIA")){NationalityCode="MNG";}
		else if(Nationality.contains("MONTSERRAT")){NationalityCode="MSR";}
		else if(Nationality.contains("MOROCCO")){NationalityCode="MAR";}
		else if(Nationality.contains("MOZAMBIQUE")){NationalityCode="MOZ";}
		else if(Nationality.contains("MYANMAR")){NationalityCode="MMR";}
		else if(Nationality.contains("NAMIBIA")){NationalityCode="NAM";}
		else if(Nationality.contains("NAURU")){NationalityCode="MRU";}
		else if(Nationality.contains("NEPAL")){NationalityCode="NPL";}
		else if(Nationality.contains("NETHERLANDS")){NationalityCode="NLD";}
		else if(Nationality.contains("NETHERLANDS ANTILLES")){NationalityCode="ANT";}
		else if(Nationality.contains("NEW CALEDONIA")){NationalityCode="NCL";}
		else if(Nationality.contains("NEW ZEALAND")){NationalityCode="NZL";}
		else if(Nationality.contains("NICARAGUA")){NationalityCode="NIC";}
		else if(Nationality.contains("NIGER")){NationalityCode="NER";}
		else if(Nationality.contains("LIECHTENSTEIN")){NationalityCode="LIE";}
		else if(Nationality.contains("LITHUANIA")){NationalityCode="LTU";}
		else if(Nationality.contains("LUXEMBOURG")){NationalityCode="LUX";}
		else if(Nationality.contains("MACAO")){NationalityCode="MAC";}
		else if(Nationality.contains("MACEDONIA, REPUBLIC OF")){NationalityCode="MKD";}
		else if(Nationality.contains("MADAGASCAR")){NationalityCode="MDG";}
		else if(Nationality.contains("MALAWI")){NationalityCode="MWI";}
		else if(Nationality.contains("PALAU")){NationalityCode="PLW";}
		else if(Nationality.contains("PALESTINE, STATE OF")){NationalityCode="PSE";}
		else if(Nationality.contains("PANAMA")){NationalityCode="PAN";}
		else if(Nationality.contains("PAPUA NEW GUINEA")){NationalityCode="PNG";}
		else if(Nationality.contains("PARAGUAY")){NationalityCode="PRY";}
		else if(Nationality.contains("PERU")){NationalityCode="PER";}
		else if(Nationality.contains("PHILIPPINES")){NationalityCode="PHL";}
		else if(Nationality.contains("PITCAIRN")){NationalityCode="PCN";}
		else if(Nationality.contains("POLAND")){NationalityCode="POL";}
		else if(Nationality.contains("PORTUGAL")){NationalityCode="PRT";}
		else if(Nationality.contains("PUERTO RICO")){NationalityCode="PRI";}
		else if(Nationality.contains("QATAR")){NationalityCode="QAT";}
		else if(Nationality.contains("REUNION")){NationalityCode="REU";}
		else if(Nationality.contains("ROMANIA")){NationalityCode="ROU";}
		else if(Nationality.contains("RUSSIAN FEDERATION")){NationalityCode="RUS";}
		else if(Nationality.contains("RWANDA")){NationalityCode="RWA";}
		else if(Nationality.contains("STHELENA ASCENSN TRISTANCUNHA")){NationalityCode="SHN";}
		else if(Nationality.contains("SAINT KITTS AND NEVIS")){NationalityCode="KNA";}
		else if(Nationality.contains("SAINT LUCIA")){NationalityCode="LCA";}
		else if(Nationality.contains("SAINT PIERRE AND MIQUELON")){NationalityCode="SPM";}
		else if(Nationality.contains("BONAIRE, SINT EUSTATIUS, SABA")){NationalityCode="BES";}
		else if(Nationality.contains("KOSOVO")){NationalityCode="XKD";}
		else if(Nationality.contains("SAINT VINCENT, THE GRENADINES")){NationalityCode="VCT";}
		else if(Nationality.contains("SAMOA")){NationalityCode="WSM";}
		else if(Nationality.contains("SAN MARINO")){NationalityCode="SMR";}
		else if(Nationality.contains("SAO TOME AND PRINCIPE")){NationalityCode="STP";}
		else if(Nationality.contains("SAUDI ARABIA")){NationalityCode="SAU";}
		else if(Nationality.contains("SENEGAL")){NationalityCode="SEN";}
		else if(Nationality.contains("NIGERIA")){NationalityCode="NGA";}
		else if(Nationality.contains("NIUE")){NationalityCode="NIU";}
		else if(Nationality.contains("NORFOLK ISLAND")){NationalityCode="NFK";}
		else if(Nationality.contains("NORTHERN MARIANA ISLANDS")){NationalityCode="MNP";}
		else if(Nationality.contains("NORWAY")){NationalityCode="NOR";}
		else if(Nationality.contains("OMAN")){NationalityCode="OMN";}
		else if(Nationality.contains("PAKISTAN")){NationalityCode="PAK";}
		else if(Nationality.contains("SOUTH AFRICA")){NationalityCode="ZAF";}
		else if(Nationality.contains("SOUTH GEORGIA,SANDWICH ISLAND")){NationalityCode="SGS";}
		else if(Nationality.contains("SPAIN")){NationalityCode="ESP";}
		else if(Nationality.contains("SRI LANKA")){NationalityCode="LKA";}
		else if(Nationality.contains("SUDAN")){NationalityCode="SDN";}
		else if(Nationality.contains("SURINAME")){NationalityCode="SUR";}
		else if(Nationality.contains("SVALBARD AND JAN MAYEN")){NationalityCode="SJM";}
		else if(Nationality.contains("SWAZILAND")){NationalityCode="SWZ";}
		else if(Nationality.contains("CURACAO")){NationalityCode="CUW";}
		else if(Nationality.contains("MONTENEGRO")){NationalityCode="MNE";}
		else if(Nationality.contains("SAINT BARTHELEMY")){NationalityCode="BLM";}
		else if(Nationality.contains("SAINT MARTIN (FRENCH PART)")){NationalityCode="MAF";}
		else if(Nationality.contains("SERBIA")){NationalityCode="SRB";}
		else if(Nationality.contains("SINT MAARTEN (DUTCH PART)")){NationalityCode="SXM";}
		else if(Nationality.contains("NAURU")){NationalityCode="NRU";}
		else if(Nationality.contains("SOUTH SUDAN")){NationalityCode="SSD";}
		else if(Nationality.contains("Saudi offshore")){NationalityCode="XAA";}
		else if(Nationality.contains("SUPRANATIONAL")){NationalityCode="XBB";}
		else if(Nationality.contains("LABUAN (Rebased)")){NationalityCode="XLE";}
		else if(Nationality.contains("UNKNOWN")){NationalityCode="ZZZ";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Nationality = ("+Nationality+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return NationalityCode;
	}


	public static String getNationalityCodeNew(String DB_Nationality) {
		String Nationality=DBUtils.readColumnWithRowIDNew(DB_Nationality, GetCase.scenarioID);
		String NationalityCode="";
		if(Nationality.contains("ALAND ISLANDS")){NationalityCode="ALA";}
		else if(Nationality.contains("AFGHANISTAN")){NationalityCode="AFG";}
		else if(Nationality.contains("ALBANIA")){NationalityCode="ALB";}
		else if(Nationality.contains("ALGERIA")){NationalityCode="DZA";}
		else if(Nationality.contains("AMERICAN SAMOA")){NationalityCode="ASM";}
		else if(Nationality.contains("ANDORRA")){NationalityCode="AND";}
		else if(Nationality.contains("ANGOLA")){NationalityCode="AGO";}
		else if(Nationality.contains("ANGUILLA")){NationalityCode="AIA";}
		else if(Nationality.contains("ANTARCTICA")){NationalityCode="ATA";}
		else if(Nationality.contains("ANTIGUA AND BARBUDA")){NationalityCode="ATG";}
		else if(Nationality.contains("ARGENTINA")){NationalityCode="ARG";}
		else if(Nationality.contains("ARMENIA")){NationalityCode="ARM";}
		else if(Nationality.contains("ARUBA")){NationalityCode="ABW";}
		else if(Nationality.contains("AUSTRALIA")){NationalityCode="AUS";}
		else if(Nationality.contains("AUSTRIA")){NationalityCode="AUT";}
		else if(Nationality.contains("AZERBAIJAN")){NationalityCode="AZE";}
		else if(Nationality.contains("BAHAMAS")){NationalityCode="BHS";}
		else if(Nationality.contains("BAHRAIN")){NationalityCode="BHR";}
		else if(Nationality.contains("BANGLADESH")){NationalityCode="BGD";}
		else if(Nationality.contains("BARBADOS")){NationalityCode="BRB";}
		else if(Nationality.contains("BELARUS")){NationalityCode="BLR";}
		else if(Nationality.contains("BELGIUM")){NationalityCode="BEL";}
		else if(Nationality.contains("BELIZE")){NationalityCode="BLZ";}
		else if(Nationality.contains("BENIN")){NationalityCode="BEN";}
		else if(Nationality.contains("BERMUDA")){NationalityCode="BMU";}
		else if(Nationality.contains("BHUTAN")){NationalityCode="BTN";}
		else if(Nationality.contains("BOLIVIA,PLURINATIONAL STATEOF")){NationalityCode="BOL";}
		else if(Nationality.contains("BONAIRE, SINT EUSTATIUS, SABA")){NationalityCode="BES";}
		else if(Nationality.contains("BOSNIA AND HERZEGOVINA")){NationalityCode="BIH";}
		else if(Nationality.contains("BOTSWANA")){NationalityCode="BWA";}
		else if(Nationality.contains("BOUVET ISLAND")){NationalityCode="BVT";}
		else if(Nationality.contains("BRAZIL")){NationalityCode="BRA";}
		else if(Nationality.contains("BRITISH INDIAN OCEANTERRITORY")){NationalityCode="IOT";}
		else if(Nationality.contains("BRUNEI DARUSSALAM")){NationalityCode="BRN";}
		else if(Nationality.contains("BULGARIA")){NationalityCode="BGR";}
		else if(Nationality.contains("BURKINA FASO")){NationalityCode="BFA";}
		else if(Nationality.contains("BURUNDI")){NationalityCode="BDI";}
		else if(Nationality.contains("CAMBODIA")){NationalityCode="KHM";}
		else if(Nationality.contains("CAMEROON")){NationalityCode="CMR";}
		else if(Nationality.contains("CANADA")){NationalityCode="CAN";}
		else if(Nationality.contains("CABO VERDE")){NationalityCode="CPV";}
		else if(Nationality.contains("CAYMAN ISLANDS")){NationalityCode="CYM";}
		else if(Nationality.contains("CENTRAL AFRICAN REPUBLIC")){NationalityCode="CAF";}
		else if(Nationality.contains("CHAD")){NationalityCode="TCD";}
		else if(Nationality.contains("CHILE")){NationalityCode="CHL";}
		else if(Nationality.contains("CHINA")){NationalityCode="CHN";}
		else if(Nationality.contains("CHRISTMAS ISLAND")){NationalityCode="CXR";}
		else if(Nationality.contains("COCOS (KEELING) ISLANDS")){NationalityCode="CCK";}
		else if(Nationality.contains("COLOMBIA")){NationalityCode="COL";}
		else if(Nationality.contains("COMOROS")){NationalityCode="COM";}
		else if(Nationality.contains("CONGO")){NationalityCode="COG";}
		else if(Nationality.contains("CONGO, DEMOCRATIC REPUBLIC OF")){NationalityCode="COD";}
		else if(Nationality.contains("COOK ISLANDS")){NationalityCode="COK";}
		else if(Nationality.contains("COSTA RICA")){NationalityCode="CRI";}
		else if(Nationality.contains("COTE D'IVOIRE")){NationalityCode="CIV";}
		else if(Nationality.contains("CROATIA")){NationalityCode="HRV";}
		else if(Nationality.contains("CUBA")){NationalityCode="CUB";}
		else if(Nationality.contains("CURACAO")){NationalityCode="CUW";}
		else if(Nationality.contains("CYPRUS")){NationalityCode="CYP";}
		else if(Nationality.contains("CZECH REPUBLIC")){NationalityCode="CZE";}
		else if(Nationality.contains("DENMARK")){NationalityCode="DNK";}
		else if(Nationality.contains("DJIBOUTI")){NationalityCode="DJI";}
		else if(Nationality.contains("DOMINICA")){NationalityCode="DMA";}
		else if(Nationality.contains("DOMINICAN REPUBLIC")){NationalityCode="DOM";}
		else if(Nationality.contains("ECUADOR")){NationalityCode="ECU";}
		else if(Nationality.contains("EGYPT")){NationalityCode="EGY";}
		else if(Nationality.contains("EL SALVADOR")){NationalityCode="SLV";}
		else if(Nationality.contains("EQUATORIAL GUINEA")){NationalityCode="GNQ";}
		else if(Nationality.contains("ERITREA")){NationalityCode="ERI";}
		else if(Nationality.contains("ESTONIA")){NationalityCode="EST";}
		else if(Nationality.contains("ETHIOPIA")){NationalityCode="ETH";}
		else if(Nationality.contains("FALKLAND ISLANDS FLK")){NationalityCode="FLK";}
		else if(Nationality.contains("FAROE ISLANDS")){NationalityCode="FRO";}
		else if(Nationality.contains("FIJI")){NationalityCode="FJI";}
		else if(Nationality.contains("FINLAND")){NationalityCode="FIN";}
		else if(Nationality.contains("FRANCE")){NationalityCode="FRA";}
		else if(Nationality.contains("FRENCH GUIANA")){NationalityCode="GUF";}
		else if(Nationality.contains("FRENCH POLYNESIA")){NationalityCode="PYF";}
		else if(Nationality.contains("FRENCH SOUTHERN TERRITORIES")){NationalityCode="ATF";}
		else if(Nationality.contains("GABON")){NationalityCode="GAB";}
		else if(Nationality.contains("GAMBIA")){NationalityCode="GMB";}
		else if(Nationality.contains("GEORGIA")){NationalityCode="GEO";}
		else if(Nationality.contains("GERMANY")){NationalityCode="DEU";}
		else if(Nationality.contains("GHANA")){NationalityCode="GHA";}
		else if(Nationality.contains("GIBRALTAR")){NationalityCode="GIB";}
		else if(Nationality.contains("GREECE")){NationalityCode="GRC";}
		else if(Nationality.contains("GREENLAND")){NationalityCode="GRL";}
		else if(Nationality.contains("GRENADA")){NationalityCode="GRD";}
		else if(Nationality.contains("GUADELOUPE")){NationalityCode="GLP";}
		else if(Nationality.contains("GUAM")){NationalityCode="GUM";}
		else if(Nationality.contains("GUATEMALA")){NationalityCode="GTM";}
		else if(Nationality.contains("GUERNSEY")){NationalityCode="GGY";}
		else if(Nationality.contains("GUINEA")){NationalityCode="GIN";}
		else if(Nationality.contains("GUINEA-BISSAU")){NationalityCode="GNB";}
		else if(Nationality.contains("GUYANA")){NationalityCode="GUY";}
		else if(Nationality.contains("HAITI")){NationalityCode="HTI";}
		else if(Nationality.contains("HEARD ISLAND,MCDONALD ISLANDS")){NationalityCode="HMD";}
		else if(Nationality.contains("HONDURAS")){NationalityCode="HND";}
		else if(Nationality.contains("HONG KONG")){NationalityCode="HKG";}
		else if(Nationality.contains("HUNGARY")){NationalityCode="HUN";}
		else if(Nationality.contains("ICELAND")){NationalityCode="ISL";}
		else if(Nationality.contains("INDIA")){NationalityCode="IND";}
		else if(Nationality.contains("INDONESIA")){NationalityCode="IDN";}
		else if(Nationality.contains("IRAN, ISLAMIC REPUBLIC OF")){NationalityCode="IRN";}
		else if(Nationality.contains("IRAQ")){NationalityCode="IRQ";}
		else if(Nationality.contains("IRELAND")){NationalityCode="IRL";}
		else if(Nationality.contains("ISLE OF MAN")){NationalityCode="IMN";}
		else if(Nationality.contains("ISRAEL")){NationalityCode="ISR";}
		else if(Nationality.contains("ITALY")){NationalityCode="ITA";}
		else if(Nationality.contains("JAMAICA")){NationalityCode="JAM";}
		else if(Nationality.contains("JAPAN")){NationalityCode="JPN";}
		else if(Nationality.contains("JERSEY")){NationalityCode="JEY";}
		else if(Nationality.contains("JORDAN")){NationalityCode="JOR";}
		else if(Nationality.contains("KAZAKHSTAN")){NationalityCode="KAZ";}
		else if(Nationality.contains("KENYA")){NationalityCode="KEN";}
		else if(Nationality.contains("KIRIBATI")){NationalityCode="KIR";}
		else if(Nationality.contains("KOREA, REPUBLIC OF")){NationalityCode="KOR";}
		else if(Nationality.contains("KOREADEMOCRATIC PEOPLES REP")){NationalityCode="PRK";}
		else if(Nationality.contains("KOSOVO")){NationalityCode="XKD";}
		else if(Nationality.contains("KUWAIT")){NationalityCode="KWT";}
		else if(Nationality.contains("KYRGYZSTAN")){NationalityCode="KGZ";}
		else if(Nationality.contains("LAO PEOPLES DEMOCRATIC REP")){NationalityCode="LAO";}
		else if(Nationality.contains("LATVIA")){NationalityCode="LVA";}
		else if(Nationality.contains("LEBANON")){NationalityCode="LBN";}
		else if(Nationality.contains("LESOTHO")){NationalityCode="LSO";}
		else if(Nationality.contains("LIBERIA")){NationalityCode="LBR";}
		else if(Nationality.contains("LIBYA")){NationalityCode="LBY";}
		else if(Nationality.contains("LIECHTENSTEIN")){NationalityCode="LIE";}
		else if(Nationality.contains("LITHUANIA")){NationalityCode="LTU";}
		else if(Nationality.contains("LUXEMBOURG")){NationalityCode="LUX";}
		else if(Nationality.contains("MACAO")){NationalityCode="MAC";}
		else if(Nationality.contains("MACEDONIA, REPUBLIC OF")){NationalityCode="MKD";}
		else if(Nationality.contains("MADAGASCAR")){NationalityCode="MDG";}
		else if(Nationality.contains("MALAWI")){NationalityCode="MWI";}
		else if(Nationality.contains("MALAYSIA")){NationalityCode="MYS";}
		else if(Nationality.contains("MALDIVES")){NationalityCode="MDV";}
		else if(Nationality.contains("MALI")){NationalityCode="MLI";}
		else if(Nationality.contains("MALTA")){NationalityCode="MLT";}
		else if(Nationality.contains("MARSHALL ISLANDS")){NationalityCode="MHL";}
		else if(Nationality.contains("MARTINIQUE")){NationalityCode="MTQ";}
		else if(Nationality.contains("MAURITANIA")){NationalityCode="MRT";}
		else if(Nationality.contains("MAURITIUS")){NationalityCode="MUS";}
		else if(Nationality.contains("MAYOTTE")){NationalityCode="MYT";}
		else if(Nationality.contains("MEXICO")){NationalityCode="MEX";}
		else if(Nationality.contains("MICRONESIA,FEDERATED STATE OF")){NationalityCode="FSM";}
		else if(Nationality.contains("MOLDOVA, REPUBLIC OF")){NationalityCode="MDA";}
		else if(Nationality.contains("MONACO")){NationalityCode="MCO";}
		else if(Nationality.contains("MONGOLIA")){NationalityCode="MNG";}
		else if(Nationality.contains("MONTENEGRO")){NationalityCode="MNE";}
		else if(Nationality.contains("MONTSERRAT")){NationalityCode="MSR";}
		else if(Nationality.contains("MOROCCO")){NationalityCode="MAR";}
		else if(Nationality.contains("MOZAMBIQUE")){NationalityCode="MOZ";}
		else if(Nationality.contains("MYANMAR")){NationalityCode="MMR";}
		else if(Nationality.contains("NAMIBIA")){NationalityCode="NAM";}
		else if(Nationality.contains("NAURU")){NationalityCode="NRU";}
		else if(Nationality.contains("NEPAL")){NationalityCode="NPL";}
		else if(Nationality.contains("NETHERLANDS")){NationalityCode="NLD";}
		else if(Nationality.contains("NEW CALEDONIA")){NationalityCode="NCL";}
		else if(Nationality.contains("NEW ZEALAND")){NationalityCode="NZL";}
		else if(Nationality.contains("NICARAGUA")){NationalityCode="NIC";}
		else if(Nationality.contains("NIGER")){NationalityCode="NER";}
		else if(Nationality.contains("NIGERIA")){NationalityCode="NGA";}
		else if(Nationality.contains("NIUE")){NationalityCode="NIU";}
		else if(Nationality.contains("NORFOLK ISLAND")){NationalityCode="NFK";}
		else if(Nationality.contains("NORTHERN MARIANA ISLANDS")){NationalityCode="MNP";}
		else if(Nationality.contains("NORWAY")){NationalityCode="NOR";}
		else if(Nationality.contains("OMAN")){NationalityCode="OMN";}
		else if(Nationality.contains("PAKISTAN")){NationalityCode="PAK";}
		else if(Nationality.contains("PALAU")){NationalityCode="PLW";}
		else if(Nationality.contains("PALESTINE, STATE OF")){NationalityCode="PSE";}
		else if(Nationality.contains("PANAMA")){NationalityCode="PAN";}
		else if(Nationality.contains("PAPUA NEW GUINEA")){NationalityCode="PNG";}
		else if(Nationality.contains("PARAGUAY")){NationalityCode="PRY";}
		else if(Nationality.contains("PERU")){NationalityCode="PER";}
		else if(Nationality.contains("PHILIPPINES")){NationalityCode="PHL";}
		else if(Nationality.contains("PITCAIRN")){NationalityCode="PCN";}
		else if(Nationality.contains("POLAND")){NationalityCode="POL";}
		else if(Nationality.contains("PORTUGAL")){NationalityCode="PRT";}
		else if(Nationality.contains("PUERTO RICO")){NationalityCode="PRI";}
		else if(Nationality.contains("QATAR")){NationalityCode="QAT";}
		else if(Nationality.contains("REUNION")){NationalityCode="REU";}
		else if(Nationality.contains("ROMANIA")){NationalityCode="ROU";}
		else if(Nationality.contains("RUSSIAN FEDERATION")){NationalityCode="RUS";}
		else if(Nationality.contains("RWANDA")){NationalityCode="RWA";}
		else if(Nationality.contains("SAINT BARTHELEMY")){NationalityCode="BLM";}
		else if(Nationality.contains("SAINT KITTS AND NEVIS")){NationalityCode="KNA";}
		else if(Nationality.contains("SAINT LUCIA")){NationalityCode="LCA";}
		else if(Nationality.contains("SAINT MARTIN (FRENCH PART)")){NationalityCode="MAF";}
		else if(Nationality.contains("SAINT PIERRE AND MIQUELON")){NationalityCode="SPM";}
		else if(Nationality.contains("SAINT VINCENT, THE GRENADINES")){NationalityCode="VCT";}
		else if(Nationality.contains("SAMOA")){NationalityCode="WSM";}
		else if(Nationality.contains("SAN MARINO")){NationalityCode="SMR";}
		else if(Nationality.contains("SAO TOME AND PRINCIPE")){NationalityCode="STP";}
		else if(Nationality.contains("SAUDI ARABIA")){NationalityCode="SAU";}
		else if(Nationality.contains("SENEGAL")){NationalityCode="SEN";}
		else if(Nationality.contains("SERBIA")){NationalityCode="SRB";}
		else if(Nationality.contains("SEYCHELLES")){NationalityCode="SYC";}
		else if(Nationality.contains("SIERRA LEONE")){NationalityCode="SLE";}
		else if(Nationality.contains("SINGAPORE")){NationalityCode="SGP";}
		else if(Nationality.contains("SINT MAARTEN (DUTCH PART)")){NationalityCode="SXM";}
		else if(Nationality.contains("SLOVAKIA")){NationalityCode="SVK";}
		else if(Nationality.contains("SLOVENIA")){NationalityCode="SVN";}
		else if(Nationality.contains("SOLOMON ISLANDS")){NationalityCode="SLB";}
		else if(Nationality.contains("SOMALIA")){NationalityCode="SOM";}
		else if(Nationality.contains("SOUTH AFRICA")){NationalityCode="ZAF";}
		else if(Nationality.contains("SOUTH GEORGIA,SANDWICH ISLAND")){NationalityCode="SGS";}
		else if(Nationality.contains("SOUTH SUDAN")){NationalityCode="SSD";}
		else if(Nationality.contains("SPAIN")){NationalityCode="ESP";}
		else if(Nationality.contains("SRI LANKA")){NationalityCode="LKA";}
		else if(Nationality.contains("STHELENA ASCENSN TRISTANCUNHA")){NationalityCode="SHN";}
		else if(Nationality.contains("SUDAN")){NationalityCode="SDN";}
		else if(Nationality.contains("SURINAME")){NationalityCode="SUR";}
		else if(Nationality.contains("SVALBARD AND JAN MAYEN")){NationalityCode="SJM";}
		else if(Nationality.contains("SWAZILAND")){NationalityCode="SWZ";}
		else if(Nationality.contains("SWEDEN")){NationalityCode="SWE";}
		else if(Nationality.contains("SWITZERLAND")){NationalityCode="CHE";}
		else if(Nationality.contains("SYRIAN ARAB REPUBLIC")){NationalityCode="SYR";}
		else if(Nationality.contains("TAIWAN")){NationalityCode="TWN";}
		else if(Nationality.contains("TAJIKISTAN")){NationalityCode="TJK";}
		else if(Nationality.contains("TANZANIA, UNITED REPUBLIC OF")){NationalityCode="TZA";}
		else if(Nationality.contains("THAILAND")){NationalityCode="THA";}
		else if(Nationality.contains("TIMOR-LESTE")){NationalityCode="TLS";}
		else if(Nationality.contains("TOGO")){NationalityCode="TGO";}
		else if(Nationality.contains("TOKELAU")){NationalityCode="TKL";}
		else if(Nationality.contains("TONGA")){NationalityCode="TON";}
		else if(Nationality.contains("TRINIDAD AND TOBAGO")){NationalityCode="TTO";}
		else if(Nationality.contains("TUNISIA")){NationalityCode="TUN";}
		else if(Nationality.contains("TURKEY")){NationalityCode="TUR";}
		else if(Nationality.contains("TURKMENISTAN")){NationalityCode="TKM";}
		else if(Nationality.contains("TURKS AND CAICOS ISLANDS")){NationalityCode="TCA";}
		else if(Nationality.contains("TUVALU")){NationalityCode="TUV";}
		else if(Nationality.contains("UGANDA")){NationalityCode="UGA";}
		else if(Nationality.contains("UKRAINE")){NationalityCode="UKR";}
		else if(Nationality.contains("UNITED ARAB EMIRATES")){NationalityCode="ARE";}
		else if(Nationality.contains("UNITED KINGDOM")){NationalityCode="GBR";}
		else if(Nationality.contains("UNITED STATES OF AMERICA")){NationalityCode="USA";}
		else if(Nationality.contains("UNITED STATES OUTLYING ISLAND")){NationalityCode="UMI";}
		else if(Nationality.contains("URUGUAY")){NationalityCode="URY";}
		else if(Nationality.contains("UZBEKISTAN")){NationalityCode="UZB";}
		else if(Nationality.contains("VANUATU")){NationalityCode="VUT";}
		else if(Nationality.contains("HOLY SEE")){NationalityCode="VAT";}
		else if(Nationality.contains("VENEZUELA, BOLIVARIAN REP OF")){NationalityCode="VEN";}
		else if(Nationality.contains("VIETNAM")){NationalityCode="VNM";}
		else if(Nationality.contains("VIRGIN ISLANDS, BRITISH")){NationalityCode="VGB";}
		else if(Nationality.contains("VIRGIN ISLANDS, U.S.")){NationalityCode="VIR";}
		else if(Nationality.contains("WALLIS AND FUTUNA")){NationalityCode="WLF";}
		else if(Nationality.contains("WESTERN SAHARA")){NationalityCode="ESH";}
		else if(Nationality.contains("YEMEN")){NationalityCode="YEM";}
		else if(Nationality.contains("ZAMBIA")){NationalityCode="ZMB";}
		else if(Nationality.contains("ZIMBABWE")){NationalityCode="ZWE";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Nationality = ("+Nationality+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return NationalityCode;
	}

	public static String getProfileTypeCode(String DB_ProfileType) {
		//	String ProfileType=DBUtils.readColumnWithRowIDNew(DB_ProfileType, GetCase.scenarioID);
		String ProfileType=DB_ProfileType;
		String ProfileTypeCode="";
		if(ProfileType.contains("CLIENT")){ProfileTypeCode="CLT";}
		else if(ProfileType.contains("RELATED PARTY")){ProfileTypeCode="RPT";}
		else if(ProfileType.contains("NON-CLIENT")){ProfileTypeCode="NON";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Nationality = ("+ProfileType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}
		return ProfileTypeCode;
	}

	public static String getISICDesc(String DB_ISICDesc) {
		String ISICDesc=""+DBUtils.readColumnWithRowIDNew(DB_ISICDesc, GetCase.scenarioID);
		String ISICCode="";

		if(ISICDesc.contains("ART, ENTERTAINMENT, RECREATION & SPORTS")){ISICCode="RS01";}
		else if(ISICDesc.contains("NIGHTLIFE, GAMING AND GAMBLING")){ISICCode="RS02";}
		else if(ISICDesc.contains("INVESTMENT &  SECURITIES")){ISICCode="RS03";}
		else if(ISICDesc.contains("INSURANCE")){ISICCode="RS04";}
		else if(ISICDesc.contains("MONEY SERVICES AND INSURANCE AGENTS")){ISICCode="RS05";}
		else if(ISICDesc.contains("BANKING, ACCOUNTING & FINANCE")){ISICCode="RS06";}
		else if(ISICDesc.contains("BUILDING SERVICES & CONSTRUCTION")){ISICCode="RS07";}
		else if(ISICDesc.contains("HOSPITALITY & TOURISM")){ISICCode="RS08";}
		else if(ISICDesc.contains("TRAVEL AGENTS")){ISICCode="RS09";}
		else if(ISICDesc.contains("EDUCATIONAL SERVICES")){ISICCode="RS10";}
		else if(ISICDesc.contains("CATERING, RESTAURANT & FOOD SERVICES")){ISICCode="RS11";}
		else if(ISICDesc.contains("HAWKERS & STALLHOLDERS")){ISICCode="RS12";}
		else if(ISICDesc.contains("LOCAL NON-PROFIT ORGANIZATION")){ISICCode="RS13";}
		else if(ISICDesc.contains("FOREIGN GOVTS, INTL./POLITICAL ORGANISATIONS")){ISICCode="RS14";}
		else if(ISICDesc.contains("LOCAL GOVERNMENT &  PUBLIC UTILITIES")){ISICCode="RS15";}
		else if(ISICDesc.contains("INFORMATION TECHNOLOGY")){ISICCode="RS16";}
		else if(ISICDesc.contains("TELECOMMUNICATION")){ISICCode="RS17";}
		else if(ISICDesc.contains("LEGAL SERVICES, ACCOUNTANTS & TRUST")){ISICCode="RS18";}
		else if(ISICDesc.contains("MANUFACTURING / INDUSTRIAL")){ISICCode="RS19";}
		else if(ISICDesc.contains("MANUFACTURING TOBACCO/LEATHER/CHEMICAL PRODUCTS")){ISICCode="RS20";}
		else if(ISICDesc.contains("DEFENCE AND WEAPONS")){ISICCode="RS21";}
		else if(ISICDesc.contains("MARKETING")){ISICCode="RS22";}
		else if(ISICDesc.contains("MEDIA & COMMUNICATION")){ISICCode="RS23";}
		else if(ISICDesc.contains("MEDICAL & HEALTH CARE SERVICES")){ISICCode="RS24";}
		else if(ISICDesc.contains("PERSONAL SERVICES, RETAIL & WHOLESALE")){ISICCode="RS25";}
		else if(ISICDesc.contains("RETAIL JEWELRY, TOBACCO IMPORT AND EXPORT")){ISICCode="RS26";}
		else if(ISICDesc.contains("PRECIOUS METALS AND DIAMONDS")){ISICCode="RS27";}
		else if(ISICDesc.contains("PROPERTY MANAGEMENT & REAL ESTATE")){ISICCode="RS28";}
		else if(ISICDesc.contains("PUBLIC TRANSPORTATION & LOGISTIC")){ISICCode="RS29";}
		else if(ISICDesc.contains("LOGGING")){ISICCode="RS30";}
		else if(ISICDesc.contains("EMPLOYMENT AGENCIES")){ISICCode="RS31";}
		else if(ISICDesc.contains("AGRICULTURE AND FISHING")){ISICCode="RS32";}
		else if(ISICDesc.contains("FORESTRY")){ISICCode="RS33";}
		else if(ISICDesc.contains("OIL, GAS AND MINING INDUSTRY")){ISICCode="RS34";}
		else if(ISICDesc.contains("Speciality")){ISICCode="RS35";}
		else if(ISICDesc.contains("Textile")){ISICCode="RS36";}
		else if(ISICDesc.contains("Automobile")){ISICCode="RS37";}
		else if(ISICDesc.contains("Chemical Products")){ISICCode="RS38";}
		else if(ISICDesc.equalsIgnoreCase("OTHER")){ISICCode="9998";}

		else{logger.info(">>>>>ERROR: ISICDesc = ("+ISICDesc+")  does not matches with any Options<<<<<<<");ISICCode=ISICDesc;}

		return ISICCode;
	}

	public static String getAliasTypeCode(String DB_AliasType)
	{

		String AliasType=DBUtils.readColumnWithRowIDNew(DB_AliasType, GetCase.scenarioID);
		String AliasTypeCode="";
		if(AliasType.contains("AKA (also known as)") || AliasType.equalsIgnoreCase("AKA")){AliasTypeCode="AKA";}
		else if(AliasType.contains("Previous Name") || AliasType.equalsIgnoreCase("PNM")){AliasTypeCode="PNM";}
		else if(AliasType.contains("CCMS Relationship Name") || AliasType.equalsIgnoreCase("CRN")){AliasTypeCode="CRN";}
		else if(AliasType.contains("RLS Relationship Name") || AliasType.equalsIgnoreCase("RRN")){AliasTypeCode="RRN";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: AliasType = ("+AliasType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return AliasTypeCode;
	}

	public static String getContactTypeCode(String DB_ContactType)
	{

		String ContactType=DBUtils.readColumnWithRowIDNew(DB_ContactType, GetCase.scenarioID);
		String ContactTypeCode="";
		if(ContactType.contains("FOR EMAIL CONTACT")){ContactTypeCode="COL";}
		else if(ContactType.contains("Office Telephone No.-12")){ContactTypeCode="OTC";}
		else if(ContactType.contains("Office Telephone No.-11")){ContactTypeCode="OTB";}
		else if(ContactType.contains("Office Telephone No.-10")){ContactTypeCode="OTA";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM6";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM5";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM4";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM3";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM2";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EM1";}
		else if(ContactType.contains("Personal email address 3")){ContactTypeCode="RE3";}
		else if(ContactType.contains("Personal email address 2")){ContactTypeCode="RE2";}
		else if(ContactType.contains("Personal email address 1")){ContactTypeCode="RE1";}
		else if(ContactType.contains("SWIFT SCB 950")){ContactTypeCode="SW5";}
		else if(ContactType.contains("SWIFT  SCB 940")){ContactTypeCode="SW4";}
		else if(ContactType.contains("Email ID - eStatement")){ContactTypeCode="EMS";}
		else if(ContactType.contains("Swift Advice Address")){ContactTypeCode="SWA";}
		else if(ContactType.contains("Conversion Default")){ContactTypeCode="ZZZ";}
		else if(ContactType.contains("Tel for Call back Auth.Personnel")){ContactTypeCode="TCB";}
		else if(ContactType.contains("Swift MT942S")){ContactTypeCode="SWF";}
		else if(ContactType.contains("Pager No.")){ContactTypeCode="PGR";}
		else if(ContactType.contains("Web Address")){ContactTypeCode="WAD";}
		else if(ContactType.contains("Email ID E-ST Exception")){ContactTypeCode="ERR";}
		else if(ContactType.contains("Mobile No.-9")){ContactTypeCode="MO9";}
		else if(ContactType.contains("Mobile No.-8")){ContactTypeCode="MO8";}
		else if(ContactType.contains("Mobile No.-7")){ContactTypeCode="MO7";}
		else if(ContactType.contains("Mobile No.-6")){ContactTypeCode="MO6";}
		else if(ContactType.contains("Mobile No.-5")){ContactTypeCode="MO5";}
		else if(ContactType.contains("Mobile No.-4")){ContactTypeCode="MO4";}
		else if(ContactType.contains("Office Fax No.-4")){ContactTypeCode="OF4";}
		else if(ContactType.contains("Office Fax No.-3")){ContactTypeCode="OF3";}
		else if(ContactType.contains("Office Telephone No.-9")){ContactTypeCode="OT9";}
		else if(ContactType.contains("Office Telephone No.-8")){ContactTypeCode="OT8";}
		else if(ContactType.contains("Office Telephone No.-7")){ContactTypeCode="OT7";}
		else if(ContactType.contains("Office Telephone No.-6")){ContactTypeCode="OT6";}
		else if(ContactType.contains("Office Telephone No.-5")){ContactTypeCode="OT5";}
		else if(ContactType.contains("Office Telephone No.-4")){ContactTypeCode="OT4";}
		else if(ContactType.contains("Residence Telephone No-9")){ContactTypeCode="RT9";}
		else if(ContactType.contains("Residence Telephone No-8")){ContactTypeCode="RT8";}
		else if(ContactType.contains("Residence Telephone No-7")){ContactTypeCode="RT7";}
		else if(ContactType.contains("Residence Telephone No-6")){ContactTypeCode="RT6";}
		else if(ContactType.contains("Residence Telephone No-5")){ContactTypeCode="RT5";}
		else if(ContactType.contains("Residence Telephone No-4")){ContactTypeCode="RT4";}
		else if(ContactType.contains("Official Email Address 1")){ContactTypeCode="OE1";}
		else if(ContactType.contains("Official Email Address 2")){ContactTypeCode="OE2";}
		else if(ContactType.contains("Official Email Address 3")){ContactTypeCode="OE3";}
		else if(ContactType.contains("Regst Office Telephone No.-1")){ContactTypeCode="OT1";}
		else if(ContactType.contains("Office Telephone No.-2")){ContactTypeCode="OT2";}
		else if(ContactType.contains("Office Telephone No.-3")){ContactTypeCode="OT3";}
		else if(ContactType.contains("Regst- Res Telephone No.-1")){ContactTypeCode="RT1";}
		else if(ContactType.contains("Residence Telephone No.-2")){ContactTypeCode="RT2";}
		else if(ContactType.contains("Residence Telephone No-3")){ContactTypeCode="RT3";}
		else if(ContactType.contains("Regst- Office Fax No.-1")){ContactTypeCode="OF1";}
		else if(ContactType.contains("Office Fax No.-2")){ContactTypeCode="OF2";}
		else if(ContactType.contains("Fax no. With indemnity")){ContactTypeCode="INF";}
		else if(ContactType.contains("Residence Fax No.")){ContactTypeCode="FRS";}
		else if(ContactType.contains("Regst- Mobile No.-1")){ContactTypeCode="MO1";}
		else if(ContactType.contains("Mobile No.-2")){ContactTypeCode="MO2";}
		else if(ContactType.contains("Mobile No.-3")){ContactTypeCode="MO3";}
		else if(ContactType.contains("3rd party contact")){ContactTypeCode="PPN";}
		else if(ContactType.contains("Official Email Address")){ContactTypeCode="EMO";}
		else if(ContactType.contains("Personal Email Address")){ContactTypeCode="EMR";}
		else if(ContactType.contains("SWIFT  SCB 940")){ContactTypeCode="SW6";}
		else if(ContactType.contains("SWIFT SCB 950")){ContactTypeCode="SW7";}
		else if(ContactType.contains("Telephone No.-1")){ContactTypeCode="LT1";}
		else if(ContactType.contains("Telephone No.-2")){ContactTypeCode="LT2";}
		else if(ContactType.contains("Telephone No.-3")){ContactTypeCode="LT3";}
		else if(ContactType.contains("Telephone No.-4")){ContactTypeCode="LT4";}
		else if(ContactType.contains("Mobile No-1")){ContactTypeCode="MT1";}
		else if(ContactType.contains("Mobile No-2")){ContactTypeCode="MT2";}
		else if(ContactType.contains("Mobile No-3")){ContactTypeCode="MT3";}
		else if(ContactType.contains("Mobile No-4")){ContactTypeCode="MT4";}
		else if(ContactType.contains("OFF Telephone No-4")){ContactTypeCode="LO4";}
		else if(ContactType.contains("OFF Telephone No-2")){ContactTypeCode="LO2";}
		else if(ContactType.contains("OFF Telephone No-3")){ContactTypeCode="LO3";}
		else if(ContactType.contains("Office eMAILID-1")){ContactTypeCode="LM1";}
		else if(ContactType.contains("Office eMAILID-2")){ContactTypeCode="LM2";}
		else if(ContactType.contains("Office eMAILID-3")){ContactTypeCode="LM3";}
		else if(ContactType.contains("Office eMAILID-3")){ContactTypeCode="LM4";}
		else if(ContactType.contains("eMAILID-1")){ContactTypeCode="LR1";}
		else if(ContactType.contains("eMAILID-2")){ContactTypeCode="LR2";}
		else if(ContactType.contains("eMAILID-3")){ContactTypeCode="LR3";}
		else if(ContactType.contains("eMAILID-4")){ContactTypeCode="LR4";}
		else if(ContactType.contains("OFF Telephone No-1")){ContactTypeCode="LO1";}
		else if(ContactType.contains("Telephone No.-5")){ContactTypeCode="LT5";}
		else if(ContactType.contains("NSC Swfit BIC Code")){ContactTypeCode="NSC";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: ContactType = ("+ContactType+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return ContactTypeCode;
	}

	public static String getRelatedParty(String RelatedParty)
	{

//		String RelatedParty=DBUtils.readColumnWithRowIDNew(DB_RelatedParty, GetCase.scenarioID);
		String RelatedPartyCode="";

		if(RelatedParty.contains("Primary")){RelatedPartyCode="PRI";}
		else if(RelatedParty.contains("Joint")){RelatedPartyCode="JOT";}
		else if(RelatedParty.contains("Supplementary")){RelatedPartyCode="SUP";}
		else if(RelatedParty.contains("Borrower")){RelatedPartyCode="BOR";}
		else if(RelatedParty.contains("Co-Borrower")){RelatedPartyCode="COB";}
		else if(RelatedParty.contains("Guardian")){RelatedPartyCode="GUA";}
		else if(RelatedParty.contains("Power")){RelatedPartyCode="POA";}
		else if(RelatedParty.contains("Mandate Holders")){RelatedPartyCode="MH";}
		else if(RelatedParty.contains("Nominee")){RelatedPartyCode="NOM";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: RelatedParty = ("+RelatedParty+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");}

		return RelatedPartyCode;
	}

	public static String Serviceindicator(String DB_ServiceindicatorCode)
	{

		String ServiceindicatorCode=DBUtils.readColumnWithRowIDNew(DB_ServiceindicatorCode, GetCase.scenarioID);

		String Serviceindicator="";

		if(ServiceindicatorCode.contains("SME ELITE")){Serviceindicator="39";}
		else if(ServiceindicatorCode.contains("Special Customer")){Serviceindicator="78";}
		else if(ServiceindicatorCode.contains("Sensitive Client")){Serviceindicator="15";}
		else if(ServiceindicatorCode.contains("Others")){Serviceindicator="16";}
		else if(ServiceindicatorCode.contains("Priority Banking- VIP")){Serviceindicator="22";}
		else if(ServiceindicatorCode.contains("Priority Banking- Celebrity")){Serviceindicator="23";}
		else if(ServiceindicatorCode.contains("Private Banking-VIP")){Serviceindicator="24";}
		else if(ServiceindicatorCode.contains("Private Banking -Celebrity")){Serviceindicator="25";}
		else if(ServiceindicatorCode.contains("VIP")){Serviceindicator="02";}
		else if(ServiceindicatorCode.contains("Priority Banking")){Serviceindicator="05";}
		else if(ServiceindicatorCode.contains("Private Banking")){Serviceindicator="07";}
		else if(ServiceindicatorCode.contains("Troubled Customer")){Serviceindicator="11";}
		else if(ServiceindicatorCode.contains("Wholesale Banking -Platinum customer")){Serviceindicator="12";}
		else if(ServiceindicatorCode.contains("Wholesale Banking -Gold customer")){Serviceindicator="13";}
		else if(ServiceindicatorCode.contains("Whole sale banking- Core customer")){Serviceindicator="14";}
		else if(ServiceindicatorCode.contains("NPA SELL DOWN ACCOUNT")){Serviceindicator="55";}


		return Serviceindicator;
	}


	public static String getAddressesType(String DB_AddressesType)
	{

		String AddressesType=""+DBUtils.readColumnWithRowIDNew(DB_AddressesType, GetCase.scenarioID);
		String AddressesTypeCode="";
		if(AddressesType.contains("Card Mailing Address")){AddressesTypeCode="CAI";}
		else if(AddressesType.contains("Mailing address65")){AddressesTypeCode="Z65";}
		else if(AddressesType.contains("Mailing address64")){AddressesTypeCode="Z64";}
		else if(AddressesType.contains("Mailing address63")){AddressesTypeCode="Z63";}
		else if(AddressesType.contains("Mailing address (Additional) 6")){AddressesTypeCode="Z0F";}
		else if(AddressesType.contains("Mailing address (Additional) 5")){AddressesTypeCode="Z0E";}
		else if(AddressesType.contains("Mailing address (Additional) 4")){AddressesTypeCode="Z0D";}
		else if(AddressesType.contains("Mailing address (Additional) 3")){AddressesTypeCode="Z0C";}
		else if(AddressesType.contains("Mailing address (Additional) 2")){AddressesTypeCode="Z0B";}
		else if(AddressesType.contains("Mailing address (Additional) 1")){AddressesTypeCode="Z0A";}
		else if(AddressesType.contains("A13 TDC  Address")){AddressesTypeCode="TDS";}
		else if(AddressesType.contains("A22 SCB Group Co. premises address for staff")){AddressesTypeCode="STF";}
		else if(AddressesType.contains("A1 Residence Address")){AddressesTypeCode="RES";}
		else if(AddressesType.contains("A21 Registered Address of Parent Company")){AddressesTypeCode="REP";}
		else if(AddressesType.contains("Property Address")){AddressesTypeCode="PRP";}
		else if(AddressesType.contains("A13 Permanent Address")){AddressesTypeCode="PER";}
		else if(AddressesType.contains("Mailing address62")){AddressesTypeCode="Z62";}
		else if(AddressesType.contains("A12 Office Address")){AddressesTypeCode="OFF";}
		else if(AddressesType.contains("Office Address 1")){AddressesTypeCode="OF1";}
		else if(AddressesType.contains("Mailing Address of Parent Company")){AddressesTypeCode="MPC";}
		else if(AddressesType.contains("Loan Advice Address")){AddressesTypeCode="LOA";}
		else if(AddressesType.contains("Address for Collections")){AddressesTypeCode="COL";}
		else if(AddressesType.contains("Mailing address86")){AddressesTypeCode="Z86";}
		else if(AddressesType.contains("Mailing address85")){AddressesTypeCode="Z85";}
		else if(AddressesType.contains("Mailing address84")){AddressesTypeCode="Z84";}
		else if(AddressesType.contains("Mailing address83")){AddressesTypeCode="Z83";}
		else if(AddressesType.contains("Mailing address82")){AddressesTypeCode="Z82";}
		else if(AddressesType.contains("Mailing address81")){AddressesTypeCode="Z81";}
		else if(AddressesType.contains("Mailing address80")){AddressesTypeCode="Z80";}
		else if(AddressesType.contains("Mailing address79")){AddressesTypeCode="Z79";}
		else if(AddressesType.contains("Mailing address78")){AddressesTypeCode="Z78";}
		else if(AddressesType.contains("Mailing address77")){AddressesTypeCode="Z77";}
		else if(AddressesType.contains("Mailing address76")){AddressesTypeCode="Z76";}
		else if(AddressesType.contains("Mailing address75")){AddressesTypeCode="Z75";}
		else if(AddressesType.contains("Mailing address74")){AddressesTypeCode="Z74";}
		else if(AddressesType.contains("Mailing address73")){AddressesTypeCode="Z73";}
		else if(AddressesType.contains("Mailing address72")){AddressesTypeCode="Z72";}
		else if(AddressesType.contains("Mailing address71")){AddressesTypeCode="Z71";}
		else if(AddressesType.contains("Mailing address70")){AddressesTypeCode="Z70";}
		else if(AddressesType.contains("Mailing address69")){AddressesTypeCode="Z69";}
		else if(AddressesType.contains("Mailing address68")){AddressesTypeCode="Z68";}
		else if(AddressesType.contains("Mailing address67")){AddressesTypeCode="Z67";}
		else if(AddressesType.contains("Mailing address66")){AddressesTypeCode="Z66";}
		else if(AddressesType.contains("Mailing address36")){AddressesTypeCode="Z36";}
		else if(AddressesType.contains("Conversion Default")){AddressesTypeCode="ZZZ";}
		else if(AddressesType.contains("Cashier Order Address")){AddressesTypeCode="COA";}
		else if(AddressesType.contains("A20 Locker Advice Address")){AddressesTypeCode="LAA";}
		else if(AddressesType.contains("SI Trf Advice Address")){AddressesTypeCode="SAA";}
		else if(AddressesType.contains("Mailing address37")){AddressesTypeCode="Z37";}
		else if(AddressesType.contains("Mailing address38")){AddressesTypeCode="Z38";}
		else if(AddressesType.contains("Mailing address39")){AddressesTypeCode="Z39";}
		else if(AddressesType.contains("Mailing address40")){AddressesTypeCode="Z40";}
		else if(AddressesType.contains("Mailing address41")){AddressesTypeCode="Z41";}
		else if(AddressesType.contains("Mailing address42")){AddressesTypeCode="Z42";}
		else if(AddressesType.contains("Mailing address43")){AddressesTypeCode="Z43";}
		else if(AddressesType.contains("Mailing address44")){AddressesTypeCode="Z44";}
		else if(AddressesType.contains("Mailing address45")){AddressesTypeCode="Z45";}
		else if(AddressesType.contains("Mailing address46")){AddressesTypeCode="Z46";}
		else if(AddressesType.contains("Mailing address47")){AddressesTypeCode="Z47";}
		else if(AddressesType.contains("Mailing address48")){AddressesTypeCode="Z48";}
		else if(AddressesType.contains("Mailing address49")){AddressesTypeCode="Z49";}
		else if(AddressesType.contains("Mailing address50")){AddressesTypeCode="Z50";}
		else if(AddressesType.contains("Mailing address51")){AddressesTypeCode="Z51";}
		else if(AddressesType.contains("Mailing address52")){AddressesTypeCode="Z52";}
		else if(AddressesType.contains("Mailing address53")){AddressesTypeCode="Z53";}
		else if(AddressesType.contains("Mailing address27")){AddressesTypeCode="ZA1";}
		else if(AddressesType.contains("Mailing address28")){AddressesTypeCode="ZA2";}
		else if(AddressesType.contains("Mailing address29")){AddressesTypeCode="ZA3";}
		else if(AddressesType.contains("Mailing address30")){AddressesTypeCode="ZA4";}
		else if(AddressesType.contains("Mailing address31")){AddressesTypeCode="ZA5";}
		else if(AddressesType.contains("Mailing address32")){AddressesTypeCode="ZA6";}
		else if(AddressesType.contains("Mailing address33")){AddressesTypeCode="ZA7";}
		else if(AddressesType.contains("Mailing address34")){AddressesTypeCode="ZA8";}
		else if(AddressesType.contains("Mailing address35")){AddressesTypeCode="ZA9";}
		else if(AddressesType.contains("A15 Mailing address1")){AddressesTypeCode="ZAA";}
		else if(AddressesType.contains("A16 Mailing address2")){AddressesTypeCode="ZAB";}
		else if(AddressesType.contains("A17 Mailing address3")){AddressesTypeCode="ZAC";}
		else if(AddressesType.contains("A18 Mailing address4")){AddressesTypeCode="ZAD";}
		else if(AddressesType.contains("Mailing address5")){AddressesTypeCode="ZAE";}
		else if(AddressesType.contains("Mailing address6")){AddressesTypeCode="ZAF";}
		else if(AddressesType.contains("Mailing address7")){AddressesTypeCode="ZAG";}
		else if(AddressesType.contains("Mailing address8")){AddressesTypeCode="ZAH";}
		else if(AddressesType.contains("Mailing address9")){AddressesTypeCode="ZAI";}
		else if(AddressesType.contains("Mailing address10")){AddressesTypeCode="ZAJ";}
		else if(AddressesType.contains("Mailing address11")){AddressesTypeCode="ZAK";}
		else if(AddressesType.contains("Mailing address12")){AddressesTypeCode="ZAL";}
		else if(AddressesType.contains("Mailing address13")){AddressesTypeCode="ZAM";}
		else if(AddressesType.contains("Mailing address14")){AddressesTypeCode="ZAN";}
		else if(AddressesType.contains("Mailing address15")){AddressesTypeCode="ZAO";}
		else if(AddressesType.contains("Mailing address54")){AddressesTypeCode="Z54";}
		else if(AddressesType.contains("Mailing address55")){AddressesTypeCode="Z55";}
		else if(AddressesType.contains("Mailing address56")){AddressesTypeCode="Z56";}
		else if(AddressesType.contains("Mailing address57")){AddressesTypeCode="Z57";}
		else if(AddressesType.contains("Mailing address58")){AddressesTypeCode="Z58";}
		else if(AddressesType.contains("Mailing address59")){AddressesTypeCode="Z59";}
		else if(AddressesType.contains("Mailing address60")){AddressesTypeCode="Z60";}
		else if(AddressesType.contains("Mailing address61")){AddressesTypeCode="Z61";}
		else if(AddressesType.contains("Mailing address22")){AddressesTypeCode="ZAV";}
		else if(AddressesType.contains("Mailing address23")){AddressesTypeCode="ZAW";}
		else if(AddressesType.contains("Mailing address24")){AddressesTypeCode="ZAX";}
		else if(AddressesType.contains("Mailing address25")){AddressesTypeCode="ZAY";}
		else if(AddressesType.contains("Mailing address26")){AddressesTypeCode="ZAZ";}
		else if(AddressesType.contains("Mailing address16")){AddressesTypeCode="ZAP";}
		else if(AddressesType.contains("Mailing address17")){AddressesTypeCode="ZAQ";}
		else if(AddressesType.contains("Mailing address18")){AddressesTypeCode="ZAR";}
		else if(AddressesType.contains("Mailing address19")){AddressesTypeCode="ZAS";}
		else if(AddressesType.contains("Mailing address20")){AddressesTypeCode="ZAT";}
		else if(AddressesType.contains("Mailing address21")){AddressesTypeCode="ZAU";}
		else if(AddressesType.contains("Alternate Contact")){AddressesTypeCode="ALC";}
		else if(AddressesType.contains("A19 Chartered Accountant Address")){AddressesTypeCode="CHA";}
		else if(AddressesType.contains("A14 Consolidated Statement Address")){AddressesTypeCode="CST";}
		else if(AddressesType.contains("A14 Legal/Registered Address")){AddressesTypeCode="LEG";}
		else if(AddressesType.contains("Default address type")){AddressesTypeCode="999";}
		else if(AddressesType.contains("Lords Conversion")){AddressesTypeCode="LOG";}
		else if(AddressesType.contains("Guarantor & mailing address")){AddressesTypeCode="LGM";}
		else if(AddressesType.contains("Office address")){AddressesTypeCode="LOF";}
		else if(AddressesType.contains("Mailing address")){AddressesTypeCode="LMA";}
		else if(AddressesType.contains("Office Address & mailing address")){AddressesTypeCode="LOM";}
		else if(AddressesType.contains("Lords Conversion")){AddressesTypeCode="LRS";}
		else if(AddressesType.contains("Permanent Address")){AddressesTypeCode="LPR";}
		else if(AddressesType.contains("Permanent &  mailing address")){AddressesTypeCode="LPM";}
		else if(AddressesType.contains("Residence & mailing address")){AddressesTypeCode="LRM";}
		else if(AddressesType.contains("Office1")){AddressesTypeCode="LO1";}
		else if(AddressesType.contains("Office2")){AddressesTypeCode="LO2";}
		else if(AddressesType.contains("Office3")){AddressesTypeCode="LO3";}
		else if(AddressesType.contains("Permanent1")){AddressesTypeCode="LP1";}
		else if(AddressesType.contains("Permanent2")){AddressesTypeCode="LP2";}
		else if(AddressesType.contains("Permanent3")){AddressesTypeCode="LP3";}
		else if(AddressesType.contains("Registered Address1")){AddressesTypeCode="LR1";}
		else if(AddressesType.contains("Registered Address2")){AddressesTypeCode="LR2";}
		else if(AddressesType.contains("ISMAIl ADDRESS")){AddressesTypeCode="MAI";}
		else if(AddressesType.contains("Office3")){AddressesTypeCode="LO4";}
		else if(AddressesType.contains("Registered Address3")){AddressesTypeCode="LR3";}
		else if(AddressesType.contains("Registered Address4")){AddressesTypeCode="LR4";}
		else if(AddressesType.contains("Hold Mail Address")){AddressesTypeCode="HMA";}
		else if(AddressesType.contains("The Field Contains AddressTyepe")){AddressesTypeCode="HOM";}
		else if(AddressesType.contains("RLS Account Address")){AddressesTypeCode="COR";}
		else if(AddressesType.contains("Hold Mail Address")){AddressesTypeCode="HMA";}
		else if(AddressesType.contains("The Field Contains AddressTyepe")){AddressesTypeCode="HOM";}
		else if(AddressesType.contains("RLS Account Address")){AddressesTypeCode="COR";}
		else if(AddressesType.contains("null")){logger.info("DB has null Value under "+AddressesType);}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: AddressesType = ("+AddressesType+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			AddressesTypeCode=AddressesType;}

		return AddressesTypeCode;
	}


	public static String getStateCode(String DB_State)
	{

		String State=""+DBUtils.readColumnWithRowIDNew(DB_State, GetCase.scenarioID);
		String StateCode="";
		if(State.toUpperCase().contains("ANDAMAN AND NICOBAR ISLANDS")){StateCode="AN";}
		else if(State.toUpperCase().contains("ANDHRA PRADESH")){StateCode="AP";}
		else if(State.toUpperCase().contains("ARUNACHAL PRADESH")){StateCode="AR";}
		else if(State.toUpperCase().contains("ASSAM")){StateCode="AS";}
		else if(State.toUpperCase().contains("BIHAR")){StateCode="BR";}
		else if(State.toUpperCase().contains("CHANDIGARH")){StateCode="CH";}
		else if(State.toUpperCase().contains("CHATTISGARH")){StateCode="CG";}
		else if(State.toUpperCase().contains("DADRA AND NAGAR HAVELI")){StateCode="DN";}
		else if(State.toUpperCase().contains("DAMAN AND DIU")){StateCode="DD";}
		else if(State.toUpperCase().contains("DELHI")){StateCode="DL";}
		else if(State.toUpperCase().contains("GOA")){StateCode="GA";}
		else if(State.toUpperCase().contains("GUJARAT")){StateCode="GJ";}
		else if(State.toUpperCase().contains("HARYANA")){StateCode="HR";}
		else if(State.toUpperCase().contains("HIMACHAL PRADESH")){StateCode="HP";}
		else if(State.toUpperCase().contains("JAMMU AND KASHMIR")){StateCode="JK";}
		else if(State.toUpperCase().contains("JHARKHAND")){StateCode="JH";}
		else if(State.toUpperCase().contains("KARNATAKA")){StateCode="KA";}
		else if(State.toUpperCase().contains("KERALA")){StateCode="KL";}
		else if(State.toUpperCase().contains("LAKSHADWEEP ISLANDS")){StateCode="LD";}
		else if(State.toUpperCase().contains("MADHYA PRADESH")){StateCode="MP";}
		else if(State.toUpperCase().contains("MAHARASHTRA")){StateCode="MH";}
		else if(State.toUpperCase().contains("MANIPUR")){StateCode="MN";}
		else if(State.toUpperCase().contains("MEGHALAYA")){StateCode="ML";}
		else if(State.toUpperCase().contains("MIZORAM")){StateCode="MZ";}
		else if(State.toUpperCase().contains("NAGALAND")){StateCode="NL";}
		else if(State.toUpperCase().contains("ODISHA")){StateCode="OR";}
		else if(State.toUpperCase().contains("PONDICHERRY")){StateCode="PY";}
		else if(State.toUpperCase().contains("PUNJAB")){StateCode="PB";}
		else if(State.toUpperCase().contains("RAJASTHAN")){StateCode="RJ";}
		else if(State.toUpperCase().contains("SIKKIM")){StateCode="SK";}
		else if(State.toUpperCase().contains("TAMIL NADU")){StateCode="TN";}
		else if(State.toUpperCase().contains("TELANGANA")){StateCode="TS";}
		else if(State.toUpperCase().contains("TRIPURA")){StateCode="TR";}
		else if(State.toUpperCase().contains("UTTAR PRADESH")){StateCode="UP";}
		else if(State.toUpperCase().contains("UTTARAKHAND")){StateCode="UA";}
		else if(State.toUpperCase().contains("WEST BENGAL")){StateCode="WB";}
		else if(State.contains("null")){logger.info("DB has null Value under "+State);}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: State = ("+State+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");StateCode=State;}

		return StateCode;
	}

	public static String getMarketingPreferencesCode(String DB_MarketingPreferences)
	{

		String MarketingPreferences=""+DBUtils.readColumnWithRowIDNew(DB_MarketingPreferences, GetCase.scenarioID);
		String MarketingPreferencesCode="";
		if(MarketingPreferences.contains("Okay to Call") || MarketingPreferences.contains("AND") ){MarketingPreferencesCode="AND";}
		else if(MarketingPreferences.contains("Not Okay to Call") || MarketingPreferences.contains("ANN")){MarketingPreferencesCode="ANN";}
		else if(MarketingPreferences.contains("Not Okay to eMail") || MarketingPreferences.contains("EMD")){MarketingPreferencesCode="EMD";}
		else if(MarketingPreferences.contains("Not Okay to SMS") || MarketingPreferences.contains("SMD")){MarketingPreferencesCode="SMD";}
		else if(MarketingPreferences.contains("Ok to eMail") || MarketingPreferences.contains("EMK")){MarketingPreferencesCode="EMK";}
		else if(MarketingPreferences.contains("Ok to SMS") || MarketingPreferences.contains("SMK")){MarketingPreferencesCode="SMK";}
		else if(MarketingPreferences.contains("D-DND") || MarketingPreferences.contains("DND")){MarketingPreferencesCode="DND";}
		else if(MarketingPreferences.contains("Bank Initiated DND") || MarketingPreferences.contains("NDN")){MarketingPreferencesCode="NDN";}
		else if(MarketingPreferences.contains("Customer has not choosen") || MarketingPreferences.contains("YDN")){MarketingPreferencesCode="YDN";}
		else if(MarketingPreferences.contains("null")){logger.info("DB has null Value under in "+DB_MarketingPreferences);}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: MarketingPreferences = ("+MarketingPreferences+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");MarketingPreferencesCode=MarketingPreferences;}

		return MarketingPreferencesCode;
	}


	public static String Cardtype(String DB_DebitType)
	{
		String DebitType=""+DBUtils.readColumnWithRowIDNew(DB_DebitType, GetCase.scenarioID);
		String CardType="";

		if(DebitType.contains("CBP-Cash back platinum")){CardType="CBP";}
		else if(DebitType.contains("CCI-Preferred platinum")){CardType="CCI";}
		else if(DebitType.contains("IPI-Infinite Platinum debit card")){CardType="IPI";}
		else if(DebitType.contains("MCP-Master card platinum")){CardType="MCP";}
		else if(DebitType.contains("MLC-ATM CARD")){CardType="MLC";}
		else if(DebitType.contains("MVI-GMM Platinum")){CardType="MVI";}
		else if(DebitType.contains("NTR-Not Reqd")){CardType="NTR";}
		else if(DebitType.contains("OTH-Others")){CardType="OTH";}
		else if(DebitType.contains("PRE-NRE Preferred platinum")){CardType="PRE";}
		else if(DebitType.contains("PRN-NRO Preferred platinum")){CardType="PRN";}
		else if(DebitType.contains("PVE-NRE Priority platinum")){CardType="PVE";}
		else if(DebitType.contains("PVN-NRO Priority platinum")){CardType="PVN";}
		else if(DebitType.contains("SVI-Smart banking platinum")){CardType="SVI";}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: DebitType = ("+DebitType+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");CardType=DebitType;}
		return CardType;
	}

	public static String SegmentCode(String DBCloumn_ARMCode)
	{
		String ARMCode=""+DBUtils.readColumnWithRowIDNew(DBCloumn_ARMCode, GetCase.scenarioID);

		String SegmentCode="";
		if(ARMCode.toUpperCase().contains("RAB")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("O51")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("SMF")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("SGV")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XEN")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XF0")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XE4")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XH3")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("N91")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XF3")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("XH3")){SegmentCode="35";}
		else if(ARMCode.toUpperCase().contains("NZ0")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("X7T")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("NN2")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("OX2")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("XQ1")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("NW7")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("NQA")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("XQ2")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("XRZ")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("OQJ")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("XQ2")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("XRF")){SegmentCode="38";}
		else if(ARMCode.toUpperCase().contains("NK9")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("N4A")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("NL1")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("R71")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("N5U")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("NXM")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("N5R")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("N4C")){SegmentCode="41";}
		else if(ARMCode.toUpperCase().contains("N1C")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("X9V")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("X6V")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N1H")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("X2X")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N2G")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N2E")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N2D")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N2F")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("X1X")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("N2D")){SegmentCode="55";}
		else if(ARMCode.toUpperCase().contains("R17")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("NSO")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("NYY")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("N4T")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("RQ9")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("NB5")){SegmentCode="57";}
		else if(ARMCode.toUpperCase().contains("N5Q")){SegmentCode="62";}
		else if(ARMCode.toUpperCase().contains("N5W")){SegmentCode="62";}
		else if(ARMCode.toUpperCase().contains("N5V")){SegmentCode="62";}
		else if(ARMCode.toUpperCase().contains("NB5")){SegmentCode="62";}
		else if(ARMCode.toUpperCase().contains("N5R")){SegmentCode="62";}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: ARMCode = ("+ARMCode+") does not matches with any Options<<<<<<<<<<<<<<<<<<<");SegmentCode=ARMCode;}
		return SegmentCode;
	}


	/////Product Tab
	public static String getAssessmentType(String DB_AssessmentType) {
		String AssessmentType=""+DBUtils.readColumnWithRowIDNew(DB_AssessmentType, GetCase.scenarioID);
		String AssessmentTypeValue="";

		if(AssessmentType.contains("Income")){AssessmentTypeValue="I";}
		else if(AssessmentType.contains("AUM")){AssessmentTypeValue="A";}
		else if(AssessmentType.contains("Income & AUM")){AssessmentTypeValue="IA";}
		else if(AssessmentType.contains("None (used for student / housewife category)")){AssessmentTypeValue="NN";}
		else if(AssessmentType.contains("Surrogate")){AssessmentTypeValue="SI";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: AssessmentType =("+AssessmentType+")not matches with any Options<<<<<<<<<<<<<<<<<<<");
			AssessmentTypeValue=AssessmentType;}
		return AssessmentTypeValue;

	}
	public static String getFrequency(String DB_Frequency) {
		String Frequency=DBUtils.readColumnWithRowIDNew(DB_Frequency, GetCase.scenarioID);
		String FrequencyValue="";
		if(Frequency.contains("Monthly")){FrequencyValue="M";}
		else if(Frequency.contains("Bi-Monthly")){FrequencyValue="BM";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Frequency = ("+Frequency+") not matches with any Options<<<<<<<<<<<<<<<<<<<");
			FrequencyValue=Frequency;}
		return FrequencyValue;
	}

	public static String getRepaymentAccountType(String DB_AccountType) {
		String RepaymentAccountType=DBUtils.readColumnWithRowIDNew(DB_AccountType, GetCase.scenarioID);
		String RepaymentAccountTypeValue="";
		if(RepaymentAccountType.contains("Savings Account")){RepaymentAccountTypeValue="SA";}
		else if(RepaymentAccountType.contains("Current Account")){RepaymentAccountTypeValue="CA";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Repayment Account Type= ("+RepaymentAccountType+") not matches with any Options<<<<<<<<<<<<<<<<<<<");
			RepaymentAccountTypeValue=RepaymentAccountType;}
		return RepaymentAccountTypeValue;
	}
	public static String getDisbursementmode(String DB_Disbursementmode) {
		String Disbursementmode=DBUtils.readColumnWithRowIDNew(DB_Disbursementmode, GetCase.scenarioID);
		String DisbursementmodeValue="";
		if(Disbursementmode.contains("Pay order")){DisbursementmodeValue="01";}
		else if(Disbursementmode.contains("Account credit")){DisbursementmodeValue="02";}
		else if(Disbursementmode.contains("RTGS")){DisbursementmodeValue="03";}
		else if(Disbursementmode.contains("NEFT")){DisbursementmodeValue="04";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: Disbursement mode=("+Disbursementmode+") not matches with any Options<<<<<<<<<<<<<<<<<<<");
			DisbursementmodeValue=Disbursementmode;}
		return DisbursementmodeValue;
	}
	public static String getPickUpMethod(String DB_PickUpMethod) {
		String PickUpMethod=DBUtils.readColumnWithRowIDNew(DB_PickUpMethod, GetCase.scenarioID);
		String PickUpMethodValue="";
		if(PickUpMethod.contains("Pickup")){PickUpMethodValue="P";}
		else if(PickUpMethod.contains("Courier")){PickUpMethodValue="C";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: PickUpMethod= ("+PickUpMethod+") not matches with any Options<<<<<<<<<<<<<<<<<<<");
			PickUpMethodValue=PickUpMethod;}
		return PickUpMethodValue;
	}

	public static String getPickUpBy(String DB_PickUpBy) {
		String PickUpBy=DBUtils.readColumnWithRowIDNew(DB_PickUpBy, GetCase.scenarioID);
		String PickUpByValue="";
		if(PickUpBy.contains("Payee")){PickUpByValue="P";}
		else if(PickUpBy.contains("Self")){PickUpByValue="S";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: PickUpBy =("+PickUpBy+")  not matches with any Options<<<<<<<<<<<<<<<<<<<");
			PickUpByValue=PickUpBy;}
		return PickUpByValue;
	}

	public static String getClearingZonecode(String DB_ClearingZone) {
		String ClearingZone=DBUtils.readColumnWithRowIDNew(DB_ClearingZone, GetCase.scenarioID);
		String ClearingZonecodeValue="";
		if(ClearingZone.contains("Abohar")){ClearingZonecodeValue="1";}
		else if(ClearingZone.contains("Achalpur")){ClearingZonecodeValue="2";}
		else if(ClearingZone.contains("Adoni")){ClearingZonecodeValue="3";}
		else if(ClearingZone.contains("Agra")){ClearingZonecodeValue="4";}
		else if(ClearingZone.contains("Ahibannapur")){ClearingZonecodeValue="5";}
		else if(ClearingZone.contains("Ahmedabad")){ClearingZonecodeValue="6";}
		else if(ClearingZone.contains("Ahmednagar")){ClearingZonecodeValue="7";}
		else if(ClearingZone.contains("Ajmer")){ClearingZonecodeValue="8";}
		else if(ClearingZone.contains("Akola")){ClearingZonecodeValue="9";}
		else if(ClearingZone.contains("Akot")){ClearingZonecodeValue="10";}
		else if(ClearingZone.contains("Alibag")){ClearingZonecodeValue="11";}
		else if(ClearingZone.contains("Aligarh")){ClearingZonecodeValue="12";}
		else if(ClearingZone.contains("Allahabad")){ClearingZonecodeValue="13";}
		else if(ClearingZone.contains("Alleppey")){ClearingZonecodeValue="14";}
		else if(ClearingZone.contains("Almora")){ClearingZonecodeValue="15";}
		else if(ClearingZone.contains("Alote")){ClearingZonecodeValue="16";}
		else if(ClearingZone.contains("Alwar")){ClearingZonecodeValue="17";}
		else if(ClearingZone.contains("Alwaye")){ClearingZonecodeValue="18";}
		else if(ClearingZone.contains("Amalapuram")){ClearingZonecodeValue="19";}
		else if(ClearingZone.contains("Amalner")){ClearingZonecodeValue="20";}
		else if(ClearingZone.contains("Amauli")){ClearingZonecodeValue="21";}
		else if(ClearingZone.contains("Ambala")){ClearingZonecodeValue="22";}
		else if(ClearingZone.contains("Ambasamudram")){ClearingZonecodeValue="23";}
		else if(ClearingZone.contains("Ambattur")){ClearingZonecodeValue="24";}
		else if(ClearingZone.contains("Ambikapur")){ClearingZonecodeValue="25";}
		else if(ClearingZone.contains("Amrawati")){ClearingZonecodeValue="26";}
		else if(ClearingZone.contains("Amreli")){ClearingZonecodeValue="27";}
		else if(ClearingZone.contains("Amritsar")){ClearingZonecodeValue="28";}
		else if(ClearingZone.contains("Amroha")){ClearingZonecodeValue="29";}
		else if(ClearingZone.contains("Amroli")){ClearingZonecodeValue="30";}
		else if(ClearingZone.contains("Anakapalle")){ClearingZonecodeValue="31";}
		else if(ClearingZone.contains("Anand")){ClearingZonecodeValue="32";}
		else if(ClearingZone.contains("Anantapur")){ClearingZonecodeValue="33";}
		else if(ClearingZone.contains("Angamally")){ClearingZonecodeValue="34";}
		else if(ClearingZone.contains("Anjangaon Bari")){ClearingZonecodeValue="35";}
		else if(ClearingZone.contains("Anjangaon Surji")){ClearingZonecodeValue="36";}
		else if(ClearingZone.contains("Anjar")){ClearingZonecodeValue="37";}
		else if(ClearingZone.contains("Ankleshwar")){ClearingZonecodeValue="38";}
		else if(ClearingZone.contains("Ansing")){ClearingZonecodeValue="39";}
		else if(ClearingZone.contains("Aranmula")){ClearingZonecodeValue="40";}
		else if(ClearingZone.contains("Ardauna")){ClearingZonecodeValue="41";}
		else if(ClearingZone.contains("Armoor")){ClearingZonecodeValue="42";}
		else if(ClearingZone.contains("Arrah")){ClearingZonecodeValue="43";}
		else if(ClearingZone.contains("Arunapuram")){ClearingZonecodeValue="44";}
		else if(ClearingZone.contains("Arvi")){ClearingZonecodeValue="45";}
		else if(ClearingZone.contains("Asansol")){ClearingZonecodeValue="46";}
		else if(ClearingZone.contains("Aurangabad")){ClearingZonecodeValue="47";}
		else if(ClearingZone.contains("Aurangabad")){ClearingZonecodeValue="48";}
		else if(ClearingZone.contains("Ayodhya")){ClearingZonecodeValue="49";}
		else if(ClearingZone.contains("Ayoor")){ClearingZonecodeValue="50";}
		else if(ClearingZone.contains("Azamgarh")){ClearingZonecodeValue="51";}
		else if(ClearingZone.contains("Babrala")){ClearingZonecodeValue="52";}
		else if(ClearingZone.contains("Bachhrawan")){ClearingZonecodeValue="53";}
		else if(ClearingZone.contains("Bagalkot")){ClearingZonecodeValue="54";}
		else if(ClearingZone.contains("Bagdogra")){ClearingZonecodeValue="55";}
		else if(ClearingZone.contains("Bahadurgarh")){ClearingZonecodeValue="56";}
		else if(ClearingZone.contains("Bahraich")){ClearingZonecodeValue="57";}
		else if(ClearingZone.contains("Baladia")){ClearingZonecodeValue="58";}
		else if(ClearingZone.contains("Balaghat")){ClearingZonecodeValue="59";}
		else if(ClearingZone.contains("Balapur")){ClearingZonecodeValue="60";}
		else if(ClearingZone.contains("Balarampur")){ClearingZonecodeValue="61";}
		else if(ClearingZone.contains("Balasore")){ClearingZonecodeValue="62";}
		else if(ClearingZone.contains("Ballia")){ClearingZonecodeValue="63";}
		else if(ClearingZone.contains("Balurghat")){ClearingZonecodeValue="64";}
		else if(ClearingZone.contains("Banda")){ClearingZonecodeValue="65";}
		else if(ClearingZone.contains("Banga")){ClearingZonecodeValue="66";}
		else if(ClearingZone.contains("Bangalore")){ClearingZonecodeValue="67";}
		else if(ClearingZone.contains("Bangarpet")){ClearingZonecodeValue="68";}
		else if(ClearingZone.contains("Bankura")){ClearingZonecodeValue="69";}
		else if(ClearingZone.contains("Banswara")){ClearingZonecodeValue="70";}
		else if(ClearingZone.contains("Bara Banki")){ClearingZonecodeValue="71";}
		else if(ClearingZone.contains("Baramati")){ClearingZonecodeValue="72";}
		else if(ClearingZone.contains("Baraut")){ClearingZonecodeValue="73";}
		else if(ClearingZone.contains("Bardoli")){ClearingZonecodeValue="74";}
		else if(ClearingZone.contains("Barielly")){ClearingZonecodeValue="75";}
		else if(ClearingZone.contains("Barnala")){ClearingZonecodeValue="76";}
		else if(ClearingZone.contains("Barsi")){ClearingZonecodeValue="77";}
		else if(ClearingZone.contains("Basoda")){ClearingZonecodeValue="78";}
		else if(ClearingZone.contains("Basti")){ClearingZonecodeValue="79";}
		else if(ClearingZone.contains("Batala")){ClearingZonecodeValue="80";}
		else if(ClearingZone.contains("Beas")){ClearingZonecodeValue="81";}
		else if(ClearingZone.contains("Belgaum")){ClearingZonecodeValue="82";}
		else if(ClearingZone.contains("Bellary")){ClearingZonecodeValue="83";}
		else if(ClearingZone.contains("Belwa")){ClearingZonecodeValue="84";}
		else if(ClearingZone.contains("Benupur")){ClearingZonecodeValue="85";}
		else if(ClearingZone.contains("Berhampore")){ClearingZonecodeValue="86";}
		else if(ClearingZone.contains("Berhampur")){ClearingZonecodeValue="87";}
		else if(ClearingZone.contains("Betul")){ClearingZonecodeValue="88";}
		else if(ClearingZone.contains("Bewa Chauraha")){ClearingZonecodeValue="89";}
		else if(ClearingZone.contains("Bhadarva")){ClearingZonecodeValue="90";}
		else if(ClearingZone.contains("Bhadohi")){ClearingZonecodeValue="91";}
		else if(ClearingZone.contains("Bhadrak")){ClearingZonecodeValue="92";}
		else if(ClearingZone.contains("Bhadravathi")){ClearingZonecodeValue="93";}
		else if(ClearingZone.contains("Bhagalpur")){ClearingZonecodeValue="94";}
		else if(ClearingZone.contains("Bhakrapet")){ClearingZonecodeValue="95";}
		else if(ClearingZone.contains("Bhandara")){ClearingZonecodeValue="96";}
		else if(ClearingZone.contains("Bharatipuram")){ClearingZonecodeValue="97";}
		else if(ClearingZone.contains("Bharatpur")){ClearingZonecodeValue="98";}
		else if(ClearingZone.contains("Bhatinda")){ClearingZonecodeValue="99";}
		else if(ClearingZone.contains("Bhavanagar")){ClearingZonecodeValue="100";}
		else if(ClearingZone.contains("Bhilwara")){ClearingZonecodeValue="101";}
		else if(ClearingZone.contains("Bhimavaram")){ClearingZonecodeValue="102";}
		else if(ClearingZone.contains("Bhiwadi")){ClearingZonecodeValue="103";}
		else if(ClearingZone.contains("Bhiwani")){ClearingZonecodeValue="104";}
		else if(ClearingZone.contains("Bhopal")){ClearingZonecodeValue="105";}
		else if(ClearingZone.contains("Bhramansahi")){ClearingZonecodeValue="106";}
		else if(ClearingZone.contains("Bhubaneshwar")){ClearingZonecodeValue="107";}
		else if(ClearingZone.contains("Bhuj")){ClearingZonecodeValue="108";}
		else if(ClearingZone.contains("Bhusaval")){ClearingZonecodeValue="109";}
		else if(ClearingZone.contains("Bidar")){ClearingZonecodeValue="110";}
		else if(ClearingZone.contains("Bijapur")){ClearingZonecodeValue="111";}
		else if(ClearingZone.contains("Bikaner")){ClearingZonecodeValue="112";}
		else if(ClearingZone.contains("Bilaspur")){ClearingZonecodeValue="113";}
		else if(ClearingZone.contains("Bilaspur")){ClearingZonecodeValue="114";}
		else if(ClearingZone.contains("Billainagar")){ClearingZonecodeValue="115";}
		else if(ClearingZone.contains("Bilthara")){ClearingZonecodeValue="116";}
		else if(ClearingZone.contains("Binjharpur")){ClearingZonecodeValue="117";}
		else if(ClearingZone.contains("Biribati")){ClearingZonecodeValue="118";}
		else if(ClearingZone.contains("Bodeli")){ClearingZonecodeValue="119";}
		else if(ClearingZone.contains("Bodh Gaya")){ClearingZonecodeValue="120";}
		else if(ClearingZone.contains("Bokaro ")){ClearingZonecodeValue="121";}
		else if(ClearingZone.contains("Bongaigaon")){ClearingZonecodeValue="122";}
		else if(ClearingZone.contains("Borda")){ClearingZonecodeValue="123";}
		else if(ClearingZone.contains("Borsad")){ClearingZonecodeValue="124";}
		else if(ClearingZone.contains("Borvihir")){ClearingZonecodeValue="125";}
		else if(ClearingZone.contains("Botad")){ClearingZonecodeValue="126";}
		else if(ClearingZone.contains("Broach")){ClearingZonecodeValue="127";}
		else if(ClearingZone.contains("Budaun")){ClearingZonecodeValue="128";}
		else if(ClearingZone.contains("Bukkapatnam")){ClearingZonecodeValue="129";}
		else if(ClearingZone.contains("Bulandshahar")){ClearingZonecodeValue="130";}
		else if(ClearingZone.contains("Buldhana")){ClearingZonecodeValue="131";}
		else if(ClearingZone.contains("Bulsar")){ClearingZonecodeValue="132";}
		else if(ClearingZone.contains("Burdwan")){ClearingZonecodeValue="133";}
		else if(ClearingZone.contains("Buxer")){ClearingZonecodeValue="134";}
		else if(ClearingZone.contains("Byadgi")){ClearingZonecodeValue="135";}
		else if(ClearingZone.contains("Calcutta")){ClearingZonecodeValue="136";}
		else if(ClearingZone.contains("Chaibasa")){ClearingZonecodeValue="137";}
		else if(ClearingZone.contains("Chalakudy")){ClearingZonecodeValue="138";}
		else if(ClearingZone.contains("Chalisgaon")){ClearingZonecodeValue="139";}
		else if(ClearingZone.contains("Challakere")){ClearingZonecodeValue="140";}
		else if(ClearingZone.contains("Champa")){ClearingZonecodeValue="141";}
		else if(ClearingZone.contains("Chandigarh")){ClearingZonecodeValue="142";}
		else if(ClearingZone.contains("Chandrapur")){ClearingZonecodeValue="143";}
		else if(ClearingZone.contains("Changanacherry")){ClearingZonecodeValue="144";}
		else if(ClearingZone.contains("Chapra")){ClearingZonecodeValue="145";}
		else if(ClearingZone.contains("Charkhi Dadri")){ClearingZonecodeValue="146";}
		else if(ClearingZone.contains("Chas")){ClearingZonecodeValue="147";}
		else if(ClearingZone.contains("Chawakkad")){ClearingZonecodeValue="148";}
		else if(ClearingZone.contains("Chenganur")){ClearingZonecodeValue="149";}
		else if(ClearingZone.contains("Chennai")){ClearingZonecodeValue="150";}
		else if(ClearingZone.contains("Cherukole")){ClearingZonecodeValue="151";}
		else if(ClearingZone.contains("Chethalayam")){ClearingZonecodeValue="152";}
		else if(ClearingZone.contains("Chhadvel Korde")){ClearingZonecodeValue="153";}
		else if(ClearingZone.contains("Chhara")){ClearingZonecodeValue="154";}
		else if(ClearingZone.contains("Chhindwara")){ClearingZonecodeValue="155";}
		else if(ClearingZone.contains("Chhota Udepur")){ClearingZonecodeValue="156";}
		else if(ClearingZone.contains("Chickaballapur")){ClearingZonecodeValue="157";}
		else if(ClearingZone.contains("Chickmagalur")){ClearingZonecodeValue="158";}
		else if(ClearingZone.contains("Chidambaram")){ClearingZonecodeValue="159";}
		else if(ClearingZone.contains("Chikhali")){ClearingZonecodeValue="160";}
		else if(ClearingZone.contains("Chilakaluripet")){ClearingZonecodeValue="161";}
		else if(ClearingZone.contains("Chintamani")){ClearingZonecodeValue="162";}
		else if(ClearingZone.contains("Chiplun")){ClearingZonecodeValue="163";}
		else if(ClearingZone.contains("Chirala")){ClearingZonecodeValue="164";}
		else if(ClearingZone.contains("Chit Baragaon")){ClearingZonecodeValue="165";}
		else if(ClearingZone.contains("Chitradurga")){ClearingZonecodeValue="166";}
		else if(ClearingZone.contains("Chittoor")){ClearingZonecodeValue="167";}
		else if(ClearingZone.contains("Cochin")){ClearingZonecodeValue="168";}
		else if(ClearingZone.contains("Coimbatore")){ClearingZonecodeValue="169";}
		else if(ClearingZone.contains("Cooch-Behar")){ClearingZonecodeValue="170";}
		else if(ClearingZone.contains("Coonor")){ClearingZonecodeValue="171";}
		else if(ClearingZone.contains("Cuddapah")){ClearingZonecodeValue="172";}
		else if(ClearingZone.contains("Cuncolim")){ClearingZonecodeValue="173";}
		else if(ClearingZone.contains("Curchorem")){ClearingZonecodeValue="174";}
		else if(ClearingZone.contains("Cuttack")){ClearingZonecodeValue="175";}
		else if(ClearingZone.contains("Dabhasa")){ClearingZonecodeValue="176";}
		else if(ClearingZone.contains("Daman")){ClearingZonecodeValue="177";}
		else if(ClearingZone.contains("Damoh")){ClearingZonecodeValue="178";}
		else if(ClearingZone.contains("Darbhangha")){ClearingZonecodeValue="179";}
		else if(ClearingZone.contains("Dariyabad")){ClearingZonecodeValue="180";}
		else if(ClearingZone.contains("Darjeeling")){ClearingZonecodeValue="181";}
		else if(ClearingZone.contains("Daryapur")){ClearingZonecodeValue="182";}
		else if(ClearingZone.contains("Davanagere")){ClearingZonecodeValue="183";}
		else if(ClearingZone.contains("Dehradun")){ClearingZonecodeValue="184";}
		else if(ClearingZone.contains("Delhi")){ClearingZonecodeValue="185";}
		else if(ClearingZone.contains("Deoband")){ClearingZonecodeValue="186";}
		else if(ClearingZone.contains("Deoria")){ClearingZonecodeValue="187";}
		else if(ClearingZone.contains("Devas")){ClearingZonecodeValue="188";}
		else if(ClearingZone.contains("Dhamnod")){ClearingZonecodeValue="189";}
		else if(ClearingZone.contains("Dhanbad")){ClearingZonecodeValue="190";}
		else if(ClearingZone.contains("Dhar")){ClearingZonecodeValue="191";}
		else if(ClearingZone.contains("Dharampuri")){ClearingZonecodeValue="192";}
		else if(ClearingZone.contains("Dharapuram")){ClearingZonecodeValue="193";}
		else if(ClearingZone.contains("Dharmapuri")){ClearingZonecodeValue="194";}
		else if(ClearingZone.contains("Dharmavaram")){ClearingZonecodeValue="195";}
		else if(ClearingZone.contains("Dharwad")){ClearingZonecodeValue="196";}
		else if(ClearingZone.contains("Dhoraji")){ClearingZonecodeValue="197";}
		else if(ClearingZone.contains("Dhrangadhra")){ClearingZonecodeValue="198";}
		else if(ClearingZone.contains("Dhubri")){ClearingZonecodeValue="199";}
		else if(ClearingZone.contains("Dindigal")){ClearingZonecodeValue="200";}
		else if(ClearingZone.contains("Dinhata")){ClearingZonecodeValue="201";}
		else if(ClearingZone.contains("Diu")){ClearingZonecodeValue="202";}
		else if(ClearingZone.contains("Dohad")){ClearingZonecodeValue="203";}
		else if(ClearingZone.contains("Dumka")){ClearingZonecodeValue="204";}
		else if(ClearingZone.contains("Durg")){ClearingZonecodeValue="205";}
		else if(ClearingZone.contains("Durgapur")){ClearingZonecodeValue="206";}
		else if(ClearingZone.contains("Dwarka")){ClearingZonecodeValue="207";}
		else if(ClearingZone.contains("Edapallikota")){ClearingZonecodeValue="208";}
		else if(ClearingZone.contains("Eluru")){ClearingZonecodeValue="209";}
		else if(ClearingZone.contains("Ernakulam")){ClearingZonecodeValue="210";}
		else if(ClearingZone.contains("Erode")){ClearingZonecodeValue="211";}
		else if(ClearingZone.contains("Etah")){ClearingZonecodeValue="212";}
		else if(ClearingZone.contains("Etawah")){ClearingZonecodeValue="213";}
		else if(ClearingZone.contains("Ezhamator")){ClearingZonecodeValue="214";}
		else if(ClearingZone.contains("Faizabad")){ClearingZonecodeValue="215";}
		else if(ClearingZone.contains("Faridabad")){ClearingZonecodeValue="216";}
		else if(ClearingZone.contains("Faridkot")){ClearingZonecodeValue="217";}
		else if(ClearingZone.contains("Farrukhabad")){ClearingZonecodeValue="218";}
		else if(ClearingZone.contains("Fatehganj")){ClearingZonecodeValue="219";}
		else if(ClearingZone.contains("Fatehpur")){ClearingZonecodeValue="220";}
		else if(ClearingZone.contains("Fazilka")){ClearingZonecodeValue="221";}
		else if(ClearingZone.contains("Ferozabad")){ClearingZonecodeValue="222";}
		else if(ClearingZone.contains("Ferozepur")){ClearingZonecodeValue="223";}
		else if(ClearingZone.contains("Freeland ganj")){ClearingZonecodeValue="224";}
		else if(ClearingZone.contains("Gadag")){ClearingZonecodeValue="225";}
		else if(ClearingZone.contains("Gadarwara")){ClearingZonecodeValue="226";}
		else if(ClearingZone.contains("Gagaikondan")){ClearingZonecodeValue="227";}
		else if(ClearingZone.contains("Gajuwaka")){ClearingZonecodeValue="228";}
		else if(ClearingZone.contains("Gandhidham")){ClearingZonecodeValue="229";}
		else if(ClearingZone.contains("Gandhinagar")){ClearingZonecodeValue="230";}
		else if(ClearingZone.contains("Gangadhara")){ClearingZonecodeValue="231";}
		else if(ClearingZone.contains("Gangavathi")){ClearingZonecodeValue="232";}
		else if(ClearingZone.contains("Gangtok")){ClearingZonecodeValue="233";}
		else if(ClearingZone.contains("Garampani")){ClearingZonecodeValue="234";}
		else if(ClearingZone.contains("Garh Mukteshwar")){ClearingZonecodeValue="235";}
		else if(ClearingZone.contains("Gaya")){ClearingZonecodeValue="236";}
		else if(ClearingZone.contains("Ghaziabad")){ClearingZonecodeValue="237";}
		else if(ClearingZone.contains("Ghazipur")){ClearingZonecodeValue="238";}
		else if(ClearingZone.contains("Giddalur")){ClearingZonecodeValue="239";}
		else if(ClearingZone.contains("Giridih")){ClearingZonecodeValue="240";}
		else if(ClearingZone.contains("Godhra")){ClearingZonecodeValue="241";}
		else if(ClearingZone.contains("Gokak")){ClearingZonecodeValue="242";}
		else if(ClearingZone.contains("Gokulpur")){ClearingZonecodeValue="243";}
		else if(ClearingZone.contains("Gonda")){ClearingZonecodeValue="244";}
		else if(ClearingZone.contains("Gondal")){ClearingZonecodeValue="245";}
		else if(ClearingZone.contains("Gondia")){ClearingZonecodeValue="246";}
		else if(ClearingZone.contains("Gopalganj")){ClearingZonecodeValue="247";}
		else if(ClearingZone.contains("Gorakhpur")){ClearingZonecodeValue="248";}
		else if(ClearingZone.contains("Goraya")){ClearingZonecodeValue="249";}
		else if(ClearingZone.contains("Gosaiganj")){ClearingZonecodeValue="250";}
		else if(ClearingZone.contains("Gowribidanur")){ClearingZonecodeValue="251";}
		else if(ClearingZone.contains("Gudivada")){ClearingZonecodeValue="252";}
		else if(ClearingZone.contains("Gudiyattam")){ClearingZonecodeValue="253";}
		else if(ClearingZone.contains("Gujri")){ClearingZonecodeValue="254";}
		else if(ClearingZone.contains("Gulbarga")){ClearingZonecodeValue="255";}
		else if(ClearingZone.contains("Gumthala")){ClearingZonecodeValue="256";}
		else if(ClearingZone.contains("Guna")){ClearingZonecodeValue="257";}
		else if(ClearingZone.contains("Guntur")){ClearingZonecodeValue="258";}
		else if(ClearingZone.contains("Gurdaspur")){ClearingZonecodeValue="259";}
		else if(ClearingZone.contains("Gurgaon")){ClearingZonecodeValue="260";}
		else if(ClearingZone.contains("Guwahati")){ClearingZonecodeValue="261";}
		else if(ClearingZone.contains("Gwalior")){ClearingZonecodeValue="262";}
		else if(ClearingZone.contains("Hajipur")){ClearingZonecodeValue="263";}
		else if(ClearingZone.contains("Haldia")){ClearingZonecodeValue="264";}
		else if(ClearingZone.contains("Haldwani")){ClearingZonecodeValue="265";}
		else if(ClearingZone.contains("Halol")){ClearingZonecodeValue="266";}
		else if(ClearingZone.contains("Hamirpur")){ClearingZonecodeValue="267";}
		else if(ClearingZone.contains("Hansi")){ClearingZonecodeValue="268";}
		else if(ClearingZone.contains("Hanumakonda")){ClearingZonecodeValue="269";}
		else if(ClearingZone.contains("Hanumangarh")){ClearingZonecodeValue="270";}
		else if(ClearingZone.contains("Hapur")){ClearingZonecodeValue="271";}
		else if(ClearingZone.contains("Hardoi")){ClearingZonecodeValue="272";}
		else if(ClearingZone.contains("Harduaganj")){ClearingZonecodeValue="273";}
		else if(ClearingZone.contains("Hardwar")){ClearingZonecodeValue="274";}
		else if(ClearingZone.contains("Hariharpur")){ClearingZonecodeValue="275";}
		else if(ClearingZone.contains("Hassan")){ClearingZonecodeValue="276";}
		else if(ClearingZone.contains("Hathras")){ClearingZonecodeValue="277";}
		else if(ClearingZone.contains("Hazaribagh")){ClearingZonecodeValue="278";}
		else if(ClearingZone.contains("Hazipur")){ClearingZonecodeValue="279";}
		else if(ClearingZone.contains("Himatnagar")){ClearingZonecodeValue="280";}
		else if(ClearingZone.contains("Hindupur")){ClearingZonecodeValue="281";}
		else if(ClearingZone.contains("Hissar")){ClearingZonecodeValue="282";}
		else if(ClearingZone.contains("Hiwarkhed")){ClearingZonecodeValue="283";}
		else if(ClearingZone.contains("Holagunda")){ClearingZonecodeValue="284";}
		else if(ClearingZone.contains("Honavar")){ClearingZonecodeValue="285";}
		else if(ClearingZone.contains("Hoshangabad")){ClearingZonecodeValue="286";}
		else if(ClearingZone.contains("Hoshiarpur")){ClearingZonecodeValue="287";}
		else if(ClearingZone.contains("Hospet")){ClearingZonecodeValue="288";}
		else if(ClearingZone.contains("Hosur")){ClearingZonecodeValue="289";}
		else if(ClearingZone.contains("Hubli")){ClearingZonecodeValue="290";}
		else if(ClearingZone.contains("Hunsur")){ClearingZonecodeValue="291";}
		else if(ClearingZone.contains("Huzurabad")){ClearingZonecodeValue="292";}
		else if(ClearingZone.contains("Hyderabad")){ClearingZonecodeValue="293";}
		else if(ClearingZone.contains("Ichalkaranji")){ClearingZonecodeValue="294";}
		else if(ClearingZone.contains("Idar")){ClearingZonecodeValue="295";}
		else if(ClearingZone.contains("Ieeja")){ClearingZonecodeValue="296";}
		else if(ClearingZone.contains("Iglas")){ClearingZonecodeValue="297";}
		else if(ClearingZone.contains("Ilkal")){ClearingZonecodeValue="298";}
		else if(ClearingZone.contains("Imphal")){ClearingZonecodeValue="299";}
		else if(ClearingZone.contains("Indore")){ClearingZonecodeValue="300";}
		else if(ClearingZone.contains("Irinjalakuda")){ClearingZonecodeValue="301";}
		else if(ClearingZone.contains("Itarsi")){ClearingZonecodeValue="302";}
		else if(ClearingZone.contains("Jabalpur")){ClearingZonecodeValue="303";}
		else if(ClearingZone.contains("Jagadhri")){ClearingZonecodeValue="304";}
		else if(ClearingZone.contains("Jagdalpur")){ClearingZonecodeValue="305";}
		else if(ClearingZone.contains("Jagraon")){ClearingZonecodeValue="306";}
		else if(ClearingZone.contains("Jagtial")){ClearingZonecodeValue="307";}
		else if(ClearingZone.contains("Jaipur")){ClearingZonecodeValue="308";}
		else if(ClearingZone.contains("Jajpur road")){ClearingZonecodeValue="309";}
		else if(ClearingZone.contains("Jalalpur")){ClearingZonecodeValue="310";}
		else if(ClearingZone.contains("Jalgaon")){ClearingZonecodeValue="311";}
		else if(ClearingZone.contains("Jallandhar")){ClearingZonecodeValue="312";}
		else if(ClearingZone.contains("Jalna")){ClearingZonecodeValue="313";}
		else if(ClearingZone.contains("Jalpaiguri")){ClearingZonecodeValue="314";}
		else if(ClearingZone.contains("Jam-Jodhpur")){ClearingZonecodeValue="315";}
		else if(ClearingZone.contains("Jam-Khambalia")){ClearingZonecodeValue="316";}
		else if(ClearingZone.contains("Jammu")){ClearingZonecodeValue="317";}
		else if(ClearingZone.contains("Jamnagar")){ClearingZonecodeValue="318";}
		else if(ClearingZone.contains("Jamshedpur")){ClearingZonecodeValue="319";}
		else if(ClearingZone.contains("Jaora")){ClearingZonecodeValue="320";}
		else if(ClearingZone.contains("Jaswada")){ClearingZonecodeValue="321";}
		else if(ClearingZone.contains("Jattari")){ClearingZonecodeValue="322";}
		else if(ClearingZone.contains("Jaunpur")){ClearingZonecodeValue="323";}
		else if(ClearingZone.contains("Jetpur")){ClearingZonecodeValue="324";}
		else if(ClearingZone.contains("Jhansi")){ClearingZonecodeValue="325";}
		else if(ClearingZone.contains("Jharia")){ClearingZonecodeValue="326";}
		else if(ClearingZone.contains("Jodhpur")){ClearingZonecodeValue="327";}
		else if(ClearingZone.contains("Joravarnagar")){ClearingZonecodeValue="328";}
		else if(ClearingZone.contains("Junagadh")){ClearingZonecodeValue="329";}
		else if(ClearingZone.contains("Kadamtala")){ClearingZonecodeValue="330";}
		else if(ClearingZone.contains("Kadappakada")){ClearingZonecodeValue="331";}
		else if(ClearingZone.contains("Kadi")){ClearingZonecodeValue="332";}
		else if(ClearingZone.contains("Kadipur")){ClearingZonecodeValue="333";}
		else if(ClearingZone.contains("Kadiri")){ClearingZonecodeValue="334";}
		else if(ClearingZone.contains("Kadur")){ClearingZonecodeValue="335";}
		else if(ClearingZone.contains("Kaithal")){ClearingZonecodeValue="336";}
		else if(ClearingZone.contains("Kakinada")){ClearingZonecodeValue="337";}
		else if(ClearingZone.contains("Kakoda")){ClearingZonecodeValue="338";}
		else if(ClearingZone.contains("Kalka")){ClearingZonecodeValue="339";}
		else if(ClearingZone.contains("Kallakurichi")){ClearingZonecodeValue="340";}
		else if(ClearingZone.contains("Kallissery")){ClearingZonecodeValue="341";}
		else if(ClearingZone.contains("Kalol")){ClearingZonecodeValue="342";}
		else if(ClearingZone.contains("Kalyani")){ClearingZonecodeValue="343";}
		else if(ClearingZone.contains("Kamareddy")){ClearingZonecodeValue="344";}
		else if(ClearingZone.contains("Kampli")){ClearingZonecodeValue="345";}
		else if(ClearingZone.contains("Kanchipuram")){ClearingZonecodeValue="346";}
		else if(ClearingZone.contains("Kanhaipur")){ClearingZonecodeValue="347";}
		else if(ClearingZone.contains("Kankhal Gurukul Kangri")){ClearingZonecodeValue="348";}
		else if(ClearingZone.contains("Kannauj")){ClearingZonecodeValue="349";}
		else if(ClearingZone.contains("Kannur")){ClearingZonecodeValue="350";}
		else if(ClearingZone.contains("Kanpur")){ClearingZonecodeValue="351";}
		else if(ClearingZone.contains("Kapadwanj")){ClearingZonecodeValue="352";}
		else if(ClearingZone.contains("Kapurthala")){ClearingZonecodeValue="353";}
		else if(ClearingZone.contains("Kapustalani")){ClearingZonecodeValue="354";}
		else if(ClearingZone.contains("Karad")){ClearingZonecodeValue="355";}
		else if(ClearingZone.contains("Karaikudi")){ClearingZonecodeValue="356";}
		else if(ClearingZone.contains("Karajgaon")){ClearingZonecodeValue="357";}
		else if(ClearingZone.contains("Karanja")){ClearingZonecodeValue="358";}
		else if(ClearingZone.contains("Kareli")){ClearingZonecodeValue="359";}
		else if(ClearingZone.contains("Karimnagar")){ClearingZonecodeValue="360";}
		else if(ClearingZone.contains("Karkala")){ClearingZonecodeValue="361";}
		else if(ClearingZone.contains("Karnal")){ClearingZonecodeValue="362";}
		else if(ClearingZone.contains("Karur")){ClearingZonecodeValue="363";}
		else if(ClearingZone.contains("Karwar")){ClearingZonecodeValue="364";}
		else if(ClearingZone.contains("Kasargod")){ClearingZonecodeValue="365";}
		else if(ClearingZone.contains("Kashipur")){ClearingZonecodeValue="366";}
		else if(ClearingZone.contains("Kasoda")){ClearingZonecodeValue="367";}
		else if(ClearingZone.contains("Katehri")){ClearingZonecodeValue="368";}
		else if(ClearingZone.contains("Katihar")){ClearingZonecodeValue="369";}
		else if(ClearingZone.contains("Katni")){ClearingZonecodeValue="370";}
		else if(ClearingZone.contains("Kavali")){ClearingZonecodeValue="371";}
		else if(ClearingZone.contains("Kaviyoor")){ClearingZonecodeValue="372";}
		else if(ClearingZone.contains("Kawant")){ClearingZonecodeValue="373";}
		else if(ClearingZone.contains("Kayamkulam")){ClearingZonecodeValue="374";}
		else if(ClearingZone.contains("Kayavarohan")){ClearingZonecodeValue="375";}
		else if(ClearingZone.contains("Keonjhar")){ClearingZonecodeValue="376";}
		else if(ClearingZone.contains("Khamgaon")){ClearingZonecodeValue="377";}
		else if(ClearingZone.contains("Khammam")){ClearingZonecodeValue="378";}
		else if(ClearingZone.contains("Khandavalli")){ClearingZonecodeValue="379";}
		else if(ClearingZone.contains("Khandwa")){ClearingZonecodeValue="380";}
		else if(ClearingZone.contains("Khanna")){ClearingZonecodeValue="381";}
		else if(ClearingZone.contains("Kharagpur")){ClearingZonecodeValue="382";}
		else if(ClearingZone.contains("Khargone")){ClearingZonecodeValue="383";}
		else if(ClearingZone.contains("Khatauli")){ClearingZonecodeValue="384";}
		else if(ClearingZone.contains("Kher")){ClearingZonecodeValue="385";}
		else if(ClearingZone.contains("Khetri")){ClearingZonecodeValue="386";}
		else if(ClearingZone.contains("Kodakara")){ClearingZonecodeValue="387";}
		else if(ClearingZone.contains("Kokrajhar")){ClearingZonecodeValue="388";}
		else if(ClearingZone.contains("Kolar")){ClearingZonecodeValue="389";}
		else if(ClearingZone.contains("Kolhapur")){ClearingZonecodeValue="390";}
		else if(ClearingZone.contains("Kollam")){ClearingZonecodeValue="391";}
		else if(ClearingZone.contains("Kollegal")){ClearingZonecodeValue="392";}
		else if(ClearingZone.contains("Kondakamarla")){ClearingZonecodeValue="393";}
		else if(ClearingZone.contains("Kopergaon")){ClearingZonecodeValue="394";}
		else if(ClearingZone.contains("Korba")){ClearingZonecodeValue="395";}
		else if(ClearingZone.contains("Kosbad")){ClearingZonecodeValue="396";}
		else if(ClearingZone.contains("Kosikalan")){ClearingZonecodeValue="397";}
		else if(ClearingZone.contains("Kota")){ClearingZonecodeValue="398";}
		else if(ClearingZone.contains("Kotagiri")){ClearingZonecodeValue="399";}
		else if(ClearingZone.contains("Kotda Chakar")){ClearingZonecodeValue="400";}
		else if(ClearingZone.contains("Kothavalasa")){ClearingZonecodeValue="401";}
		else if(ClearingZone.contains("Kottayam")){ClearingZonecodeValue="402";}
		else if(ClearingZone.contains("Kottiyam")){ClearingZonecodeValue="403";}
		else if(ClearingZone.contains("Kovilpatti")){ClearingZonecodeValue="404";}
		else if(ClearingZone.contains("Kozhikode")){ClearingZonecodeValue="405";}
		else if(ClearingZone.contains("Krishnagiri")){ClearingZonecodeValue="406";}
		else if(ClearingZone.contains("Krishnanagar")){ClearingZonecodeValue="407";}
		else if(ClearingZone.contains("Kuchaman City")){ClearingZonecodeValue="408";}
		else if(ClearingZone.contains("Kulathupuzha")){ClearingZonecodeValue="409";}
		else if(ClearingZone.contains("Kumbakonam")){ClearingZonecodeValue="410";}
		else if(ClearingZone.contains("Kundapur")){ClearingZonecodeValue="411";}
		else if(ClearingZone.contains("Kunnicode")){ClearingZonecodeValue="412";}
		else if(ClearingZone.contains("Kurnool")){ClearingZonecodeValue="413";}
		else if(ClearingZone.contains("Kurseong")){ClearingZonecodeValue="414";}
		else if(ClearingZone.contains("Kurukshetra")){ClearingZonecodeValue="415";}
		else if(ClearingZone.contains("Lakshisarai")){ClearingZonecodeValue="416";}
		else if(ClearingZone.contains("Lalgola")){ClearingZonecodeValue="417";}
		else if(ClearingZone.contains("Lalitpur")){ClearingZonecodeValue="418";}
		else if(ClearingZone.contains("Latur")){ClearingZonecodeValue="419";}
		else if(ClearingZone.contains("Lonavala")){ClearingZonecodeValue="420";}
		else if(ClearingZone.contains("Lucknow")){ClearingZonecodeValue="421";}
		else if(ClearingZone.contains("Ludhiana")){ClearingZonecodeValue="422";}
		else if(ClearingZone.contains("Machilipatnam")){ClearingZonecodeValue="423";}
		else if(ClearingZone.contains("Madanapalle")){ClearingZonecodeValue="424";}
		else if(ClearingZone.contains("Madhapar")){ClearingZonecodeValue="425";}
		else if(ClearingZone.contains("Madhavpur")){ClearingZonecodeValue="426";}
		else if(ClearingZone.contains("Madhubani")){ClearingZonecodeValue="427";}
		else if(ClearingZone.contains("Madurai")){ClearingZonecodeValue="428";}
		else if(ClearingZone.contains("Maharajganj")){ClearingZonecodeValue="429";}
		else if(ClearingZone.contains("Mainpuri")){ClearingZonecodeValue="430";}
		else if(ClearingZone.contains("Malda")){ClearingZonecodeValue="431";}
		else if(ClearingZone.contains("Malegaon")){ClearingZonecodeValue="432";}
		else if(ClearingZone.contains("Malegaon")){ClearingZonecodeValue="433";}
		else if(ClearingZone.contains("Malkapur")){ClearingZonecodeValue="434";}
		else if(ClearingZone.contains("Manchar")){ClearingZonecodeValue="435";}
		else if(ClearingZone.contains("Mancherial")){ClearingZonecodeValue="436";}
		else if(ClearingZone.contains("Mandi-Ahmedgarh")){ClearingZonecodeValue="437";}
		else if(ClearingZone.contains("Mandi-Gobindgarh")){ClearingZonecodeValue="438";}
		else if(ClearingZone.contains("Mandla")){ClearingZonecodeValue="439";}
		else if(ClearingZone.contains("Mandsaur")){ClearingZonecodeValue="440";}
		else if(ClearingZone.contains("Mandvi")){ClearingZonecodeValue="441";}
		else if(ClearingZone.contains("Mandya")){ClearingZonecodeValue="442";}
		else if(ClearingZone.contains("Mangalore")){ClearingZonecodeValue="443";}
		else if(ClearingZone.contains("Manjeri")){ClearingZonecodeValue="444";}
		else if(ClearingZone.contains("Manpur")){ClearingZonecodeValue="445";}
		else if(ClearingZone.contains("Mapusa")){ClearingZonecodeValue="446";}
		else if(ClearingZone.contains("Margao")){ClearingZonecodeValue="447";}
		else if(ClearingZone.contains("MARKAPUR")){ClearingZonecodeValue="448";}
		else if(ClearingZone.contains("Mathura")){ClearingZonecodeValue="449";}
		else if(ClearingZone.contains("Mauranwan")){ClearingZonecodeValue="450";}
		else if(ClearingZone.contains("Mawana")){ClearingZonecodeValue="451";}
		else if(ClearingZone.contains("Mayiladuthurai")){ClearingZonecodeValue="452";}
		else if(ClearingZone.contains("Meerut")){ClearingZonecodeValue="453";}
		else if(ClearingZone.contains("MEHABOOBNAGAR")){ClearingZonecodeValue="454";}
		else if(ClearingZone.contains("Mehsana")){ClearingZonecodeValue="455";}
		else if(ClearingZone.contains("Meppadi")){ClearingZonecodeValue="456";}
		else if(ClearingZone.contains("MERCARA")){ClearingZonecodeValue="457";}
		else if(ClearingZone.contains("Merta City")){ClearingZonecodeValue="458";}
		else if(ClearingZone.contains("Mettur")){ClearingZonecodeValue="459";}
		else if(ClearingZone.contains("Mhow")){ClearingZonecodeValue="460";}
		else if(ClearingZone.contains("Midnapore")){ClearingZonecodeValue="461";}
		else if(ClearingZone.contains("Mihinpurwa")){ClearingZonecodeValue="462";}
		else if(ClearingZone.contains("Miryalaguda")){ClearingZonecodeValue="463";}
		else if(ClearingZone.contains("Mirzapur")){ClearingZonecodeValue="464";}
		else if(ClearingZone.contains("Moga")){ClearingZonecodeValue="465";}
		else if(ClearingZone.contains("Mohali")){ClearingZonecodeValue="466";}
		else if(ClearingZone.contains("Mohgaon")){ClearingZonecodeValue="467";}
		else if(ClearingZone.contains("Moolankavo")){ClearingZonecodeValue="468";}
		else if(ClearingZone.contains("Moradabad")){ClearingZonecodeValue="469";}
		else if(ClearingZone.contains("Morena")){ClearingZonecodeValue="470";}
		else if(ClearingZone.contains("Morvi")){ClearingZonecodeValue="471";}
		else if(ClearingZone.contains("Motihari")){ClearingZonecodeValue="472";}
		else if(ClearingZone.contains("Mukerian")){ClearingZonecodeValue="473";}
		else if(ClearingZone.contains("Mukhed")){ClearingZonecodeValue="474";}
		else if(ClearingZone.contains("Mukti")){ClearingZonecodeValue="475";}
		else if(ClearingZone.contains("Muktsar")){ClearingZonecodeValue="476";}
		else if(ClearingZone.contains("Mulbagal")){ClearingZonecodeValue="477";}
		else if(ClearingZone.contains("Mumbai")){ClearingZonecodeValue="478";}
		else if(ClearingZone.contains("Mundargi")){ClearingZonecodeValue="479";}
		else if(ClearingZone.contains("Mundgaon")){ClearingZonecodeValue="480";}
		else if(ClearingZone.contains("Murtizapur")){ClearingZonecodeValue="481";}
		else if(ClearingZone.contains("Muzaffarnagar")){ClearingZonecodeValue="482";}
		else if(ClearingZone.contains("Muzaffarpur")){ClearingZonecodeValue="483";}
		else if(ClearingZone.contains("Mysore")){ClearingZonecodeValue="484";}
		else if(ClearingZone.contains("Nabha")){ClearingZonecodeValue="485";}
		else if(ClearingZone.contains("Nadiad")){ClearingZonecodeValue="486";}
		else if(ClearingZone.contains("Nagda")){ClearingZonecodeValue="487";}
		else if(ClearingZone.contains("Nagpur")){ClearingZonecodeValue="488";}
		else if(ClearingZone.contains("Naihati")){ClearingZonecodeValue="489";}
		else if(ClearingZone.contains("Nainital")){ClearingZonecodeValue="490";}
		else if(ClearingZone.contains("Nakodar")){ClearingZonecodeValue="491";}
		else if(ClearingZone.contains("Namakkal")){ClearingZonecodeValue="492";}
		else if(ClearingZone.contains("Nambur")){ClearingZonecodeValue="493";}
		else if(ClearingZone.contains("Nanded")){ClearingZonecodeValue="494";}
		else if(ClearingZone.contains("Nandigama")){ClearingZonecodeValue="495";}
		else if(ClearingZone.contains("Nandurbar")){ClearingZonecodeValue="496";}
		else if(ClearingZone.contains("Nandyal")){ClearingZonecodeValue="497";}
		else if(ClearingZone.contains("Nanjangud")){ClearingZonecodeValue="498";}
		else if(ClearingZone.contains("Narasaraopet")){ClearingZonecodeValue="499";}
		else if(ClearingZone.contains("Naregal")){ClearingZonecodeValue="500";}
		else if(ClearingZone.contains("Narsingpur")){ClearingZonecodeValue="501";}
		else if(ClearingZone.contains("Nasik")){ClearingZonecodeValue="502";}
		else if(ClearingZone.contains("Naswadi")){ClearingZonecodeValue="503";}
		else if(ClearingZone.contains("Navasari")){ClearingZonecodeValue="504";}
		else if(ClearingZone.contains("Nawadah")){ClearingZonecodeValue="505";}
		else if(ClearingZone.contains("Nawashahar")){ClearingZonecodeValue="506";}
		else if(ClearingZone.contains("Neemuch-Baghana")){ClearingZonecodeValue="507";}
		else if(ClearingZone.contains("Nellore")){ClearingZonecodeValue="508";}
		else if(ClearingZone.contains("Ner Pingalai")){ClearingZonecodeValue="509";}
		else if(ClearingZone.contains("Neulpur")){ClearingZonecodeValue="510";}
		else if(ClearingZone.contains("Newasa")){ClearingZonecodeValue="511";}
		else if(ClearingZone.contains("Nimbhora")){ClearingZonecodeValue="512";}
		else if(ClearingZone.contains("Nizamabad")){ClearingZonecodeValue="513";}
		else if(ClearingZone.contains("Numligarh")){ClearingZonecodeValue="514";}
		else if(ClearingZone.contains("Ongole")){ClearingZonecodeValue="515";}
		else if(ClearingZone.contains("Pachora")){ClearingZonecodeValue="516";}
		else if(ClearingZone.contains("Paladhi")){ClearingZonecodeValue="517";}
		else if(ClearingZone.contains("Palai")){ClearingZonecodeValue="518";}
		else if(ClearingZone.contains("Palakkad")){ClearingZonecodeValue="519";}
		else if(ClearingZone.contains("Palakol")){ClearingZonecodeValue="520";}
		else if(ClearingZone.contains("Palamaner")){ClearingZonecodeValue="521";}
		else if(ClearingZone.contains("Palanpur")){ClearingZonecodeValue="522";}
		else if(ClearingZone.contains("Pali")){ClearingZonecodeValue="523";}
		else if(ClearingZone.contains("Palwal")){ClearingZonecodeValue="524";}
		else if(ClearingZone.contains("Panchkula")){ClearingZonecodeValue="525";}
		else if(ClearingZone.contains("Panchkula Sector-10")){ClearingZonecodeValue="526";}
		else if(ClearingZone.contains("Pandharpur")){ClearingZonecodeValue="527";}
		else if(ClearingZone.contains("Panditwari")){ClearingZonecodeValue="528";}
		else if(ClearingZone.contains("Panipat")){ClearingZonecodeValue="529";}
		else if(ClearingZone.contains("Panjim")){ClearingZonecodeValue="530";}
		else if(ClearingZone.contains("Paradeep")){ClearingZonecodeValue="531";}
		else if(ClearingZone.contains("Parner")){ClearingZonecodeValue="532";}
		else if(ClearingZone.contains("Parola")){ClearingZonecodeValue="533";}
		else if(ClearingZone.contains("Parvathipuram")){ClearingZonecodeValue="534";}
		else if(ClearingZone.contains("Patan")){ClearingZonecodeValue="535";}
		else if(ClearingZone.contains("Pathanapuram")){ClearingZonecodeValue="536";}
		else if(ClearingZone.contains("Pathankot")){ClearingZonecodeValue="537";}
		else if(ClearingZone.contains("Patiala")){ClearingZonecodeValue="538";}
		else if(ClearingZone.contains("Patna")){ClearingZonecodeValue="539";}
		else if(ClearingZone.contains("Pattanamthitta")){ClearingZonecodeValue="540";}
		else if(ClearingZone.contains("Pattancheru")){ClearingZonecodeValue="541";}
		else if(ClearingZone.contains("Pauni")){ClearingZonecodeValue="542";}
		else if(ClearingZone.contains("Pauri")){ClearingZonecodeValue="543";}
		else if(ClearingZone.contains("Pavagada")){ClearingZonecodeValue="544";}
		else if(ClearingZone.contains("Payagpur")){ClearingZonecodeValue="545";}
		else if(ClearingZone.contains("Peralasserry")){ClearingZonecodeValue="546";}
		else if(ClearingZone.contains("Perinad")){ClearingZonecodeValue="547";}
		else if(ClearingZone.contains("Perinthaalmanna")){ClearingZonecodeValue="548";}
		else if(ClearingZone.contains("Peroorkada")){ClearingZonecodeValue="549";}
		else if(ClearingZone.contains("Peth")){ClearingZonecodeValue="550";}
		else if(ClearingZone.contains("Petlad")){ClearingZonecodeValue="551";}
		else if(ClearingZone.contains("Phagwara")){ClearingZonecodeValue="552";}
		else if(ClearingZone.contains("Phalton")){ClearingZonecodeValue="553";}
		else if(ClearingZone.contains("Pilibhit")){ClearingZonecodeValue="554";}
		else if(ClearingZone.contains("Pilkhuwa")){ClearingZonecodeValue="555";}
		else if(ClearingZone.contains("Pimpri Raja")){ClearingZonecodeValue="556";}
		else if(ClearingZone.contains("Pithapuram")){ClearingZonecodeValue="557";}
		else if(ClearingZone.contains("Pithoragarh")){ClearingZonecodeValue="558";}
		else if(ClearingZone.contains("Pondicherry")){ClearingZonecodeValue="559";}
		else if(ClearingZone.contains("Ponnur")){ClearingZonecodeValue="560";}
		else if(ClearingZone.contains("Poovar")){ClearingZonecodeValue="561";}
		else if(ClearingZone.contains("Porbandar")){ClearingZonecodeValue="562";}
		else if(ClearingZone.contains("Porumamilla")){ClearingZonecodeValue="563";}
		else if(ClearingZone.contains("Pratapgadh")){ClearingZonecodeValue="564";}
		else if(ClearingZone.contains("Pratappur")){ClearingZonecodeValue="565";}
		else if(ClearingZone.contains("Proddatur")){ClearingZonecodeValue="566";}
		else if(ClearingZone.contains("Pudukottai")){ClearingZonecodeValue="567";}
		else if(ClearingZone.contains("Pulikezhu")){ClearingZonecodeValue="568";}
		else if(ClearingZone.contains("Pune")){ClearingZonecodeValue="569";}
		else if(ClearingZone.contains("Punganuru")){ClearingZonecodeValue="570";}
		else if(ClearingZone.contains("Puri")){ClearingZonecodeValue="571";}
		else if(ClearingZone.contains("Purnea")){ClearingZonecodeValue="572";}
		else if(ClearingZone.contains("Purulia")){ClearingZonecodeValue="573";}
		else if(ClearingZone.contains("Pusad")){ClearingZonecodeValue="574";}
		else if(ClearingZone.contains("Raichur")){ClearingZonecodeValue="575";}
		else if(ClearingZone.contains("Raigad")){ClearingZonecodeValue="576";}
		else if(ClearingZone.contains("Raiganj")){ClearingZonecodeValue="577";}
		else if(ClearingZone.contains("Raipur")){ClearingZonecodeValue="578";}
		else if(ClearingZone.contains("Rajam")){ClearingZonecodeValue="579";}
		else if(ClearingZone.contains("Rajamundhry")){ClearingZonecodeValue="580";}
		else if(ClearingZone.contains("Rajapalayam")){ClearingZonecodeValue="581";}
		else if(ClearingZone.contains("Rajkot")){ClearingZonecodeValue="582";}
		else if(ClearingZone.contains("Rajnandgaon")){ClearingZonecodeValue="583";}
		else if(ClearingZone.contains("Rajpura")){ClearingZonecodeValue="584";}
		else if(ClearingZone.contains("Rajura")){ClearingZonecodeValue="585";}
		else if(ClearingZone.contains("Ramachandrapuram")){ClearingZonecodeValue="586";}
		else if(ClearingZone.contains("Ramanathapuram")){ClearingZonecodeValue="587";}
		else if(ClearingZone.contains("Ramgarh")){ClearingZonecodeValue="588";}
		else if(ClearingZone.contains("Ramnagar")){ClearingZonecodeValue="589";}
		else if(ClearingZone.contains("Rampur")){ClearingZonecodeValue="590";}
		else if(ClearingZone.contains("Rampurghat")){ClearingZonecodeValue="591";}
		else if(ClearingZone.contains("Ranavav")){ClearingZonecodeValue="592";}
		else if(ClearingZone.contains("Ranchi")){ClearingZonecodeValue="593";}
		else if(ClearingZone.contains("Raniganj")){ClearingZonecodeValue="594";}
		else if(ClearingZone.contains("Rasra")){ClearingZonecodeValue="595";}
		else if(ClearingZone.contains("Ratanpura")){ClearingZonecodeValue="596";}
		else if(ClearingZone.contains("Ratlam")){ClearingZonecodeValue="597";}
		else if(ClearingZone.contains("Ratnagiri")){ClearingZonecodeValue="598";}
		else if(ClearingZone.contains("Rewa")){ClearingZonecodeValue="599";}
		else if(ClearingZone.contains("Rewari")){ClearingZonecodeValue="600";}
		else if(ClearingZone.contains("Rishra")){ClearingZonecodeValue="601";}
		else if(ClearingZone.contains("Rohtak")){ClearingZonecodeValue="602";}
		else if(ClearingZone.contains("Roorkee")){ClearingZonecodeValue="603";}
		else if(ClearingZone.contains("Ropar")){ClearingZonecodeValue="604";}
		else if(ClearingZone.contains("Rourkela")){ClearingZonecodeValue="605";}
		else if(ClearingZone.contains("Rudrapur")){ClearingZonecodeValue="606";}
		else if(ClearingZone.contains("Rupaidiha")){ClearingZonecodeValue="607";}
		else if(ClearingZone.contains("Sadashivpet")){ClearingZonecodeValue="608";}
		else if(ClearingZone.contains("Sagar")){ClearingZonecodeValue="609";}
		else if(ClearingZone.contains("Saharanpur")){ClearingZonecodeValue="610";}
		else if(ClearingZone.contains("Salem")){ClearingZonecodeValue="611";}
		else if(ClearingZone.contains("Samalkot")){ClearingZonecodeValue="612";}
		else if(ClearingZone.contains("Samastipur")){ClearingZonecodeValue="613";}
		else if(ClearingZone.contains("Sambalpur")){ClearingZonecodeValue="614";}
		else if(ClearingZone.contains("Samodha")){ClearingZonecodeValue="615";}
		else if(ClearingZone.contains("Sandasal")){ClearingZonecodeValue="616";}
		else if(ClearingZone.contains("Sangamner")){ClearingZonecodeValue="617";}
		else if(ClearingZone.contains("Sangli")){ClearingZonecodeValue="618";}
		else if(ClearingZone.contains("Sangrur")){ClearingZonecodeValue="619";}
		else if(ClearingZone.contains("Sardhana")){ClearingZonecodeValue="620";}
		else if(ClearingZone.contains("Satara")){ClearingZonecodeValue="621";}
		else if(ClearingZone.contains("Satna")){ClearingZonecodeValue="622";}
		else if(ClearingZone.contains("Sawai Madhopur")){ClearingZonecodeValue="623";}
		else if(ClearingZone.contains("Sehore")){ClearingZonecodeValue="624";}
		else if(ClearingZone.contains("Selakui")){ClearingZonecodeValue="625";}
		else if(ClearingZone.contains("Sewagram")){ClearingZonecodeValue="626";}
		else if(ClearingZone.contains("Shahdol")){ClearingZonecodeValue="627";}
		else if(ClearingZone.contains("Shahjahanpur")){ClearingZonecodeValue="628";}
		else if(ClearingZone.contains("Shahpur")){ClearingZonecodeValue="629";}
		else if(ClearingZone.contains("Shamli")){ClearingZonecodeValue="630";}
		else if(ClearingZone.contains("Shegaon")){ClearingZonecodeValue="631";}
		else if(ClearingZone.contains("Shelubazar")){ClearingZonecodeValue="632";}
		else if(ClearingZone.contains("Shibpur")){ClearingZonecodeValue="633";}
		else if(ClearingZone.contains("Shimoga")){ClearingZonecodeValue="634";}
		else if(ClearingZone.contains("Shirajgaon Band")){ClearingZonecodeValue="635";}
		else if(ClearingZone.contains("Shivani MIDC Area")){ClearingZonecodeValue="636";}
		else if(ClearingZone.contains("Shivpuri")){ClearingZonecodeValue="637";}
		else if(ClearingZone.contains("Sholapur")){ClearingZonecodeValue="638";}
		else if(ClearingZone.contains("Shrirampur")){ClearingZonecodeValue="639";}
		else if(ClearingZone.contains("Shuklaganj")){ClearingZonecodeValue="640";}
		else if(ClearingZone.contains("Sibsagar")){ClearingZonecodeValue="641";}
		else if(ClearingZone.contains("Siddipet")){ClearingZonecodeValue="642";}
		else if(ClearingZone.contains("Sidhpur")){ClearingZonecodeValue="643";}
		else if(ClearingZone.contains("Sikanderpur")){ClearingZonecodeValue="644";}
		else if(ClearingZone.contains("Silchar")){ClearingZonecodeValue="645";}
		else if(ClearingZone.contains("Siliguri")){ClearingZonecodeValue="646";}
		else if(ClearingZone.contains("Silvassa")){ClearingZonecodeValue="647";}
		else if(ClearingZone.contains("Simla")){ClearingZonecodeValue="648";}
		else if(ClearingZone.contains("Sirsa")){ClearingZonecodeValue="649";}
		else if(ClearingZone.contains("Sirsi")){ClearingZonecodeValue="650";}
		else if(ClearingZone.contains("Siruguppa")){ClearingZonecodeValue="651";}
		else if(ClearingZone.contains("Sitamarhi")){ClearingZonecodeValue="652";}
		else if(ClearingZone.contains("Sitapur")){ClearingZonecodeValue="653";}
		else if(ClearingZone.contains("Siwan")){ClearingZonecodeValue="654";}
		else if(ClearingZone.contains("Sokhda")){ClearingZonecodeValue="655";}
		else if(ClearingZone.contains("Solan")){ClearingZonecodeValue="656";}
		else if(ClearingZone.contains("Sonand")){ClearingZonecodeValue="657";}
		else if(ClearingZone.contains("Sonepat")){ClearingZonecodeValue="658";}
		else if(ClearingZone.contains("Sriganganagar")){ClearingZonecodeValue="659";}
		else if(ClearingZone.contains("Srikakulam")){ClearingZonecodeValue="660";}
		else if(ClearingZone.contains("Srikalahasti")){ClearingZonecodeValue="661";}
		else if(ClearingZone.contains("Srinagar")){ClearingZonecodeValue="662";}
		else if(ClearingZone.contains("Srinagar")){ClearingZonecodeValue="663";}
		else if(ClearingZone.contains("SRINIVASPUR")){ClearingZonecodeValue="664";}
		else if(ClearingZone.contains("Sultanpur")){ClearingZonecodeValue="665";}
		else if(ClearingZone.contains("Surat")){ClearingZonecodeValue="666";}
		else if(ClearingZone.contains("Surendranagar")){ClearingZonecodeValue="667";}
		else if(ClearingZone.contains("Suri")){ClearingZonecodeValue="668";}
		else if(ClearingZone.contains("Tadepalligudem")){ClearingZonecodeValue="669";}
		else if(ClearingZone.contains("Talodh")){ClearingZonecodeValue="670";}
		else if(ClearingZone.contains("Tanuku")){ClearingZonecodeValue="671";}
		else if(ClearingZone.contains("Taran Taran")){ClearingZonecodeValue="672";}
		else if(ClearingZone.contains("Tenali")){ClearingZonecodeValue="673";}
		else if(ClearingZone.contains("Thakurdwara")){ClearingZonecodeValue="674";}
		else if(ClearingZone.contains("Thalassery")){ClearingZonecodeValue="675";}
		else if(ClearingZone.contains("Thanikudam")){ClearingZonecodeValue="676";}
		else if(ClearingZone.contains("Thanjavur")){ClearingZonecodeValue="677";}
		else if(ClearingZone.contains("Theni")){ClearingZonecodeValue="678";}
		else if(ClearingZone.contains("Thiruvalla")){ClearingZonecodeValue="679";}
		else if(ClearingZone.contains("Thiruvananthapuram")){ClearingZonecodeValue="680";}
		else if(ClearingZone.contains("Tikunia")){ClearingZonecodeValue="681";}
		else if(ClearingZone.contains("Tinsukia")){ClearingZonecodeValue="682";}
		else if(ClearingZone.contains("Tiptur")){ClearingZonecodeValue="683";}
		else if(ClearingZone.contains("Tiruchirapalli")){ClearingZonecodeValue="684";}
		else if(ClearingZone.contains("Tirunelveli")){ClearingZonecodeValue="685";}
		else if(ClearingZone.contains("Tirupathi")){ClearingZonecodeValue="686";}
		else if(ClearingZone.contains("Tirupur")){ClearingZonecodeValue="687";}
		else if(ClearingZone.contains("Tirur")){ClearingZonecodeValue="688";}
		else if(ClearingZone.contains("Tiruvannamalai")){ClearingZonecodeValue="689";}
		else if(ClearingZone.contains("Tiruvarur")){ClearingZonecodeValue="690";}
		else if(ClearingZone.contains("Trichur")){ClearingZonecodeValue="691";}
		else if(ClearingZone.contains("Tumkur")){ClearingZonecodeValue="692";}
		else if(ClearingZone.contains("Tumsar")){ClearingZonecodeValue="693";}
		else if(ClearingZone.contains("Tuticorin")){ClearingZonecodeValue="694";}
		else if(ClearingZone.contains("Udaipur")){ClearingZonecodeValue="695";}
		else if(ClearingZone.contains("Udamalpet")){ClearingZonecodeValue="696";}
		else if(ClearingZone.contains("Udgir")){ClearingZonecodeValue="697";}
		else if(ClearingZone.contains("Udupi")){ClearingZonecodeValue="698";}
		else if(ClearingZone.contains("Ujjain")){ClearingZonecodeValue="699";}
		else if(ClearingZone.contains("Ulubari")){ClearingZonecodeValue="700";}
		else if(ClearingZone.contains("Unjha")){ClearingZonecodeValue="701";}
		else if(ClearingZone.contains("Unnao")){ClearingZonecodeValue="702";}
		else if(ClearingZone.contains("Vadakara")){ClearingZonecodeValue="703";}
		else if(ClearingZone.contains("Vadkun")){ClearingZonecodeValue="704";}
		else if(ClearingZone.contains("Vadodara")){ClearingZonecodeValue="705";}
		else if(ClearingZone.contains("Vapi")){ClearingZonecodeValue="706";}
		else if(ClearingZone.contains("Varanasi")){ClearingZonecodeValue="707";}
		else if(ClearingZone.contains("Vasco-Da-Gama")){ClearingZonecodeValue="708";}
		else if(ClearingZone.contains("Vav")){ClearingZonecodeValue="709";}
		else if(ClearingZone.contains("Vavol")){ClearingZonecodeValue="710";}
		else if(ClearingZone.contains("Vellore")){ClearingZonecodeValue="711";}
		else if(ClearingZone.contains("Venkojipalem")){ClearingZonecodeValue="712";}
		else if(ClearingZone.contains("Veraval")){ClearingZonecodeValue="713";}
		else if(ClearingZone.contains("Vidisha")){ClearingZonecodeValue="714";}
		else if(ClearingZone.contains("Viha")){ClearingZonecodeValue="715";}
		else if(ClearingZone.contains("Vijayapura")){ClearingZonecodeValue="716";}
		else if(ClearingZone.contains("Vijayawada")){ClearingZonecodeValue="717";}
		else if(ClearingZone.contains("Villupuram")){ClearingZonecodeValue="718";}
		else if(ClearingZone.contains("Virudunagar")){ClearingZonecodeValue="719";}
		else if(ClearingZone.contains("Visakhapatnam")){ClearingZonecodeValue="720";}
		else if(ClearingZone.contains("Vizianagaram")){ClearingZonecodeValue="721";}
		else if(ClearingZone.contains("Vrindavan")){ClearingZonecodeValue="722";}
		else if(ClearingZone.contains("Wadegaon")){ClearingZonecodeValue="723";}
		else if(ClearingZone.contains("Wai")){ClearingZonecodeValue="724";}
		else if(ClearingZone.contains("Waluj")){ClearingZonecodeValue="725";}
		else if(ClearingZone.contains("Wani")){ClearingZonecodeValue="726";}
		else if(ClearingZone.contains("Warangal")){ClearingZonecodeValue="727";}
		else if(ClearingZone.contains("Wardha")){ClearingZonecodeValue="728";}
		else if(ClearingZone.contains("Washim")){ClearingZonecodeValue="729";}
		else if(ClearingZone.contains("Yamunanager")){ClearingZonecodeValue="730";}
		else if(ClearingZone.contains("Yeotmal")){ClearingZonecodeValue="731";}
		else if(ClearingZone.contains("Yeshwanthapur")){ClearingZonecodeValue="732";}
		else if(ClearingZone.contains("Zadeshwar")){ClearingZonecodeValue="733";}
		else if(ClearingZone.contains("Adoor")){ClearingZonecodeValue="734";}
		else if(ClearingZone.contains("AMBUR")){ClearingZonecodeValue="735";}
		else if(ClearingZone.contains("ANGUL")){ClearingZonecodeValue="736";}
		else if(ClearingZone.contains("ANKOLA")){ClearingZonecodeValue="737";}
		else if(ClearingZone.contains("ARNI")){ClearingZonecodeValue="738";}
		else if(ClearingZone.contains("ARSIKERE")){ClearingZonecodeValue="739";}
		else if(ClearingZone.contains("ATHANI")){ClearingZonecodeValue="740";}
		else if(ClearingZone.contains("Attingal")){ClearingZonecodeValue="741";}
		else if(ClearingZone.contains("BAGHPAT")){ClearingZonecodeValue="742";}
		else if(ClearingZone.contains("BALARAMAPURAM")){ClearingZonecodeValue="743";}
		else if(ClearingZone.contains("BARIPADA")){ClearingZonecodeValue="744";}
		else if(ClearingZone.contains("BHATKAL")){ClearingZonecodeValue="745";}
		else if(ClearingZone.contains("BHILAI")){ClearingZonecodeValue="746";}
		else if(ClearingZone.contains("CHAMRAJANAGAR")){ClearingZonecodeValue="747";}
		else if(ClearingZone.contains("CHANDAUSI")){ClearingZonecodeValue="748";}
		else if(ClearingZone.contains("CHIKODI")){ClearingZonecodeValue="749";}
		else if(ClearingZone.contains("CUDDALORE")){ClearingZonecodeValue="750";}
		else if(ClearingZone.contains("DANDELI")){ClearingZonecodeValue="751";}
		else if(ClearingZone.contains("DEOGHAR")){ClearingZonecodeValue="752";}
		else if(ClearingZone.contains("DEVAKOTTAI")){ClearingZonecodeValue="753";}
		else if(ClearingZone.contains("Dhenkanal")){ClearingZonecodeValue="754";}
		else if(ClearingZone.contains("DHULE")){ClearingZonecodeValue="755";}
		else if(ClearingZone.contains("DIBRUGARH")){ClearingZonecodeValue="756";}
		else if(ClearingZone.contains("GUDALUR")){ClearingZonecodeValue="757";}
		else if(ClearingZone.contains("GUDUR")){ClearingZonecodeValue="758";}
		else if(ClearingZone.contains("GUNTAKAL")){ClearingZonecodeValue="759";}
		else if(ClearingZone.contains("GURUVAYUR")){ClearingZonecodeValue="760";}
		else if(ClearingZone.contains("HALIYAL")){ClearingZonecodeValue="761";}
		else if(ClearingZone.contains("HASANPUR")){ClearingZonecodeValue="762";}
		else if(ClearingZone.contains("Haveri")){ClearingZonecodeValue="763";}
		else if(ClearingZone.contains("JAMKHANDI")){ClearingZonecodeValue="764";}
		else if(ClearingZone.contains("JIND")){ClearingZonecodeValue="765";}
		else if(ClearingZone.contains("JORHAT")){ClearingZonecodeValue="766";}
		else if(ClearingZone.contains("KADUTHURUTHY")){ClearingZonecodeValue="767";}
		else if(ClearingZone.contains("KALAMASSERY")){ClearingZonecodeValue="768";}
		else if(ClearingZone.contains("KANHANGAD")){ClearingZonecodeValue="769";}
		else if(ClearingZone.contains("Kazhakkoottam")){ClearingZonecodeValue="770";}
		else if(ClearingZone.contains("KHURJA")){ClearingZonecodeValue="771";}
		else if(ClearingZone.contains("KOPPAL")){ClearingZonecodeValue="772";}
		else if(ClearingZone.contains("KUMTA")){ClearingZonecodeValue="773";}
		else if(ClearingZone.contains("KUNDARA")){ClearingZonecodeValue="774";}
		else if(ClearingZone.contains("KUNNAMKULAM")){ClearingZonecodeValue="775";}
		else if(ClearingZone.contains("LAKHIMPUR")){ClearingZonecodeValue="776";}
		else if(ClearingZone.contains("LAKSHMESHWAR")){ClearingZonecodeValue="777";}
		else if(ClearingZone.contains("MADDUR")){ClearingZonecodeValue="778";}
		else if(ClearingZone.contains("MAHE")){ClearingZonecodeValue="779";}
		else if(ClearingZone.contains("MANANTHAVADY")){ClearingZonecodeValue="780";}
		else if(ClearingZone.contains("Mavelikkara")){ClearingZonecodeValue="781";}
		else if(ClearingZone.contains("MIRAJ")){ClearingZonecodeValue="782";}
		else if(ClearingZone.contains("MODINAGAR")){ClearingZonecodeValue="783";}
		else if(ClearingZone.contains("MONGHYR")){ClearingZonecodeValue="784";}
		else if(ClearingZone.contains("NAGAPATTINAM")){ClearingZonecodeValue="785";}
		else if(ClearingZone.contains("NAGERCOIL")){ClearingZonecodeValue="786";}
		else if(ClearingZone.contains("NARNAUL")){ClearingZonecodeValue="787";}
		else if(ClearingZone.contains("NEYVELI")){ClearingZonecodeValue="788";}
		else if(ClearingZone.contains("NIPANI")){ClearingZonecodeValue="789";}
		else if(ClearingZone.contains("PANDALAM")){ClearingZonecodeValue="790";}
		else if(ClearingZone.contains("PAYYANNUR")){ClearingZonecodeValue="791";}
		else if(ClearingZone.contains("PHILLAUR")){ClearingZonecodeValue="792";}
		else if(ClearingZone.contains("POLLACHI")){ClearingZonecodeValue="793";}
		else if(ClearingZone.contains("PONKUNNAM")){ClearingZonecodeValue="794";}
		else if(ClearingZone.contains("PORT BLAIR")){ClearingZonecodeValue="795";}
		else if(ClearingZone.contains("PUNALUR")){ClearingZonecodeValue="796";}
		else if(ClearingZone.contains("PUTTUR")){ClearingZonecodeValue="797";}
		else if(ClearingZone.contains("QUILANDY")){ClearingZonecodeValue="798";}
		else if(ClearingZone.contains("RANEBENNUR")){ClearingZonecodeValue="799";}
		else if(ClearingZone.contains("SAKLESHPUR")){ClearingZonecodeValue="800";}
		else if(ClearingZone.contains("SAMBHAL")){ClearingZonecodeValue="801";}
		else if(ClearingZone.contains("SANGAREDDY")){ClearingZonecodeValue="802";}
		else if(ClearingZone.contains("SAUNDATTI")){ClearingZonecodeValue="803";}
		else if(ClearingZone.contains("SHILLONG")){ClearingZonecodeValue="804";}
		else if(ClearingZone.contains("SINDHANOOR")){ClearingZonecodeValue="805";}
		else if(ClearingZone.contains("Sivakasi")){ClearingZonecodeValue="806";}
		else if(ClearingZone.contains("TADAPATRI")){ClearingZonecodeValue="807";}
		else if(ClearingZone.contains("TALIPARAMBA")){ClearingZonecodeValue="808";}
		else if(ClearingZone.contains("THIRTHAHALLI")){ClearingZonecodeValue="809";}
		else if(ClearingZone.contains("THODUPUZHA")){ClearingZonecodeValue="810";}
		else if(ClearingZone.contains("TIRUPATTUR")){ClearingZonecodeValue="811";}
		else if(ClearingZone.contains("TIRUTTANI")){ClearingZonecodeValue="812";}
		else if(ClearingZone.contains("TIRUVALLUR")){ClearingZonecodeValue="813";}
		else if(ClearingZone.contains("Tripunithura")){ClearingZonecodeValue="814";}
		else if(ClearingZone.contains("UDHAGAMANDALAM")){ClearingZonecodeValue="815";}
		else if(ClearingZone.contains("VANIAMBADI")){ClearingZonecodeValue="816";}
		else if(ClearingZone.contains("VENKATAGIR")){ClearingZonecodeValue="817";}
		else if(ClearingZone.contains("YADAGIRI")){ClearingZonecodeValue="818";}
		else if(ClearingZone.contains("YEMMIGANUR")){ClearingZonecodeValue="819";}
		else if(ClearingZone.contains("ZAHEERABAD")){ClearingZonecodeValue="820";}
		else {logger.info(">>>>>>>>>>>>>>>>>ERROR: Clearing Zone = ("+ClearingZone+")does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			ClearingZonecodeValue=ClearingZone;}
		return ClearingZonecodeValue;
	}

	public static String getPrintLocation(String DB_PrintLocation) {
		String PrintLoc=DBUtils.readColumnWithRowIDNew(DB_PrintLocation, GetCase.scenarioID);
		String PrintLocVal="";

		return PrintLocVal;
	}
	public static String getFeeCode(String DB_FeeCode) {
		String FeeInfo=DBUtils.readColumnWithRowIDNew(DB_FeeCode, GetCase.scenarioID);
		String FeeInfoCode="";
		if(FeeInfo.contains("PRE-CLOSURE FEE CAT D")){FeeInfoCode="F11";}
		else if(FeeInfo.contains("PRE-CLOSURE FEE CAT A")){FeeInfoCode="F02";}
		else if(FeeInfo.contains("PRE-CLOSURE FEE SELF-EMPLOYED PROFESSIONAL")){FeeInfoCode="F13";}
		else if(FeeInfo.contains("PRE- CLOSURE FEE CAT B")){FeeInfoCode="F09";}
		else if(FeeInfo.contains("PRE-CLOSURE FEE CAT C")){FeeInfoCode="F10";}
		else if(FeeInfo.contains("PRE-CLOSURE FEE CAT Z")){FeeInfoCode="F12";}
		else if(FeeInfo.contains("PRE-CLOSURE FEE SELF-EMPLOYED NON-PROFESSIONAL")){FeeInfoCode="F14";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- SELF EMPLOYED NON- PROFESSI+")){FeeInfoCode="F04";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- CAT C")){FeeInfoCode="F06";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- CAT B")){FeeInfoCode="F05";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- SELF EMPLOYED PROFESSIONAL")){FeeInfoCode="F03";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- CAT A")){FeeInfoCode="F01";}
		else if(FeeInfo.contains("PROCESSING FEE PL/PC- CAT D")){FeeInfoCode="F07";}
		else{logger.info(">>>>>>>>>>>>>>>>>ERROR: FeeInfo = ("+FeeInfo+")  does not matches with any Options<<<<<<<<<<<<<<<<<<<");
			FeeInfoCode= FeeInfo;
		}
		return FeeInfoCode;
	}




}
