package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.FDMRequestGen;
import com.scb.rtob.module.test.framework.glue.GetCase;

public class PriceEsclationL3SetValue 
{	
	public static Logger logger = Logger.getLogger(FraudRiskCheckerSetValue.class);
	private static JSONObject json = FDMRequestGen.jsonReq;
	
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void fraudRiskVerificationList()
	{
	
	}
}
