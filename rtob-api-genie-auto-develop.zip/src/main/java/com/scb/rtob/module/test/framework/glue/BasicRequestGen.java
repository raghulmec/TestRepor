package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.UpdatedCodes.GlobalClass;
import com.scb.rtob.module.test.framework.utils.*;

import cucumber.api.java.en.Given;

public class BasicRequestGen {
	
	public static Logger logger = Logger.getLogger(BasicRequestGen.class);
	/********To be used in BasicSetValue class***********************/
	public static JSONObject jsonReq;
	public static List<String> scenariodesc = new ArrayList<String>();
	public static List<String> wbyes = new ArrayList<String>();
	public static List<String> wbno = new ArrayList<String>();
	public static String scenarioid1;
	public static int rowCount1 = 0;
	public static int columnCount1 = 0;
	static String basicScenarioID = "1";
	
	
	public static JSONParser parser = new JSONParser();
	
	public static void main(String[] args) throws Throwable {
		
		GetCase.loadProps();
		logger.info("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"BDC"+File.separator+""+GetCase.envmap.get("Basic_Template"));
		
	}
	
	
	public static void promoteBasicData() throws Throwable {
		
		logger.info("---------------------------------------- Promote Basic Data Starts--------------------------------------");
		FileReader reader = CommonUtils.readFilefromDirectory("Globaltemplate", "BDC_New.json");
		jsonReq = (JSONObject) parser.parse(reader);
		/****************************Set values for JSON attributes*************************************/
		logger.info(jsonReq);
		GlobalClass.createBasicBlindJson(jsonReq);
		
		BatchRun.jsonReq=jsonReq;
		logger.info(jsonReq);
		/****************************Start - API call part**********************************************/
		GetCase.callPromoteCaseApi("ApplicationRefNo", "CurrentWorkBasket_Basic","BDCTemplateRefNo", jsonReq, true);
		logger.info("---------------------------------------- Promote Basic Data Ends--------------------------------------");
        
	}
	
	
	public static void setValueBasic() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		BasicSetValue.setJSON(jsonReq);
		BasicSetValue.setContent();
		BasicSetValue.setCustomerDetails();
		BasicSetValue.setMultipleCustomerContactDetails();
		BasicSetValue.setApplicantProductRelationship();
		BasicSetValue.setEmployeementDetails();
		BasicSetValue.setDocumentDetails();
		BasicSetValue.setApplicationDetailsTab();
		BasicSetValue.setPrimaryProductDetailsTab();
		
		if(GetCase.isMultipleProduct){
			
			BasicSetValue.setSecondaryProductDetailsTab(1);
			BasicSetValue.setSecondaryProductDetailsTab(2);
			BasicSetValue.setSecondaryProductDetailsTab(3);
			BasicSetValue.setSecondaryProductDetailsTab(4);
			BasicSetValue.setSecondaryProductDetailsTab(5);
		}
		else{logger.info("GetCase.MultipleProduct Flag: FALSE");}
		
		if(GetCase.isCoApp){
			
			BasicSetValue.setCoapplicantDetails(1);
			BasicSetValue.setCoapplicantDetails(2);
			BasicSetValue.setCoapplicantDetails(3);
			BasicSetValue.setCoapplicantDetails(4);
			BasicSetValue.setCoapplicantDetailsinProduct();					
		}
		else{logger.info("GetCase.isCoApp Flag: FALSE");}
		
	}
	
	
		
	@Given("^Call the PromoteCase api for Basic Data Capture$")
	public static void promoteBasic() throws Throwable {

		FileReader reader = CommonUtils.readFilefromDirectory("Globaltemplate", "Basic_Template");
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueBasic();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));

		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_Blind"));
		httpRequest.header("ScenarioID",DBUtils.readColumnWithRowID("BDCTemplateRefNo", GetCase.scenarioID));	
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	@Given("^validate if the application moved to Blind Data Capture$")
	public static void validateWorkbasket() throws Throwable {
		
		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Blind")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_Blind"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	}

}