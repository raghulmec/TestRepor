package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.FraudRiskCheckerSetValue;
import com.scb.rtob.module.test.framework.utils.FraudRiskVerificationSetValue;
import com.scb.rtob.module.test.framework.utils.FullDataSetValue;

import cucumber.api.java.en.Given;


	/*********************************@Author: Shaik Dilawar Hassan*************************************/

public class FraudRiskVerification {

public static Logger logger = Logger.getLogger(FraudRiskVerification.class);
	
	static String CIScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	


	/**************************************************************************************************
	 * Function to read,parse json file and authenticate.
	 * And Returns Authenticated application by logging in.
	 * @throws Throwable 
	 **************************************************************************************************/
	
	@Given("^Call the PromoteCase api for FraudRiskVerification$")
	public static void promoteFraudRiskVerification() throws Throwable {
		
		JSONParser parser = new JSONParser();// creating object for json
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD_Flow"+File.separator+""+GetCase.envmap.get("FraudRiskVerification_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader); // assigns the json format details to an object 
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setvalueFRV();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		
		/****************************Authentication Part Starts****************************************/
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_FraudRiskVerification"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
			
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}

	
	/**************************************************************************************************
	 * Function to check if application has moved to Fulfilment.
	 * And Returns if application has moved to Fulfilment
	 * @throws Throwable
	 **************************************************************************************************/
	
    @Given("^validate if the application has moved to next WorkBasket$")
    public static void validateFRVtoFulfillment() throws Throwable {
		
    	String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CDDException")))
		{
			//**********'NO-FRAUD'
			logger.info("Selected 'SCREEND' and moved to SYSTEM WAIT");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_CDDException")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to SYSTEM WAIT", currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CDDException")));
			
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_InternalVerification")))
		{	
			//**********'FRAUD'
			logger.info("Selected 'APPEAL' and moved to InternalVerification");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_InternalVerification")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to RM supervisor",currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_InternalVerification")));
		}
		else
		{
			logger.info("Does not matches with Expected WB");
			Assert.assertTrue("Does not matches with Expected WB", false);
		}   
    
    }
    
    
    
    
 
    /**************************************************************************************************
	 * Function to modify details by promoting via json file.
	 * And Returns application with updated data in Fraud Risk Verification WorkBasket.
	 * @throws ClassNotFoundException, SQLException, IOException 
	 **************************************************************************************************/
        
    public static void setvalueFRV() throws ClassNotFoundException, SQLException, IOException
    {
    	DBUtils.convertDBtoMap("acdquery");
			
		FraudRiskCheckerSetValue.setJSON(jsonReq);
		FraudRiskCheckerSetValue.fraudRiskVerificationList();
		
		FraudRiskVerificationSetValue.setJSON(jsonReq);
		FraudRiskVerificationSetValue.fraudRiskVerificationList();
    }
    
}


