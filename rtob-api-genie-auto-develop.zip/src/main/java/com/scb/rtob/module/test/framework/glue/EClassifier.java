package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.scb.rtob.action.CSDocumentAdd;
import com.scb.rtob.dto.RTOBDocumentDetailsDTO;
import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.Mapper;
//import com.sun.media.jfxmedia.logging.Logger;
public class EClassifier {

	
	public static void eClassify() throws ClassNotFoundException, SQLException, IOException {
//	public static void main(String args[]) throws ClassNotFoundException, SQLException, IOException {
		
	
		System.out.println("-----------------------------------------eClassify Starts------------------------------------");
		
	CSDocumentAdd documentAdd = new CSDocumentAdd();
	//	String fileName = "C:\\Hemant\\bil- 30-12-2007.tif";
		String fileName = "."+File.separator+"tiffImage"+File.separator+"picture.tif";
		
	
		String folderPath = "/";
		try {
			
			GetCase.loadProps();
			Mapper.setMapper();
			
			DBUtils.convertDBtoMap("diquery");
				
			
            SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
            System.out.println(dateFormat.format(new Date()));
            
            List<RTOBDocumentDetailsDTO> documentDetailsDTOs = new ArrayList<RTOBDocumentDetailsDTO>();
            System.out.println("E-Classification starts");
            String No_of_docs = DBUtils.readColumnWithRowID("Primary_No_of_docs", GetCase.scenarioID);
//            String Coapp1_docs = DBUtils.readColumnWithRowID("Coapp1_No_of_documents", GetCase.scenarioID); 
//            String Coapp2_docs = DBUtils.readColumnWithRowID("Coapp2_No_of_documents", GetCase.scenarioID);
//            String Coapp3_docs = DBUtils.readColumnWithRowID("Coapp3_No_of_documents", GetCase.scenarioID);
//            String Coapp4_docs = DBUtils.readColumnWithRowID("Coapp4_No_of_documents", GetCase.scenarioID);
            
            System.out.println(DBUtils.readColumnWithRowID("Primary_No_of_docs", GetCase.scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp1_No_of_documents", GetCase.scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp2_No_of_documents", GetCase.scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp3_No_of_documents", GetCase.scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp4_No_of_documents", GetCase.scenarioID));
            System.out.println("ApplicationRefNo"+DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID)); 
            
            int docs=Integer.parseInt(No_of_docs);
//            int docsCoapps1=Integer.parseInt(Coapp1_docs);
//            int docsCoapps2=Integer.parseInt(Coapp2_docs);
//            int docsCoapps3=Integer.parseInt(Coapp3_docs);
//            int docsCoapps4=Integer.parseInt(Coapp4_docs);

            String primCategory=null,primType=null,coapp1Category=null,coapp1Type=null,coapp2Category=null,coapp2Type=null,coapp3Category=null,coapp3Type=null,coapp4Category=null,coapp4Type=null;
            String appid=DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID);
           
            
            RTOBDocumentDetailsDTO documentDetailsDTO = new RTOBDocumentDetailsDTO();
            for (int i=1;i<=docs;i++)
            {
            	System.out.println("loop of i: "+i);
                   primCategory=DBUtils.readColumnWithRowID("PrimaryDocCategory"+i,GetCase.scenarioID);
                   primType=DBUtils.readColumnWithRowID("PrimaryTargetDocType"+i,GetCase.scenarioID);
                   
                   if((!primCategory.equals("null"))||(!primType.equals("null")))
                   {
                    
   
                         primCategory=DBUtils.readColumnWithRowID("PrimaryDocCategory"+i,GetCase.scenarioID);
                          primType=DBUtils.readColumnWithRowID("PrimaryTargetDocType"+i,GetCase.scenarioID);
                         
                          System.out.println("Primary Document: "+ "PrimaryDocCategory"+i);
                        		  System.out.println("Primary Document: "+"PrimaryTargetDocType"+i);
                          
                          System.out.println("Primary Document: "+primCategory);
                        System.out.println("Primary Documenttype: "+primType);
                        
                  
                        System.out.println("Converted Doc Category : "+Mapper.retrieveDoc(primCategory));
                        System.out.println("Converted Doc Type : "+Mapper.retrieveDoc(primType));
                   }

                   if(i!=1){
                 
                         documentDetailsDTO=null;
                         documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   }
                   
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(primCategory));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(primType));
                   documentDetailsDTO.setApplicSeqNo("1");
                   documentDetailsDTO.setCntryCode("IN");
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);
                   
              //     i=i+1;docs=docs+1;
            }
            
//            if(docsCoapps1!=0){
//            	System.out.println("1st Coapplicant Eclassifier Started");
//            }
//            
//           for (int i=1;i<=docsCoapps1;i++)
//            {
//        	   
//        	   
//        	   
//        	   
//                   coapp1Category=DBUtils.readColumnWithRowID("CoApplicant1DocCategory"+i,GetCase.scenarioID);
//                   coapp1Type=DBUtils.readColumnWithRowID("CoApplicant1TargetDocType"+i,GetCase.scenarioID);
//                   
//                   if((!coapp1Category.equals("null"))||!(coapp1Type.equals("null"))){
//                	   
//                
//                   
//                   coapp1Category=DBUtils.readColumnWithRowID("CoApplicant1DocCategory"+i,GetCase.scenarioID);
//                   coapp1Type=DBUtils.readColumnWithRowID("CoApplicant1TargetDocType"+i,GetCase.scenarioID);
//                   
//                   
//                   }
//                   documentDetailsDTO= null;
//                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
//                   documentDetailsDTO.setCustName("RTOB Automation");
//                   documentDetailsDTO.setTxnRefNo(appid);
//                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp1Category));
//                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp1Type));
//                   documentDetailsDTO.setApplicSeqNo("2");
//                   documentDetailsDTO.setCntryCode("IN");  
//                   documentDetailsDTO.setTxnType("CR");
//                   documentDetailsDTO.setDocPageCount("15");
//                   documentDetailsDTO.setCreatedID("1553401");
//                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
//                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
//                   documentDetailsDTO.setFileName(fileName);
//                   documentDetailsDTO.setFolderPath(folderPath);
//                   documentDetailsDTOs.add(documentDetailsDTO);
//
//            }
           
          /* if(docsCoapps2!=0){
           	System.out.println("2nd Coapplicant Eclassifier Started");
           }
           
            for (int i=1;i<=docsCoapps2;i++)
            {
                   coapp2Category=DBUtils.readColumnWithRowID("CoApplicant2DocCategory"+i,GetCase.scenarioID);
                   coapp2Type=DBUtils.readColumnWithRowID("CoApplicant2TargetDocType"+i,GetCase.scenarioID);
                   
                   if((coapp2Category.equals("null"))||(coapp2Type.equals("null"))){
                   
                   coapp2Category=DBUtils.readColumnWithRowID("CoApplicant2DocCategory"+i,GetCase.scenarioID);
                   coapp2Type=DBUtils.readColumnWithRowID("CoApplicant2TargetDocType"+i,GetCase.scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp2Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp2Type));
                   documentDetailsDTO.setApplicSeqNo("3");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }
            
            if(docsCoapps3!=0){
            	System.out.println("3rd Coapplicant Eclassifier Started");
            }
            
            for (int i=1;i<=docsCoapps3;i++)
            {
                   coapp3Category=DBUtils.readColumnWithRowID("CoApplicant3DocCategory"+i,GetCase.scenarioID);
                   coapp3Type=DBUtils.readColumnWithRowID("CoApplicant3TargetDocType"+i,GetCase.scenarioID);
                   
                   if((coapp3Category.equals("null"))||(coapp3Type.equals("null"))){
                   
                   coapp3Category=DBUtils.readColumnWithRowID("CoApplicant3DocCategory"+i,GetCase.scenarioID);
                   coapp3Type=DBUtils.readColumnWithRowID("CoApplicant3TargetDocType"+i,GetCase.scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp3Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp3Type));
                   documentDetailsDTO.setApplicSeqNo("4");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }
     
            if(docsCoapps4!=0){
            	System.out.println("4th Coapplicant Eclassifier Started");
            }
            
            
            for (int i=1;i<=docsCoapps4;i++)
            {
                   coapp4Category=DBUtils.readColumnWithRowID("CoApplicant4DocCategory"+i,GetCase.scenarioID);
                   coapp4Type=DBUtils.readColumnWithRowID("CoApplicant4TargetDocType"+i,GetCase.scenarioID);
                   
                   if((coapp4Category.equals("null"))||(coapp4Type.equals("null"))){
                   
                   coapp4Category=DBUtils.readColumnWithRowID("CoApplicant4DocCategory"+i,GetCase.scenarioID);
                   coapp4Type=DBUtils.readColumnWithRowID("CoApplicant4TargetDocType"+i,GetCase.scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp4Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp4Type));
                   documentDetailsDTO.setApplicSeqNo("5");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }*/

			
			documentAdd.addCSDocument(documentDetailsDTOs);
			System.out.println("Done.");
		} catch (Exception e) {
			System.out.println("ERROR : "+e.getMessage());
		}
	
		System.out.println("-----------------------------------------eClassify ENDS------------------------------------");
	}
	
	public static void eClassifyWithScenarioID(String scenarioID) throws ClassNotFoundException, SQLException, IOException {			
		
		System.out.println("-----------------------------------------eClassify Starts------------------------------------");
		
	CSDocumentAdd documentAdd = new CSDocumentAdd();
	//	String fileName = "C:\\Hemant\\bil- 30-12-2007.tif";
		String fileName = "."+File.separator+"tiffImage"+File.separator+"picture.tif";
		
	
		String folderPath = "/";
		try {
			
			GetCase.loadProps();
			Mapper.setMapper();
			
			DBUtils.convertDBtoMap("diquery");
				
			
            SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
            System.out.println(dateFormat.format(new Date()));
            
            List<RTOBDocumentDetailsDTO> documentDetailsDTOs = new ArrayList<RTOBDocumentDetailsDTO>();
            String No_of_docs = DBUtils.readColumnWithRowID("Primary_No_of_docs", scenarioID);
          /*  String Coapp1_docs = DBUtils.readColumnWithRowID("Coapp1_No_of_documents", scenarioID); 
            String Coapp2_docs = DBUtils.readColumnWithRowID("Coapp2_No_of_documents", scenarioID);
            String Coapp3_docs = DBUtils.readColumnWithRowID("Coapp3_No_of_documents", scenarioID);
            String Coapp4_docs = DBUtils.readColumnWithRowID("Coapp4_No_of_documents", scenarioID);*/
            
            System.out.println(DBUtils.readColumnWithRowID("Primary_No_of_docs", scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp1_No_of_documents", scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp2_No_of_documents", scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp3_No_of_documents", scenarioID));
            System.out.println(DBUtils.readColumnWithRowID("Coapp4_No_of_documents", scenarioID));
            System.out.println("Application id"+DBUtils.readColumnWithRowID("ApplicationRefNo", scenarioID)); 
            
            int docs=Integer.parseInt(No_of_docs);
           /* int docsCoapps1=Integer.parseInt(Coapp1_docs);
            int docsCoapps2=Integer.parseInt(Coapp2_docs);
            int docsCoapps3=Integer.parseInt(Coapp3_docs);
            int docsCoapps4=Integer.parseInt(Coapp4_docs);*/

            String primCategory=null,primType=null,coapp1Category=null,coapp1Type=null,coapp2Category=null,coapp2Type=null,coapp3Category=null,coapp3Type=null,coapp4Category=null,coapp4Type=null;
            String appid=DBUtils.readColumnWithRowID("ApplicationRefNo", scenarioID);
           
            
            RTOBDocumentDetailsDTO documentDetailsDTO = new RTOBDocumentDetailsDTO();
            for (int i=1;i<=docs;i++)
            {
            	System.out.println("loop of i: "+i);
                   primCategory=DBUtils.readColumnWithRowID("PrimaryDocCategory"+i,scenarioID);
                   primType=DBUtils.readColumnWithRowID("PrimaryTargetDocType"+i,scenarioID);
                   
                   if((!primCategory.equals("null"))||(!primType.equals("null")))
                   {
                    
                         
                         
                         
                         primCategory=DBUtils.readColumnWithRowID("PrimaryDocCategory"+i,scenarioID);
                          primType=DBUtils.readColumnWithRowID("PrimaryTargetDocType"+i,scenarioID);
                         
                          System.out.println("Primary Document: "+ "PrimaryDocCategory"+i);
                        		  System.out.println("Primary Document: "+"PrimaryTargetDocType"+i);
                          
                          System.out.println("Primary Document: "+primCategory);
                        System.out.println("Primary Documenttype: "+primType);
                        
                        
                        System.out.println("Converted Doc Category : "+Mapper.retrieveDoc(primCategory));
                        System.out.println("Converted Doc Type : "+Mapper.retrieveDoc(primType));
                   }

                   if(i!=1){
                 
                         documentDetailsDTO=null;
                         documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   }
                   
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(primCategory));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(primType));
                   documentDetailsDTO.setApplicSeqNo("1");
                   documentDetailsDTO.setCntryCode("IN");
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);
                   
              //     i=i+1;docs=docs+1;
            }
            
           /* if(docsCoapps1!=0){
            	System.out.println("1st Coapplicant Eclassifier Started");
            }
            
           for (int i=1;i<=docsCoapps1;i++)
            {
        	   
        	   
        	   
        	   
                   coapp1Category=DBUtils.readColumnWithRowID("CoApplicant1DocCategory"+i,scenarioID);
                   coapp1Type=DBUtils.readColumnWithRowID("CoApplicant1TargetDocType"+i,scenarioID);
                   
                   if((!coapp1Category.equals("null"))||!(coapp1Type.equals("null"))){
                	   
                
                   
                   coapp1Category=DBUtils.readColumnWithRowID("CoApplicant1DocCategory"+i,scenarioID);
                   coapp1Type=DBUtils.readColumnWithRowID("CoApplicant1TargetDocType"+i,scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp1Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp1Type));
                   documentDetailsDTO.setApplicSeqNo("2");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }
           
           if(docsCoapps2!=0){
           	System.out.println("2nd Coapplicant Eclassifier Started");
           }
           
            for (int i=1;i<=docsCoapps2;i++)
            {
                   coapp2Category=DBUtils.readColumnWithRowID("CoApplicant2DocCategory"+i,scenarioID);
                   coapp2Type=DBUtils.readColumnWithRowID("CoApplicant2TargetDocType"+i,scenarioID);
                   
                   if((coapp2Category.equals("null"))||(coapp2Type.equals("null"))){
                   
                   coapp2Category=DBUtils.readColumnWithRowID("CoApplicant2DocCategory"+i,scenarioID);
                   coapp2Type=DBUtils.readColumnWithRowID("CoApplicant2TargetDocType"+i,scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp2Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp2Type));
                   documentDetailsDTO.setApplicSeqNo("3");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }
            
            if(docsCoapps3!=0){
            	System.out.println("3rd Coapplicant Eclassifier Started");
            }
            
            for (int i=1;i<=docsCoapps3;i++)
            {
                   coapp3Category=DBUtils.readColumnWithRowID("CoApplicant3DocCategory"+i,scenarioID);
                   coapp3Type=DBUtils.readColumnWithRowID("CoApplicant3TargetDocType"+i,scenarioID);
                   
                   if((coapp3Category.equals("null"))||(coapp3Type.equals("null"))){
                   
                   coapp3Category=DBUtils.readColumnWithRowID("CoApplicant3DocCategory"+i,scenarioID);
                   coapp3Type=DBUtils.readColumnWithRowID("CoApplicant3TargetDocType"+i,scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp3Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp3Type));
                   documentDetailsDTO.setApplicSeqNo("4");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }
     
            if(docsCoapps4!=0){
            	System.out.println("4th Coapplicant Eclassifier Started");
            }
            
            
            for (int i=1;i<=docsCoapps4;i++)
            {
                   coapp4Category=DBUtils.readColumnWithRowID("CoApplicant4DocCategory"+i,scenarioID);
                   coapp4Type=DBUtils.readColumnWithRowID("CoApplicant4TargetDocType"+i,scenarioID);
                   
                   if((coapp4Category.equals("null"))||(coapp4Type.equals("null"))){
                   
                   coapp4Category=DBUtils.readColumnWithRowID("CoApplicant4DocCategory"+i,scenarioID);
                   coapp4Type=DBUtils.readColumnWithRowID("CoApplicant4TargetDocType"+i,scenarioID);
                   
                   
                   }
                   documentDetailsDTO= null;
                   documentDetailsDTO = new RTOBDocumentDetailsDTO();
                   documentDetailsDTO.setCustName("RTOB Automation");
                   documentDetailsDTO.setTxnRefNo(appid);
                   documentDetailsDTO.setDocCatgoyCode(Mapper.retrieveDoc(coapp4Category));
                   documentDetailsDTO.setDocumentType(Mapper.retrieveDoc(coapp4Type));
                   documentDetailsDTO.setApplicSeqNo("5");
                   documentDetailsDTO.setCntryCode("IN");  
                   documentDetailsDTO.setTxnType("CR");
                   documentDetailsDTO.setDocPageCount("15");
                   documentDetailsDTO.setCreatedID("1553401");
                   documentDetailsDTO.setSrcCreatedDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setDocRecDate(dateFormat.format(new Date()));
                   documentDetailsDTO.setFileName(fileName);
                   documentDetailsDTO.setFolderPath(folderPath);
                   documentDetailsDTOs.add(documentDetailsDTO);

            }*/

			
			documentAdd.addCSDocument(documentDetailsDTOs);
			System.out.println("Done.");
		} catch (Exception e) {
			System.out.println("ERROR : "+e.getMessage());
		}
	
		System.out.println("-----------------------------------------eClassify ENDS------------------------------------");
		}
}