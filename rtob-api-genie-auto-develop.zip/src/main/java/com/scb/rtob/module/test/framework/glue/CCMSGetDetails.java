package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.SoapServiceCall;

import cucumber.api.java.en.Given;


public class CCMSGetDetails {
	SoapServiceCall soapClient = new SoapServiceCall();
	public static Logger logger = Logger.getLogger(CCMSGetDetails.class);
	
	String sceID = GetCase.scenarioID; 
	
	String userName= GetCase.envmap.get("soapUserName");
	String password =GetCase.envmap.get("soapPassWord"); 
	
	
	@Given("^Call CCMS GetDetails api for Fullfilment$")
	public void GetCCMSDetails() throws IOException { 
		/* Adding URL and login values to the Request*/
		String urlResource= GetCase.envmap.get("CCMSCCenquirygetDetails_URL");		
		Map<String, String> authHeaders = new HashMap<String, String>();
	    authHeaders.put("username", userName);
	    authHeaders.put("password", password);
	    
		/* Adding Header values to the Request*/
		Map<String, String> reqHeaders = new HashMap<String, String>();
		reqHeaders.put("SOAPAction","scbCoreBankingCreditCardCreditCardEnquiry_v1_ws_provider_v1_creditCardEnquiry_Binder_getDetails");
		String strContentType = "text/xml;charset=UTF-8;";
		/*Adding input parameters to the Hashmaps from DB */
//		xmlReqParams.put("ns2:CardNum", "4129037090873902");
//		xmlReqParams.put("ns1:countryCode", "IN");
//		xmlReqParams.put("ns2:SCB_EntityType", "05");
//		xmlReqParams.put("ns2:SCB_SourceFlag", "RTO");
//		xmlReqParams.put("ns2:SCB_FuncCode", "16");		
		String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"};
//		String query= GetCase.envmap.get("soapuiquery");
		try {
			DBUtils.convertDBtoMap("soapuiquery");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Map<String, String> xmlReqParams = new HashMap<String, String>();
        for(int t=0;t<fieldHeader.length;t++)
        {
                        String temp = fieldHeader[t].replaceFirst(":", "_");
                        String val = DBUtils.readColumnWithRowID(temp,sceID);
                        xmlReqParams.put(fieldHeader[t], val);
        } 
        
		String soapEnvelope = null;
		try {
			/* Parsing Input values to the Request*/
			soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetDetails.xml", xmlReqParams);
			logger.info(soapEnvelope);
		} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/* Providing Response values required */
		String[] resArrParams = {"crdenq:SCB_CustNum","crdenq:CardCategory"};
		Map<String, String> resParams = null;
		try {
			/* Submiting updated request and obtaining the response map*/
			String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
			resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
			for(Map.Entry<String, String> m: resParams.entrySet()){ ;
			logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
			try {
				compareRTOBTestDataVsXMLResponse(resParams);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		catch (ParserConfigurationException | SAXException | IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();

		} 

	}
	public void compareRTOBTestDataVsXMLResponse(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException 
	{
	              DBUtils.convertDBtoMap("fulldatatablename");
	              boolean t1,t2 = false;
	              boolean finalflag = true;
	              
	                      t1 = xmlResponse.get("CardCategory").equalsIgnoreCase(DBUtils.readColumnWithRowID("Card_Category",sceID).toString());
	                     t2 = xmlResponse.get("CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("Cust_Num",sceID).toString());
	              finalflag = t1 && t2;
	              
	               if(finalflag)
	              {
	                     System.out.println("XML responses are compared with RTOB test data");
	              }
	              
	}
	    //Tanushree 3/12/2018
	
		@Given("Get financial details for CCMS")
		public void GetCCMSFinanceDetails() throws Throwable { 
			
			String urlResource= GetCase.envmap.get("CCMSCCenquirygetDetails_URL");
			Map<String, String> authHeaders = new HashMap<String, String>();
		    authHeaders.put("username", userName);
		    authHeaders.put("password", password);
			
			/* Adding Header values to the Request*/
			Map<String, String> reqHeaders = new HashMap<String, String>();
			reqHeaders.put("SOAPAction","scbCoreBankingCreditCardCreditCardEnquiry_v1_ws_provider_v1_creditCardEnquiry_Binder_getFinancialDetails");
			String strContentType = "text/xml;charset=UTF-8;";
			String[] fieldHeader = {"ns2:CardNum","ns2:SCB_EntityType","ns2:SCB_SourceFlag"};
			
			try {
				DBUtils.convertDBtoMap("soapuiquery");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			Map<String, String> xmlReqParams = new HashMap<String, String>();
	        for(int t=0;t<fieldHeader.length;t++)
	        {
	                        String temp = fieldHeader[t].replaceFirst(":", "_");
	                        String val = DBUtils.readColumnWithRowID(temp,sceID);
	                        xmlReqParams.put(fieldHeader[t], val);
	        } 
			String soapEnvelope = null;
			try {
				/* Parsing Input values to the Request*/
				soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetFinanceDetails.xml", xmlReqParams);
				logger.info(soapEnvelope);
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/* Providing Response values required */
			String[] resArrParams = {"crdenq:SCB_InterestPerDiem", "crdenq:AcctIdentType", "crdenq:Amt"};
			Map<String, String> resParams = null;
			try {
				/* Submiting updated request and obtaining the response map*/
				String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
				resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
				for(Map.Entry<String, String> m: resParams.entrySet()){ ;
				logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
				}
			}
			catch (ParserConfigurationException | SAXException | IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			}			
			DBUtils.convertDBtoMap("fulldatatablename");
            boolean t1,t2,t3 = false;
            boolean finalflag = true;
            
                    t1 = resParams.get("SCB_InterestPerDiem").equalsIgnoreCase(DBUtils.readColumnWithRowID("InterestPerDiem",sceID).toString());
                   t2 = resParams.get("crdenq_AcctIdentType").equalsIgnoreCase(DBUtils.readColumnWithRowID("AcctIdentType",sceID).toString());
                   t3 = resParams.get("crdenq_Amt").equalsIgnoreCase(DBUtils.readColumnWithRowID("Amount",sceID).toString());
            finalflag = t1 && t2 && t3;
            
             if(finalflag)
            {
                   System.out.println("XML responses are compared with RTOB test data");
            }
		}
		
		
		
		@Given("Get card profile details for CCMS")
		public void GetCardProfileDetails() throws Throwable { 
			
			String urlResource= GetCase.envmap.get("CCMSCardProfilegetDetails_URL");
			Map<String, String> authHeaders = new HashMap<String, String>();
		    authHeaders.put("username", userName);
		    authHeaders.put("password", password);
		    
			/* Adding Header values to the Request*/
			Map<String, String> reqHeaders = new HashMap<String, String>();
			reqHeaders.put("SOAPAction","scbCoreBankingCreditCardCreditCardProfile_v1_ws_provider_v1_creditCardProfile_Binder_getDetails");
			String strContentType = "text/xml;charset=UTF-8;";
			String[] fieldHeader = {"ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:PartyId"};
			
			try {
				DBUtils.convertDBtoMap("soapuiquery");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			Map<String, String> xmlReqParams = new HashMap<String, String>();
	        for(int t=0;t<fieldHeader.length;t++)
	        {
	                        String temp = fieldHeader[t].replaceFirst(":", "_");
	                        String val = DBUtils.readColumnWithRowID(temp,sceID);
	                        logger.info(val);
	                        xmlReqParams.put(fieldHeader[t], val);
	        } 
			String soapEnvelope = null;
			try {
				/* Parsing Input values to the Request*/
				soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetCardProfileDetails.xml", xmlReqParams);
				logger.info(soapEnvelope);
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/* Providing Response values required */
			String[] resArrParams = {"crdprf:customerFullName","crdprf:dateOfBirth","crdprf:AddressInformation"};
			Map<String, String> resParams = null;
			try {
				/* Submiting updated request and obtaining the response map*/
				String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
				resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
				for(Map.Entry<String, String> m: resParams.entrySet()){ ;
				logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
				}
			}
			catch (ParserConfigurationException | SAXException | IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			}			
			DBUtils.convertDBtoMap("fulldatatablename");
            boolean t1,t2,t3 = false;
            boolean finalflag = true;
            
                    t1 = resParams.get("crdprf_customerFullName").equalsIgnoreCase(DBUtils.readColumnWithRowID("FullName",sceID).toString());
                   t2 = resParams.get("crdprf_dateOfBirth").equalsIgnoreCase(DBUtils.readColumnWithRowID("DOB",sceID).toString());
                   t3 = resParams.get("crdprf_AddressInformation").equalsIgnoreCase(DBUtils.readColumnWithRowID("Address1_Address_Line_1",sceID).toString());
            finalflag = t1 && t2 && t3;
            
             if(finalflag)
            {
                   System.out.println("XML responses are compared with RTOB test data");
            }
		}
		

		
		@Given("Get card listing details for CCMS")
		public void GetCardListingDetails() throws Throwable { 
			
			String urlResource= GetCase.envmap.get("CCMSCardProfilegetDetails_URL");
			Map<String, String> authHeaders = new HashMap<String, String>();
		    authHeaders.put("username", userName);
		    authHeaders.put("password", password);
			
			/* Adding Header values to the Request*/
			Map<String, String> reqHeaders = new HashMap<String, String>();
			reqHeaders.put("SOAPAction","scbCoreBankingCreditCardCreditCardProfile_v1_ws_provider_v1_creditCardProfile_Binder_getCardListing");
			String strContentType = "text/xml;charset=UTF-8;";
			String[] fieldHeader = {"ns1:countryCode","ns2:SCB_RelId","ns2:SCB_EntityType","ns2:SCB_SourceFlag"};
			
			try {
				DBUtils.convertDBtoMap("soapuiquery");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			Map<String, String> xmlReqParams = new HashMap<String, String>();
	        for(int t=0;t<fieldHeader.length;t++)
	        {
	                        String temp = fieldHeader[t].replaceFirst(":", "_");
	                        String val = DBUtils.readColumnWithRowID(temp,sceID);
	                        logger.info(val);
	                        xmlReqParams.put(fieldHeader[t], val);
	        } 
			String soapEnvelope = null;
			try {
				/* Parsing Input values to the Request*/
				soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetCardListingDetails.xml", xmlReqParams);
				logger.info(soapEnvelope);
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/* Providing Response values required */
			String[] resArrParams = {"crdprf:SCBCardInfo","crdprf:SCB_CardStatus","crdprf:SCB_ExpDt","crdprf:AcctStatusCode"};
			Map<String, String> resParams = null;
			try {
				/* Submiting updated request and obtaining the response map*/
				String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
				resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
				for(Map.Entry<String, String> m: resParams.entrySet()){ ;
				logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
				}
			}
			catch (ParserConfigurationException | SAXException | IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			}	
			DBUtils.convertDBtoMap("fulldatatablename");
            boolean t1,t2,t3,t4 = false;
            boolean finalflag = true;
            
                    t1 = resParams.get("crdprf_SCBCardInfo").equalsIgnoreCase(DBUtils.readColumnWithRowID("CardInfo",sceID).toString());
                   t2 = resParams.get("crdprf_SCB_CardStatus").equalsIgnoreCase(DBUtils.readColumnWithRowID("Status",sceID).toString());
                   t3 = resParams.get("crdprf_SCB_ExpDt").equalsIgnoreCase(DBUtils.readColumnWithRowID("ExpDt",sceID).toString());
                   t4 = resParams.get("crdprf:AcctStatusCode").equalsIgnoreCase(DBUtils.readColumnWithRowID("StatusCode",sceID).toString());
                   
            finalflag = t1 && t2 && t3 && t4;
            
             if(finalflag)
            {
                   System.out.println("XML responses are compared with RTOB test data");
            }
			
		}
 
		@Given("^Call CCMS GetLimitDetails api for Fullfilment$")
		public void GetCCMSLimitDetails() throws IOException { 
			/* Adding URL and login values to the Request*/
			String urlResource= GetCase.envmap.get("CCMSCardLimitDetails_URL");		
			Map<String, String> authHeaders = new HashMap<String, String>();
		    authHeaders.put("username", userName);
		    authHeaders.put("password", password);
		    
			/* Adding Header values to the Request*/
			Map<String, String> reqHeaders = new HashMap<String, String>();
			reqHeaders.put("SOAPAction","scbCoreBankingCreditCardCreditCardEnquiry_v1_ws_provider_v1_creditCardEnquiry_Binder_getLimitDetails");
			String strContentType = "text/xml;charset=UTF-8;";
			/*Adding input parameters to the Hashmaps from DB */
//			xmlReqParams.put("ns2:CardNum", "4129037090873902");
//			xmlReqParams.put("ns1:countryCode", "IN");
//			xmlReqParams.put("ns2:SCB_EntityType", "05");
//			xmlReqParams.put("ns2:SCB_SourceFlag", "RTO");
//			xmlReqParams.put("ns2:SCB_FuncCode", "16");		
			String[] fieldHeader = {"ns2:CardNum","ns1:countryCode","ns2:SCB_EntityType","ns2:SCB_SourceFlag","ns2:SCB_FuncCode"};
//			String query= GetCase.envmap.get("soapuiquery");
			try {
				DBUtils.convertDBtoMap("soapuiquery");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			Map<String, String> xmlReqParams = new HashMap<String, String>();
	        for(int t=0;t<fieldHeader.length;t++)
	        {
	                        String temp = fieldHeader[t].replaceFirst(":", "_");
	                        String val = DBUtils.readColumnWithRowID(temp,sceID);
	                        xmlReqParams.put(fieldHeader[t], val);
	        } 
	        
			String soapEnvelope = null;
			try {
				/* Parsing Input values to the Request*/
				soapEnvelope = soapClient.updateXmlRequest("src"+File.separator+"test"+File.separator+"resources"+File.separator+"xmltemplates"+File.separator+"ccmsGetDetails.xml", xmlReqParams);
				logger.info(soapEnvelope);
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			/* Providing Response values required */
			String[] resArrParams = {"crdenq:SCB_CustNum","crdlmt:Amt","crdlmt:SCB_CardType"};
			Map<String, String> resParams = null;
			try {
				/* Submiting updated request and obtaining the response map*/
				String xmlresponse = soapClient.submitPostAuth(urlResource,authHeaders ,reqHeaders, strContentType, soapEnvelope);
				resParams = soapClient.readXmlResponse(xmlresponse, resArrParams);
				for(Map.Entry<String, String> m: resParams.entrySet()){ ;
				logger.info("Key-"+m.getKey()+" : "+"Value-"+m.getValue());
				try {
					compareRTOBTestDataVsXMLResponseLimit(resParams);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			}
			catch (ParserConfigurationException | SAXException | IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			} 

		}
		public void compareRTOBTestDataVsXMLResponseLimit(Map<String,String> xmlResponse) throws ClassNotFoundException, SQLException, IOException 
		{
		              DBUtils.convertDBtoMap("fulldatatablename");
		              boolean t1,t2,t3 = false;
		              boolean finalflag = true;
		              
		                      t1 = xmlResponse.get("crdenq:SCB_CustNum").equalsIgnoreCase(DBUtils.readColumnWithRowID("CustomerID",sceID).toString());
		                     t2 = xmlResponse.get("crdlmt:Amt").equalsIgnoreCase(DBUtils.readColumnWithRowID("Amount",sceID).toString());
		                     t3 = xmlResponse.get("crdlmt:SCB_CardType").equalsIgnoreCase(DBUtils.readColumnWithRowID("CardType",sceID).toString());
		              finalflag = t1 && t2 && t3;
		              
		               if(finalflag)
		              {
		                     System.out.println("XML responses are compared with RTOB test data");
		              }
		              
		}

}


