package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.CreditCheckCheckerSetValue;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**********************************@Author:Subramaniya Siva Ram A**************************************/      
public class CreditCheckCheckerGen {

static String fdcScenarioID = "1";

public static Logger logger = Logger.getLogger(CreditCheckCheckerGen.class);
public static JSONObject jsonReq;


/**************************************************************************************************
* Function to read,parse json file and authenticate.
* And Returns Authenticated application by logging in.
* @throws Throwable 
 **************************************************************************************************/

	
	@When("^Call the PromoteCase api for Credit Check Checker$")
	public static void promoteCreditCheckChecker() throws Throwable{
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("CreditCheckChecker_Template"));
	
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueCreditCheckChecker();
		
		/****************************Start - API call part**********************************************/
		RestAssured.baseURI = GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		
		 /****************************Authentication Part Starts****************************************/
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_CreditCheckChecker"));
		
		httpRequest.body(jsonReq);
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
		
	}
	
	@Then("^validate if the application moved from Credit Check Checker to '(.*)'")
	public static void validateWorkbasket(String currentWorkbasket) throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		if(currentWorkBasket.equalsIgnoreCase(GetCase.envmap.get("CurrentWorkBasket_FDCChecker")) && currentWorkbasket.equals(GetCase.envmap.get("CurrentWorkBasket_FDCChecker"))){
			
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+"Because CreditChecker has selected Approve Action");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")+", Actual : "+currentWorkBasket);
			Assert.assertTrue(true);
		}
		else if(GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get("CurrentWorkBasket_DisplayOffers"))&&currentWorkbasket.equals(GetCase.envmap.get("CurrentWorkBasket_FDCChecker"))){
			
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+"Because CreditChecker has selected Reject Action");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_InternalVerification")+", Actual : "+currentWorkBasket);
			Assert.assertTrue(true);
		}
		
		}
	
	 /**************************************************************************************************
     * Function to modify details by promoting via json file.
     * And Returns application with updated data in Fraud Risk Verification WorkBasket.
     * @throws ClassNotFoundException, SQLException, IOException 
     **************************************************************************************************/        

	public static void setValueCreditCheckChecker() throws ClassNotFoundException, SQLException, IOException{
			
			DBUtils.convertDBtoMap("acdquery");
			
			String CCCAction = DBUtils.readColumnWithRowID("creditcheckeraction", fdcScenarioID);
			
			RMSupervisorSetValue.setJSON(jsonReq);
			
				switch (CCCAction){
				
					case "A":{
						
						String comments = "APPROVED FOR TESTING";
						CreditCheckCheckerSetValue.setContent(CCCAction, comments);
						break;
						
					}
					case "R":{
						
						String comments = "REJECTED FOR TESTING";
						CreditCheckCheckerSetValue.setContent(CCCAction, comments);
						break;
						
					}
					
				}
							
			}

	
}
