package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.CreditCheckCheckerGen;
import com.scb.rtob.module.test.framework.glue.GetCase;

public class CreditCheckCheckerSetValue {
	
public static Logger logger = Logger.getLogger(CreditCheckCheckerSetValue.class);
	
	private static JSONObject json = CreditCheckCheckerGen.jsonReq;

	public static void main(String[] args) {
		

	}
	
	public static void setContent(String comments, String Action){
		
		JsonPath.parse(json).set("$.content.Comments", comments);
		JsonPath.parse(json).set("$.content.CreditCheckerActionList",Action);
		
	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	

}