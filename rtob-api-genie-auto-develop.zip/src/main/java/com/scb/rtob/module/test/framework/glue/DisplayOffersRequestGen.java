package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DisplayOffersRequestGen {
	

	private static JSONObject json = FDMRequestGen.jsonReq;
	public static Logger logger = Logger.getLogger(DisplayOffersRequestGen.class);
	
	static String NegativeProbableScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	@Then("^Call the PromoteCase api for Display Offers WB$")
	public static void promoteNativeProbable() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD_Flow"+File.separator+""+GetCase.envmap.get("OffersWB_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setDisplayOffers();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get(f"ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkbasket_DisplayOffers"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	
	@When("^Set values for DisplayOffers Set values $")
	
		public static void setDisplayOffers() throws Throwable, SQLException, IOException{
		
		DBUtils.convertDBtoMap("acdquery");
		
		setJSON(jsonReq);
	
		setDisplayffersWBDetails();
		
		}
	
	public static void setDisplayffersWBDetails(){
		
		JsonPath.parse(json).set("$.content.Comments",DBUtils.readColumnWithRowID("Active", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Decision",DBUtils.readColumnWithRowID("Decision", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.IsBureauEditTabActive",DBUtils.readColumnWithRowID("Active", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.IsIncomeEditTabActive",DBUtils.readColumnWithRowID("Active", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.IsPriceEscalationRequired",DBUtils.readColumnWithRowID("Active", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.IsPriceEscalationRequired",DBUtils.readColumnWithRowID("Active", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].OfferDetails[0].AppealAmount",DBUtils.readColumnWithRowID("AppealAmount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].OfferDetails[0].AppealEffectiveRate",DBUtils.readColumnWithRowID("AppealEffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].OfferDetails[0].AppealTenor",DBUtils.readColumnWithRowID("AppealTenor", GetCase.scenarioID));
	
	}

	
	/**************************************************************************************************
	 * Function to check if application has moved from DisplayOffers to Next WorkBasket.
	 * And Returns if application has moved to Next WorkBasket
	 * @throws Throwable
	 **************************************************************************************************/
	@Given("^validate if the application moved from DisplayOffer to Next WorkBasket$")
	public static void validateDisplayOffer() throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_RMSuperVisor")))
		{
			//**********'ACCEPT'
			logger.info("Selected 'ACCEPT' and moved to Archival");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Archival")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to Archival", currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_Archival")));
			
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_RMSuperVisor")))
		{	
			//**********'APPEAL'
			logger.info("Selected 'APPEAL' and moved to RM supervisor");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_RMSuperVisor")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to RM supervisor",currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_RMSuperVisor")));
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_Archival")))
		{	
			//**********'REJECT'
			logger.info("Selected 'REJECT' and moved to Archival");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Archival")+", Actual : "+currentWorkBasket);
			Assert.assertTrue(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_Archival")));
		}	
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CreditCheckChecker")))
		{	
			//**********'RESUBMIT'
			logger.info("Selected 'RESUBMIT' and moved to Archival");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_CreditCheckChecker")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to CreditCheckChecker", currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CreditCheckChecker")));
		}	
		else if(currentWorkBasket.contains(GetCase.envmap.get("")))
		{	
			//**********'REVERIFICATION'
			//Clarification Needed
		}
		else
		{
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+" Does Not Matches with Expected Workbasket");
			Assert.assertFalse("Does Not Matches with any Expected Workbasket",false);
		}
	}
	

}
