package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;

public class Investigation {
	public static Logger logger = Logger.getLogger(Investigation.class);
	public static JSONObject jsonReq;
	private static JSONObject json = Investigation.jsonReq;
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void setValueInvestigation() throws ClassNotFoundException, SQLException, IOException
	{		
		DBUtils.convertDBtoMap("acdquery");				
		String investigationAction = DBUtils.readColumnWithRowID("Investigation Action", GetCase.scenarioID);
		String investigationRemark = DBUtils.readColumnWithRowID("Investigation Remark", GetCase.scenarioID);
		
		setJSON(jsonReq);
		if(investigationAction!=null)
		{JsonPath.parse(jsonReq).set("$.content.InvestigationAction",investigationAction);}
		else{logger.info("Investigation Action in DB is null");}
		
		if(investigationRemark!=null)
		{JsonPath.parse(jsonReq).set("$.content.Comments",investigationRemark);}
		else{logger.info("Investigation Remark in DB is null");}
		
	}
	
    /**************************************************************************************************
    * Function to read,parse json file and authenticate.
    * And Returns Authenticated application by logging in.
    * @throws Throwable 
     **************************************************************************************************/

	@Given("^Call the PromoteCase api for InvestigationWB$")
	public static void promoteInvestigation() throws Throwable {
		
		
		JSONParser parser = new JSONParser();
		
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("Investigation_Template"));
		
		
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueInvestigation();
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		
		/****************************Authentication Part Starts****************************************/
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_Investigation"));
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info("GetCase.response.getStatusCode() :----------------------------->"+GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	

	@Given("^validate if the application moved to next logical step$")
	/**************************************************************************************************
	 * In Investigation WB we need to perform 1 Action i.e Approve or Decline or Refer investigation
	 *   Approve- Application will move to FraudRiskChecker 
	 *   Decline- Application will move to FrontlineReferral / Archival / InternalVerification
	 *   Refer- 

	 **************************************************************************************************/
	public static void validateNextWorkbasket() throws Throwable {
		
		String response = GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info(response);
		
		if(response.contains(GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker")))
		{
			logger.info("APPROVED and moved to next logical step: FraudRiskChecker");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker")+", Actual : "+response);
			Assert.assertTrue(true);
		}
		else if(response.contains(GetCase.envmap.get("CurrentWorkBasket_Archival")))
		{
			logger.info("DECLINE and moved to next step: Archival");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_InternalVerification")+", Actual : "+response);
			Assert.assertTrue(true);
		}
		else if(response.contains(GetCase.envmap.get("CurrentWorkBasket_FrontlineReferral")))
		{
			logger.info("DECLINE and moved to next step: Frontline Referral WB");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_FrontlineReferral")+", Actual : "+response);
			Assert.assertTrue(true);
		}
		else
		{
			logger.info("Assert Fail - Did not matches Expected");
			Assert.assertTrue(false);		
			
		}
		}
	

	
	
	

}
