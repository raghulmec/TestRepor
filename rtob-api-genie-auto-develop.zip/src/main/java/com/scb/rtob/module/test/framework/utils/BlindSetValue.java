package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class BlindSetValue {
	
	public static Logger logger = Logger.getLogger(BlindSetValue.class);
	
	private static JSONObject json = BlindRequestGen.jsonReq;
	
	
	static String FullName = null;
	static String coApplicantFullName = null;

	public static void main(String[] args) {
		

	}
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void setContent(){
		
		FullName = DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				   DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				   DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.CustFullName",FullName);
	}
	
	public static void setCustomerDetails(){
		logger.info("setting");
		
		JsonPath.parse(json).set("$.content.Customers[0].Title",DBUtils.readColumnWithRowID("Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DateOfBirth",DBUtils.readColumnWithRowID("DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].FirstName",DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		
		
		logger.info("Reading from Json File: "+JsonPath.parse(json).read("$.content.Customers[0].FirstName"));
		
		logger.info("GET JSON: " +json.get("$.content.Customers[0].FirstName"));
		logger.info(DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].LastName",DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].MiddleName",DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Country Of Birth Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Residence Country Description", GetCase.scenarioID));
		
		
		//***************************************************Vijay-02082018**********************************************************
		JsonPath.parse(json).set("$.content.Customers[0].ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
	
		
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
	}
	
	
	public static void setCustomerAliasType(){
        
        JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Alias Type", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Alias(es)", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Alias First Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Alias Last Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("AliasMiddleName", GetCase.scenarioID));
        
        JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant1 Alias Type", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant1 Aliases", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant1 Alias First Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Last Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Middle Name", GetCase.scenarioID));
        
        JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant2 Alias Type", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant2 Aliases", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant2 Alias First Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Last Name", GetCase.scenarioID));
        JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Middle Name", GetCase.scenarioID));
        
 }

	
	public static void setMultipleCustomerContactDetails(){
		
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));



	JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Contact type Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Contact Details1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
	
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactType",DBUtils.readColumnWithRowID("Contact type Code2", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactNumber",DBUtils.readColumnWithRowID("Contact Details2", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
	
	
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));



	JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Contact type Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Contact Details1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
	
}
	
	public static void setApplicantProductRelationship(){
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
	}
	
	public static void setEmployeementDetails(){
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Industry",DBUtils.readColumnWithRowID("ISIC Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryDescription",DBUtils.readColumnWithRowID("ISIC Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Occupation Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Occupation Description", GetCase.scenarioID));
		
	}
	
	public static void setDocumentDetails(){		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		
	}
	
	
	public static void setApplicationDetailsTab(){
				
		JsonPath.parse(json).set("$.content.SrcID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourceID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SalesID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ReferralID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.AcquisitionCode",DBUtils.readColumnWithRowID("Acquisition Channel", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ApplicationBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchCode",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
		//***************************************Vijay-02082018******************************************
	//	JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		
	}
	
public static void setPrimaryProductDetailsTab(){
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
		
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("Usage Type", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BundleType",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));		

		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID));
			
		/*********************************************** TD ********************************************************/
		
		//JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PLODSpecialRate",DBUtils.readColumnWithRowID("Special Rate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TermPeriod",DBUtils.readColumnWithRowID("TD_Term", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TenureType",DBUtils.readColumnWithRowID("Tenure Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ValueDate",DBUtils.readColumnWithRowID("Value Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountNo",DBUtils.readColumnWithRowID("Fund Account No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeAmount",DBUtils.readColumnWithRowID("Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PaymentMode",DBUtils.readColumnWithRowID("Payment Mode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].InterestFrqcy",DBUtils.readColumnWithRowID("Interest - Frequency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOne",DBUtils.readColumnWithRowID("2-in-1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Lien",DBUtils.readColumnWithRowID("Lien", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].NumberOfDeposit",DBUtils.readColumnWithRowID("No of Deposit", GetCase.scenarioID));
		
		

}
	
	public static void setSecondaryProductDetailsTab(int productsequence){
		
	
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type"+productsequence, GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductCode",DBUtils.readColumnWithRowID("ProductCode"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory"+productsequence, GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship[0].FullName",FullName);

		
		/*********************************************** TD ********************************************************/
		
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PLODSpecialRate",DBUtils.readColumnWithRowID("Special Rate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TermPeriod",DBUtils.readColumnWithRowID("TD_Term", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TenureType",DBUtils.readColumnWithRowID("Tenure Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ValueDate",DBUtils.readColumnWithRowID("Value Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountNo",DBUtils.readColumnWithRowID("Fund Account No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeAmount",DBUtils.readColumnWithRowID("Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PaymentMode",DBUtils.readColumnWithRowID("Payment Mode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].InterestFrqcy",DBUtils.readColumnWithRowID("Interest - Frequency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOne",DBUtils.readColumnWithRowID("2-in-1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lien",DBUtils.readColumnWithRowID("Lien", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].NumberOfDeposit",DBUtils.readColumnWithRowID("No of Deposit", GetCase.scenarioID));
		
	
	}
	

	
public static void setApplicantProductRelationship(int productsequence, int coapplicantsequence){
	FullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
			   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
			   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
	//Product
			JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship["+coapplicantsequence+"].FullName",FullName);
			JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship["+coapplicantsequence+"].RelatedPartyType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" RelatedPartyType", GetCase.scenarioID));	
}
	
public static void setCoapplicantDetailsinProduct(){
	
	setApplicantProductRelationship(1,1);
	setApplicantProductRelationship(1,2);
	setApplicantProductRelationship(1,3);
	setApplicantProductRelationship(1,4);
	
	setApplicantProductRelationship(2,1);
	setApplicantProductRelationship(2,2);
	setApplicantProductRelationship(2,3);
	setApplicantProductRelationship(2,4);
	
	setApplicantProductRelationship(3,1);
	setApplicantProductRelationship(3,2);
	setApplicantProductRelationship(3,3);
	setApplicantProductRelationship(3,4);
	
	setApplicantProductRelationship(4,1);
	setApplicantProductRelationship(4,2);
	setApplicantProductRelationship(4,3);
	setApplicantProductRelationship(4,4);
	
	setApplicantProductRelationship(5,1);
	setApplicantProductRelationship(5,2);
	setApplicantProductRelationship(5,3);
	setApplicantProductRelationship(5,4);
}

public static void setCoapplicantDetails(int coapplicantsequence){
		
		FullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
				   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
				   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.CustFullName",FullName);
		
		//Customer
		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Title",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DateOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FirstName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LastName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MiddleName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));

	//Contact
	
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISD Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+"_ContactType_Classification", GetCase.scenarioID));
		
	//Employment
		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Industry",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Description", GetCase.scenarioID));

	//Documents
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date", GetCase.scenarioID));

	}
	
	
		
}
