package com.scb.rtob.module.test.framework.glue;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.json.stream.JsonGenerator;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jayway.jsonpath.spi.json.JsonSmartJsonProvider;

import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.utils.ACDSetValue;
import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.standardchartered.genie.util.FileUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ACDRequestGen {

	static String fdcScenarioID = "1";

	public static Logger logger = Logger.getLogger(ACDRequestGen.class);
	public static Response response;
	public static JSONObject jsonReqRes;
	public static org.json.simple.JSONObject jsonReq;
	public static JSONParser parser = new JSONParser();
	public static String CurrentWorkBasketActionOne;
	public static String CurrentWorkBasketActionTwo;
	public static String CurrentWorkBasketActionReason;
	public static String PathToNode;
	public static JsonSmartJsonProvider jsonprovider;

	@When("^Call the PromoteCase api from '(.*)'$")
	public static String promoteCaseAPI(String currentWorkBasket) throws Throwable{


		FileReader reader = new FileReader("./src/test/resources/jsontemplates/APITemplates/PutcaseTemplates.json");
		jsonReq = (org.json.simple.JSONObject) parser.parse(reader);

		//}



		//jsonReq = (JSONObject) parser.parse(reader);

		logger.info(jsonReq);


		/****************************Set values for JSON attributes*************************************/
		/**********Need Not be done as it is taken care in the previous StepDef call, UpdateByAtri**********/

		//setACDJSONAttributes(currentWorkBasket);

		logger.info(jsonReq);
		/****************************Start - API call part**********************************************/
		RestAssured.baseURI = GetCase.envmap.get("URIGet");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		//httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));


		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",currentWorkBasket);

		GetCase.scenarioCurrent.write("ApprefID : "+DBUtils.readColumnWithRowID("ApplicationRefNo", GetCase.scenarioID));
		GetCase.scenarioCurrent.write("ApprefID : "+GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.body(jsonReq);
		//httpRequest.body(jsonReqRes.toString());
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(org.json.simple.JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());


		if(GetCase.response.getStatusCode() != 200){
			GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
			GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
			//Assert.fail();
		}
		else{
			GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
			Assert.assertTrue("Pass", true);
		}

		//GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		//logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));

		String WorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+WorkBasket);


		return WorkBasket;

	}

	@Then("^validate if the application moved from '(.*)' to '(.*)'$")
	public static void validateWorkbasket(String previousWorkBasket, String ExpectedcurrentWorkBasket) throws Throwable {


		logger.info("Previous Workbasket : "+GetCase.envmap.get(previousWorkBasket));
		//logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		switch (CurrentWorkBasketActionOne){

			case "Approve":{

				logger.info("CIAction : " + CurrentWorkBasketActionOne);


				logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
				if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
					logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

			}

			case "Decline":{

				logger.info("CIAction : " + CurrentWorkBasketActionOne);

				logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
				if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
					logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

			}

			case "Recommend":{

				logger.info("CIAction : " + CurrentWorkBasketActionOne);

				logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
				if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
					logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

			}

			case "Refer":{

				logger.info("CIAction : " + CurrentWorkBasketActionOne);

				if((CurrentWorkBasketActionReason=="CI003")||(CurrentWorkBasketActionReason=="CI004")||(CurrentWorkBasketActionReason=="CI005")||(CurrentWorkBasketActionReason=="CI006")){

					logger.info("Refer Reason : " + CurrentWorkBasketActionReason);

					logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
					if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
						logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

				}
				else{

					if ((CurrentWorkBasketActionReason=="CI001")||(CurrentWorkBasketActionReason=="CI002")){

						logger.info("Refer Reason : " + CurrentWorkBasketActionReason);

						logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
						if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
							logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

					}
					else{

						if (CurrentWorkBasketActionReason=="CI007"){

							logger.info("Refer Reason : " + CurrentWorkBasketActionReason);

							logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
							if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
								logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));

						}

					}

				}

			}

		}

	}


	public static void setACDJSONAttributes(String currentWorkBasket) throws ClassNotFoundException, SQLException, IOException{

		logger.info(GetCase.envmap.get("acdquery"));
		DBUtils.convertDBtoMap("acdquery");

		String ActionJsonNodePathpw = GetCase.envmap.get("pyWorkParty").substring(2);
		String[]arrayActionpw = ActionJsonNodePathpw.split("\\.");
		int lengthActionpw = arrayActionpw.length;
		String lastelementActionpw = arrayActionpw[lengthActionpw-1];
		String toReplacepw = "."+lastelementActionpw;
		PathToNode = ActionJsonNodePathpw.replace(toReplacepw, "");
		logger.info(PathToNode);
		ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionpw, " ");



		switch (currentWorkBasket){

			case "DeDupe":

				DBUtils.convertDBtoMap("bdquery");
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("RelationshipNo", GetCase.scenarioID);
				String RelID = DBUtils.readColumnWithRowID("RelationshipNo", GetCase.scenarioID);;


				logger.info(JsonPath.parse(jsonReq).read(GetCase.envmap.get("DedupeLike")));
				java.util.List<String> Relationshipno = JsonPath.parse(jsonReq).read(GetCase.envmap.get("DedupeLike"));

				for(String Relation:Relationshipno){
					String Rel=Relation.trim();
					if(RelID.equalsIgnoreCase(Rel)){

						CurrentWorkBasketActionOne = "false";

						String ActionJsonNodePathLike = GetCase.envmap.get("SelectCheckBox").substring(2);
						String[]arrayActionLike = ActionJsonNodePathLike.split("\\.");
						int lengthActionLike = arrayActionLike.length;
						String lastelementActionLike = arrayActionLike[lengthActionLike-1];
						String toReplaceLike = "."+lastelementActionLike;
						PathToNode = ActionJsonNodePathLike.replace(toReplaceLike, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionLike, CurrentWorkBasketActionOne, "DedupeLike",RelID);


						CurrentWorkBasketActionOne = "true";
						String ActionJsonNodePathFC = GetCase.envmap.get("slectcheckboxTrue").substring(2);
						String[]arrayActionFC = ActionJsonNodePathFC.split("\\.");
						int lengthActionFC = arrayActionFC.length;
						String lastelementActionFC = arrayActionFC[lengthActionFC-1];
						String toReplaceFC = "."+lastelementActionFC;
						PathToNode = ActionJsonNodePathFC.replace(toReplaceFC, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionFC, CurrentWorkBasketActionOne,"DedupeLike",RelID);
					}

				}
				break;

			case "NegativeProbableWB":{

				//String NegativeCheck = "SHOLLINGANALLORE";
				String NegativeCheck = DBUtils.readColumnWithRowID("BureaverifyResponse", GetCase.scenarioID);
				logger.info(JsonPath.parse(jsonReq).read(GetCase.envmap.get("NegativeArea")));

				java.util.List<String> NegativeArea = JsonPath.parse(jsonReq).read(GetCase.envmap.get("NegativeArea"));
				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("BureaverifyResponse", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "TEST";
				String ActionJsonNodeNegative = GetCase.envmap.get("NegativeListCommnts").substring(2);
				String[]arrayActionNegative = ActionJsonNodeNegative.split("\\.");
				int lengthActionNegative = arrayActionNegative.length;
				String lastelementActionNegative = arrayActionNegative[lengthActionNegative-1];
				String toReplaceNegative = "."+lastelementActionNegative;
				PathToNode = ActionJsonNodeNegative.replace(toReplaceNegative, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionNegative, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("Negativeselection", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "M";NegativeMatch
				String ActionJsonNegativeBlock = GetCase.envmap.get("NegativeListBlockList").substring(2);
				String[]arrayActionBlock = ActionJsonNegativeBlock.split("\\.");
				int lengthActionBlock = arrayActionBlock.length;
				String lastelementActionBlock = arrayActionBlock[lengthActionBlock-1];
				String toReplaceBlock = "."+lastelementActionBlock;
				PathToNode = ActionJsonNegativeBlock.replace(toReplaceBlock, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionBlock, CurrentWorkBasketActionOne, "NegativeArea",NegativeCheck);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("NegativeMatch", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "true";
				String ActionJsonNegativeSelect = GetCase.envmap.get("NegativeMatchListSelected").substring(2);
				String[]arrayActionBselect = ActionJsonNegativeSelect.split("\\.");
				int lengthActionSelect = arrayActionBselect.length;
				String lastelementActionSelect = arrayActionBselect[lengthActionSelect-1];
				String toReplaceSelect = "."+lastelementActionSelect;
				PathToNode = ActionJsonNegativeSelect.replace(toReplaceSelect, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionSelect, CurrentWorkBasketActionOne, "NegativeArea",NegativeCheck);

				break;
			}


			case "FullCheckerReview":{


				CurrentWorkBasketActionOne = "A";
				String ActionJsonNodePathFC = GetCase.envmap.get("FullDataCaptureChecker").substring(2);
				String[]arrayActionFC = ActionJsonNodePathFC.split("\\.");
				int lengthActionFC = arrayActionFC.length;
				String lastelementActionFC = arrayActionFC[lengthActionFC-1];
				String toReplaceFC = "."+lastelementActionFC;
				PathToNode = ActionJsonNodePathFC.replace(toReplaceFC, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionFC, CurrentWorkBasketActionOne);
				break;
			}

			case "Exceptions":{


				CurrentWorkBasketActionOne = "true";
				String ActionJsonNodePathFC = GetCase.envmap.get("pySelected").substring(2);
				String[]arrayActionFC = ActionJsonNodePathFC.split("\\.");
				int lengthActionFC = arrayActionFC.length;
				String lastelementActionFC = arrayActionFC[lengthActionFC-1];
				String toReplaceFC = "."+lastelementActionFC;
				PathToNode = ActionJsonNodePathFC.replace(toReplaceFC, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionFC, CurrentWorkBasketActionOne);


				String skipService = GetCase.envmap.get("SkipService").substring(2);
				String[]arraySkipService = skipService.split("\\.");
				int lengthSkipService = arraySkipService.length;
				String lastelementSkipService = arraySkipService[lengthSkipService-1];
				String toReplaceSkipService = "."+lastelementSkipService;
				PathToNode = skipService.replace(toReplaceSkipService, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, toReplaceSkipService, "false");



				break;
			}

			case "FrontlineReferralWB":{

				if(GetCase.envmap.get("ReworkCategoryDesc").matches("ReworkCategoryDesc")){

					logger.info(JsonPath.parse(jsonReq).read(GetCase.envmap.get("ReworkCategoryDesc")));
					java.util.List<String> ReworkCategoryDesc = JsonPath.parse(jsonReq).read(GetCase.envmap.get("ReworkCategoryDesc"));

					logger.info(JsonPath.parse(jsonReq).read(GetCase.envmap.get("RMReferralRemarks")));
					java.util.List<String> ReferralRemarks = JsonPath.parse(jsonReq).read(GetCase.envmap.get("RMReferralRemarks"));
					int i=1;
					for (String Remarks : ReferralRemarks) {

						String DocCategory = addTheDocumentCatagoryinTemplate(Remarks);

						String NameOfTheDocument = selectTheDocumentType(Remarks);
						//if(NameOfTheDocument.contains(Remarks)){


						//CurrentWorkBasketActionOne = DocCategoryCode;
						String ActionJsonNodeDocUpload = GetCase.envmap.get("DocCategoryToUpload").substring(2);
						String[]arrayActionDocupload = ActionJsonNodeDocUpload.split("\\.");
						int lengthActionDocupload = arrayActionDocupload.length;
						String lastelementActionDocupload = arrayActionDocupload[lengthActionDocupload-1];
						String toReplaceDocupload = "."+lastelementActionDocupload;
						PathToNode = ActionJsonNodeDocUpload.replace(toReplaceDocupload, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDocupload, DocCategory);

						String ActionJsonNodeDocType = GetCase.envmap.get("DocTypeToUpload").substring(2);
						String[]arrayActionDocType = ActionJsonNodeDocType.split("\\.");
						int lengthActionDocType = arrayActionDocType.length;
						String lastelementActionDocType = arrayActionDocType[lengthActionDocType-1];
						String toReplaceDocType = "."+lastelementActionDocType;
						PathToNode = ActionJsonNodeDocType.replace(toReplaceDocType, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDocType, NameOfTheDocument);

						String ActionJsonDocUploadSucc = GetCase.envmap.get("DocUploadSuccess").substring(2);
						String[]arrayActionDocSucc = ActionJsonDocUploadSucc.split("\\.");
						int lengthActionDocSucc = arrayActionDocSucc.length;
						String lastelementActionDocSucc = arrayActionDocSucc[lengthActionDocSucc-1];
						String toReplaceDocSucc = "."+lastelementActionDocSucc;
						PathToNode = ActionJsonDocUploadSucc.replace(toReplaceDocSucc, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDocSucc, "true");


						String ActionJsonNodeIsDocUpload = GetCase.envmap.get("IsDocUploaded").substring(2);
						String[]arrayActionDocUpload = ActionJsonNodeIsDocUpload.split("\\.");
						int lengthActionDocUpload = arrayActionDocUpload.length;
						String lastelementActionDocUpload = arrayActionDocUpload[lengthActionDocUpload-1];
						String toReplaceIsDoc = "."+lastelementActionDocUpload;
						PathToNode = ActionJsonNodeIsDocUpload.replace(toReplaceIsDoc, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDocUpload, "true");

						String ActionJsonNodeuploadDoc = GetCase.envmap.get("UploadDocument").substring(2);
						String[]arrayActionUploadDoc = ActionJsonNodeuploadDoc.split("\\.");
						int lengthActionUplaodDoc = arrayActionUploadDoc.length;
						String lastelementActionuploadDoc = arrayActionUploadDoc[lengthActionUplaodDoc-1];
						String toReplaceuploadDoc = "."+lastelementActionuploadDoc;
						PathToNode = ActionJsonNodeuploadDoc.replace(toReplaceuploadDoc, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionuploadDoc, "14020189350001014560003227928.pdf");

						String ActionJsonNodeuploaApp = GetCase.envmap.get("UploadApplicant").substring(2);
						String[]arrayActionUploadApp = ActionJsonNodeuploaApp.split("\\.");
						int lengthActionUplaodApp = arrayActionUploadApp.length;
						String lastelementActionuploadApp = arrayActionUploadApp[lengthActionUplaodApp-1];
						String toReplaceuploadApp = "."+lastelementActionuploadApp;
						PathToNode = ActionJsonNodeuploaApp.replace(toReplaceuploadApp, "");
						logger.info(PathToNode);
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionuploadApp, "1");



						setReferralDocuments(Remarks,i);

						setProdDocumentList(Remarks,i);
						setDocuments(Remarks,i);
						i++;
					}/*else if(Remarks.contains("Work In")){

				}*/

				}

				String ActionJsonisRework = GetCase.envmap.get("IsReworkCompleted").substring(2);
				String[]arrayActionisRework = ActionJsonisRework.split("\\.");
				int lengthActionisRework = arrayActionisRework.length;
				String lastelementActionIsRework = arrayActionisRework[lengthActionisRework-1];
				String toReplaceisrework = "."+lastelementActionIsRework;
				PathToNode = ActionJsonisRework.replace(toReplaceisrework, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionIsRework, "true");

				String ActionJsonisReferralReson = GetCase.envmap.get("ReferralReson").substring(2);
				String[]arrayActionisReferralReson = ActionJsonisReferralReson.split("\\.");
				int lengthActionisReferralReson = arrayActionisReferralReson.length;
				String lastelementActionReferralReson = arrayActionisReferralReson[lengthActionisReferralReson-1];
				String toReplaceReferralReson = "."+lastelementActionReferralReson;
				PathToNode = ActionJsonisReferralReson.replace(toReplaceReferralReson, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionReferralReson, "true");


				//}

				break;
			}

			case "NorkomWorkBasket":{


				CurrentWorkBasketActionOne = "A";
				String ActionJsonNodePathRV = GetCase.envmap.get("NorkomAction").substring(2);
				String[]arrayActionRV = ActionJsonNodePathRV.split("\\.");
				int lengthActionRV = arrayActionRV.length;
				String lastelementActionRV = arrayActionRV[lengthActionRV-1];
				String toReplaceRV = "."+lastelementActionRV;
				PathToNode = ActionJsonNodePathRV.replace(toReplaceRV, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRV, CurrentWorkBasketActionOne);
				break;
			}

			case "CDD Reviewer":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("ResidenceVerification", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Y";
				String ActionJsonNodePathRV = GetCase.envmap.get("ResidenceVerification").substring(2);
				String[]arrayActionRV = ActionJsonNodePathRV.split("\\.");
				int lengthActionRV = arrayActionRV.length;
				String lastelementActionRV = arrayActionRV[lengthActionRV-1];
				String toReplaceRV = "."+lastelementActionRV;
				PathToNode = ActionJsonNodePathRV.replace(toReplaceRV, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRV, CurrentWorkBasketActionOne);
				break;
			}

			case "EDD Reviewer":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("ResidenceVerification", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Y";
				String ActionJsonNodePathRV = GetCase.envmap.get("ResidenceVerification").substring(2);
				String[]arrayActionRV = ActionJsonNodePathRV.split("\\.");
				int lengthActionRV = arrayActionRV.length;
				String lastelementActionRV = arrayActionRV[lengthActionRV-1];
				String toReplaceRV = "."+lastelementActionRV;
				PathToNode = ActionJsonNodePathRV.replace(toReplaceRV, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRV, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("AmountOfTransaction", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "10000";
				String ActionJsonNodeAmount = GetCase.envmap.get("AmountOfTranction").substring(2);
				String[]arrayActionAmount = ActionJsonNodeAmount.split("\\.");
				int lengthActionamount = arrayActionAmount.length;
				String lastelementActionAmount = arrayActionAmount[lengthActionamount-1];
				String toReplaceAmount = "."+lastelementActionAmount;
				PathToNode = ActionJsonNodeAmount.replace(toReplaceAmount, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionAmount, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CountryCDDPerformed", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "W";
				String ActionJsonCountry = GetCase.envmap.get("CountryOffCDD").substring(2);
				String[]arrayActionCountry = ActionJsonCountry.split("\\.");
				int lengthActionCountry = arrayActionCountry.length;
				String lastelementActionCountry = arrayActionCountry[lengthActionCountry-1];
				String toReplaceCountry = "."+lastelementActionCountry;
				PathToNode = ActionJsonCountry.replace(toReplaceCountry, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionCountry, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("NoOfTranction", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "2";
				String ActionJsonNodePath = GetCase.envmap.get("NoOfTranction").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				break;
			}


			case "MEDD Reviewer":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("ResidenceVerification", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Y";
				String ActionJsonNodePathRV = GetCase.envmap.get("ResidenceVerification").substring(2);
				String[]arrayActionRV = ActionJsonNodePathRV.split("\\.");
				int lengthActionRV = arrayActionRV.length;
				String lastelementActionRV = arrayActionRV[lengthActionRV-1];
				String toReplaceRV = "."+lastelementActionRV;
				PathToNode = ActionJsonNodePathRV.replace(toReplaceRV, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRV, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_CDDApproveName", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Ramakrishna";
				String ActionJsonNodeApproveName = GetCase.envmap.get("CDDApproveName").substring(2);
				String[]arrayActionAppName = ActionJsonNodeApproveName.split("\\.");
				int lengthActionAppName = arrayActionAppName.length;
				String lastelementActionAppName = arrayActionAppName[lengthActionAppName-1];
				String toReplaceAppName = "."+lastelementActionAppName;
				PathToNode = ActionJsonNodeApproveName.replace(toReplaceAppName, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionAppName, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_ComplinceApproveName", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Tanu";
				String ActionJsonComName = GetCase.envmap.get("ComplinceApproveName").substring(2);
				String[]arrayActionComName = ActionJsonComName.split("\\.");
				int lengthActionComName = arrayActionComName.length;
				String lastelementActionComName = arrayActionComName[lengthActionComName-1];
				String toReplaceComName = "."+lastelementActionComName;
				PathToNode = ActionJsonComName.replace(toReplaceComName, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionComName, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("KYCCountryStatus", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "B";
				String ActionJsonNodePath = GetCase.envmap.get("KYCCountryStatus").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Remarks", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Test";
				String ActionJsonremarks = GetCase.envmap.get("Remarks").substring(2);
				String[]arrayActionRemarks = ActionJsonremarks.split("\\.");
				int lengthRemarks = arrayActionRemarks.length;
				String lastelementRemarks = arrayActionRemarks[lengthRemarks-1];
				String toReplaceRemarks = "."+lastelementRemarks;
				PathToNode = ActionJsonremarks.replace(toReplaceRemarks, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementRemarks, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_SegmentHeadApproverName", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Dilawar";
				String ActionJsonSegmentApprove = GetCase.envmap.get("SegmentHeadApproverName").substring(2);
				String[]arraySegment = ActionJsonSegmentApprove.split("\\.");
				int lengthSegment = arraySegment.length;
				String lastelementSegment = arraySegment[lengthSegment-1];
				String toReplaceSeg = "."+lastelementSegment;
				PathToNode = ActionJsonSegmentApprove.replace(toReplaceSeg, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementSegment, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_AssignReasonCode", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "MIG";
				String ActionJsonAssignReasonCode = GetCase.envmap.get("AssignReasonCode").substring(2);
				String[]arrayReasonCode = ActionJsonAssignReasonCode.split("\\.");
				int lengthReasonCode = arrayReasonCode.length;
				String lastelementReasonCode = arrayReasonCode[lengthReasonCode-1];
				String toReplaceReason = "."+lastelementReasonCode;
				PathToNode = ActionJsonAssignReasonCode.replace(toReplaceReason, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReasonCode, CurrentWorkBasketActionOne);




				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_InfoCode", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "SMS";
				String ActionJsonMisCode = GetCase.envmap.get("InfoCode").substring(2);
				String[]arrayMISCode = ActionJsonMisCode.split("\\.");
				int lengthMisCode = arrayMISCode.length;
				String lastelementMISCode = arrayMISCode[lengthMisCode-1];
				String toReplaceMISCode = "."+lastelementMISCode;
				PathToNode = ActionJsonMisCode.replace(toReplaceMISCode, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementMISCode, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("MEDD_InfoValue", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "YES";
				String ActionJsonMisValue = GetCase.envmap.get("InfoValue").substring(2);
				String[]arrayMISValue = ActionJsonMisValue.split("\\.");
				int lengthMisValue = arrayMISValue.length;
				String lastelementMISValue = arrayMISValue[lengthMisValue-1];
				String toReplaceMISValue = "."+lastelementMISValue;
				PathToNode = ActionJsonMisValue.replace(toReplaceMISValue, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementMISValue, CurrentWorkBasketActionOne);

				break;
			}

			case "FraudRiskCheck":{


				String ActionJsonNodePathPFN = GetCase.envmap.get("pyFullName").substring(2);
				String[]arrayActionPFN = ActionJsonNodePathPFN.split("\\.");
				int lengthActionPFN = arrayActionPFN.length;
				String lastelementActionPFN = arrayActionPFN[lengthActionPFN-1];
				String toReplacePFN = "."+lastelementActionPFN;
				PathToNode = ActionJsonNodePathPFN.replace(toReplacePFN, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionPFN, "Chittenedi, Venkat Sandeep");

				String ActionJsonNodePath3 = GetCase.envmap.get("pyWorkPartyUri").substring(2);
				String[]arrayAction3 = ActionJsonNodePath3.split("\\.");
				int lengthAction3 = arrayAction3.length;
				String lastelementAction3 = arrayAction3[lengthAction3-1];
				String toReplace3 = "."+lastelementAction3;
				PathToNode = ActionJsonNodePath3.replace(toReplace3, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction3, "1577701");

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("FraudVal", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Screened";
				String ActionJsonNodePath = GetCase.envmap.get("ScreenedStatus").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				break;
			}

			case "CreditCheckChecker":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "A";
				String ActionJsonNodePath = GetCase.envmap.get("CreditCheckerActionList").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);
				break;
			}

			case "PriceEscalationL3WB":{

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "20";
				String ActionJsonNodePath = GetCase.envmap.get("ApprovedEffectiveRate").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "10000";
				String ActionJsonfeeAmount = GetCase.envmap.get("ApprovedFeeAmount").substring(2);
				String[]arrayFeeAmount = ActionJsonfeeAmount.split("\\.");
				int lengthFeeAmount = arrayFeeAmount.length;
				String lastelementFeeAmount = arrayFeeAmount[lengthFeeAmount-1];
				String toReplaceFeeamount = "."+lastelementFeeAmount;
				PathToNode = ActionJsonfeeAmount.replace(toReplaceFeeamount, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementFeeAmount, CurrentWorkBasketActionOne);

				break;
			}

			case "PriceEscalationWB":{

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "23";
				String ActionJsonNodePath = GetCase.envmap.get("PEApprovedEffectiveRate").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "10000";
				String ActionJsonfeeAmount = GetCase.envmap.get("AppealFeeAmount").substring(2);
				String[]arrayFeeAmount = ActionJsonfeeAmount.split("\\.");
				int lengthFeeAmount = arrayFeeAmount.length;
				String lastelementFeeAmount = arrayFeeAmount[lengthFeeAmount-1];
				String toReplaceFeeamount = "."+lastelementFeeAmount;
				PathToNode = ActionJsonfeeAmount.replace(toReplaceFeeamount, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementFeeAmount, CurrentWorkBasketActionOne);

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CCC_Decision", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "25.2";
				String ActionJsonAppealFeePercent = GetCase.envmap.get("AppealFeePercent").substring(2);
				String[]arrayFeePercent = ActionJsonAppealFeePercent.split("\\.");
				int lengthFeePercent = arrayFeePercent.length;
				String lastelementFeePercent = arrayFeePercent[lengthFeePercent-1];
				String toReplaceFeePercent = "."+lastelementFeePercent;
				PathToNode = ActionJsonAppealFeePercent.replace(toReplaceFeePercent, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementFeePercent, CurrentWorkBasketActionOne);

				break;
			}

			case "InternalVerificationWB":{
				//jsonprovider = jsonReqRes;

				logger.info(JsonPath.parse(jsonReq).read("$.content.Customers[0].VerificationList[0].VerificationType"));
				String Verificationtype = JsonPath.parse(jsonReq).read("$.content.Customers[0].VerificationList[0].VerificationType");



				if(Verificationtype.equalsIgnoreCase("VISIT OFFICE")){

			/*CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("AppRefNo", GetCase.scenarioID);

			//CurrentWorkBasketActionOne = "IN20180515000011";
			String ActionJsonNodePathAppid = GetCase.envmap.get("ApprefNo").substring(2);
			String[]arrayActionApp = ActionJsonNodePathAppid.split("\\.");
			int lengthActionApp = arrayActionApp.length;
			String lastelementActionapp = arrayActionApp[lengthActionApp-1];
			String toReplaceApp = "."+lastelementActionapp;
			PathToNode = ActionJsonNodePathAppid.replace(toReplaceApp, "");
			logger.info(PathToNode);
			ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionapp, CurrentWorkBasketActionOne);

			CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("EmployerName", GetCase.scenarioID);
			//CurrentWorkBasketActionOne = "Cognizant";
			String ActionJsonNodePathEmployeer = GetCase.envmap.get("EmployerName").substring(2);
			String[]arrayActionEmp = ActionJsonNodePathEmployeer.split("\\.");
			int lengthActionemp = arrayActionEmp.length;
			String lastelementActionEmp = arrayActionEmp[lengthActionemp-1];
			String toReplaceEmp = "."+lastelementActionEmp;
			PathToNode = ActionJsonNodePathEmployeer.replace(toReplaceEmp, "");
			logger.info(PathToNode);
			ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionEmp, CurrentWorkBasketActionOne);

			//CurrentWorkBasketActionOne = "TDMHRIDAY TDMDUPUIS";
			CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("FullName", GetCase.scenarioID);
			String ActionJsonNodePathFN = GetCase.envmap.get("FullName").substring(2);
			String[]arrayActionFN = ActionJsonNodePathFN.split("\\.");
			int lengthActionFN = arrayActionFN.length;
			String lastelementActionFN = arrayActionFN[lengthActionFN-1];
			String toReplaceFN = "."+lastelementActionFN;
			PathToNode = ActionJsonNodePathFN.replace(toReplaceFN, "");
			logger.info(PathToNode);
			ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionFN, CurrentWorkBasketActionOne);

			//CurrentWorkBasketActionOne = "south";
			CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Region", GetCase.scenarioID);
			String ActionJsonNodePathRegion = GetCase.envmap.get("Region").substring(2);
			String[]arrayActionRG = ActionJsonNodePathRegion.split("\\.");
			int lengthActionRG = arrayActionRG.length;
			String lastelementActionRG = arrayActionRG[lengthActionRG-1];
			String toReplaceRG = "."+lastelementActionRG;
			PathToNode = ActionJsonNodePathRegion.replace(toReplaceRG, "");
			logger.info(PathToNode);
			ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRG, CurrentWorkBasketActionOne);

			//CurrentWorkBasketActionOne = "R0005";
			CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Doctype", GetCase.scenarioID);
			String ActionJsonNodePathdoc = GetCase.envmap.get("DocumentType").substring(2);
			String[]arrayActionDoc = ActionJsonNodePathdoc.split("\\.");
			int lengthActionDoc = arrayActionDoc.length;
			String lastelementActionDoc = arrayActionDoc[lengthActionDoc-1];
			String toReplaceDoc = "."+lastelementActionDoc;
			PathToNode = ActionJsonNodePathdoc.replace(toReplaceDoc, "");
			logger.info(PathToNode);
			ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDoc, CurrentWorkBasketActionOne);*/

					setIncomeDocuments();

					CurrentWorkBasketActionOne = "9887766554";
					String ActionJsonNodePathCon = GetCase.envmap.get("ContactNumber").substring(2);
					String[]arrayActionCon = ActionJsonNodePathCon.split("\\.");
					int lengthActionCon = arrayActionCon.length;
					String lastelementActionCon = arrayActionCon[lengthActionCon-1];
					String toReplaceCon = "."+lastelementActionCon;
					PathToNode = ActionJsonNodePathCon.replace(toReplaceCon, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionCon, CurrentWorkBasketActionOne);

					CurrentWorkBasketActionOne = "MO1";
					String ActionJsonNodePathCot = GetCase.envmap.get("ContactType").substring(2);
					String[]arrayActionCot = ActionJsonNodePathCot.split("\\.");
					int lengthActionCot = arrayActionCot.length;
					String lastelementActionCot = arrayActionCot[lengthActionCot-1];
					String toReplaceCot = "."+lastelementActionCot;
					PathToNode = ActionJsonNodePathCot.replace(toReplaceCot, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionCot, CurrentWorkBasketActionOne);

					CurrentWorkBasketActionOne = "M";
					String ActionJsonNodePathCTC = GetCase.envmap.get("ContactTypeClassification").substring(2);
					String[]arrayActionCTC = ActionJsonNodePathCTC.split("\\.");
					int lengthActionCTC = arrayActionCTC.length;
					String lastelementActionCTC = arrayActionCTC[lengthActionCTC-1];
					String toReplaceCTC = "."+lastelementActionCTC;
					PathToNode = ActionJsonNodePathCTC.replace(toReplaceCTC, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionCTC, CurrentWorkBasketActionOne);

					CurrentWorkBasketActionOne = "91";
					String ActionJsonNodePathIsd = GetCase.envmap.get("ISDCode").substring(2);
					String[]arrayActionIsd = ActionJsonNodePathIsd.split("\\.");
					int lengthActionIsd = arrayActionIsd.length;
					String lastelementActionIsd = arrayActionIsd[lengthActionIsd-1];
					String toReplaceIsd = "."+lastelementActionIsd;
					PathToNode = ActionJsonNodePathIsd.replace(toReplaceIsd, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionIsd, CurrentWorkBasketActionOne);


				}else if(Verificationtype.equalsIgnoreCase("INCOME VERIFICATION")){
					//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("AppRefNo", GetCase.scenarioID);

					String ActionJsonNodePathPFN = GetCase.envmap.get("pyFullName").substring(2);
					String[]arrayActionPFN = ActionJsonNodePathPFN.split("\\.");
					int lengthActionPFN = arrayActionPFN.length;
					String lastelementActionPFN = arrayActionPFN[lengthActionPFN-1];
					String toReplacePFN = "."+lastelementActionPFN;
					PathToNode = ActionJsonNodePathPFN.replace(toReplacePFN, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionPFN, "Chittenedi, Venkat Sandeep");

					String ActionJsonNodePath3 = GetCase.envmap.get("pyWorkPartyUri").substring(2);
					String[]arrayAction3 = ActionJsonNodePath3.split("\\.");
					int lengthAction3 = arrayAction3.length;
					String lastelementAction3 = arrayAction3[lengthAction3-1];
					String toReplace3 = "."+lastelementAction3;
					PathToNode = ActionJsonNodePath3.replace(toReplace3, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction3, "1577701");

					setIncomeDocuments();

				/*
				CurrentWorkBasketActionOne = "IN20180515000011";
				String ActionJsonNodePathAppid = GetCase.envmap.get("ApprefNo").substring(2);
				String[]arrayActionApp = ActionJsonNodePathAppid.split("\\.");
				int lengthActionApp = arrayActionApp.length;
				String lastelementActionapp = arrayActionApp[lengthActionApp-1];
				String toReplaceApp = "."+lastelementActionapp;
				PathToNode = ActionJsonNodePathAppid.replace(toReplaceApp, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionapp, CurrentWorkBasketActionOne);

				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("EmployerName", GetCase.scenarioID);
				CurrentWorkBasketActionOne = "Cognizant";
				String ActionJsonNodePathEmployeer = GetCase.envmap.get("EmployerName").substring(2);
				String[]arrayActionEmp = ActionJsonNodePathEmployeer.split("\\.");
				int lengthActionemp = arrayActionEmp.length;
				String lastelementActionEmp = arrayActionEmp[lengthActionemp-1];
				String toReplaceEmp = "."+lastelementActionEmp;
				PathToNode = ActionJsonNodePathEmployeer.replace(toReplaceEmp, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionEmp, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = "TDMHRIDAY TDMDUPUIS";
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("FullName", GetCase.scenarioID);
				String ActionJsonNodePathFN = GetCase.envmap.get("FullName").substring(2);
				String[]arrayActionFN = ActionJsonNodePathFN.split("\\.");
				int lengthActionFN = arrayActionFN.length;
				String lastelementActionFN = arrayActionFN[lengthActionFN-1];
				String toReplaceFN = "."+lastelementActionFN;
				PathToNode = ActionJsonNodePathFN.replace(toReplaceFN, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionFN, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = "south";
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Region", GetCase.scenarioID);
				String ActionJsonNodePathRegion = GetCase.envmap.get("Region").substring(2);
				String[]arrayActionRG = ActionJsonNodePathRegion.split("\\.");
				int lengthActionRG = arrayActionRG.length;
				String lastelementActionRG = arrayActionRG[lengthActionRG-1];
				String toReplaceRG = "."+lastelementActionRG;
				PathToNode = ActionJsonNodePathRegion.replace(toReplaceRG, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionRG, CurrentWorkBasketActionOne);

				CurrentWorkBasketActionOne = "R0005";
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Doctype", GetCase.scenarioID);
				String ActionJsonNodePathdoc = GetCase.envmap.get("DocumentType").substring(2);
				String[]arrayActionDoc = ActionJsonNodePathdoc.split("\\.");
				int lengthActionDoc = arrayActionDoc.length;
				String lastelementActionDoc = arrayActionDoc[lengthActionDoc-1];
				String toReplaceDoc = "."+lastelementActionDoc;
				PathToNode = ActionJsonNodePathdoc.replace(toReplaceDoc, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionDoc, CurrentWorkBasketActionOne);*/

				}else if(Verificationtype.equalsIgnoreCase("2 WAY SMS VERIFICATION")){

					CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("BureauCustResponse", GetCase.scenarioID);
					String ActionJsonNodeCutRes = GetCase.envmap.get("bureauCustResponse").substring(2);
					String[]arrayActionCutRes = ActionJsonNodeCutRes.split("\\.");
					int lengthActionCutRes = arrayActionCutRes.length;
					String lastelementActionCutRes = arrayActionCutRes[lengthActionCutRes-1];
					String toReplaceCutRes = "."+lastelementActionCutRes;
					PathToNode = ActionJsonNodeCutRes.replace(toReplaceCutRes, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionCutRes, CurrentWorkBasketActionOne);

					CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("BureauVerStatus", GetCase.scenarioID);
					String ActionJsonNodeBVS = GetCase.envmap.get("bureauVerStatus").substring(2);
					String[]arrayActionBVS = ActionJsonNodeBVS.split("\\.");
					int lengthActionBVS = arrayActionBVS.length;
					String lastelementActionBVS = arrayActionBVS[lengthActionBVS-1];
					String toReplaceBVS = "."+lastelementActionBVS;
					PathToNode = ActionJsonNodeBVS.replace(toReplaceBVS, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionBVS, CurrentWorkBasketActionOne);

					CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("BureaverifyResponse", GetCase.scenarioID);
					String ActionJsonNodeBVR = GetCase.envmap.get("bureaverifyResponse").substring(2);
					String[]arrayActionBVR = ActionJsonNodeBVR.split("\\.");
					int lengthActionBVR = arrayActionBVR.length;
					String lastelementActionBVR = arrayActionBVR[lengthActionBVR-1];
					String toReplaceBVR = "."+lastelementActionBVR;
					PathToNode = ActionJsonNodeBVR.replace(toReplaceBVR, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionBVR, CurrentWorkBasketActionOne);


				}

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("VerificationStatus", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "POS";
				String ActionJsonNodePathVs = GetCase.envmap.get("VerfStatus").substring(2);
				String[]arrayActionVS = ActionJsonNodePathVs.split("\\.");
				int lengthActionVS = arrayActionVS.length;
				String lastelementActionVS = arrayActionVS[lengthActionVS-1];
				String toReplaceVS = "."+lastelementActionVS;
				PathToNode = ActionJsonNodePathVs.replace(toReplaceVS, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementActionVS, CurrentWorkBasketActionOne);

				break;
			}

			case "OffersWB":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("Decision", GetCase.scenarioID);

//				CurrentWorkBasketActionOne = "Appeal";
				String ActionJsonNodePath = GetCase.envmap.get("DisplayOffersWBDecision").substring(2);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

				if (CurrentWorkBasketActionOne.equalsIgnoreCase("Appeal")){

					String ActionJsonNode = GetCase.envmap.get("Comments").substring(2);
					String[]arrayAct = ActionJsonNode.split("\\.");
					int lengthAct = arrayAct.length;
					String lastelementAct = arrayAct[lengthAct-1];
					String toRepl = "."+lastelementAct;
					PathToNode = ActionJsonNode.replace(toRepl, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAct, CurrentWorkBasketActionOne);


					String appealAmount = DBUtils.readColumnWithRowIDNew("AppealAmount", GetCase.scenarioID);

//				CurrentWorkBasketActionOne = "Appeal";
					String ActionJson = GetCase.envmap.get("AppealAmount").substring(2);
					String[]arrayA = ActionJson.split("\\.");
					int lengthA = arrayA.length;
					String lastelementA = arrayA[lengthA-1];
					String toRep = "."+lastelementA;
					PathToNode = ActionJson.replace(toRep, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementA, appealAmount);

					String appealRate = DBUtils.readColumnWithRowIDNew("AppealEffectiveRate", GetCase.scenarioID);

					String ActionJson2 = GetCase.envmap.get("AppealEffectiveRate").substring(2);
					String[]arrayA2 = ActionJson2.split("\\.");
					int lengthA2 = arrayA2.length;
					String lastelementA2 = arrayA2[lengthA2-1];
					String toRep2 = "."+lastelementA2;
					PathToNode = ActionJson2.replace(toRep2, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementA2, appealRate);


					String AppealTenor = DBUtils.readColumnWithRowIDNew("AppealTenor", GetCase.scenarioID);

					String ActionJson3 = GetCase.envmap.get("AppealTenor").substring(2);
					String[]arrayA3 = ActionJson3.split("\\.");
					int lengthA3 = arrayA3.length;
					String lastelementA3 = arrayA3[lengthA3-1];
					String toRep3 = "."+lastelementA3;
					PathToNode = ActionJson3.replace(toRep3, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementA3, AppealTenor);



				}
				if (CurrentWorkBasketActionOne.equalsIgnoreCase("Resubmit")){

					CurrentWorkBasketActionReason = DBUtils.readColumnWithRowIDNew("Match", GetCase.scenarioID);
//					CurrentWorkBasketActionReason = "true";
					String ActionJsonNodePath1 = GetCase.envmap.get("DisplayOffersWBOfferResubmitDeclaration").substring(2);
					String[]arrayAction1 = ActionJsonNodePath1.split("\\.");
					int lengthAction1 = arrayAction1.length;
					String lastelementAction1 = arrayAction1[lengthAction1-1];
					String toReplace1 = "."+lastelementAction1;
					PathToNode = ActionJsonNodePath1.replace(toReplace1, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction1, CurrentWorkBasketActionReason);

					String ActionJsonNodePath2 = GetCase.envmap.get("isBureauEdit").substring(2);
					String[]arrayAction2 = ActionJsonNodePath2.split("\\.");
					int lengthAction2 = arrayAction2.length;
					String lastelementAction2 = arrayAction2[lengthAction2-1];
					String toReplace2 = "."+lastelementAction2;
					PathToNode = ActionJsonNodePath2.replace(toReplace2, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction2, CurrentWorkBasketActionReason);

					String ActionJsonNodePath4 = GetCase.envmap.get("isIncomeEdit").substring(2);
					String[]arrayAction4 = ActionJsonNodePath4.split("\\.");
					int lengthAction4 = arrayAction4.length;
					String lastelementAction4 = arrayAction4[lengthAction4-1];
					String toReplace4 = "."+lastelementAction4;
					PathToNode = ActionJsonNodePath4.replace(toReplace4, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction4, CurrentWorkBasketActionReason);

					/*String ActionJsonNodePath5 = GetCase.envmap.get("isPriceEscalation").substring(2);
					String[]arrayAction5 = ActionJsonNodePath5.split("\\.");
					int lengthAction5 = arrayAction5.length;
					String lastelementAction5 = arrayAction1[lengthAction5-1];
					String toReplace5 = "."+lastelementAction5;
					PathToNode = ActionJsonNodePath5.replace(toReplace5, "");
					logger.info(PathToNode);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction5, CurrentWorkBasketActionReason);*/

				}
				break;

			}

			case "RMSupervisorWB":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("OfferAction", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "ApproveAppeal";
				String ActionJsonNodePath = GetCase.envmap.get("RMSupervisorWBOfferAction").substring(2);
				logger.info(ActionJsonNodePath);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				logger.info(lengthAction);
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);


				if(CurrentWorkBasketActionOne == "ApproveAppeal"){

					CurrentWorkBasketActionReason = DBUtils.readColumnWithRowIDNew("AppealFlag", GetCase.scenarioID);
					//CurrentWorkBasketActionReason = "Y";
					String ReasonJsonNodePath = GetCase.envmap.get("RMSupervisorWBAppealFlag").substring(2);
					String[]arrayReason = ReasonJsonNodePath.split("\\.");
					int lengthReason = arrayReason.length;
					String lastelementReason = arrayReason[lengthReason-1];
					String toReplace2 = "."+lastelementReason;
					PathToNode = ReasonJsonNodePath.replace(toReplace2, "");
					logger.info(PathToNode);
					logger.info(lastelementReason);
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReason, CurrentWorkBasketActionReason);

				}
				break;

			}

			case "CreditInitiationWB":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CIAction", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = "Decline";
				if (CurrentWorkBasketActionOne!=null){

					String ActionJsonNodePath = GetCase.envmap.get("CIAction").substring(2);
					logger.info("texxxxxxxxxxxxxxxxxxt"+ActionJsonNodePath);
					String[]arrayAction = ActionJsonNodePath.split("\\.");
					int lengthAction = arrayAction.length;
					logger.info("texxxxxxxxxxxxxxxxxxt"+lengthAction);
					String lastelementAction = arrayAction[lengthAction-1];
					String toReplace = lastelementAction;
					PathToNode = ActionJsonNodePath.replace(toReplace, "");
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

					if (CurrentWorkBasketActionOne == "Refer"){

						CurrentWorkBasketActionReason = DBUtils.readColumnWithRowIDNew("ReferReason", GetCase.scenarioID);
						CurrentWorkBasketActionReason = "CI002";
						String ReasonJsonNodePath = GetCase.envmap.get("ReferReason").substring(2);
						String[]arrayReason = ReasonJsonNodePath.split("\\.");
						int lengthReason = arrayReason.length;
						String lastelementReason = arrayReason[lengthReason-1];
						String toReplace2 = lastelementReason;
						PathToNode = ReasonJsonNodePath.replace(toReplace2, "");
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReason, CurrentWorkBasketActionReason);

					}

				}
				else{

					CurrentWorkBasketActionTwo = DBUtils.readColumnWithRowIDNew("Decision", GetCase.scenarioID);
					//CurrentWorkBasketActionTwo = "Decline";
					if (CurrentWorkBasketActionTwo!=null){

						String ActionJsonNodePath1 = GetCase.envmap.get("Decision").substring(2);
						String[]arrayAction1 = ActionJsonNodePath1.split("\\.");
						int lengthAction1 = arrayAction1.length;
						String lastelementAction1 = arrayAction1[lengthAction1-1];
						String toReplace1 = lastelementAction1;
						PathToNode = ActionJsonNodePath1.replace(toReplace1, "");
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction1, CurrentWorkBasketActionTwo);

						if (CurrentWorkBasketActionTwo == "Decline"){

							CurrentWorkBasketActionReason = DBUtils.readColumnWithRowIDNew("Reasons", GetCase.scenarioID);
							//CurrentWorkBasketActionReason = "CPD001";
							logger.info("CurrentWorkBasketActionReason = CPD001");
							String ReasonJsonNodePath1 = GetCase.envmap.get("Reasons").substring(2);
							logger.info(ReasonJsonNodePath1);
							String[]arrayReason1 = ReasonJsonNodePath1.split("\\.");
							int lengthReason1 = arrayReason1.length;
							String lastelementReason1 = arrayReason1[lengthReason1-1];
							String toReplace2 = lastelementReason1;
							PathToNode = ReasonJsonNodePath1.replace(toReplace2, "");

							ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReason1, CurrentWorkBasketActionReason);
							logger.info("NO CALL");
						}

					}

				}
				break;
			}
			case "CIException":{

				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowIDNew("CIAction", GetCase.scenarioID);
				//CurrentWorkBasketActionOne = null;
				if (CurrentWorkBasketActionOne!=null){

					String ActionJsonNodePath = GetCase.envmap.get("CIAction").substring(2);
					logger.info("texxxxxxxxxxxxxxxxxxt"+ActionJsonNodePath);
					String[]arrayAction = ActionJsonNodePath.split("\\.");
					int lengthAction = arrayAction.length;
					logger.info("texxxxxxxxxxxxxxxxxxt"+lengthAction);
					String lastelementAction = arrayAction[lengthAction-1];
					String toReplace = lastelementAction;
					PathToNode = ActionJsonNodePath.replace(toReplace, "");
					ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);

					if (CurrentWorkBasketActionOne == "Refer"){

						CurrentWorkBasketActionReason = DBUtils.readColumnWithRowID("ReferReason", GetCase.scenarioID);
						//CurrentWorkBasketActionReason = "CI002";
						String ReasonJsonNodePath = GetCase.envmap.get("ReferReason").substring(2);
						String[]arrayReason = ReasonJsonNodePath.split("\\.");
						int lengthReason = arrayReason.length;
						String lastelementReason = arrayReason[lengthReason-1];
						String toReplace2 = lastelementReason;
						PathToNode = ReasonJsonNodePath.replace(toReplace2, "");
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReason, CurrentWorkBasketActionReason);

					}

				}
				else{

					CurrentWorkBasketActionTwo = DBUtils.readColumnWithRowIDNew("Decision", GetCase.scenarioID);
					//CurrentWorkBasketActionTwo = "Decline";
					if (CurrentWorkBasketActionTwo!=null){

						String ActionJsonNodePath1 = GetCase.envmap.get("Decision").substring(2);
						String[]arrayAction1 = ActionJsonNodePath1.split("\\.");
						int lengthAction1 = arrayAction1.length;
						String lastelementAction1 = arrayAction1[lengthAction1-1];
						String toReplace1 = lastelementAction1;
						PathToNode = ActionJsonNodePath1.replace(toReplace1, "");
						ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementAction1, CurrentWorkBasketActionTwo);

						if (CurrentWorkBasketActionTwo == "Decline"){

							CurrentWorkBasketActionReason = DBUtils.readColumnWithRowIDNew("Reasons", GetCase.scenarioID);
							//CurrentWorkBasketActionReason = "CPD001";
							logger.info("CurrentWorkBasketActionReason = CPD001");
							String ReasonJsonNodePath1 = GetCase.envmap.get("Reasons").substring(2);
							logger.info(ReasonJsonNodePath1);
							String[]arrayReason1 = ReasonJsonNodePath1.split("\\.");
							int lengthReason1 = arrayReason1.length;
							String lastelementReason1 = arrayReason1[lengthReason1-1];
							String toReplace2 = lastelementReason1;
							PathToNode = ReasonJsonNodePath1.replace(toReplace2, "");

							ACDSetValue.UpdateJSONTemplate(PathToNode, lastelementReason1, CurrentWorkBasketActionReason);
							logger.info("NO CALL");
						}

					}

				}
				break;

			}

		}


	}

	/***************************************************callGetCaseApiDup method Code Added By Atri Nil Bal, Dated: 2ndMar2018***************************************************/
	@SuppressWarnings("deprecation")
	@Given("^Call the GetCase api and validate the workbasket '(.*)'$")
	public static void callGetCaseApi(String currentWorkbasket) throws Throwable {

		RestAssured.baseURI = GetCase.envmap.get("URIGet");

		RestAssured.useRelaxedHTTPSValidation();

		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));


		//httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));
		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));

		//httpRequest.header("CurrentWorkBasket",GetCase.envmap.get(currentWorkbasket));
		httpRequest.header("CurrentWorkBasket",currentWorkbasket);
		logger.info(currentWorkbasket);

		response = httpRequest.request(Method.GET,"/GetCase");

		logger.info(response.headers());
		logger.info(response.getStatusCode());
		logger.info("Status Code ok : "+AuthenticateRTOB.validateStatusCode(response.getStatusCode()));



		/***************code to place the Get Case Response JSON Template in a .json file*******************/
		logger.info("Writing in file");
		FileWriter file = new FileWriter("./src/test/resources/jsontemplates/APITemplates/APITemplate.json");
		file.write(response.asString());
		file.close();
		/***************code to place the Get Case Response JSON Template in a .json file, END*******************/

		/***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION*******************/

		JsonReader JR2 = Json.createReader(new FileReader("./src/test/resources/jsontemplates/APITemplates/APITemplate.json"));
		JsonObject JO = JR2.readObject();

		Map<String, Boolean> configFinal = new HashMap<>();
		configFinal.put(JsonGenerator.PRETTY_PRINTING, true);

		try(PrintWriter pw2 = new PrintWriter("./src/test/resources/jsontemplates/APITemplates/GetCaseTemplate.json");
			JsonWriter jw2 = Json.createWriterFactory(configFinal).createWriter(pw2)){

			jw2.writeObject(JO);
		}
		/***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION, END*******************/

		/***************CODE SNIPPET TO read the GetCase JSON Template in a File***************/
		File filenew = new File("./src/test/resources/jsontemplates/APITemplates/GetCaseTemplate.json");
		String content = FileUtils.readFileToString(filenew);

		FileReader reader = new FileReader("./src/test/resources/jsontemplates/APITemplates/GetCaseTemplate.json");
		jsonReq = (org.json.simple.JSONObject) parser.parse(reader);

		/***************CODE SNIPPET to CHECK the GetCase JSON Template BEFORE Updation As Per Scenario*******************/
		System.out.println("******************************************************************");
		logger.info("START OF BEFORE");
		JSONObject GetResponse = new JSONObject(content);

		// JSONArray GetResArray = new JSONArray(content);
		jsonReqRes = GetResponse;
		ACDSetValue.JSONObjectReader(GetResponse);
		// ACDSetValue.JSONArrayReader(GetResArray);
		logger.info("END OF BEFORE");
		System.out.println("******************************************************************");
		/***************CODE SNIPPET to CHECK the GetCase JSON Template BEFORE Updation As Per Scenario, END*******************/
		/***************CODE SNIPPET of Method Call to set Current WorkBasket specific Parameters in JSON Template as per scenario***************/

		setACDJSONAttributes(currentWorkbasket);

		/***************CODE SNIPPET of Method Call to set Current WorkBasket specific Parameters in JSON Template as per scenario, END***************/


		/***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION*******************/
		FileWriter file24 = new FileWriter("./src/test/resources/jsontemplates/APITemplates/OutputTemplate.json");
		file24.write(GetResponse.toString());
		file24.close();

		JsonReader JRFinal = Json.createReader(new FileReader("./src/test/resources/jsontemplates/APITemplates/OutputTemplate.json"));
		JsonObject JOFinal = JRFinal.readObject();

		Map<String, Boolean> configFinalFinal = new HashMap<>();
		configFinalFinal.put(JsonGenerator.PRETTY_PRINTING, true);





		try(PrintWriter pwFinal = new PrintWriter("./src/test/resources/jsontemplates/APITemplates/APITemplate.json");
			JsonWriter jw2Final = Json.createWriterFactory(configFinal).createWriter(pwFinal)){

			jw2Final.writeObject(JOFinal);
		}
		/***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION, End*******************/

		/***************CODE SNIPPET to CHECK the GetCase JSON Template AFTER Updation As Per Scenario*******************/
		File fileFinal = new File("./src/test/resources/jsontemplates/APITemplates/OutputTemplate.json");
		String contentFinal = FileUtils.readFileToString(fileFinal);

		System.out.println("******************************************************************");
		logger.info("START OF AFTER");
		//JSONObject GetResponseFinal = new JSONObject(GetResponse.toString());
		JSONObject GetResponseFinal = new JSONObject(contentFinal);
		ACDSetValue.JSONObjectReader(GetResponseFinal);
		logger.info("END OF AFTER");
		System.out.println("******************************************************************");
		/***************CODE SNIPPET to CHECK the GetCase JSON Template AFTER Updation As Per Scenario, END*******************/


		/***************CODE TO EXTRACT THE "content" PORTION OF THE MODIFIED JSON TEMPLATE***************/
	   /* File filePromote = new File("C:/Users/1580707/StanChartBank/framework_dumps/API framework dump/src/test/resources/jsontemplates/CI/OutPutCI_Template.json");
	    String contentPromote = FileUtils.readFileToString(filePromote);*/
		JSONObject GetResponsePUT = GetResponseFinal.getJSONObject("content");
		String GetResponsePUTModified = "{\"content\""+":"+GetResponsePUT.toString()+"}";
		GetResponsePUTModified = GetResponsePUTModified.replace("\n", "").replace("\r", "");
		logger.info(GetResponsePUTModified);


	    /*JSONObject GetResponceforPyWork = GetResponseFinal.getJSONObject("pyWorkParty");
	    String GetResponsePymodified = "{\"pyWorkParty\""+":"+GetResponceforPyWork.toString()+"}";
	    GetResponsePymodified = GetResponsePymodified.replace("\n", "");
	    logger.info(GetResponsePymodified);*/

		File filePromoteModified = new File("./src/test/resources/jsontemplates/APITemplates/OutputTemplate.json");
		FileWriter fileWriter = new FileWriter(filePromoteModified);
		fileWriter.write(GetResponsePUTModified);
		fileWriter.flush();
		fileWriter.close();
		/***************CODE TO EXTRACT THE "content" PORTION OF THE MODIFIED JSON TEMPLATE, End***************/
		JSONObject PutRequest = new JSONObject(GetResponsePUTModified);
		jsonReqRes = PutRequest;




		/*FileWriter filePUT = new FileWriter("C:/Users/1580707/StanChartBank/framework_dumps/API framework dump/src/test/resources/jsontemplates/CI/HolderCI_Template.json");
		filePUT.write(GetResponsePUT.toString());
		filePUT.close();*/

		JsonReader JRFinalPUT = Json.createReader(new FileReader("./src/test/resources/jsontemplates/APITemplates/OutputTemplate.json"));
		JsonObject JOFinalPUT = JRFinalPUT.readObject();

		Map<String, Boolean> configFinalPUT = new HashMap<>();
		configFinalPUT.put(JsonGenerator.PRETTY_PRINTING, true);

		try(PrintWriter pwFinal = new PrintWriter("./src/test/resources/jsontemplates/APITemplates/PutcaseTemplates.json");
			JsonWriter jw2Final = Json.createWriterFactory(configFinal).createWriter(pwFinal)){

			jw2Final.writeObject(JOFinalPUT);
		}

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void setReferralDocuments(String DocName, int i) throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("--------------------------- Contacts Starts-------------------------------------------------------");
		// ArrayList List =new ArrayList();


		HashMap contactsMap =new HashMap();
		InsertInMap(contactsMap,"DocumentCategory",addTheDocumentCatagoryinTemplate(DocName),false);
		InsertInMap(contactsMap,"DocumentName",selectTheDocumentType(DocName),false);
		InsertInMap(contactsMap,"IsDocumentAvailable","Y",false);

		InsertInMap(contactsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

		System.out.println("contactsMap---->"+contactsMap);
		//List.add(contactsMap);


		JsonPath.parse(jsonReq).set("$.content.Documents["+i+"]",contactsMap);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void setProdDocumentList(String DocName, int i) throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("--------------------------- Contacts Starts-------------------------------------------------------");
		// ArrayList List =new ArrayList();


		HashMap contactsMap =new HashMap();
		InsertInMap(contactsMap,"DocumentCategory",addTheDocumentCatagoryinTemplate(DocName),false);
		InsertInMap(contactsMap,"DocumentName",selectTheDocumentType(DocName),false);
		InsertInMap(contactsMap,"IsDocumentAvailable","Y",false);

		InsertInMap(contactsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

		System.out.println("contactsMap---->"+contactsMap);
		//List.add(contactsMap);


		JsonPath.parse(jsonReq).set("$.content.Customers[0].ProdDocumentList["+i+"]",contactsMap);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void setDocuments(String DocName, int i) throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("--------------------------- Contacts Starts-------------------------------------------------------");
		// ArrayList List =new ArrayList();
		String FullName = JsonPath.parse(jsonReq).read("$.content.Customers[0].FullName");

		HashMap contactsMap =new HashMap();
		InsertInMap(contactsMap,"DocumentCategDesc",setDocumentCategoryName(DocName),false);
		InsertInMap(contactsMap,"DocumentCategory",addTheDocumentCatagoryinTemplate(DocName),false);
		InsertInMap(contactsMap,"DocumentId","{025D5117-FFA1-40B5-BE57-95C5011D8CC0}",false);
		InsertInMap(contactsMap,"DocumentType",selectTheDocumentType(DocName),false);
		InsertInMap(contactsMap,"DocumentName",setTheDocumentName(DocName),false);
		InsertInMap(contactsMap,"ReClassify","false",false);
		InsertInMap(contactsMap,"Relationship",FullName,false);
		InsertInMap(contactsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Master-Document",false);

		System.out.println("contactsMap---->"+contactsMap);
		//List.add(contactsMap);


		JsonPath.parse(jsonReq).set("$.content.Documents["+i+"]",contactsMap);

	}



	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void setIncomeDocuments() throws ClassNotFoundException, SQLException, IOException
	{
		System.out.println("--------------------------- Contacts Starts-------------------------------------------------------");
		// ArrayList List =new ArrayList();
		String FullName = JsonPath.parse(jsonReq).read("$.content.Customers[0].FullName");

		HashMap contactsMap =new HashMap();
		InsertInMap(contactsMap,"ApplicationRefNo",DBUtils.readColumnWithRowIDNew("AppRefNo", GetCase.scenarioID),true);
		InsertInMap(contactsMap,"DocumentType","R0005",false);
		InsertInMap(contactsMap,"EmployerName",DBUtils.readColumnWithRowIDNew("EmployerName", GetCase.scenarioID),false);
		InsertInMap(contactsMap,"FullName",FullName,false);
		InsertInMap(contactsMap,"pxObjClass","SCB-FW-AppWorkFlowFW-Data-Verification",false);
		InsertInMap(contactsMap,"Region",DBUtils.readColumnWithRowIDNew("Region", GetCase.scenarioID),false);

		System.out.println("contactsMap---->"+contactsMap);
		//List.add(contactsMap);


		JsonPath.parse(jsonReq).set("$.content.Customers[0].VerificationList[0].VerificationCaseData.VerifiedData",contactsMap);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void InsertInMap(HashMap Map,String Key,String Values,boolean flag)
	{
		if(flag==true)
		{
			String DbValue = DBUtils.readColumnWithRowIDNew(Values, GetCase.scenarioID);
			if(DbValue==null){DbValue="";}
			System.out.println(Values+"="+DbValue);
			Map.put(Key,DbValue);
		}
		else if(flag==false)
		{
			System.out.println(Key+"="+Values);
			Map.put(Key, Values);
		}

	}




	public static String addTheDocumentCatagoryinTemplate(String DocName){

		String DocCatCode="";

		if(DocName.contains("PAYSLIP")){DocCatCode="R0005";}
		else if(DocName.contains("PROOF OF PROPRIETORSHIP")){DocCatCode="R0005";}
		else if(DocName.contains("DUMMY DOCUMENT")){DocCatCode="R0005";}
		else if(DocName.contains("PARTNERSHIP DEED")){DocCatCode="R0005";}
		else if(DocName.contains("SERVICE TAX REGISTRATION CERTIFICATE ")){DocCatCode="R0005";}
		else if(DocName.contains("SHOP AND ESTABLISHMENT CERTIFICATE")){DocCatCode="R0005";}
		else if(DocName.contains("TRADE LICENSE")){DocCatCode="R0005";}
		else if(DocName.contains("SALES TAX REGISTRATION CERTIFICATE")){DocCatCode="R0005";}
		else if(DocName.contains("FORM 16")){DocCatCode="R0005";}
		else if(DocName.contains("CA REPORT ON INCOME DOCUMENT")){DocCatCode="R0005";}
		else if(DocName.contains("INCREMENT LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("DOCUMENT FRAUD VERIFICATION REPORT")){DocCatCode="R0005";}
		else if(DocName.contains("1 WAY SMS VERIFICATION REPORT")){DocCatCode="R0005";}
		else if(DocName.contains("2 WAY SMS VERIFICATION REPORT")){DocCatCode="R0005";}
		else if(DocName.contains("PERSONAL DISCUSSION VERIFICATION REPORT")){DocCatCode="R0005";}
		else if(DocName.contains("OFFICE VERIFICATION REPORT")){DocCatCode="R0005";}
		else if(DocName.contains("EMAIL APPROVAL - LEVEL 1")){DocCatCode="R0005";}
		else if(DocName.contains("HEALTH INSURANCE")){DocCatCode="R0005";}
		else if(DocName.contains("INCOME ASSESSMENT")){DocCatCode="R0005";}
		else if(DocName.contains("INT/DIVND LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("LABOUR INSURANCE")){DocCatCode="R0005";}
		else if(DocName.contains("LIFE INSURANCE")){DocCatCode="R0005";}
		else if(DocName.contains("OTHER BANK''S STATEMENT")){DocCatCode="R0005";}
		else if(DocName.contains("ANNUAL BONUS LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("AUTO INSURANCE")){DocCatCode="R0005";}
		else if(DocName.contains("BANK LH AUM")){DocCatCode="R0005";}
		else if(DocName.contains("BANK STATEMENT  ( SALARIED /SELF EMPLOYED)")){DocCatCode="R0005";}
		else if(DocName.contains("CREDIT CARD /DEBIT CARD STATEMENT")){DocCatCode="R0005";}
		else if(DocName.contains("SHAREHOLDING % DOC")){DocCatCode="R0005";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatCode="R0005";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("HR LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("OFFER LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocCatCode="R0005";}
		else if(DocName.contains("RETIREMENT PROOF")){DocCatCode="R0005";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocCatCode="R0005";}
		else if(DocName.contains("UTILITY BILL")){DocCatCode="R0005";}
		else if(DocName.contains("ITR DOCUMENT")){DocCatCode="R0005";}
		else if(DocName.contains("PROFIT & LOSS STATEMENT")){DocCatCode="R0005";}
		else if(DocName.contains("BALANCE SHEET")){DocCatCode="R0005";}
		else if(DocName.contains("PROFESSIONAL DEGREE CERTIFICATE")){DocCatCode="R0005";}
		else if(DocName.contains("MCA SITE PRINTOUT")){DocCatCode="R0005";}
		else if(DocName.contains("LOAN REPAYMENT TRACK")){DocCatCode="R0005";}
		else if(DocName.contains("LOAN REPAYMENT SCHEDULE")){DocCatCode="R0005";}
		else if(DocName.contains("LOAN CLOSURE PROOF")){DocCatCode="R0005";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocCatCode="R0005";}
		else if(DocName.contains("PROOF OF BUSINESS CONTINUITY FOR 3YEARS")){DocCatCode="R0005";}
		else if(DocName.contains("PROPERTY INSURANCE")){DocCatCode="R0005";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocCatCode="R0001";}
		else if(DocName.contains("PASSPORT")){DocCatCode="R0001";}
		else if(DocName.contains("PEP")){DocCatCode="R0001";}
		else if(DocName.contains("AADHAAR")){DocCatCode="R0001";}
		else if(DocName.contains("DRIVING LIC NO")){DocCatCode="R0001";}
		else if(DocName.contains("EMIRATES ID")){DocCatCode="R0001";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocCatCode="R0001";}
		else if(DocName.contains("ID CARD ISSUED BY ELECTORAL OFFICE")){DocCatCode="R0001";}
		else if(DocName.contains("IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE")){DocCatCode="R0001";}
		else if(DocName.contains("MARK SHEET")){DocCatCode="R0001";}
		else if(DocName.contains("NADRA")){DocCatCode="R0001";}
		else if(DocName.contains("NREGA JOB CARD")){DocCatCode="R0001";}
		else if(DocName.contains("PAN NO")){DocCatCode="R0001";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocCatCode="R0001";}
		else if(DocName.contains("BLACKLIST CHECK")){DocCatCode="R0001";}
		else if(DocName.contains("SAR")){DocCatCode="R0001";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocCatCode="R0001";}
		else if(DocName.contains("SUPPLEMENTARY - ID")){DocCatCode="R0001";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocCatCode="R0001";}
		else if(DocName.contains("VOTERS ID ")){DocCatCode="R0001";}
		else if(DocName.contains("SECONDARY - ID")){DocCatCode="R0001";}
		else if(DocName.contains("CUSTOMER PHOTO")){DocCatCode="R0001";}
		else if(DocName.contains("EMPLOYER /HR CERTIFICATE OF ADDRESS")){DocCatCode="R0007";}
		else if(DocName.contains("HR LETTER")){DocCatCode="R0007";}
		else if(DocName.contains("BUSINESS LETTERHEAD")){DocCatCode="R0007";}
		else if(DocName.contains("CASH COVERED LETTER ")){DocCatCode="R0007";}
		else if(DocName.contains("SURROGATE SPECIFIC PRODUCT ST/LETTER")){DocCatCode="R0007";}
		else if(DocName.contains("CLIENT AUTHORIZATION")){DocCatCode="R0007";}
		else if(DocName.contains("SET-OFF LETTER ")){DocCatCode="R0007";}
		else if(DocName.contains("SOW")){DocCatCode="R0007";}
		else if(DocName.contains("CERTIFICATE")){DocCatCode="R0007";}
		else if(DocName.contains("FOREIGN TIN")){DocCatCode="R0002";}
		else if(DocName.contains("FORM 60")){DocCatCode="R0002";}
		else if(DocName.contains("GST/VAT DOCUMENT")){DocCatCode="R0002";}
		else if(DocName.contains("PAN NO")){DocCatCode="R0002";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatCode="R0002";}
		else if(DocName.contains("CRS DOCUMENT")){DocCatCode="R0002";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocCatCode="R0002";}
		else if(DocName.contains("TAX IDENTIFICATION NUMBER")){DocCatCode="R0002";}
		else if(DocName.contains("CANADIAN TAX IDENTIFICATION")){DocCatCode="R0002";}
		else if(DocName.contains("PASSPORT")){DocCatCode="R0004";}
		else if(DocName.contains("VISA")){DocCatCode="R0004";}
		else if(DocName.contains("PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS")){DocCatCode="R0004";}
		else if(DocName.contains("PIO CARD")){DocCatCode="R0004";}
		else if(DocName.contains("POST OFFICE SAVINGS BANK ACCOUNT STATEMENT ")){DocCatCode="R0004";}
		else if(DocName.contains("PROPERTY TAX RECEIPT")){DocCatCode="R0004";}
		else if(DocName.contains("PAN VERIFICATION COPY ")){DocCatCode="R0004";}
		else if(DocName.contains("AADHAAR")){DocCatCode="R0004";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatCode="R0004";}
		else if(DocName.contains("PAN NO")){DocCatCode="R0004";}
		else if(DocName.contains("DRIVING LIC NO")){DocCatCode="R0004";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocCatCode="R0004";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocCatCode="R0004";}
		else if(DocName.contains("MARK SHEET")){DocCatCode="R0004";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocCatCode="R0004";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocCatCode="R0004";}
		else if(DocName.contains("ELECTRICITY BILL")){DocCatCode="R0004";}
		else if(DocName.contains("EMBASSY / UNO LETTERS")){DocCatCode="R0004";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocCatCode="R0004";}
		else if(DocName.contains("GAS BILL")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD (OTHER NATIONALITY)")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS")){DocCatCode="R0004";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS")){DocCatCode="R0004";}
		else if(DocName.contains("INTERNET BILL")){DocCatCode="R0004";}
		else if(DocName.contains("LETTER ISSUED BY A GAZETTED OFFICER")){DocCatCode="R0004";}
		else if(DocName.contains("LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER")){DocCatCode="R0004";}
		else if(DocName.contains("MAINTENANCE BILL")){DocCatCode="R0004";}
		else if(DocName.contains("MOBILE BILL")){DocCatCode="R0004";}
		else if(DocName.contains("MUNICIPAL TAX RECEIPT")){DocCatCode="R0004";}
		else if(DocName.contains("NATIONAL IDENTITY CARD")){DocCatCode="R0004";}
		else if(DocName.contains("NREGA JOB CARD")){DocCatCode="R0004";}
		else if(DocName.contains("OCI CARD")){DocCatCode="R0004";}
		else if(DocName.contains("ACKNOWLEDGMENT OF RECEIPT OF LETTER,")){DocCatCode="R0004";}
		else if(DocName.contains("ADDRESS CONFIRMATION THROUGH CIBIL DATA")){DocCatCode="R0004";}
		else if(DocName.contains("ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE")){DocCatCode="R0004";}
		else if(DocName.contains("CENTRAL POPULATION REGISTER (SMART CARD) ")){DocCatCode="R0004";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocCatCode="R0004";}
		else if(DocName.contains("RESIDENCE PROOF")){DocCatCode="R0004";}
		else if(DocName.contains("RESIDENCE VERIFICATION REPORT")){DocCatCode="R0004";}
		else if(DocName.contains("RESIDENT PERMIT")){DocCatCode="R0004";}
		else if(DocName.contains("RESIDENT VERIFICATION REPORT")){DocCatCode="R0004";}
		else if(DocName.contains("SUPPLEMENTARY - RESIDENCE PROOF")){DocCatCode="R0004";}
		else if(DocName.contains("TELEPHONE BILL")){DocCatCode="R0004";}
		else if(DocName.contains("VOTERS ID ")){DocCatCode="R0004";}
		else if(DocName.contains("WATER BILL")){DocCatCode="R0004";}
		else if(DocName.contains("LETTER ISSUED BY NATIONAL POPULATION REGISTER")){DocCatCode="R0004";}
		else if(DocName.contains("NADRA")){DocCatCode="R0004";}
		else if(DocName.contains("TAX DEMAND LETTER OR STATEMENT")){DocCatCode="R0004";}
		else if(DocName.contains("PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)")){DocCatCode="R0004";}
		else if(DocName.contains("ACKNOWLEDGED NOTICE OF INTIMATION ? ORIGINAL")){DocCatCode="R0008";}
		else if(DocName.contains("ADDITIONAL COST LETTER")){DocCatCode="R0008";}
		else if(DocName.contains("AFFIDAVIT CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("AFFIDAVIT FROM APPLICANT")){DocCatCode="R0008";}
		else if(DocName.contains("AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT")){DocCatCode="R0008";}
		else if(DocName.contains("AFTER COMPLETION ARCHITECTS CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("AGREEMENT LODGED FOR REGN")){DocCatCode="R0008";}
		else if(DocName.contains("ALLOTMENT LETTER")){DocCatCode="R0008";}
		else if(DocName.contains("AMENITIES AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("ANNEXURE Z")){DocCatCode="R0008";}
		else if(DocName.contains("APPLICATION FOR NAME TRANSFER")){DocCatCode="R0008";}
		else if(DocName.contains("APPROVED LAYOUT PLAN")){DocCatCode="R0008";}
		else if(DocName.contains("APPROVED SANCTION PLANS")){DocCatCode="R0008";}
		else if(DocName.contains("APPROVED TCP LAYOUT")){DocCatCode="R0008";}
		else if(DocName.contains("ARCHITECTS ESTIMATE")){DocCatCode="R0008";}
		else if(DocName.contains("AUTHORISATION LETTER FROM BORROWER ADDRESSED T")){DocCatCode="R0008";}
		else if(DocName.contains("AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA")){DocCatCode="R0008";}
		else if(DocName.contains("BACK DEED")){DocCatCode="R0008";}
		else if(DocName.contains("BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR")){DocCatCode="R0008";}
		else if(DocName.contains("BOARD RESOLUTION")){DocCatCode="R0008";}
		else if(DocName.contains("BUILDER DECLARATION")){DocCatCode="R0008";}
		else if(DocName.contains("BYE LAWS OF SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("CA CERTIFICATE FOR DISBURSAL")){DocCatCode="R0008";}
		else if(DocName.contains("CERTI (BY TEHSIL OFFICE ) OF INTEKHAB KHATUNI")){DocCatCode="R0008";}
		else if(DocName.contains("CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL")){DocCatCode="R0008";}
		else if(DocName.contains("CHAIN DOCUMENTS OF THE PROPERTY.")){DocCatCode="R0008";}
		else if(DocName.contains("CHAIN OF TITLE DOCUMENTS")){DocCatCode="R0008";}
		else if(DocName.contains("CHALLANS -  RECEIPTS OF PAYMENTS MADE")){DocCatCode="R0008";}
		else if(DocName.contains("COMMENCEMENT CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("CONFIRMATION LETTER FROM PURCHASER")){DocCatCode="R0008";}
		else if(DocName.contains("CONSTRUCTION AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("CONSTRUCTION PERMISSION")){DocCatCode="R0008";}
		else if(DocName.contains("CONSTRUCTION SCHEDULE")){DocCatCode="R0008";}
		else if(DocName.contains("CONVERSION CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("CONVEYANCE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("CROSS COLLATERAL")){DocCatCode="R0008";}
		else if(DocName.contains("CROSS DEFAULT AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("DEATH CERTIFICATES")){DocCatCode="R0008";}
		else if(DocName.contains("DECLARATION FROM PURCHASER")){DocCatCode="R0008";}
		else if(DocName.contains("DEED OF APARTMENT")){DocCatCode="R0008";}
		else if(DocName.contains("DEED OF ASSIGNMENT")){DocCatCode="R0008";}
		else if(DocName.contains("DEMAND LETTER FOR CURR DISB")){DocCatCode="R0008";}
		else if(DocName.contains("DEMAND LETTER FROM DDA")){DocCatCode="R0008";}
		else if(DocName.contains("DEVELOPMENT AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("DISBURSAL SCHEDULE")){DocCatCode="R0008";}
		else if(DocName.contains("DIVERSION RENT RECEIPT")){DocCatCode="R0008";}
		else if(DocName.contains("DOC ENSURING OWNERSHIP")){DocCatCode="R0008";}
		else if(DocName.contains("DOCUMENTS OF THE BUILDER")){DocCatCode="R0008";}
		else if(DocName.contains("DRCS APPROVAL")){DocCatCode="R0008";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocCatCode="R0008";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY BUYER")){DocCatCode="R0008";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("SALE AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("SALE DEED EXECUTED BY BUYER/BORROWER")){DocCatCode="R0008";}
		else if(DocName.contains("SALE DEED EXECUTED BY SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("SANCTION PLANS")){DocCatCode="R0008";}
		else if(DocName.contains("SEARCH REPORT")){DocCatCode="R0008";}
		else if(DocName.contains("SHARE CERTIFICATE BUYER")){DocCatCode="R0008";}
		else if(DocName.contains("SHARE CERTIFICATE SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("SUB-LEASE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("SURRENDER DEED FROM SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatCode="R0008";}
		else if(DocName.contains("TECHNICAL CUM LEGAL UNDERTAKING")){DocCatCode="R0008";}
		else if(DocName.contains("TITLE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("TRANSFER FORM FOR SHARE CERT")){DocCatCode="R0008";}
		else if(DocName.contains("TRANSFER LETTER FAV SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("TRANSFER LETTER FROM PCNTDA")){DocCatCode="R0008";}
		else if(DocName.contains("TRANSFER MEMORANDUM IN FAVOR OF PURCHASER")){DocCatCode="R0008";}
		else if(DocName.contains("WILL SIGNED BY THE SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("DDA MORTGAGE -ACK")){DocCatCode="R0008";}
		else if(DocName.contains("LIST OF DOCUMENTS HELD WITH HFC ")){DocCatCode="R0008";}
		else if(DocName.contains("MEMORANDUM OF ENTRY")){DocCatCode="R0008";}
		else if(DocName.contains("NOC FROM LAND ACQUISITION OFF ( KHASRA PLOT)")){DocCatCode="R0008";}
		else if(DocName.contains("RESOLUTION FOR A MORTGAGE PROPERTY")){DocCatCode="R0008";}
		else if(DocName.contains("STAMPED MOE")){DocCatCode="R0008";}
		else if(DocName.contains("TRIPATRIATE AGR")){DocCatCode="R0008";}
		else if(DocName.contains("UNDERTAKING FROM SELLER TO HANDOVER DOCS")){DocCatCode="R0008";}
		else if(DocName.contains("VALUATION REPORT")){DocCatCode="R0008";}
		else if(DocName.contains("7/12EXTRACT")){DocCatCode="R0008";}
		else if(DocName.contains("ENCUMBRANCE CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("FINANCIAL COVENANTS")){DocCatCode="R0008";}
		else if(DocName.contains("FLAT BUYERS AGR")){DocCatCode="R0008";}
		else if(DocName.contains("EARLIER DOCS OF THE BUILDER")){DocCatCode="R0008";}
		else if(DocName.contains("EARLIER DOCS OF THE SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("STAMP DUTY RECEIPT")){DocCatCode="R0008";}
		else if(DocName.contains("FORM 8 & 13")){DocCatCode="R0008";}
		else if(DocName.contains("FORM A + B + REGULARISED PLAN")){DocCatCode="R0008";}
		else if(DocName.contains("GIFT DEED")){DocCatCode="R0008";}
		else if(DocName.contains("GPA BY THE SELLER IN FAVOR OF THE BUYER")){DocCatCode="R0008";}
		else if(DocName.contains("GPA SPA AND WILL")){DocCatCode="R0008";}
		else if(DocName.contains("GPOA")){DocCatCode="R0008";}
		else if(DocName.contains("HANDING OVER POSSESSION LETTER TO THE BORROWER")){DocCatCode="R0008";}
		else if(DocName.contains("HIRE PURCHASE AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("INDEMNITY")){DocCatCode="R0008";}
		else if(DocName.contains("INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER")){DocCatCode="R0008";}
		else if(DocName.contains("INDEMNITY SIGNED BY SELLER")){DocCatCode="R0008";}
		else if(DocName.contains("INDENTURE OF SALE")){DocCatCode="R0008";}
		else if(DocName.contains("INDEX 2")){DocCatCode="R0008";}
		else if(DocName.contains("INSTRUMENT OF TRANSFER OF LAND")){DocCatCode="R0008";}
		else if(DocName.contains("INTIMATION TO JDA OF MORTGAGE DULY ACK")){DocCatCode="R0008";}
		else if(DocName.contains("INTIMATION TO RIICO OF MORTGAGE")){DocCatCode="R0008";}
		else if(DocName.contains("KHATAUNI FOR THE FASLI YEAR")){DocCatCode="R0008";}
		else if(DocName.contains("KHATHA DOCUMENT")){DocCatCode="R0008";}
		else if(DocName.contains("LAND OWNERS DEED")){DocCatCode="R0008";}
		else if(DocName.contains("LATEST OUTSTANDING LETTER FROM FINANCIER")){DocCatCode="R0008";}
		else if(DocName.contains("LEASE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("LEGAL DOCUMENT OF EXPIRED OWNER")){DocCatCode="R0008";}
		else if(DocName.contains("LEGAL OPINION")){DocCatCode="R0008";}
		else if(DocName.contains("LEGAL REPORT")){DocCatCode="R0008";}
		else if(DocName.contains("LETTER FROM BANK TO THE DEVELOPER / BUILDER")){DocCatCode="R0008";}
		else if(DocName.contains("LETTER FROM BORROWER TO THE DEVELOPER / BLDG")){DocCatCode="R0008";}
		else if(DocName.contains("LETTER FROM SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("LETTER OF OFFER")){DocCatCode="R0008";}
		else if(DocName.contains("LETTER OF UNDERTAKING")){DocCatCode="R0008";}
		else if(DocName.contains("LIEN MARKING LETTER")){DocCatCode="R0008";}
		else if(DocName.contains("LIEN NOTED CERTIFICATE FROM SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY")){DocCatCode="R0008";}
		else if(DocName.contains("LOAN CLOSURE LETTER")){DocCatCode="R0008";}
		else if(DocName.contains("LOCATION CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION")){DocCatCode="R0008";}
		else if(DocName.contains("MARGIN MONEY RECEIPTS")){DocCatCode="R0008";}
		else if(DocName.contains("MEMORANDUM OF DEPOSIT OF TITLE DEED ? ORIGINAL")){DocCatCode="R0008";}
		else if(DocName.contains("MEMORANDUM OF UNDERTAKING")){DocCatCode="R0008";}
		else if(DocName.contains("MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT")){DocCatCode="R0008";}
		else if(DocName.contains("MORTGAGE PERMISSION FROM RHB")){DocCatCode="R0008";}
		else if(DocName.contains("MP PRAKOSHTHA ADHINIYAM")){DocCatCode="R0008";}
		else if(DocName.contains("NA ORDER")){DocCatCode="R0008";}
		else if(DocName.contains("NAME TRANSFER FAV BORROWER")){DocCatCode="R0008";}
		else if(DocName.contains("NEW ENGINEERING CONTRACT ")){DocCatCode="R0008";}
		else if(DocName.contains("NO DUES CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("NOC FROM BDA")){DocCatCode="R0008";}
		else if(DocName.contains("NOC FROM BUILDER / SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("NOC TO MORTGAGE")){DocCatCode="R0008";}
		else if(DocName.contains("NOC TO TRANSFER")){DocCatCode="R0008";}
		else if(DocName.contains("OCCUPATION CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("ORIGINAL COMP CERTIFICATE ")){DocCatCode="R0008";}
		else if(DocName.contains("ORIGINAL INSURANCE CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("ORIGINAL NOMINATION AGREEMENT")){DocCatCode="R0008";}
		else if(DocName.contains("PARTITION DEED")){DocCatCode="R0008";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocCatCode="R0008";}
		else if(DocName.contains("PATTA")){DocCatCode="R0008";}
		else if(DocName.contains("PAYMENT RECEIPTS FOR LAND")){DocCatCode="R0008";}
		else if(DocName.contains("PAYMENT SCHEDULE")){DocCatCode="R0008";}
		else if(DocName.contains("PERMISSION FOR ADMITTING BORROWER AS MEMBER")){DocCatCode="R0008";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO")){DocCatCode="R0008";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY")){DocCatCode="R0008";}
		else if(DocName.contains("PLANNING PERMIT AND CONSTRUCTION PERMIT")){DocCatCode="R0008";}
		else if(DocName.contains("PLOTS ALLOTTED AT CONCESSIONAL RATES")){DocCatCode="R0008";}
		else if(DocName.contains("POA")){DocCatCode="R0008";}
		else if(DocName.contains("POA DOCS FAV SELLER / BUILDER OR DEVELOPER")){DocCatCode="R0008";}
		else if(DocName.contains("PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA")){DocCatCode="R0008";}
		else if(DocName.contains("POSSESSION CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("POSSESSION LETTER FROM RHB")){DocCatCode="R0008";}
		else if(DocName.contains("PREVIOUS AGREEMENT LODGED FOR REGISTRATION")){DocCatCode="R0008";}
		else if(DocName.contains("PREVIOUS PARTY SHARE CERTIFICATE")){DocCatCode="R0008";}
		else if(DocName.contains("PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN")){DocCatCode="R0008";}
		else if(DocName.contains("PROOF OD AGRICULTURAL LAND")){DocCatCode="R0008";}
		else if(DocName.contains("PROOF OF BASIS OF OWNERSHIP")){DocCatCode="R0008";}
		else if(DocName.contains("PROOF OF CUSTOMER EQUITY")){DocCatCode="R0008";}
		else if(DocName.contains("PROOF OF DISCHARGE OF MORTGAGE")){DocCatCode="R0008";}
		else if(DocName.contains("PROOF OF PROPERTY UNDER JURISDICTION")){DocCatCode="R0008";}
		else if(DocName.contains("PROPERTY CARD")){DocCatCode="R0008";}
		else if(DocName.contains("RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC")){DocCatCode="R0008";}
		else if(DocName.contains("RECTIFICATION DEED")){DocCatCode="R0008";}
		else if(DocName.contains("REGISTERED AGREEMENT TO SELL")){DocCatCode="R0008";}
		else if(DocName.contains("REGISTERED MORTGAGE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("REGISTERED SALE DEED")){DocCatCode="R0008";}
		else if(DocName.contains("REGISTERED TRANSFER DEED")){DocCatCode="R0008";}
		else if(DocName.contains("REGISTRATION RECEIPT")){DocCatCode="R0008";}
		else if(DocName.contains("RENT RECEIPT FOR LEASEHOLD PLOT")){DocCatCode="R0008";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocCatCode="R0008";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocCatCode="R0008";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocCatCode="R0008";}
		else if(DocName.contains("IRS FORM 2848")){DocCatCode="R0008";}
		else if(DocName.contains("FORM W8-BEN")){DocCatCode="R0008";}
		else if(DocName.contains("FORM W9")){DocCatCode="R0008";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocCatCode="R0008";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocCatCode="R0008";}
		else if(DocName.contains("REFERENCE")){DocCatCode="R0008";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocCatCode="R0008";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocCatCode="R0008";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocCatCode="R0008";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocCatCode="R0008";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocCatCode="R0008";}
		else if(DocName.contains("STATEMENT OF WORK")){DocCatCode="R0008";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocCatCode="R0008";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocCatCode="R0008";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocCatCode="R0008";}
		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocCatCode="R0008";}
		else if(DocName.contains("LOGIN CHECKLIST")){DocCatCode="R0008";}
		else if(DocName.contains("DIARY NOTE")){DocCatCode="R0008";}
		else if(DocName.contains("NAME SCREENING RESOLUTION EVIDENCE")){DocCatCode="R0008";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocCatCode="R0008";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocCatCode="R0008";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocCatCode="R0008";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocCatCode="R0008";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocCatCode="R0008";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocCatCode="R0008";}
		else if(DocName.contains("PISE SEARCH")){DocCatCode="R0008";}
		else if(DocName.contains("PLAN DOCUMENT")){DocCatCode="R0008";}
		else if(DocName.contains("CC WORKSHEET")){DocCatCode="R0008";}
		else if(DocName.contains("IRANIAN ADDENDUM")){DocCatCode="R0006";}
		else if(DocName.contains("LEGAL DOCUMENT")){DocCatCode="R0006";}
		else if(DocName.contains("LOAN AGREEMENT ACROSS LOCATIONS")){DocCatCode="R0006";}
		else if(DocName.contains("LOCKER ACCOUNT OPENING FORM")){DocCatCode="R0006";}
		else if(DocName.contains("LOCKER AGREEMENT")){DocCatCode="R0006";}
		else if(DocName.contains("LOCKER RENT & FEE")){DocCatCode="R0006";}
		else if(DocName.contains("MARINER DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("MARRIAGE CERTIFICATE")){DocCatCode="R0006";}
		else if(DocName.contains("MEMORANDUM OF GENERAL PLEDGE")){DocCatCode="R0006";}
		else if(DocName.contains("MID")){DocCatCode="R0006";}
		else if(DocName.contains("MULTIPLE PRODUCT DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("NATIONALITY PROOF")){DocCatCode="R0006";}
		else if(DocName.contains("NOMINATION FORM")){DocCatCode="R0006";}
		else if(DocName.contains("NORKOM")){DocCatCode="R0006";}
		else if(DocName.contains("NOTARIZED AFFIDAVIT FOR NAME CHANGE")){DocCatCode="R0006";}
		else if(DocName.contains("NR DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("NRI ANNEXURE STATEMENT")){DocCatCode="R0006";}
		else if(DocName.contains("OFFER LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("PDPA")){DocCatCode="R0006";}
		else if(DocName.contains("POA & DEBIT AUTHORISATION")){DocCatCode="R0006";}
		else if(DocName.contains("RECOVERY INSTRUCTION FOR LOCKER RENT")){DocCatCode="R0006";}
		else if(DocName.contains("REIMBURSEMENT FORM ? AOF")){DocCatCode="R0006";}
		else if(DocName.contains("RESIDENT PERMIT")){DocCatCode="R0006";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("PAN NO")){DocCatCode="R0006";}
		else if(DocName.contains("PASSPORT")){DocCatCode="R0006";}
		else if(DocName.contains("ANNEXURE - 18 (3IN1 PRODUCT)")){DocCatCode="R0006";}
		else if(DocName.contains("ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)")){DocCatCode="R0006";}
		else if(DocName.contains("ANNEXURE X - SIGNATURE DIFFER")){DocCatCode="R0006";}
		else if(DocName.contains("CKYC FORM")){DocCatCode="R0006";}
		else if(DocName.contains("CLIENT DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("CLOSE RELATIVE DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("CLOSURE INSTRUCTION")){DocCatCode="R0006";}
		else if(DocName.contains("CONTINOUS DISCHARGE CERTIFICATE")){DocCatCode="R0006";}
		else if(DocName.contains("CRS/ FATCA AOF ANNEXURE")){DocCatCode="R0006";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE")){DocCatCode="R0006";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID")){DocCatCode="R0006";}
		else if(DocName.contains("CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA")){DocCatCode="R0006";}
		else if(DocName.contains("CUSTOMER SERVICE LETTER. ")){DocCatCode="R0006";}
		else if(DocName.contains("DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("DEPONENT ID PROOF")){DocCatCode="R0006";}
		else if(DocName.contains("DIVORCE CERTIFICATE/COURT ORDER")){DocCatCode="R0006";}
		else if(DocName.contains("DOB MISMATCH DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("REQUEST FOR FIXED DEPOSIT/LIEN")){DocCatCode="R0006";}
		else if(DocName.contains("REQUEST FOR LOCKER")){DocCatCode="R0006";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("RPI ANNEXURE STATEMENT")){DocCatCode="R0006";}
		else if(DocName.contains("SANCTION LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT")){DocCatCode="R0006";}
		else if(DocName.contains("SIGNATURE CARD")){DocCatCode="R0006";}
		else if(DocName.contains("SIGNATURE PROOF")){DocCatCode="R0006";}
		else if(DocName.contains("SUPPLEMENTAL H/S AGR")){DocCatCode="R0006";}
		else if(DocName.contains("SUPPLEMENTARY DECLARTION")){DocCatCode="R0006";}
		else if(DocName.contains("WORK PERMIT")){DocCatCode="R0006";}
		else if(DocName.contains("CREDIT CARD COPY")){DocCatCode="R0006";}
		else if(DocName.contains("PARTNER?S AUTHORITY LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("DIPLOMAT DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("TXN INFORMATION DOCUMENT( TID)")){DocCatCode="R0006";}
		else if(DocName.contains("VERNACULAR BOND")){DocCatCode="R0006";}
		else if(DocName.contains("VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH")){DocCatCode="R0006";}
		else if(DocName.contains("VERNACULAR DECLARATION - UNDERSTAND ENGLISH")){DocCatCode="R0006";}
		else if(DocName.contains("CUSTOMER CLARIFICATION E-MAIL")){DocCatCode="R0006";}
		else if(DocName.contains("INTERNAL CLARIFICATION E-MAIL")){DocCatCode="R0006";}
		else if(DocName.contains("BACK VALUE DATE APPROVAL")){DocCatCode="R0006";}
		else if(DocName.contains("2IN1 LINKING FORM")){DocCatCode="R0006";}
		else if(DocName.contains("ACCOUNT OPENING FORM")){DocCatCode="R0006";}
		else if(DocName.contains("ACKNOWLEDGED LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("EMPLOYMENT PROOF")){DocCatCode="R0006";}
		else if(DocName.contains("EXPAT DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("VISA")){DocCatCode="R0006";}
		else if(DocName.contains("STAFF DECLARATION")){DocCatCode="R0006";}
		else if(DocName.contains("STATEMENT OF OTHER HOLDING")){DocCatCode="R0006";}
		else if(DocName.contains("AADHAAR ENROLLMENT PROOF")){DocCatCode="R0006";}
		else if(DocName.contains("RATION CARD")){DocCatCode="R0006";}
		else if(DocName.contains("CHEQUE LEAF")){DocCatCode="R0006";}
		else if(DocName.contains("FIR COPY")){DocCatCode="R0006";}
		else if(DocName.contains("CENTRAL BANK AUTHORIZATION LETTER")){DocCatCode="R0006";}
		else if(DocName.contains("FUNDING CHEQUE")){DocCatCode="R0006";}
		else if(DocName.contains("GAZZETTE NOTIFICATION")){DocCatCode="R0006";}
		else if(DocName.contains("GPOA")){DocCatCode="R0006";}
		else if(DocName.contains("GUARDIAN DECLARATION FOR PAN NO UPDATION")){DocCatCode="R0006";}
		else if(DocName.contains("ID")){DocCatCode="R0006";}
		else if(DocName.contains("IID")){DocCatCode="R0006";}
		else if(DocName.contains("IRS FORM 2848")){DocCatCode="R0003";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocCatCode="R0003";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocCatCode="R0003";}
		else if(DocName.contains("FORM W8-BEN")){DocCatCode="R0003";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocCatCode="R0003";}
		else if(DocName.contains("FORM W9")){DocCatCode="R0003";}

		else if(DocName.contains("LOGIN CHECKLIST")){DocCatCode="R0009";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocCatCode="R0009";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocCatCode="R0009";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocCatCode="R0009";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocCatCode="R0009";}

		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocCatCode="R0009";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocCatCode="R0009";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocCatCode="R0009";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocCatCode="R0009";}
		else if(DocName.contains("PLAN DOCUMENT")){DocCatCode="R0009";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocCatCode="R0009";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocCatCode="R0009";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocCatCode="R0009";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocCatCode="R0009";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocCatCode="R0009";}
		else if(DocName.contains("STATEMENT OF WORK")){DocCatCode="R0009";}
		else if(DocName.contains("PISE SEARCH")){DocCatCode="R0009";}
		else if(DocName.contains("CC WORKSHEET")){DocCatCode="R0009";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocCatCode="R0009";}
		else if(DocName.contains("REFERENCE")){DocCatCode="R0009";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocCatCode="R0009";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocCatCode="R0009";}
		else if(DocName.contains("DIARY NOTE")){DocCatCode="R0009";}


		return DocCatCode;
	}


	public static String setDocumentCategoryName(String DocName){

		String DocCatName="";

		if(DocName.contains("PAYSLIP")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PROOF OF PROPRIETORSHIP")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("DUMMY DOCUMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PARTNERSHIP DEED")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("SERVICE TAX REGISTRATION CERTIFICATE ")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("SHOP AND ESTABLISHMENT CERTIFICATE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("TRADE LICENSE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("SALES TAX REGISTRATION CERTIFICATE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("FORM 16")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("CA REPORT ON INCOME DOCUMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("INCREMENT LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("DOCUMENT FRAUD VERIFICATION REPORT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("1 WAY SMS VERIFICATION REPORT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("2 WAY SMS VERIFICATION REPORT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PERSONAL DISCUSSION VERIFICATION REPORT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("OFFICE VERIFICATION REPORT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("EMAIL APPROVAL - LEVEL 1")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("HEALTH INSURANCE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("INCOME ASSESSMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("INT/DIVND LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("LABOUR INSURANCE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("LIFE INSURANCE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("OTHER BANK''S STATEMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("ANNUAL BONUS LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("AUTO INSURANCE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("BANK LH AUM")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("BANK STATEMENT  ( SALARIED /SELF EMPLOYED)")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("CREDIT CARD /DEBIT CARD STATEMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("SHAREHOLDING % DOC")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("HR LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("OFFER LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("RETIREMENT PROOF")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("UTILITY BILL")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("ITR DOCUMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PROFIT & LOSS STATEMENT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("BALANCE SHEET")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PROFESSIONAL DEGREE CERTIFICATE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("MCA SITE PRINTOUT")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("LOAN REPAYMENT TRACK")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("LOAN REPAYMENT SCHEDULE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("LOAN CLOSURE PROOF")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PROOF OF BUSINESS CONTINUITY FOR 3YEARS")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PROPERTY INSURANCE")){DocCatName="CLIENT CREDIT ASSESSMENT DOCUMENTS";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("PASSPORT")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("PEP")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("AADHAAR")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("DRIVING LIC NO")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("EMIRATES ID")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("ID CARD ISSUED BY ELECTORAL OFFICE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("MARK SHEET")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("NADRA")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("NREGA JOB CARD")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("PAN NO")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("BLACKLIST CHECK")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("SAR")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("SUPPLEMENTARY - ID")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("VOTERS ID ")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("SECONDARY - ID")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("CUSTOMER PHOTO")){DocCatName="CLIENT ID  DOCUMENTS";}
		else if(DocName.contains("EMPLOYER /HR CERTIFICATE OF ADDRESS")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("HR LETTER")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("BUSINESS LETTERHEAD")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("CASH COVERED LETTER ")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("SURROGATE SPECIFIC PRODUCT ST/LETTER")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("CLIENT AUTHORIZATION")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("SET-OFF LETTER ")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("SOW")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("CERTIFICATE")){DocCatName="CLIENT SERVICING DOCUMENTS";}
		else if(DocName.contains("FOREIGN TIN")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("FORM 60")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("GST/VAT DOCUMENT")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("PAN NO")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("CRS DOCUMENT")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("TAX IDENTIFICATION NUMBER")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("CANADIAN TAX IDENTIFICATION")){DocCatName="CLIENT TAX DOCUMENTS";}
		else if(DocName.contains("PASSPORT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("VISA")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PIO CARD")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("POST OFFICE SAVINGS BANK ACCOUNT STATEMENT ")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PROPERTY TAX RECEIPT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PAN VERIFICATION COPY ")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("AADHAAR")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PAN NO")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("DRIVING LIC NO")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("MARK SHEET")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("ELECTRICITY BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("EMBASSY / UNO LETTERS")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("GAS BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD (OTHER NATIONALITY)")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("INTERNET BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("LETTER ISSUED BY A GAZETTED OFFICER")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("MAINTENANCE BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("MOBILE BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("MUNICIPAL TAX RECEIPT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("NATIONAL IDENTITY CARD")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("NREGA JOB CARD")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("OCI CARD")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("ACKNOWLEDGMENT OF RECEIPT OF LETTER,")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("ADDRESS CONFIRMATION THROUGH CIBIL DATA")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("CENTRAL POPULATION REGISTER (SMART CARD) ")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("RESIDENCE PROOF")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("RESIDENCE VERIFICATION REPORT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("RESIDENT PERMIT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("RESIDENT VERIFICATION REPORT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("SUPPLEMENTARY - RESIDENCE PROOF")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("TELEPHONE BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("VOTERS ID ")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("WATER BILL")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("LETTER ISSUED BY NATIONAL POPULATION REGISTER")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("NADRA")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("TAX DEMAND LETTER OR STATEMENT")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)")){DocCatName="CLIENT VERIFICATION DOCUMENTS";}
		else if(DocName.contains("ACKNOWLEDGED NOTICE OF INTIMATION ? ORIGINAL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ADDITIONAL COST LETTER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AFFIDAVIT CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AFFIDAVIT FROM APPLICANT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AFTER COMPLETION ARCHITECTS CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AGREEMENT LODGED FOR REGN")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ALLOTMENT LETTER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AMENITIES AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ANNEXURE Z")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("APPLICATION FOR NAME TRANSFER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("APPROVED LAYOUT PLAN")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("APPROVED SANCTION PLANS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("APPROVED TCP LAYOUT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ARCHITECTS ESTIMATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AUTHORISATION LETTER FROM BORROWER ADDRESSED T")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("BACK DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("BOARD RESOLUTION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("BUILDER DECLARATION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("BYE LAWS OF SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CA CERTIFICATE FOR DISBURSAL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CERTI (BY TEHSIL OFFICE ) OF INTEKHAB KHATUNI")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CHAIN DOCUMENTS OF THE PROPERTY.")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CHAIN OF TITLE DOCUMENTS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CHALLANS -  RECEIPTS OF PAYMENTS MADE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("COMMENCEMENT CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONFIRMATION LETTER FROM PURCHASER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONSTRUCTION AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONSTRUCTION PERMISSION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONSTRUCTION SCHEDULE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONVERSION CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CONVEYANCE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CROSS COLLATERAL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CROSS DEFAULT AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEATH CERTIFICATES")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DECLARATION FROM PURCHASER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEED OF APARTMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEED OF ASSIGNMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEMAND LETTER FOR CURR DISB")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEMAND LETTER FROM DDA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DEVELOPMENT AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DISBURSAL SCHEDULE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DIVERSION RENT RECEIPT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DOC ENSURING OWNERSHIP")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DOCUMENTS OF THE BUILDER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DRCS APPROVAL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY BUYER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SALE AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SALE DEED EXECUTED BY BUYER/BORROWER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SALE DEED EXECUTED BY SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SANCTION PLANS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SEARCH REPORT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SHARE CERTIFICATE BUYER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SHARE CERTIFICATE SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SUB-LEASE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SURRENDER DEED FROM SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TECHNICAL CUM LEGAL UNDERTAKING")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TITLE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRANSFER FORM FOR SHARE CERT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRANSFER LETTER FAV SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRANSFER LETTER FROM PCNTDA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRANSFER MEMORANDUM IN FAVOR OF PURCHASER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("WILL SIGNED BY THE SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DDA MORTGAGE -ACK")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LIST OF DOCUMENTS HELD WITH HFC ")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MEMORANDUM OF ENTRY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NOC FROM LAND ACQUISITION OFF ( KHASRA PLOT)")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("RESOLUTION FOR A MORTGAGE PROPERTY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("STAMPED MOE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRIPATRIATE AGR")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("UNDERTAKING FROM SELLER TO HANDOVER DOCS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("VALUATION REPORT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("7/12EXTRACT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ENCUMBRANCE CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FINANCIAL COVENANTS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FLAT BUYERS AGR")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("EARLIER DOCS OF THE BUILDER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("EARLIER DOCS OF THE SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("STAMP DUTY RECEIPT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FORM 8 & 13")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FORM A + B + REGULARISED PLAN")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("GIFT DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("GPA BY THE SELLER IN FAVOR OF THE BUYER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("GPA SPA AND WILL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("GPOA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("HANDING OVER POSSESSION LETTER TO THE BORROWER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("HIRE PURCHASE AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INDEMNITY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INDEMNITY SIGNED BY SELLER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INDENTURE OF SALE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INDEX 2")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INSTRUMENT OF TRANSFER OF LAND")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INTIMATION TO JDA OF MORTGAGE DULY ACK")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INTIMATION TO RIICO OF MORTGAGE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("KHATAUNI FOR THE FASLI YEAR")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("KHATHA DOCUMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LAND OWNERS DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LATEST OUTSTANDING LETTER FROM FINANCIER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LEASE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LEGAL DOCUMENT OF EXPIRED OWNER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LEGAL OPINION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LEGAL REPORT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LETTER FROM BANK TO THE DEVELOPER / BUILDER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LETTER FROM BORROWER TO THE DEVELOPER / BLDG")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LETTER FROM SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LETTER OF OFFER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LETTER OF UNDERTAKING")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LIEN MARKING LETTER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LIEN NOTED CERTIFICATE FROM SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LOAN CLOSURE LETTER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LOCATION CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MARGIN MONEY RECEIPTS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MEMORANDUM OF DEPOSIT OF TITLE DEED ? ORIGINAL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MEMORANDUM OF UNDERTAKING")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MORTGAGE PERMISSION FROM RHB")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("MP PRAKOSHTHA ADHINIYAM")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NA ORDER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NAME TRANSFER FAV BORROWER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NEW ENGINEERING CONTRACT ")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NO DUES CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NOC FROM BDA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NOC FROM BUILDER / SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NOC TO MORTGAGE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NOC TO TRANSFER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("OCCUPATION CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ORIGINAL COMP CERTIFICATE ")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ORIGINAL INSURANCE CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ORIGINAL NOMINATION AGREEMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PARTITION DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PATTA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PAYMENT RECEIPTS FOR LAND")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PAYMENT SCHEDULE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PERMISSION FOR ADMITTING BORROWER AS MEMBER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PLANNING PERMIT AND CONSTRUCTION PERMIT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PLOTS ALLOTTED AT CONCESSIONAL RATES")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("POA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("POA DOCS FAV SELLER / BUILDER OR DEVELOPER")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("POSSESSION CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("POSSESSION LETTER FROM RHB")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PREVIOUS AGREEMENT LODGED FOR REGISTRATION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PREVIOUS PARTY SHARE CERTIFICATE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROOF OD AGRICULTURAL LAND")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROOF OF BASIS OF OWNERSHIP")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROOF OF CUSTOMER EQUITY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROOF OF DISCHARGE OF MORTGAGE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROOF OF PROPERTY UNDER JURISDICTION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PROPERTY CARD")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("RECTIFICATION DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REGISTERED AGREEMENT TO SELL")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REGISTERED MORTGAGE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REGISTERED SALE DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REGISTERED TRANSFER DEED")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REGISTRATION RECEIPT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("RENT RECEIPT FOR LEASEHOLD PLOT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("IRS FORM 2848")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FORM W8-BEN")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("FORM W9")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("REFERENCE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("STATEMENT OF WORK")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("LOGIN CHECKLIST")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("DIARY NOTE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("NAME SCREENING RESOLUTION EVIDENCE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PISE SEARCH")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("PLAN DOCUMENT")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("CC WORKSHEET")){DocCatName="COLLATERAL DOCUMENTS";}
		else if(DocName.contains("IRANIAN ADDENDUM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("LEGAL DOCUMENT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("LOAN AGREEMENT ACROSS LOCATIONS")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("LOCKER ACCOUNT OPENING FORM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("LOCKER AGREEMENT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("LOCKER RENT & FEE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("MARINER DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("MARRIAGE CERTIFICATE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("MEMORANDUM OF GENERAL PLEDGE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("MID")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("MULTIPLE PRODUCT DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NATIONALITY PROOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NOMINATION FORM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NORKOM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NOTARIZED AFFIDAVIT FOR NAME CHANGE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NR DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("NRI ANNEXURE STATEMENT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("OFFER LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("PDPA")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("POA & DEBIT AUTHORISATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RECOVERY INSTRUCTION FOR LOCKER RENT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("REIMBURSEMENT FORM ? AOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RESIDENT PERMIT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("PAN NO")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("PASSPORT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ANNEXURE - 18 (3IN1 PRODUCT)")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ANNEXURE X - SIGNATURE DIFFER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CKYC FORM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CLIENT DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CLOSE RELATIVE DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CLOSURE INSTRUCTION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CONTINOUS DISCHARGE CERTIFICATE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CRS/ FATCA AOF ANNEXURE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CUSTOMER SERVICE LETTER. ")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("DEPONENT ID PROOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("DIVORCE CERTIFICATE/COURT ORDER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("DOB MISMATCH DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("REQUEST FOR FIXED DEPOSIT/LIEN")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("REQUEST FOR LOCKER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RPI ANNEXURE STATEMENT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SANCTION LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SIGNATURE CARD")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SIGNATURE PROOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SUPPLEMENTAL H/S AGR")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("SUPPLEMENTARY DECLARTION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("WORK PERMIT")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CREDIT CARD COPY")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("PARTNER?S AUTHORITY LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("DIPLOMAT DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("TXN INFORMATION DOCUMENT( TID)")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("VERNACULAR BOND")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("VERNACULAR DECLARATION - UNDERSTAND ENGLISH")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CUSTOMER CLARIFICATION E-MAIL")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("INTERNAL CLARIFICATION E-MAIL")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("BACK VALUE DATE APPROVAL")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("2IN1 LINKING FORM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ACCOUNT OPENING FORM")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ACKNOWLEDGED LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("EMPLOYMENT PROOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("EXPAT DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("VISA")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("STAFF DECLARATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("STATEMENT OF OTHER HOLDING")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("AADHAAR ENROLLMENT PROOF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("RATION CARD")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CHEQUE LEAF")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("FIR COPY")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("CENTRAL BANK AUTHORIZATION LETTER")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("FUNDING CHEQUE")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("GAZZETTE NOTIFICATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("GPOA")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("GUARDIAN DECLARATION FOR PAN NO UPDATION")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("ID")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}
		else if(DocName.contains("IID")){DocCatName="PRODUCT & SUPPORTING DOCUMENTS";}

		else if(DocName.contains("IRS FORM 2848")){DocCatName="FATCA  DOCUMENTS";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){ DocCatName="FATCA  DOCUMENTS";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){ DocCatName="FATCA  DOCUMENTS";}
		else if(DocName.contains("FORM W8-BEN")){ DocCatName="FATCA  DOCUMENTS";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){ DocCatName="FATCA  DOCUMENTS";}
		else if(DocName.contains("FORM W9")){DocCatName="FATCA  DOCUMENTS";}

		else if(DocName.contains("LOGIN CHECKLIST")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocCatName="INTERNAL DOCUMENTS";}

		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("PLAN DOCUMENT")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("CORROBORATION OF SOW")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S)")) {DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("STATEMENT OF WORK")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("PISE SEARCH")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("CC WORKSHEET")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("REFERENCE")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){ DocCatName="INTERNAL DOCUMENTS";}
		else if(DocName.contains("DIARY NOTE")){ DocCatName="INTERNAL DOCUMENTS";}



		return DocCatName;
	}


	public static String selectTheDocumentType(String DocName){

		String DocType="";
		if(DocName.contains("PAYSLIP")){DocType="T0235";}
		else if(DocName.contains("PROOF OF PROPRIETORSHIP")){DocType="T0366";}
		else if(DocName.contains("DUMMY DOCUMENT")){DocType="T0228";}
		else if(DocName.contains("PARTNERSHIP DEED")){DocType="T0367";}
		else if(DocName.contains("SERVICE TAX REGISTRATION CERTIFICATE ")){DocType="T0368";}
		else if(DocName.contains("SHOP AND ESTABLISHMENT CERTIFICATE")){DocType="T0369";}
		else if(DocName.contains("TRADE LICENSE")){DocType="T0370";}
		else if(DocName.contains("SALES TAX REGISTRATION CERTIFICATE")){DocType="T0371";}
		else if(DocName.contains("FORM 16")){DocType="T0373";}
		else if(DocName.contains("CA REPORT ON INCOME DOCUMENT")){DocType="T0374";}
		else if(DocName.contains("INCREMENT LETTER")){DocType="T0375";}
		else if(DocName.contains("DOCUMENT FRAUD VERIFICATION REPORT")){DocType="T0393";}
		else if(DocName.contains("1 WAY SMS VERIFICATION REPORT")){DocType="T0394";}
		else if(DocName.contains("2 WAY SMS VERIFICATION REPORT")){DocType="T0395";}
		else if(DocName.contains("PERSONAL DISCUSSION VERIFICATION REPORT")){DocType="T0396";}
		else if(DocName.contains("OFFICE VERIFICATION REPORT")){DocType="T0397";}
		else if(DocName.contains("EMAIL APPROVAL - LEVEL 1")){DocType="T0398";}
		else if(DocName.contains("HEALTH INSURANCE")){DocType="T0130";}
		else if(DocName.contains("INCOME ASSESSMENT")){DocType="T0143";}
		else if(DocName.contains("INT/DIVND LETTER")){DocType="T0151";}
		else if(DocName.contains("LABOUR INSURANCE")){DocType="T0159";}
		else if(DocName.contains("LIFE INSURANCE")){DocType="T0176";}
		else if(DocName.contains("OTHER BANK''S STATEMENT")){DocType="T0226";}
		else if(DocName.contains("ANNUAL BONUS LETTER")){DocType="T0023";}
		else if(DocName.contains("AUTO INSURANCE")){DocType="T0032";}
		else if(DocName.contains("BANK LH AUM")){DocType="T0035";}
		else if(DocName.contains("BANK STATEMENT  ( SALARIED /SELF EMPLOYED)")){DocType="T0036";}
		else if(DocName.contains("CREDIT CARD /DEBIT CARD STATEMENT")){DocType="T0069";}
		else if(DocName.contains("SHAREHOLDING % DOC")){DocType="T0307";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="T0326";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="T0107";}
		else if(DocName.contains("HR LETTER")){DocType="T0132";}
		else if(DocName.contains("OFFER LETTER")){DocType="T0222";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocType="T0229";}
		else if(DocName.contains("RETIREMENT PROOF")){DocType="T0386";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocType="T0025";}
		else if(DocName.contains("UTILITY BILL")){DocType="T0340";}
		else if(DocName.contains("ITR DOCUMENT")){DocType="T0356";}
		else if(DocName.contains("PROFIT & LOSS STATEMENT")){DocType="T0357";}
		else if(DocName.contains("BALANCE SHEET")){DocType="T0358";}
		else if(DocName.contains("PROFESSIONAL DEGREE CERTIFICATE")){DocType="T0359";}
		else if(DocName.contains("MCA SITE PRINTOUT")){DocType="T0360";}
		else if(DocName.contains("LOAN REPAYMENT TRACK")){DocType="T0361";}
		else if(DocName.contains("LOAN REPAYMENT SCHEDULE")){DocType="T0362";}
		else if(DocName.contains("LOAN CLOSURE PROOF")){DocType="T0363";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocType="T0364";}
		else if(DocName.contains("PROOF OF BUSINESS CONTINUITY FOR 3YEARS")){DocType="T0365";}
		else if(DocName.contains("PROPERTY INSURANCE")){DocType="T0266";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocType="T0230";}
		else if(DocName.contains("PASSPORT")){DocType="T0231";}
		else if(DocName.contains("PEP")){DocType="T0238";}
		else if(DocName.contains("AADHAAR")){DocType="T0002";}
		else if(DocName.contains("DRIVING LIC NO")){DocType="T0098";}
		else if(DocName.contains("EMIRATES ID")){DocType="T0105";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocType="T0113";}
		else if(DocName.contains("ID CARD ISSUED BY ELECTORAL OFFICE")){DocType="T0134";}
		else if(DocName.contains("IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="T0141";}
		else if(DocName.contains("MARK SHEET")){DocType="T0189";}
		else if(DocName.contains("NADRA")){DocType="T0203";}
		else if(DocName.contains("NREGA JOB CARD")){DocType="T0218";}
		else if(DocName.contains("PAN NO")){DocType="T0227";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocType="T0037";}
		else if(DocName.contains("BLACKLIST CHECK")){DocType="T0038";}
		else if(DocName.contains("SAR")){DocType="T0298";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocType="T0301";}
		else if(DocName.contains("SUPPLEMENTARY - ID")){DocType="T0319";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocType="T0332";}
		else if(DocName.contains("VOTERS ID ")){DocType="T0346";}
		else if(DocName.contains("SECONDARY - ID")){DocType="T0303";}
		else if(DocName.contains("CUSTOMER PHOTO")){DocType="T0380";}
		else if(DocName.contains("EMPLOYER /HR CERTIFICATE OF ADDRESS")){DocType="T0106";}
		else if(DocName.contains("HR LETTER")){DocType="T0132";}
		else if(DocName.contains("BUSINESS LETTERHEAD")){DocType="T0041";}
		else if(DocName.contains("CASH COVERED LETTER ")){DocType="T0045";}
		else if(DocName.contains("SURROGATE SPECIFIC PRODUCT ST/LETTER")){DocType="T0323";}
		else if(DocName.contains("CLIENT AUTHORIZATION")){DocType="T0056";}
		else if(DocName.contains("SET-OFF LETTER ")){DocType="T0304";}
		else if(DocName.contains("SOW")){DocType="T0311";}
		else if(DocName.contains("CERTIFICATE")){DocType="T0049";}
		else if(DocName.contains("FOREIGN TIN")){DocType="T0114";}
		else if(DocName.contains("FORM 60")){DocType="T0115";}
		else if(DocName.contains("GST/VAT DOCUMENT")){DocType="T0127";}
		else if(DocName.contains("PAN NO")){DocType="T0227";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="T0326";}
		else if(DocName.contains("CRS DOCUMENT")){DocType="T0072";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocType="T0073";}
		else if(DocName.contains("TAX IDENTIFICATION NUMBER")){DocType="T0325";}
		else if(DocName.contains("CANADIAN TAX IDENTIFICATION")){DocType="T0044";}
		else if(DocName.contains("PASSPORT")){DocType="T0231";}
		else if(DocName.contains("VISA")){DocType="T0345";}
		else if(DocName.contains("PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS")){DocType="T0240";}
		else if(DocName.contains("PIO CARD")){DocType="T0245";}
		else if(DocName.contains("POST OFFICE SAVINGS BANK ACCOUNT STATEMENT ")){DocType="T0256";}
		else if(DocName.contains("PROPERTY TAX RECEIPT")){DocType="T0267";}
		else if(DocName.contains("PAN VERIFICATION COPY ")){DocType="T0377";}
		else if(DocName.contains("AADHAAR")){DocType="T0002";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="T0107";}
		else if(DocName.contains("PAN NO")){DocType="T0227";}
		else if(DocName.contains("DRIVING LIC NO")){DocType="T0098";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocType="T0332";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocType="T0230";}
		else if(DocName.contains("MARK SHEET")){DocType="T0189";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocType="T0301";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocType="T0037";}
		else if(DocName.contains("ELECTRICITY BILL")){DocType="T0102";}
		else if(DocName.contains("EMBASSY / UNO LETTERS")){DocType="T0104";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocType="T0113";}
		else if(DocName.contains("GAS BILL")){DocType="T0121";}
		else if(DocName.contains("IDENTITY CARD (OTHER NATIONALITY)")){DocType="T0135";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION")){DocType="T0136";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT")){DocType="T0137";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS")){DocType="T0138";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS")){DocType="T0139";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS")){DocType="T0140";}
		else if(DocName.contains("INTERNET BILL")){DocType="T0152";}
		else if(DocName.contains("LETTER ISSUED BY A GAZETTED OFFICER")){DocType="T0170";}
		else if(DocName.contains("LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER")){DocType="T0171";}
		else if(DocName.contains("MAINTENANCE BILL")){DocType="T0186";}
		else if(DocName.contains("MOBILE BILL")){DocType="T0196";}
		else if(DocName.contains("MUNICIPAL TAX RECEIPT")){DocType="T0201";}
		else if(DocName.contains("NATIONAL IDENTITY CARD")){DocType="T0205";}
		else if(DocName.contains("NREGA JOB CARD")){DocType="T0218";}
		else if(DocName.contains("OCI CARD")){DocType="T0221";}
		else if(DocName.contains("ACKNOWLEDGMENT OF RECEIPT OF LETTER,")){DocType="T0006";}
		else if(DocName.contains("ADDRESS CONFIRMATION THROUGH CIBIL DATA")){DocType="T0008";}
		else if(DocName.contains("ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="T0009";}
		else if(DocName.contains("CENTRAL POPULATION REGISTER (SMART CARD) ")){DocType="T0047";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocType="T0279";}
		else if(DocName.contains("RESIDENCE PROOF")){DocType="T0284";}
		else if(DocName.contains("RESIDENCE VERIFICATION REPORT")){DocType="T0285";}
		else if(DocName.contains("RESIDENT PERMIT")){DocType="T0286";}
		else if(DocName.contains("RESIDENT VERIFICATION REPORT")){DocType="T0287";}
		else if(DocName.contains("SUPPLEMENTARY - RESIDENCE PROOF")){DocType="T0320";}
		else if(DocName.contains("TELEPHONE BILL")){DocType="T0329";}
		else if(DocName.contains("VOTERS ID ")){DocType="T0346";}
		else if(DocName.contains("WATER BILL")){DocType="T0348";}
		else if(DocName.contains("LETTER ISSUED BY NATIONAL POPULATION REGISTER")){DocType="T0388";}
		else if(DocName.contains("NADRA")){DocType="T0203";}
		else if(DocName.contains("TAX DEMAND LETTER OR STATEMENT")){DocType="T0324";}
		else if(DocName.contains("PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)")){DocType="T0237";}
		else if(DocName.contains("ACKNOWLEDGED NOTICE OF INTIMATION ? ORIGINAL")){DocType="T0005";}
		else if(DocName.contains("ADDITIONAL COST LETTER")){DocType="T0007";}
		else if(DocName.contains("AFFIDAVIT CERTIFICATE")){DocType="T0011";}
		else if(DocName.contains("AFFIDAVIT FROM APPLICANT")){DocType="T0012";}
		else if(DocName.contains("AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT")){DocType="T0013";}
		else if(DocName.contains("AFTER COMPLETION ARCHITECTS CERTIFICATE")){DocType="T0014";}
		else if(DocName.contains("AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY")){DocType="T0015";}
		else if(DocName.contains("AGREEMENT LODGED FOR REGN")){DocType="T0016";}
		else if(DocName.contains("ALLOTMENT LETTER")){DocType="T0017";}
		else if(DocName.contains("AMENITIES AGREEMENT")){DocType="T0018";}
		else if(DocName.contains("ANNEXURE Z")){DocType="T0022";}
		else if(DocName.contains("APPLICATION FOR NAME TRANSFER")){DocType="T0024";}
		else if(DocName.contains("APPROVED LAYOUT PLAN")){DocType="T0026";}
		else if(DocName.contains("APPROVED SANCTION PLANS")){DocType="T0027";}
		else if(DocName.contains("APPROVED TCP LAYOUT")){DocType="T0028";}
		else if(DocName.contains("ARCHITECTS ESTIMATE")){DocType="T0029";}
		else if(DocName.contains("AUTHORISATION LETTER FROM BORROWER ADDRESSED T")){DocType="T0030";}
		else if(DocName.contains("AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA")){DocType="T0031";}
		else if(DocName.contains("BACK DEED")){DocType="T0033";}
		else if(DocName.contains("BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR")){DocType="T0034";}
		else if(DocName.contains("BOARD RESOLUTION")){DocType="T0039";}
		else if(DocName.contains("BUILDER DECLARATION")){DocType="T0040";}
		else if(DocName.contains("BYE LAWS OF SOCIETY")){DocType="T0042";}
		else if(DocName.contains("CA CERTIFICATE FOR DISBURSAL")){DocType="T0043";}
		else if(DocName.contains("CERTI (BY TEHSIL OFFICE ) OF INTEKHAB KHATUNI")){DocType="T0048";}
		else if(DocName.contains("CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL")){DocType="T0051";}
		else if(DocName.contains("CHAIN DOCUMENTS OF THE PROPERTY.")){DocType="T0052";}
		else if(DocName.contains("CHAIN OF TITLE DOCUMENTS")){DocType="T0053";}
		else if(DocName.contains("CHALLANS -  RECEIPTS OF PAYMENTS MADE")){DocType="T0054";}
		else if(DocName.contains("COMMENCEMENT CERTIFICATE")){DocType="T0060";}
		else if(DocName.contains("CONFIRMATION LETTER FROM PURCHASER")){DocType="T0061";}
		else if(DocName.contains("CONSTRUCTION AGREEMENT")){DocType="T0062";}
		else if(DocName.contains("CONSTRUCTION PERMISSION")){DocType="T0063";}
		else if(DocName.contains("CONSTRUCTION SCHEDULE")){DocType="T0064";}
		else if(DocName.contains("CONVERSION CERTIFICATE")){DocType="T0066";}
		else if(DocName.contains("CONVEYANCE DEED")){DocType="T0067";}
		else if(DocName.contains("CROSS COLLATERAL")){DocType="T0070";}
		else if(DocName.contains("CROSS DEFAULT AGREEMENT")){DocType="T0071";}
		else if(DocName.contains("DEATH CERTIFICATES")){DocType="T0080";}
		else if(DocName.contains("DECLARATION FROM PURCHASER")){DocType="T0083";}
		else if(DocName.contains("DEED OF APARTMENT")){DocType="T0084";}
		else if(DocName.contains("DEED OF ASSIGNMENT")){DocType="T0085";}
		else if(DocName.contains("DEMAND LETTER FOR CURR DISB")){DocType="T0086";}
		else if(DocName.contains("DEMAND LETTER FROM DDA")){DocType="T0087";}
		else if(DocName.contains("DEVELOPMENT AGREEMENT")){DocType="T0089";}
		else if(DocName.contains("DISBURSAL SCHEDULE")){DocType="T0091";}
		else if(DocName.contains("DIVERSION RENT RECEIPT")){DocType="T0092";}
		else if(DocName.contains("DOC ENSURING OWNERSHIP")){DocType="T0095";}
		else if(DocName.contains("DOCUMENTS OF THE BUILDER")){DocType="T0096";}
		else if(DocName.contains("DRCS APPROVAL")){DocType="T0097";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocType="T0279";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY BUYER")){DocType="T0290";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY SELLER")){DocType="T0291";}
		else if(DocName.contains("SALE AGREEMENT")){DocType="T0292";}
		else if(DocName.contains("SALE DEED EXECUTED BY BUYER/BORROWER")){DocType="T0293";}
		else if(DocName.contains("SALE DEED EXECUTED BY SELLER")){DocType="T0294";}
		else if(DocName.contains("SANCTION PLANS")){DocType="T0296";}
		else if(DocName.contains("SEARCH REPORT")){DocType="T0302";}
		else if(DocName.contains("SHARE CERTIFICATE BUYER")){DocType="T0305";}
		else if(DocName.contains("SHARE CERTIFICATE SELLER")){DocType="T0306";}
		else if(DocName.contains("SUB-LEASE DEED")){DocType="T0317";}
		else if(DocName.contains("SURRENDER DEED FROM SOCIETY")){DocType="T0322";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="T0326";}
		else if(DocName.contains("TECHNICAL CUM LEGAL UNDERTAKING")){DocType="T0328";}
		else if(DocName.contains("TITLE DEED")){DocType="T0330";}
		else if(DocName.contains("TRANSFER FORM FOR SHARE CERT")){DocType="T0333";}
		else if(DocName.contains("TRANSFER LETTER FAV SELLER")){DocType="T0334";}
		else if(DocName.contains("TRANSFER LETTER FROM PCNTDA")){DocType="T0335";}
		else if(DocName.contains("TRANSFER MEMORANDUM IN FAVOR OF PURCHASER")){DocType="T0336";}
		else if(DocName.contains("WILL SIGNED BY THE SELLER")){DocType="T0349";}
		else if(DocName.contains("DDA MORTGAGE -ACK")){DocType="T0079";}
		else if(DocName.contains("LIST OF DOCUMENTS HELD WITH HFC ")){DocType="T0177";}
		else if(DocName.contains("MEMORANDUM OF ENTRY")){DocType="T0192";}
		else if(DocName.contains("NOC FROM LAND ACQUISITION OFF ( KHASRA PLOT)")){DocType="T0211";}
		else if(DocName.contains("RESOLUTION FOR A MORTGAGE PROPERTY")){DocType="T0288";}
		else if(DocName.contains("STAMPED MOE")){DocType="T0314";}
		else if(DocName.contains("TRIPATRIATE AGR")){DocType="T0337";}
		else if(DocName.contains("UNDERTAKING FROM SELLER TO HANDOVER DOCS")){DocType="T0339";}
		else if(DocName.contains("VALUATION REPORT")){DocType="T0341";}
		else if(DocName.contains("7/12EXTRACT")){DocType="T0001";}
		else if(DocName.contains("ENCUMBRANCE CERTIFICATE")){DocType="T0109";}
		else if(DocName.contains("FINANCIAL COVENANTS")){DocType="T0111";}
		else if(DocName.contains("FLAT BUYERS AGR")){DocType="T0112";}
		else if(DocName.contains("EARLIER DOCS OF THE BUILDER")){DocType="T0099";}
		else if(DocName.contains("EARLIER DOCS OF THE SOCIETY")){DocType="T0100";}
		else if(DocName.contains("STAMP DUTY RECEIPT")){DocType="T0313";}
		else if(DocName.contains("FORM 8 & 13")){DocType="T0116";}
		else if(DocName.contains("FORM A + B + REGULARISED PLAN")){DocType="T0117";}
		else if(DocName.contains("GIFT DEED")){DocType="T0123";}
		else if(DocName.contains("GPA BY THE SELLER IN FAVOR OF THE BUYER")){DocType="T0124";}
		else if(DocName.contains("GPA SPA AND WILL")){DocType="T0125";}
		else if(DocName.contains("GPOA")){DocType="T0126";}
		else if(DocName.contains("HANDING OVER POSSESSION LETTER TO THE BORROWER")){DocType="T0129";}
		else if(DocName.contains("HIRE PURCHASE AGREEMENT")){DocType="T0131";}
		else if(DocName.contains("INDEMNITY")){DocType="T0144";}
		else if(DocName.contains("INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER")){DocType="T0146";}
		else if(DocName.contains("INDEMNITY SIGNED BY SELLER")){DocType="T0147";}
		else if(DocName.contains("INDENTURE OF SALE")){DocType="T0148";}
		else if(DocName.contains("INDEX 2")){DocType="T0149";}
		else if(DocName.contains("INSTRUMENT OF TRANSFER OF LAND")){DocType="T0150";}
		else if(DocName.contains("INTIMATION TO JDA OF MORTGAGE DULY ACK")){DocType="T0153";}
		else if(DocName.contains("INTIMATION TO RIICO OF MORTGAGE")){DocType="T0154";}
		else if(DocName.contains("KHATAUNI FOR THE FASLI YEAR")){DocType="T0157";}
		else if(DocName.contains("KHATHA DOCUMENT")){DocType="T0158";}
		else if(DocName.contains("LAND OWNERS DEED")){DocType="T0160";}
		else if(DocName.contains("LATEST OUTSTANDING LETTER FROM FINANCIER")){DocType="T0161";}
		else if(DocName.contains("LEASE DEED")){DocType="T0162";}
		else if(DocName.contains("LEGAL DOCUMENT OF EXPIRED OWNER")){DocType="T0164";}
		else if(DocName.contains("LEGAL OPINION")){DocType="T0165";}
		else if(DocName.contains("LEGAL REPORT")){DocType="T0166";}
		else if(DocName.contains("LETTER FROM BANK TO THE DEVELOPER / BUILDER")){DocType="T0167";}
		else if(DocName.contains("LETTER FROM BORROWER TO THE DEVELOPER / BLDG")){DocType="T0168";}
		else if(DocName.contains("LETTER FROM SOCIETY")){DocType="T0169";}
		else if(DocName.contains("LETTER OF OFFER")){DocType="T0172";}
		else if(DocName.contains("LETTER OF UNDERTAKING")){DocType="T0173";}
		else if(DocName.contains("LIEN MARKING LETTER")){DocType="T0174";}
		else if(DocName.contains("LIEN NOTED CERTIFICATE FROM SOCIETY")){DocType="T0175";}
		else if(DocName.contains("LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY")){DocType="T0178";}
		else if(DocName.contains("LOAN CLOSURE LETTER")){DocType="T0180";}
		else if(DocName.contains("LOCATION CERTIFICATE")){DocType="T0181";}
		else if(DocName.contains("LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION")){DocType="T0185";}
		else if(DocName.contains("MARGIN MONEY RECEIPTS")){DocType="T0187";}
		else if(DocName.contains("MEMORANDUM OF DEPOSIT OF TITLE DEED ? ORIGINAL")){DocType="T0191";}
		else if(DocName.contains("MEMORANDUM OF UNDERTAKING")){DocType="T0194";}
		else if(DocName.contains("MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT")){DocType="T0197";}
		else if(DocName.contains("MORTGAGE PERMISSION FROM RHB")){DocType="T0198";}
		else if(DocName.contains("MP PRAKOSHTHA ADHINIYAM")){DocType="T0199";}
		else if(DocName.contains("NA ORDER")){DocType="T0202";}
		else if(DocName.contains("NAME TRANSFER FAV BORROWER")){DocType="T0204";}
		else if(DocName.contains("NEW ENGINEERING CONTRACT ")){DocType="T0207";}
		else if(DocName.contains("NO DUES CERTIFICATE")){DocType="T0208";}
		else if(DocName.contains("NOC FROM BDA")){DocType="T0209";}
		else if(DocName.contains("NOC FROM BUILDER / SOCIETY")){DocType="T0210";}
		else if(DocName.contains("NOC TO MORTGAGE")){DocType="T0212";}
		else if(DocName.contains("NOC TO TRANSFER")){DocType="T0213";}
		else if(DocName.contains("OCCUPATION CERTIFICATE")){DocType="T0220";}
		else if(DocName.contains("ORIGINAL COMP CERTIFICATE ")){DocType="T0223";}
		else if(DocName.contains("ORIGINAL INSURANCE CERTIFICATE")){DocType="T0224";}
		else if(DocName.contains("ORIGINAL NOMINATION AGREEMENT")){DocType="T0225";}
		else if(DocName.contains("PARTITION DEED")){DocType="T0228";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocType="T0229";}
		else if(DocName.contains("PATTA")){DocType="T0232";}
		else if(DocName.contains("PAYMENT RECEIPTS FOR LAND")){DocType="T0233";}
		else if(DocName.contains("PAYMENT SCHEDULE")){DocType="T0234";}
		else if(DocName.contains("PERMISSION FOR ADMITTING BORROWER AS MEMBER")){DocType="T0241";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO")){DocType="T0242";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM SOCIETY")){DocType="T0243";}
		else if(DocName.contains("PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY")){DocType="T0244";}
		else if(DocName.contains("PLANNING PERMIT AND CONSTRUCTION PERMIT")){DocType="T0248";}
		else if(DocName.contains("PLOTS ALLOTTED AT CONCESSIONAL RATES")){DocType="T0249";}
		else if(DocName.contains("POA")){DocType="T0250";}
		else if(DocName.contains("POA DOCS FAV SELLER / BUILDER OR DEVELOPER")){DocType="T0252";}
		else if(DocName.contains("PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA")){DocType="T0253";}
		else if(DocName.contains("POSSESSION CERTIFICATE")){DocType="T0254";}
		else if(DocName.contains("POSSESSION LETTER FROM RHB")){DocType="T0255";}
		else if(DocName.contains("PREVIOUS AGREEMENT LODGED FOR REGISTRATION")){DocType="T0257";}
		else if(DocName.contains("PREVIOUS PARTY SHARE CERTIFICATE")){DocType="T0258";}
		else if(DocName.contains("PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN")){DocType="T0259";}
		else if(DocName.contains("PROOF OD AGRICULTURAL LAND")){DocType="T0260";}
		else if(DocName.contains("PROOF OF BASIS OF OWNERSHIP")){DocType="T0261";}
		else if(DocName.contains("PROOF OF CUSTOMER EQUITY")){DocType="T0262";}
		else if(DocName.contains("PROOF OF DISCHARGE OF MORTGAGE")){DocType="T0263";}
		else if(DocName.contains("PROOF OF PROPERTY UNDER JURISDICTION")){DocType="T0264";}
		else if(DocName.contains("PROPERTY CARD")){DocType="T0265";}
		else if(DocName.contains("RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC")){DocType="T0268";}
		else if(DocName.contains("RECTIFICATION DEED")){DocType="T0270";}
		else if(DocName.contains("REGISTERED AGREEMENT TO SELL")){DocType="T0272";}
		else if(DocName.contains("REGISTERED MORTGAGE DEED")){DocType="T0273";}
		else if(DocName.contains("REGISTERED SALE DEED")){DocType="T0274";}
		else if(DocName.contains("REGISTERED TRANSFER DEED")){DocType="T0275";}
		else if(DocName.contains("REGISTRATION RECEIPT")){DocType="T0276";}
		else if(DocName.contains("RENT RECEIPT FOR LEASEHOLD PLOT")){DocType="T0278";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocType="T0050";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocType="T0347";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocType="T0381";}
		else if(DocName.contains("IRS FORM 2848")){DocType="T0156";}
		else if(DocName.contains("FORM W8-BEN")){DocType="T0118";}
		else if(DocName.contains("FORM W9")){DocType="T0119";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocType="T0073";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocType="T0010";}
		else if(DocName.contains("REFERENCE")){DocType="T0271";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocType="T0068";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocType="T0082";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocType="T0297";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocType="T0299";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocType="T0310";}
		else if(DocName.contains("STATEMENT OF WORK")){DocType="T0316";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocType="T0327";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocType="T0331";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocType="T0387";}
		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocType="T0103";}
		else if(DocName.contains("LOGIN CHECKLIST")){DocType="T0372";}
		else if(DocName.contains("DIARY NOTE")){DocType="T0376";}
		else if(DocName.contains("NAME SCREENING RESOLUTION EVIDENCE")){DocType="T0352";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocType="T0353";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocType="T0354";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocType="T0355";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocType="T0364";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocType="T0101";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocType="T0239";}
		else if(DocName.contains("PISE SEARCH")){DocType="T0246";}
		else if(DocName.contains("PLAN DOCUMENT")){DocType="T0247";}
		else if(DocName.contains("CC WORKSHEET")){DocType="T0046";}
		else if(DocName.contains("IRANIAN ADDENDUM")){DocType="T0155";}
		else if(DocName.contains("LEGAL DOCUMENT")){DocType="T0163";}
		else if(DocName.contains("LOAN AGREEMENT ACROSS LOCATIONS")){DocType="T0179";}
		else if(DocName.contains("LOCKER ACCOUNT OPENING FORM")){DocType="T0182";}
		else if(DocName.contains("LOCKER AGREEMENT")){DocType="T0183";}
		else if(DocName.contains("LOCKER RENT & FEE")){DocType="T0184";}
		else if(DocName.contains("MARINER DECLARATION")){DocType="T0188";}
		else if(DocName.contains("MARRIAGE CERTIFICATE")){DocType="T0190";}
		else if(DocName.contains("MEMORANDUM OF GENERAL PLEDGE")){DocType="T0193";}
		else if(DocName.contains("MID")){DocType="T0195";}
		else if(DocName.contains("MULTIPLE PRODUCT DECLARATION")){DocType="T0200";}
		else if(DocName.contains("NATIONALITY PROOF")){DocType="T0206";}
		else if(DocName.contains("NOMINATION FORM")){DocType="T0214";}
		else if(DocName.contains("NORKOM")){DocType="T0215";}
		else if(DocName.contains("NOTARIZED AFFIDAVIT FOR NAME CHANGE")){DocType="T0216";}
		else if(DocName.contains("NR DECLARATION")){DocType="T0217";}
		else if(DocName.contains("NRI ANNEXURE STATEMENT")){DocType="T0219";}
		else if(DocName.contains("OFFER LETTER")){DocType="T0222";}
		else if(DocName.contains("PDPA")){DocType="T0236";}
		else if(DocName.contains("POA & DEBIT AUTHORISATION")){DocType="T0251";}
		else if(DocName.contains("RECOVERY INSTRUCTION FOR LOCKER RENT")){DocType="T0269";}
		else if(DocName.contains("REIMBURSEMENT FORM ? AOF")){DocType="T0277";}
		else if(DocName.contains("RESIDENT PERMIT")){DocType="T0286";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="T0107";}
		else if(DocName.contains("PAN NO")){DocType="T0227";}
		else if(DocName.contains("PASSPORT")){DocType="T0231";}
		else if(DocName.contains("ANNEXURE - 18 (3IN1 PRODUCT)")){DocType="T0019";}
		else if(DocName.contains("ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)")){DocType="T0020";}
		else if(DocName.contains("ANNEXURE X - SIGNATURE DIFFER")){DocType="T0021";}
		else if(DocName.contains("CKYC FORM")){DocType="T0055";}
		else if(DocName.contains("CLIENT DECLARATION")){DocType="T0057";}
		else if(DocName.contains("CLOSE RELATIVE DECLARATION")){DocType="T0058";}
		else if(DocName.contains("CLOSURE INSTRUCTION")){DocType="T0059";}
		else if(DocName.contains("CONTINOUS DISCHARGE CERTIFICATE")){DocType="T0065";}
		else if(DocName.contains("CRS/ FATCA AOF ANNEXURE")){DocType="T0074";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE")){DocType="T0075";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID")){DocType="T0076";}
		else if(DocName.contains("CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA")){DocType="T0077";}
		else if(DocName.contains("CUSTOMER SERVICE LETTER. ")){DocType="T0078";}
		else if(DocName.contains("DECLARATION")){DocType="T0081";}
		else if(DocName.contains("DEPONENT ID PROOF")){DocType="T0088";}
		else if(DocName.contains("DIVORCE CERTIFICATE/COURT ORDER")){DocType="T0093";}
		else if(DocName.contains("DOB MISMATCH DECLARATION")){DocType="T0094";}
		else if(DocName.contains("REQUEST FOR FIXED DEPOSIT/LIEN")){DocType="T0280";}
		else if(DocName.contains("REQUEST FOR LOCKER")){DocType="T0281";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DECLARATION")){DocType="T0282";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION")){DocType="T0283";}
		else if(DocName.contains("RPI ANNEXURE STATEMENT")){DocType="T0289";}
		else if(DocName.contains("SANCTION LETTER")){DocType="T0295";}
		else if(DocName.contains("SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT")){DocType="T0300";}
		else if(DocName.contains("SIGNATURE CARD")){DocType="T0308";}
		else if(DocName.contains("SIGNATURE PROOF")){DocType="T0309";}
		else if(DocName.contains("SUPPLEMENTAL H/S AGR")){DocType="T0318";}
		else if(DocName.contains("SUPPLEMENTARY DECLARTION")){DocType="T0321";}
		else if(DocName.contains("WORK PERMIT")){DocType="T0350";}
		else if(DocName.contains("CREDIT CARD COPY")){DocType="T0383";}
		else if(DocName.contains("PARTNER?S AUTHORITY LETTER")){DocType="T0384";}
		else if(DocName.contains("DIPLOMAT DECLARATION")){DocType="T0090";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocType="T0025";}
		else if(DocName.contains("TXN INFORMATION DOCUMENT( TID)")){DocType="T0338";}
		else if(DocName.contains("VERNACULAR BOND")){DocType="T0342";}
		else if(DocName.contains("VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH")){DocType="T0343";}
		else if(DocName.contains("VERNACULAR DECLARATION - UNDERSTAND ENGLISH")){DocType="T0344";}
		else if(DocName.contains("CUSTOMER CLARIFICATION E-MAIL")){DocType="T0378";}
		else if(DocName.contains("INTERNAL CLARIFICATION E-MAIL")){DocType="T0379";}
		else if(DocName.contains("BACK VALUE DATE APPROVAL")){DocType="T0351";}
		else if(DocName.contains("2IN1 LINKING FORM")){DocType="T0382";}
		else if(DocName.contains("ACCOUNT OPENING FORM")){DocType="T0003";}
		else if(DocName.contains("ACKNOWLEDGED LETTER")){DocType="T0004";}
		else if(DocName.contains("EMPLOYMENT PROOF")){DocType="T0108";}
		else if(DocName.contains("EXPAT DECLARATION")){DocType="T0110";}
		else if(DocName.contains("VISA")){DocType="T0345";}
		else if(DocName.contains("STAFF DECLARATION")){DocType="T0312";}
		else if(DocName.contains("STATEMENT OF OTHER HOLDING")){DocType="T0315";}
		else if(DocName.contains("AADHAAR ENROLLMENT PROOF")){DocType="T0392";}
		else if(DocName.contains("RATION CARD")){DocType="T0385";}
		else if(DocName.contains("CHEQUE LEAF")){DocType="T0389";}
		else if(DocName.contains("FIR COPY")){DocType="T0390";}
		else if(DocName.contains("CENTRAL BANK AUTHORIZATION LETTER")){DocType="T0391";}
		else if(DocName.contains("FUNDING CHEQUE")){DocType="T0120";}
		else if(DocName.contains("GAZZETTE NOTIFICATION")){DocType="T0122";}
		else if(DocName.contains("GPOA")){DocType="T0126";}
		else if(DocName.contains("GUARDIAN DECLARATION FOR PAN NO UPDATION")){DocType="T0128";}
		else if(DocName.contains("ID")){DocType="T0133";}
		else if(DocName.contains("IID")){DocType="T0142";}


		else if(DocName.contains("IRS FORM 2848")){DocType="T0156";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocType="T0347";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocType="T0050";}
		else if(DocName.contains("FORM W8-BEN")){DocType="T0118";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocType="T0381";}
		else if(DocName.contains("FORM W9")){DocType="T0119";}

		else if(DocName.contains("LOGIN CHECKLIST")){DocType="T0372";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocType="T0010";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocType="T0327";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocType="T0239";}

		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocType="T0103";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocType="T0331";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocType="T0082";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocType="T0387";}
		else if(DocName.contains("PLAN DOCUMENT")){DocType="T0247";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocType="T0068";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocType="T0297";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocType="T0354";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocType="T0310";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocType="T0353";}
		else if(DocName.contains("STATEMENT OF WORK")){DocType="T0316";}
		else if(DocName.contains("PISE SEARCH")){DocType="T0246";}
		else if(DocName.contains("CC WORKSHEET")){DocType="T0046";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocType="T0101";}
		else if(DocName.contains("REFERENCE")){DocType="T0271";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocType="T0299";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocType="T0355";}
		else if(DocName.contains("DIARY NOTE")){DocType="T0376";}

		return DocType;
	}

	public static String setTheDocumentName(String DocName){

		String DocType="";
		if(DocName.contains("PAYSLIP")){DocType="PAYSLIP";}
		else if(DocName.contains("PROOF OF PROPRIETORSHIP")){DocType="PROOF OF PROPRIETORSHIP";}
		else if(DocName.contains("DUMMY DOCUMENT")){DocType="DUMMY DOCUMENT";}
		else if(DocName.contains("PARTNERSHIP DEED")){DocType="PARTNERSHIP DEED";}
		else if(DocName.contains("SERVICE TAX REGISTRATION CERTIFICATE ")){DocType="SERVICE TAX REGISTRATION CERTIFICATE ";}
		else if(DocName.contains("SHOP AND ESTABLISHMENT CERTIFICATE")){DocType="SHOP AND ESTABLISHMENT CERTIFICATE";}
		else if(DocName.contains("TRADE LICENSE")){DocType="TRADE LICENSE";}
		else if(DocName.contains("SALES TAX REGISTRATION CERTIFICATE")){DocType="SALES TAX REGISTRATION CERTIFICATE";}
		else if(DocName.contains("FORM 16")){DocType="FORM 16";}
		else if(DocName.contains("CA REPORT ON INCOME DOCUMENT")){DocType="CA REPORT ON INCOME DOCUMENT";}
		else if(DocName.contains("INCREMENT LETTER")){DocType="INCREMENT LETTER";}
		else if(DocName.contains("DOCUMENT FRAUD VERIFICATION REPORT")){DocType="DOCUMENT FRAUD VERIFICATION REPORT";}
		else if(DocName.contains("1 WAY SMS VERIFICATION REPORT")){DocType="1 WAY SMS VERIFICATION REPORT";}
		else if(DocName.contains("2 WAY SMS VERIFICATION REPORT")){DocType="2 WAY SMS VERIFICATION REPORT";}
		else if(DocName.contains("PERSONAL DISCUSSION VERIFICATION REPORT")){DocType="PERSONAL DISCUSSION VERIFICATION REPORT";}
		else if(DocName.contains("OFFICE VERIFICATION REPORT")){DocType="OFFICE VERIFICATION REPORT";}
		else if(DocName.contains("EMAIL APPROVAL - LEVEL 1")){DocType="EMAIL APPROVAL - LEVEL 1";}
		else if(DocName.contains("HEALTH INSURANCE")){DocType="HEALTH INSURANCE";}
		else if(DocName.contains("INCOME ASSESSMENT")){DocType="INCOME ASSESSMENT";}
		else if(DocName.contains("INT/DIVND LETTER")){DocType="INT/DIVND LETTER";}
		else if(DocName.contains("LABOUR INSURANCE")){DocType="LABOUR INSURANCE";}
		else if(DocName.contains("LIFE INSURANCE")){DocType="LIFE INSURANCE";}
		else if(DocName.contains("OTHER BANK''S STATEMENT")){DocType="OTHER BANK''S STATEMENT";}
		else if(DocName.contains("ANNUAL BONUS LETTER")){DocType="ANNUAL BONUS LETTER";}
		else if(DocName.contains("AUTO INSURANCE")){DocType="AUTO INSURANCE";}
		else if(DocName.contains("BANK LH AUM")){DocType="BANK LH AUM";}
		else if(DocName.contains("BANK STATEMENT  ( SALARIED /SELF EMPLOYED)")){DocType="BANK STATEMENT  ( SALARIED /SELF EMPLOYE";}
		else if(DocName.contains("CREDIT CARD /DEBIT CARD STATEMENT")){DocType="CREDIT CARD /DEBIT CARD STATEMENT";}
		else if(DocName.contains("SHAREHOLDING % DOC")){DocType="SHAREHOLDING % DOC";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="TAX PAID  RECEIPTS";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="EMPLOYMENT CONTRACT LETTER";}
		else if(DocName.contains("HR LETTER")){DocType="HR LETTER";}
		else if(DocName.contains("OFFER LETTER")){DocType="OFFER LETTER";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocType="PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS";}
		else if(DocName.contains("RETIREMENT PROOF")){DocType="RETIREMENT PROOF";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocType="APPOINTMENT LETTER";}
		else if(DocName.contains("UTILITY BILL")){DocType="UTILITY BILL";}
		else if(DocName.contains("ITR DOCUMENT")){DocType="ITR DOCUMENT";}
		else if(DocName.contains("PROFIT & LOSS STATEMENT")){DocType="PROFIT & LOSS STATEMENT";}
		else if(DocName.contains("BALANCE SHEET")){DocType="BALANCE SHEET";}
		else if(DocName.contains("PROFESSIONAL DEGREE CERTIFICATE")){DocType="PROFESSIONAL DEGREE CERTIFICATE";}
		else if(DocName.contains("MCA SITE PRINTOUT")){DocType="MCA SITE PRINTOUT";}
		else if(DocName.contains("LOAN REPAYMENT TRACK")){DocType="LOAN REPAYMENT TRACK";}
		else if(DocName.contains("LOAN REPAYMENT SCHEDULE")){DocType="LOAN REPAYMENT SCHEDULE";}
		else if(DocName.contains("LOAN CLOSURE PROOF")){DocType="LOAN CLOSURE PROOF";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocType="WORK EXPERIENCE PROOF";}
		else if(DocName.contains("PROOF OF BUSINESS CONTINUITY FOR 3YEARS")){DocType="PROOF OF BUSINESS CONTINUITY FOR 3YEARS";}
		else if(DocName.contains("PROPERTY INSURANCE")){DocType="PROPERTY INSURANCE";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocType="PASSING CERTIFICATE";}
		else if(DocName.contains("PASSPORT")){DocType="PASSPORT";}
		else if(DocName.contains("PEP")){DocType="PEP";}
		else if(DocName.contains("AADHAAR")){DocType="AADHAAR";}
		else if(DocName.contains("DRIVING LIC NO")){DocType="DRIVING LIC NO";}
		else if(DocName.contains("EMIRATES ID")){DocType="EMIRATES ID";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocType="FOREIGN PASSPORT";}
		else if(DocName.contains("ID CARD ISSUED BY ELECTORAL OFFICE")){DocType="ID CARD ISSUED BY ELECTORAL OFFICE";}
		else if(DocName.contains("IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="IDENTITY PROOF OF SPOUSE OR CLOSE RELATIVE";}
		else if(DocName.contains("MARK SHEET")){DocType="MARK SHEET";}
		else if(DocName.contains("NADRA")){DocType="NADRA";}
		else if(DocName.contains("NREGA JOB CARD")){DocType="NREGA JOB CARD";}
		else if(DocName.contains("PAN NO")){DocType="PAN NO";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocType="BIRTH CERTIFICATE";}
		else if(DocName.contains("BLACKLIST CHECK")){DocType="BLACKLIST CHECK";}
		else if(DocName.contains("SAR")){DocType="SAR";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocType="SCHOOL LEAVING CERTIFCATE";}
		else if(DocName.contains("SUPPLEMENTARY - ID")){DocType="SUPPLEMENTARY - ID";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocType="TRANSFER CERTIFICATE";}
		else if(DocName.contains("VOTERS ID ")){DocType="VOTERS ID ";}
		else if(DocName.contains("SECONDARY - ID")){DocType="SECONDARY - ID";}
		else if(DocName.contains("CUSTOMER PHOTO")){DocType="CUSTOMER PHOTO";}
		else if(DocName.contains("EMPLOYER /HR CERTIFICATE OF ADDRESS")){DocType="EMPLOYER /HR CERTIFICATE OF ADDRESS";}
		else if(DocName.contains("HR LETTER")){DocType="HR LETTER";}
		else if(DocName.contains("BUSINESS LETTERHEAD")){DocType="BUSINESS LETTERHEAD";}
		else if(DocName.contains("CASH COVERED LETTER ")){DocType="CASH COVERED LETTER ";}
		else if(DocName.contains("SURROGATE SPECIFIC PRODUCT ST/LETTER")){DocType="SURROGATE SPECIFIC PRODUCT ST/LETTER";}
		else if(DocName.contains("CLIENT AUTHORIZATION")){DocType="CLIENT AUTHORIZATION";}
		else if(DocName.contains("SET-OFF LETTER ")){DocType="SET-OFF LETTER ";}
		else if(DocName.contains("SOW")){DocType="SOW";}
		else if(DocName.contains("CERTIFICATE")){DocType="CERTIFICATE";}
		else if(DocName.contains("FOREIGN TIN")){DocType="FOREIGN TIN";}
		else if(DocName.contains("FORM 60")){DocType="FORM 60";}
		else if(DocName.contains("GST/VAT DOCUMENT")){DocType="GST/VAT DOCUMENT";}
		else if(DocName.contains("PAN NO")){DocType="PAN NO";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="TAX PAID  RECEIPTS";}
		else if(DocName.contains("CRS DOCUMENT")){DocType="CRS DOCUMENT";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocType="CRS VALIDATION CHECKLIST";}
		else if(DocName.contains("TAX IDENTIFICATION NUMBER")){DocType="TAX IDENTIFICATION NUMBER";}
		else if(DocName.contains("CANADIAN TAX IDENTIFICATION")){DocType="CANADIAN TAX IDENTIFICATION";}
		else if(DocName.contains("PASSPORT")){DocType="PASSPORT";}
		else if(DocName.contains("VISA")){DocType="VISA";}
		else if(DocName.contains("PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS")){DocType="PERIODIC REVIEW CHECKLIST AND OTHER SUPPORTING DOCUMENTS";}
		else if(DocName.contains("PIO CARD")){DocType="PIO CARD";}
		else if(DocName.contains("POST OFFICE SAVINGS BANK ACCOUNT STATEMENT ")){DocType="POST OFFICE SAVINGS BANK ACCOUNT STATEMENT ";}
		else if(DocName.contains("PROPERTY TAX RECEIPT")){DocType="PROPERTY TAX RECEIPT";}
		else if(DocName.contains("PAN VERIFICATION COPY ")){DocType="PAN VERIFICATION COPY ";}
		else if(DocName.contains("AADHAAR")){DocType="AADHAAR";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="EMPLOYMENT CONTRACT LETTER";}
		else if(DocName.contains("PAN NO")){DocType="PAN NO";}
		else if(DocName.contains("DRIVING LIC NO")){DocType="DRIVING LIC NO";}
		else if(DocName.contains("TRANSFER CERTIFICATE")){DocType="TRANSFER CERTIFICATE";}
		else if(DocName.contains("PASSING CERTIFICATE")){DocType="PASSING CERTIFICATE";}
		else if(DocName.contains("MARK SHEET")){DocType="MARK SHEET";}
		else if(DocName.contains("SCHOOL LEAVING CERTIFCATE")){DocType="SCHOOL LEAVING CERTIFCATE";}
		else if(DocName.contains("BIRTH CERTIFICATE")){DocType="BIRTH CERTIFICATE";}
		else if(DocName.contains("ELECTRICITY BILL")){DocType="ELECTRICITY BILL";}
		else if(DocName.contains("EMBASSY / UNO LETTERS")){DocType="EMBASSY / UNO LETTERS";}
		else if(DocName.contains("FOREIGN PASSPORT")){DocType="FOREIGN PASSPORT";}
		else if(DocName.contains("GAS BILL")){DocType="GAS BILL";}
		else if(DocName.contains("IDENTITY CARD (OTHER NATIONALITY)")){DocType="IDENTITY CARD (OTHER NATIONALIT";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION")){DocType="IDENTITY CARD ISSUED BY AGENCY OF FOREIGN JURISDICTION";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT")){DocType="IDENTITY CARD ISSUED BY GOVERNMENT DEPARTMENT";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS")){DocType="IDENTITY CARD ISSUED BY PUBLIC FINANCIAL INSTITUTIONS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS")){DocType="IDENTITY CARD ISSUED BY PUBLIC SECTOR UNDERTAKINGS";}
		else if(DocName.contains("IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS")){DocType="IDENTITY CARD ISSUED BY SCHEDULED COMMERCIAL BANKS";}
		else if(DocName.contains("INTERNET BILL")){DocType="INTERNET BILL";}
		else if(DocName.contains("LETTER ISSUED BY A GAZETTED OFFICER")){DocType="LETTER ISSUED BY A GAZETTED OFFICER";}
		else if(DocName.contains("LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER")){DocType="LETTER OF ALLOTMENT OF ACCOMMODATION FROM EMPLOYER";}
		else if(DocName.contains("MAINTENANCE BILL")){DocType="MAINTENANCE BILL";}
		else if(DocName.contains("MOBILE BILL")){DocType="MOBILE BILL";}
		else if(DocName.contains("MUNICIPAL TAX RECEIPT")){DocType="MUNICIPAL TAX RECEIPT";}
		else if(DocName.contains("NATIONAL IDENTITY CARD")){DocType="NATIONAL IDENTITY CARD";}
		else if(DocName.contains("NREGA JOB CARD")){DocType="NREGA JOB CARD";}
		else if(DocName.contains("OCI CARD")){DocType="OCI CARD";}
		else if(DocName.contains("ACKNOWLEDGMENT OF RECEIPT OF LETTER,")){DocType="ACKNOWLEDGMENT OF RECEIPT OF LETTER,";}
		else if(DocName.contains("ADDRESS CONFIRMATION THROUGH CIBIL DATA")){DocType="ADDRESS CONFIRMATION THROUGH CIBIL DATA";}
		else if(DocName.contains("ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE")){DocType="ADDRESS PROOF OF SPOUSE OR CLOSE RELATIVE";}
		else if(DocName.contains("CENTRAL POPULATION REGISTER (SMART CARD) ")){DocType="CENTRAL POPULATION REGISTER (SMART CAR";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocType="RENTAL AGREEMENT/SALE? DEED";}
		else if(DocName.contains("RESIDENCE PROOF")){DocType="RESIDENCE PROOF";}
		else if(DocName.contains("RESIDENCE VERIFICATION REPORT")){DocType="RESIDENCE VERIFICATION REPORT";}
		else if(DocName.contains("RESIDENT PERMIT")){DocType="RESIDENT PERMIT";}
		else if(DocName.contains("RESIDENT VERIFICATION REPORT")){DocType="RESIDENT VERIFICATION REPORT";}
		else if(DocName.contains("SUPPLEMENTARY - RESIDENCE PROOF")){DocType="SUPPLEMENTARY - RESIDENCE PROOF";}
		else if(DocName.contains("TELEPHONE BILL")){DocType="TELEPHONE BILL";}
		else if(DocName.contains("VOTERS ID ")){DocType="VOTERS ID ";}
		else if(DocName.contains("WATER BILL")){DocType="WATER BILL";}
		else if(DocName.contains("LETTER ISSUED BY NATIONAL POPULATION REGISTER")){DocType="LETTER ISSUED BY NATIONAL POPULATION REGISTER";}
		else if(DocName.contains("NADRA")){DocType="NADRA";}
		else if(DocName.contains("TAX DEMAND LETTER OR STATEMENT")){DocType="TAX DEMAND LETTER OR STATEMENT";}
		else if(DocName.contains("PENSION OR FAMILY PENSION PAYMENT ORDERS (PPOS)")){DocType="PENSION OR FAMILY PENSION PAYMENT ORDERS (PPO";}
		else if(DocName.contains("ACKNOWLEDGED NOTICE OF INTIMATION ? ORIGINAL")){DocType="ACKNOWLEDGED NOTICE OF INTIMATION ? ORIGINAL";}
		else if(DocName.contains("ADDITIONAL COST LETTER")){DocType="ADDITIONAL COST LETTER";}
		else if(DocName.contains("AFFIDAVIT CERTIFICATE")){DocType="AFFIDAVIT CERTIFICATE";}
		else if(DocName.contains("AFFIDAVIT FROM APPLICANT")){DocType="AFFIDAVIT FROM APPLICANT";}
		else if(DocName.contains("AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT")){DocType="AFFIDAVIT FROM THE APPLICANT REGARDING THE MUT";}
		else if(DocName.contains("AFTER COMPLETION ARCHITECTS CERTIFICATE")){DocType="AFTER COMPLETION ARCHITECTS CERTIFICATE";}
		else if(DocName.contains("AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY")){DocType="AGREEMENT ENTERED BET ALLOTTEE AND SOCIETY";}
		else if(DocName.contains("AGREEMENT LODGED FOR REGN")){DocType="AGREEMENT LODGED FOR REGN";}
		else if(DocName.contains("ALLOTMENT LETTER")){DocType="ALLOTMENT LETTER";}
		else if(DocName.contains("AMENITIES AGREEMENT")){DocType="AMENITIES AGREEMENT";}
		else if(DocName.contains("ANNEXURE Z")){DocType="ANNEXURE Z";}
		else if(DocName.contains("APPLICATION FOR NAME TRANSFER")){DocType="APPLICATION FOR NAME TRANSFER";}
		else if(DocName.contains("APPROVED LAYOUT PLAN")){DocType="APPROVED LAYOUT PLAN";}
		else if(DocName.contains("APPROVED SANCTION PLANS")){DocType="APPROVED SANCTION PLANS";}
		else if(DocName.contains("APPROVED TCP LAYOUT")){DocType="APPROVED TCP LAYOUT";}
		else if(DocName.contains("ARCHITECTS ESTIMATE")){DocType="ARCHITECTS ESTIMATE";}
		else if(DocName.contains("AUTHORISATION LETTER FROM BORROWER ADDRESSED T")){DocType="AUTHORISATION LETTER FROM BORROWER ADDRESSED T";}
		else if(DocName.contains("AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA")){DocType="AUTHORITY LETTER FROM APPLI TO COLLECT ORIGINA";}
		else if(DocName.contains("BACK DEED")){DocType="BACK DEED";}
		else if(DocName.contains("BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR")){DocType="BALANCE TRANSFER DOCUMENTS EXECUTED IN FAVOUR";}
		else if(DocName.contains("BOARD RESOLUTION")){DocType="BOARD RESOLUTION";}
		else if(DocName.contains("BUILDER DECLARATION")){DocType="BUILDER DECLARATION";}
		else if(DocName.contains("BYE LAWS OF SOCIETY")){DocType="BYE LAWS OF SOCIETY";}
		else if(DocName.contains("CA CERTIFICATE FOR DISBURSAL")){DocType="CA CERTIFICATE FOR DISBURSAL";}
		else if(DocName.contains("CERTI (BY TEHSIL OFFICE ) OF INTEKHAB KHATUNI")){DocType="CERTI (BY TEHSIL OFFICE";}
		else if(DocName.contains("CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL")){DocType="CERTIFIED 12 YEARS INTEKHAB KHASRA FROM TEHSIL";}
		else if(DocName.contains("CHAIN DOCUMENTS OF THE PROPERTY.")){DocType="CHAIN DOCUMENTS OF THE PROPERTY.";}
		else if(DocName.contains("CHAIN OF TITLE DOCUMENTS")){DocType="CHAIN OF TITLE DOCUMENTS";}
		else if(DocName.contains("CHALLANS -  RECEIPTS OF PAYMENTS MADE")){DocType="CHALLANS -  RECEIPTS OF PAYMENTS MADE";}
		else if(DocName.contains("COMMENCEMENT CERTIFICATE")){DocType="COMMENCEMENT CERTIFICATE";}
		else if(DocName.contains("CONFIRMATION LETTER FROM PURCHASER")){DocType="CONFIRMATION LETTER FROM PURCHASER";}
		else if(DocName.contains("CONSTRUCTION AGREEMENT")){DocType="CONSTRUCTION AGREEMENT";}
		else if(DocName.contains("CONSTRUCTION PERMISSION")){DocType="CONSTRUCTION PERMISSION";}
		else if(DocName.contains("CONSTRUCTION SCHEDULE")){DocType="CONSTRUCTION SCHEDULE";}
		else if(DocName.contains("CONVERSION CERTIFICATE")){DocType="CONVERSION CERTIFICATE";}
		else if(DocName.contains("CONVEYANCE DEED")){DocType="CONVEYANCE DEED";}
		else if(DocName.contains("CROSS COLLATERAL")){DocType="CROSS COLLATERAL";}
		else if(DocName.contains("CROSS DEFAULT AGREEMENT")){DocType="CROSS DEFAULT AGREEMENT";}
		else if(DocName.contains("DEATH CERTIFICATES")){DocType="DEATH CERTIFICATES";}
		else if(DocName.contains("DECLARATION FROM PURCHASER")){DocType="DECLARATION FROM PURCHASER";}
		else if(DocName.contains("DEED OF APARTMENT")){DocType="DEED OF APARTMENT";}
		else if(DocName.contains("DEED OF ASSIGNMENT")){DocType="DEED OF ASSIGNMENT";}
		else if(DocName.contains("DEMAND LETTER FOR CURR DISB")){DocType="DEMAND LETTER FOR CURR DISB";}
		else if(DocName.contains("DEMAND LETTER FROM DDA")){DocType="DEMAND LETTER FROM DDA";}
		else if(DocName.contains("DEVELOPMENT AGREEMENT")){DocType="DEVELOPMENT AGREEMENT";}
		else if(DocName.contains("DISBURSAL SCHEDULE")){DocType="DISBURSAL SCHEDULE";}
		else if(DocName.contains("DIVERSION RENT RECEIPT")){DocType="DIVERSION RENT RECEIPT";}
		else if(DocName.contains("DOC ENSURING OWNERSHIP")){DocType="DOC ENSURING OWNERSHIP";}
		else if(DocName.contains("DOCUMENTS OF THE BUILDER")){DocType="DOCUMENTS OF THE BUILDER";}
		else if(DocName.contains("DRCS APPROVAL")){DocType="DRCS APPROVAL";}
		else if(DocName.contains("RENTAL AGREEMENT/SALE? DEED")){DocType="RENTAL AGREEMENT/SALE? DEED";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY BUYER")){DocType="SALE & PUR AGREEMENT EXEC BY BUYER";}
		else if(DocName.contains("SALE & PUR AGREEMENT EXEC BY SELLER")){DocType="SALE & PUR AGREEMENT EXEC BY SELLER";}
		else if(DocName.contains("SALE AGREEMENT")){DocType="SALE AGREEMENT";}
		else if(DocName.contains("SALE DEED EXECUTED BY BUYER/BORROWER")){DocType="SALE DEED EXECUTED BY BUYER/BORROWER";}
		else if(DocName.contains("SALE DEED EXECUTED BY SELLER")){DocType="SALE DEED EXECUTED BY SELLER";}
		else if(DocName.contains("SANCTION PLANS")){DocType="SANCTION PLANS";}
		else if(DocName.contains("SEARCH REPORT")){DocType="SEARCH REPORT";}
		else if(DocName.contains("SHARE CERTIFICATE BUYER")){DocType="SHARE CERTIFICATE BUYER";}
		else if(DocName.contains("SHARE CERTIFICATE SELLER")){DocType="SHARE CERTIFICATE SELLER";}
		else if(DocName.contains("SUB-LEASE DEED")){DocType="SUB-LEASE DEED";}
		else if(DocName.contains("SURRENDER DEED FROM SOCIETY")){DocType="SURRENDER DEED FROM SOCIETY";}
		else if(DocName.contains("TAX PAID  RECEIPTS")){DocType="TAX PAID  RECEIPTS";}
		else if(DocName.contains("TECHNICAL CUM LEGAL UNDERTAKING")){DocType="TECHNICAL CUM LEGAL UNDERTAKING";}
		else if(DocName.contains("TITLE DEED")){DocType="TITLE DEED";}
		else if(DocName.contains("TRANSFER FORM FOR SHARE CERT")){DocType="TRANSFER FORM FOR SHARE CERT";}
		else if(DocName.contains("TRANSFER LETTER FAV SELLER")){DocType="TRANSFER LETTER FAV SELLER";}
		else if(DocName.contains("TRANSFER LETTER FROM PCNTDA")){DocType="TRANSFER LETTER FROM PCNTDA";}
		else if(DocName.contains("TRANSFER MEMORANDUM IN FAVOR OF PURCHASER")){DocType="TRANSFER MEMORANDUM IN FAVOR OF PURCHASER";}
		else if(DocName.contains("WILL SIGNED BY THE SELLER")){DocType="WILL SIGNED BY THE SELLER";}
		else if(DocName.contains("DDA MORTGAGE -ACK")){DocType="DDA MORTGAGE -ACK";}
		else if(DocName.contains("LIST OF DOCUMENTS HELD WITH HFC ")){DocType="LIST OF DOCUMENTS HELD WITH HFC ";}
		else if(DocName.contains("MEMORANDUM OF ENTRY")){DocType="MEMORANDUM OF ENTRY";}
		else if(DocName.contains("NOC FROM LAND ACQUISITION OFF ( KHASRA PLOT)")){DocType="NOC FROM LAND ACQUISITION OFF ( KHASRA PLO";}
		else if(DocName.contains("RESOLUTION FOR A MORTGAGE PROPERTY")){DocType="RESOLUTION FOR A MORTGAGE PROPERTY";}
		else if(DocName.contains("STAMPED MOE")){DocType="STAMPED MOE";}
		else if(DocName.contains("TRIPATRIATE AGR")){DocType="TRIPATRIATE AGR";}
		else if(DocName.contains("UNDERTAKING FROM SELLER TO HANDOVER DOCS")){DocType="UNDERTAKING FROM SELLER TO HANDOVER DOCS";}
		else if(DocName.contains("VALUATION REPORT")){DocType="VALUATION REPORT";}
		else if(DocName.contains("7/12EXTRACT")){DocType="7/12EXTRACT";}
		else if(DocName.contains("ENCUMBRANCE CERTIFICATE")){DocType="ENCUMBRANCE CERTIFICATE";}
		else if(DocName.contains("FINANCIAL COVENANTS")){DocType="FINANCIAL COVENANTS";}
		else if(DocName.contains("FLAT BUYERS AGR")){DocType="FLAT BUYERS AGR";}
		else if(DocName.contains("EARLIER DOCS OF THE BUILDER")){DocType="EARLIER DOCS OF THE BUILDER";}
		else if(DocName.contains("EARLIER DOCS OF THE SOCIETY")){DocType="EARLIER DOCS OF THE SOCIETY";}
		else if(DocName.contains("STAMP DUTY RECEIPT")){DocType="STAMP DUTY RECEIPT";}
		else if(DocName.contains("FORM 8 & 13")){DocType="FORM 8 & 13";}
		else if(DocName.contains("FORM A + B + REGULARISED PLAN")){DocType="FORM A + B + REGULARISED PLAN";}
		else if(DocName.contains("GIFT DEED")){DocType="GIFT DEED";}
		else if(DocName.contains("GPA BY THE SELLER IN FAVOR OF THE BUYER")){DocType="GPA BY THE SELLER IN FAVOR OF THE BUYER";}
		else if(DocName.contains("GPA SPA AND WILL")){DocType="GPA SPA AND WILL";}
		else if(DocName.contains("GPOA")){DocType="GPOA";}
		else if(DocName.contains("HANDING OVER POSSESSION LETTER TO THE BORROWER")){DocType="HANDING OVER POSSESSION LETTER TO THE BORROWER";}
		else if(DocName.contains("HIRE PURCHASE AGREEMENT")){DocType="HIRE PURCHASE AGREEMENT";}
		else if(DocName.contains("INDEMNITY")){DocType="INDEMNITY";}
		else if(DocName.contains("INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER")){DocType="INDEMNITY GIVEN FOR LOSS OF PROPERTY PAPER";}
		else if(DocName.contains("INDEMNITY SIGNED BY SELLER")){DocType="INDEMNITY SIGNED BY SELLER";}
		else if(DocName.contains("INDENTURE OF SALE")){DocType="INDENTURE OF SALE";}
		else if(DocName.contains("INDEX 2")){DocType="INDEX 2";}
		else if(DocName.contains("INSTRUMENT OF TRANSFER OF LAND")){DocType="INSTRUMENT OF TRANSFER OF LAND";}
		else if(DocName.contains("INTIMATION TO JDA OF MORTGAGE DULY ACK")){DocType="INTIMATION TO JDA OF MORTGAGE DULY ACK";}
		else if(DocName.contains("INTIMATION TO RIICO OF MORTGAGE")){DocType="INTIMATION TO RIICO OF MORTGAGE";}
		else if(DocName.contains("KHATAUNI FOR THE FASLI YEAR")){DocType="KHATAUNI FOR THE FASLI YEAR";}
		else if(DocName.contains("KHATHA DOCUMENT")){DocType="KHATHA DOCUMENT";}
		else if(DocName.contains("LAND OWNERS DEED")){DocType="LAND OWNERS DEED";}
		else if(DocName.contains("LATEST OUTSTANDING LETTER FROM FINANCIER")){DocType="LATEST OUTSTANDING LETTER FROM FINANCIER";}
		else if(DocName.contains("LEASE DEED")){DocType="LEASE DEED";}
		else if(DocName.contains("LEGAL DOCUMENT OF EXPIRED OWNER")){DocType="LEGAL DOCUMENT OF EXPIRED OWNER";}
		else if(DocName.contains("LEGAL OPINION")){DocType="LEGAL OPINION";}
		else if(DocName.contains("LEGAL REPORT")){DocType="LEGAL REPORT";}
		else if(DocName.contains("LETTER FROM BANK TO THE DEVELOPER / BUILDER")){DocType="LETTER FROM BANK TO THE DEVELOPER / BUILDER";}
		else if(DocName.contains("LETTER FROM BORROWER TO THE DEVELOPER / BLDG")){DocType="LETTER FROM BORROWER TO THE DEVELOPER / BLDG";}
		else if(DocName.contains("LETTER FROM SOCIETY")){DocType="LETTER FROM SOCIETY";}
		else if(DocName.contains("LETTER OF OFFER")){DocType="LETTER OF OFFER";}
		else if(DocName.contains("LETTER OF UNDERTAKING")){DocType="LETTER OF UNDERTAKING";}
		else if(DocName.contains("LIEN MARKING LETTER")){DocType="LIEN MARKING LETTER";}
		else if(DocName.contains("LIEN NOTED CERTIFICATE FROM SOCIETY")){DocType="LIEN NOTED CERTIFICATE FROM SOCIETY";}
		else if(DocName.contains("LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY")){DocType="LIST OF MEMBERS OF SOCIETY CERTIFIED BY SECY";}
		else if(DocName.contains("LOAN CLOSURE LETTER")){DocType="LOAN CLOSURE LETTER";}
		else if(DocName.contains("LOCATION CERTIFICATE")){DocType="LOCATION CERTIFICATE";}
		else if(DocName.contains("LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION")){DocType="LOU/ MOU/ANNEXURE Z - BUILDER DECLARATION";}
		else if(DocName.contains("MARGIN MONEY RECEIPTS")){DocType="MARGIN MONEY RECEIPTS";}
		else if(DocName.contains("MEMORANDUM OF DEPOSIT OF TITLE DEED ? ORIGINAL")){DocType="MEMORANDUM OF DEPOSIT OF TITLE DEED ? ORIGINAL";}
		else if(DocName.contains("MEMORANDUM OF UNDERTAKING")){DocType="MEMORANDUM OF UNDERTAKING";}
		else if(DocName.contains("MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT")){DocType="MORTGAGE ACKNOWLEDGEMENT LETTER FROM DEVT";}
		else if(DocName.contains("MORTGAGE PERMISSION FROM RHB")){DocType="MORTGAGE PERMISSION FROM RHB";}
		else if(DocName.contains("MP PRAKOSHTHA ADHINIYAM")){DocType="MP PRAKOSHTHA ADHINIYAM";}
		else if(DocName.contains("NA ORDER")){DocType="NA ORDER";}
		else if(DocName.contains("NAME TRANSFER FAV BORROWER")){DocType="NAME TRANSFER FAV BORROWER";}
		else if(DocName.contains("NEW ENGINEERING CONTRACT ")){DocType="NEW ENGINEERING CONTRACT ";}
		else if(DocName.contains("NO DUES CERTIFICATE")){DocType="NO DUES CERTIFICATE";}
		else if(DocName.contains("NOC FROM BDA")){DocType="NOC FROM BDA";}
		else if(DocName.contains("NOC FROM BUILDER / SOCIETY")){DocType="NOC FROM BUILDER / SOCIETY";}
		else if(DocName.contains("NOC TO MORTGAGE")){DocType="NOC TO MORTGAGE";}
		else if(DocName.contains("NOC TO TRANSFER")){DocType="NOC TO TRANSFER";}
		else if(DocName.contains("OCCUPATION CERTIFICATE")){DocType="OCCUPATION CERTIFICATE";}
		else if(DocName.contains("ORIGINAL COMP CERTIFICATE ")){DocType="ORIGINAL COMP CERTIFICATE ";}
		else if(DocName.contains("ORIGINAL INSURANCE CERTIFICATE")){DocType="ORIGINAL INSURANCE CERTIFICATE";}
		else if(DocName.contains("ORIGINAL NOMINATION AGREEMENT")){DocType="ORIGINAL NOMINATION AGREEMENT";}
		else if(DocName.contains("PARTITION DEED")){DocType="PARTITION DEED";}
		else if(DocName.contains("PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS")){DocType="PARTNERSHIP DEED OR MOA/AOA OF DEVELOPERS";}
		else if(DocName.contains("PATTA")){DocType="PATTA";}
		else if(DocName.contains("PAYMENT RECEIPTS FOR LAND")){DocType="PAYMENT RECEIPTS FOR LAND";}
		else if(DocName.contains("PAYMENT SCHEDULE")){DocType="PAYMENT SCHEDULE";}
		else if(DocName.contains("PERMISSION FOR ADMITTING BORROWER AS MEMBER")){DocType="PERMISSION FOR ADMITTING BORROWER AS MEMBER";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO")){DocType="PERMISSION FOR TRANSFER FROM DEVELOPMENT AUTHO";}
		else if(DocName.contains("PERMISSION FOR TRANSFER FROM SOCIETY")){DocType="PERMISSION FOR TRANSFER FROM SOCIETY";}
		else if(DocName.contains("PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY")){DocType="PERPETUAL LEASE DEED BYE LAWS OF THE SOCIETY";}
		else if(DocName.contains("PLANNING PERMIT AND CONSTRUCTION PERMIT")){DocType="PLANNING PERMIT AND CONSTRUCTION PERMIT";}
		else if(DocName.contains("PLOTS ALLOTTED AT CONCESSIONAL RATES")){DocType="PLOTS ALLOTTED AT CONCESSIONAL RATES";}
		else if(DocName.contains("POA")){DocType="POA";}
		else if(DocName.contains("POA DOCS FAV SELLER / BUILDER OR DEVELOPER")){DocType="POA DOCS FAV SELLER / BUILDER OR DEVELOPER";}
		else if(DocName.contains("PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA")){DocType="PORCHA CLASSIFYING LAND FOR NON-MUNCIPAL / GRA";}
		else if(DocName.contains("POSSESSION CERTIFICATE")){DocType="POSSESSION CERTIFICATE";}
		else if(DocName.contains("POSSESSION LETTER FROM RHB")){DocType="POSSESSION LETTER FROM RHB";}
		else if(DocName.contains("PREVIOUS AGREEMENT LODGED FOR REGISTRATION")){DocType="PREVIOUS AGREEMENT LODGED FOR REGISTRATION";}
		else if(DocName.contains("PREVIOUS PARTY SHARE CERTIFICATE")){DocType="PREVIOUS PARTY SHARE CERTIFICATE";}
		else if(DocName.contains("PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN")){DocType="PREVIOUS SALE AGREEMENT / BACK DEED / CHAIN";}
		else if(DocName.contains("PROOF OD AGRICULTURAL LAND")){DocType="PROOF OD AGRICULTURAL LAND";}
		else if(DocName.contains("PROOF OF BASIS OF OWNERSHIP")){DocType="PROOF OF BASIS OF OWNERSHIP";}
		else if(DocName.contains("PROOF OF CUSTOMER EQUITY")){DocType="PROOF OF CUSTOMER EQUITY";}
		else if(DocName.contains("PROOF OF DISCHARGE OF MORTGAGE")){DocType="PROOF OF DISCHARGE OF MORTGAGE";}
		else if(DocName.contains("PROOF OF PROPERTY UNDER JURISDICTION")){DocType="PROOF OF PROPERTY UNDER JURISDICTION";}
		else if(DocName.contains("PROPERTY CARD")){DocType="PROPERTY CARD";}
		else if(DocName.contains("RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC")){DocType="RE-ALLOTMENT LETTER IN CASE OF REGULARISED SOC";}
		else if(DocName.contains("RECTIFICATION DEED")){DocType="RECTIFICATION DEED";}
		else if(DocName.contains("REGISTERED AGREEMENT TO SELL")){DocType="REGISTERED AGREEMENT TO SELL";}
		else if(DocName.contains("REGISTERED MORTGAGE DEED")){DocType="REGISTERED MORTGAGE DEED";}
		else if(DocName.contains("REGISTERED SALE DEED")){DocType="REGISTERED SALE DEED";}
		else if(DocName.contains("REGISTERED TRANSFER DEED")){DocType="REGISTERED TRANSFER DEED";}
		else if(DocName.contains("REGISTRATION RECEIPT")){DocType="REGISTRATION RECEIPT";}
		else if(DocName.contains("RENT RECEIPT FOR LEASEHOLD PLOT")){DocType="RENT RECEIPT FOR LEASEHOLD PLOT";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocType="CERTIFICATE OF LOSS OF US NATIONALITY";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocType="W9 VALIDATION CHECKLIST";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocType="DECLARATION FROM DIPLOMATS / SOVEREIGNERS";}
		else if(DocName.contains("IRS FORM 2848")){DocType="IRS FORM 2848";}
		else if(DocName.contains("FORM W8-BEN")){DocType="FORM W8-BEN";}
		else if(DocName.contains("FORM W9")){DocType="FORM W9";}
		else if(DocName.contains("CRS VALIDATION CHECKLIST")){DocType="CRS VALIDATION CHECKLIST";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocType="ADVERSE MEDIA ASSESSMENT FORM";}
		else if(DocName.contains("REFERENCE")){DocType="REFERENCE";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocType="CORROBORATION OF SOW";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocType="DECLARATION FROM OVERSEAS RM";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocType="SANCTIONS ADVICE FORM";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocType="SCHEDULED BANK STATISTICS";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocType="SOI/SOW CHECKLIST";}
		else if(DocName.contains("STATEMENT OF WORK")){DocType="STATEMENT OF WORK";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocType="TAX RISK ASSESSMENT QUESTIONNAIRE";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocType="TRANSACTION INFORMATION";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocType="UNCLEAR DOCUMENT";}
		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocType="ELIGIBILITY CALCULATION PRINTOUT";}
		else if(DocName.contains("LOGIN CHECKLIST")){DocType="LOGIN CHECKLIST";}
		else if(DocName.contains("DIARY NOTE")){DocType="DIARY NOTE";}
		else if(DocName.contains("NAME SCREENING RESOLUTION EVIDENCE")){DocType="NAME SCREENING RESOLUTION EVIDENCE";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocType="CORROBORATION DOCUMENT(";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocType="INTERNET SEARCH EVIDENCE";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocType="CDD APPROVAL EMAIL(";}
		else if(DocName.contains("WORK EXPERIENCE PROOF")){DocType="WORK EXPERIENCE PROOF";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocType="ECIB/DATA CHECK";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocType="PEP ASSESSMENT FORM";}
		else if(DocName.contains("PISE SEARCH")){DocType="PISE SEARCH";}
		else if(DocName.contains("PLAN DOCUMENT")){DocType="PLAN DOCUMENT";}
		else if(DocName.contains("CC WORKSHEET")){DocType="CC WORKSHEET";}
		else if(DocName.contains("IRANIAN ADDENDUM")){DocType="IRANIAN ADDENDUM";}
		else if(DocName.contains("LEGAL DOCUMENT")){DocType="LEGAL DOCUMENT";}
		else if(DocName.contains("LOAN AGREEMENT ACROSS LOCATIONS")){DocType="LOAN AGREEMENT ACROSS LOCATIONS";}
		else if(DocName.contains("LOCKER ACCOUNT OPENING FORM")){DocType="LOCKER ACCOUNT OPENING FORM";}
		else if(DocName.contains("LOCKER AGREEMENT")){DocType="LOCKER AGREEMENT";}
		else if(DocName.contains("LOCKER RENT & FEE")){DocType="LOCKER RENT & FEE";}
		else if(DocName.contains("MARINER DECLARATION")){DocType="MARINER DECLARATION";}
		else if(DocName.contains("MARRIAGE CERTIFICATE")){DocType="MARRIAGE CERTIFICATE";}
		else if(DocName.contains("MEMORANDUM OF GENERAL PLEDGE")){DocType="MEMORANDUM OF GENERAL PLEDGE";}
		else if(DocName.contains("MID")){DocType="MID";}
		else if(DocName.contains("MULTIPLE PRODUCT DECLARATION")){DocType="MULTIPLE PRODUCT DECLARATION";}
		else if(DocName.contains("NATIONALITY PROOF")){DocType="NATIONALITY PROOF";}
		else if(DocName.contains("NOMINATION FORM")){DocType="NOMINATION FORM";}
		else if(DocName.contains("NORKOM")){DocType="NORKOM";}
		else if(DocName.contains("NOTARIZED AFFIDAVIT FOR NAME CHANGE")){DocType="NOTARIZED AFFIDAVIT FOR NAME CHANGE";}
		else if(DocName.contains("NR DECLARATION")){DocType="NR DECLARATION";}
		else if(DocName.contains("NRI ANNEXURE STATEMENT")){DocType="NRI ANNEXURE STATEMENT";}
		else if(DocName.contains("OFFER LETTER")){DocType="OFFER LETTER";}
		else if(DocName.contains("PDPA")){DocType="PDPA";}
		else if(DocName.contains("POA & DEBIT AUTHORISATION")){DocType="POA & DEBIT AUTHORISATION";}
		else if(DocName.contains("RECOVERY INSTRUCTION FOR LOCKER RENT")){DocType="RECOVERY INSTRUCTION FOR LOCKER RENT";}
		else if(DocName.contains("REIMBURSEMENT FORM ? AOF")){DocType="REIMBURSEMENT FORM ? AOF";}
		else if(DocName.contains("RESIDENT PERMIT")){DocType="RESIDENT PERMIT";}
		else if(DocName.contains("EMPLOYMENT CONTRACT LETTER")){DocType="EMPLOYMENT CONTRACT LETTER";}
		else if(DocName.contains("PAN NO")){DocType="PAN NO";}
		else if(DocName.contains("PASSPORT")){DocType="PASSPORT";}
		else if(DocName.contains("ANNEXURE - 18 (3IN1 PRODUCT)")){DocType="ANNEXURE - 18 (3IN1 PRODUC";}
		else if(DocName.contains("ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARED)")){DocType="ANNEXURE - 2 FOR SPECIAL CUSTOMER (VISUALLY IMPARE";}
		else if(DocName.contains("ANNEXURE X - SIGNATURE DIFFER")){DocType="ANNEXURE X - SIGNATURE DIFFER";}
		else if(DocName.contains("CKYC FORM")){DocType="CKYC FORM";}
		else if(DocName.contains("CLIENT DECLARATION")){DocType="CLIENT DECLARATION";}
		else if(DocName.contains("CLOSE RELATIVE DECLARATION")){DocType="CLOSE RELATIVE DECLARATION";}
		else if(DocName.contains("CLOSURE INSTRUCTION")){DocType="CLOSURE INSTRUCTION";}
		else if(DocName.contains("CONTINOUS DISCHARGE CERTIFICATE")){DocType="CONTINOUS DISCHARGE CERTIFICATE";}
		else if(DocName.contains("CRS/ FATCA AOF ANNEXURE")){DocType="CRS/ FATCA AOF ANNEXURE";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE")){DocType="CUSTOMER DECLARATION FOR NAME MISMATCH / NAME CAPTURE";}
		else if(DocName.contains("CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID")){DocType="CUSTOMER DECLARATION FOR NOT HAVING THE EMAIL ID";}
		else if(DocName.contains("CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA")){DocType="CUSTOMER DECLATION FOR UNDISCLOSED OR MISMATCH DATA";}
		else if(DocName.contains("CUSTOMER SERVICE LETTER. ")){DocType="CUSTOMER SERVICE LETTER. ";}
		else if(DocName.contains("DECLARATION")){DocType="DECLARATION";}
		else if(DocName.contains("DEPONENT ID PROOF")){DocType="DEPONENT ID PROOF";}
		else if(DocName.contains("DIVORCE CERTIFICATE/COURT ORDER")){DocType="DIVORCE CERTIFICATE/COURT ORDER";}
		else if(DocName.contains("DOB MISMATCH DECLARATION")){DocType="DOB MISMATCH DECLARATION";}
		else if(DocName.contains("REQUEST FOR FIXED DEPOSIT/LIEN")){DocType="REQUEST FOR FIXED DEPOSIT/LIEN";}
		else if(DocName.contains("REQUEST FOR LOCKER")){DocType="REQUEST FOR LOCKER";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DECLARATION")){DocType="RESIDENCE FOREIGN CURRENCY DECLARATION";}
		else if(DocName.contains("RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION")){DocType="RESIDENCE FOREIGN CURRENCY DOMESTIC DECLARATION";}
		else if(DocName.contains("RPI ANNEXURE STATEMENT")){DocType="RPI ANNEXURE STATEMENT";}
		else if(DocName.contains("SANCTION LETTER")){DocType="SANCTION LETTER";}
		else if(DocName.contains("SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT")){DocType="SCHOLARSHIP CERTIFICATE FOR BSBDA PRODUCT";}
		else if(DocName.contains("SIGNATURE CARD")){DocType="SIGNATURE CARD";}
		else if(DocName.contains("SIGNATURE PROOF")){DocType="SIGNATURE PROOF";}
		else if(DocName.contains("SUPPLEMENTAL H/S AGR")){DocType="SUPPLEMENTAL H/S AGR";}
		else if(DocName.contains("SUPPLEMENTARY DECLARTION")){DocType="SUPPLEMENTARY DECLARTION";}
		else if(DocName.contains("WORK PERMIT")){DocType="WORK PERMIT";}
		else if(DocName.contains("CREDIT CARD COPY")){DocType="CREDIT CARD COPY";}
		else if(DocName.contains("PARTNER?S AUTHORITY LETTER")){DocType="PARTNER?S AUTHORITY LETTER";}
		else if(DocName.contains("DIPLOMAT DECLARATION")){DocType="DIPLOMAT DECLARATION";}
		else if(DocName.contains("APPOINTMENT LETTER")){DocType="APPOINTMENT LETTER";}
		else if(DocName.contains("TXN INFORMATION DOCUMENT( TID)")){DocType="TXN INFORMATION DOCUMENT( TI";}
		else if(DocName.contains("VERNACULAR BOND")){DocType="VERNACULAR BOND";}
		else if(DocName.contains("VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH")){DocType="VERNACULAR DECLARATION - DOESNOT UNDERSTAND ENGLISH";}
		else if(DocName.contains("VERNACULAR DECLARATION - UNDERSTAND ENGLISH")){DocType="VERNACULAR DECLARATION - UNDERSTAND ENGLISH";}
		else if(DocName.contains("CUSTOMER CLARIFICATION E-MAIL")){DocType="CUSTOMER CLARIFICATION E-MAIL";}
		else if(DocName.contains("INTERNAL CLARIFICATION E-MAIL")){DocType="INTERNAL CLARIFICATION E-MAIL";}
		else if(DocName.contains("BACK VALUE DATE APPROVAL")){DocType="BACK VALUE DATE APPROVAL";}
		else if(DocName.contains("2IN1 LINKING FORM")){DocType="2IN1 LINKING FORM";}
		else if(DocName.contains("ACCOUNT OPENING FORM")){DocType="ACCOUNT OPENING FORM";}
		else if(DocName.contains("ACKNOWLEDGED LETTER")){DocType="ACKNOWLEDGED LETTER";}
		else if(DocName.contains("EMPLOYMENT PROOF")){DocType="EMPLOYMENT PROOF";}
		else if(DocName.contains("EXPAT DECLARATION")){DocType="EXPAT DECLARATION";}
		else if(DocName.contains("VISA")){DocType="VISA";}
		else if(DocName.contains("STAFF DECLARATION")){DocType="STAFF DECLARATION";}
		else if(DocName.contains("STATEMENT OF OTHER HOLDING")){DocType="STATEMENT OF OTHER HOLDING";}
		else if(DocName.contains("AADHAAR ENROLLMENT PROOF")){DocType="AADHAAR ENROLLMENT PROOF";}
		else if(DocName.contains("RATION CARD")){DocType="RATION CARD";}
		else if(DocName.contains("CHEQUE LEAF")){DocType="CHEQUE LEAF";}
		else if(DocName.contains("FIR COPY")){DocType="FIR COPY";}
		else if(DocName.contains("CENTRAL BANK AUTHORIZATION LETTER")){DocType="CENTRAL BANK AUTHORIZATION LETTER";}
		else if(DocName.contains("FUNDING CHEQUE")){DocType="FUNDING CHEQUE";}
		else if(DocName.contains("GAZZETTE NOTIFICATION")){DocType="GAZZETTE NOTIFICATION";}
		else if(DocName.contains("GPOA")){DocType="GPOA";}
		else if(DocName.contains("GUARDIAN DECLARATION FOR PAN NO UPDATION")){DocType="GUARDIAN DECLARATION FOR PAN NO UPDATION";}
		else if(DocName.contains("ID")){DocType="ID";}
		else if(DocName.contains("IID")){DocType="IID";}

		else if(DocName.contains("IRS FORM 2848")){DocType="IRS FORM 2848";}
		else if(DocName.contains("W9 VALIDATION CHECKLIST")){DocType="W9 VALIDATION CHECKLIST";}
		else if(DocName.contains("CERTIFICATE OF LOSS OF US NATIONALITY")){DocType="CERTIFICATE OF LOSS OF US NATIONALITY";}
		else if(DocName.contains("FORM W8-BEN")){DocType="FORM W8-BEN";}
		else if(DocName.contains("DECLARATION FROM DIPLOMATS / SOVEREIGNERS")){DocType="DECLARATION FROM DIPLOMATS / SOVEREIGNERS";}
		else if(DocName.contains("FORM W9")){DocType="FORM W9";}

		else if(DocName.contains("LOGIN CHECKLIST")){DocType="LOGIN CHECKLIST";}
		else if(DocName.contains("ADVERSE MEDIA ASSESSMENT FORM")){DocType="ADVERSE MEDIA ASSESSMENT FORM";}
		else if(DocName.contains("TAX RISK ASSESSMENT QUESTIONNAIRE")){DocType="TAX RISK ASSESSMENT QUESTIONNAIRE";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocType="PEP ASSESSMENT FORM";}
		else if(DocName.contains("PEP ASSESSMENT FORM")){DocType="PEP ASSESSMENT FORM";}

		else if(DocName.contains("ELIGIBILITY CALCULATION PRINTOUT")){DocType="ELIGIBILITY CALCULATION PRINTOUT";}
		else if(DocName.contains("TRANSACTION INFORMATION")){DocType="TRANSACTION INFORMATION";}
		else if(DocName.contains("DECLARATION FROM OVERSEAS RM")){DocType="DECLARATION FROM OVERSEAS RM";}
		else if(DocName.contains("UNCLEAR DOCUMENT")){DocType="UNCLEAR DOCUMENT";}
		else if(DocName.contains("PLAN DOCUMENT")){DocType="PLAN DOCUMENT";}
		else if(DocName.contains("CORROBORATION OF SOW")){DocType="CORROBORATION OF SOW";}
		else if(DocName.contains("SANCTIONS ADVICE FORM")){DocType="SANCTIONS ADVICE FORM";}
		else if(DocName.contains("INTERNET SEARCH EVIDENCE")){DocType="INTERNET SEARCH EVIDENCE";}
		else if(DocName.contains("SOI/SOW CHECKLIST")){DocType="SOI/SOW CHECKLIST";}
		else if(DocName.contains("CORROBORATION DOCUMENT(S) FOR SOI AND SOW")){DocType="CORROBORATION DOCUMENT(";}
		else if(DocName.contains("STATEMENT OF WORK")){DocType="STATEMENT OF WORK";}
		else if(DocName.contains("PISE SEARCH")){DocType="PISE SEARCH";}
		else if(DocName.contains("CC WORKSHEET")){DocType="CC WORKSHEET";}
		else if(DocName.contains("ECIB/DATA CHECK")){DocType="ECIB/DATA CHECK";}
		else if(DocName.contains("REFERENCE")){DocType="REFERENCE";}
		else if(DocName.contains("SCHEDULED BANK STATISTICS")){DocType="SCHEDULED BANK STATISTICS";}
		else if(DocName.contains("CDD APPROVAL EMAIL(S)")){DocType="CDD APPROVAL EMAIL(";}
		else if(DocName.contains("DIARY NOTE")){DocType="DIARY NOTE";}


		return DocType;
	}




	public static String retriveDocumentCategoryCode(String DBDocumentCategory)
	{
		String DocCatCode="";
		String DocumentCategory=DBUtils.readColumnWithRowIDNew(DBDocumentCategory, GetCase.scenarioID);
		if(DocumentCategory.contains("CLIENT ID")){DocCatCode="R0001";}
		else if(DocumentCategory.contains("CLIENT TAX DOCUMENTS")){DocCatCode="R0002";}
		else if(DocumentCategory.contains("FATCA DOCUMENTS")){DocCatCode="R0003";}
		else if(DocumentCategory.contains("CLIENT VERIFICATION DOCUMENTS")){DocCatCode="R0004";}
		else if(DocumentCategory.contains("CLIENT CREDIT ASSESSMENT DOCUMENTS")){DocCatCode="R0005";}
		else if(DocumentCategory.contains("PRODUCT")){DocCatCode="R0006";}
		else if(DocumentCategory.contains("CLIENT SERVICING DOCUMENTS")){DocCatCode="R0007";}
		else if(DocumentCategory.contains("COLLATERAL DOCUMENTS")){DocCatCode="R0008";}
		else if(DocumentCategory.contains("INTERNAL DOCUMENTS")){DocCatCode="R0009";}
		else{System.out.println("Not a Valid Category Document");}

		System.out.println("DocumentCategory Code for "+ DocumentCategory+" is :"+DocCatCode);
		return DocCatCode;
	}






	@Given("^Process the ACD WB Details '(.*)'$")
	public static void processTheNextWorkBasket(String WorkbasketName) throws Throwable{

		/*String WorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();

		logger.info("Current Workbasket : "+WorkBasket);*/

		/* String[] WBName = WorkbasketName.split("/");
		 for(String workName: WBName){
		  workName = workName.trim();*/

		switch(WorkbasketName){

			case "DeDupe":
				String str=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				//WorkbasketName= ACDRequestGen.processTheNextWorkBasket(WorkbasketName);
				if(!str.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "NorkomWorkBasket":

				String str1=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str1.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}

				break;

			case "FullCheckerReview":

				String str2=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str2.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;
			case "NegativeProbableWB":
				String str3=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str3.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;


			case "CDD Reviewer":
				String str4=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str4.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "FraudRiskCheck":
				String str5=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str5.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;
			case "CreditCheckChecker":
				String str6=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str6.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;
			case "InternalVerificationWB":
				String str7=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str7.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "OffersWB":
				String str8=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str8.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "RMSupervisorWB":
				String str9=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str9.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "CreditInitiationWB":
				String str10=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str10.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "CIException":
				String str11=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str11.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "EDD Reviewer":
				String str12=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str12.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "MEDD Reviewer":
				String str13=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str13.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "FrontlineReferralWB":
				String str14=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str14.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "PriceEscalationL3WB":
				String str15=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str15.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;

			case "PriceEscalationWB":
				String str16=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str16.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;
			case "Exceptions":
				String str17=WorkbasketName;
				callGetCaseApi(WorkbasketName);
				WorkbasketName= promoteCaseAPI(WorkbasketName);

				if(!str17.equalsIgnoreCase(WorkbasketName)){
					processTheNextWorkBasket(WorkbasketName);
				}
				break;
			default:
				logger.info("WorkBasket Name not match any case: "+ WorkbasketName);
		}
		// }

	}




}
