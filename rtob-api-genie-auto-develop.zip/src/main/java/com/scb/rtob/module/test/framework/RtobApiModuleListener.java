package com.scb.rtob.module.test.framework;

import com.standardchartered.genie.GenieRuntime;
import com.standardchartered.genie.module.BaseGenieListener;

public class RtobApiModuleListener extends BaseGenieListener {

    private final GenieRuntime runtime;

    public RtobApiModuleListener(GenieRuntime runtime) {
        this.runtime = runtime;
    }

}
