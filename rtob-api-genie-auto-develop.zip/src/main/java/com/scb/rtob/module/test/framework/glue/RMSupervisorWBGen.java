package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.DedupSetValue;
import com.scb.rtob.module.test.framework.utils.RMSupervisorSetValue;

import cucumber.api.java.en.Given;


 	/************************************@Author: Vaka Ramakrishna***************************************/															 	  

public class RMSupervisorWBGen {
	
	static String fdcScenarioID = "1";
	
	public static Logger logger = Logger.getLogger(RMSupervisorWBGen.class);
	public static JSONObject jsonReq;
	
	/**************************************************************************************************
	 * Function to read,parse json file and authenticate.
	 * And Returns Authenticated application by logging in.
	 * @throws Throwable 
	 **************************************************************************************************/
	@Given("^Call the PromoteCase api for RMSupervisor$")
	public static void promoteRMSupervisor() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader(GetCase.envmap.get("RMSupervisorWB_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueRMSupervisor();		
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		/****************************Authentication Part Starts****************************************/	
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_RMSuperVisor"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	

	/**************************************************************************************************
	 * Function to check if application has moved from RM Supervisor to Next WorkBasket.
	 * And Returns if application has moved to Next WorkBasket
	 * @throws Throwable
	 **************************************************************************************************/
	@Given("^validate if the application moved from RM Supervisor to Next WorkBasket$")
	public static void validateWorkbasketDedup() throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")))
		{
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+" Becase of RM supervisor is selected Decline Appeal");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket").toString());
			Assert.assertTrue(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")));
			
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker")))
		{			
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+": Application is in SYSTEM WAIT");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket").toString());
			Assert.assertTrue("Application didn't move to System wait", currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_FraudRiskChecker")));
		}
		else
		{
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+": Does Not Matches with Expected Workbasket");
			Assert.assertFalse("Current Workbasket : Does Not Matches with Expected Workbasket", false);
		}
	}

	/**************************************************************************************************
		 * Function to modify details by promoting via json file.
		 * And Returns application with updated data in RMSupervisor WorkBasket.
		 * @throws ClassNotFoundException, SQLException, IOException 
		 **************************************************************************************************/
	public static void setValueRMSupervisor() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("acdquery");
		
		RMSupervisorSetValue.setJSON(jsonReq);
		
		switch(fdcScenarioID){
		
			case "1":
				
				RMSupervisorSetValue.setContent();
				
				break;
				
			case "2":
				
			case "3":
				
			case "4":
				
				
		}
		
		
	}

}
