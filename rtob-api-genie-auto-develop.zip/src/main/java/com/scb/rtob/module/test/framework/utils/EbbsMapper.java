package com.scb.rtob.module.test.framework.utils;

import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

public class EbbsMapper {
	
	public static Logger logger = Logger.getLogger(EbbsMapper.class);
	
	private static HashMap<String, String> ebbsmapper = new HashMap<String, String>();

	public static void main(String[] args) {
		setEbbsMapper();
		eBBSCompareWithTestdata();
	}

	public static void eBBSCompareWithTestdata() {

		String result=null;
        for (Entry<String, String> entry : ebbsmapper.entrySet()) {
        	
        	System.out.println("**************");
        	System.out.println("Field : "+entry.getKey());
        	
        	try{
        		
        		System.out.println("Test Data  : "+DBUtils.testdatamap.get(0).get(entry.getKey()));
            	System.out.println("Ebbs value : "+DBUtils.eBBstestdatamap.get(0).get(entry.getValue()));
            	System.out.println("Result : "+DBUtils.testdatamap.get(0).get(entry.getKey()).toString()
            		         	  .equalsIgnoreCase(DBUtils.eBBstestdatamap.get(0).get(entry.getValue()).toString()));	
        	}
        	
        	catch(NullPointerException NPE){
        		
        		if(DBUtils.eBBstestdatamap.get(0).containsKey(entry.getValue())){	
        			System.out.println("Field values are NULL");
        		}
        		else
        			System.out.println("Field is not present in EBBS");        		
        		
        	}
        	
        	
        	
        	System.out.println("**************"); 	

        }
	}

	public static void setEbbsMapper() {
		
		ebbsmapper.put("First_Name", "FIRSTNAME");
		ebbsmapper.put("Middle_Name", "MIDDLENAME");
		ebbsmapper.put("First_Name", "FIRSTNAME");
		ebbsmapper.put("Last_Name", "LASTNAME");
		ebbsmapper.put("DOB", "DATEOFBIRTH");
		ebbsmapper.put("Full_Name", "FULLNAME");
		ebbsmapper.put("Nationality_Code1", "NATIONALITYCODE");
		ebbsmapper.put("Country_Of_Birth_Code", "DOMICILECOUNTRY");
		ebbsmapper.put("Residence_Country_Code", "RESIDENTCOUNTRY");
		ebbsmapper.put("ARM_Code", "ARMCODE");
		ebbsmapper.put("Constitution_Code", "CONSTITUTIONCODE");
		ebbsmapper.put("Work_Type", "WORKTYPE");
		ebbsmapper.put("Nature_of_Business", "NATUREOFBUSINESS");
		ebbsmapper.put("Gender", "SEX");
		ebbsmapper.put("X", "Y");
	}
	
	public static String retrieveFromMapper(String columnName){
						return ebbsmapper.get(columnName);
			}

}
