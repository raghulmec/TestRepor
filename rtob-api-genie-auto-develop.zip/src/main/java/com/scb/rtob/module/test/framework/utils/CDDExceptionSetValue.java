package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class CDDExceptionSetValue {
	
	public static Logger logger = Logger.getLogger(CDDExceptionSetValue.class);
	
	private static JSONObject json = CDDReviewer.jsonReq;
	
	static String FullName = null;

	public static void main(String[] args) {
		

	}
	
	public static void setContent(){
	
		
		FullName = DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);

		
		JsonPath.parse(json).set("$.content.Customers[0].Names[0].FirstName",DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Names[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].Names[0].LastName",DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Names[0].MiddleName",DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID));
		
	}
	}
