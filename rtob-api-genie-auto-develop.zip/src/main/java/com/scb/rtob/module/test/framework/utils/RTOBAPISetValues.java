package com.scb.rtob.module.test.framework.utils;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.GetCase;
import com.scb.rtob.module.test.framework.glue.RTOB_API;

public class RTOBAPISetValues {

public static Logger logger = Logger.getLogger(BasicSetValue.class);
	
	private static JSONObject json = RTOB_API.jsonReq;
	static String ShortName =null;
	static String FullName = null;
	static String Coapp1_FullName = null;
	static String coApplicantFullName = null;
	
	
	public static void setDocumentCompanyName(JSONObject jsonReq) throws ClassNotFoundException, SQLException, IOException{
		DBUtils.convertDBtoMap("diquery");
		setJSON(jsonReq);
		setDocumentIndex();
	}
	
	public static void setValueBasic(JSONObject jsonReq) throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		setJSON(jsonReq);
		
				setContent();
				
				setCustomerDetails();
				setCustomerAliasType();
				setMultipleCustomerContactDetails();
				
				setApplicantProductRelationship();
				
				setEmployeementDetails();
				
				setDocumentDetails();
				
				setApplicationDetailsTab();
				
				setPrimaryProductDetailsTab();
				/*if(GetCase.isMultipleProduct){
				setSecondaryProductDetailsTab(1);
				setSecondaryProductDetailsTab(2);
				setSecondaryProductDetailsTab(3);
				setSecondaryProductDetailsTab(4);
				setSecondaryProductDetailsTab(5);
				}*/
				
				
				if(GetCase.isCoApp){
					
					setCoapplicantDetails(1);
					/*setCoapplicantDetails(2);
					setCoapplicantDetails(3);
					setCoapplicantDetails(4);
					setCoapplicantDetailsinProduct();*/
					
				}
		
	}
	
public static void setValueFDCMaker(JSONObject jsonReq) throws ClassNotFoundException, SQLException, IOException{
		
		
		setJSON(jsonReq);
	
		SetCustomerIncomeDocumentDetails();
		setBasicDataCaptureFields_CustomerTab();
		setCustomerAliasType();
		setPrimaryProductDetailsTab();
		setApplicantProductRelationship();
		setApplicationDetailsTab();
		setBasicDataCaptureFields_ProductandApplicationTab();
		setCustomerDetailsForFDCMaker();
		FamilyDetails();
		setCustomerContactsDetails();
		setEmployeementDetailsForFDCMaker();
		//setCustomerDocumentDetailsForFDC();
		setProductDetailsTab();
		setProductMISPAge();
		setAddress();
		setBankuse();
		setCKYCDetails();
		setFatcaInfoDetails();
		
		Eops();
		//FullDataSetValue.moreFinancialSection();
		setInfoCodeDetails();
		if(GetCase.isMultipleProduct){
			//setCustomerDocumentDetailsCoApplicantForFDC();
		setSecondaryProductDetailsTab(1);
		setSecondaryProductDetailsTab(2);
		setSecondaryProductDetailsTab(3);
		setSecondaryProductDetailsTab(4);
		setSecondaryProductDetailsTab(5);
		}	
		if(GetCase.isCoApp){
					

					setCoapplicantDetails(1);
				/*	setCoapplicantDetails(2);
					setCoapplicantDetails(3);
					setCoapplicantDetails(4);*/
							
				}
				
	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}

	public static void setDocumentIndex(){
		JsonPath.parse(json).set("$.content.OCRDocuments[0].CompanyCategoryCode",DBUtils.readColumnWithRowID("CompanyCategoryCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OCRDocuments[0].CompanyCode",DBUtils.readColumnWithRowID("Companycode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OCRDocuments[0].CompanyDesc",DBUtils.readColumnWithRowID("CompanyName", GetCase.scenarioID));
	}
	public static void setContent(){
	
		FullName = DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) + " " +
			   DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) + " " +
			   DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);
		
		Coapp1_FullName = DBUtils.readColumnWithRowID("Coapplicant1 First Name", GetCase.scenarioID) + " " +
				   DBUtils.readColumnWithRowID("Coapplicant1 Middle Name", GetCase.scenarioID) + " " +
				   DBUtils.readColumnWithRowID("Coapplicant1 Last Name", GetCase.scenarioID);
		
		ShortName = DBUtils.readColumnWithRowID("Title", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);
				
		
		JsonPath.parse(json).set("$.content.CustFullName",FullName);
		
	}

	public static void setCustomerDetails(){
		logger.info("setting");
	
		JsonPath.parse(json).set("$.content.Customers[0].Title",DBUtils.readColumnWithRowID("Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DateOfBirth",DBUtils.readColumnWithRowID("DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].FirstName",DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
	
	
		logger.info("Reading from Json File: "+JsonPath.parse(json).read("$.content.Customers[0].FirstName"));
	
		logger.info("GET JSON: " +json.get("$.content.Customers[0].FirstName"));
		logger.info(DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].LastName",DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].MiddleName",DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Country Of Birth Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirth",DBUtils.readColumnWithRowID("Country Of Birth Code", GetCase.scenarioID));
	    JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidence",DBUtils.readColumnWithRowID("Residence Country Code", GetCase.scenarioID));

			//JsonPath.parse(json).set("$.content.Customers[0].ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
	}
	
	
	public static void setCustomerAliasType(){
		
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Alias(es)", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("AliasMiddleName", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant1 Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant1 Aliases", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant1 Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[1].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant1 Alias Middle Name", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasType",DBUtils.readColumnWithRowID("Coapplicant2 Alias Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasNames",DBUtils.readColumnWithRowID("Coapplicant2 Aliases", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasFirstName",DBUtils.readColumnWithRowID("Coapplicant2 Alias First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasLastName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[2].AliasNameInfo[0].AliasMiddleName",DBUtils.readColumnWithRowID("Coapplicant2 Alias Middle Name", GetCase.scenarioID));
		
	}
	
	
	
	

	public static void setMultipleCustomerContactDetails(){
		
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("ISD Code", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[0].pxObjClass","SCB-Data-Contact");
		
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Contact type Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Contact Details1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ISDCode",DBUtils.readColumnWithRowID("ISD Code1", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[1].pxObjClass","SCB-Data-Contact");
		
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactType",DBUtils.readColumnWithRowID("Contact type Code2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactNumber",DBUtils.readColumnWithRowID("Contact Details2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ISDCode",DBUtils.readColumnWithRowID("ISD Code2", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Contacts[2].pxObjClass","SCB-Data-Contact");
		
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code1", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details1", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("ISD Code1", GetCase.scenarioID));
//	
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Contact type Code2", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Contact Details2", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ISDCode",DBUtils.readColumnWithRowID("ISD Code2", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[1].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("ContactType_Classification", GetCase.scenarioID));
	}

	public static void setApplicantProductRelationship(){
	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].RelatedPartyType",DBUtils.readColumnWithRowID("Relationship Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].RelatedPartyType","PRI");
		//Co-app
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[1].FullName",Coapp1_FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[1].RelatedPartyType","SUP");
	
	}
	
	

	public static void setEmployeementDetails(){
	
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Industry",DBUtils.readColumnWithRowID("ISIC Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryDescription",DBUtils.readColumnWithRowID("ISIC Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Occupation Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Occupation Description", GetCase.scenarioID));
	
	}

	public static void setDocumentDetails(){		
	
	
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[2].DocumentName",DBUtils.readColumnWithRowIDNew("Name_of_the_Document_code2", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentNumber",DBUtils.readColumnWithRowID("Document Number1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[2].DocumentNumber",DBUtils.readColumnWithRowIDNew("Document_Number2", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[2].DocumentExpiryDate",DBUtils.readColumnWithRowIDNew("Document_Expiry_Date2", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[4].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[4].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[6].DocumentSignatureDate", DBUtils.readColumnWithRowID("Document Signature Date", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number1", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[1].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date1", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[1].DocumentList[6].DocumentSignatureDate", DBUtils.readColumnWithRowID("Document Signature Date", GetCase.scenarioID)); 

        

	}


	public static void setApplicationDetailsTab(){
			
		JsonPath.parse(json).set("$.content.SrcID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourceID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SalesID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ReferralID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.AcquisitionCode",DBUtils.readColumnWithRowID("Acquisition Channel", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ApplicationBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchCode",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));

	//***************************************Vijay-02082018******************************************
	//	JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
	}

	public static void setPrimaryProductDetailsTab(){
	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[1].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);

	//*******************************************Vijay-02082018******************************************
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("Usage Type", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BundleType",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));		
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[1].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedNameList[0].CCEmbossedName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedNameList[0].RelatedPartyType","PRI");
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedNameList[1].CCEmbossedName",Coapp1_FullName);
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedNameList[1].RelatedPartyType","SUPP1");
		


	}

	public static void setSecondaryProductDetailsTab(int productsequence){
	

		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type"+productsequence, GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductCode",DBUtils.readColumnWithRowID("ProductCode"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory"+productsequence, GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship[0].FullName",FullName);

		
		/*********************************************** TD ********************************************************/
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PLODSpecialRate",DBUtils.readColumnWithRowID("Special Rate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TermPeriod",DBUtils.readColumnWithRowID("TD_Term", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TenureType",DBUtils.readColumnWithRowID("Tenure Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ValueDate",DBUtils.readColumnWithRowID("Value Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountNo",DBUtils.readColumnWithRowID("Fund Account No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeAmount",DBUtils.readColumnWithRowID("Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PaymentMode",DBUtils.readColumnWithRowID("Payment Mode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].InterestFrqcy",DBUtils.readColumnWithRowID("Interest - Frequency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOne",DBUtils.readColumnWithRowID("2-in-1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lien",DBUtils.readColumnWithRowID("Lien", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].NumberOfDeposit",DBUtils.readColumnWithRowID("No of Deposit", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory"+productsequence, GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship[0].FullName",FullName);

	

		
		
	}



	public static void setApplicantProductRelationship(int productsequence, int coapplicantsequence){
		FullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
		   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
		   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
//Product
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship["+coapplicantsequence+"].FullName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship["+coapplicantsequence+"].RelatedPartyType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" RelatedPartyType", GetCase.scenarioID));	
	}

	public static void setCoapplicantDetailsinProduct() {

		setApplicantProductRelationship(1, 1);
		setApplicantProductRelationship(1, 2);
		setApplicantProductRelationship(1, 3);
		setApplicantProductRelationship(1, 4);

		setApplicantProductRelationship(2, 1);
		setApplicantProductRelationship(2, 2);
		setApplicantProductRelationship(2, 3);
		setApplicantProductRelationship(2, 4);

		setApplicantProductRelationship(3, 1);
		setApplicantProductRelationship(3, 2);
		setApplicantProductRelationship(3, 3);
		setApplicantProductRelationship(3, 4);

		setApplicantProductRelationship(4, 1);
		setApplicantProductRelationship(4, 2);
		setApplicantProductRelationship(4, 3);
		setApplicantProductRelationship(4, 4);

		setApplicantProductRelationship(5, 1);
		setApplicantProductRelationship(5, 2);
		setApplicantProductRelationship(5, 3);
		setApplicantProductRelationship(5, 4);
	}

/**
 * @param coapplicantsequence
 */
	public static void setCoapplicantDetails(int coapplicantsequence){
	
	FullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
			   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
			   DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
	
	JsonPath.parse(json).set("$.content.CustFullName",FullName);
	
	//Customer
	
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Title",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Title", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DateOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" DOB", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].EmbossedName",FullName);
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FirstName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",FullName);
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LastName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LegalName",FullName);
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MiddleName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Description", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidence",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Description", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));

//Contact

	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISD Code1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code2", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details2", GetCase.scenarioID));
	//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactTypeClassification",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+"_ContactType_Classification", GetCase.scenarioID));
	
//Employment
	
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Industry",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Description", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+"Occupation Code", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Description", GetCase.scenarioID));

//DocumentsCoapplicant1_Name_of_the_Document_code
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[2].DocumentName",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Name_of_the_Document_code2", GetCase.scenarioID));

	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentNumber",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Document_Number", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentNumber",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Document_Number1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[2].DocumentNumber",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Document_Number2", GetCase.scenarioID));

	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Document_Expiry_Date", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));
	JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[2].DocumentExpiryDate",DBUtils.readColumnWithRowIDNew("Coapplicant"+coapplicantsequence+"_Document_Expiry_Date2", GetCase.scenarioID));

	
}

	/**
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void setCustomerDetailsForFDCMaker() throws ClassNotFoundException, SQLException, IOException{
	
	DBUtils.convertDBtoMap("fdquery");
		
		JsonPath.parse(json).set("$.content.Customers[0].Gender",DBUtils.readColumnWithRowID("Gender", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ConstitutionCode",DBUtils.readColumnWithRowID("Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].InitialFundSrc",DBUtils.readColumnWithRowID("Source(s) of Initial Funding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MaritalStatus",DBUtils.readColumnWithRowID("Marital Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].PlaceOfBirth",DBUtils.readColumnWithRowID("Place of Birth", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Qualification",DBUtils.readColumnWithRowID("Educational Qualification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MarketingPreferences",DBUtils.readColumnWithRowID("Marketing Preferences", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NumberOfDependants",DBUtils.readColumnWithRowID("No. of Dependants", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].TypeOfInitialFund",DBUtils.readColumnWithRowID("TypeOfInitialFunding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ResidenceStatusForAsset",DBUtils.readColumnWithRowID("Residential Status", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].GSTCustomerType",DBUtils.readColumnWithRowID("Customer Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].GSTRegistrationNumber",DBUtils.readColumnWithRowID("GST Registration Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpecificStatus",DBUtils.readColumnWithRowID("Specific status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].AdviceDetailsAddressType",DBUtils.readColumnWithRowID("Advice Detail Address Type", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].InternetBanking",DBUtils.readColumnWithRowID("Online Banking", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].EmbossedName",DBUtils.readColumnWithRowID("Embossed debit card name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MobileBanking",DBUtils.readColumnWithRowID("Mobile Banking", GetCase.scenarioID));
		
		//***************************Ends**********************************//
		

	

}

	public static void setEmployeementDetailsForFDCMaker(){
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmployerRelationshipName",DBUtils.readColumnWithRowID("Employer Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmploymentType",DBUtils.readColumnWithRowID("Work Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.EmpReltnID",DBUtils.readColumnWithRowID("Employee ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.StaffCategory",DBUtils.readColumnWithRowID("Staff Category", GetCase.scenarioID));
	
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IsPayrollCust",DBUtils.readColumnWithRowID("Payroll Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NatureOfBusiness",DBUtils.readColumnWithRowID("Nature of Business", GetCase.scenarioID));
	
		
		//***************************Vijay02082018***************************//
		
		//cc
		JsonPath.parse(json).set("$.content.Customers[0].Employment.AnnualDeclaredIncome",DBUtils.readColumnWithRowID("AnnualDeclaredIncome", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.BusinessEstablishmentDate",DBUtils.readColumnWithRowID("Business Establishment Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Company_Type",DBUtils.readColumnWithRowID("Company Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CompanyName",DBUtils.readColumnWithRowID("Company Name", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].Employment.CompanyType",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CurrentOrgMM",DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.CurrentOrgYY",DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Department",DBUtils.readColumnWithRowID("Department", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Designation",DBUtils.readColumnWithRowID("Designation", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IncorporationCountry",DBUtils.readColumnWithRowID("Incorporation Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IncorporationDate",DBUtils.readColumnWithRowID("Incorporation Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryGroup",DBUtils.readColumnWithRowID("Industry Group Sector", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ModeOfSalary",DBUtils.readColumnWithRowID("Salary Mode", GetCase.scenarioID));
		
		int a = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID))*12;
		int b = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID))*12;
		
		int c = Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Current business/Organization", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID)));
		int d = Integer.parseInt(DBUtils.readColumnWithRowID("No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID)));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NoOfMonthsInCurrentBusinessOrganization",a);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.NoOfMonthsInPreviousBusinessOrganization",b);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.OwnershipType",DBUtils.readColumnWithRowID("Describe Applicant/Ownership Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousEmployerName",DBUtils.readColumnWithRowID("Previous employer name ", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousOrgMM",DBUtils.readColumnWithRowID("No of Months in Previous business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.PreviousOrgYY",DBUtils.readColumnWithRowID("No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.SharePercentage",DBUtils.readColumnWithRowID("% of Share holding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TaxResidencyStatus",DBUtils.readColumnWithRowID("Tax Residency status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TotalExpMM",c);
		JsonPath.parse(json).set("$.content.Customers[0].Employment.TotalExpYY",d);
		

	}

	public static void setDocumentDetailsForFDCMaker(){		
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[4].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[7].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[15].DocumentSignatureDate", DBUtils.readColumnWithRowID("Document Signature Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DocumentList[15].DocumentSignatureDate1", DBUtils.readColumnWithRowID("Document Signature Date1", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentName",DBUtils.readColumnWithRowID("Name of the Document code2", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Document Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[1].DocumentName",DBUtils.readColumnWithRowID("Document Number1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowIDNew("Document_Number2", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].IDDocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Document Expiry Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].VerfDocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowIDNew("Document_Expiry_Date2", GetCase.scenarioID));
		
	}
	

	
	public static void setBasicDataCaptureFields_ProductandApplicationTab() throws ClassNotFoundException, SQLException, IOException{
	
		setApplicantProductRelationship();
		
		JsonPath.parse(json).set("$.content.SrcID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourceID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SalesID",DBUtils.readColumnWithRowID("Sorucing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ReferralID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Referral ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.AcquisitionCode",DBUtils.readColumnWithRowID("Acquisition Channel", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.ApplicationBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchCode",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignCode",DBUtils.readColumnWithRowID("Campaigncode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].IsAccountType",DBUtils.readColumnWithRowID("Account Request Type", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductDescription",DBUtils.readColumnWithRowID("ProductDescription", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[1].ProductCode",DBUtils.readColumnWithRowID("ProductCode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[1].ProductCategory",DBUtils.readColumnWithRowID("ProductCategory", GetCase.scenarioID));
	}
	
	
		
	public static void FamilyDetails(){
		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].MaidenFirstName",DBUtils.readColumnWithRowID("MaidenFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherFirstName",DBUtils.readColumnWithRowID("FatherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherLastName",DBUtils.readColumnWithRowID("FatherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherMiddleName",DBUtils.readColumnWithRowID("FatherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FatherPrefix",DBUtils.readColumnWithRowID("FatherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherFirstName",DBUtils.readColumnWithRowID("MotherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherLastName",DBUtils.readColumnWithRowID("MotherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherMaidenName",DBUtils.readColumnWithRowID("MotherMaidenName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherMiddleName",DBUtils.readColumnWithRowID("MotherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MotherPrefix",DBUtils.readColumnWithRowID("MotherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseFirstName",DBUtils.readColumnWithRowID("SpouseFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseLastName",DBUtils.readColumnWithRowID("SpouseLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpouseMiddleName",DBUtils.readColumnWithRowID("SpouseMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].SpousePrefix",DBUtils.readColumnWithRowID("SpousePrefix", GetCase.scenarioID));
		
		
		//***************************Vijay02082018***************************//
		
		JsonPath.parse(json).set("$.content.Customers[0].NumberOfChildren",DBUtils.readColumnWithRowID("Number of children", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].AgeOfChild",DBUtils.readColumnWithRowID("Age of Child", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].GenderOfChild",DBUtils.readColumnWithRowID("Gender of Child", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].ChildrenDetails[0].NameOfChild",DBUtils.readColumnWithRowID("Name of the Child", GetCase.scenarioID));
		
		//******************************************************************//
		
		
	}
	
	

	public static void setCustomerContactsDetails(){
		JsonPath.parse(json).set("$.content.Customers[0].CustomerContacts[0].ContactType",DBUtils.readColumnWithRowID("Contact type Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CustomerContacts[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CustomerContacts[0].pxObjClass","SCB-FW-AppWorkFlowFW-Data-Contact");
	}
	
	
	
		
	public static void setApplicationDetailsTabForFDCMaker(){
		
	
				
		JsonPath.parse(json).set("$.content.ApplicationInfo.ShortName",ShortName);
	
		//**************************************Vijay-02082018**********************************\
		//JsonPath.parse(json).set("$.content.ApplicationInfo.BranchName",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.ApplicationInfo.DebitCardRequired",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.SourcingCity",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
	
	}
	
	public static void setProductDetailsTab(){
		
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AccountShortNm",ShortName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeAmount",DBUtils.readColumnWithRowID("Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeDate",DBUtils.readColumnWithRowID("Cheque Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeDrawnOn",DBUtils.readColumnWithRowID("Cheque Drawn On", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeNumber",DBUtils.readColumnWithRowID("Cheque Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice", GetCase.scenarioID));

		//*****************************************Vijay-02082018********************************/
		//TD
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeSuspenseAccount",DBUtils.readColumnWithRowID("Cheque suspense Account", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TenureType",DBUtils.readColumnWithRowID("Tenure Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TermPeriod",DBUtils.readColumnWithRowID("TD_Term", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RefAccountCurrency",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
	    JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountCurrency",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MinimumClearingBalance",DBUtils.readColumnWithRowID("Minimum Clearing Balance", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Lien",DBUtils.readColumnWithRowID("Lien", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ValueDate",DBUtils.readColumnWithRowID("Value Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOne",DBUtils.readColumnWithRowID("2-in-1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].TwoInOneCurrency",DBUtils.readColumnWithRowID("2-in-1 Currency", GetCase.scenarioID));		
		//CASA
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("AcquisitionUsage", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CampaignUsage",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ChequeBookRequired",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Currency",DBUtils.readColumnWithRowID("Account Currency Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EmployeeBanking",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].InterestFrqcy",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductBranch",DBUtils.readColumnWithRowID("Application Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].StatementTypeCASA",DBUtils.readColumnWithRowID("Statement Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApplicantProductRelationship[0].FullName",FullName);
		//CC PL
		
		//**************************************@author 1567977 PL-REPAYMENT DETIALS****************************************************************************//
		
		//EDA ON OTHER BANK A/C
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedAmount",DBUtils.readColumnWithRowID("RequestedAmount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].AccountType",DBUtils.readColumnWithRowID("Repayment_Account_Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Repayment_Account_Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentAccountNumber",DBUtils.readColumnWithRowID("Repayment_Account_Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BranchDescription",DBUtils.readColumnWithRowID("", GetCase.scenarioID)); //Repayment-Branch Name
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].DebitType",DBUtils.readColumnWithRowID("Debit_Type", GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Frequency",DBUtils.readColumnWithRowID("Frequency", GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].EffectiveDate",DBUtils.readColumnWithRowID("Effective_Date", GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].ExpiryDate",DBUtils.readColumnWithRowID("Expiry_Date", GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].EDAName",DBUtils.readColumnWithRowID("EDA_Account_holder_Name", GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RepaymentDetails[0].IFSCCode",DBUtils.readColumnWithRowID("IFSC code", GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BankUtilityName",DBUtils.readColumnWithRowID("BankPreUtility_Name", GetCase.scenarioID));	//-- Bank name updated based on IFSC code
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BankSortCode",DBUtils.readColumnWithRowID("Bank_Sort_Code", GetCase.scenarioID));			
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BeneficiaryBankRegionName",DBUtils.readColumnWithRowID("", GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MonthlyRepaymentDueDt",DBUtils.readColumnWithRowID("Monthly_Repayment_Due_Date", GetCase.scenarioID));		

		//PDC-POST DATA CHEQUE
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCTotalChequeNo",DBUtils.readColumnWithRowID("PDCTotal_cheque_No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCTotalChequeValueCurrency",DBUtils.readColumnWithRowID("PDCTotal_Cheque_Value_Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCTotalChequeValue",DBUtils.readColumnWithRowID("PDCCheque_Value", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCChequeDetails[0].PDCChequeValue",DBUtils.readColumnWithRowID("PDCCheque_Value", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCChequeDetails[0].PDCChequeNo",DBUtils.readColumnWithRowID("PDCCheque_No", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCChequeDetails[0].PDCChequeValueCurrency",DBUtils.readColumnWithRowID("PDCTotal_Cheque_Value_Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCChequeDetails[0].PDCEffectiveDate",DBUtils.readColumnWithRowID("PDCEffective_Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PDCChequeDetails[0].PDCExpiryDate",DBUtils.readColumnWithRowID("PDCExpiry_Date", GetCase.scenarioID));

		
		
       //***************************************************@author 1567977 DISBURSEMENT DETAILS******************************************************************//
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode", GetCase.scenarioID));				
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementDetails[0].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode", GetCase.scenarioID));				
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementDetails[0].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BenificiaryBank",DBUtils.readColumnWithRowID("Beneficiary's Bank", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementDetails[0].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AdvanceEMI",DBUtils.readColumnWithRowID("Advance EMI", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementIFSC",DBUtils.readColumnWithRowID("DisbursementIFSC", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DisbursementDetails[0].DisbursementIFSC",DBUtils.readColumnWithRowID("IFSC code - Disbursement", GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].LoanNotes",DBUtils.readColumnWithRowID("FDC_ProdTab_BankUse_LoanNotes", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AmountForDisbursement",DBUtils.readColumnWithRowID("Amount for Disbursement", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ApprovedEffectiveRate",DBUtils.readColumnWithRowID("ApprovedEffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].PLODSpecialRate",DBUtils.readColumnWithRowID("Special Rate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].AssessmentType",DBUtils.readColumnWithRowID("Assessment Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EffectiveRate",DBUtils.readColumnWithRowID("EffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EmployeeBanking",DBUtils.readColumnWithRowID("", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedEffectiveRate",DBUtils.readColumnWithRowID("RequestedEffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].RequestedTenor",DBUtils.readColumnWithRowID("Requested Tenure", GetCase.scenarioID));
		// JsonPath.parse(json).set("$.content.OfferInitial.Products[0].SettlementAccountChoice",DBUtils.readColumnWithRowID("A", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].DrawDownDate",DBUtils.readColumnWithRowID("Drawdown Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].EffectiveRate",DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].CCEmbossedName",DBUtils.readColumnWithRowID("CC_Emboss_Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].BillingCycle",DBUtils.readColumnWithRowID("Billing_Cycle", GetCase.scenarioID));
			
			//CC
		/**********************************@author 1567977:Address section in Products****************************************/
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddrType",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.AddressLine1",DBUtils.readColumnWithRowID("Address Line 1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.AddressLine2",DBUtils.readColumnWithRowID("Address Line 2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.AddressLine3",DBUtils.readColumnWithRowID("Address Line 3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.AddressLine4",DBUtils.readColumnWithRowID("AddressLine4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.CityName",DBUtils.readColumnWithRowID("City", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.Country",DBUtils.readColumnWithRowID("Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.PostalCode",DBUtils.readColumnWithRowID("Zip Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.Type",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.Residence_Type",DBUtils.readColumnWithRowID("Address1_Residence type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ProductAddressInfo.Area",DBUtils.readColumnWithRowID("Area", GetCase.scenarioID));
		
		/*********************************************************************************************************************/
			

		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].ConsolidatedFlag",DBUtils.readColumnWithRowID("Consolidated Flag", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].StatementFlag",DBUtils.readColumnWithRowID("Statement Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].Lez_Code",DBUtils.readColumnWithRowID("Lez Code", GetCase.scenarioID));
		
	}
	
	public static void setSecondaryProductDetailsTabForFDCMaker(int productsequence){
		
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AccountShortNm",ShortName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeAmount",DBUtils.readColumnWithRowID("Amount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeDate",DBUtils.readColumnWithRowID("Cheque Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeDrawnOn",DBUtils.readColumnWithRowID("Cheque Drawn On"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeNumber",DBUtils.readColumnWithRowID("Cheque Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("Fund Account Choice"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DepositAmount",DBUtils.readColumnWithRowID("TD_Deposit_Amount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeSuspenseAccount",DBUtils.readColumnWithRowID("Cheque suspense Account"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TenureType",DBUtils.readColumnWithRowID("Tenure Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TermPeriod",DBUtils.readColumnWithRowID("TD_Term"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RefAccountCurrency",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverChoice",DBUtils.readColumnWithRowID("Roll Over Choice"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RollOverInstruction",DBUtils.readColumnWithRowID("Roll Over Instruction"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountCurrency",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Purpose",DBUtils.readColumnWithRowID("Purpose of account opening"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].MinimumClearingBalance",DBUtils.readColumnWithRowID("Minimum Clearing Balance"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lien",DBUtils.readColumnWithRowID("Lien"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ValueDate",DBUtils.readColumnWithRowID("Value Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOne",DBUtils.readColumnWithRowID("2-in-1"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].TwoInOneCurrency",DBUtils.readColumnWithRowID("2-in-1 Currency"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AcquisitionOrUsageIndicator",DBUtils.readColumnWithRowID("AcquisitionUsage"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CampaignUsage",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ChequeBookRequired",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Currency",DBUtils.readColumnWithRowID("Account Currency Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EmployeeBanking",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].InterestFrqcy",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductBranch",DBUtils.readColumnWithRowID("Application Branch"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].StatementTypeCASA",DBUtils.readColumnWithRowID("Statement Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApplicantProductRelationship[0].FullName",FullName);
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AdvanceEMI",DBUtils.readColumnWithRowID("Advance EMI"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AmountForDisbursement",DBUtils.readColumnWithRowID("Amount for Disbursement"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApprovedEffectiveRate",DBUtils.readColumnWithRowID("ApprovedEffectiveRate"+productsequence, GetCase.scenarioID));
		
		//**************************************@author 1567977 PL-REPAYMENT DETIALS****************************************************************************//

		//EDA ON OTHER BANK A/C
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].RepaymentMode",DBUtils.readColumnWithRowID("Repayment mode"+productsequence, GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedAmount",DBUtils.readColumnWithRowID("RequestedAmount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].AccountType",DBUtils.readColumnWithRowID("Repayment_Account_Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Repayment_Account_Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentAccountNumber",DBUtils.readColumnWithRowID("Repayment_Account_Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BranchDescription",DBUtils.readColumnWithRowID("", GetCase.scenarioID)); //Repayment-Branch Name
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].DebitType",DBUtils.readColumnWithRowID("Debit_Type"+productsequence, GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Frequency",DBUtils.readColumnWithRowID("Frequency"+productsequence, GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].EffectiveDate",DBUtils.readColumnWithRowID("Effective_Date"+productsequence, GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].ExpiryDate",DBUtils.readColumnWithRowID("Expiry_Date"+productsequence, GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].EDAName",DBUtils.readColumnWithRowID("EDA_Account_holder_Name"+productsequence, GetCase.scenarioID)); 
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RepaymentDetails[0].IFSCCode",DBUtils.readColumnWithRowID("IFSC code"+productsequence, GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BankUtilityName",DBUtils.readColumnWithRowID("BankPreUtility_Name"+productsequence, GetCase.scenarioID));	//-- Bank name updated based on IFSC code
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BankSortCode",DBUtils.readColumnWithRowID("Bank_Sort_Code"+productsequence, GetCase.scenarioID));			
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BeneficiaryBankRegionName",DBUtils.readColumnWithRowID("", GetCase.scenarioID));		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].MonthlyRepaymentDueDt",DBUtils.readColumnWithRowID("Monthly_Repayment_Due_Date"+productsequence, GetCase.scenarioID));		

		//PDC-POST DATA CHEQUE
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCTotalChequeNo",DBUtils.readColumnWithRowID("PDCTotal_cheque_No"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCTotalChequeValueCurrency",DBUtils.readColumnWithRowID("PDCTotal_Cheque_Value_Currency"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCTotalChequeValue",DBUtils.readColumnWithRowID("PDCCheque_Value"+productsequence, GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCChequeDetails[0].PDCChequeValue",DBUtils.readColumnWithRowID("PDCCheque_Value"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCChequeDetails[0].PDCChequeNo",DBUtils.readColumnWithRowID("PDCCheque_No"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCChequeDetails[0].PDCChequeValueCurrency",DBUtils.readColumnWithRowID("PDCTotal_Cheque_Value_Currency"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCChequeDetails[0].PDCEffectiveDate",DBUtils.readColumnWithRowID("PDCEffective_Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PDCChequeDetails[0].PDCExpiryDate",DBUtils.readColumnWithRowID("PDCExpiry_Date"+productsequence, GetCase.scenarioID));
			
       //*********************************************************************************************************************************************************************************************************//
	   //***************************************************@author1567977 DISBURSEMENT DETAILS**********************************************************************************************************************//
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode"+productsequence, GetCase.scenarioID));				
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementDetails[0].DrawDownMode",DBUtils.readColumnWithRowID("Disbursement mode"+productsequence, GetCase.scenarioID));				
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementDetails[0].BeneficiaryACNumber",DBUtils.readColumnWithRowID("Beneficiary A/C Number"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BenificiaryBank",DBUtils.readColumnWithRowID("Beneficiary's Bank"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementDetails[0].BenificiaryName",DBUtils.readColumnWithRowID("Beneficiary Name"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AdvanceEMI",DBUtils.readColumnWithRowID("Advance EMI"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementIFSC",DBUtils.readColumnWithRowID("DisbursementIFSC"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementDetails[0].DisbursementIFSC",DBUtils.readColumnWithRowID("IFSC code - Disbursement"+productsequence, GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].LoanNotes",DBUtils.readColumnWithRowID("FDC_ProdTab_BankUse_LoanNotes"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AmountForDisbursement",DBUtils.readColumnWithRowID("Amount for Disbursement"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ApprovedEffectiveRate",DBUtils.readColumnWithRowID("ApprovedEffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].PLODSpecialRate",DBUtils.readColumnWithRowID("Special Rate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].AssessmentType",DBUtils.readColumnWithRowID("Assessment Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EffectiveRate",DBUtils.readColumnWithRowID("EffectiveRate"+productsequence, GetCase.scenarioID));
				
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DisbursementIFSC",DBUtils.readColumnWithRowID("DisbursementIFSC"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EmployeeBanking",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedAmount",DBUtils.readColumnWithRowID("RequestedAmount"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedEffectiveRate",DBUtils.readColumnWithRowID("RequestedEffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].RequestedTenor",DBUtils.readColumnWithRowID("Requested Tenure"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].SettlementAccountChoice",DBUtils.readColumnWithRowID("A"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].DrawDownDate",DBUtils.readColumnWithRowID("Drawdown Date"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].EffectiveRate",DBUtils.readColumnWithRowID("FDC_ProductDetails_EffectiveRate"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].IFSCCode",DBUtils.readColumnWithRowID("IFSC code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CCEmbossedName",DBUtils.readColumnWithRowID("Embossed debit card name"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].BillingCycle",DBUtils.readColumnWithRowID("Billing_Cycle"+productsequence, GetCase.scenarioID));
		
		/**********************************@author 1567977:Address section in Products****************************************/
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.ProductAddrType",DBUtils.readColumnWithRowID("Address1_Residence type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.AddressLine1",DBUtils.readColumnWithRowID("Address Line 1"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.AddressLine2",DBUtils.readColumnWithRowID("Address Line 2"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.AddressLine3",DBUtils.readColumnWithRowID("Address Line 3"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.AddressLine4",DBUtils.readColumnWithRowID("AddressLine4"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.CityName",DBUtils.readColumnWithRowID("City"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.Country",DBUtils.readColumnWithRowID("Country"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.PostalCode",DBUtils.readColumnWithRowID("Zip Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.State",DBUtils.readColumnWithRowID("State"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.Type",DBUtils.readColumnWithRowID("Address Type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.Residence_Type",DBUtils.readColumnWithRowID("Address1_Residence type"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddressInfo.Area",DBUtils.readColumnWithRowID("Area"+productsequence, GetCase.scenarioID));

		/*********************************************************************************************************************/
		
		//JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].ProductAddrType",DBUtils.readColumnWithRowID("Address1_Residence type"+productsequence, GetCase.scenarioID));
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].Lez_Code",DBUtils.readColumnWithRowID("Lez Code"+productsequence, GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products["+productsequence+"].CCEmbossedName",DBUtils.readColumnWithRowID("CC Emboss Name"+productsequence, GetCase.scenarioID));
	
		
		}
	
	
	public static void setProductMISPAge(){
		
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MISPage[0].MISCode",DBUtils.readColumnWithRowID("MIS Code (Prd)", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.OfferInitial.Products[0].MISPage[0].MISValue",DBUtils.readColumnWithRowID("MIS Value (Prd)", GetCase.scenarioID));
	}
	
	





	public static void setAddress(){
		
		

		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine1",DBUtils.readColumnWithRowID("Address Line 1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine2",DBUtils.readColumnWithRowID("Address Line 2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine3",DBUtils.readColumnWithRowID("Address Line 3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].CityName",DBUtils.readColumnWithRowID("City", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Country",DBUtils.readColumnWithRowID("Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].PostalCode",DBUtils.readColumnWithRowID("Zip Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Address1_Mailing Address Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Address1_Permanent Address same as Residential Address", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Type",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
	
	
		//JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].State",DBUtils.readColumnWithRowID("State", GetCase.scenarioID));
		
		
//		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Address1_Mailing Address Indicator", GetCase.scenarioID));
//		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Address1_Permanent Address same as Residential Address", GetCase.scenarioID));
	
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthInYY",DBUtils.readColumnWithRowID("Address1_Length at Current Address", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthInMM",DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_MM", GetCase.scenarioID));
		
		
		
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Residence_Type",DBUtils.readColumnWithRowID("Address1_Residence type", GetCase.scenarioID));
		
		//**********************************Vijay-02082018*******************************************
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].AddressLine4",DBUtils.readColumnWithRowID("AddressLine4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Country",DBUtils.readColumnWithRowID("Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Type",DBUtils.readColumnWithRowID("Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].Area",DBUtils.readColumnWithRowID("Area", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Addresses[0].LengthAtCurrentAddressInMonths",DBUtils.readColumnWithRowID("Address1_Length_at_Current_Address_MM", GetCase.scenarioID));
		//*******************************************************************************************

		
	}
	
	public static void setBankuse(){
		
		JsonPath.parse(json).set("$.content.ApplicationInfo.ClosingID",DBUtils.readColumnWithRowID("Closing ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.InvesmntAccntReq",DBUtils.readColumnWithRowID("Investment Account Request", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.HRDate",DBUtils.readColumnWithRowID("HR Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.Fund",DBUtils.readColumnWithRowID("Fund", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.RefRelationship",DBUtils.readColumnWithRowID("Referee_Relationship", GetCase.scenarioID));

	}
	
	public static void setCKYCDetails(){
		
		/***************************************************@author 1567977*****************************************************************/
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCDateOfDeclaration",DBUtils.readColumnWithRowID("KYC Date Of Declaration", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCPlaceOfDeclaration",DBUtils.readColumnWithRowID("KYC Place Of Declaration", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCVerificationDate",DBUtils.readColumnWithRowID("KYC Verification Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCEmployeeName",DBUtils.readColumnWithRowID("KYC Employee Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCEmployeeDesignation",DBUtils.readColumnWithRowID("KYC Employee Designation", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCVerificationBranch",DBUtils.readColumnWithRowID("KYC Verification Branch", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.ApplicationInfo.KYCEmployeeCode",DBUtils.readColumnWithRowID("KYC Employee Code", GetCase.scenarioID));
		
	}
	
	
	public static void setFatcaInfoDetails(){
		
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSCitizen",DBUtils.readColumnWithRowID("Is Customer a US Citizen?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSGreenCardHolder",DBUtils.readColumnWithRowID("FATCA - Is Customer a US Resident?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FATCAInfo.IsUSResident",DBUtils.readColumnWithRowID("FATCA - Is Customer a Green card holder?", GetCase.scenarioID));
		
	
	}
	

	public static void Eops(){
	
		//***************************Vijay02082018***************************//
		JsonPath.parse(json).set("$.content.Customers[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers[0].FullName",DBUtils.readColumnWithRowID(FullName, GetCase.scenarioID));
		
	}
	
	public static void moreFinancialSection(){
		
		//***************************Vijay02082018***************************//
		
		
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Account Number/App Ref No.", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AccountType",DBUtils.readColumnWithRowID("Account Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].ActualMonthlyCommitment",DBUtils.readColumnWithRowID("Actual Monthly Commitment", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].ApplicantType",DBUtils.readColumnWithRowID("Applicant Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].AppliedAmountCurrency",DBUtils.readColumnWithRowID("Applied Amount Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].CommitmentCurrency",DBUtils.readColumnWithRowID("Commitment Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OriginalApprovedLimit",DBUtils.readColumnWithRowID("Original approved limit", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OriginalApprovedLimitCurrency",DBUtils.readColumnWithRowID("Original approved limit currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OtherCardRepaymentRatio",DBUtils.readColumnWithRowID("other Card Repayment Ratio", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OustandingAmountCurrency",DBUtils.readColumnWithRowID("Oustanding amount currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].OutstandingAmount",DBUtils.readColumnWithRowID("Outstanding amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].Source",DBUtils.readColumnWithRowID("Source", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].MoreFinancialDetails[0].Status",DBUtils.readColumnWithRowID("Status", GetCase.scenarioID));

	
	
	}
	
	public static void setInfoCodeDetails(){
		JsonPath.parse(json).set("$.content.Customers[0].InfoCode[0].Code",DBUtils.readColumnWithRowID("MIS Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].InfoCode[0].Value",DBUtils.readColumnWithRowID("MIS Value", GetCase.scenarioID));	
	}
	
	
	public static void setCoapplicantBasicDataCaptureFields_CustomerTab(int coapplicantsequence) throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		
		coApplicantFullName = DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",coApplicantFullName);

		//Customer Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Title",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DateOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" DOB", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].First_Name",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LastName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MiddleName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Middle Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfBirth",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].CountryOfResidence",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Residence Country Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
		


		//Contact Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[0].ISDCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISD Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact type Code1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Contacts[1].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details1", GetCase.scenarioID));


				
				//Employment Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ClientType",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Client Type", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Industry",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" ISIC Description", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Code", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Occupation Description", GetCase.scenarioID));
				
				
						//Document Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[4].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[7].DocumentName",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Name of the Document", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].IDDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].VerfDocumentList[0].DocumentNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Number1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[0].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DocumentList[1].DocumentExpiryDate",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Document Expiry Date1", GetCase.scenarioID));


				
						//Eops Details

				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ContactNumber",DBUtils.readColumnWithRowID("Coapplicant"+coapplicantsequence+" Contact Details", GetCase.scenarioID));
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FullName",DBUtils.readColumnWithRowID(FullName, GetCase.scenarioID));

	}
	
	public static void setCoapplicantDetailsForFDCMaker(int coapplicantsequence){
		
				JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Gender",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Gender", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ConstitutionCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InitialFundSrc",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Source(s) of Initial Funding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MaritalStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Marital Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].PlaceOfBirth",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Place of Birth", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Qualification",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Educational Qualification", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MarketingPreferences",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Marketing Preferences", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].RelationWithBank",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Educational Qualification", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].TypeOfInitialFund",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" TypeOfInitialFunding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ConstitutionCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Constitution Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfDependants",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No. of Dependants", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].ResidenceStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Residential Status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].GSTCustomerType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Customer Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].GSTRegistrationNumber",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" GST Registration Number", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpecificStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Specific status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].AdviceDetailsAddressType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Advice Detail Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InternetBanking",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Online Banking", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].DomicileCountryCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MobileBanking",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Mobile Banking", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfDependants",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No. of Dependants", GetCase.scenarioID));

		// FamilyDetails

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MaidenFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MaidenFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FatherPrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FatherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherMaidenName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherMaidenName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MotherPrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MotherPrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseFirstName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseFirstName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseLastName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseLastName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpouseMiddleName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpouseMiddleName", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].SpousePrefix",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" SpousePrefix", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].NumberOfChildren",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Number of children", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].AgeOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Age of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].GenderOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Gender of Child", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content..Customers["+coapplicantsequence+"].ChildrenDetails[0].NameOfChild",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Name of the Child", GetCase.scenarioID));


		
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmployerRelationshipName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Employer Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmploymentType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Work Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.EmpReltnID",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Employee ID", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.StaffCategory",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Staff Category", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IsPayrollCust",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Payroll Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NatureOfBusiness",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Nature of Business", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.AnnualDeclaredIncome",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" AnnualDeclaredIncome", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.BusinessEstablishmentDate",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Business Establishment Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Company_Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Company Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CompanyName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Company Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CompanyType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" A", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CurrentOrgMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.CurrentOrgYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Department",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Department", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.Designation",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Designation", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IncorporationCountry",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Incorporation Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IncorporationDate",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Incorporation Date", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.IndustryGroup",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Industry Group Sector", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.ModeOfSalary",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Salary Mode", GetCase.scenarioID));

		int a = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID))*12; 
		int b = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID))*12; 

		int c = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Current business/Organization", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID)));
		int d = Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Current_businessPreOrganization_YY", GetCase.scenarioID)+Integer.parseInt(DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID)));


		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NoOfMonthsInCurrentBusinessOrganization",a);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.NoOfMonthsInPreviousBusinessOrganization",b); 
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.OwnershipType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Describe Applicant/Ownership Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousEmployerName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Previous employer name ", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousOrgMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No of Months in Previous business/Organization", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.PreviousOrgYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" No_of_Months_in_Previous_businessPreOrganization_YY", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.SharePercentage",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" % of Share holding", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TaxResidencyStatus",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Tax Residency status", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TotalExpMM",c);
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Employment.TotalExpYY",d);



		//Address Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine1",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine2",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 2", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine3",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Line 3", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].CityName",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" City", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Country",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].PostalCode",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Zip Code", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Mailing Address Indicator", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Type", GetCase.scenarioID));
		//JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Permanent Address same as Residential Address", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].State",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" State", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsMailingAddress",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Mailing Address Indicator", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].IsPermanentandMailingAddressSame",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Permanent Address same as Residential Address", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthInYY",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length at Current Address", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthInMM",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length_at_Current_Address_MM", GetCase.scenarioID));

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Residence_Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Residence type", GetCase.scenarioID));


		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].AddressLine4",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" AddressLine4", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Country",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Country", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Type",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].Area",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Area", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].Addresses[0].LengthAtCurrentAddressInMonths",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Address1_Length_at_Current_Address_MM", GetCase.scenarioID));

		//FATCA Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSCitizen",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Is Customer a US Citizen?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSGreenCardHolder",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FATCA - Is Customer a US Resident?", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].FATCAInfo.IsUSResident",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" FATCA - Is Customer a Green card holder?", GetCase.scenarioID));


		//More Financial Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AccountNumber",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Account Number/App Ref No.", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AccountType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Account Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].ActualMonthlyCommitment",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Actual Monthly Commitment", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].ApplicantType",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Applicant Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].AppliedAmountCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Applied Amount Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].CommitmentCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Commitment Currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OriginalApprovedLimit",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Original approved limit", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OriginalApprovedLimitCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Original approved limit currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OtherCardRepaymentRatio",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" other Card Repayment Ratio", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OustandingAmountCurrency",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Oustanding amount currency", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].OutstandingAmount",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Outstanding amount", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].Source",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Source", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].MoreFinancialDetails[0].Status",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" Status", GetCase.scenarioID));

		//Internal Details

		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InfoCode[0].Code",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MIS Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers["+coapplicantsequence+"].InfoCode[0].Value",DBUtils.readColumnWithRowID("Coapp"+coapplicantsequence+" MIS Value", GetCase.scenarioID));


	

}
	
	public static void setBasicDataCaptureFields_CustomerTab() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		
		//Customer Tab
		
		FullName = DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);
		
		JsonPath.parse(json).set("$.content.CustFullName",FullName);
		
		ShortName = DBUtils.readColumnWithRowID("Title", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID) +
				DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID) +
				 DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID);

		
		JsonPath.parse(json).set("$.content.Customers[0].Title",DBUtils.readColumnWithRowID("Title", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].DateOfBirth",DBUtils.readColumnWithRowID("DOB", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].EmbossedName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].FirstName",DBUtils.readColumnWithRowID("First Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].FullName",FullName);

		JsonPath.parse(json).set("$.content.Customers[0].LastName",DBUtils.readColumnWithRowID("Last Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].LegalName",FullName);
		JsonPath.parse(json).set("$.content.Customers[0].MiddleName",DBUtils.readColumnWithRowID("Middle Name", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].Nationality",DBUtils.readColumnWithRowID("Nationality Code1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].NationalityList[0].NationalityDescription",DBUtils.readColumnWithRowID("Nationality Description1", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirthDescription",DBUtils.readColumnWithRowID("Country Of Birth Description", GetCase.scenarioID));	
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidenceDescription",DBUtils.readColumnWithRowID("Residence Country Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfBirth",DBUtils.readColumnWithRowID("Country Of Birth Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].CountryOfResidence",DBUtils.readColumnWithRowID("Residence Country Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].ContactNumber",DBUtils.readColumnWithRowID("Contact Details", GetCase.scenarioID));
	//	JsonPath.parse(json).set("$.content.Customers[0].DomicileCountryCode",DBUtils.readColumnWithRowID("Country Of Birth Code", GetCase.scenarioID));
		
		setMultipleCustomerContactDetails();
		
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ClientType",DBUtils.readColumnWithRowID("Client Type", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.Industry",DBUtils.readColumnWithRowID("ISIC Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.IndustryDescription",DBUtils.readColumnWithRowID("ISIC Description", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionCode",DBUtils.readColumnWithRowID("Occupation Code", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.Customers[0].Employment.ProfessionDescription",DBUtils.readColumnWithRowID("Occupation Description", GetCase.scenarioID));
	
		setDocumentDetails();
		Eops();		
	}

/**************************************************************************************************
	 * @author 1575731
	 * MethodName: setCustomerIncomeDocumentDetailsInFDCMaker
	 * Objective: Provide Income details in Json for Primary & CoApp1, CoApp2 ...
	 * Arguments: CustomerIndex ,incomeDocArrayIndex,PrimaryOrCoApp
	 * * * CustomerIndex: Takes integer as Argument(If primary- provide 0, CoApp1 - provide 1..)
	 * * * incomeDocArrayIndex: Takes integer as argument, Used for Creating Json Path
	 * * * PrimaryOrCoApp: if primary then provide :"Primary" else CoApp1,CoApp2,.. based on how you created in DB
	 * @return: void 
	 **************************************************************************************************/
	public static void setCustomerIncomeDocumentDetailsInFDCMaker_All(int CustomerIndex , String PrimaryOrCoApp ,int IncomeDocCount,int incomeDocArrayIndex) throws ClassNotFoundException, SQLException, IOException
		{
		    DBUtils.convertDBtoMap("fdqueryIncome");
			String pxObjClass="SCB-Data-FinancialDetails";
			String timeZone="T18:30:00.000Z";
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
		
		if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("FORM 16"))
		{
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory","R0005");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType","T0373");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			/**********************************************Form 16 Details***************************************************************/
			String pxObjectClassForm16="SCB-Data-FinancialDetails-FORM16";
			
			//Year1
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Income_As_Per_Tax_File_1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[0].pxObjClass",pxObjectClassForm16);
			
			//Year2
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfIssueDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc1", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[1].pxObjClass",pxObjectClassForm16);
			
			//Year3
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].AssessmentYearFromYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfIssueDoc2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].AssessmentYearToYear",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].IncomeAsPerTax",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Income_As_Per_Tax_File_2", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Detail[2].GrandTotal","0");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Form16Details[2].pxObjClass",pxObjectClassForm16);
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("CREDIT CARD /DEBIT CARD STATEMENT"))
		{
			String pxObjClassCC="SCB-Data-FinancialDetails-CreditCardStatement";
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory","R0005");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType","T0069");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","2");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			//################################################Credit Statements #########################################
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardLimit",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfIssueDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].CardRepayRatio",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DateOfExpiryDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].IssuerName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].LastMonthOutstanding",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].ProductName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDt",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtFrom",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[0].StatementDtTo",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1StatementDtTo", GetCase.scenarioID));
			
			//Month1 - Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].CardLimit",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2CardLimit", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].DateOfIssueDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2DateOfIssueDoc1", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].CardRepayRatio",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2CardRepayRatio", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].pxObjClass",pxObjClassCC);
			
			//Optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].DateOfExpiryDoc",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2DateOfExpiryDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].IssuerName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2IssuerName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].LastMonthOutstanding",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2LastMonthOutstanding", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].ProductName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2ProductName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].StatementDt",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2StatementDt", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].StatementDtFrom",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2StatementDtFrom", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CreditCardStatement[1].StatementDtTo",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2StatementDtTo", GetCase.scenarioID));
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("PAYSLIP"))
		{
			String pxObjClassPaySlip="SCB-Data-FinancialDetails-Payslip";
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocAccuracy","90");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentCategory","R0005");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentName",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentRemarks","Other Bank CC Documents");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentType","T0235");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].OcrFlag","Y");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PeriodLength","3");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].pxObjClass",pxObjClass);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].UserFlag","true");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate","");
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","M");
			
			//######################PaySlip Details####################
			
			//Month1
			System.out.println(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field1-->"+DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field1", GetCase.scenarioID));
			int bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field1", GetCase.scenarioID));
			int bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field2", GetCase.scenarioID));
			int bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field3", GetCase.scenarioID));
			int bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field4", GetCase.scenarioID));
			int bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field5", GetCase.scenarioID));
			int bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field6", GetCase.scenarioID));
			int bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field7", GetCase.scenarioID));
			int bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_Basic_Monthly_Salary_Field8", GetCase.scenarioID));
			
			int mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field1", GetCase.scenarioID));
			int mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field2", GetCase.scenarioID));
			int mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field3", GetCase.scenarioID));
			int mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field4", GetCase.scenarioID));
			int mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field5", GetCase.scenarioID));
			int mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field6", GetCase.scenarioID));
			int mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field7", GetCase.scenarioID));
			int mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyAllowance_Field8", GetCase.scenarioID));
			
			int mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			int mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyBonus_Field1", GetCase.scenarioID));
			
			int mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field1", GetCase.scenarioID));
			int mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field2", GetCase.scenarioID));
			int mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field3", GetCase.scenarioID));
			int mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field4", GetCase.scenarioID));
			int mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field5", GetCase.scenarioID));
			int mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field6", GetCase.scenarioID));
			int mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field7", GetCase.scenarioID));
			int mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyCommission_Field8", GetCase.scenarioID));
			
			int mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field1", GetCase.scenarioID));
			int mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field2", GetCase.scenarioID));
			int mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field3", GetCase.scenarioID));
			int mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field4", GetCase.scenarioID));
			int mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field5", GetCase.scenarioID));
			int mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field6", GetCase.scenarioID));
			int mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field7", GetCase.scenarioID));
			int mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M1_MonthlyVariableBonus_Field8", GetCase.scenarioID));
			
			int basicSalarytotal = bfield1+bfield2+bfield3+bfield4+bfield5+bfield6+bfield7+bfield8;
			int MonthlyAllowancetotal = mafield1+mafield2+mafield3+mafield4+mafield5+mafield6+mafield7+mafield8;
			int MonthlyBonustotal = mbfield1+mbfield2+mbfield3+mbfield4+mbfield5+mbfield6+mbfield7+mbfield8;
			int MonthlyCommissiontotal = mcfield1+mcfield2+mcfield3+mcfield4+mcfield5+mcfield6+mcfield7+mcfield8;
			int MonthlyVariableBonus = mvfield1+mvfield2+mvfield3+mvfield4+mvfield5+mvfield6+mvfield7+mvfield8;
			
			int grandTotal= basicSalarytotal+MonthlyAllowancetotal+MonthlyBonustotal+MonthlyCommissiontotal+MonthlyVariableBonus;
			
			//Month1 Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrandTotal",""+(float)grandTotal);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Gross_Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Net_Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field1",""+(float)bfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field2",""+(float)bfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field3",""+(float)bfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field4",""+(float)bfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field5",""+(float)bfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field6",""+(float)bfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field7",""+(float)bfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field8",""+(float)bfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Total",""+(float)basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field1",""+(float)mafield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field2",""+(float)mafield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field3",""+(float)mafield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field4",""+(float)mafield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field5",""+(float)mafield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field6",""+(float)mafield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field7",""+(float)mafield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field8",""+(float)mafield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Total",""+(float)MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field1",""+(float)mbfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field2",""+(float)mbfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field3",""+(float)mbfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field4",""+(float)mbfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field5",""+(float)mbfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field6",""+(float)mbfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field7",""+(float)mbfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field8",""+(float)mbfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Total",""+(float)MonthlyBonustotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field1",""+(float)mcfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field2",""+(float)mcfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field3",""+(float)mcfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field4",""+(float)mcfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field5",""+(float)mcfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field6",""+(float)mcfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field7",""+(float)mcfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field8",""+(float)mcfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Total",""+(float)MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",""+(float)mvfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",""+(float)mvfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",""+(float)mvfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",""+(float)mvfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",""+(float)mvfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",""+(float)mvfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",""+(float)mvfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",""+(float)mvfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Total",""+(float)MonthlyVariableBonus);

			/* Month 2*/
			int m2bfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field1", GetCase.scenarioID));
			int m2bfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field2", GetCase.scenarioID));
			int m2bfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field3", GetCase.scenarioID));
			int m2bfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field4", GetCase.scenarioID));
			int m2bfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field5", GetCase.scenarioID));
			int m2bfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field6", GetCase.scenarioID));
			int m2bfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field7", GetCase.scenarioID));
			int m2bfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_Basic_Monthly_Salary_Field8", GetCase.scenarioID));
			
			int m2mafield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field1", GetCase.scenarioID));
			int m2mafield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field2", GetCase.scenarioID));
			int m2mafield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field3", GetCase.scenarioID));
			int m2mafield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field4", GetCase.scenarioID));
			int m2mafield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field5", GetCase.scenarioID));
			int m2mafield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field6", GetCase.scenarioID));
			int m2mafield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field7", GetCase.scenarioID));
			int m2mafield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyAllowance_Field8", GetCase.scenarioID));
			
			int m2mbfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			int m2mbfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyBonus_Field1", GetCase.scenarioID));
			
			int m2mcfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field1", GetCase.scenarioID));
			int m2mcfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field2", GetCase.scenarioID));
			int m2mcfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field3", GetCase.scenarioID));
			int m2mcfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field4", GetCase.scenarioID));
			int m2mcfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field5", GetCase.scenarioID));
			int m2mcfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field6", GetCase.scenarioID));
			int m2mcfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field7", GetCase.scenarioID));
			int m2mcfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyCommission_Field8", GetCase.scenarioID));
			
			int m2mvfield1 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field1", GetCase.scenarioID));
			int m2mvfield2 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field2", GetCase.scenarioID));
			int m2mvfield3 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field3", GetCase.scenarioID));
			int m2mvfield4 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field4", GetCase.scenarioID));
			int m2mvfield5 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field5", GetCase.scenarioID));
			int m2mvfield6 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field6", GetCase.scenarioID));
			int m2mvfield7 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field7", GetCase.scenarioID));
			int m2mvfield8 = Integer.parseInt(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_M2_MonthlyVariableBonus_Field8", GetCase.scenarioID));
			
			int m2basicSalarytotal = m2bfield1+m2bfield2+m2bfield3+m2bfield4+m2bfield5+m2bfield6+m2bfield7+m2bfield8;
			int m2MonthlyAllowancetotal = m2mafield1+m2mafield2+m2mafield3+m2mafield4+m2mafield5+m2mafield6+m2mafield7+m2mafield8;
			int m2MonthlyBonustotal = m2mbfield1+m2mbfield2+m2mbfield3+m2mbfield4+m2mbfield5+m2mbfield6+m2mbfield7+m2mbfield8;
			int m2MonthlyCommissiontotal = m2mcfield1+m2mcfield2+m2mcfield3+m2mcfield4+m2mcfield5+m2mcfield6+m2mcfield7+m2mcfield8;
			int m2MonthlyVariableBonus = m2mvfield1+m2mvfield2+m2mvfield3+m2mvfield4+m2mvfield5+m2mvfield6+m2mvfield7+m2mvfield8;
			
			int m2grandTotal= m2basicSalarytotal+m2MonthlyAllowancetotal+m2MonthlyBonustotal+m2MonthlyCommissiontotal+m2MonthlyVariableBonus;
			
			//Month2 Mandatory
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrandTotal",""+(float)m2grandTotal);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].GrossPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Gross_Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].NetPay",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_Net_Pay", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].pxObjClass",pxObjClassPaySlip);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"DateOfIssueDoc1", GetCase.scenarioID)+timeZone);
			
			//optional
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field1",""+(float)m2bfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field2",""+(float)m2bfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field3",""+(float)m2bfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field4",""+(float)m2bfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field5",""+(float)m2bfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field6",""+(float)m2bfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field7",""+(float)m2bfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Field8",""+(float)m2bfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.BasicMonthlySalary.Total",""+(float)m2basicSalarytotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field1",""+(float)m2mafield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field2",""+(float)m2mafield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field3",""+(float)m2mafield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field4",""+(float)m2mafield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field5",""+(float)m2mafield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field6",""+(float)m2mafield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field7",""+(float)m2mafield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Field8",""+(float)m2mafield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyAllowance.Total",""+(float)m2MonthlyAllowancetotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field1",""+(float)m2mbfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field2",""+(float)m2mbfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field3",""+(float)m2mbfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field4",""+(float)m2mbfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field5",""+(float)m2mbfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field6",""+(float)m2mbfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field7",""+(float)m2mbfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Field8",""+(float)m2mbfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyBonus.Total", ""+(float)m2MonthlyCommissiontotal);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field1",""+(float)m2mcfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field2",""+(float)m2mcfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field3",""+(float)m2mcfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field4",""+(float)m2mcfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field5",""+(float)m2mcfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field6",""+(float)m2mcfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field7",""+(float)m2mcfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Field8",""+(float)m2mcfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyCommission.Total", ""+(float)m2MonthlyVariableBonus);
			
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field1",""+(float)m2mvfield1);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field2",""+(float)m2mvfield2);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field3",""+(float)m2mvfield3);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field4",""+(float)m2mvfield4);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field5",""+(float)m2mvfield5);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field6",""+(float)m2mvfield6);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field7",""+(float)m2mvfield7);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Field8",""+(float)m2mvfield8);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].PayslipDetails[0].Component.MonthlyVariableBonus.Total", ""+(float)m2MonthlyVariableBonus);
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("BONUS"))
		{
			/*******************************************Bonus Letters*******************************************************/
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentDate",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DateOfIssueDoc", GetCase.scenarioID)+timeZone);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].Mandatory","O");
			
		}
		
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("BANK STATEMENT"))
		{
			/***************************************Bank Statements*********************************************************/			
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			
		}
		else if(DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID).contains("ITR DOCUMENT"))
		{
			/*******************************************ITR DOCUMENT*******************************************************/
			//JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].CustomerFullNameOcr",FullName);
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[0].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[1].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].DocumentStatus",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentStatus", GetCase.scenarioID));
			JsonPath.parse(json).set("$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"].BankStatement[2].GrandTotal",DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_CardGrandTotal", GetCase.scenarioID));
			
		}
		
		else{System.out.println(""+DBUtils.readColumnWithRowID(PrimaryOrCoApp+"_IncomeDoc"+IncomeDocCount+"_DocumentName", GetCase.scenarioID)+"Does Not matches with any of the Income docs");}
		
}
public static void SetCustomerIncomeDocumentDetails()  throws ClassNotFoundException, SQLException, IOException
	{
		DBUtils.convertDBtoMap("fdqueryIncome");
		System.out.println("-----------------       *********SetCustomerIncomeDocumentDetails -Starts**********          ---------------------------");
		int CustomerIndex=0;
		String PrimaryOrCoApp="Primary";
		int incomeDocArrayIndex=0;
		
		for(int IncomeDocCount=1;IncomeDocCount<=3;IncomeDocCount++)
		{
			System.out.println("--------------$.content.Customers["+CustomerIndex+"].IncomeDocumentList["+incomeDocArrayIndex+"]--------------IncomeDocCount:-->"+IncomeDocCount+","+"PrimaryOrCoApp:--->"+PrimaryOrCoApp+",incomeDocArrayIndex:--->"+incomeDocArrayIndex+"CustomerIndex:-->"+CustomerIndex+"------------------------------");
			setCustomerIncomeDocumentDetailsInFDCMaker_All(CustomerIndex, PrimaryOrCoApp, IncomeDocCount, incomeDocArrayIndex);
			incomeDocArrayIndex++;
//			CustomerIndex++;
		}
		
		System.out.println("-----------------        **********SetCustomerIncomeDocumentDetails -Ends**********      ---------------------------");
		
	}

}
