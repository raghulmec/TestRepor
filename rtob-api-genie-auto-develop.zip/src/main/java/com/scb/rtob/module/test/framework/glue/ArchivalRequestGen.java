package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.internal.filter.ValueNode.JsonNode;
import com.scb.rtob.module.test.framework.utils.*;

import cucumber.api.java.en.Given;


public class ArchivalRequestGen {
	
	public static Logger logger = Logger.getLogger(ArchivalRequestGen.class);
	
	static String basicScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	

	public static void main(String[] args) throws Throwable {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		//promoteBasic();
	
	}
		
	@Given("^Call the PromoteCase api for Archival$")
	public static void promoteArchival() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"Archival"+File.separator+""+GetCase.envmap.get("Archival_Template"));
		
		
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
//		setValueArchival();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive ().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
//		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_Archival"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
//		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	@Given("^validate if the application moved from Archival WB$")
	public static void validateArchivalWorkbasket() throws Throwable {
		
		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		
		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Archival")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		
		Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_Archival"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	}

	public static void setValueArchival() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");
		
//		ArchivalSetValue.setJSON(jsonReq);
		JsonPath.parse(jsonReq).set("$.content.DocStorageRefNum[0]",DBUtils.readColumnWithRowID("Storage Ref No", GetCase.scenarioID));
		JsonPath.parse(jsonReq).set("$.content.ArchivalDate[0]",DBUtils.readColumnWithRowID("Archival Date", GetCase.scenarioID));
		JsonPath.parse(jsonReq).set("$.content.ActionBasicDatacapture[0]","Completed");
		
	}

}