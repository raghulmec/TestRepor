package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;



import java.util.Set;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.json.stream.JsonGenerator;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;

import com.scb.rtob.module.test.framework.utils.CreditInitiationSetValues;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class CreditInitiationRequestGen {

	static String fdcScenarioID = "1";
	
	public static Logger logger = Logger.getLogger(CreditInitiationRequestGen.class);
	public static Response response;
	public static JSONObject jsonReq;
	public static JSONParser parser = new JSONParser();
	public static String CurrentWorkBasketActionOne;
	public static String CurrentWorkBasketActionTwo;
	public static String CurrentWorkBasketActionReason;
	public static String PathToNode;
	
	/*@When("^Call the PromoteCase api from '(.*)'$")
	public static void promoteCI(String currentWorkBasket) throws Throwable{
			
		String JsonTemplate = currentWorkBasket+"_Template";
		
		//FileReader reader = new FileReader(GetCase.envmap.get(JsonTemplate));
		//FileReader reader = new FileReader("C:/Users/1580707/StanChartBank/framework_dumps/API framework dump/src/test/resources/jsontemplates/CI/CI_Template.json");
		
		//jsonReq = (JSONObject) parser.parse(reader);
		//jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		*//****************************Set values for JSON attributes*************************************//*
		*//**********Need Not be done as it is taken care in the previous StepDef call, UpdateByAtri**********//* 
		//setACDJSONAttributes(currentWorkBasket);
		
		*//****************************Start - API call part**********************************************//*
		RestAssured.baseURI = GetCase.envmap.get("URIGet");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		//httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));
		httpRequest.header("ApplicationRefNo","IN20180306000402");
		httpRequest.header("CurrentWorkBasket",currentWorkBasket);
		
		//httpRequest.body(jsonReq);
		httpRequest.body(jsonReq.toString());
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(org.json.simple.JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
		
	}*/
	
	/*@Then("^validate if the application moved from '(.*)' to '(.*)'")
	public static void validateWorkbasket(String previousWorkBasket, String ExpectedcurrentWorkBasket) throws Throwable {
		
		
		logger.info("Previous Workbasket : "+GetCase.envmap.get(previousWorkBasket));
		//logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		switch (CurrentWorkBasketActionOne){
		
		case "Approve":{
			
			logger.info("CIAction : " + CurrentWorkBasketActionOne);
			
			
			logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
			if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
				logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
			
		}
		
		case "Decline":{
			
			logger.info("CIAction : " + CurrentWorkBasketActionOne);
			
			logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
			if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
				logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
			
		}
		
		case "Recommend":{
			
			logger.info("CIAction : " + CurrentWorkBasketActionOne);
			
			logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
			if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
				logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
			
		}
		
		case "Refer":{
			
			logger.info("CIAction : " + CurrentWorkBasketActionOne);
			
			if((CurrentWorkBasketActionReason=="CI003")||(CurrentWorkBasketActionReason=="CI004")||(CurrentWorkBasketActionReason=="CI005")||(CurrentWorkBasketActionReason=="CI006")){
				
				logger.info("Refer Reason : " + CurrentWorkBasketActionReason);
				
				logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
				if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
					logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
							
			}
			else{
				
				if ((CurrentWorkBasketActionReason=="CI001")||(CurrentWorkBasketActionReason=="CI002")){
					
					logger.info("Refer Reason : " + CurrentWorkBasketActionReason);
					
					logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
					if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
						logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
					
				}
				else{
					
					if (CurrentWorkBasketActionReason=="CI007"){
						
						logger.info("Refer Reason : " + CurrentWorkBasketActionReason);
						
						logger.info("EXPECTED RESULT : Current Workbasket should be - "+GetCase.envmap.get(ExpectedcurrentWorkBasket));
						if (GetCase.responseJSON.get("CurrentWorkBasket").equals(GetCase.envmap.get(ExpectedcurrentWorkBasket)))
							logger.info("ACTUAL RESULT : Current Workbasket is - "+GetCase.responseJSON.get("CurrentWorkBasket"));
						
					}
					
				}
				
			}
			
		}
		
	}
			
}
	*/
	
	public static void setACDJSONAttributes(String currentWorkBasket) throws ClassNotFoundException, SQLException, IOException{
			
		logger.info("acdquery");
		DBUtils.convertDBtoMap("acdquery");
			
		switch (currentWorkBasket){
		
		case "Credit Check Checker":{
			
			//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("creditcheckeraction", Hooks.scenarioID);
			CurrentWorkBasketActionOne = "A";
			String ActionJsonNodePath = GetCase.envmap.get("CreditCheckerActionList").substring(2);
			String[]arrayAction = ActionJsonNodePath.split(".");
			int lengthAction = arrayAction.length;
			String lastelementAction = arrayAction[lengthAction-1];
			String toReplace = "."+lastelementAction;
			PathToNode = ActionJsonNodePath.replace(toReplace, "");
			logger.info(PathToNode);
			CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);
			break;
		}
		
		
			case "DisplayOffers":{
				
				CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("OffersDecision", GetCase.scenarioID);
				String ActionJsonNodePath = GetCase.envmap.get("DisplayOffersWBDecision").substring(2);
				String[]arrayAction = ActionJsonNodePath.split(".");
				int lengthAction = arrayAction.length;
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				logger.info(PathToNode);
				CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);
				
				
				if (CurrentWorkBasketActionOne == "Resubmit"){
					
					CurrentWorkBasketActionReason = DBUtils.readColumnWithRowID("DisplayOffersWBOfferResubmitDeclaration", GetCase.scenarioID);
					String ActionJsonNodePath1 = GetCase.envmap.get("DisplayOffersWBOfferResubmitDeclaration").substring(2);
					String[]arrayAction1 = ActionJsonNodePath1.split(".");
					int lengthAction1 = arrayAction1.length;
					String lastelementAction1 = arrayAction1[lengthAction1-1];
					String toReplace1 = "."+lastelementAction1;
					PathToNode = ActionJsonNodePath1.replace(toReplace1, "");
					logger.info(PathToNode);
					CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction1, CurrentWorkBasketActionReason);
										
				}
				break;
				
			}
			
			case "RMSupervisorWB":{
				
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("OfferAction", Hooks.scenarioID);
				CurrentWorkBasketActionOne = "ApproveAppeal";
				String ActionJsonNodePath = GetCase.envmap.get("RMSupervisorWBOfferAction").substring(2);
				logger.info(ActionJsonNodePath);
				String[]arrayAction = ActionJsonNodePath.split("\\.");
				int lengthAction = arrayAction.length;
				logger.info(lengthAction);
				String lastelementAction = arrayAction[lengthAction-1];
				String toReplace = "."+lastelementAction;
				PathToNode = ActionJsonNodePath.replace(toReplace, "");
				CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);
				
				
				if(CurrentWorkBasketActionOne == "ApproveAppeal"){
					
					//CurrentWorkBasketActionReason = DBUtils.readColumnWithRowID("AppealFlag", Hooks.scenarioID);
					CurrentWorkBasketActionReason = "Y";
					String ReasonJsonNodePath = GetCase.envmap.get("RMSupervisorWBAppealFlag").substring(2);
					String[]arrayReason = ReasonJsonNodePath.split("\\.");
					int lengthReason = arrayReason.length;
					String lastelementReason = arrayReason[lengthReason-1];
					String toReplace2 = "."+lastelementReason;
					PathToNode = ReasonJsonNodePath.replace(toReplace2, "");
					logger.info(PathToNode);
					logger.info(lastelementReason);
					CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementReason, CurrentWorkBasketActionReason);
					
				}
				break;
				
			}
			
			case "Credit_Initiation":{
				
				//CurrentWorkBasketActionOne = DBUtils.readColumnWithRowID("CIAction", Hooks.scenarioID);				
				CurrentWorkBasketActionOne = null;
				if (CurrentWorkBasketActionOne!=null){
					
					String ActionJsonNodePath = GetCase.envmap.get("CIAction").substring(2);
					logger.info("texxxxxxxxxxxxxxxxxxt"+ActionJsonNodePath);
					String[]arrayAction = ActionJsonNodePath.split("\\.");
					int lengthAction = arrayAction.length;
					logger.info("texxxxxxxxxxxxxxxxxxt"+lengthAction);
					String lastelementAction = arrayAction[lengthAction-1];
					String toReplace = lastelementAction;
					PathToNode = ActionJsonNodePath.replace(toReplace, "");
					CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction, CurrentWorkBasketActionOne);
					
					if (CurrentWorkBasketActionOne == "Refer"){
						
						//CurrentWorkBasketActionReason = DBUtils.readColumnWithRowID("ReferReason", Hooks.scenarioID);
						CurrentWorkBasketActionReason = "CI002";
						String ReasonJsonNodePath = GetCase.envmap.get("ReferReason").substring(2);
						String[]arrayReason = ReasonJsonNodePath.split("\\.");
						int lengthReason = arrayReason.length;
						String lastelementReason = arrayReason[lengthReason-1];
						String toReplace2 = lastelementReason;
						PathToNode = ReasonJsonNodePath.replace(toReplace2, "");						
						CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementReason, CurrentWorkBasketActionReason);
						
					}
					
				}
				else{
					
					//CurrentWorkBasketActionTwo = DBUtils.readColumnWithRowID("Decision", Hooks.scenarioID);
					CurrentWorkBasketActionTwo = "Decline";
					if (CurrentWorkBasketActionTwo!=null){
						
						String ActionJsonNodePath1 = GetCase.envmap.get("Decision").substring(2);
						String[]arrayAction1 = ActionJsonNodePath1.split("\\.");
						int lengthAction1 = arrayAction1.length;
						String lastelementAction1 = arrayAction1[lengthAction1-1];
						String toReplace1 = lastelementAction1;
						PathToNode = ActionJsonNodePath1.replace(toReplace1, "");
						CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementAction1, CurrentWorkBasketActionTwo);
						
						if (CurrentWorkBasketActionTwo == "Decline"){
							
							//CurrentWorkBasketActionReason = DBUtils.readColumnWithRowID("Reasons", Hooks.scenarioID);
							CurrentWorkBasketActionReason = "CPD001";
							logger.info("CurrentWorkBasketActionReason = CPD001");
							String ReasonJsonNodePath1 = GetCase.envmap.get("Reasons").substring(2);
							logger.info(ReasonJsonNodePath1);
							String[]arrayReason1 = ReasonJsonNodePath1.split("\\.");
							int lengthReason1 = arrayReason1.length;
							String lastelementReason1 = arrayReason1[lengthReason1-1];
							String toReplace2 = lastelementReason1;
							PathToNode = ReasonJsonNodePath1.replace(toReplace2, "");
							
							CreditInitiationSetValues.UpdateJSONTemplate(PathToNode, lastelementReason1, CurrentWorkBasketActionReason);
							logger.info("NO CALL");
						}
						
					}
					
				}
				break;
				
			}
		
		}
			
		
	}
	
/***************************************************callGetCaseApiDup method Code Added By Atri Nil Bal, Dated: 2ndMar2018***************************************************/	
/*	@SuppressWarnings("deprecation")
	@Given("^Call the GetCase api and validate the workbasket '(.*)'$")	
	public static void callGetCaseApiDup(String currentWorkbasket) throws Throwable {
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		
		//httpRequest.header("ApplicationRefNo",Hooks.scenarioID);
		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		
		//httpRequest.header("CurrentWorkBasket",GetCase.envmap.get(currentWorkbasket));
		httpRequest.header("CurrentWorkBasket",currentWorkbasket);
		
		response = httpRequest.request(Method.GET,"/GetCase");
		
		logger.info(response.headers());
		logger.info(response.getStatusCode());
		logger.info("Status Code ok : "+AuthenticateRTOB.validateStatusCode(response.getStatusCode()));
		
		
				
		*//***************code to place the Get Case Response JSON Template in a .json file*******************//*
		logger.info("Writing in file");
		FileWriter file = new FileWriter("./src/test/resources/jsontemplates/ACD_Flow/HolderCI_Template.json");
		file.write(response.asString());
		file.close();
		*//***************code to place the Get Case Response JSON Template in a .json file, END*******************//*
		
		*//***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION*******************//*
		
		JsonReader JR2 = Json.createReader(new FileReader("./src/test/resources/jsontemplates/ACD_Flow/HolderCI_Template.json"));
		JsonObject JO = JR2.readObject();
		
		Map<String, Boolean> configFinal = new HashMap<>();
		configFinal.put(JsonGenerator.PRETTY_PRINTING, true);
		
		try(PrintWriter pw2 = new PrintWriter("./src/test/resources/jsontemplates/ACD_Flow/GetCaseCI_Template.json");
				JsonWriter jw2 = Json.createWriterFactory(configFinal).createWriter(pw2)){
					
					jw2.writeObject(JO);
		}
		*//***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION, END*******************//*
		
		*//***************CODE SNIPPET TO read the GetCase JSON Template in a File***************//*
	    File filenew = new File("./src/test/resources/jsontemplates/ACD_Flow/GetCaseCI_Template.json");
	    String content = FileUtils.readFileToString(filenew);
	    
	    *//***************CODE SNIPPET to CHECK the GetCase JSON Template BEFORE Updation As Per Scenario*******************//*
	    System.out.println("******************************************************************");
	    logger.info("START OF BEFORE");
	    JSONObject GetResponse = new JSONObject(content);
	    jsonReq = GetResponse;
	    CreditInitiationSetValues.JSONObjectReader(GetResponse);
	    logger.info("END OF BEFORE");
	    System.out.println("******************************************************************");
	    *//***************CODE SNIPPET to CHECK the GetCase JSON Template BEFORE Updation As Per Scenario, END*******************//*
	    *//***************CODE SNIPPET of Method Call to set Current WorkBasket specific Parameters in JSON Template as per scenario***************//*
	    
	    setACDJSONAttributes(currentWorkbasket);
	    
	    *//***************CODE SNIPPET of Method Call to set Current WorkBasket specific Parameters in JSON Template as per scenario, END***************//*
	    
	    
		*//***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION*******************//*
		FileWriter file24 = new FileWriter("./src/test/resources/jsontemplates/ACD_Flow/OutPutCI_Template.json");
		file24.write(GetResponse.toString());
		file24.close();
		
		JsonReader JRFinal = Json.createReader(new FileReader("./src/test/resources/jsontemplates/ACD_Flow/OutPutCI_Template.json"));
		JsonObject JOFinal = JRFinal.readObject();
		
		Map<String, Boolean> configFinalFinal = new HashMap<>();
		configFinalFinal.put(JsonGenerator.PRETTY_PRINTING, true);
		
		try(PrintWriter pwFinal = new PrintWriter("./src/test/resources/jsontemplates/ACD_Flow/HolderCI_Template.json");
				JsonWriter jw2Final = Json.createWriterFactory(configFinal).createWriter(pwFinal)){
					
					jw2Final.writeObject(JOFinal);
		}
		*//***************CODE SNIPPET FOR JSON PRETTY FORMAT VERSION, End*******************//*
		
		*//***************CODE SNIPPET to CHECK the GetCase JSON Template AFTER Updation As Per Scenario*******************//*
	    File fileFinal = new File("./src/test/resources/jsontemplates/ACD_Flow/OutPutCI_Template.json");
	    String contentFinal = FileUtils.readFileToString(fileFinal);
	    
	    System.out.println("******************************************************************");
	    logger.info("START OF AFTER");
	    JSONObject GetResponseFinal = new JSONObject(contentFinal);
	    CreditInitiationSetValues.JSONObjectReader(GetResponseFinal);
	    logger.info("END OF AFTER");
	    System.out.println("******************************************************************");
	    *//***************CODE SNIPPET to CHECK the GetCase JSON Template AFTER Updation As Per Scenario, END*******************//*
	    
	    
	    *//***************CODE TO EXTRACT THE "content" PORTION OF THE MODIFIED JSON TEMPLATE***************//*
	    File filePromote = new File("C:/Users/1580707/StanChartBank/framework_dumps/API framework dump/src/test/resources/jsontemplates/CI/OutPutCI_Template.json");
	    String contentPromote = FileUtils.readFileToString(filePromote);
	    JSONObject GetResponsePUT = GetResponseFinal.getJSONObject("content");
	    String GetResponsePUTModified = "{\"content\""+":"+GetResponsePUT.toString()+"}";
		File filePromoteModified = new File("./src/test/resources/jsontemplates/ACD_Flow/OutPutCI_Template.json");
		FileWriter fileWriter = new FileWriter(filePromoteModified);
		fileWriter.write(GetResponsePUTModified);
		fileWriter.flush();
		fileWriter.close();
		*//***************CODE TO EXTRACT THE "content" PORTION OF THE MODIFIED JSON TEMPLATE, End***************//*
		JSONObject PutRequest = new JSONObject(GetResponsePUTModified);
		jsonReq = PutRequest;
		
		
		FileWriter filePUT = new FileWriter("C:/Users/1580707/StanChartBank/framework_dumps/API framework dump/src/test/resources/jsontemplates/CI/HolderCI_Template.json");
		filePUT.write(GetResponsePUT.toString());
		filePUT.close();
		
		JsonReader JRFinalPUT = Json.createReader(new FileReader("./src/test/resources/jsontemplates/ACD_Flow/OutPutCI_Template.json"));
		JsonObject JOFinalPUT = JRFinalPUT.readObject();
		
		Map<String, Boolean> configFinalPUT = new HashMap<>();
		configFinalPUT.put(JsonGenerator.PRETTY_PRINTING, true);
		
		try(PrintWriter pwFinal = new PrintWriter("./src/test/resources/jsontemplates/ACD_Flow/PutCaseCI_Template.json");
				JsonWriter jw2Final = Json.createWriterFactory(configFinal).createWriter(pwFinal)){
					
					jw2Final.writeObject(JOFinalPUT);
		}
		
		
	    
	    
	    
	}
	*/
	/***************************************************callGetCaseApiDup method Code Added By Atri Nil Bal, Dated: 2ndMar2018,END***************************************************/
	
}
