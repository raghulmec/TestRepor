package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.internal.filter.ValueNode.JsonNode;
import com.scb.rtob.module.test.framework.utils.*;

import cucumber.api.java.en.Given;

public class DedupRequestGen {
	
	public static Logger logger = Logger.getLogger(DedupRequestGen.class);
	static JSONParser parser = new JSONParser();
	
	static String fdcScenarioID = "1";
	
	/********To be used in DedupRequestSetValue class***********************/
	
	public static JSONObject jsonReq;

	public static void main(String[] args) throws Throwable {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		promoteDedup();
		
		validateWorkbasketDedup();
		
	
	}
		
	@Given("^Call the PromoteCase api for Dedupe$")
	public static void promoteDedup() throws Throwable {
		
		
		
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"Dedupe"+File.separator+""+GetCase.envmap.get("Dedupe_Template"));
		
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueDedup();		
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI =  GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		//logger.info(DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//logger.info(DBUtils.readColumnWithRowID("Scenarioid", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo", "IN20180215000006", GetCase.scenarioID);
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_Dedupe"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	

	@Given("^validate if the application moved from Dedupe to FDC Maker$")
	public static void validateWorkbasketDedup() throws Throwable {
		
		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		
		
		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_FDM")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	//	Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_FDM"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
	}

	public static void setValueDedup() throws ClassNotFoundException, SQLException, IOException, ParseException{
		
		DBUtils.convertDBtoMap("bdquery");
		
		DedupSetValue.setJSON(jsonReq);
		
		
	}

public static void promoteDedupAPI() throws Throwable {
	
	logger.info("---------------------------------------- Promote DEDUPE WB Starts--------------------------------------");
	FileReader reader = CommonUtils.readFilefromDirectory("Globaltemplate", "DeDupe.json");
	jsonReq = (JSONObject) parser.parse(reader);
	
	/****************************Set values for JSON attributes*************************************/
	
	setValueDedup();
	logger.info(jsonReq);	
	/****************************Start - API call part**********************************************/
	
	GetCase.callPromoteCaseApi("ApplicationID_BDC", "CurrentWorkBasket_Dedupe","BDCTemplateRefNo", jsonReq, true);
	logger.info("---------------------------------------- Promote DEDUPE WB  Ends--------------------------------------");
    
}


}