package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;

public class InvestmentMaker {
 
public static Logger logger = Logger.getLogger(InvestmentMaker.class);
	
	static String InvestmentMakerScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	
	public static void main(String[] args) {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		//promoteBasic();
	}
	
	
	@Given("^Call the PromoteCase api for Investment Maker$")
	public static void promoteInvestMaker() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"InvestmentMaker"+File.separator+""+GetCase.envmap.get("InvestmentMaker_Template"));
	
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
	
		/****************************Set values for JSON attributes*************************************/
		
		//setValueInvestmentMaker();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_InvestmentMaker"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));	
			
	}
	
	public static void setValueInvMaker() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("bdquery");

		JsonPath.parse(jsonReq).set("$.content.InvestmentDocumentAvailable[0]",DBUtils.readColumnWithRowID("InvestmentDocumentAvailable", GetCase.scenarioID));
        JsonPath.parse(jsonReq).set("$.content.InvestmentAccNoOffline[0]",DBUtils.readColumnWithRowID("InvestmentAccNoOffline", GetCase.scenarioID));
        JsonPath.parse(jsonReq).set("$.content.InvestmentAccNoOnline[0]",DBUtils.readColumnWithRowID("InvestmentAccNoOnline", GetCase.scenarioID));
        JsonPath.parse(jsonReq).set("$.content.CDDExceptionAction[0]","A");

		
	
	}
	
	

}
