package com.scb.rtob.module.test.framework.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import net.minidev.json.parser.ParseException;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class OnboardingSetValue {

	public static Logger logger = Logger.getLogger(OnboardingSetValue.class);

	private static JSONObject json = DedupRequestGen.jsonReq;

	

	public static void main(String[] args) {


	}

	public static void setContent(){

	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}

	public static void ProductCheckBoxSelect(){
		

		
			
			
			try{
				
				for(int i=0;i<=5;i++){
					
					for(int j=0;j<=20;j++){
					
						String productcode = DBUtils.readColumnWithRowID("ProductCode"+i+1, GetCase.scenarioID);
			String jsonproductcode = JsonPath.parse(json).read("$.content.ProductCategoryList["+i+"].ProdSubCategoryList["+j+"].ProductCode");
			if(productcode.equals(jsonproductcode)){
				JsonPath.parse(json).set("$.content.ProductCategoryList[0].ProdSubCategoryList[0].pySelected","true");
				
				logger.info("Check True: "+JsonPath.parse(json).read("$.content.ProductCategoryList[0].ProdSubCategoryList[0].pySelected"));
				logger.info("Check the product code: "+jsonproductcode+" has been selected");
								}

					}	
											}
			}catch(Exception e){
				
			}
			
}

	}

