package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.*;

public class FullDataCheckerSetValue {
	
	public static Logger logger = Logger.getLogger(FullDataCheckerSetValue.class);
	
	private static JSONObject json = FDMRequestGen.jsonReq;
	
	static String FullName = null;

	public static void main(String[] args) {
		

	}
	
	public static void setContent(){
		
	}

	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
		
}
