package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;
import com.scb.rtob.module.test.framework.utils.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class InternalVerificationRequestGen {
	
	public static Logger logger = Logger.getLogger(InternalVerificationRequestGen.class);
	public static JSONObject jsonReq;
	

	public static void main(String[] args) throws Throwable {
		
		GetCase.loadProps();
		System.out.println("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("InternalVerification_Template"));
		
	}
		
	@Given("^Call the PromoteCase api for InternalVerification$")
	public static void promoteBasic() throws Throwable {
		
		
		JSONParser parser = new JSONParser();
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("InternalVerification_Template"));
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueInternalVerification();
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));	
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_InternalVerification"));
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		GetCase.responseJSON=(JSONObject)obj;
		logger.info(GetCase.response.getStatusCode());
		GetCase.scenarioCurrent.write("Status Code : "+GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);
		GetCase.scenarioCurrent.write("JSON Response : "+GetCase.responseJSON);
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
//	@Given("^validate if the application moved to Blind Data Capture$")
//	public static void validateWorkbasket() throws Throwable {
//		
//		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
//		
//		jsonReq = null;
//		
//		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_Blind")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket"));
//		
//		Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_Blind"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
//		
//	}

	public static void setValueInternalVerification() throws ClassNotFoundException, SQLException, IOException{
		
		DBUtils.convertDBtoMap("acdquery");
		
		InternalVerificationSetValue.setJSON(jsonReq);
		
		InternalVerificationSetValue.setPrimaryData();
				
		if(GetCase.isCoApp){
			
			InternalVerificationSetValue.setCoapplicantData(1);
//			InternalVerificationSetValue.setCoapplicantData(2);
//			InternalVerificationSetValue.setCoapplicantData(3);
		}
		
	}	

}