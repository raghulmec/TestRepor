package com.scb.rtob.module.test.framework.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.scb.rtob.module.test.framework.glue.GetCase;

public class CommonUtils {

	private static Logger logger = Logger.getLogger(CommonUtils.class);
	
	public static String screenShotPath = "C:/CaptureScreenshot";
	
	//static Wrapper wrap= new Wrapper();
	//static Commons com=new Commons();
	
	public static List<LinkedHashMap<String, String>> mydata = new ArrayList<LinkedHashMap<String, String>>();
	
	public static List<ArrayList<String>> xceldata = new ArrayList<ArrayList<String>>();
	
	public List<HashMap<String, String>> inputData = new ArrayList<HashMap<String, String>>();
	
	public List<List<HashMap<String, String>>> mydata1 = new ArrayList<List<HashMap<String, String>>>();
	
	public static int rowCount = 10;

	
	@SuppressWarnings({ "resource" })
	public static void convertExcelToMap(String FilePath,String FileName,String sheetName) throws IOException, ClassNotFoundException, SQLException{
		mydata.clear();

		
		String ext1 = FilenameUtils.getExtension(FileName);
		logger.info("File extension is :"+ext1);
		
		String MyFile= FilePath+File.separator+FileName;
		logger.info("MyFile[before] :"+MyFile);

		File file = null;
		FileInputStream fin = null;
		try {
			file = new File(MyFile);
			fin = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		logger.info("MyFile[after] :"+file.toString());		
		
		if(ext1.equalsIgnoreCase("xls"))
		{
			logger.info("Inside xls Condition");			
			HSSFWorkbook book = new HSSFWorkbook(fin);
			HSSFSheet sheet = book.getSheet(sheetName);
			rowCount = sheet.getPhysicalNumberOfRows();
			Row headerRow = sheet.getRow(0);			
			forItteration(sheet,headerRow);
		}
		else if(ext1.equalsIgnoreCase("xlsx"))
		{
			logger.info("Inside xlsx Condition");
			XSSFWorkbook book = new XSSFWorkbook(fin);
			XSSFSheet sheet = book.getSheet(sheetName);
			rowCount = sheet.getPhysicalNumberOfRows();
			Row headerRow = sheet.getRow(0);
			forItteration(sheet,headerRow);
		}

		

	}
	
	@SuppressWarnings("deprecation")
	public static void forItteration(Sheet sheet, Row HeaderRow)
	{
		logger.info("Inside Loop");	
		for (int i = 1; i < rowCount; i++) {
			Row currentRow = sheet.getRow(i);
		    int val = currentRow.getPhysicalNumberOfCells();
		    LinkedHashMap<String, String> currentHash = new LinkedHashMap<String, String>(); 
		    for (int j = 0; j <val; j++) {
		        Cell currentCell = currentRow.getCell(j);
		        
		        try{
		        	
		        switch (currentCell.getCellType()) {
		            case Cell.CELL_TYPE_STRING:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue()); 
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue())); 
		                break;
		        	}
		        }
		        
		        catch(NullPointerException NPE){
		        	
		        	currentHash.put(HeaderRow.getCell(j).getStringCellValue(), "null"); 
		        }
		    }
		    
		    mydata.add(currentHash);
		}
		
	}
	
	
	public static String readColumn(String column,int row){
		HashMap<String, String> map = mydata.get(row);
		String result=null;
        for (Entry<String, String> entry : map.entrySet()) {
        	if(entry.getKey().equalsIgnoreCase(column)){
        		logger.info(entry.getValue());
        		result = entry.getValue();
        	}

        }
       return result;
       
       
	}
	
	
	
	public static String readColumnUpdate(String column,int row){
		HashMap<String, String> map = mydata.get(row);
		String result=null;
        for (Entry<String, String> entry : map.entrySet()) {
        	String newalka = entry.getKey();
        	logger.info(newalka);
        	if(newalka.equalsIgnoreCase(column)){
        		logger.info(entry.getValue());
        		result = entry.getValue();
        		break;
        	}

        }
       return result;
       
       
	}
	
	public static String readColumn1(String column){
		for(int i=0;i<10;i++){
		HashMap<String, String> map = mydata.get(i);
		String result=null;
        for (Entry<String, String> entry : map.entrySet()) {
        	if(entry.getKey().equalsIgnoreCase(column)){
        		logger.info(entry.getValue());
        		//result = entry.getValue();
        		//System.out.println(result);
        	}

        }
      
		}
		return column;
		
		
       
	}
	
	public static String readColumnWithRowID(String column,String rowID){
		logger.info("row :"+column+":"+rowID);
		String result=null;
		try{
			for(int i=0;i<rowCount;i++){
				if(readColumn("Scenarioid", i).equalsIgnoreCase(rowID)){
					logger.info("matched with "+readColumn("Scenarioid", i));
					result = readColumn(column, i);
					break;
				}
			}
		}
		catch(IndexOutOfBoundsException I){
			logger.info("Row ID didn't match");
			I.printStackTrace();
		}
		catch(Exception E){
			logger.info("Reading from Excel has failed");
		}
		logger.info("result : "+result);
		return result;
	}
	
	@SuppressWarnings({ "deprecation", "resource", "unused" })
	public static void convertExcelToMapFromLocal(String FilePath,String FileName,String sheetName) throws IOException{
		mydata.clear();
		String MyFile= FilePath+File.separator+FileName;
		HSSFWorkbook book = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(MyFile)));
		FileInputStream fin = new FileInputStream(MyFile);
//		HSSFWorkbook book = new HSSFWorkbook(fin);
		HSSFSheet sheet = book.getSheet(sheetName);
//		XSSFWorkbook book = new XSSFWorkbook(fin);
//		XSSFSheet sheet = book.getSheet(sheetName);
		/*for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
		{
		    Row currentRow = sheet.getRow(i);
		    for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		    {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType())
		        {
		            case Cell.CELL_TYPE_STRING:
		                System.out.print(currentCell.getStringCellValue() + "|");
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                System.out.print(currentCell.getNumericCellValue() + "|");
		                break;
		              
		            case Cell.CELL_TYPE_BLANK:
		                System.out.print("<blank>|");
		                break;
		        }
		    }
		    System.out.println("\n");
		}*/
		rowCount = sheet.getPhysicalNumberOfRows();
		Row HeaderRow = sheet.getRow(0);
		for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
		    Row currentRow = sheet.getRow(i);
		    LinkedHashMap<String, String> currentHash = new LinkedHashMap<String, String>();
		    for (int j = 0; j < currentRow.getPhysicalNumberOfCells(); j++) {
		        Cell currentCell = currentRow.getCell(j);
		        switch (currentCell.getCellType()) {
		            case Cell.CELL_TYPE_STRING:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
		                break;
		            case Cell.CELL_TYPE_NUMERIC:
		                currentHash.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(currentCell.getNumericCellValue()));
		                break;
		        }
		    }
		    mydata.add(currentHash);
		    //System.out.println("\n\n"+currentHash);
		}
		//logger.info(mydata);
		//logger.info(mydata.get(0));
	}
	
	/**************************************************************************************************
	 * @author 1575731
	 * MehtodName: readFilefromDirectory
	 * It accepts 2 arguments (String directory, String jsonTemplateName)
	 **** 1. directory
	 **** 2. jsonTemplateName
	 * Objective: It will read the file from the given directory
	 * @return FileReader 
	 **************************************************************************************************/	
	
	public static FileReader readFilefromDirectory(String directory, String jsonWithExtension) throws FileNotFoundException
	{
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+directory+File.separator+""+jsonWithExtension);
		return reader;
	}

	
	
}
