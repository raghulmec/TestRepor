package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.utils.DBUtils;
import com.scb.rtob.module.test.framework.utils.FullDataSetValue;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

	/*********************************@Author: Shaik Dilawar Hassan*************************************/		
public class NegativeProbable {

	
	private static JSONObject json = FDMRequestGen.jsonReq;
	public static Logger logger = Logger.getLogger(NegativeProbable.class);
	
	static String NegativeProbableScenarioID = "2";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	
	/**************************************************************************************************
	 * Function to read,parse json file and authenticate.
	 * And Returns Authenticated application by logging in.
	 * @throws Throwable 
	 **************************************************************************************************/	
	@Then("^Call the PromoteCase api for Negative Probable$")
	public static void promoteNativeProbable() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD_Flow"+File.separator+""+GetCase.envmap.get("NegativeProbable_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueNegativeProbable();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		/****************************Authentication Part Starts****************************************/
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get(f"ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_NegativeProbable"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	
    /**************************************************************************************************
	 * Function to modify details by promoting via json file.
	 * And Returns application with updated data in Negative probable WorkBasket.
	 * @throws Throwable, SQLException, IOException
	 **************************************************************************************************/	
	@When("^Set values for Negative probable $")
	
		public static void setValueNegativeProbable() throws Throwable, SQLException, IOException{
		
		DBUtils.convertDBtoMap("acdquery");
		
		setJSON(jsonReq);
	
		setNegativeProbableMatchDetails();
		
		}
	
	public static void setNegativeProbableMatchDetails(){
		JsonPath.parse(json).set("$.content.NegativeProbableMatch[0].Match",DBUtils.readColumnWithRowID("Match", GetCase.scenarioID));
		JsonPath.parse(json).set("$.content.NegativeProbableMatch[0].Nomatch",DBUtils.readColumnWithRowID("Nomatch", GetCase.scenarioID));
	
	}
	
	
}
