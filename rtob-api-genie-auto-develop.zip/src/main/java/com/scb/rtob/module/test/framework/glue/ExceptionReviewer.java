package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import cucumber.api.java.en.Given;

public class ExceptionReviewer {

public static Logger logger = Logger.getLogger(ExceptionReviewer.class);
	
	static String ExceptionReviewerScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	
	public static void main(String[] args) {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		//promoteBasic();
	}
	
	
	@Given("^Call the PromoteCase api for Exception Reviewer$")
	public static void promoteException() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"ExceptionReviewer"+File.separator+""+GetCase.envmap.get("ExceptionReviewer_Template"));
		
	
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
	
		/****************************Set values for JSON attributes*************************************/
		
		//setValueExceptionReviewer();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_ExceptionReviewer"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));	
	}
	
	
	@Given("^validate the wb the application is moved to from Exception Reviewer$")
	public static void validateWorkbasket() throws Throwable {
		
		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		
    	GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_ExceptionReviewer")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket").toString());
	
		Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_ExceptionReviewer"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	}

	
}

