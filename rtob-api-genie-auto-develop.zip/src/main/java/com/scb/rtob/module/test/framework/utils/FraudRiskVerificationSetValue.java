package com.scb.rtob.module.test.framework.utils;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.FDMRequestGen;
import com.scb.rtob.module.test.framework.glue.GetCase;

public class FraudRiskVerificationSetValue {
	
public static Logger logger = Logger.getLogger(FraudRiskVerificationSetValue.class);
	
	private static JSONObject json = FDMRequestGen.jsonReq;
	
	static String FullName = null;
	static String coApplicantFullName = null;
	static String ShortName = null;
	
	public static void setJSON(JSONObject JSONObj){
		json = JSONObj;
	}
	
	public static void fraudRiskVerificationList(){
		
		
	
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[0].VerifyResult",DBUtils.readColumnWithRowID("VerifyResult1", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[1].VerifyResult2",DBUtils.readColumnWithRowID("VerifyResult2", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[2].VerifyResult3",DBUtils.readColumnWithRowID("VerifyResult3", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[3].VerifyResult4",DBUtils.readColumnWithRowID("VerifyResult4", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[4].VerifyResult5",DBUtils.readColumnWithRowID("VerifyResult5", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[5].VerifyResult6",DBUtils.readColumnWithRowID("VerifyResult6", GetCase.scenarioID));
		
		
		JsonPath.parse(json).set("$.content.Customers[0].FraudRiskVerificationList[6].VerifyResult7",DBUtils.readColumnWithRowID("VerifyResult7", GetCase.scenarioID));
		
		
	}

}
