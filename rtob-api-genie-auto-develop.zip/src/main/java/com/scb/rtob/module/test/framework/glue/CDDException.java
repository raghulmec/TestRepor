package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;
import org.junit.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.internal.filter.ValueNode.JsonNode;
import com.scb.rtob.module.test.framework.utils.*;

import cucumber.api.java.en.Given;


public class CDDException {
	
	public static Logger logger = Logger.getLogger(CDDException.class);
	
	static String CDDReviewerScenarioID = "1";
	
	/********To be used in BasicSetValue class***********************/
	
	public static JSONObject jsonReq;
	
	

	public static void main(String[] args) throws Throwable {
		
		GetCase.scenarioID="05";
		
		GetCase.loadProps();
		
		logger.info(GetCase.envmap);
		
		//promoteBasic();
	
	}
		
	@Given("^Call the PromoteCase api for CDD Exception$")
	public static void promoteBasic() throws Throwable {
		
		JSONParser parser = new JSONParser();
		
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+
				"jsontemplates"+File.separator+"CDDException"+File.separator+""+GetCase.envmap.get("CDDException_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
		
		setValueCDDException();
		
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		
		RestAssured.baseURI = GetCase.envmap.get("URI");
		
		RestAssured.useRelaxedHTTPSValidation();
		
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_BDC", GetCase.scenarioID));
		//httpRequest.header("ApplicationRefNo",GetCase.envmap.get("ApplicationRefNo"));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_CDDException"));
		
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		
		logger.info(GetCase.response.getStatusCode());
		
		logger.info(GetCase.response.headers());
		
		logger.info(GetCase.responseJSON);
		
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	@Given("^validate if the application moved from CDD Exception to CDD Reviewer$")
	public static void validateWorkbasket() throws Throwable {
		
		logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket"));
		
		GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_CDDReviewer")+", Actual : "+GetCase.responseJSON.get("CurrentWorkBasket").toString());
		
	//	Assert.assertEquals(GetCase.envmap.get("CurrentWorkBasket_CDDReviewer"),GetCase.responseJSON.get("CurrentWorkBasket").toString());
	}

	public static void setValueCDDException() throws ClassNotFoundException, SQLException, IOException{
		
		FullDataSetValue.setJSON(jsonReq);
		
		
		FullDataSetValue.setBasicDataCaptureFields_CustomerTab();
		FullDataSetValue.setCustomerDetails();
		FullDataSetValue.FamilyDetails();
		FullDataSetValue.setCustomerContactsDetails();
		FullDataSetValue.setEmployeementDetails();
		FullDataSetValue.setAddress();
		FullDataSetValue.setFatcaInfoDetails();
		FullDataSetValue.Eops();
		FullDataSetValue.moreFinancialSection();
		FullDataSetValue.setInfoCodeDetails();
		CDDExceptionSetValue.setContent();		
		
		
				if(GetCase.isCoApp){
					

					FullDataSetValue.setCoapplicantDetails(1);
					FullDataSetValue.setCoapplicantDetails(2);
					FullDataSetValue.setCoapplicantDetails(3);
					FullDataSetValue.setCoapplicantDetails(4);
							
				}
				
	}


}