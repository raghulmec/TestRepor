package com.scb.rtob.module.test.framework.utils;

import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jayway.jsonpath.JsonPath;
import com.scb.rtob.module.test.framework.glue.ACDRequestGen;
import com.scb.rtob.module.test.framework.glue.GetCase;





public class ACDSetValue {

	public static Logger logger = Logger.getLogger(ACDSetValue.class);
	//	public static org.json.JSONObject json = ACDRequestGen.jsonReq;
	public static JSONObject json = ACDRequestGen.jsonReqRes;
	public static JSONObject GetResponseJSONObject = new JSONObject();
	public static JSONArray GetResponseJSONArray = new JSONArray();
	public static org.json.simple.JSONObject jsonReq = ACDRequestGen.jsonReq;
	public static org.json.simple.JSONObject getRequestJsonObject = new org.json.simple.JSONObject();
	public static org.json.simple.JSONArray getReqJsonArray = new org.json.simple.JSONArray();

	public static void updateJSON(String targetKey, String value){

		JSONObject BufferJSONObject = GetResponseJSONObject;
		if(BufferJSONObject!=null){

			if (BufferJSONObject.has(targetKey)){

				logger.info(targetKey+" is present in JSON");

				BufferJSONObject = GetResponseJSONObject;
				//removing the KEY:VALUE entirely
				BufferJSONObject.remove(targetKey);
				logger.info("Writing the "+value+" for "+targetKey);
				BufferJSONObject.put(targetKey, value);
			}
			else{
				logger.info(targetKey+" is not present in JSON");
				BufferJSONObject.put(targetKey, value);
				logger.info("writing successfully in JSONObject the KEY : VALUE pair");
				GetResponseJSONObject = json;


			}

		}

		else{

			JSONArray BufferJSONArray = GetResponseJSONArray;

			JSONObject tempObj = new JSONObject();
			tempObj.put(targetKey, value);
			BufferJSONArray.put(tempObj);


		}

	}


	public static void UpdateJSONTemplate(String NodePath, String targetKey, String value){

		String [] keys = NodePath.split("\\.");
		logger.info(targetKey);

		for (int i=0;i<keys.length;i++){

			String key = keys[i];
			logger.info(key);
			JSONObject HolderJSONObject = GetResponseJSONObject;
			if (HolderJSONObject.has(key)){

				JSONArray tempJA = HolderJSONObject.optJSONArray(key);
				if(tempJA!=null){

					tempJA = HolderJSONObject.getJSONArray(key);
					int tempJALength = tempJA.length();
					String nodePathDup;
					String nodePath = new String();
					for (int j=i;j<keys.length; j++){

						nodePathDup = keys[j];
						if (j<keys.length-1)
							nodePath = nodePath+nodePathDup+".";
						else
							nodePath = nodePath + nodePathDup;


					}

					for (int index = 0; index <tempJALength; index++){
						logger.info(key+ " is here");
						JSONObject TempJO = tempJA.getJSONObject(index);
						GetResponseJSONObject = TempJO;
						//UpdateJSONTemplate(nodePath, targetKey, value);
						System.out.println(key);
						System.out.println(keys[keys.length-1]);

						if (key == keys[keys.length-1])
							updateJSON(targetKey, value);
					}

				}
				else{

					JSONObject tempJO = HolderJSONObject.getJSONObject(key);
					GetResponseJSONObject = tempJO;
					System.out.println(keys[keys.length -1]);
					if (key == keys[keys.length -1]){

						logger.info("here i am ");
						updateJSON(targetKey, value);

					}
				}

			}
		}
		GetResponseJSONObject = json;

	}		/*
			 */

	public static void UpdateJSONTemplate(String NodePath, String targetKey, String value, String getJson,String RelID){



		java.util.List<String> Relationshipno = JsonPath.parse(jsonReq).read(GetCase.envmap.get(getJson));

		String [] keys = NodePath.split("\\.");
		logger.info(targetKey);

		for (int i=0;i<keys.length;i++){

			String key = keys[i];
			logger.info(key);
			JSONObject HolderJSONObject = GetResponseJSONObject;
			if (HolderJSONObject.has(key)){

				JSONArray tempJA = HolderJSONObject.optJSONArray(key);
				if(tempJA!=null){

					tempJA = HolderJSONObject.getJSONArray(key);
					int tempJALength = tempJA.length();
					String nodePathDup;
					String nodePath = new String();
					for (int j=i;j<keys.length; j++){

						nodePathDup = keys[j];
						if (j<keys.length-1)
							nodePath = nodePath+nodePathDup+".";
						else
							nodePath = nodePath + nodePathDup;


					}


					for (int index = 0; index <tempJALength; index++){
						logger.info(key+ " is here");
						JSONObject TempJO = tempJA.getJSONObject(index);
						GetResponseJSONObject = TempJO;
						//UpdateJSONTemplate(nodePath, targetKey, value);
						System.out.println(key);
						System.out.println(keys[keys.length-1]);

						if (key == keys[keys.length-1]){
							for(String Relation:Relationshipno){
								String Rel=Relation.trim();
								if(RelID.equalsIgnoreCase(Rel)){
									updateJSON(targetKey, value);
									break;
								}
							}
							break;
						}
					}
				}
				else{

					JSONObject tempJO = HolderJSONObject.getJSONObject(key);
					GetResponseJSONObject = tempJO;
					System.out.println(keys[keys.length -1]);
					if (key == keys[keys.length -1]){

						logger.info("here i am ");
						updateJSON(targetKey, value);

					}
				}

			}
		}
		GetResponseJSONObject = json;
	}



























	public static void JSONArrayReader(JSONArray GetResponseJSONArray){

		int GetResponseJSONArrayLength = GetResponseJSONArray.length();
		JSONArray tempJSONArray = GetResponseJSONArray;
		//traversing through the indices of the JSONArray
		for (int loop = 0; loop<GetResponseJSONArrayLength; loop++){


			Object GetResponseJSONArrayValue = GetResponseJSONArray.get(loop);
			//code to check whether the value of the current JSONArray-index is a JSONObject
			if (GetResponseJSONArrayValue instanceof JSONObject){

				JSONObject HolderJSONObject = (JSONObject)GetResponseJSONArrayValue;

				JSONObjectReader(HolderJSONObject);

			}
			//code to check whether the value of the current JSONArray-index is a JSONArray or not
			else{
				//code to check whether the value of the current JSONArray-index is a JSONArray
				if (GetResponseJSONArrayValue instanceof JSONArray){

					JSONArray HolderJSONArray = (JSONArray)GetResponseJSONArrayValue;
					JSONArrayReader(HolderJSONArray);
					GetResponseJSONArray = tempJSONArray;

				}
				//if the value of the current JSONArray-index is neither a JSONObject nor a JSONArray
				else {

					logger.info("In JSONArray: "+loop);
					logger.info("The JSONArray Key "+loop+"'s value is neither a JSONObject nor a JSONArray.");
					logger.info("The VALUE is "+GetResponseJSONArrayValue.toString());

				}

			}



		}
	}

	public static void JSONObjectReader(JSONObject InputJSONObject){

		GetResponseJSONObject = InputJSONObject;

		Set <String> GetResponseJSONObjectKeysList = GetResponseJSONObject.keySet();
		Iterator <String> GetResponseJSONObjectKeysListIte = GetResponseJSONObjectKeysList.iterator();
		//code for traversing the JSONObject KEY:VALUE pairs
		while (GetResponseJSONObjectKeysListIte.hasNext()){

			String keys = GetResponseJSONObjectKeysListIte.next();
			logger.info(keys);
			//code to check whether the keys value is a JSONObject
			JSONObject HolderJSONObject = GetResponseJSONObject.optJSONObject(keys);
			//if keys value is not a JSONObject
			if (HolderJSONObject == null){
				//code to check whether the keys value is a JSONArray
				JSONArray HolderJSONArray = GetResponseJSONObject.optJSONArray(keys);
				//if keys value is not a JSONArray
				if (HolderJSONArray == null){

					logger.info("The JSONObject Key "+keys+"'s value is neither a JSONObject nor a JSONArray.");

					logger.info("VALUE is: "+InputJSONObject.get(keys).toString());


				}
				//if keys value is a JSONArray
				else{

					logger.info("Inside JSONArray: "+keys);

					HolderJSONArray = GetResponseJSONObject.getJSONArray(keys);
					JSONArrayReader(HolderJSONArray);


				}

			}
			//if keys value is a JSONObject
			else{

				JSONObject TempJSONObject = GetResponseJSONObject;
				HolderJSONObject = GetResponseJSONObject.getJSONObject(keys);
				logger.info("Inside JSONObject: "+keys);
				JSONObjectReader(HolderJSONObject);
				GetResponseJSONObject = TempJSONObject;

			}

		}

	}

}
