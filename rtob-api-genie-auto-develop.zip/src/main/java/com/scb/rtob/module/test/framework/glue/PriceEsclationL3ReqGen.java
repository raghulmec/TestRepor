package com.scb.rtob.module.test.framework.glue;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileReader;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;

import com.scb.rtob.module.test.framework.utils.DBUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PriceEsclationL3ReqGen
{
	private static JSONObject json = FDMRequestGen.jsonReq;
	public static JSONObject jsonReq;
	
	public static Logger logger = Logger.getLogger(DisplayOffersRequestGen.class);
	

	/**************************************************************************************************
	 * This function is to check if application is available in PriceEsclationL3 WB or not.
	 * @throws Throwable
	 **************************************************************************************************/
	@Given("^validate if the application is available in Price Esclation L3 WorkBasket$")
	public static void validateCurrentBasket() throws Throwable {
		
		System.out.println("AfterPromoteWB :=============> " + GetCase.afterPromoteWB);
		if(GetCase.afterPromoteWB.contains(GetCase.envmap.get("CurrentWorkBasket_PriceEscalationL3WB")))
		{
			
			logger.info("Application is available under Price EscalationL3 WB");
			Assert.assertTrue("Application did'nt moved to DisplayOffer", GetCase.afterPromoteWB.contains(GetCase.envmap.get("CurrentWorkBasket_PriceEscalationL3WB")));
		}
		else
		{
			System.out.println("AfterPromoteWB" + GetCase.afterPromoteWB);
			logger.info("Application is not available under Price EscalationL3 WB");
			Assert.assertTrue("Application is not available under Price EscalationL3 WB",false);
		}
	}
	
	
	
	@Then("^Call the PromoteCase api for PriceEsclationL3 WB$")
	public static void promotePriceEsclation() throws Throwable {
		
		JSONParser parser = new JSONParser();
		FileReader reader = new FileReader("."+File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsontemplates"+File.separator+"ACD"+File.separator+""+GetCase.envmap.get("PriceEsclationL3_Template"));
		
		jsonReq = (JSONObject) parser.parse(reader);
		logger.info(jsonReq);
		
		/****************************Set values for JSON attributes*************************************/
//		setDisplayOffers();
		logger.info(jsonReq);
		
		/****************************Start - API call part**********************************************/
		RestAssured.baseURI = GetCase.envmap.get("URI");
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic(GetCase.envmap.get("apiUserName"), GetCase.envmap.get("apiPassWord"));
		
		httpRequest.header("ApplicationRefNo",DBUtils.readColumnWithRowID("ApplicationID_ACD", GetCase.scenarioID));
		httpRequest.header("CurrentWorkBasket",GetCase.envmap.get("CurrentWorkBasket_PriceEscalationL3WB"));
		httpRequest.body(jsonReq);
		
		GetCase.response = httpRequest.request(Method.PUT,"/PromoteCase");
		Object obj=JSONValue.parse(GetCase.response.getBody().asString());
		
		GetCase.responseJSON=(JSONObject)obj;
		GetCase.afterPromoteWB= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		
		logger.info(GetCase.response.getStatusCode());
		logger.info(GetCase.response.headers());
		logger.info(GetCase.responseJSON);
		logger.info("Status Code ok: "+AuthenticateRTOB.validateStatusCode(GetCase.response.getStatusCode()));
        
	}
	
	/**************************************************************************************************
	 * This function is to check if application has moved from PriceEsclation L3 to Next WorkBasket.
	 * And Returns if application has moved to Next WorkBasket
	 * @throws Throwable
	 **************************************************************************************************/
	@Given("^validate if the application moved from Price Esclation L3 to Next WorkBasket$")
	public static void validatePriceEsclationL3() throws Throwable {
		
		String currentWorkBasket= GetCase.responseJSON.get("CurrentWorkBasket").toString();
		logger.info("Current Workbasket : "+currentWorkBasket);
		
		if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")))
		{
			logger.info("When PCO call is [DECLINE] application will land to DisplayOffers");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to DisplayOffer", currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_DisplayOffers")));
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CreditInitiationWB")))
		{	
			logger.info("When PCO call is [REFER] application will land to Credit Initiation");
			GetCase.scenarioCurrent.write("Expected : "+GetCase.envmap.get("CurrentWorkBasket_CreditInitiationWB")+", Actual : "+currentWorkBasket);
			Assert.assertTrue("Application did'nt moved to Credit Initiation",currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CreditInitiationWB")));
		}
		else if(currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_Fraud")) && currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CDDReviewer"))  )
		{	
			logger.info("When PCO call is [APPROVE] application will move to system wait");
			Assert.assertTrue("Application did'nt moved to system wait",currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_Fraud"))&& currentWorkBasket.contains(GetCase.envmap.get("CurrentWorkBasket_CDDReviewer")));
		}
		else
		{
			logger.info("Current Workbasket : "+GetCase.responseJSON.get("CurrentWorkBasket")+" Does Not Matches with Expected Workbasket");
			Assert.assertTrue("Does Not Matches with any Expected Workbasket",false);
		}
	}
	
	
	
	
	

}
